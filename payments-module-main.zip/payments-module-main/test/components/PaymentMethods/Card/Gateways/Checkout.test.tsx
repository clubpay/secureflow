import { CheckoutCardPayment } from "@/components/PaymentMethods/Card/Gateways";

test("Component should be defined", () => {
  expect(CheckoutCardPayment).toBeDefined();
});
