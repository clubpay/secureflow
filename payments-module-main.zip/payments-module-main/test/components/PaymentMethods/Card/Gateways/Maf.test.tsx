import { MafCardPayment } from "@/components/PaymentMethods/Card/Gateways";

test("Component should be defined", () => {
  expect(MafCardPayment).toBeDefined();
});
