import { CardPayPortal } from "@/components/PaymentMethods/Card";

test("Component should be defined", () => {
  expect(CardPayPortal).toBeDefined();
});
