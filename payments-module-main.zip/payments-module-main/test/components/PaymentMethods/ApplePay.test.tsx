import { ApplePay } from "@/components/PaymentMethods/ApplePay";

test("Component should be defined", () => {
  expect(ApplePay).toBeDefined();
});
