import { GooglePay } from "@/components/PaymentMethods/GooglePay";

test("Component should be defined", () => {
  expect(GooglePay).toBeDefined();
});
