import { Checkbox } from "@/components/Core";

test("Component should be defined", () => {
  expect(Checkbox).toBeDefined();
});
