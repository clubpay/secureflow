import { Button } from "@/components/Core";

test("Component should be defined", () => {
  expect(Button).toBeDefined();
});
