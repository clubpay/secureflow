import { Input } from "@/components/Core";

test("Component should be defined", () => {
  expect(Input).toBeDefined();
});
