import type { StorybookConfig } from "@storybook/react-vite"
import { mergeConfig } from 'vite';
import { default as path } from 'path';
import { cssOptions } from "../vite.config";

const config: StorybookConfig = {
  stories: ["../src/**/*.mdx", "../src/**/*.stories.@(js|jsx|mjs|ts|tsx)"],
  addons: [
    "@storybook/addon-links",
    "@storybook/addon-essentials",
    "@storybook/addon-interactions",
    "storybook-addon-deep-controls",
    "storybook-addon-react-router-v6"
  ],
  docs: {
    autodocs: "tag",
  },
  staticDirs: ['./public'],
  framework: {
    name: "@storybook/react-vite",
    options: {},
  },
  async viteFinal(config) {
    return mergeConfig(config, {
      resolve: {
        alias: {
          "@/": `${path.resolve(__dirname, "../src")}/`
        }
      },
      css: cssOptions,
    });
  },
}
export default config
