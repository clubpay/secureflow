
import { create } from '@storybook/theming/create';

export default create({
  base: 'light',
  brandTitle: 'Qlub',
  brandUrl: 'https://qlub.com.au',
  brandImage: './qlub.png',
  brandTarget: '_self',
});