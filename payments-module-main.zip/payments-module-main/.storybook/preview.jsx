const preview = {
  parameters: {
    actions: { argTypesRegex: "^on[A-Z].*" },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/,
      }
    },
    deepControls: { enabled: true },
    options: {
      storySort: (a, b) => {
        return a.id.split("-").length - b.id.split("-").length
      },
    },
  },
}

export default preview
