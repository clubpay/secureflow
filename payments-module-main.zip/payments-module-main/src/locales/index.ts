import { KeyValue } from "@/types";

const locales: KeyValue = {};

let loadedTranslations: KeyValue = {};

const browserLanguage = typeof window !== "undefined" ? navigator.language.split("-")[0] : "en";

const translations = (import.meta as any).glob("./*.json");

export const load = async (locale?: string): Promise<string> => {
  locale ??= browserLanguage;
  locales[locale] ??=
    (await translations[`./${locale}.json`]?.()
      .then((m: any) => m.default)
      .catch(() => ({}))) ?? {};
  loadedTranslations = locales[locale];
  return locale;
};

export const t = (key: string) => {
  if (Object.keys(loadedTranslations).length === 0) {
    return key;
  }
  return loadedTranslations[key] ?? key;
};

load();
