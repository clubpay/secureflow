export * from "./cards";
export * from "./storage";

export const APPLE_PAY_CONSENT_COOKIE_NAME = "apple_pay_billing_consent";
export const ROUTING_OVERIDING_COUNTRIES = ["ae"];
