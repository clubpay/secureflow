import { KeyValue } from "@/types";

const cardValidations: KeyValue = {
  invalid: {
    "card-number": "Enter a valid card number",
    "expiry-date": "Enter a valid expiry date",
    "cvv": "Enter a valid security code"
  },
  incomplete: {
    "card-number": "Enter a valid card number",
    "expiry-date": "Enter a complete expiry date",
    "cvv": "Enter a complete security code"
  }
};

export default cardValidations;
