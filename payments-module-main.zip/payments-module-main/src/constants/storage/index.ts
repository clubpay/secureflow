export default {
  ATTEMPT_WITH_PREFERRED_NETWORKS: "qlub.payment.apple.attempt_with_preferred_networks",
  ATTEMPT_WITH_PREFERRED_MERCHANT_CAPABILITIES: "qlub.payment.apple.attempt_with_preferred_merchants",
  LIMIT_FOREX: "qlub.payment.limit_forex",
  NAPS_ALERT_TRIGGERED: "qlub.payment.naps_alert_triggered",
  DEVICE_ID: "qlub.payment.device_id",
  CUSTOMER_PAYMENT_PROFILE: "qlub.payment.customer_payment_profile",
  IS_FOREX_USED: "qlub.payment.is_forex_used",
  IS_FOREX_INTERRUPTED: "qlub.payment.is_forex_interrupted"
};
