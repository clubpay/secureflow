import { createContext, useContext, useState } from "react";

interface ICardContext {
  isAddingCard: (tem: string) => boolean;
  toggleAddCard: (pgNameWithPayMethod: string) => void;
  disselectAddCard: (pgNameWithPayMethod: string) => void;
}

const CardContext = createContext<ICardContext>({
  isAddingCard: () => true,
  toggleAddCard: () => {},
  disselectAddCard: () => {}
});

export const CardProvider = ({ children }: { children: JSX.Element }) => {
  const [isAddingCard, setIsAddingCard] = useState<any>({});

  const toggleAddCard = (pgNameWithPayMethod: string) =>
    setIsAddingCard((prevState: any) => ({
      ...prevState,
      [pgNameWithPayMethod]: !Boolean(prevState?.[pgNameWithPayMethod])
    }));

  const disselectAddCard = (pgNameWithPayMethod: string) =>
    setIsAddingCard((prevState: any) => ({ ...prevState, [pgNameWithPayMethod]: false }));

  return (
    <CardContext.Provider
      value={{
        isAddingCard: (pgNameWithPayMethod: string) => isAddingCard?.[pgNameWithPayMethod],
        toggleAddCard,
        disselectAddCard
      }}
    >
      {children}
    </CardContext.Provider>
  );
};

export const useCardsData = () => useContext(CardContext);

export default useCardsData;
