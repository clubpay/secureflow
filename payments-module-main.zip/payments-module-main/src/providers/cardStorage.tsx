import { createContext, useContext, useState } from "react";
import { KeyValue } from "@/types";

// let rendered = false;

interface ICardStorageContext {
  enabled: Record<string, boolean>;
  savedCard: Record<string, KeyValue | null | undefined>;
  editInProgress: Record<string, boolean>;
  enable: (gatewayId: string, value: boolean) => void;
  setSavedCard: (gatewayId: string, value: KeyValue | null | undefined) => void;
  edit: (gatewayId: string, value: boolean) => void;
  isUsingSavedCard: (gatewayId: string) => boolean;
}

const CardStorageContext = createContext<ICardStorageContext>({
  enabled: {},
  savedCard: {},
  editInProgress: {},
  enable: () => {},
  setSavedCard: () => {},
  edit: () => {},
  isUsingSavedCard: () => false
});

export const CardStorageProvider = ({ children }: { children: JSX.Element }) => {
  const [enabled, setEnabled] = useState<Record<string, boolean>>({});
  const [savedCard, setSavedCard] = useState<Record<string, KeyValue | null | undefined>>({});
  const [editInProgress, setEditInProgress] = useState<Record<string, boolean>>({});

  // if (rendered) return children;

  // rendered = true;

  return (
    <CardStorageContext.Provider
      value={{
        enabled,
        savedCard,
        editInProgress,
        enable: (gatewayId: string, value: boolean) => setEnabled({ ...enabled, [gatewayId]: value }),
        setSavedCard: (gatewayId: string, value: KeyValue | null | undefined) =>
          setSavedCard({ ...savedCard, [gatewayId]: value }),
        edit: (gatewayId: string, value: boolean) => setEditInProgress({ ...editInProgress, [gatewayId]: value }),
        isUsingSavedCard: (gatewayId: string) =>
          !(enabled[gatewayId] && savedCard[gatewayId] && !editInProgress[gatewayId])
      }}
    >
      {children}
    </CardStorageContext.Provider>
  );
};

export const useCardStorage = () => useContext(CardStorageContext);

export default useCardStorage;
