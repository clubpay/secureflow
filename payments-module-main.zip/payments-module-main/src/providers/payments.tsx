import { createContext, useContext, useState } from "react";

interface IPaymentContext {
  processing: boolean;
  setProcessing: (value: boolean) => void;
  loading: boolean;
  setLoading: (value: boolean) => void;
}

const PaymentContext = createContext<IPaymentContext>({
  processing: false,
  setProcessing: () => {},
  loading: false,
  setLoading: () => {}
});

export const PaymentProvider = ({ children }: { children: JSX.Element }) => {
  const [processing, setProcessing] = useState(false);
  const [loading, setLoading] = useState(false);
  return (
    <PaymentContext.Provider
      value={{
        processing,
        setProcessing,
        loading,
        setLoading
      }}
    >
      {children}
    </PaymentContext.Provider>
  );
};

export const usePayment = () => useContext(PaymentContext);

export default usePayment;
