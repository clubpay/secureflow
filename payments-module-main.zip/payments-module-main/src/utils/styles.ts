import camelCase from "lodash/camelCase";

export interface ExtractedStyles {
  [key: string]: {
    [key: string]: {
      class?: string;
      attributes?: {
        [key: string]: string;
      };
    };
  };
}

export const extractStyles = (styles: { readonly [key: string]: string }, variants: string[]): ExtractedStyles => {
  return Object.entries(styles).reduce((acc: any, [key, value]) => {
    const variant = variants.find((v) => key.includes(v));
    if (variant) {
      if (!acc[variant]) acc[variant] = {};
      const classes = key.replace(`${variant}-`, "");
      const splitClasses = classes.split("-");
      if (!acc[variant][splitClasses[0]]) acc[variant][splitClasses[0]] = {};
      if (splitClasses.length > 1) {
        const property = camelCase(classes.replace(`${splitClasses[0]}-`, ""));
        if (!acc[variant][splitClasses[0]].attributes) acc[variant][splitClasses[0]].attributes = {};
        acc[variant][splitClasses[0]].attributes[property] = value;
      } else {
        acc[variant][splitClasses[0]].class = value;
      }
    }
    return acc;
  }, {});
};
