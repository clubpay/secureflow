export * from "./mada";

export const formatMaskedCard = (cardNumber: string) => {
  return cardNumber
    .replace(/x/g, "•")
    .replace(/(.{4})/g, "$1 ")
    .trim();
};

export const maskAndFormatNumber = (bin: string, last4: string): string => {
  return formatMaskedCard(`${bin}${"*".repeat(6)}${last4}`);
};

type CardBrandType = "visa" | "master" | "mastercard" | "amex" | "american express" | "vr" | "sodexo" | "unknown";

export interface ICard {
  bin: string;
  brand?: CardBrandType;
  cardHolderName: string;
  data: null;
  expirationMonth: number;
  expirationYear: number;
  maskedNumber: string;
  singleUse: boolean;
  token: string;
  selected: boolean;
}
