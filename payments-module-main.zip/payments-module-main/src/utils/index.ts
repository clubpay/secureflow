import { jwtDecode } from "jwt-decode";
import { v4 as uuidv4 } from "uuid";
import storage from "@/constants/storage";

export * from "./json";
export * from "./cardNetworks";
export * from "./payments";
export * from "./events";
export * from "./styles";
export { constructBasePaymentPayload, gaEventSuffix, getPaymentKitProps } from "./payments";

export enum ErrorMessageKey {
  Card = "card",
  Expiry = "expiry",
  Cvv = "cvv",
  Name = "name",
  Generic = "generic",
  Cpf = "cpf"
}

export const isSafari = () => {
  if (!process.browser) {
    return false;
  }
  return /^((?!chrome|android).)*safari/i.test(window?.navigator.userAgent);
};

export const getPGNameFromId = (pgID: string, gateways: any[]) => {
  const pg = gateways.find((gateway) => gateway?.id === pgID);
  return pg?.name;
};

export const ErrorMessages: Record<ErrorMessageKey, string> = {
  [ErrorMessageKey.Card]: "Card number is invalid. Please check the details and retry",
  [ErrorMessageKey.Expiry]: "Expiry date is invalid. Please check the details and retry",
  [ErrorMessageKey.Cvv]: "CVV is invalid. Please check the details and retry",
  [ErrorMessageKey.Name]: "Cardholder's name is missing. Please check the details and try again.",
  [ErrorMessageKey.Generic]: "Card information is invalid. Please check the details and retry",
  [ErrorMessageKey.Cpf]: "CPF number is invalid. Please check the details and retry."
};

export const setCookie = (name: string, value: string, days = 1000) => {
  let expires = "";
  if (days) {
    var date = new Date();
    date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
    expires = "; expires=" + date.toUTCString();
  }
  document.cookie = name + "=" + (value || "") + expires + "; path=/";
};

export const getCookie = (name: string) => {
  var nameEQ = name + "=";
  var ca = document.cookie.split(";");
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == " ") c = c.substring(1, c.length);
    if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
  }
  return null;
};
export const eraseCookie = (name: string) => {
  document.cookie = name + "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;";
};
export const getDeviceId = () => {
  const existingId = localStorage.getItem(storage.DEVICE_ID);

  if (existingId) return existingId;
  const newId = uuidv4();
  localStorage.setItem(storage.DEVICE_ID, newId);
  return newId;
};

export const getCustomerId = () => {
  try {
    const auth = JSON.parse(localStorage.getItem("qlub.auth") || "");
    const decoded = jwtDecode<{ customerId: string }>(auth.JWTToken);
    return decoded?.customerId;
  } catch (error) {
    return null;
  }
};
