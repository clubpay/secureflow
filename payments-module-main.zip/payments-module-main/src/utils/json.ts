import { KeyValue } from "@/types";

export const prefixKeys = (object: KeyValue, prefix: string) => {
  return Object.keys(object).reduce((acc: KeyValue, key) => {
    acc[`${prefix}${key}`] = object[key];
    return acc;
  }, {});
};

export const addToKeys = (object: KeyValue, keyPair: KeyValue) => {
  return Object.keys(object).reduce((acc: KeyValue, key) => {
    acc[key] = {
      ...acc[key],
      ...keyPair
    };
    return acc;
  }, {});
};

export const prefixAndAddToKeys = (object: KeyValue, prefix: string, keyPair: KeyValue) => {
  return Object.keys(object).reduce((acc: KeyValue, key) => {
    acc[`${prefix}${key}`] = {
      ...object[key],
      ...keyPair
    };
    return acc;
  }, {});
};

export const prefixValues = (object: KeyValue, prefix: string) => {
  return Object.keys(object).reduce((acc: KeyValue, key) => {
    acc[key] = `${prefix}${object[key]}`;
    return acc;
  }, {});
};
