import { StripePaymentMethod } from "@/types";
import { StripeConfig } from "@/types/payments/config/stripe";
import { StripeConnectConfig } from "@/types/payments/config/stripeConnect";

const emailDisabledPaymentMethods = [StripePaymentMethod.KakaoPay];
const loadingRequiredPaymentMethods = [StripePaymentMethod.Paynow];

export const isLoadingDialogRequired = (paymentMethod?: StripePaymentMethod) => {
  return loadingRequiredPaymentMethods.includes(paymentMethod!);
};

export const isEmailDisabled = (paymentMethod?: StripePaymentMethod) => {
  return emailDisabledPaymentMethods.includes(paymentMethod!);
};

export const getPaymentMethods = (config: StripeConfig | StripeConnectConfig) => {
  const paymentMethods: string[] = [];
  if (!config.hideCardPay) paymentMethods.push(StripePaymentMethod.Card);
  if (config.grabPay) paymentMethods.push(StripePaymentMethod.Grabpay);
  if (config.alipay) paymentMethods.push(StripePaymentMethod.Alipay);
  if (config.kr_card) paymentMethods.push(StripePaymentMethod.KrCard);
  if (config.kakao_pay) paymentMethods.push(StripePaymentMethod.KakaoPay);
  if (config.naver_pay) paymentMethods.push(StripePaymentMethod.NaverPay);
  if (config.payco) paymentMethods.push(StripePaymentMethod.Payco);
  if (config.samsung_pay) paymentMethods.push(StripePaymentMethod.SamsunPay);

  return paymentMethods;
};
