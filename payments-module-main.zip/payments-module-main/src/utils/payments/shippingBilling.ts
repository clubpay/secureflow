import { APPLE_PAY_CONSENT_COOKIE_NAME } from "@/constants";
import { getCookie } from "@/utils";
import { PaymentTypeEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { qlubSessionStorage } from "@clubpay/customer-common-module/src/service/storage/sessionStorage";

export const disableApplePayShippingBilling = () => {
  qlubSessionStorage.set("qlub.payment.apple.disable_billing", "true");
};

export const getApplePayShippingBillingConfig: any = (config: any, paymentGateway: PaymentTypeEnum) => {
  const isCanceled = qlubSessionStorage.get("qlub.payment.apple.disable_billing");

  const isApplepayConsentCookieExist = getCookie(APPLE_PAY_CONSENT_COOKIE_NAME);

  if (paymentGateway === PaymentTypeEnum.Stripe || paymentGateway === PaymentTypeEnum.StripeConnect) {
    const stripeConfig = {
      requestPayerName: false,
      requestPayerEmail: false,
      requestPayerPhone: false
    };

    if (isCanceled) return stripeConfig;

    if (config.applePayShippingDetails) {
      stripeConfig.requestPayerName = true;
      stripeConfig.requestPayerEmail = true;
      stripeConfig.requestPayerPhone = true;
    }
    if (config.applePayBillingDetails) {
      stripeConfig.requestPayerName = true;
      stripeConfig.requestPayerEmail = true;
      stripeConfig.requestPayerPhone = true;
    }

    return stripeConfig;
  }

  if (isCanceled) return {};

  if (paymentGateway === PaymentTypeEnum.Tapp) {
    const tappConfig: Pick<
      ApplePayJS.ApplePayPaymentRequest,
      "requiredShippingContactFields" | "requiredBillingContactFields"
    > = {};

    if (config.applePayShippingDetails) {
      tappConfig.requiredShippingContactFields = ["phone", "email", "name"];
    }
    if (config.applePayBillingDetails) {
      tappConfig.requiredBillingContactFields = ["phone", "email", "name"];
    }

    return tappConfig;
  }

  const defaultConfig: Pick<
    ApplePayJS.ApplePayPaymentRequest,
    "requiredShippingContactFields" | "requiredBillingContactFields"
  > = {};

  if (config.applePayShippingDetails || isApplepayConsentCookieExist || config.applePayConsent) {
    defaultConfig.requiredShippingContactFields = ["phone", "email", "name"];
  }
  if (config.applePayBillingDetails) {
    defaultConfig.requiredBillingContactFields = ["phone", "email", "name"];
  }

  return defaultConfig;
};
