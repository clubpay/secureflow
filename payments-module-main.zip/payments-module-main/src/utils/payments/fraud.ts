import { UAParser } from "ua-parser-js";
import axiosInstance from "@clubpay/customer-common-module/src/repository/axios";
import { getDeviceId } from "..";

export const setHeaders = () => {
  const parser = new UAParser(window.navigator.userAgent);
  const result = parser.getResult();

  const details = {
    browser: {
      name: result?.browser?.name,
      version: result?.browser?.version
    },
    os: {
      name: result?.os?.name,
      version: result?.os?.version
    },
    device: {
      type: result?.device?.type,
      model: result?.device?.model,
      vendor: result?.device?.vendor,
      id: getDeviceId()
    }
  };

  axiosInstance.axios.defaults.headers.common["Client-Info"] = JSON.stringify(details);
};
