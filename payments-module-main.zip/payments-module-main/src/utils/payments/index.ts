import { endOfMonth, isBefore, startOfToday } from "date-fns";
import Button from "@/components/Core/Button";
import ApplePay from "@/components/Global/PaymentButtonForClient/ApplePay";
import GooglePay from "@/components/Global/PaymentButtonForClient/GooglePay";
import { shouldExcludePayMethodHelper } from "@/components/PaymentPortal/util";
import { ROUTING_OVERIDING_COUNTRIES } from "@/constants";
import storage from "@/constants/storage";
import { useCommonStore } from "@/stores/commonStore";
import { useForexStore } from "@/stores/forexStore";
import { usePGGroupStore } from "@/stores/pgGroupStore";
import {
  IForex,
  IGatewayPaymentHandler,
  PaymentGatewayConfig,
  PaymentKitPayloadType,
  PaymentProfile,
  QlubMetaData
} from "@/types";
import { IPayBasePayload } from "@/types/api/common";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { IRestaurantConfig } from "@clubpay/customer-common-module/src/repository/vendor/type";
import { parseJSON } from "@clubpay/customer-common-module/src/utility/k_json";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { ErrorMessageKey, ErrorMessages, getCustomerId } from "..";

export const constructBasePaymentPayload = (
  gatewayID: string,
  traceId?: string,
  qlub?: QlubMetaData,
  ref?: string,
  tipAmount?: any
): IPayBasePayload => {
  ref ??= getRandomString();

  const redirectUrlParams = { ref, traceId };

  let successUrl = qlub?.redirections?.success;
  let failureUrl = qlub?.redirections?.failure;

  if (typeof successUrl === "function") successUrl = successUrl(redirectUrlParams);
  if (typeof failureUrl === "function") failureUrl = failureUrl(redirectUrlParams);

  return {
    id: qlub?.sessionId,
    reference: ref,
    diningSessionID: qlub?.diningSessionId,
    tipAmount: tipAmount,
    successUrl,
    failureUrl,
    gatewayID
  };
};

export const gaEventSuffix = (savedCard: boolean) => (savedCard ? "saved" : "");

export const getPaymentKitProps = (pgs: any, payload: PaymentKitPayloadType) => {
  const forex = useForexStore.getState();

  const {
    amount,
    vendor,
    hasSplitPayment,
    enableCardPayment,
    events,
    diningSessionID,
    currencyPrecision,
    tip,
    lang,
    totalAmount,
    remainingAmount,
    consumer,
    extraConfig = {},
    billPaidStatus = "",
    isSubscriptionPayment
  } = payload;

  const qlub = {
    diningSessionId: diningSessionID,
    currencyPrecision,
    tip,
    lang,
    remainingAmount,
    isSplitPayment: !!hasSplitPayment,
    exchange: forex
  };

  const pg: PaymentGatewayConfig[] = pgs.map((item: any) => {
    const { id: gatewayId, name, config } = item;
    const {
      publicKey,
      supportedNetworks,
      supportedNetworksList,
      gatewayMerchantId,
      apiKey,
      publishableKey,
      pgOrder,
      pgDefaultSelected,
      merchantAccount
    } = config;

    return {
      id: gatewayId,
      name,
      vendor,
      amount,
      hasSplitPayment,
      config: {
        ...config,
        enableCardPayment,
        publicKey: publicKey || apiKey || publishableKey || gatewayMerchantId || merchantAccount,
        supportedNetworks: supportedNetworks || supportedNetworksList,
        googleAllowedCardNetworks: supportedNetworksList?.map((network: string) => network.toLowerCase()),
        pgOrder: pgOrder ?? 0,
        pgDefaultSelected: Boolean(pgDefaultSelected),
        events: {
          onReady: events?.onReady,
          onBeforePayment: (data: IGatewayPaymentHandler) => events?.onBeforePayment?.(gatewayId, data),
          onAfterPayment: events?.onAfterPayment,
          onUnlockPayment: () => events?.onUnlockPayment?.(gatewayId),
          onPaymentSuccess: (payload: any) => events?.onPaymentSuccess?.(gatewayId, payload),
          onPaymentPending: (payload?: any) => events?.onPaymentPending?.(gatewayId, payload),
          onPaymentFailure: (payload: IGatewayPaymentHandler) => events?.onPaymentFailure?.(gatewayId, payload),
          onPaymentCancel: events?.onPaymentCancel,
          onTraceStart: events?.onTraceStart,
          onTraceClose: events?.onTraceClose,
          onExchangeChange: events?.onExchangeChange,
          onOverlayClick: events?.onOverlayClick,
          onPgRegister: events?.onPgRegister,
          onPgUnregister: events?.onPgUnregister,
          isPgElemVisible: events?.isPgElemVisible?.(gatewayId),
          onPrePayment: events?.onPrePayment
        },
        extraConfig: { ...config, ...extraConfig }
      }
    };
  });

  return {
    locale: lang,
    amount,
    totalAmount,
    pg,
    qlub,
    hasPgGroup: vendor.paymentGatewayList.hasPgGroup,
    consumer,
    onPaymentMethodSelect: events?.onPaymentMethodSelect,
    billPaidStatus: billPaidStatus,
    countryCode: vendor.country?.code,
    vendor,
    isSubscriptionPayment
  };
};

export const getExpiryPlaceHolder = (part?: "month" | "year") => {
  const date = new Date();
  const year = Number(date.getFullYear()?.toString().slice(-2)) + 1;
  if (!part) {
    if (typeof year === "number") return `12/${year}`;
    return `MM/YY`;
  } else if (part === "month") return "12";
  else return year.toString();
};

export const MASTERPASS_PF_BANK_ICA = {
  sipay: "1017",
  ipara: "1002"
};

export const getAdditionalParameters = ({
  total,
  restaurantUnique,
  bankIca
}: {
  total: string;
  restaurantUnique: string;
  bankIca?: string;
}) => {
  const additionalParameters = {
    [MASTERPASS_PF_BANK_ICA.ipara]: {},
    [MASTERPASS_PF_BANK_ICA.sipay]: {
      additionalParameters: {
        order_product_name_arr: [restaurantUnique],
        order_product_code_arr: [restaurantUnique],
        order_price_arr: [total],
        order_qty_arr: ["1"],
        order_product_info_arr: [restaurantUnique]
      }
    }
  };

  return additionalParameters[bankIca || MASTERPASS_PF_BANK_ICA.ipara] || {};
};

const isAmexCard = (cardNumber: string) => {
  const cleanedNumber = cardNumber.replace(/\D/g, "");
  return /^3[47][0-9]{13}$/.test(cleanedNumber);
};

export const getCVVLength = (cardNumber: string) => {
  const digits = cardNumber.replace(/\s/g, "");
  if (isAmexCard(digits)) return 5;
  return 4;
};

export const sanitizeCardInput = (type: "card" | "expiry" | "cvv", content: string, length = 4) => {
  if (type === "card") {
    if (content?.length >= 20) return undefined;
    const input = content.replace(/\D/g, "");
    const formatted = input.replace(/(\d{4})(?=\d)/g, "$1 ");
    return formatted;
  } else if (type === "expiry") {
    const input = content.replace(/\D/g, "");
    const formatted = input.slice(0, 4).replace(/(\d{2})(?=\d)/, "$1/");
    return formatted;
  } else if (type === "cvv") {
    if (content?.length >= length) return undefined;
    return content;
  }

  return;
};

export const shouldPaymentModuleEnableBlockMode = (countryFlag: boolean, restuarantFlag: boolean) => {
  return countryFlag || restuarantFlag;
};

export const getButton = () => {
  const { state } = usePGGroupStore.getState();

  const paymentMethodName = state.pgGroupInteractionData.currentSelected?.split("-")?.[1];

  let btnElement = Button;

  switch (paymentMethodName) {
    case PaymentElementEnum.ApplePay:
      btnElement = GooglePay;
      break;
    case PaymentElementEnum.GooglePay:
      btnElement = ApplePay;
      break;
    case PaymentElementEnum.CardPay:
      btnElement = Button;
      break;
  }

  return btnElement;
};

export const getExchangeInterruptionMessage = (config: IRestaurantConfig, lang: string | string[]) => {
  const defaultMessage = "Please retry payment, you will be charged in {{currencyCode}}";
  if (config.exchangeInterruptionMessage) {
    const locale = JSON.parse(config?.exchangeInterruptionMessage).find((item: any) => item.locale === lang);
    return locale?.value || defaultMessage;
  }
  return defaultMessage;
};

export const validateExpiryDate = (expiryDate: string) => {
  const expiryDatePattern = /^(0[1-9]|1[0-2])\/(\d{2})$/;
  if (!expiryDatePattern.test(expiryDate)) {
    return ErrorMessages[ErrorMessageKey.Expiry];
  }

  const [month, year] = expiryDate.split("/").map(Number);

  const expiryYear = 2000 + year;
  const expiryDateObj = endOfMonth(new Date(expiryYear, month - 1));

  const today = startOfToday();

  if (!isBefore(today, expiryDateObj)) {
    return "Expiry date is expired. Please check the details and retry";
  }
  return false;
};

export const validateExpiryDateWithLongYear = (expiryDate: string) => {
  const expiryDatePattern = /^(0[1-9]|1[0-2])\/(\d{2}|\d{4})$/;
  if (!expiryDatePattern.test(expiryDate)) {
    return ErrorMessages[ErrorMessageKey.Expiry];
  }

  const [month, year] = expiryDate.split("/").map(Number);

  const expiryYear = year < 100 ? 2000 + year : year;
  const expiryDateObj = endOfMonth(new Date(expiryYear, month - 1));

  const today = startOfToday();

  if (!isBefore(today, expiryDateObj)) {
    return "Expiry date is expired. Please check the details and retry";
  }
  return false;
};

export const handleForexRouting = (pg: PaymentGatewayConfig, paymentElement: PaymentElementEnum, exchange?: IForex) => {
  const countryCode = pg.vendor?.country?.code?.toLowerCase();
  const config = pg.config;
  const isRoutingEnabled = exchange?.isRoutingApplied;
  const shouldOveride = ROUTING_OVERIDING_COUNTRIES.includes(countryCode) && !exchange?.isApplied;

  if (!isRoutingEnabled) return null;

  if (shouldOveride) {
    if (config.forexPgReallocationSupportedPaymentMethods?.includes(paymentElement)) return true;
    if (config.forexRetryingPaymentMethods?.includes(paymentElement))
      return shouldExcludePayMethodHelper(pg, paymentElement);
  } else {
    if (config.forexPgReallocationSupportedPaymentMethods?.includes(paymentElement)) {
      const flag = shouldExcludePayMethodHelper(pg, paymentElement);
      return flag;
    }
    if (config.forexRetryingPaymentMethods?.includes(paymentElement)) {
      return true;
    }
  }

  return null;
};

export const handleGeneralForex = (pg: PaymentGatewayConfig, paymentElement: PaymentElementEnum, exchange?: IForex) => {
  const config = pg.config;

  const isForexInterrupted = exchange?.isInterrupted;

  if (isForexInterrupted) {
    if (config.forexPgReallocationSupportedPaymentMethods?.includes(paymentElement)) return true;
    if (config.forexRetryingPaymentMethods?.includes(paymentElement))
      return shouldExcludePayMethodHelper(pg, paymentElement);
  } else {
    if (config.forexRetryingPaymentMethods?.includes(paymentElement)) return true;
  }
  return null;
};

export const getPaymentProfile = () => {
  const paymentProfile = parseJSON(localStorage.getItem(storage.CUSTOMER_PAYMENT_PROFILE)) as PaymentProfile;
  return paymentProfile;
};

const updatePaymentProfile = (updates: Partial<PaymentProfile>) => {
  const paymentProfile = getPaymentProfile() || { customerId: getCustomerId() };
  const updatedProfile = { ...paymentProfile, ...updates };
  localStorage.setItem(storage.CUSTOMER_PAYMENT_PROFILE, JSON.stringify(updatedProfile));
};

const setLastPaymentDetails = (updates: Partial<PaymentProfile["lastPayment"]>) => {
  const paymentProfile = getPaymentProfile();
  updatePaymentProfile({
    lastPayment: {
      ...paymentProfile?.lastPayment,
      ...updates
    }
  });
};

const recordCardBrandUsed = (cardBrand: string) => {
  const paymentProfile = getPaymentProfile();
  const cards = paymentProfile.previousUsedCardBrands ?? [];

  cards.unshift(cardBrand);

  if (cards?.length > 10) cards.pop();

  const updatedProfile = {
    ...paymentProfile,
    previousUsedCardBrands: cards
  };

  updatePaymentProfile(updatedProfile);
};

const set3dsFlag = (flag: boolean) => {
  const paymentProfile = getPaymentProfile();
  const used3ds = paymentProfile.used3ds;

  if (!used3ds && flag) updatePaymentProfile({ used3ds: flag });
};

export const setPaymentProfile = (data: Partial<PaymentProfile>) => {
  if (data?.lastPayment) setLastPaymentDetails(data.lastPayment);

  data.previousUsedCardBrands?.length && recordCardBrandUsed(data.previousUsedCardBrands.at(0) as string);

  typeof data?.lastPayment?.used3ds !== "undefined" && set3dsFlag(data.lastPayment.used3ds);
};

export const isMultiPG = (availalbeMethods: string[]) => {
  if (availalbeMethods.length === 0) return false;

  const prefixes = availalbeMethods.map((item) => item.split("-")[0]);
  const uniquePrefixes = new Set(prefixes);

  return uniquePrefixes.size > 1;
};

const returnWithPGOrderValue = (methodOrder: number, pgOrder: number) => pgOrder * 10 + methodOrder;

export const getPaymentMethodOrder = (
  paymentMethod: PaymentElementEnum,
  pgConfig: PaymentGatewayConfig["config"],
  pgName: string
) => {
  const pgElementOrder = pgConfig.pgElemOrder;
  let pgOrder = pgConfig.extraConfig.pgOrder ?? 99;

  const forex = useForexStore.getState();
  const {
    state: { lastPaymentData }
  } = useCommonStore.getState();

  if (
    pgConfig.forexRetryingPaymentMethods?.includes(paymentMethod) &&
    forex.paymentMethod === paymentMethod &&
    forex.paymentMethodOrder
  ) {
    return forex.paymentMethodOrder;
  }

  if (lastPaymentData.name == pgName && paymentMethod == lastPaymentData.method) {
    return 1;
  }

  if (!pgElementOrder && typeof pgConfig.extraConfig.pgOrder == "undefined") return 9999;

  if (pgElementOrder?.includes(paymentMethod))
    return returnWithPGOrderValue(pgElementOrder.indexOf(paymentMethod) + 1, pgOrder);

  return returnWithPGOrderValue((pgElementOrder?.length ?? 0) + 1, pgOrder);
};
