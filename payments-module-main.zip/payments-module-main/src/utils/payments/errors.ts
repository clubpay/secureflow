const errorMapping: { [key: string]: string } = {
  /** moneyhash */
  "Card number is invalid.": "Card number is invalid",
  "Card number is required.": "Card number is required",
  "Expiry month is invalid.": "Expiry month is invalid",
  "Expiry month is required.": "Expiry month is required",
  "Expiry year is invalid.": "Expiry year is invalid",
  "Expiry year is required.": "Expiry year is required",
  "Expiration year is in the past.": "Expiry year is invalid",
  "CVV is invalid.": "CVV is invalid",
  "CVV is required.": "CVV is required",
  "Card holder name is invalid.": "Card holder name is invalid",
  "Card holder name is required.": "Card holder name is required"
};

export const mapErrors = (error: string) => {
  return errorMapping[error];
};
