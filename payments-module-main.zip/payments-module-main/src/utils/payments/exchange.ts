import Router from "next/router";
import storage from "@/constants/storage";
import { IForex, PaymentGatewayConfig } from "@/types";
import {
  PaymentElementEnum,
  PaymentExchangeDecision
} from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { PGNameEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { IRestaurantConfig } from "@clubpay/customer-common-module/src/repository/vendor";
import { getPaymentProfile } from ".";
import { VendorCache } from "../vendor";

export const getPaymentExchangeDecision = (exchange?: IForex, pgName?: PGNameEnum) => {
  const vendor = VendorCache.getInstance().get(Router.query as any);
  const enableNIRenderingAfterUsingPreviously = vendor?.country?.config?.enableNIRenderingAfterUsingPreviously;

  const paymentProfile = getPaymentProfile();
  const lastPayment = paymentProfile?.lastPayment;

  /** only applicable for ngenius */
  const isLastPaymentPaidWithLocalCurrency =
    ((lastPayment?.isForexInterrupted && !lastPayment?.isForexPayment) ||
      (!lastPayment?.isForexInterrupted && !lastPayment?.isForexPayment && lastPayment?.isInternationalCard)) &&
    enableNIRenderingAfterUsingPreviously &&
    pgName === PGNameEnum.NGenius;

  if (exchange?.isApplied) return PaymentExchangeDecision.UseForeignCurrency;
  if (sessionStorage.getItem(storage.LIMIT_FOREX) || isLastPaymentPaidWithLocalCurrency) {
    return PaymentExchangeDecision.UseLocalCurrency;
  }
  if (!exchange?.currencyCode) return PaymentExchangeDecision.ExchangeUndecided;
  return PaymentExchangeDecision.UseLocalCurrency;
};

export const getExchangeInterruptionMessage = (config?: IRestaurantConfig) => {
  const defaultMessage = "Please retry payment, you will be charged in {{currencyCode}}";
  if (config?.exchangeInterruptionMessage) {
    const lang = Router.query.lang || "en";
    const locale = JSON.parse(config?.exchangeInterruptionMessage).find((item: any) => item?.locale === lang);
    return locale?.value || defaultMessage;
  }
  return defaultMessage;
};

export const handleLimitForex = (pg: PaymentGatewayConfig, paymentMethod: PaymentElementEnum) => {
  /** if forex is skipped, alway show the ngenius payment methods
   * and hide all the payment methods other than ngenius which support reallocation
   */

  const { name, config } = pg;

  const limitForex = sessionStorage.getItem(storage.LIMIT_FOREX);
  const isNgenius = name === PGNameEnum.NGenius;
  const isReallocationSupported =
    config.forexPgReallocationSupportedPaymentMethods?.includes(paymentMethod) ||
    config.forexRetryingPaymentMethods?.includes(paymentMethod);

  if (limitForex) {
    if (isNgenius && isReallocationSupported) return false;
    if (isReallocationSupported) return true;
  }
  return null;
};

export const handleForexWithLastPayment = (pg: PaymentGatewayConfig, paymentMethod: PaymentElementEnum) => {
  /**
   * paym-1396
   * if user paid with local currency after interruption
   * render the ngenius payment methods which support reallocation in the next time neglecting other
   * reallocation supported payment methods
   */

  const { name, config } = pg;
  const paymentProfile = getPaymentProfile();
  const lastPayment = paymentProfile?.lastPayment;

  const isNgenius = name === PGNameEnum.NGenius;
  const isLastPaymentPaidWithLocalCurrency =
    (lastPayment?.isForexInterrupted && !lastPayment?.isForexPayment) ||
    (!lastPayment?.isForexInterrupted && !lastPayment?.isForexPayment && lastPayment?.isInternationalCard);

  const isReallocationSupported =
    config.forexPgReallocationSupportedPaymentMethods?.includes(paymentMethod) ||
    config.forexRetryingPaymentMethods?.includes(paymentMethod);

  const enableNIRenderingAfterUsingPreviously = pg.vendor?.country?.config?.enableNIRenderingAfterUsingPreviously;

  if (isLastPaymentPaidWithLocalCurrency && isReallocationSupported && enableNIRenderingAfterUsingPreviously) {
    if (isNgenius) return false;
    else return true;
  }
  return null;
};
