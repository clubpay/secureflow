import Router from "next/router";
import storage from "@/constants/storage";
import { VendorCache } from "../vendor";

export const clearEventFlags = () => {
  sessionStorage.removeItem(storage.NAPS_ALERT_TRIGGERED);
  sessionStorage.removeItem(storage.IS_FOREX_INTERRUPTED);
  sessionStorage.removeItem(storage.IS_FOREX_USED);
};

export const getPaymentGoogleEventArgs = (gatewayId: string) => {
  const vendor = VendorCache.getInstance().get(Router.query as any);
  const pgConfig = vendor?.paymentGateways?.find((pg) => pg.id == gatewayId)?.config;

  return {
    forex_ui: vendor?.config?.forexUI ?? "v2",
    is_forex_limited: Boolean(sessionStorage.getItem(storage.LIMIT_FOREX)),
    preselect_usd_fallback: Boolean(pgConfig?.preselectUSDFallback),
    naps_alert_triggered: Boolean(sessionStorage.getItem(storage.NAPS_ALERT_TRIGGERED)),
    isExchangeInterrupted: Boolean(sessionStorage.getItem(storage.IS_FOREX_INTERRUPTED)),
    isExchangeUsed: Boolean(sessionStorage.getItem(storage.IS_FOREX_USED))
  };
};
