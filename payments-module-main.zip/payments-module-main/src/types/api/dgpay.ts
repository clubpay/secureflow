import { IPayBasePayload } from "./common";

export interface IDGPayGet3DSSessionPayload extends IPayBasePayload {
  orderID: string;
  gatewayID: string;
}

export interface IDGPayGet3DSSessionResponse {
  threeDSessionID: string;
  billAmount: string;
  totalAmount: string;
}
