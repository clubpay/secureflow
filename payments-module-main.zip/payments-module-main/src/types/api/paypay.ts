import { IPayBasePayload } from "./common";

export interface IPaypayRegisterPayload extends IPayBasePayload {
  orderID: string;
}

export interface IPaypayRegisterResponse {
  accessID: string;
  accessPass: string;
  orderID: string;
  startLimitDate: string;
  startURL: string;
  token: string;
}
