import { IAppleContactDetails, IPayBasePayload, IPayByApplePayload } from "./common";

export interface IMyFatoorahPayByApplePayload extends IPayByApplePayload, IAppleContactDetails {
  sessionId: string;
  cardBrand: string;
  callBackUrl: string;
  errorUrl: string;
}

export interface IMyFatoorahPayByKNetApplePayload extends IPayBasePayload {
  callBackUrl: string;
  errorUrl: string;
  currencyIso: string;
}

export interface IMyFatoorahInitiateSessionPayload {
  diningSessionID?: string;
  gatewayID: string;
}

export interface IMyFatoorahPayByAppleResponse {
  invoiceId: string;
  isDirectPayment: boolean;
  paymentUrl: string;
  userDefinedField: string;
  recurringId: string;
}

export interface IMyFatoorahPayByKNetAppleResponse {
  redirectUrl: string;
}

export interface IMyFatoorahInitiateSessionResponse {
  sessionID: string;
  countryCode: string;
}

export interface IMyFatoorahPayByCardPayload extends IPayBasePayload {
  sessionId?: string;
  cardBrand: string;
  callBackUrl?: string;
  errorUrl?: string;
}

export interface IMyFatoorahPayByKetPayload extends IPayBasePayload {
  callBackUrl?: string;
  errorUrl?: string;
  currencyIso: string;
}

export interface IMyFatoorahPayByCardResponse {
  needVerification: boolean;
  redirectUrl: string;
}

export interface IMyFatoorahPayByKNetResponse {
  redirectUrl: string;
}
