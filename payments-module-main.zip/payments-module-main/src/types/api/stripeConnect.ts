import { IPayBasePayload } from "./common";
import {
  IStripeCreatePaymentIntentPayload,
  IStripePayPayload,
  IStripePaymentIntentResponse,
  IStripeVerifyPayload,
  IStripeVerifyResponse
} from "./stripe";

export interface IStripeConnectCreatePaymentIntentPayload extends IStripeCreatePaymentIntentPayload {}

export interface IStripeConnectPaymentIntentResponse extends IStripePaymentIntentResponse {}

export interface IStripeConnectPayPayload extends IStripePayPayload {}

export interface IStripeConnectPayResponse extends IPayBasePayload {
  intentID: string;
}

export interface IStripeConnectVerifyPayload extends IStripeVerifyPayload {
  paymentMethod?: string;
}

export interface IStripeConnectVerifyResponse extends IStripeVerifyResponse {}
