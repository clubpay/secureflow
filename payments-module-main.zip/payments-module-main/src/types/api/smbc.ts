import { IPayBasePayload } from "./common";

export interface ISMBCLinkRequestPayload extends IPayBasePayload {}

export interface ISMBCLinkRequestResponse {
  link: string;
}
