import { IPayBasePayload } from "./common";

export interface ITicketPGGenerateLinkPayload extends IPayBasePayload {}

export interface ITicketPGGenerateLinkResponse {
  paymentUrl: string;
  paymentURL?: string;
}
