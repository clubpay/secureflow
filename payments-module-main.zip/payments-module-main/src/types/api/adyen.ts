import { IAdyenPaymentMethod } from "../payments/config/adyen";
import {
  IAppleContactDetails,
  IExchangeData,
  IPayBasePayload,
  IPayByApplePayload,
  IPayByGooglePayload,
  IPaymentDetails
} from "./common";

export interface IAdyenPayByCardPayload extends IPayBasePayload {
  paymentMethod: IAdyenPaymentMethod;
  returnUrl: string;
}

export interface IAdyenPayByCardResponse {
  [key: string]: any;
}

export interface IAdyenPayByApplePayload extends IPayByApplePayload, IAppleContactDetails {
  paymentMethod: {
    type: string;
    applePayToken: string;
  };
}

export interface IAdyenDetails extends IPaymentDetails {
  exchangeData: IExchangeData;
}

export interface IAdyenPayByGooglePayload extends IPayByGooglePayload {}
