import { IPayBasePayload } from "./common";

export interface IDivitPayByFpsPayload extends IPayBasePayload {}

export interface IDivitPayByFpsResponse {
  redirectUrl: string;
}
