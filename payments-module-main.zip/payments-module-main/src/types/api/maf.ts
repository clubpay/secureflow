import {
  IAppleContactDetails,
  IPayBasePayload,
  IPayByApplePayload,
  IPayByGooglePayload,
  IPaymentDetails
} from "./common";

export interface IMafV2PaymentPayload extends IPayBasePayload {
  cardToken: string;
  customerEmail: string;
  cardBin: string;
  cardBrand: string;
}

export interface IMafV2PaymentResponse {
  responseMessage: string;
  responseCode: string;
  threeDsAuthId: string;
  orderReference: string;
  transactionReference: string;
  currencyCode: string;
  billAmount: string;
  tipAmount: string;
  amount: string;
}

export interface IGenerateTokenMafV2Payload extends IPayBasePayload {
  cardToken?: string;
  customerEmail?: string;
}

export interface IVerifyMafV2Payload {
  diningSessionID: string;
  gatewayID: string;
  reference: string;
  id: string;
  shippingContact?: ShippingContact;
}

export interface ShippingContact {
  emailAddress: string;
  familyName: string;
  givenName: string;
  phoneNumber: string;
  countryCode: string;
  country: string;
  addressLines: string[];
}

export interface IVerifyMafV2Response {
  success: boolean;
}

export interface IMafV2PayByApplePayload extends IPayByApplePayload, IAppleContactDetails {}

export interface IMafV2ApplePayDetails extends IPaymentDetails {
  responseCode: string;
}

export interface IMafV2PayByGooglePayload extends IPayByGooglePayload {}

export interface IMafV2PayByGooglePayResponse {
  result: boolean;
  responseCode: string;
}
