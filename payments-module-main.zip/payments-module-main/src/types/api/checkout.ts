import { IExchangeData } from "@clubpay/customer-common-module/src/repository/vendor";
import {
  IAppleContactDetails,
  IPayBasePayload,
  IPayByApplePayload,
  IPayByGooglePayload,
  IPaymentDetails,
  IVerifyPaymentPayload,
  PaymentExchangeDecision
} from "./common";

export interface ICheckoutDetails extends IPaymentDetails {
  exchangeData: IExchangeData;
  ICheckoutDetails?: any;
}

export interface ICheckoutPayByApplePayload extends IPayByApplePayload, IAppleContactDetails {
  isSplitPayment: boolean;
  exchangeDecision: PaymentExchangeDecision;
}

export interface ICheckoutPayByGooglePayload extends IPayByGooglePayload {}

export interface ICheckoutVerifyPaymentPayload extends IVerifyPaymentPayload {
  sessionID: string;
}

export interface ICheckoutVerifyResponse {
  redirectUrl: string;
  success: boolean;
}

export interface ICheckoutPayByCardPayload extends IPayBasePayload {
  cvv: string;
  expiryMonth: number;
  expiryYear: number;
  name: string;
  number: string;
}

export interface ICheckoutPayByTokenPayload extends IPayBasePayload {
  cardToken?: string;
  cardType?: string;
  saveCard: boolean;
  issuerCountry?: string;
  scheme?: string;
  isSplitPayment: boolean;
  exchangeDecision: PaymentExchangeDecision;
  productType?: string;
}

export interface ICheckoutPayByTokenResponse {
  cardApproved: boolean;
  needVerification: boolean;
  paidAmount: string;
  redirectUrl: string;
  exchangeData?: IExchangeData;
  routingApplied?: boolean;
}

export interface ICheckoutPayWithSavedCardPayload extends IPayBasePayload {
  isMada: boolean;
  sourceId: string;
  isSplitPayment: boolean;
  exchangeDecision: PaymentExchangeDecision;
}

export interface ICheckoutPayWithSavedCardResponse extends ICheckoutPayByTokenResponse {}

export interface ICheckoutSavedCardDetailsResponse {
  bin: string;
  isMada: boolean;
  last4: string;
  scheme: string;
  sourceId: string;
}

export interface ICheckoutUnsaveCardResponse {
  result: boolean;
}

export interface ICheckoutPayBySTCPayPayload {
  id: string;
  tipAmount: string;
  diningSessionID: string;
  reference: string;
  gatewayID: string;
  success_url: string;
  failure_url: string;
  customer: {
    email: string;
    name: string;
    phone: {
      number: string;
      countryCode: string;
    };
  };
}

export interface ICheckoutPayBySTCPayCapturePayload {
  id: string;
  tipAmount: string;
  diningSessionID: string;
  reference: string;
  gatewayID: string;
  paymentId: string;
  processing: {
    otp_value: string;
  };
}

export interface ICheckoutPayBySTCPayResponse {
  id: string;
  status: string;
  reference: string;
  isPending: boolean;
  customer: {
    id: string;
    email: string;
    name: string;
    phone: {
      countryCode: string;
      number: string;
    };
  };
}

export interface ICheckoutPayBySTCPayCapturePayload {
  id: string;
  tipAmount: string;
  diningSessionID: string;
  reference: string;
  gatewayID: string;
  processing: {
    otp_value: string;
  };
  annotations?: {
    paymentMethod: string;
    funnel: string;
  };
}

export interface ICheckoutPayByKNETPayload {
  id: string;
  tipAmount: string;
  diningSessionID: string;
  reference: string;
  gatewayID: string;
  success_url: string;
  failure_url: string;
}

export interface ICheckoutPayByKNETResponse {
  id: string;
  status: string;
  reference: string;
  isPending: boolean;
  _links: {
    redirect: {
      href: string;
    };
  };
}
