import {
  IAppleContactDetails,
  IExchangeData,
  IPayBasePayload,
  IPayByApplePayload,
  IPayByGooglePayload,
  IPaymentDetails,
  PaymentExchangeDecision
} from "./common";

export interface ICCPPPayByCardPayload extends IPayBasePayload {
  securePayToken: string;
  cardNumber: string;
  responseUrl: string;
  locale: string;
}

export interface ICCPPPayByCardResponse {
  needVerification: boolean;
  redirectUrl: string;
}

export interface ICCPPPayByApplePayload extends IPayByApplePayload, IAppleContactDetails {
  isSplitPayment: boolean;
  exchangeDecision: PaymentExchangeDecision;
}

export interface ICCPPDetails extends IPaymentDetails {
  exchangeData: IExchangeData;
}

export interface ICCPPPayByGooglePayload extends IPayByGooglePayload {}
