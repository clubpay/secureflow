import { IAppleContactDetails, IPayBasePayload, IPayByApplePayload, IPaymentDetails } from "./common";

export interface ITappPaymentPayload extends IPayBasePayload {
  cardToken: string;
  billingCountry: string;
  cardBrand: string;
  cardScheme: string;
}

export interface ITappPaymentResponse {
  needVerification: boolean;
  redirectUrl: string;
}

export interface ITappPayByApplePayload extends IPayByApplePayload, IAppleContactDetails {}

export interface ITappApplePayDetails extends IPaymentDetails {}
