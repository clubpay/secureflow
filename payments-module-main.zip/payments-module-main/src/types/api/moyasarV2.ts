import { IAppleContactDetails, IPayByApplePayload, IPaymentDetails } from "./common";

export interface IMoyasarV2PayByApplePayload extends IPayByApplePayload, IAppleContactDetails {}

export interface IMoyasarV2ValidateApplePayload {
  validation_url: string;
  display_name: string;
  domain_name: string;
  publishable_api_key?: string;
}

export interface IMoyasarV2Details extends IPaymentDetails {}

export interface IMoyasarV2InitateRequestPayload {
  GatewayID: number;
  Reference: string;
  TipAmount: string;
  DiningSessionID: any;
  ID: string;
  PaymentMethod: string;
  Source: string;
}
