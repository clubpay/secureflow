import { IPayBasePayload, IVerifyPaymentPayload } from "./common";

export interface IPayTMInitiateTransactionPayload extends IPayBasePayload {
  orderID: string;
}

export interface IPayTMLegacyInitiateTransactionPayload extends IPayTMInitiateTransactionPayload {
  callbackUrl: string;
}

export interface IPayTMInitiateTransactionResponse {
  orderID: string;
  token: string;
}

export interface IPayTMVerifyTransactionPayload extends IVerifyPaymentPayload {
  id: string;
  orderID: string;
  txnType: string;
}

export interface IPayTMVerifyTransactionResponse {
  redirectUrl: string;
  success: boolean;
}
