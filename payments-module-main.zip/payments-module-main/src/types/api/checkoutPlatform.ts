import { ICheckoutPayByTokenResponse } from "./checkout";
import { IPayBasePayload, IPayByApplePayload, IPayByGooglePayload, IPaymentDetails } from "./common";

export interface ICheckoutPlatformDetails extends IPaymentDetails {}

export interface ICheckoutPlatformPayByApplePayload extends IPayByApplePayload {}

export interface ICheckoutPlatformPayByGooglePayload extends IPayByGooglePayload {}

export interface ICheckoutPlatformPayByTokenPayload extends IPayBasePayload {
  cardToken: string;
  gatewayID: string;
  cardType: string;
}

export interface ICheckoutPlatformPayByTokenResponse extends ICheckoutPayByTokenResponse {}
