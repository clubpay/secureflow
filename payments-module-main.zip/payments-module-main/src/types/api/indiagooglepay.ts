import { IPayBasePayload } from "./common";

export interface IGooglePayIndiaPayload extends IPayBasePayload {
  billAmount: string;
  paymentResponse: string;
}

export interface IGooglePayIndiaResponse {
  result: boolean;
}
