import { IPayBasePayload, IPayByApplePayload, IPayByGooglePayload, IPaymentDetails } from "./common";

export interface IVostroPayByDebitPayload extends IPayBasePayload {
  amount: string;
  currency: string;
  transactionToken: string;
}

export interface IVostroPayByDebitResponse {
  errors: IVostroError[];
  paymentMethod: string;
  purchaseId: string;
  redirectUrl: string;
  returnType: string;
  success: boolean;
  uuid: string;
}

export interface IVostroError {
  code: string | number;
  description: string;
  extra: Record<string, string>;
  items: string;
}

export interface IVostroPayByApplePayload extends IPayByApplePayload {}

export interface IVostroPayByGooglePayload extends IPayByGooglePayload {}

export interface IVostroDetails extends IPaymentDetails {}
