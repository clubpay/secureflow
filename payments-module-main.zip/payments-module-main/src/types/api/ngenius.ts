import { IPayBasePayload } from "./common";

export interface INgeniusPayByUnionPayPayload extends IPayBasePayload {
  redirectUrl: string;
}

export interface INgeniusPayByUnionPayResponse {
  redirectUrl: string;
}
