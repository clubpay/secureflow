import { IAppleContactDetails, IPayBasePayload, IPayByApplePayload } from "./common";

export interface IGenerateSessionMashreqPayload {
  diningSessionID: string;
  gatewayID: string;
}

export interface IGenerateSessionMashreqResponse {
  sessionId: string;
}

export interface IPayMashreqPayload extends IPayBasePayload {
  billingCountry: string;
  cardBrand: string;
  mashreqSessionId: string;
}

export interface IMashreqPayResponse {
  needVerification: boolean;
  redirectUrl: string;
  redirectHtml: string;
}

export interface IMashreqPayByApplePayload extends IPayByApplePayload, IAppleContactDetails {
  mashreqSessionId: string;
}

export interface IMashreqDetails {
  needVerification: boolean;
  redirectUrl: string;
}

export interface IMashreqAuthorizePayload {
  mashreqSessionId: string;
}

export interface IMashreqAuthorizeResponse {
  status: "pending" | "success" | "fail";
}
