import { IPayBasePayload, IPayByGooglePayload, IVerifyPaymentPayload } from "./common";

export interface ITunaPaySessionPayload {
  gatewayID: string;
  diningSessionID: string;
  reference: string;
  id: string;
}

export interface ITunaPaySessionResponse {
  sessionToken: string;
  code: number;
  customerID: string;
  customerEmail: string;
}

export interface ITunaPaymentItem {
  amount: string;
  detailUniqueId: string;
  productDescription: string;
  qty: string;
}

export interface ITunaPaymentMethod {
  amount: string;
  billingInfoDocument: string;
  billingInfoDocumentType: string;
  cardBrandName: string;
  cardExpirationMonth: number;
  cardExpirationYear: number;
  cardHolderName: string;
  cardToken: string;
  cardTokenSingleUse: number;
  installments: number;
  paymentMethodType: string;
  saveCard: boolean;
  tokenProvider: string;
}

export interface ITunaCardPaymentPayload extends IPayBasePayload {
  cardToken: string;
  cardHolderName: string;
  cardBrand: string;
  cardExpireMonth: number;
  cardExpiryYear: number;
  method: string;
  sessionToken: string;
  tokenSingleUse: boolean;
  cardBin: string;
  document: string;
  documentType: string;
}

export interface ITunaPixPaymentPayload extends IPayBasePayload {
  method: string;
  sessionToken: string;
}

export interface ITunaPixPaymentResponse {
  billAmount: string;
  expiration: number;
  methodID: number;
  methodKey: string;
  methodType: string;
  operationId: string;
  paymentKey: string;
  qrContent: string;
  qrImage: string;
  status: string;
  success: boolean;
  tipAmount: string;
  totalAmount: string;
}

export interface ITunaVerifyPixPayload extends IVerifyPaymentPayload {}

export interface ITunaVerifyPixResponse {
  billAmount: string;
  success: boolean;
  tipAmount: string;
  totalAmount: string;
}

export interface ITunaPayByGooglePayload extends IPayByGooglePayload {
  sessionToken: string;
  method: string;
}

export interface ITunaPayByGoogleResponse extends ITunaVerifyPixResponse {}

export interface ITunaValidatePayload {
  applePayUrl: string;
  diningSessionID: string;
  gatewayID: string;
}

export interface ITunaPayByApplePayPayload {
  id: string;
  diningSessionID: string;
  tipAmount: string;
  appleToken: string;
  shippingContact?: any;
  billingContact?: any;
  reference: string;
  gatewayID: string;
  cardType: string;
  hostname: string;
  method: string;
  sessionToken: string;
}
