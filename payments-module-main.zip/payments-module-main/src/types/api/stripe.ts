import { IPayBasePayload, IVerifyPaymentPayload } from "./common";

export interface IStripeCreatePaymentIntentPayload {
  gatewayID: string;
  id: string;
  diningSessionID: string;
  reference: string;
  automaticPaymentMethodParams?: boolean;
  enable3ds?: boolean;
  issuerCountry?: string;
  tipAmount?: string;
  paymentMethod?: string;
}

export interface IStripePaymentIntentResponse {
  clientSecret: string;
  intentID: string;
}

export interface IStripePayPayload extends IPayBasePayload {
  intentID: string;
  paymentMethod?: string;
  shippingContact?: {
    payerName?: string;
    payerEmail?: string;
    payerPhone?: string;
  };
}

export interface IStripePayResponse extends IPayBasePayload {
  intentID: string;
}

export interface IStripeVerifyPayload extends IVerifyPaymentPayload {
  id: string;
  intentID: string;
  billAmount: string;
  tipAmount: string;
  paymentMethod?: string;
}

export interface IStripeVerifyResponse {
  redirectURL: string;
  success: boolean;
}
