import { IExchangeData, IPayBasePayload } from "./common";

export interface IMoneyhashCardPayPayload extends IPayBasePayload {}

export interface IMoneyhashCardPayResponse {
  intentId: string;
  exchangeData?: IExchangeData;
  routingApplied?: boolean;
}
