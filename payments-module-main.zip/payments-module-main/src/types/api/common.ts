import ApplePayPaymentContact = ApplePayJS.ApplePayPaymentContact;

export interface ICardStorage {
  getSavedCardDetails: Function;
  unsaveCard: Function;
}

export interface IPaymentDetails {
  cardApproved: boolean;
  needVerification: boolean;
  redirectUrl: string;
  paidAmount: string;
}
export interface IPayBasePayload {
  id?: string;
  diningSessionID?: string;
  gatewayID?: string;
  reference?: string;
  successUrl?: string;
  failureUrl?: string;
  pendingUrl?: string;
  tipAmount: string;
  cardBrand?: string;
  cardType?: string | null;
  issuerCountry?: string | null;
  productType?: string | null;
  last4?: string;
  bin?: string;
  exchangeDecision?: PaymentExchangeDecision;
  isSplitPayment?: boolean;
  subscribe?: boolean;
  annotations?: {
    paymentMethod: string;
    funnel: string;
  };
  additionalData?: {
    cpf?: string;
    cnpj?: string;
  };
}

export interface IAppleContactDetails {
  shippingContact?: ApplePayPaymentContact;
  billingContact?: ApplePayPaymentContact;
}

export interface IPayByApplePayload extends IPayBasePayload {
  appleToken?: string;
  gatewayID: string;
  cardType?: string;
  hostname?: string;
}

export interface IPayByGooglePayload extends IPayBasePayload {
  googleToken: string;
  gatewayID: string;
  cardType?: string;
  customerEmail?: string;
}

export interface IValidateApplePaySessionPayload {
  applePayUrl: string;
  diningSessionID: string;
  gatewayID: string;
  hostname?: string;
}

export interface IValidateApplePaySessionResponse {
  jsonData: string;
}

export interface IVerifyPaymentPayload {
  diningSessionID: string;
  reference: string;
  success?: boolean;
  gatewayID: string;
  id?: string;
}

export interface IExchangeData {
  amount?: string;
  amountCalculated: string;
  oldCurrencyCode?: string;
  newCurrencyCode: string;
  exchangeRate?: string;
  unsupportedCurrency?: string;
}

export enum PaymentExchangeDecision {
  ExchangeUndecided = "exchangeUndecided",
  UseForeignCurrency = "useForeignCurrency",
  UseLocalCurrency = "useLocalCurrency"
}
