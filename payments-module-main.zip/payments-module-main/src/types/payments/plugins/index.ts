export interface ISnackBar {
  enqueue: (message: string, options?: any) => void;
  close: (key?: any) => void;
}
