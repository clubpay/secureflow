import { PGNameEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { AdyenConfig } from "./adyen";
import { CCPPConfig } from "./ccpp";
import { CheckoutConfig } from "./checkout";
import { DivitConfig } from "./divit";
import { MAFConfig } from "./maf";
import { MoneyhashConfig } from "./moneyhash";
import { MoyasarV2 } from "./moysar";
import { StripeConfig } from "./stripe";
import { StripeConnectConfig } from "./stripeConnect";

export * from "./common";

export interface PaymentGatewayConfig {
  vendor?: any;
  id: string;
  amount: any;
  name: PGNameEnum;
  config:
    | CheckoutConfig
    | MAFConfig
    | MoyasarV2
    | CCPPConfig
    | AdyenConfig
    | StripeConfig
    | StripeConnectConfig
    | MoneyhashConfig
    | DivitConfig;
  hasSplitPayment?: boolean;
}
