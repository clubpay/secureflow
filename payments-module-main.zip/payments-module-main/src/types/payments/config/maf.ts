import { ApplePayConfig, GooglePayConfig, SharedConfig } from "./common";

export interface MAFConfig extends SharedConfig, GooglePayConfig, ApplePayConfig {
  "apiKey": string;
  "no3ds": boolean;
  "3dsThreshold": number;
  "gateway": string;
  "gatewayMerchantId": string;
  "merchantID": string;
  "merchantIdentifier": string;
  "showDescriptor": boolean;
}
