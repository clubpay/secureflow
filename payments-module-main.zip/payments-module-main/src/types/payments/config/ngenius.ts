import { CSSProperties } from "react";

export enum NGeniusPaymentStatus {
  AUTHORISED = "AUTHORISED",
  CAPTURED = "CAPTURED",
  ERROR = "ERROR",
  FAILED = "FAILED",
  PURCHASED = "PURCHASED",
  THREE_DS_FAILURE = "3DS_FAILURE",
  THREE_DS_SUCCESS = "3DS_SUCCESS",
  UNDECIDED = "UNDECIDED"
}

export type NGeniusValidateEvent = {
  isCVVValid: boolean;
  isExpiryValid: boolean;
  isNameValid: boolean;
  isPanValid: boolean;
};

export type NGeniusOptions = {
  style?: {
    main?: CSSProperties;
    base?: CSSProperties & { fontUrl?: string };
    input?: CSSProperties & { fontUrl?: string };
    invalid?: CSSProperties & { fontUrl?: string };
  };
  apiKey: string;
  hostedSessionApiKey?: string;
  outletRef: string;
  onSuccess?: () => void;
  onFail?: () => void;
  onChangeValidStatus?: (e: NGeniusValidateEvent) => void;
};

export type NI = {
  generateSessionId: () => Promise<{ session_id: string }>;
  mountCardInput: (mountPoint: string, options: NGeniusOptions) => void;
  handlePaymentResponse: (
    paymentResponse: any,
    options: {
      mountId: string;
      style?: CSSProperties;
    }
  ) => Promise<{ status: NGeniusPaymentStatus; error: string }>;
};
