import { ApplePayConfig, GooglePayConfig, SharedConfig } from "./common";

export interface MyFatoorahConfig extends SharedConfig, GooglePayConfig, ApplePayConfig {}

export type MyFatoorahResponse = {
  sessionId: string;
  cardBrand: string;
  cardIdentifier: string;
};
