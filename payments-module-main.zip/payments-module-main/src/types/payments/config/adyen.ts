import { ApplePayConfig, GooglePayConfig, SharedConfig } from "./common";

export interface AdyenConfig extends SharedConfig, GooglePayConfig, ApplePayConfig {
  clientKey: string;
}

export interface IAdyenBrowserInfo {
  acceptHeader: string;
  colorDepth: number;
  language: string;
  javaEnabled: boolean;
  screenHeight: number;
  screenWidth: number;
  userAgent: string;
  timeZoneOffset: number;
}

export interface IAdyenRiskData {
  clientData: string;
}

export interface IAdyenPaymentData {
  riskData: IAdyenRiskData;
  paymentMethod: IAdyenPaymentMethod;
  browserInfo: IAdyenBrowserInfo;
  origin: string;
  clientStateDataIndicator: boolean;
}

export interface IAdyenPaymentRequest {
  data: IAdyenPaymentData;
  isValid: boolean;
}

export interface IAdyenPaymentMethod {
  type: string;
  holderName: string;
  encryptedCardNumber: string;
  encryptedExpiryMonth: string;
  encryptedExpiryYear: string;
  encryptedSecurityCode: string;
  checkoutAttemptId: string;
}
