import PaymentAPIManager from "@/api/gateways";
import { IHandleSentryClose, ITransactionObject } from "@clubpay/customer-common-module/src/hook/useSentryTrace";
import { IPGRegister, PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { ConsumerType, IForex } from "..";

export type GoogleCardNetworks =
  | "AMEX"
  | "DISCOVER"
  | "ELECTRON"
  | "ELO"
  | "ELO_DEBIT"
  | "INTERAC"
  | "JCB"
  | "MAESTRO"
  | "MASTERCARD"
  | "VISA";

export type CardNetwork = "visa" | "mastercard" | "amex" | "vr" | "sodexo" | "discover" | "mada";

export type AppleCardNetworks = "visa" | "mastercard" | "amex" | "vr" | "sodexo" | "discover" | "mada";

export type GoogleAuthMethod = "PAN_ONLY" | "CRYPTOGRAM_3DS";

export type MerchantCapabilities = "supports3DS" | "supportsEMV" | "supportsCredit" | "supportsDebit";

export type RefundType = "full" | "partial" | "disabled";

export enum PaymentGateways {
  Checkout = "checkout",
  MAF = "maf",
  Stripe = "stripe"
}

interface PaymentFallback {
  priority?: number;
  timeout?: number;
  indicatorTimeout?: number;
  onIndicator?: Function;
  onFallback?: Function;
}

export interface IGatewayPaymentHandler {
  paymentElement: PaymentElementEnum;
  refId: string;
  traceId?: string;
  meta?: {
    gaEventSuffix?: string;
    [key: string]: any;
  };
}

export interface EventsTypes {
  onReady?: () => void;
  onBeforePayment?: (payload?: any) => void;
  onAfterPayment?: () => void;
  onUnlockPayment?: (gatewayId: string) => Promise<boolean>;
  onPaymentSuccess?: (payload: IGatewayPaymentHandler) => void;
  onPaymentPending?: (gatewayId: string, payload?: IGatewayPaymentHandler) => void;
  onPaymentFailure?: (payload: IGatewayPaymentHandler) => void;
  onPaymentCancel?: (payload: IGatewayPaymentHandler) => void;
  onTraceStart?: (gatewayId: string) => ITransactionObject;
  onTraceClose?: (payload: IHandleSentryClose) => void;
  onOverlayClick?: () => void;
  onPgRegister?: (payload: IPGRegister) => void;
  onPgUnregister?: (payload: IPGRegister) => void;
  isPgElemVisible?: (gatewayId: string) => boolean;
  onPrePayment?: (paymentFn: (payload: any) => void, type: PaymentElementEnum) => void;
}

export interface SharedConfig {
  sandbox: boolean;
  countryCode?: string;
  publicKey?: string;
  appleSDKVersion?: number;
  refundType?: RefundType;
  elements?: PaymentElementEnum[];
  fallback?: PaymentFallback;
  enableCardPayment?: boolean;
  events?: any;
  apiManager?: PaymentAPIManager;
  extraConfig?: any;
  forexPgReallocationSupportedPaymentMethods?: PaymentElementEnum[];
  forexRetryingPaymentMethods?: PaymentElementEnum[];
  splitPaymentEnable: boolean;
  priority?: number;
  pgDefaultSelectedElem: string[];
  limitForex: boolean;
  preselectUSDFallback: boolean;
  customerProfile: boolean;
  hideCardPay?: boolean;
  pgElemOrder: PaymentElementEnum[];
  pgOrder?: number;
  disableAmexCard?: boolean;
}

export interface GooglePayConfig {
  googleMerchantId: string;
  googleAllowedCardNetworks: GoogleCardNetworks[];
  googleAllowedAuthMethods?: GoogleAuthMethod[];
  merchantCapabilities?: MerchantCapabilities[];
  googlePayCustomerEmail?: boolean;
}

export interface ApplePayConfig {
  supportedNetworks?: AppleCardNetworks[];
  supportedNetworksList?: AppleCardNetworks[];
  preferredNetworks?: AppleCardNetworks[];
  appleSDKVersion?: number;
  applePayBillingDetails: boolean;
  applePayShippingDetails: boolean;
  applepayRetryingTimeout: number;
  preferredMerchantCapabilitiesList: MerchantCapabilities[];
  merchantCapabilitiesList: MerchantCapabilities[];
}

export interface PaymentKitPayloadType {
  amount: number;
  vendor: any;
  hasSplitPayment: boolean;
  enableCardPayment: boolean;
  events?: any;
  diningSessionID: string;
  currencyPrecision: number;
  tip: number;
  lang: string;
  remainingAmount: number;
  consumer: ConsumerType;
  exchange?: IForex;
  extraConfig?: any;
  totalAmount?: number;
  billPaidStatus?: string;
  isSubscriptionPayment?: boolean;
}
