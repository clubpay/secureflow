import { ApplePayConfig, GooglePayConfig, SharedConfig } from ".";

export interface StripeConfig extends SharedConfig, GooglePayConfig, ApplePayConfig {
  stripeElementOrder: string[];
  paynow: boolean;
  grabPay: boolean;
  alipay: boolean;
  kr_card: boolean;
  kakao_pay: boolean;
  naver_pay: boolean;
  payco: boolean;
  samsung_pay: boolean;
}
