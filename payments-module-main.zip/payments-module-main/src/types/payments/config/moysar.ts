import { ApplePayConfig, GooglePayConfig, SharedConfig } from "./common";

export interface MoyasarV2 extends SharedConfig, GooglePayConfig, ApplePayConfig {
  domain: string;
  publishableKey: string;
}
