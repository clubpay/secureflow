import { ApplePayConfig, GooglePayConfig, SharedConfig } from ".";

export interface StripeConnectConfig extends SharedConfig, GooglePayConfig, ApplePayConfig {
  paynowUI: "v0" | "v1" | "v2" | "v3" | "v4";
  stripeElementOrder: string[];
  paynow: boolean;
  grabPay: boolean;
  alipay: boolean;
  kr_card: boolean;
  kakao_pay: boolean;
  naver_pay: boolean;
  payco: boolean;
  samsung_pay: boolean;
}
