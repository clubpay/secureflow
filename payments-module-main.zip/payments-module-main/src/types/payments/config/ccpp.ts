import { ApplePayConfig, GooglePayConfig, SharedConfig } from "./common";

export interface CCPPConfig extends SharedConfig, GooglePayConfig, ApplePayConfig {
  gatewayMerchantId: string;
}

export type CCPPCardResponse = {
  encryptedCardInfo: string;
  expMonthCardInfo: string;
  expYearCardInfo: string;
  maskedCardInfo: string;
};
