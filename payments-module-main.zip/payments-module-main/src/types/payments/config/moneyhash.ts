import { ApplePayConfig, GooglePayConfig, SharedConfig } from ".";

export interface MoneyhashConfig extends SharedConfig, GooglePayConfig, ApplePayConfig {
  publicApiKey: string;
  flowId: string;
}
