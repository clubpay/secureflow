import { ApplePayConfig, GooglePayConfig, SharedConfig } from "./common";

export interface CheckoutConfig extends SharedConfig, GooglePayConfig, ApplePayConfig {
  countryCode?: string;
  publicKey: string;
}
