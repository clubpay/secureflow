import { ApplePayConfig, SharedConfig } from "./common";

export interface DivitConfig extends SharedConfig, ApplePayConfig {}
