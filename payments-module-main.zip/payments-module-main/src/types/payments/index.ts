import { PaymentTermsProps } from "@/components/Global/PaymentTerms";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { IRestaurant } from "@clubpay/customer-common-module/src/repository/vendor";
import { KeyValue } from "..";
import { PaymentGatewayConfig } from "./config";
import { ISnackBar } from "./plugins";

export * from "./config";

export interface DesignVariants {
  variant?: "primary" | "secondary" | string;
}

interface RedirectURLFNParams {
  ref: string;
  traceId?: string;
}

export type RedirectURLFN = (params: RedirectURLFNParams) => string;

export interface QlubMetaData {
  auth?: {
    user?: KeyValue;
  };
  redirections?: {
    success?: string | RedirectURLFN;
    failure?: string | RedirectURLFN;
    cancel?: string | RedirectURLFN;
  };
  sessionId?: string;
  diningSessionId?: string;
  restaurant?: IRestaurant;
  tip?: number;
  isSplitPayment: boolean;
  exchange?: IForex;
  name?: string;
  currencyPrecision?: number;
  lang?: string | null;
  remainingAmount?: number;
}

export interface PaymentOptions extends DesignVariants {
  locale: "en" | "ar" | "ja" | "pt" | "tr" | "zh" | "es" | "hk" | "ko" | "ru" | string;
  tagline?: boolean;
  networks?: boolean;
  enableCardSaving?: boolean;
  paymentTerms?: PaymentTermsProps;
  amount?: number;
  totalAmount?: number;
  currency?: "aed" | "sar" | string;
  country?: "ae" | "sa" | string;
  pg: PaymentGatewayConfig;
  elementSequence?: PaymentElementEnum[];
  plugins?: {
    snackbar?: ISnackBar;
  };
  qlub: QlubMetaData;
  hasPgGroup?: boolean;
  consumer: ConsumerType;
  onPaymentMethodSelect: any;
  billPaidStatus?: string;
  countryCode?: string;
  vendor?: any;
  isSubscriptionPayment?: boolean;
  slots?: any;
}

export const ConsumerTypes = {
  CUSTOMER_APP: "CUSTOMER_APP",
  PAYMENT_LINK: "PAYMENT_LINK"
} as const;

export type ConsumerType = keyof typeof ConsumerTypes;

export type IMethods = "creditcard" | "applepay" | "stcpay";

export type PaymentMetaTypes = {
  paymentMethod?: string;
  paymentGateway?: string;
  pgId?: string;
  cardBrand?: string;
  isForexDataAvailable?: string;
  isForexInterrupted?: boolean;
  isForexPayment?: boolean;
  isSavedCard?: boolean;
  isInternationalCard?: boolean;
  cardIssuerCountry?: string;
  forexCurrencyCode?: string | null;
  used3ds?: boolean;
};

export type PaymentProfile = {
  customerId: string;
  lastPayment: PaymentMetaTypes;
  previousUsedCardBrands?: string[];
  used3ds?: boolean;
};

export enum StripePaymentMethod {
  AcssDebit = "acss_debit",
  Affirm = "affirm",
  AfterpayClearpay = "afterpay_clearpay",
  Alipay = "alipay",
  AuBecsDebit = "au_becs_debit",
  BacsDebit = "bacs_debit",
  Bancontact = "bancontact",
  Blik = "blik",
  Boleto = "boleto",
  Card = "card",
  Cashapp = "cashapp",
  CustomerBalance = "customer_balance",
  Eps = "eps",
  Fpx = "fpx",
  Giropay = "giropay",
  Grabpay = "grabpay",
  Ideal = "ideal",
  Klarna = "klarna",
  Konbini = "konbini",
  Link = "link",
  Oxxo = "oxxo",
  P24 = "p24",
  Paynow = "paynow",
  Pix = "pix",
  Promptpay = "promptpay",
  SepaDebit = "sepa_debit",
  Sofort = "sofort",
  UsBankAccount = "us_bank_account",
  WechatPay = "wechat_pay",
  SamsunPay = "samsung_pay",
  Payco = "payco",
  KrCard = "kr_card",
  NaverPay = "naver_pay",
  KakaoPay = "kakao_pay"
}

export interface IForex {
  exchangeRate: number;
  currencyCode: string | null;
  vendorCurrencyCode: string | null;
  paymentMethod: PaymentElementEnum | null;
  isApplied: boolean;
  isInterrupted: boolean;
  isRoutingApplied?: boolean;
  tip: number;
  total: number;
}
