import { CCPPCardResponse } from "./payments/config/ccpp";

export * from "./icon";
export * from "./payments";

export enum Locales {
  English = "en",
  Arabic = "ar",
  Japanese = "ja",
  Portuguese = "pt",
  Turkish = "tr",
  Chinese = "zh",
  Spanish = "es",
  TraditionalMandarin = "hk",
  Korean = "ko",
  Russian = "ru"
}

export interface LazyComponentInventory {
  [key: string]: React.LazyExoticComponent<any>;
}

export interface KeyValue {
  [key: string]: any;
}

declare global {
  interface Window {
    clarity: (...args: any) => void;

    My2c2p: {
      getEncrypted: (formId: string, callback: (response: CCPPCardResponse, errorCode: number) => void) => void;
    };
    myFatoorahAP: any;
    myFatoorah: any;
  }
}
