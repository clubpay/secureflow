export interface IconProps {
  id?: string;
  className?: string;
  style?: React.CSSProperties;
  outlined?: boolean;
  height?: number;
  width?: number;
  [x: string]: any;
}
