import { produce } from "immer";
import { create } from "zustand";

interface pgDataType {
  cardsList: any[];
  value: number;
}

interface pgNewCardDataType {
  hasAdded: boolean;
  shouldSaveCard: boolean;
}

interface dataState {
  savedCardsData: Map<string, pgDataType>;
  newCardsData: Map<string, pgNewCardDataType>;
}

interface globalState {
  state: dataState;
  setCardList: (payload: { name: string; list: any[] }) => void;
  setSelectedCard: (arg1: string, arg2: string) => void;
  setNewCardData: (payload: string, status?: boolean) => void;
  setDiselectNewCardData: (payload: string) => void;
  setSaveCard: (payload: string) => void;
  removeCard: (arg1: string, arg2: string) => void;
}

export const useCardStore = create<globalState>((set) => ({
  state: {
    savedCardsData: new Map<string, pgDataType>(),
    newCardsData: new Map<string, pgNewCardDataType>()
  },
  setCardList: (payload) =>
    set(
      produce((store) => {
        store.state.savedCardsData.set(payload.name, {
          cardsList: payload.list
        });
      })
    ),

  setSelectedCard: (pgSignature: string, token: string) => {
    return set(
      produce((store) => {
        store.state.savedCardsData.set(pgSignature, {
          ...store.state.savedCardsData.get(pgSignature),
          cardsList: store.state.savedCardsData.get(pgSignature)?.cardsList?.map((card: any) => ({
            ...card,
            selected: card?.selected ? false : card.token === token
          }))
        });
      })
    );
  },
  setNewCardData: (pgSignature, status) =>
    set(
      produce((store) => {
        store.state.newCardsData.set(pgSignature, {
          ...store.state.newCardsData.get(pgSignature),
          hasAdded: typeof status !== "undefined" ? status : !store.state.newCardsData.get(pgSignature)?.hasAdded
        });
      })
    ),
  setDiselectNewCardData: (pgSignature: string) =>
    set(
      produce((store) => {
        store.state.newCardsData.set(pgSignature, {
          ...store.state.newCardsData.get(pgSignature),
          hasAdded: false
        });
      })
    ),
  setSaveCard: (pgSignature: string) =>
    set(
      produce((store) => {
        store.state.newCardsData.set(pgSignature, {
          ...store.state.newCardsData.get(pgSignature),
          shouldSaveCard: !store.state.newCardsData.get(pgSignature)?.shouldSaveCard
        });
      })
    ),
  removeCard: (pgSignature: string, cardToken: string) =>
    set(
      produce((store) => {
        const pgData = store.state.savedCardsData.get(pgSignature);
        if (pgData) {
          const updatedCardsList = pgData.cardsList.filter((card: any) => card.token !== cardToken);
          store.state.savedCardsData.set(pgSignature, {
            ...pgData,
            cardsList: updatedCardsList
          });
        }
      })
    )
}));

export const getSelectedCard = (pgSignature: string) => {
  const { state } = useCardStore((store: any) => store);

  if (state.savedCardsData?.get(pgSignature)?.cardsList)
    return state.savedCardsData?.get(pgSignature)?.cardsList?.find((card: any) => card.selected);

  return false;
};

export const hasSavedCardClicked = (pgSignature: string) => {
  const { state } = useCardStore((store: any) => store);

  return state.newCardsData?.get(pgSignature)?.shouldSaveCard;
};
