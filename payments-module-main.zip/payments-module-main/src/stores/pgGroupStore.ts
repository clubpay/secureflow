import { produce } from "immer";
import { create } from "zustand";

const initialState: any = {
  isPGGroupEnabled: false,
  pgElementsOrder: {},
  availablePGMethods: [],
  isPreferenceEmpty: false,
  pgGroupInteractionData: {
    currentSelected: null,
    currentSelectedPGName: ""
  },
  pgDependedPaymentMethodsData: {},
  pgMethodsReferenceHolder: {}
};

export const usePGGroupStore = create<any, []>((set) => ({
  state: initialState,
  toggleVisibility: (payload: { pgId: string; paymentMethod: string; name?: string }) =>
    set(
      produce((store: any) => {
        store.state.pgGroupInteractionData.currentSelected = `${payload.pgId}-${payload.paymentMethod}`;
        store.state.pgGroupInteractionData.currentSelectedPGName = payload.name ?? "";
      })
    ),
  setPGGroupStatus: (status: boolean) =>
    set(
      produce((store: any) => {
        store.state.isPGGroupEnabled = status;
      })
    ),
  setDefaultPGData: (payload: { pgId: string; paymentMethod: string; name?: string }) =>
    set(
      produce((store: any) => {
        store.state.pgGroupInteractionData.currentSelected = `${payload.pgId}-${payload.paymentMethod}`;
        store.state.pgGroupInteractionData.currentSelectedPGName = payload.name ?? "";
      })
    ),
  setAddPGMethod: (payload: { pgId: string; paymentMethod: string }) =>
    set(
      produce((store: any) => {
        if (!store.state.availablePGMethods.includes(`${payload.pgId}-${payload.paymentMethod}`))
          store.state.availablePGMethods.push(`${payload.pgId}-${payload.paymentMethod}`);
      })
    ),

  setPGDependedPaymentMethodsData: (payload: { pgId: string; paymentMethod: string }) =>
    set(
      produce((store: any) => {
        if (store.state.pgDependedPaymentMethodsData?.[payload.pgId]) {
          if (!store.state.pgDependedPaymentMethodsData[payload.pgId]?.includes(payload.paymentMethod)) {
            store.state.pgDependedPaymentMethodsData[payload.pgId]?.push(payload.paymentMethod);
          }
        } else store.state.pgDependedPaymentMethodsData[payload.pgId] = [payload.paymentMethod];
      })
    ),

  setPreferenceStatus: (status: boolean) =>
    set(
      produce((store: any) => {
        store.state.isPreferenceEmpty = status;
      })
    ),
  setPaymentMethodReference: (payload: { pgId: string; paymentMethod: string; fn: any }) =>
    set(
      produce((store: any) => {
        // if (!store.state.pgMethodsReferenceHolder[`${payload.pgId}-${payload.paymentMethod}`]) {
        //   store.state.pgMethodsReferenceHolder[`${payload.pgId}-${payload.paymentMethod}`] = { method: payload.fn }
        // }
        store.state.pgMethodsReferenceHolder[`${payload.pgId}-${payload.paymentMethod}`] = { method: payload.fn };
      })
    ),
  removePGMethod: (payload: { pgId: string; paymentMethod: string }) =>
    set(
      produce((store: any) => {
        store.state.availablePGMethods = store.state.availablePGMethods.filter(
          (pm: string) => pm !== `${payload.pgId}-${payload.paymentMethod}`
        );
      })
    )
}));

export const isPaymethodChoosed = (payload: { pgId: string; paymentMethod: string }) => {
  const { state } = usePGGroupStore((store: any) => store);
  return state.pgGroupInteractionData.currentSelected === `${payload.pgId}-${payload.paymentMethod}`;
};
