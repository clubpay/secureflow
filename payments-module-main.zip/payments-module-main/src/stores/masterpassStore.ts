import { produce } from "immer";
import { create } from "zustand";
import { MasterpassModalScreens } from "@/components/PaymentMethods/Card/Gateways/Masterpass/types";

const initialState: any = {
  state: {
    displayName: MasterpassModalScreens.NONE,
    cards: [],
    otp: {
      active: false,
      duration: 30,
      code: "",
      isCodeCompleted: false
    }
  }
};

export const useMasterpassStore = create<any, []>((set) => ({
  state: initialState,
  setMasterpassDisplay: (payload: any) =>
    set(
      produce((store: any) => {
        store.state.displayName = payload;
      })
    ),
  setCardsList: (payload: any) =>
    set(
      produce((store: any) => {
        store.state.cards = payload;
      })
    ),
  setSelectedCard: (payload: any) =>
    set(
      produce((store: any) => {
        store.state.cards = store.state?.cards?.map((card: any) => ({ ...card, selected: card.UniqueId === payload }));
      })
    ),
  removeCard: (payload: any) =>
    set(
      produce((store: any) => {
        store.state.cards = store.state?.cards?.filter((card: any) => ({
          ...card,
          selected: card.UniqueId != payload
        }));
      })
    ),
  setOTPProcess: (payload: { status: boolean; seconds?: number }) =>
    set(
      produce((store: any) => {
        store.state.otp.active = payload.status;
        store.state.otp.duration = payload.seconds ?? 30;
      })
    ),
  setOTPCode: (payload: { code: string; isCompleted: boolean }) =>
    set(
      produce((store: any) => {
        store.state.otp.code = payload.code;
        store.state.otp.isCodeCompleted = payload.isCompleted;
      })
    ),
  resetOTPProcess: () =>
    set(
      produce((store: any) => {
        store.state.otp = {
          active: false,
          duration: 30,
          code: "",
          isCodeCompleted: false
        };
      })
    )
}));
