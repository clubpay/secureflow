import { create } from "zustand";
import { PaymentGatewayConfig } from "@/types";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";

export type PaymentMethod = {
  name: PaymentElementEnum;
  pg: PaymentGatewayConfig;
};

export interface PgState {
  paymentMethods: PaymentMethod[];

  paymentMethodsCreatedAt: Date;
}

const initialState: PgState = { paymentMethods: [], paymentMethodsCreatedAt: new Date() };

export const usePgStore = create<PgState>()(() => ({
  ...initialState
}));

export const setPaymentMethods = (paymentMethods: PaymentMethod[]) =>
  usePgStore.setState((state: PgState) => ({ ...state, paymentMethods, paymentMethodsCreatedAt: new Date() }));
