import { ReactElement } from "react";
import { produce } from "immer";
import { create } from "zustand";

interface PayloadTypes {
  title: string;
  description: string;
  icon: ReactElement | null;
  actionButton: ReactElement | null;
}

interface ToastState {
  open: boolean;
  title: string;
  description: string;
  icon: ReactElement | null;
  actionButton: ReactElement | null;
  setOpen: (state: boolean) => void;
  setToastContent: (payload: PayloadTypes) => void;
}

const initialState: ToastState = {
  open: false,
  title: "",
  description: "",
  icon: null,
  actionButton: null,
  setOpen: (state: boolean) => {},
  setToastContent: (payload: PayloadTypes) => {}
};

export const useToastStore = create<ToastState>((set) => ({
  ...initialState,
  setOpen: (state: boolean) =>
    set(
      produce((store) => {
        store.open = state;
      })
    ),
  setToastContent: (payload: PayloadTypes) =>
    set(
      produce((store) => {
        store.title = payload.title;
        store.description = payload.description;
        store.actionButton = payload.actionButton;
        store.icon = payload.icon;
      })
    )
}));
