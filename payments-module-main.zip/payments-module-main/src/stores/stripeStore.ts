import { produce } from "immer";
import { create } from "zustand";

// Define types for the state structure
interface StripeState {
  isMultiUIModeActive: boolean;
  isApplePayEvaluated: boolean;
}

interface StripeStore {
  state: StripeState;
  setMultiUIMode: (flag: boolean) => void;
  setApplePayEvaluate: (flag: boolean) => void;
}

const initialState: StripeState = {
  isMultiUIModeActive: false,
  isApplePayEvaluated: false
};

export const useStripeStore = create<StripeStore>((set) => ({
  state: initialState,
  setMultiUIMode: (flag: boolean) =>
    set(
      produce((store: StripeStore) => {
        store.state.isMultiUIModeActive = flag;
      })
    ),

  setApplePayEvaluate: (flag: boolean) =>
    set(
      produce((store: StripeStore) => {
        store.state.isApplePayEvaluated = flag;
      })
    )
}));
