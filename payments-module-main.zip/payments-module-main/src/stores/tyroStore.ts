import { produce } from "immer";
import { create } from "zustand";

const initialState: any = {
  tyroSessionId: "",
  handlePayFunctionRef: null,
  initiated: false
};

export const useTyroStore = create<any, []>((set) => ({
  state: initialState,
  setPaymentFuncRef: (fn: VoidFunction | null) =>
    set(
      produce((store: any) => {
        store.state.handlePayFunctionRef = fn;
      })
    ),
  setTyroSessionId: (tyroSessionId: string) =>
    set(
      produce((store: any) => {
        store.state.tyroSessionId = tyroSessionId;
      })
    ),
  setInitStatus: (flag: boolean) =>
    set(
      produce((store: any) => {
        store.state.initiated = flag;
      })
    )
}));
