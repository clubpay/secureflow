import { create } from "zustand";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";

export interface ForexState {
  exchangeRate: number;
  currencyCode: string | null;
  vendorCurrencyCode: string | null;
  paymentMethod: PaymentElementEnum | null;
  paymentMethodOrder?: number | null;
  isApplied: boolean;
  isInterrupted: boolean;
  isRoutingApplied?: boolean;
  tip: number;
  total: number;
}

const initialState: ForexState = {
  exchangeRate: 0,
  currencyCode: null,
  vendorCurrencyCode: null,
  paymentMethod: null,
  paymentMethodOrder: null,
  isApplied: false,
  isInterrupted: false,
  isRoutingApplied: false,
  tip: 0,
  total: 0
};

export const useForexStore = create<ForexState>()(() => ({
  ...initialState
}));

export const setForex = (args: Partial<ForexState>) =>
  useForexStore.setState((state: ForexState) => ({ ...state, ...args }));

export const resetForex = () => useForexStore.setState(() => ({ ...initialState }));
