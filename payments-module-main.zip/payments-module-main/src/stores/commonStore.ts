import { produce } from "immer";
import { create } from "zustand";
import { ConsumerType } from "@/types";
import { ConsumerTypes } from "@/types";

interface CommonState {
  consumer: ConsumerType;
  total: number;
  lockedTime: number;
  isLocked: boolean;
  isPriorityMode: boolean;
  isRTL: boolean;
  isPayButtonTextChangeEnabled: boolean;
  countryCode: string;
  applePayConsent: boolean;
  applePayConsentCountryFlag: boolean;
  loadedState: {
    moysarV1: boolean;
    checkout: boolean;
    ngenius: boolean;
    tuna: boolean;
    applePay: boolean;
    ccpp: boolean;
    tyro: boolean;
    myFatoorah: boolean;
  };
  paymentTraceId: string;
  priority: {
    isEnabled: boolean;
    currentPriority: number;
    blockedPgs: string[];
  };
  forexPGData: {
    rootPGElementsOrder: string[];
    reallocationMode: number;
  };
  lastPaymentData: {
    pgId: string;
    method: string;
    name: string;
  };
}

interface CommonStore {
  state: CommonState;
  setConsumer: (name: ConsumerType) => void;
  setTotal: (amount: number) => void;
  setLoadedState: (name: string, status?: boolean) => void;
  setPriority: (payload: { isEnabled?: boolean; currentPriority?: number | null; blockedPgs?: string[] }) => void;
  setPayNowBtnLabelChange: (status: boolean) => void;
  setRootPGElementsOrder: (order?: any[]) => void;
  setReallocationMode: (stage: number) => void;
  setPaymentTraceId: (id: string) => void;
  setCountryCode: (code: string) => void;
  setApplePayConsent: (status: boolean) => void;
  setApplePayConsentCountryFlag: (status: boolean) => void;
  setLastPaymentForDefaultSelect: (data: { id: string; method: string; name: string }) => void;
  resetLastPaymentDefault: () => void;
  setRTL: (flag: boolean) => void;
  lock: (time?: number) => void;
  unlock: () => void;
}

const initialState: CommonState = {
  consumer: ConsumerTypes.CUSTOMER_APP,
  isLocked: false,
  lockedTime: 5000,
  isPriorityMode: false,
  isRTL: false,
  isPayButtonTextChangeEnabled: false,
  total: 0,
  countryCode: "",
  applePayConsent: false,
  applePayConsentCountryFlag: false,
  loadedState: {
    moysarV1: false,
    checkout: false,
    ngenius: false,
    tuna: false,
    applePay: false,
    ccpp: false,
    tyro: false,
    myFatoorah: false
  },
  paymentTraceId: "",
  priority: {
    isEnabled: false,
    currentPriority: 0,
    blockedPgs: []
  },
  forexPGData: {
    rootPGElementsOrder: [],
    reallocationMode: 0
  },
  lastPaymentData: {
    pgId: "",
    method: "",
    name: ""
  }
};

export const useCommonStore = create<CommonStore>((set) => ({
  state: initialState,
  setConsumer: (name: ConsumerType) =>
    set(
      produce((store) => {
        store.state.consumer = name;
      })
    ),
  setPriority: (priority) =>
    set(
      produce((store) => {
        store.state.priority = { ...store.state.priority, ...priority };
      })
    ),
  setLoadedState: (name: string, status?: boolean) =>
    set(
      produce((store) => {
        store.state.loadedState[name] = status ?? true;
      })
    ),
  setTotal: (amount: number) =>
    set(
      produce((store) => {
        store.state.total = amount;
      })
    ),

  setPayNowBtnLabelChange: (flag: boolean) => {
    set(
      produce((store) => {
        store.state.isPayButtonTextChangeEnabled = flag;
      })
    );
  },
  setPaymentTraceId: (id: string) => {
    set(
      produce((store) => {
        store.state.paymentTraceId = id;
      })
    );
  },
  setRTL: (flag: boolean) => {
    set(
      produce((store) => {
        store.state.isRTL = flag;
      })
    );
  },
  setRootPGElementsOrder: (order?: any[]) => {
    set(
      produce((store) => {
        store.state.forexPGData.rootPGElementsOrder = order;
      })
    );
  },
  setReallocationMode: (stage: number) => {
    set(
      produce((store) => {
        store.state.forexPGData.reallocationMode = stage;
      })
    );
  },
  setCountryCode: (code: string) =>
    set(
      produce((store) => {
        store.state.countryCode = code;
      })
    ),
  setApplePayConsentCountryFlag: (flag: boolean) =>
    set(
      produce((store) => {
        store.state.applePayConsentCountryFlag = flag;
      })
    ),
  setApplePayConsent: (flag: boolean) =>
    set(
      produce((store) => {
        store.state.applePayConsent = flag;
      })
    ),
  setLastPaymentForDefaultSelect: (data: { id: string; method: string; name: string }) =>
    set(
      produce((store) => {
        store.state.lastPaymentData.pgId = data.id;
        store.state.lastPaymentData.method = data.method;
        store.state.lastPaymentData.name = data.name;
      })
    ),
  resetLastPaymentDefault: () =>
    set(
      produce((store) => {
        store.state.lastPaymentData.pgId = "";
        store.state.lastPaymentData.method = "";
      })
    ),
  lock: (lockedTime = 6000) =>
    set(
      produce((store) => {
        store.state.isLocked = true;
        store.state.lockedTime = lockedTime;
      })
    ),
  unlock: () =>
    set(
      produce((store) => {
        store.state.isLocked = false;
      })
    )
}));

export const getTotal = () => {
  const {
    state: { total }
  } = useCommonStore((store) => store);
  return total;
};
