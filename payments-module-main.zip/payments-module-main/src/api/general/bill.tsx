import axiosInstance from "@clubpay/customer-common-module/src/repository/axios";

export default class BillAPIManager {
  private static instance: BillAPIManager;

  public static getInstance() {
    if (!this.instance) {
      this.instance = new BillAPIManager();
    }

    return this.instance;
  }

  public lockPayment = async (payload: any) => {
    const res = await axiosInstance.Post<any, any>("/payment/lock", payload, {
      "axios-retry": {
        retries: 3
      }
    });
    return res.data;
  };

  public unlockPayment = async (payload: any) => {
    const res = await axiosInstance.Post<any, any>("/payment/unlock", payload, {
      "axios-retry": {
        retries: 3
      }
    });
    return res.data;
  };

  public getStatus = async (payload: any) => {
    return axiosInstance.Get<any>(`payment/status`, {
      params: {
        reference: payload.reference,
        diningSessionID: payload.diningSessionID,
        id: payload.id
      }
    });
  };
}
