import {
  ICCPPDetails,
  ICCPPPayByApplePayload,
  ICCPPPayByCardPayload,
  ICCPPPayByCardResponse,
  ICCPPPayByGooglePayload
} from "@/types/api/ccpp";
import { IValidateApplePaySessionPayload, IValidateApplePaySessionResponse } from "@/types/api/common";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class CCPPAPIManager {
  private basepath = "/ccpp-gateway";

  public payByCard = (payload: ICCPPPayByCardPayload) => {
    return axiosInstance.Post<ICCPPPayByCardResponse, ICCPPPayByCardPayload>(`${this.basepath}/pay`, payload);
  };

  public payByApple = (payload: ICCPPPayByApplePayload) => {
    return axiosInstance.Post<ICCPPDetails, ICCPPPayByApplePayload>(`${this.basepath}/apple-pay`, payload);
  };

  public validateApplePaySession = (payload: IValidateApplePaySessionPayload) => {
    return axiosInstance.Post<IValidateApplePaySessionResponse, IValidateApplePaySessionPayload>(
      `${this.basepath}/apple-pay/validate`,
      payload
    );
  };

  public payByGoogle = (payload: ICCPPPayByGooglePayload) => {
    return axiosInstance.Post<ICCPPDetails, ICCPPPayByGooglePayload>(`${this.basepath}/google-pay`, payload);
  };
}
