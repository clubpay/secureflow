import { IDGPayGet3DSSessionPayload, IDGPayGet3DSSessionResponse } from "@/types/api/dgpay";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class DGPayAPIManager {
  private basepath = "/dgpay-gateway";

  public getSession = (payload: IDGPayGet3DSSessionPayload) => {
    return axiosInstance.Post<IDGPayGet3DSSessionResponse, IDGPayGet3DSSessionPayload>(
      `${this.basepath}/threedpayment`,
      payload
    );
  };
}
