import {
  ITunaCardPaymentPayload,
  ITunaPayByApplePayPayload,
  ITunaPayByGooglePayload,
  ITunaPayByGoogleResponse,
  ITunaPaySessionPayload,
  ITunaPaySessionResponse,
  ITunaPixPaymentPayload,
  ITunaPixPaymentResponse,
  ITunaValidatePayload,
  ITunaVerifyPixPayload,
  ITunaVerifyPixResponse
} from "@/types/api/tuna";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class TunaAPIManager {
  private basepath = "/tuna-gateway";

  public session = (payload: ITunaPaySessionPayload) => {
    return axiosInstance.Post<ITunaPaySessionResponse, ITunaPaySessionPayload>(`${this.basepath}/new-session`, payload);
  };

  public cardPayment = (payload: ITunaCardPaymentPayload) => {
    return axiosInstance.Post<ITunaPixPaymentResponse, ITunaCardPaymentPayload>(`${this.basepath}/card`, payload);
  };

  public payByGoogle = (payload: ITunaPayByGooglePayload) => {
    return axiosInstance.Post<ITunaPayByGoogleResponse, ITunaPayByGooglePayload>(`${this.basepath}/googlepay`, payload);
  };

  public pixPayment = (payload: ITunaPixPaymentPayload) => {
    return axiosInstance.Post<ITunaPixPaymentResponse, ITunaPixPaymentPayload>(`${this.basepath}/pix`, payload);
  };

  public verifyPix = (payload: ITunaVerifyPixPayload) => {
    return axiosInstance.Post<ITunaVerifyPixResponse, ITunaVerifyPixPayload>(`${this.basepath}/verify-pix`, payload);
  };

  public payByApple = (payload: ITunaPayByApplePayPayload) => {
    return axiosInstance.Post<any, ITunaPayByApplePayPayload>(`${this.basepath}/apple-pay`, payload);
  };

  public validateApplePaySession = (payload: ITunaValidatePayload) => {
    return axiosInstance.Post<any, ITunaValidatePayload>(`${this.basepath}/apple-pay/validate`, payload);
  };
}
