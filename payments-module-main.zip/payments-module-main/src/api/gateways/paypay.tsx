import { IPaypayRegisterPayload, IPaypayRegisterResponse } from "@/types/api/paypay";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class PayPayAPIManager {
  private basepath = "/paypay-gateway";

  public register = (payload: IPaypayRegisterPayload) => {
    return axiosInstance.Post<IPaypayRegisterResponse, IPaypayRegisterPayload>(
      `${this.basepath}/threedpayment`,
      payload
    );
  };
}
