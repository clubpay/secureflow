import { IMoneyhashCardPayPayload, IMoneyhashCardPayResponse } from "@/types/api/moneyhash";
import axiosInstance from "@clubpay/customer-common-module/src/repository/axios";

export default class MoneyhashAPIManager {
  private basepath = "/moneyhash-gateway";

  public payByCard = (payload: IMoneyhashCardPayPayload) => {
    return axiosInstance.Post<IMoneyhashCardPayResponse, IMoneyhashCardPayPayload>(
      `${this.basepath}/card-pay`,
      payload,
      {
        "axios-retry": {
          retries: 0
        },
        "timeout": 45000
      }
    );
  };
}
