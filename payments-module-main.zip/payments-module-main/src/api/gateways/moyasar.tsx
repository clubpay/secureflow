import axiosRetry from "axios-retry";
import {
  IMoyasarIntentPayload,
  IMoyasarIntentResponse,
  IMoyasarPayPayload,
  IMoyasarPayResponse,
  IMoyasarUpdatePayload,
  IMoyasarUpdateResponse,
  IVerifyMoyasarPaymentPayload,
  IVerifyMoyasarPaymentResponse
} from "@/types/api/moyasar";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class MoyasarAPIManager {
  private basepath = "/moyasar-gateway";

  public pay = (payload: IMoyasarPayPayload) => {
    return axiosInstance.Post<IMoyasarPayResponse, IMoyasarPayPayload>(`${this.basepath}/pay`, payload);
  };

  public createIntent = (payload: IMoyasarIntentPayload) => {
    return axiosInstance.Post<IMoyasarIntentResponse, IMoyasarIntentPayload>(
      `${this.basepath}/create-intent`,
      payload,
      {
        "axios-retry": {
          retries: 3,
          retryCondition: (err: any) => {
            return Promise.resolve(
              axiosRetry.isNetworkOrIdempotentRequestError(err) ||
                (err?.response?.data?.code === 404 && err?.response?.data?.items === "INVALID_PARTICIPANT_ID")
            );
          },
          retryDelay: (retryCount: number) => {
            return retryCount * 1000;
          }
        },
        "timeout": 45000
      }
    );
  };

  public updateIntent = (payload: IMoyasarUpdatePayload) => {
    return axiosInstance.Post<IMoyasarUpdateResponse, IMoyasarUpdatePayload>(`${this.basepath}/update-intent`, payload);
  };

  public verify = (payload: IVerifyMoyasarPaymentPayload) => {
    return axiosInstance.Get<IVerifyMoyasarPaymentPayload, IVerifyMoyasarPaymentResponse>(
      `${this.basepath}/verify/${payload.diningSessionID}/${payload.gatewayID}`,
      {
        params: {
          reference: payload.reference
        },
        timeout: 45000
      }
    );
  };
}
