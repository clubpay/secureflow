import {
  IGenerateSessionTyroPayload,
  IGenerateSessionTyroResponse,
  ITyroAuthorizePayload,
  ITyroAuthorizeResponse,
  ITyroPayByApplePayload,
  ITyroPayByGooglePayload,
  ITyroPayByGoogleResponse,
  ITyroPayPayload,
  ITyroPayResponse,
  ITyroValidateApplePayPayload
} from "@/types/api/tyro";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class TyroAPIManager {
  private basepath = "/tyro-gateway";

  public session = (payload: IGenerateSessionTyroPayload) => {
    return axiosInstance.Post<IGenerateSessionTyroResponse, IGenerateSessionTyroPayload>(
      `${this.basepath}/generate-session`,
      payload
    );
  };

  public pay = (payload: ITyroPayPayload) => {
    return axiosInstance.Post<ITyroPayResponse, ITyroPayPayload>(`${this.basepath}/pay`, payload);
  };

  public payByApple = (payload: ITyroPayByApplePayload) => {
    return axiosInstance.Post<any, ITyroPayByApplePayload>(`${this.basepath}/apple-pay`, payload);
  };
  public payByGoogle = (payload: ITyroPayByGooglePayload) => {
    return axiosInstance.Post<ITyroPayByGoogleResponse, ITyroPayByGooglePayload>(
      `${this.basepath}/google-pay`,
      payload
    );
  };

  public validateApplePaySession = (payload: ITyroValidateApplePayPayload) => {
    return axiosInstance.Post<any, ITyroValidateApplePayPayload>(`${this.basepath}/apple-pay/validate`, payload);
  };

  public payAuthorize = (payload: ITyroAuthorizePayload) => {
    return axiosInstance.Get<ITyroAuthorizeResponse, ITyroAuthorizePayload>(
      `${this.basepath}/pay-with-authorization/${payload.tyroSessionId}`
    );
  };
}
