import {
  IPayTMInitiateTransactionResponse,
  IPayTMLegacyInitiateTransactionPayload,
  IPayTMVerifyTransactionPayload,
  IPayTMVerifyTransactionResponse
} from "@/types/api/paytm";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class PayTMLegacyAPIManager {
  private basepath = "/paytm-legacy-gateway";

  public initiateTransaction = (payload: IPayTMLegacyInitiateTransactionPayload) => {
    return axiosInstance.Post<IPayTMInitiateTransactionResponse, IPayTMLegacyInitiateTransactionPayload>(
      `${this.basepath}/initiate`,
      payload
    );
  };

  public verifyTransaction = (payload: IPayTMVerifyTransactionPayload) => {
    return axiosInstance.Get<IPayTMVerifyTransactionResponse, IPayTMVerifyTransactionPayload>(
      `${this.basepath}/initiate/${payload.diningSessionID}/${payload.orderID}/${payload.gatewayID}`,
      {
        params: {
          reference: payload.reference,
          id: payload.id,
          txnType: payload.txnType
        }
      }
    );
  };
}
