import {
  ICheckoutPlatformDetails,
  ICheckoutPlatformPayByApplePayload,
  ICheckoutPlatformPayByGooglePayload,
  ICheckoutPlatformPayByTokenPayload,
  ICheckoutPlatformPayByTokenResponse
} from "@/types/api/checkoutPlatform";
import { IValidateApplePaySessionPayload, IValidateApplePaySessionResponse } from "@/types/api/common";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class CheckoutPlatformAPIManager {
  private basepath = "/checkout-platform-gateway";

  public payByApple = (payload: ICheckoutPlatformPayByApplePayload) => {
    return axiosInstance.Post<ICheckoutPlatformDetails, ICheckoutPlatformPayByApplePayload>(
      `${this.basepath}/apple-pay`,
      payload
    );
  };

  public payByGoogle = (payload: ICheckoutPlatformPayByGooglePayload) => {
    return axiosInstance.Post<ICheckoutPlatformDetails, ICheckoutPlatformPayByGooglePayload>(
      `${this.basepath}/google-pay`,
      payload
    );
  };

  public validateApplePaySession = (payload: IValidateApplePaySessionPayload) => {
    return axiosInstance.Post<IValidateApplePaySessionResponse, IValidateApplePaySessionPayload>(
      `${this.basepath}/apple-pay/validate`,
      payload
    );
  };

  public payByToken = (payload: ICheckoutPlatformPayByTokenPayload) => {
    return axiosInstance.Post<ICheckoutPlatformPayByTokenResponse, ICheckoutPlatformPayByTokenPayload>(
      `${this.basepath}/token`,
      payload
    );
  };
}
