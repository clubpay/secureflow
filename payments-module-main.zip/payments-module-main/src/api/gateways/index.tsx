import { PaymentGateways } from "@/types";
import AdyenAPIManager from "./adyen";
import CCPPAPIManager from "./ccpp";
import CheckoutAPIManager from "./checkout";
import CheckoutPlatformAPIManager from "./checkoutPlatform";
import DGPayAPIManager from "./dgpay";
import DivitAPIManager from "./divit";
import IndiaGPayAPIManager from "./indiagooglepay";
import MafAPIManager from "./maf";
import MashReqAPIManager from "./mashreq";
import MasterpassAPIManager from "./masterpass";
import MasterpassDirectAPIManager from "./masterpassDirect";
import Moneyhash from "./moneyhash";
import MoyasarAPIManager from "./moyasar";
import MoyasarV2APIManager from "./moyasarV2";
import MyFatoorahAPIManager from "./myFatoorah";
import NgeniusAPIManager from "./ngenius";
import PayPayAPIManager from "./paypay";
import PayTMAPIManager from "./paytm";
import PayTMLegacyAPIManager from "./paytmLegacy";
import SMBCAPIManager from "./smbc";
import StripeAPIManager from "./stripe";
import StripeConnectAPIManager from "./stripeConnect";
import TappAPIManager from "./tapp";
import TicketAPIManager from "./ticket";
import TunaAPIManager from "./tuna";
import TyroAPIManager from "./tyro";
import VostroAPIManager from "./vostro";

export default class PaymentAPIManager {
  private static instance: PaymentAPIManager;

  public adyen: AdyenAPIManager;
  public checkout: CheckoutAPIManager;
  public checkoutPlatform: CheckoutPlatformAPIManager;
  public dgpay: DGPayAPIManager;
  public indiagooglepay: IndiaGPayAPIManager;
  public maf: MafAPIManager;
  public mashreq: MashReqAPIManager;
  public moyasar: MoyasarAPIManager;
  public moyasarV2: MoyasarV2APIManager;
  public paypay: PayPayAPIManager;
  public paytm: PayTMAPIManager;
  public paytmLegacy: PayTMLegacyAPIManager;
  public smbc: SMBCAPIManager;
  public stripe: StripeAPIManager;
  public stripeConnect: StripeConnectAPIManager;
  public tapp: TappAPIManager;
  public ticket: TicketAPIManager;
  public tuna: TunaAPIManager;
  public vostro: VostroAPIManager;
  public ngenius: NgeniusAPIManager;
  public masterpass: MasterpassAPIManager;
  public masterpassDirect: MasterpassDirectAPIManager;
  public ccpp: CCPPAPIManager;
  public myFatoorah: MyFatoorahAPIManager;
  public tyro: TyroAPIManager;
  public moneyhash: Moneyhash;
  public divit: DivitAPIManager;

  private constructor() {
    this.adyen = new AdyenAPIManager();
    this.checkout = new CheckoutAPIManager();
    this.checkoutPlatform = new CheckoutPlatformAPIManager();
    this.dgpay = new DGPayAPIManager();
    this.indiagooglepay = new IndiaGPayAPIManager();
    this.maf = new MafAPIManager();
    this.mashreq = new MashReqAPIManager();
    this.moyasar = new MoyasarAPIManager();
    this.moyasarV2 = new MoyasarV2APIManager();
    this.paypay = new PayPayAPIManager();
    this.paytm = new PayTMAPIManager();
    this.paytmLegacy = new PayTMLegacyAPIManager();
    this.smbc = new SMBCAPIManager();
    this.stripe = new StripeAPIManager();
    this.stripeConnect = new StripeConnectAPIManager();
    this.tapp = new TappAPIManager();
    this.ticket = new TicketAPIManager();
    this.tuna = new TunaAPIManager();
    this.vostro = new VostroAPIManager();
    this.ngenius = new NgeniusAPIManager();
    this.masterpass = new MasterpassAPIManager();
    this.masterpassDirect = new MasterpassDirectAPIManager();
    this.ccpp = new CCPPAPIManager();
    this.myFatoorah = new MyFatoorahAPIManager();
    this.tyro = new TyroAPIManager();
    this.moneyhash = new Moneyhash();
    this.divit = new DivitAPIManager();
  }

  public static getInstance() {
    if (!this.instance) {
      this.instance = new PaymentAPIManager();
    }
    return this.instance;
  }

  public setGatewayManager(gateway: PaymentGateways, manager: any) {
    this[gateway] = manager;
  }
}
