import { IGooglePayIndiaPayload, IGooglePayIndiaResponse } from "@/types/api/indiagooglepay";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class IndiaGPayAPIManager {
  private basepath = "/google-pay-gateway";

  public sync = (payload: IGooglePayIndiaPayload) => {
    return axiosInstance.Post<IGooglePayIndiaResponse, IGooglePayIndiaPayload>(`${this.basepath}/sync`, payload);
  };
}
