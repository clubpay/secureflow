import { IMasterPassGenerateTokenPayload, IMasterPassGenerateTokenResponse } from "@/types/api/masterpass";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class MasterPassDirectAPIManager {
  private basepath = "/masterpassdirect-turkiye";

  public generateToken = (payload: IMasterPassGenerateTokenPayload) => {
    return axiosInstance.Post<IMasterPassGenerateTokenResponse, IMasterPassGenerateTokenPayload>(
      `${this.basepath}/generate-token`,
      payload,
      {
        timeout: 10000
      }
    );
  };
}
