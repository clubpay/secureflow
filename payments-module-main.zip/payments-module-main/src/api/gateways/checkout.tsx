import {
  ICheckoutDetails,
  ICheckoutPayByApplePayload,
  ICheckoutPayByGooglePayload,
  ICheckoutPayByKNETPayload,
  ICheckoutPayByKNETResponse,
  ICheckoutPayBySTCPayCapturePayload,
  ICheckoutPayBySTCPayPayload,
  ICheckoutPayBySTCPayResponse,
  ICheckoutPayByTokenPayload,
  ICheckoutPayByTokenResponse,
  ICheckoutPayWithSavedCardPayload,
  ICheckoutPayWithSavedCardResponse,
  ICheckoutSavedCardDetailsResponse,
  ICheckoutUnsaveCardResponse
} from "@/types/api/checkout";
import { ICardStorage, IValidateApplePaySessionPayload, IValidateApplePaySessionResponse } from "@/types/api/common";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class CheckoutAPIManager implements ICardStorage {
  private basepath = "/checkout-gateway";

  public payByToken = (payload: ICheckoutPayByTokenPayload) => {
    return axiosInstance.Post<ICheckoutPayByTokenResponse, ICheckoutPayByTokenPayload>(
      `${this.basepath}/token`,
      payload,
      {
        "axios-retry": {
          retries: 0
        },
        "timeout": 45000
      }
    );
  };

  public payBySavedCard = (payload: ICheckoutPayWithSavedCardPayload) => {
    return axiosInstance.Post<ICheckoutPayWithSavedCardResponse, ICheckoutPayWithSavedCardPayload>(
      `${this.basepath}/source-id-pay`,
      payload,
      {
        "axios-retry": {
          retries: 0
        },
        "timeout": 45000
      }
    );
  };

  public payByGoogle = (payload: ICheckoutPayByGooglePayload) => {
    return axiosInstance.Post<ICheckoutDetails, ICheckoutPayByGooglePayload>(`${this.basepath}/google-pay`, payload, {
      "axios-retry": {
        retries: 0
      },
      "timeout": 45000
    });
  };

  public payByApple = (payload: ICheckoutPayByApplePayload) => {
    return axiosInstance.Post<ICheckoutDetails, ICheckoutPayByApplePayload>(`${this.basepath}/apple-pay`, payload, {
      "axios-retry": {
        retries: 0
      },
      "timeout": 45000
    });
  };

  public validateApplePaySession = (payload: IValidateApplePaySessionPayload) => {
    return axiosInstance.Post<IValidateApplePaySessionResponse, IValidateApplePaySessionPayload>(
      `${this.basepath}/apple-pay/validate`,
      payload
    );
  };

  public getSavedCardDetails = () => {
    return axiosInstance.Get<ICheckoutSavedCardDetailsResponse>(`${this.basepath}/saved-card-details`);
  };

  public unsaveCard = () => {
    return axiosInstance.Post<ICheckoutUnsaveCardResponse>(`${this.basepath}/unsave-card`);
  };

  public payBySTCPay = (payload: ICheckoutPayBySTCPayPayload) => {
    return axiosInstance.Post<ICheckoutPayBySTCPayResponse, ICheckoutPayBySTCPayPayload>(
      `${this.basepath}/stc-pay-request`,
      payload
    );
  };

  public payBySTCPayCapture = (payload: ICheckoutPayBySTCPayCapturePayload) => {
    return axiosInstance.Post<ICheckoutPayBySTCPayResponse, ICheckoutPayBySTCPayCapturePayload>(
      `${this.basepath}/stc-pay-capture`,
      payload
    );
  };

  public payByKNET = (payload: ICheckoutPayByKNETPayload) => {
    return axiosInstance.Post<ICheckoutPayByKNETResponse, ICheckoutPayByKNETPayload>(
      `${this.basepath}/knet-request`,
      payload
    );
  };
  public payByQPayRequest = (payload: any) => {
    return axiosInstance.Post<any, any>(`${this.basepath}/qpay-request`, payload);
  };
}
