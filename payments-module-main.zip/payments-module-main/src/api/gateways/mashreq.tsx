import { IValidateApplePaySessionPayload, IValidateApplePaySessionResponse } from "@/types/api/common";
import {
  IGenerateSessionMashreqPayload,
  IGenerateSessionMashreqResponse,
  IMashreqAuthorizePayload,
  IMashreqAuthorizeResponse,
  IMashreqDetails,
  IMashreqPayByApplePayload,
  IMashreqPayResponse,
  IPayMashreqPayload
} from "@/types/api/mashreq";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class MashReqAPIManager {
  private basepath = "/mashreq-gateway";

  public generateSession = (payload: IGenerateSessionMashreqPayload) => {
    return axiosInstance.Post<IGenerateSessionMashreqResponse, IGenerateSessionMashreqPayload>(
      `${this.basepath}/generate-session`,
      payload
    );
  };

  public pay = (payload: IPayMashreqPayload) => {
    return axiosInstance.Post<IMashreqPayResponse, IPayMashreqPayload>(`${this.basepath}/pay`, payload, {
      timeout: 45000
    });
  };

  public authorize = (payload: IMashreqAuthorizePayload) => {
    return axiosInstance.Get<IMashreqAuthorizeResponse>(
      `${this.basepath}/pay-with-authorization/${payload.mashreqSessionId}`
    );
  };

  public validateApplePaySession = (payload: IValidateApplePaySessionPayload) => {
    return axiosInstance.Post<IValidateApplePaySessionResponse, IValidateApplePaySessionPayload>(
      `${this.basepath}/apple-pay/validate`,
      payload
    );
  };

  public payByApple = (payload: IMashreqPayByApplePayload) => {
    return axiosInstance.Post<IMashreqDetails, IMashreqPayByApplePayload>(`${this.basepath}/apple-pay`, payload);
  };
}
