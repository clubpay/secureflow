import { IValidateApplePaySessionPayload, IValidateApplePaySessionResponse } from "@/types/api/common";
import {
  ITappApplePayDetails,
  ITappPayByApplePayload,
  ITappPaymentPayload,
  ITappPaymentResponse
} from "@/types/api/tapp";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class TappAPIManager {
  private basepath = "/tap-gateway";

  public pay = (payload: ITappPaymentPayload) => {
    return axiosInstance.Post<ITappPaymentResponse, ITappPaymentPayload>(`${this.basepath}/token`, payload);
  };

  public validateApplePaySession = (payload: IValidateApplePaySessionPayload) => {
    return axiosInstance.Post<IValidateApplePaySessionResponse, IValidateApplePaySessionPayload>(
      `${this.basepath}/apple-pay/validate`,
      payload
    );
  };

  public payByApple = (payload: ITappPayByApplePayload) => {
    return axiosInstance.Post<ITappApplePayDetails, ITappPayByApplePayload>(`${this.basepath}/apple-pay`, payload);
  };
}
