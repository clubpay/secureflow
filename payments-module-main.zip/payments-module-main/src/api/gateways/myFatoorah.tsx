import {
  IMyFatoorahInitiateSessionPayload,
  IMyFatoorahInitiateSessionResponse,
  IMyFatoorahPayByApplePayload,
  IMyFatoorahPayByAppleResponse,
  IMyFatoorahPayByCardPayload,
  IMyFatoorahPayByCardResponse,
  IMyFatoorahPayByKNetApplePayload,
  IMyFatoorahPayByKNetAppleResponse,
  IMyFatoorahPayByKNetResponse,
  IMyFatoorahPayByKetPayload
} from "@/types/api/myFatoorah";
import axiosInstance from "@clubpay/customer-common-module/src/repository/axios";

export default class MyFatoorahAPIManager {
  private basepath = "/myfatoorah-gateway";

  public initiateSession = (payload: IMyFatoorahInitiateSessionPayload) => {
    return axiosInstance.Post<IMyFatoorahInitiateSessionResponse, IMyFatoorahInitiateSessionPayload>(
      `${this.basepath}/initiate-session`,
      payload
    );
  };

  public payByApple = (payload: IMyFatoorahPayByApplePayload) => {
    return axiosInstance.Post<IMyFatoorahPayByAppleResponse, IMyFatoorahPayByApplePayload>(
      `${this.basepath}/apple-pay`,
      payload
    );
  };

  public payByCard = (payload: IMyFatoorahPayByCardPayload) => {
    return axiosInstance.Post<IMyFatoorahPayByCardResponse, IMyFatoorahPayByCardPayload>(
      `${this.basepath}/card`,
      payload
    );
  };
  public payByKNetApple = (payload: IMyFatoorahPayByKNetApplePayload) => {
    return axiosInstance.Post<IMyFatoorahPayByKNetAppleResponse, IMyFatoorahPayByKNetApplePayload>(
      `${this.basepath}/knet-apple-pay`,
      payload
    );
  };

  public payByKNet = (payload: IMyFatoorahPayByKetPayload) => {
    return axiosInstance.Post<IMyFatoorahPayByKNetResponse, IMyFatoorahPayByKetPayload>(
      `${this.basepath}/knet`,
      payload
    );
  };
}
