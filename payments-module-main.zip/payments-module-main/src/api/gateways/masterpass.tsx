import {
  IMasterPassCommitPayload,
  IMasterPassCommitResponse,
  IMasterPassGenerateReferenceResponse,
  IMasterPassGenerateTokenPayload,
  IMasterPassGenerateTokenResponse,
  IUnlinkAccountPayload,
  IUnlinkAccountResponse
} from "@/types/api/masterpass";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class MasterPassAPIManager {
  private basepath = "/masterpass-turkiye";

  public commit = (payload: IMasterPassCommitPayload) => {
    return axiosInstance.Post<IMasterPassCommitResponse, IMasterPassCommitPayload>(`${this.basepath}/commit`, payload);
  };

  public generateToken = (payload: IMasterPassGenerateTokenPayload) => {
    return axiosInstance.Post<IMasterPassGenerateTokenResponse, IMasterPassGenerateTokenPayload>(
      `${this.basepath}/generate-token`,
      payload,
      {
        timeout: 10000
      }
    );
  };

  public generateReference = () => {
    return axiosInstance.Get<IMasterPassGenerateReferenceResponse>(`${this.basepath}/gen-reference`, {
      timeout: 10000
    });
  };

  public check = () => {
    return axiosInstance.Get<IMasterPassGenerateReferenceResponse>(`${this.basepath}/gen-reference`, {
      timeout: 10000
    });
  };

  public unlink = (payload: IUnlinkAccountPayload) => {
    return axiosInstance.Post<IUnlinkAccountResponse, IUnlinkAccountPayload>(`${this.basepath}/unlink`, payload, {
      timeout: 10000
    });
  };
}
