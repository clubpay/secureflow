import {
  IPayTMInitiateTransactionPayload,
  IPayTMInitiateTransactionResponse,
  IPayTMVerifyTransactionPayload,
  IPayTMVerifyTransactionResponse
} from "@/types/api/paytm";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class PayTMAPIManager {
  private basepath = "/paytm-gateway";

  public initiateTransaction = (payload: IPayTMInitiateTransactionPayload) => {
    return axiosInstance.Post<IPayTMInitiateTransactionResponse, IPayTMInitiateTransactionPayload>(
      `${this.basepath}/initiate`,
      payload
    );
  };

  public verifyTransaction = (payload: IPayTMVerifyTransactionPayload) => {
    return axiosInstance.Get<IPayTMVerifyTransactionResponse, IPayTMVerifyTransactionPayload>(
      `${this.basepath}/verify/${payload.diningSessionID}/${payload.orderID}/${payload.gatewayID}`,
      {
        params: {
          reference: payload.reference,
          id: payload.id,
          txnType: payload.txnType
        }
      }
    );
  };
}
