import { INgeniusPayByUnionPayPayload, INgeniusPayByUnionPayResponse } from "@/types/api/ngenius";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class NgeniusAPIManager {
  private basepath = "/ngenius-gateway";

  public payByApple = (payload: any) => {
    return axiosInstance.Post<any, any>(`${this.basepath}/apple-pay`, payload, {
      "axios-retry": {
        retries: 0
      },
      "timeout": 45000
    });
  };

  public validateApplePaySession = (payload: any) => {
    return axiosInstance.Post<any, any>(`${this.basepath}/apple-pay/validate`, payload);
  };

  public capture = (payload: any) => {
    return axiosInstance.Post<any, any>(`${this.basepath}/capture`, payload);
  };

  public payByToken = (payload: any) => {
    return axiosInstance.Post<any, any>(`${this.basepath}/card-pay`, payload, {
      "axios-retry": {
        retries: 0
      },
      "timeout": 45000
    });
  };

  public payByUnionPay = (payload: INgeniusPayByUnionPayPayload) => {
    return axiosInstance.Post<INgeniusPayByUnionPayResponse, INgeniusPayByUnionPayPayload>(
      `${this.basepath}/union-pay`,
      payload,
      {
        "axios-retry": {
          retries: 0
        },
        "timeout": 45000
      }
    );
  };
}
