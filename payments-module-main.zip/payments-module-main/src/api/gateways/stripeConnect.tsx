import {
  IStripeConnectCreatePaymentIntentPayload,
  IStripeConnectPayPayload,
  IStripeConnectPayResponse,
  IStripeConnectPaymentIntentResponse,
  IStripeConnectVerifyPayload,
  IStripeConnectVerifyResponse
} from "@/types/api/stripeConnect";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class StripeConnectAPIManager {
  private basepath = "/stripe-connect-gateway";

  public createPaymentIntent = (payload: IStripeConnectCreatePaymentIntentPayload) => {
    return axiosInstance.Post<IStripeConnectPaymentIntentResponse, IStripeConnectCreatePaymentIntentPayload>(
      `${this.basepath}/create-payment-intent`,
      payload
    );
  };

  public pay = (payload: IStripeConnectPayPayload) => {
    return axiosInstance.Post<IStripeConnectPayResponse, IStripeConnectPayPayload>(`${this.basepath}/pay`, payload);
  };

  public verify = (payload: IStripeConnectVerifyPayload) => {
    return axiosInstance.Post<IStripeConnectVerifyResponse, IStripeConnectVerifyPayload>(
      `${this.basepath}/verify`,
      payload
    );
  };
}
