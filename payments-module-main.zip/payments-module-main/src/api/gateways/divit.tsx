import { IDivitPayByFpsPayload, IDivitPayByFpsResponse } from "@/types/api/divit";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class DivitAPIManager {
  private basepath = "/divit-gateway";

  public payByFps = (payload: IDivitPayByFpsPayload) => {
    return axiosInstance.Post<IDivitPayByFpsResponse, IDivitPayByFpsPayload>(
      `${this.basepath}/initiate-payment`,
      payload,
      {
        "axios-retry": {
          retries: 0
        },
        "timeout": 45000
      }
    );
  };
}
