import { IPaymentDetails, IValidateApplePaySessionPayload, IValidateApplePaySessionResponse } from "@/types/api/common";
import {
  IVostroPayByApplePayload,
  IVostroPayByDebitPayload,
  IVostroPayByDebitResponse,
  IVostroPayByGooglePayload
} from "@/types/api/vostro";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class VostroAPIManager {
  private basepath = "/vostro-gateway";

  public pay = (payload: IVostroPayByDebitPayload) => {
    return axiosInstance.Post<IVostroPayByDebitResponse, IVostroPayByDebitPayload>(`${this.basepath}/debit`, payload, {
      timeout: 30000
    });
  };

  public validateApplePaySession = (payload: IValidateApplePaySessionPayload) => {
    return axiosInstance.Post<IValidateApplePaySessionResponse, IValidateApplePaySessionPayload>(
      `${this.basepath}/apple-pay/validate`,
      payload
    );
  };

  public payByApple = (payload: IVostroPayByApplePayload) => {
    return axiosInstance.Post<IPaymentDetails, IVostroPayByApplePayload>(`${this.basepath}/apple-pay`, payload);
  };

  public payByGoogle = (payload: IVostroPayByGooglePayload) => {
    return axiosInstance.Post<IPaymentDetails, IVostroPayByGooglePayload>(`${this.basepath}/google-pay`, payload);
  };
}
