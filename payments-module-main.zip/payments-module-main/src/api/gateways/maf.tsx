import { IValidateApplePaySessionPayload, IValidateApplePaySessionResponse } from "@/types/api/common";
import {
  IMafV2ApplePayDetails,
  IMafV2PayByApplePayload,
  IMafV2PayByGooglePayResponse,
  IMafV2PayByGooglePayload,
  IMafV2PaymentPayload,
  IMafV2PaymentResponse,
  IVerifyMafV2Payload,
  IVerifyMafV2Response
} from "@/types/api/maf";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class MaffAPIManager {
  private basepath = "/maf-gateway-v2";

  public pay = (payload: IMafV2PaymentPayload) => {
    return axiosInstance.Post<IMafV2PaymentResponse, IMafV2PaymentPayload>(`${this.basepath}/payment`, payload);
  };

  public payByGoogle = (payload: IMafV2PayByGooglePayload) => {
    return axiosInstance.Post<IMafV2PayByGooglePayResponse, IMafV2PayByGooglePayload>(
      `${this.basepath}/google-pay`,
      payload
    );
  };

  public verifyPayment = (payload: IVerifyMafV2Payload) => {
    return axiosInstance.Post<IVerifyMafV2Response, IVerifyMafV2Payload>(`${this.basepath}/verify`, payload);
  };

  public validateApplePaySession = (payload: IValidateApplePaySessionPayload) => {
    return axiosInstance.Post<IValidateApplePaySessionResponse, IValidateApplePaySessionPayload>(
      `${this.basepath}/apple-pay/validate`,
      payload
    );
  };

  public payByApple = (payload: IMafV2PayByApplePayload) => {
    return axiosInstance.Post<IMafV2ApplePayDetails, IMafV2PayByApplePayload>(`${this.basepath}/apple-pay`, payload);
  };
}
