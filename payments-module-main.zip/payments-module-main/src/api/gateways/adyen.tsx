import {
  IAdyenDetails,
  IAdyenPayByApplePayload,
  IAdyenPayByCardPayload,
  IAdyenPayByCardResponse,
  IAdyenPayByGooglePayload
} from "@/types/api/adyen";
import { IValidateApplePaySessionPayload, IValidateApplePaySessionResponse } from "@/types/api/common";
import axiosInstance from "@clubpay/customer-common-module/src/repository/axios";

export default class AdyenAPIManager {
  private basepath = "/adyen-gateway";

  public payByCard = (payload: IAdyenPayByCardPayload) => {
    return axiosInstance.Post<IAdyenPayByCardResponse, IAdyenPayByCardPayload>(`${this.basepath}/pay`, payload, {
      "axios-retry": {
        retries: 0
      },
      "timeout": 45000
    });
  };

  public payByApple = (payload: IAdyenPayByApplePayload) => {
    return axiosInstance.Post<IAdyenDetails, IAdyenPayByApplePayload>(`${this.basepath}/pay`, payload, {
      "axios-retry": {
        retries: 0
      },
      "timeout": 45000
    });
  };

  public payByGoogle = (payload: IAdyenPayByGooglePayload) => {
    return axiosInstance.Post<IAdyenDetails, IAdyenPayByGooglePayload>(`${this.basepath}/pay`, payload, {
      "axios-retry": {
        retries: 0
      },
      "timeout": 45000
    });
  };

  public validateApplePaySession = (payload: IValidateApplePaySessionPayload) => {
    return axiosInstance.Post<IValidateApplePaySessionResponse, IValidateApplePaySessionPayload>(
      `${this.basepath}/apple-pay/validate`,
      payload
    );
  };
}
