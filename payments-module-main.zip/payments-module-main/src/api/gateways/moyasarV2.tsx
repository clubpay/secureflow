import {
  IMoyasarV2Details,
  IMoyasarV2InitateRequestPayload,
  IMoyasarV2PayByApplePayload,
  IMoyasarV2ValidateApplePayload
} from "@/types/api/moyasarV2";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class MoyasarV2APIManager {
  private basepath = "/moyasarv2-gateway";

  public payByApple = (payload: IMoyasarV2PayByApplePayload) => {
    return axiosInstance.Post<IMoyasarV2Details, IMoyasarV2PayByApplePayload>(`${this.basepath}/apple-pay`, payload, {
      "axios-retry": {
        retries: 0
      },
      "timeout": 45000
    });
  };

  public validateApplePaySession = (payload: IMoyasarV2ValidateApplePayload) => {
    return axiosInstance.Post<any, IMoyasarV2ValidateApplePayload>(
      `https://api.moyasar.com/v1/applepay/initiate`,
      payload
    );
  };

  public initiatePayment = (payload: any) => {
    return axiosInstance.Post<any, IMoyasarV2InitateRequestPayload>(`${this.basepath}/initiate-payment`, payload);
  };

  public payByStcPay = (payload: any) => {
    return axiosInstance.Post<any, any>(`${this.basepath}/stc-pay`, payload);
  };
  public payBySTCPayCapture = (payload: any) => {
    return axiosInstance.Post<any, any>(`${this.basepath}/stc-pay-capture`, payload);
  };
}
