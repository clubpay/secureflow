import {
  IStripeCreatePaymentIntentPayload,
  IStripePayPayload,
  IStripePayResponse,
  IStripePaymentIntentResponse,
  IStripeVerifyPayload,
  IStripeVerifyResponse
} from "@/types/api/stripe";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class StripeAPIManager {
  private basepath = "/stripe-gateway";

  public createPaymentIntent = (payload: IStripeCreatePaymentIntentPayload) => {
    return axiosInstance.Post<IStripePaymentIntentResponse, IStripeCreatePaymentIntentPayload>(
      `${this.basepath}/create-payment-intent`,
      payload
    );
  };

  public pay = (payload: IStripePayPayload) => {
    return axiosInstance.Post<IStripePayResponse, IStripePayPayload>(`${this.basepath}/pay`, payload);
  };

  public verify = (payload: IStripeVerifyPayload) => {
    return axiosInstance.Post<IStripeVerifyResponse, IStripeVerifyPayload>(`${this.basepath}/verify`, payload);
  };
}
