import { ISMBCLinkRequestPayload, ISMBCLinkRequestResponse } from "@/types/api/smbc";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class SMBCAPIManager {
  private basepath = "/smbc";

  public generateLink = (payload: ISMBCLinkRequestPayload) => {
    return axiosInstance.Post<ISMBCLinkRequestResponse, ISMBCLinkRequestPayload>(
      `${this.basepath}/generate-link`,
      payload
    );
  };
}
