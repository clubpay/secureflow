import { ITicketPGGenerateLinkPayload, ITicketPGGenerateLinkResponse } from "@/types/api/ticket";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";

export default class TicketAPIManager {
  private basepath = "/ticket-gateway";

  public generateLink = (payload: ITicketPGGenerateLinkPayload) => {
    return axiosInstance.Post<ITicketPGGenerateLinkResponse, ITicketPGGenerateLinkPayload>(
      `${this.basepath}/generate-link`,
      payload
    );
  };
}
