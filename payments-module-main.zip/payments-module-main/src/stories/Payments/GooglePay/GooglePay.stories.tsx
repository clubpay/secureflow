import type { Meta, StoryObj } from "@storybook/react";
import GooglePay from "@/components/PaymentMethods/GooglePay";

const meta: Meta<typeof GooglePay> = {
  title: "Payments/Payment Methods/Google Pay",
  component: GooglePay,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;
type Story = StoryObj<typeof GooglePay>;

export const Pay: Story = {
  render: (props) => <GooglePay {...props} />
};
