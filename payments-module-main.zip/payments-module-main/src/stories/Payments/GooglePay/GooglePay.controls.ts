export default {
  googleMerchantId: {
    description: "Google Merchant ID",
    control: { type: "text" }
  },
  googleAllowedCardNetworks: {
    description: "Supported google card networks",
    control: { type: "object" }
  },
  googleAllowedAuthMethods: {
    description: "Supported google auth methods",
    control: { type: "object" }
  },
  merchantCapabilities: {
    description: "Supported merchant capabilities",
    control: { type: "object" }
  }
};
