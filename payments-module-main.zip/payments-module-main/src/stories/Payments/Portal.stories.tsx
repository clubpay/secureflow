import type { Meta, StoryObj } from "@storybook/react";
import { default as PaymentPortal } from "@/components/PaymentPortal";
import { pgConfig as checkoutPGConfig } from "./CardPay/Gateways/Checkout/Checkout.controls";
import { default as portalArgTypes } from "./CardPay/Portal.controls";
import { default as argTypes } from "./Portal.controls";

const meta: Meta<typeof PaymentPortal> = {
  title: "Payments/Payment Portal",
  component: PaymentPortal,
  parameters: {
    layout: "centered",
    controls: { exclude: ["pg"], sort: "alpha" }
  },
  tags: ["autodocs"],
  argTypes: {
    ...argTypes,
    ...portalArgTypes
  },
  args: {
    pg: checkoutPGConfig
  }
};

export default meta;

type Story = StoryObj<typeof PaymentPortal>;

export const Defaults: Story = {
  render: (props) => <PaymentPortal {...props} />
};
