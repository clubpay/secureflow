import { prefixKeys } from "@/utils";

export default {
  ...prefixKeys(
    {
      elements: {
        description: "Array of required payment elements in the order they should appear",
        control: { type: "object" },
        table: {
          defaultValue: { summary: ["applepay", "googlepay", "card"] }
        }
      }
    },
    "pg.config."
  )
};
