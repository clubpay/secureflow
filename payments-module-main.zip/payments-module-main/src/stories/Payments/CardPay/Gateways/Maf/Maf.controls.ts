export default {
  "apiKey": {
    description: "MAF API key",
    control: { type: "text" }
  },
  "no3ds": {
    description: "Whether to disable 3DS",
    control: { type: "boolean" }
  },
  "3dsThreshold": {
    description: "3DS threshold",
    control: { type: "number" }
  },
  "gateway": {
    description: "Gateway",
    control: { type: "text" }
  },
  "gatewayMerchantId": {
    description: "Gateway merchant ID",
    control: { type: "text" }
  },
  "merchantID": {
    description: "Merchant ID",
    control: { type: "text" }
  },
  "merchantIdentifier": {
    description: "Merchant identifier",
    control: { type: "text" }
  },
  "showDescriptor": {
    description: "Whether to show statement descriptor",
    control: { type: "boolean" }
  }
};
