import type { Meta, StoryObj } from "@storybook/react";
import { MafCardPayment } from "@/components/PaymentMethods/Card/Gateways";
import argTypes from "../../Portal.controls";

const meta: Meta<typeof MafCardPayment> = {
  title: "Payments/Payment Methods/Card Pay/Gateways/Maf",
  component: MafCardPayment,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"],
  argTypes: argTypes
};

export default meta;

type Story = StoryObj<typeof MafCardPayment>;

export const Pay: Story = {
  render: (props) => <MafCardPayment {...props} />
};
