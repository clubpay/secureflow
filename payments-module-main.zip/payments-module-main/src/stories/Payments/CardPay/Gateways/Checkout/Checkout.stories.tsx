import type { Meta, StoryObj } from "@storybook/react";
import { CheckoutCardPayment } from "@/components/PaymentMethods/Card/Gateways";
import argTypes from "../../Portal.controls";
import { pgConfig } from "./Checkout.controls";

const meta: Meta<typeof CheckoutCardPayment> = {
  title: "Payments/Payment Methods/Card Pay/Gateways/Checkout",
  component: CheckoutCardPayment,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"],
  argTypes: argTypes,
  args: {
    pg: pgConfig
  }
};

export default meta;

type Story = StoryObj<typeof CheckoutCardPayment>;

export const Pay: Story = {
  render: (props) => <CheckoutCardPayment {...props} />
};
