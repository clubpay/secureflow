import { PaymentGatewayConfig } from "@/types";

export const pgConfig: PaymentGatewayConfig = {
  name: "checkout",
  config: {
    sandbox: true,
    publicKey: "pk_sbox_5x2zxx67mxdoycle67ayefvbny4",
    supportedNetworks: ["visa", "mastercard", "amex", "discover"],
    refundType: "full",
    googleMerchantId: "",
    googleAllowedCardNetworks: ["visa", "mastercard", "amex", "discover"]
  }
};

export default {
  publicKey: {
    description: "Checkout public key",
    control: { type: "text" }
  }
};
