import { Locales, PaymentGateways } from "@/types";
import { prefixAndAddToKeys, prefixKeys } from "@/utils";
import ApplePayControls from "../ApplePay/ApplePay.controls";
import GooglePayControls from "../GooglePay/GooglePay.controls";
import SharedControls from "../Shared.controls";
import CheckoutControls from "./Gateways/Checkout/Checkout.controls";
import MafControls from "./Gateways/Maf/Maf.controls";

export default {
  "amount": {
    description: "Amount to be paid",
    control: { type: "number" },
    table: {
      defaultValue: { summary: 2.0 }
    }
  },
  "currency": {
    description: "Currency to be used",
    control: { type: "text" },
    table: {
      defaultValue: { summary: "AED" }
    }
  },
  "locale": {
    description: "Language to display text with",
    options: Object.values(Locales),
    control: { type: "select" },
    table: {
      defaultValue: { summary: "Browser default" }
    }
  },
  "variant": {
    description: "Design variant to use",
    options: ["primary", "secondary"],
    control: { type: "select" },
    table: {
      defaultValue: { summary: "primary" }
    }
  },
  "enableCardSaving": {
    description: "Whether to enable card saving or not (Only for gateways which support it)",
    control: { type: "boolean" },
    table: {
      defaultValue: { summary: true }
    }
  },
  "tagline": {
    description: "Whether to show the secure payments tagline or not",
    control: { type: "boolean" },
    table: {
      defaultValue: { summary: true }
    }
  },
  "networks": {
    description: "Whether to show the card networks or not",
    control: { type: "boolean" },
    table: {
      defaultValue: { summary: true }
    }
  },
  "paymentTerms.hidden": {
    description: "Whether to hide the payment terms link or not",
    control: { type: "boolean" },
    table: {
      defaultValue: { summary: true }
    }
  },
  "paymentTerms.href": {
    description: "External link to the payment terms",
    control: { type: "text" }
  },
  "pg.name": {
    description: "Payment gateway to use to process the payment",
    options: Object.values(PaymentGateways),
    control: { type: "select" },
    table: {
      defaultValue: { summary: PaymentGateways.Checkout }
    }
  },
  "pg.id": {
    description: "ID of the payment gateway being used",
    control: { type: "text" }
  },
  ...prefixKeys(SharedControls, "pg.config."),
  ...prefixKeys(ApplePayControls, "pg.config."),
  ...prefixKeys(GooglePayControls, "pg.config."),
  ...prefixAndAddToKeys(CheckoutControls, "pg.config.", { if: { arg: "pg.name", neq: PaymentGateways.MAF } }),
  ...prefixAndAddToKeys(MafControls, "pg.config.", { if: { arg: "pg.name", eq: PaymentGateways.MAF } })
};
