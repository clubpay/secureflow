import type { Meta, StoryObj } from "@storybook/react";
import { default as CardPayPortal } from "@/components/PaymentMethods/Card";
import { pgConfig as checkoutPGConfig } from "./Gateways/Checkout/Checkout.controls";
import argTypes from "./Portal.controls";

const meta: Meta<typeof CardPayPortal> = {
  title: "Payments/Payment Methods/Card Pay/Portal",
  component: CardPayPortal,
  parameters: {
    layout: "centered",
    controls: { exclude: ["pg"], sort: "alpha" }
  },
  tags: ["autodocs"],
  argTypes,
  args: {
    pg: checkoutPGConfig
  }
};

export default meta;

type Story = StoryObj<typeof CardPayPortal>;

export const Defaults: Story = {
  render: (props) => <CardPayPortal {...props} />
};
