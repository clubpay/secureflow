export default {
  sandbox: {
    description: "Whether sandbox mode is enabled or not",
    control: { type: "boolean" },
    table: {
      defaultValue: { summary: true }
    }
  },
  supportedNetworks: {
    description: "Supported card networks",
    control: { type: "object" },
    table: {
      defaultValue: { summary: [] }
    }
  },
  refundType: {
    description: "Type of refund supported",
    options: ["full", "partial", "disabled"],
    control: { type: "select" }
  }
};
