import type { Meta, StoryObj } from "@storybook/react";
import ApplePay from "@/components/PaymentMethods/ApplePay";

const meta: Meta<typeof ApplePay> = {
  title: "Payments/Payment Methods/Apple Pay",
  component: ApplePay,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;
type Story = StoryObj<typeof ApplePay>;

export const Pay: Story = {
  render: (props) => <ApplePay {...props} />
};
