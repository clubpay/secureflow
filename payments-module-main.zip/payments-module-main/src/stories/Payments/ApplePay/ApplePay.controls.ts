export default {
  applePayBillingDetails: {
    description: "Whether to collect billing details",
    control: { type: "boolean" }
  },
  applePayShippingDetails: {
    description: "Whether to collect shipping details",
    control: { type: "boolean" }
  }
};
