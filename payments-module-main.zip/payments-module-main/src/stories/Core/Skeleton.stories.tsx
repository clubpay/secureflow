import type { Meta, StoryObj } from "@storybook/react";
import { Skeleton } from "@/components/Core";
import { KeyValue } from "@/types";
import styles from "../../components/PaymentMethods/Card/Layout/Skeleton/skeleton.module.scss";

const argTypes: KeyValue = {
  containerClassName: {
    description:
      "Any additional CSS classes to be passed into the root element. Existing classes will be overwritten in case of conflict",
    type: "string"
  },
  className: {
    description:
      "Any additional CSS classes to be passed into the skeleton element. Existing classes will be overwritten in case of conflict",
    type: "string"
  },
  shade: {
    description: "The shade of the skeleton",
    control: { type: "radio" },
    options: ["light", "dark"],
    table: {
      defaultValue: { summary: "light" }
    }
  },
  count: {
    description: "The number of skeleton items to render",
    type: "number",
    table: {
      defaultValue: { summary: 1 }
    }
  }
};

const meta: Meta<typeof Skeleton> = {
  title: "Core Elements/Skeleton",
  component: Skeleton,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"],
  argTypes
};

export default meta;

type Story = StoryObj<typeof Skeleton>;

export const SingleSkeleton: Story = {
  render: (props) => <Skeleton className={styles.tagline} {...props} />
};

export const MultiLine: Story = {
  render: (props) => <Skeleton className={styles.tagline} count={3} {...props} />
};

export const NestedSkeletons: Story = {
  render: (props) => (
    <Skeleton className={`${styles.container}`} style={{ padding: 20 }} {...props}>
      <Skeleton shade="dark" className={styles.tagline} style={{ width: "30vw" }} />
      <Skeleton shade="dark" className={styles.tagline} style={{ width: "100%" }} />
      <Skeleton shade="dark" className={styles.tagline} style={{ width: "100%" }} />
    </Skeleton>
  )
};
