import type { Meta, StoryObj } from "@storybook/react";
import { Input } from "@/components/Core";
import { KeyValue } from "@/types";

const argTypes: KeyValue = {
  variant: {
    options: ["primary", "secondary"],
    control: { type: "radio" },
    description: "Changes the look of the button",
    table: {
      defaultValue: { summary: "primary" }
    }
  },
  children: {
    description: "Any JSX child / children to be passed into the button"
  },
  className: {
    description:
      "Any additional CSS classes to be passed into the button. Existing classes will be overwritten in case of conflict",
    type: "string"
  },
  overrideStyle: {
    description: "If true, the button will not have any default styling applied to it",
    table: {
      defaultValue: { summary: false }
    },
    type: "boolean"
  },
  loading: {
    description: "If true, the button will be in a loading state",
    table: {
      defaultValue: { summary: false }
    },
    type: "boolean"
  },
  prefixIcon: {
    description: "Any SVG icon to be passed into the button"
  }
};

const meta: Meta<typeof Input> = {
  title: "Core Elements/Input",
  component: Input,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"],
  argTypes
};

export default meta;

type Story = StoryObj<typeof Input>;

export const Defaults: Story = {
  render: ({ placeholder, label, ...props }) => (
    <Input label={label ?? "Card number"} placeholder={placeholder ?? "4242 4242 4242 4242"} {...props} />
  )
};

export const WithError: Story = {
  render: ({ placeholder, label, error, ...props }) => (
    <Input
      label={label ?? "Card number"}
      placeholder={placeholder ?? "4242 4242 4242 4242"}
      error={error ?? "Invalid card number"}
      {...props}
    />
  )
};
