import type { Meta, StoryObj } from "@storybook/react";
import { Checkbox } from "@/components/Core";
import { KeyValue } from "@/types";

const argTypes: KeyValue = {
  variant: {
    options: ["primary", "secondary"],
    control: { type: "radio" },
    description: "Changes the look of the button",
    table: {
      defaultValue: { summary: "primary" }
    }
  },
  className: {
    description:
      "Any additional CSS classes to be passed into the skeleton element. Existing classes will be overwritten in case of conflict",
    type: "string"
  },
  overrideStyle: {
    description: "If true, the button will not have any default styling applied to it",
    table: {
      defaultValue: { summary: false }
    },
    type: "boolean"
  },
  label: {
    description: "The label of the checkbox",
    type: "string"
  },
  onChange: {
    description: "A callback function to be called when the state of the checkbox changes"
  }
};

const meta: Meta<typeof Checkbox> = {
  title: "Core Elements/Checkbox",
  component: Checkbox,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"],
  argTypes
};

export default meta;

type Story = StoryObj<typeof Checkbox>;

export const Defaults: Story = {
  render: ({ label, ...props }) => <Checkbox label={label ?? "Click me"} {...props} />
};
