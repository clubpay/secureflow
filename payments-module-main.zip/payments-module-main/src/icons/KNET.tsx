export default () => {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="12" r="12" fill="#0872B9" />
      <path d="M9.68436 9H4.5V15.4H9.68436V9Z" fill="#FBED1F" />
      <path
        d="M9.50555 11.8386L13.3491 9.05151H20.1871L16.4329 11.8386L20.5 15.2967H13.1704L9.59494 12.0967L9.50555 11.8386Z"
        fill="#FBED1F"
      />
    </svg>
  );
};
