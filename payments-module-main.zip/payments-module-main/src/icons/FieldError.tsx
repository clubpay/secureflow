import { IconProps } from "@/types/icon";

export default (props: IconProps) => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" viewBox="0 0 16 16" {...props}>
      <path
        fill="#D10244"
        fillRule="evenodd"
        d="M15 8a7.07 7.07 0 0 1-7 7 7.07 7.07 0 0 1-7-7 7.07 7.07 0 0 1 7-7 7.07 7.07 0 0 1 7 7Z"
        clipRule="evenodd"
      />
      <path
        fill="#fff"
        fillRule="evenodd"
        d="M10.85 5.86a.5.5 0 0 0-.71-.71L8 7.29 5.86 5.15a.5.5 0 1 0-.71.71L7.29 8l-2.14 2.14a.5.5 0 0 0 .71.71L8 8.71l2.14 2.14a.5.5 0 0 0 .71-.71L8.71 8l2.14-2.14Z"
        clipRule="evenodd"
      />
    </svg>
  );
};
