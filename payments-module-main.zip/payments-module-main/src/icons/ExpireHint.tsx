import { IconProps } from "@/types/icon";

export default (props: IconProps) => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="16" viewBox="0 0 24 16" fill="none" {...props}>
      <path
        d="M0 3C0 1.34315 1.34315 0 3 0H21C22.6569 0 24 1.34315 24 3V13C24 14.6569 22.6569 16 21 16H3C1.34315 16 0 14.6569 0 13V3Z"
        fill="#E5E5EA"
      />
      <rect x="3" y="8" width="18" height="2" rx="0.5" fill="#C7C7CC" />
      <rect x="3" y="3" width="3" height="3" rx="0.5" fill="white" />
      <rect x="11.5" y="10.5" width="6" height="4" rx="2" stroke="#FF3B30" />
    </svg>
  );
};
