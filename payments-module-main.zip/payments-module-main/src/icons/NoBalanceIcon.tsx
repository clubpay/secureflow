import { IconProps } from "@/types/icon";

export default (props: IconProps) => {
  return (
    <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="48" height="48" rx="24" fill="white" />
      <rect width="48" height="48" rx="24" fill="#DF1D17" fill-opacity="0.08" />
      <path d="M12 18.6667H36" stroke="#DF1D17" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
      <path d="M19.9987 24H17.332" stroke="#DF1D17" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
      <path
        d="M25.3333 32H16C13.7909 32 12 30.2091 12 28V17.3333C12 15.1242 13.7909 13.3333 16 13.3333H32C34.2091 13.3333 36 15.1242 36 17.3333V24"
        stroke="#DF1D17"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M30.668 30.6667L34.668 34.6667"
        stroke="#DF1D17"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <path
        d="M34.668 30.6667L30.668 34.6667"
        stroke="#DF1D17"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </svg>
  );
};
