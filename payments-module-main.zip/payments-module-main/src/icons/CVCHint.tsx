import { IconProps } from "@/types/icon";

export default (props: IconProps) => {
  return (
    <svg
      width="27"
      height="18"
      viewBox="0 0 27 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="false"
      {...props}
    >
      <path
        d="M27 4v-.625A3.375 3.375 0 0 0 23.625 0H3.375A3.375 3.375 0 0 0 0 3.375V4h27ZM0 7v7.667c0 .884.356 1.731.989 2.357A3.397 3.397 0 0 0 3.375 18h20.25c.895 0 1.754-.351 2.387-.976A3.313 3.313 0 0 0 27 14.667V7H0Z"
        fill="#E6E9EB"
      />
      <path fill="#687282" d="M0 4h27v3H0z" />
      <path d="M4 11a1 1 0 0 1 1-1h16a2 2 0 1 1 0 4H5a1 1 0 0 1-1-1v-2Z" fill="#fff" />
      <rect x="16.5" y="9.5" width="7" height="5" rx="2.5" stroke="#C12424" />
    </svg>
  );
};
