import { useEffect, useState } from "react";
import PaymentAPIManager from "@/api/gateways";
import { PaymentOptions } from "@/types";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";

export interface ICheckoutCard {
  data?: {
    bin: string;
    isMada: boolean;
    last4: string;
    scheme: string;
    sourceId: string;
  };
}

const useSavedCards = (props: PaymentOptions) => {
  const { isLogin } = useAuth();
  const [savedCards, setSavedCards] = useState<any>("");
  const [selectedCard, setSelectedCard] = useState<any>(false);
  const api = props.pg.config.apiManager ?? PaymentAPIManager.getInstance();

  const fetchCheckoutCards = async () => {
    try {
      const res: ICheckoutCard = await api.checkout.getSavedCardDetails();
      setSavedCards(res?.data || null);
      setSelectedCard(!!res?.data);
    } catch (e: any) {
      setSavedCards(null);
      setSelectedCard(false);
    }
  };

  const handleSelectCard = (token: string | number | null) => {
    if (savedCards?.length)
      setSavedCards(
        (prevState: any[]) =>
          prevState?.map((card: any) => ({
            ...card,
            selected: card?.selected ? false : card.token === token
          }))
      );
  };

  useEffect(() => {
    if (savedCards) {
      if (Array.isArray(savedCards)) {
        setSelectedCard(savedCards?.find((card: any) => card?.selected) || false);
      } else {
        setSelectedCard(savedCards);
      }
    } else {
      savedCards !== "" && setSelectedCard(false);
    }
  }, [savedCards]);

  useEffect(() => {
    switch (props.pg.name) {
      case "checkout":
        if (!props.isSubscriptionPayment) fetchCheckoutCards();
        break;
      case "maf":
      case "mafv2":
      case "tuna":
        break;
    }
  }, [isLogin]);

  return {
    savedCards,
    setSavedCards,
    setSelectedCard,
    selectedCard,
    handleSelectCard
  };
};

export default useSavedCards;
