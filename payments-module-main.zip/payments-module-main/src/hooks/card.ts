import { useState } from "react";

const madaPrefix = [
  "446404",
  "440795",
  "440647",
  "421141",
  "474491",
  "588845",
  "968208",
  "457997",
  "457865",
  "468540",
  "468541",
  "468542",
  "468543",
  "417633",
  "446393",
  "636120",
  "968201",
  "410621",
  "409201",
  "403024",
  "458456",
  "462220",
  "968205",
  "455708",
  "484783",
  "588848",
  "455036",
  "968203",
  "486094",
  "486095",
  "486096",
  "504300",
  "440533",
  "489318",
  "489319",
  "445564",
  "968211",
  "410685",
  "406996",
  "432328",
  "428671",
  "428672",
  "428673",
  "968206",
  "446672",
  "543357",
  "434107",
  "407197",
  "407395",
  "412565",
  "431361",
  "604906",
  "521076",
  "588850",
  "968202",
  "529415",
  "535825",
  "543085",
  "524130",
  "554180",
  "549760",
  "968209",
  "524514",
  "529741",
  "537767",
  "535989",
  "536023",
  "513213",
  "520058",
  "558563",
  "585265",
  "588983",
  "588982",
  "589005",
  "508160",
  "531095",
  "530906",
  "532013",
  "605141",
  "968204",
  "422817",
  "422818",
  "422819",
  "428331",
  "483010",
  "483011",
  "483012",
  "589206",
  "968207",
  "419593",
  "439954",
  "530060",
  "531196",
  "420132",
  "506968",
  "406136",
  "42689700",
  "43382999"
];

const useCard = () => {
  const [number, setNumber] = useState({ error: null, value: null });
  const [expiry, setExpiry] = useState({ error: null, value: null });
  const [securityCode, setSecurityCode] = useState({ error: null, value: null });
  const [scheme, setScheme] = useState(null);
  const [issuerCountry, setIssuerCountry] = useState(null);
  const [bin, setBin] = useState<string | undefined>();

  const reset = () => {
    setNumber({ error: null, value: null });
    setExpiry({ error: null, value: null });
    setSecurityCode({ error: null, value: null });
    setScheme(null);
    setIssuerCountry(null);
    setBin(undefined);
  };

  const isCardMada = (cardNumber?: string) => {
    if (!cardNumber) return false;
    const cn = cardNumber.substr(0, 6);
    return madaPrefix.some((prefix) => {
      if (prefix.length === 6) {
        return prefix === cn;
      }
      return cardNumber.indexOf(prefix) === 0;
    });
  };

  return {
    isCardMada: () => isCardMada(bin),
    cardNumber: number,
    expiryDate: expiry,
    securityCode,
    scheme,
    issuerCountry,
    bin,
    setCardNumber: setNumber,
    setExpiryDate: setExpiry,
    setSecurityCode,
    setScheme,
    setIssuerCountry,
    setBin,
    reset
  };
};

export default useCard;
