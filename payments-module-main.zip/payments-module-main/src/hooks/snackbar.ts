import { useEffect } from "react";
import { ISnackBar } from "@/types/payments/plugins";

declare global {
  interface Window {
    snackbar: ISnackBar;
  }
}

const useSnackbar = (snackbar?: ISnackBar) => {
  useEffect(() => {
    if (window.snackbar) return;
    snackbar ??= {
      enqueue: window.alert,
      close: () => {}
    };
    window.snackbar = snackbar;
  }, []);
};

export default useSnackbar;
