import { useEffect } from "react";
import BillAPIManager from "@/api/general/bill";
import { Button } from "@/components/Core";
import { t as t2 } from "@/locales";
import { useCommonStore } from "@/stores/commonStore";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import useToast from "./toast";

const useLockUnlock = (props: any) => {
  const { displayMessage } = useToast();
  const billAPI = BillAPIManager.getInstance();

  const {
    state: { isLocked, lockedTime },
    lock,
    unlock
  } = useCommonStore((state) => state);

  const performLock = async (event: any, duration?: number) => {
    let isEligibleToProceed = false;

    if (!event) return isEligibleToProceed;

    try {
      lock(duration);
      const lockRes = await billAPI.lockPayment({
        id: getSession(),
        diningSessionID: props.qlub?.diningSessionId,
        gatewayID: props.pg.id
      });

      switch (lockRes?.state) {
        case "acquired":
          if (lockRes?.sessions?.length) {
            if (lockRes?.sessions?.[0]?.status === "accepted") {
              unlock();
              displayMessage(t2("You already paid"), "info", {
                actionButton: (
                  <Button
                    onClick={() => {
                      const item = lockRes.sessions[lockRes.sessions.length - 1];
                      if (item) {
                        props.pg?.config?.events?.onPaymentSuccess?.({
                          amount: Number(item.billAmount),
                          method: props?.pg?.name,
                          paymentElement: event.paymentElement || PaymentElementEnum.None,
                          refId: item.reference,
                          tip: item.tipAmount
                        });
                      }
                    }}
                    variant="text"
                    style={{ background: "transparent", border: "none", color: "#fff", cursor: "pointer" }}
                  >
                    {t2("Invoice")}
                  </Button>
                )
              });
            } else if (lockRes?.sessions?.[0]?.status === "initiated") {
              unlock();
              displayMessage(t2("Your payment already in progress. Please wait some time"), "info", {
                actionButton: (
                  <Button
                    onClick={() => {
                      const item = lockRes.sessions[lockRes.sessions.length - 1];
                      if (item) {
                        props.pg?.config?.events?.onPaymentPending?.({
                          paymentElement: event.paymentElement || PaymentElementEnum.None,
                          refId: item.reference
                        });
                      }
                    }}
                    variant="text"
                    style={{ background: "transparent", border: "none", color: "#fff", cursor: "pointer" }}
                  >
                    {t2("Check status")}
                  </Button>
                )
              });
            }
          } else {
            isEligibleToProceed = true;
          }
          break;
        case "failedFull":
          unlock();
          displayMessage(t2("Your payment didn't go through, The bill might already be fully paid"), "warning");
          break;

        case "failedPartial":
          unlock();
          displayMessage(
            t2(
              "Your payment didn't go through, Overpayment might happen due to another transaction occurring for this bill"
            ),
            "warning"
          );
          break;
        case "orderClosed":
          unlock();
          displayMessage(
            t2("Oops! It looks like this order has already been closed. Please check with the staff."),
            "warning"
          );
      }
    } catch (error: any) {
      unlock();
      console.log("error@performLock", error);
    } finally {
      return isEligibleToProceed;
    }
  };

  const performUnlock = async (payload?: any) => {
    unlock();
    try {
      const unlockRes = await billAPI.unlockPayment({
        id: getSession(),
        diningSessionID: props.qlub?.diningSessionId,
        gatewayID: props.pg.id
      });
      return unlockRes?.result;
    } catch (error: any) {
      console.log("error@performUnlock", error);
    }
  };

  useEffect(() => {
    let timeoutId: string | number | NodeJS.Timeout | undefined;
    if (isLocked) {
      timeoutId = setTimeout(() => {
        console.log("unlock getting called");
        unlock();
      }, lockedTime ?? 5000);
    }

    return () => clearTimeout(timeoutId);
  }, [isLocked]);

  return {
    lock: performLock,
    unlock: performUnlock
  };
};

export default useLockUnlock;
