import { RefObject, useEffect, useRef, useState } from "react";

type Props = {
  onLoad: () => void;
  containerRef: RefObject<HTMLDivElement>;
  sandbox: boolean;
};

export const useScript = ({ onLoad, containerRef, sandbox }: Props) => {
  const [loadingSdk, setLoadingSdk] = useState(true);
  const isContainerInViewport = useRef(false);

  const loadSdk = async () => {
    setLoadingSdk(true);

    const currentScript = document.getElementById("n-genius-script");
    currentScript?.remove();

    /** remove mounted card component to avoid duplicate */
    const nGeniusContainer = document.getElementById("ngenius-container");
    if (nGeniusContainer?.firstElementChild) nGeniusContainer?.removeChild(nGeniusContainer?.firstElementChild);

    delete window.NI;
    const script = document.createElement("script");

    script.id = "n-genius-script";
    script.src = sandbox
      ? "https://paypage.sandbox.ngenius-payments.com/hosted-sessions/sdk.js"
      : "https://paypage.ngenius-payments.com/hosted-sessions/sdk.js";
    script.async = true;
    script.onload = onLoad;
    document.body.appendChild(script);
  };

  useEffect(() => {
    /** reload sdk when user scroll down to the payment section */
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          loadSdk();
          isContainerInViewport.current = true;
        } else {
          isContainerInViewport.current = false;
        }
      });
    });

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => {
      if (containerRef.current) {
        observer.unobserve(containerRef.current);
      }
    };
  }, []);

  return {
    loadSdk,
    loadingSdk,
    setLoadingSdk
  };
};
