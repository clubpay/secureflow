import { useEffect } from "react";
import isEmpty from "lodash/isEmpty";
import isUndefined from "lodash/isUndefined";
import { Button } from "@/components/Core";
import ExchangeAlert from "@/components/Global/ExchangeAlert";
import storage from "@/constants/storage";
import CurrecyExchange from "@/icons/CurrecyExchange";
import { t as t2 } from "@/locales";
import { setForex, useForexStore } from "@/stores/forexStore";
import { usePGGroupStore } from "@/stores/pgGroupStore";
import { useToastStore } from "@/stores/toastStore";
import { ICheckoutPayByTokenResponse } from "@/types/api/checkout";
import { IMoneyhashCardPayResponse } from "@/types/api/moneyhash";
import { getPaymentGoogleEventArgs } from "@/utils/events";
import { snackBar } from "@clubpay/customer-common-module/src/hook/snackBar";
import { useTranslation } from "@clubpay/customer-common-module/src/hook/translations";
import { onPushEvent } from "@clubpay/customer-common-module/src/lib/gtm";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { qlubSessionStorage } from "@clubpay/customer-common-module/src/service/storage/sessionStorage";
import { sumAmounts } from "@clubpay/customer-common-module/src/utility/k_math";
import { PaymentGatewayConfig, PaymentOptions, getPaymentMethodOrder } from "..";
import { getExchangeInterruptionMessage } from "../utils/payments/exchange";

type Parameters = {
  paymentOptions: PaymentOptions;
  paymentMethod: PaymentElementEnum;
};

type TriggerInterruption = ICheckoutPayByTokenResponse | IMoneyhashCardPayResponse;

export const useExchangeInterruption = ({ paymentOptions, paymentMethod }: Parameters) => {
  const { pg, qlub, amount, totalAmount } = paymentOptions;

  const diningSessionId = qlub?.diningSessionId;
  const currencyPrecision = qlub?.currencyPrecision;
  const tipAmount = qlub?.tip || 0;
  const billAmount = amount || 0;
  const restaurantName = pg.vendor.name;
  const restaurantConfig = pg.vendor.config;
  const currencyCode = pg.vendor?.country?.currencyCode;
  const paymentGateways = pg.vendor.paymentGateways as PaymentGatewayConfig[];
  const pgName = pg.name;
  const pgConfig = pg.config;
  const exchange = qlub.exchange;

  const { triggerSnackBar } = snackBar();
  const { t } = useTranslation("common");
  const { setDefaultPGData, removePGMethod } = usePGGroupStore();
  const { setOpen, setToastContent } = useToastStore((state) => state);

  const forex = useForexStore();

  const triggerInterruption = (args: TriggerInterruption) => {
    const { exchangeData, routingApplied } = args;
    const { newCurrencyCode, exchangeRate, unsupportedCurrency } = exchangeData!;

    const shouldPopupTrigger =
      (restaurantConfig.forexUI === "v2" || typeof restaurantConfig.forexUI === "undefined") &&
      pg.config.extraConfig?.enableForexToast;

    if (pgConfig.limitForex) {
      sessionStorage.setItem(storage.LIMIT_FOREX, "true");
    }

    /** update exchange rate in the customer app */
    pgConfig.events.onExchangeChange?.({
      currencyCode: newCurrencyCode,
      isApplied: !unsupportedCurrency || (unsupportedCurrency && pgConfig.preselectUSDFallback),
      total: 0,
      ratio: Number(exchangeRate),
      paymentMethod,
      isRoutingApplied: routingApplied,
      isInterrupted: true
    });

    /** update forex data for the payment link */
    setForex({
      currencyCode: newCurrencyCode,
      vendorCurrencyCode: currencyCode,
      isApplied: !unsupportedCurrency || (!!unsupportedCurrency && pgConfig.preselectUSDFallback),
      isInterrupted: true,
      exchangeRate: Number(exchangeRate),
      paymentMethod,
      isRoutingApplied: routingApplied,
      paymentMethodOrder: getPaymentMethodOrder(paymentMethod, pg.config, pg.name)
    });

    /** if routingApplied, don't switch the pg */
    if (pgConfig.forexPgReallocationSupportedPaymentMethods?.includes(paymentMethod) && !routingApplied) {
      const forexRetryingPg = paymentGateways.find((p) => !isEmpty(p.config?.forexRetryingPaymentMethods));
      setDefaultPGData({ pgId: forexRetryingPg?.id, paymentMethod });

      pgConfig.forexPgReallocationSupportedPaymentMethods?.forEach((pm) =>
        removePGMethod({ pgId: pg.id, paymentMethod: pm })
      );
    }

    if (!shouldPopupTrigger) {
      const toastMessage = unsupportedCurrency
        ? t("Please retry payment")
        : t(getExchangeInterruptionMessage(restaurantConfig), {
            currencyCode: newCurrencyCode?.toUpperCase()
          });

      triggerSnackBar(toastMessage, {
        content: (key, message) => <ExchangeAlert id={key} message={message} />
      });
    } else {
      setToastContent({
        title: "",
        description: t2("Foreign card detected, please retry payment"),
        icon: <CurrecyExchange />,
        actionButton: <Button onClick={() => setOpen(false)}>{t2("Retry payment")}</Button>
      });
      setOpen(true);
    }

    onPushEvent("payment_interrupted", {
      pg_name: pgName,
      restaurant_name: restaurantName,
      diningSessionId,
      ...getPaymentGoogleEventArgs(pg.id)
    });

    if (window.clarity) window.clarity("set", "isExchangeInterrupted", "true");

    qlubSessionStorage.set(storage.IS_FOREX_INTERRUPTED, "true");

    if (pgConfig.limitForex) {
      /** timeout is added to avoid the checkout payment
       *  element unmounting when switching pgs
       **/
      setTimeout(() => {
        sessionStorage.setItem(storage.LIMIT_FOREX, "true");
      }, 3000);
    }
  };

  useEffect(() => {
    setForex({
      total: isUndefined(totalAmount)
        ? sumAmounts(currencyPrecision, billAmount * forex.exchangeRate, tipAmount * forex.exchangeRate)
        : sumAmounts(currencyPrecision, totalAmount * forex.exchangeRate),
      tip: sumAmounts(currencyPrecision, tipAmount * forex.exchangeRate)
    });
  }, [forex.exchangeRate, billAmount, tipAmount, totalAmount]);

  useEffect(() => {
    if (exchange?.isApplied) qlubSessionStorage.set(storage.IS_FOREX_USED, "true");
    else qlubSessionStorage.remove(storage.IS_FOREX_USED);
  }, [exchange]);

  return { triggerInterruption };
};
