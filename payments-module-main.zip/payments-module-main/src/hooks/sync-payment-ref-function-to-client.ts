import { useEffect } from "react";
import { usePGGroupStore } from "@/stores/pgGroupStore";

const usePaymentRefFunctionToClient = (onChange: any) => {
  const { state } = usePGGroupStore((state) => state);

  useEffect(() => {
    if (state.pgGroupInteractionData.currentSelected) {
      const pgData = state.pgGroupInteractionData.currentSelected;

      const paymentFn = state.pgMethodsReferenceHolder[pgData]?.method;

      paymentFn && onChange({ fn: paymentFn, name: state.pgGroupInteractionData.currentSelectedPGName });
    }
  }, [state.pgGroupInteractionData.currentSelected, state.pgMethodsReferenceHolder]);
  return null;
};

export default usePaymentRefFunctionToClient;
