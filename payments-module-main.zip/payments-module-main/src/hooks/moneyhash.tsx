import { useEffect, useRef, useState } from "react";
import forEach from "lodash/forEach";
import { Button } from "@/components/Core";
import { isAmexCard } from "@/components/PaymentMethods/Card/Gateways/Checkout/Checkout.util";
import Input from "@/components/PaymentMethods/Card/Gateways/Moneyhash/Input";
import styles from "@/components/PaymentMethods/Card/Gateways/Moneyhash/Moneyhash.module.scss";
import { CVCHint, ExpireHint, NoCard } from "@/icons";
import { t } from "@/locales";
import { useToastStore } from "@/stores/toastStore";
import { MoneyhashConfig } from "@/types/payments/config/moneyhash";
import { mapErrors } from "@/utils/payments/errors";
import { AmericanExpressLogoIcon } from "@clubpay/customer-common-module/src/component/SVG";
import { qlubLocalStorage } from "@clubpay/customer-common-module/src/service/storage/localStorage";
import MoneyHash, { CardData, Element, IntentState, PaymentIntentEventOptions } from "@moneyhash/js-sdk/headless";

type SubmitCardType = {
  cardData?: CardData;
  validationError?: any;
};

type Options = {
  pgConfig: MoneyhashConfig;
  onComplete: (e: PaymentIntentEventOptions) => void;
  onFail: (e: PaymentIntentEventOptions) => void;
};

export const useMoneyhashElements = ({ pgConfig, onComplete, onFail }: Options) => {
  const { publicApiKey, flowId, disableAmexCard } = pgConfig;
  const [errors, setErrors] = useState({ cardNumber: "", expiryMonth: "", expiryYear: "", cvv: "" });

  const elements = useRef<{
    cardNumber: Element | null;
    expiryMonth: Element | null;
    expiryYear: Element | null;
    cvv: Element | null;
  }>({ cardNumber: null, expiryMonth: null, expiryYear: null, cvv: null });

  const [moneyhash, setMoneyhash] = useState<MoneyHash<"payment">>();

  const { setToastContent, setOpen } = useToastStore();

  const cardNumber = () => (
    <Input id="card-number" label={t("Card number")} error={t(mapErrors(errors.cardNumber))} icon={<NoCard />} />
  );
  const expiryMonth = () => (
    <Input id="expiry-month" label={t("Expiry month")} error={t(mapErrors(errors.expiryMonth))} icon={<ExpireHint />} />
  );
  const expiryYear = () => (
    <Input id="expiry-year" label={t("Expiry year")} error={t(mapErrors(errors.expiryYear))} icon={<ExpireHint />} />
  );
  const cvv = () => <Input id="cvv" label={t("Security code")} error={t(mapErrors(errors.cvv))} icon={<CVCHint />} />;

  const handleBinChange = (bin: number | null) => {
    if (isAmexCard(bin?.toString()) && disableAmexCard) {
      setToastContent({
        title: t("AMEX card detected"),
        description: t("American Express is not supported, please try another card."),
        actionButton: (
          <Button
            onClick={() => {
              setOpen(false);
              elements.current.cardNumber?.clear();
            }}
          >
            {t("Try another card")}
          </Button>
        ),
        icon: <AmericanExpressLogoIcon />
      });
      setOpen(true);
    }
  };

  const submitCard = (): Promise<SubmitCardType> => {
    return new Promise(async (resolve, reject) => {
      try {
        forEach(elements.current, (element) => {
          element?.focus();
          element?.blur();
        });
        const cardData = await moneyhash?.cardForm.collect();
        resolve({ cardData });
      } catch (error: any) {
        if (error.card_number || error.cvv || error.expiry_month || error.expiry_year) {
          setErrors({
            cardNumber: error.card_number,
            expiryMonth: error.expiry_month,
            expiryYear: error.expiry_year,
            cvv: error.cvv
          });
          resolve({ validationError: error });
        } else {
          reject(error);
        }
      }
    });
  };

  const pay = async ({ intentId, cardData }: { intentId: string; cardData: CardData }) => {
    return moneyhash?.cardForm.pay({ intentId, cardData });
  };

  const handle3ds = async (intentId: string, url: string) => {
    return moneyhash?.renderUrl({
      intentId,
      url,
      renderStrategy: "REDIRECT"
    });
  };

  const getBinDetails = async (cardData: CardData) => {
    try {
      const binResponse = await moneyhash?.cardForm.binLookup({
        cardData,
        flowId
      });
      return binResponse;
    } catch (_) {
      return null;
    }
  };

  useEffect(() => {
    const init = async () => {
      const mh = new MoneyHash({
        type: "payment",
        publicApiKey,
        onComplete: (e) => {
          onComplete(e);
        },
        onFail: (e) => {
          onFail(e);
        }
      });

      const isRtl = qlubLocalStorage.get("qlub.user.lang") === "ar";

      setMoneyhash(mh);

      const elementsContext = mh.elements({
        classes: {
          error: styles.error,
          focus: styles.focus
        },
        styles: {
          textAlign: isRtl ? "right" : "left"
        }
      });

      const cardNumber = elementsContext.create({
        elementType: "cardNumber",
        elementOptions: {
          selector: "#card-number",
          placeholder: "1234 1234 1234 1234"
        }
      });
      cardNumber.mount();
      cardNumber.on("error", (e) => setErrors((state) => ({ ...state, cardNumber: e.error ?? "" })));
      cardNumber.on("cardNumberChange", (e) => handleBinChange(e.first6Digits));
      elements.current = { ...elements.current, cardNumber };

      const expiryMonth = elementsContext.create({
        elementType: "cardExpiryMonth",
        elementOptions: {
          selector: "#expiry-month",
          placeholder: "12"
        }
      });
      expiryMonth.mount();
      expiryMonth.on("error", (e) => setErrors((state) => ({ ...state, expiryMonth: e.error ?? "" })));
      elements.current = { ...elements.current, expiryMonth };

      const expiryYear = elementsContext.create({
        elementType: "cardExpiryYear",
        elementOptions: {
          selector: "#expiry-year",
          placeholder: "26"
        }
      });
      expiryYear.mount();
      expiryYear.on("error", (e) => setErrors((state) => ({ ...state, expiryYear: e.error ?? "" })));
      elements.current = { ...elements.current, expiryYear };

      const cvv = elementsContext.create({
        elementType: "cardCvv",
        elementOptions: {
          selector: "#cvv",
          placeholder: "123"
        }
      });
      cvv.mount();
      cvv.on("error", (e) => setErrors((state) => ({ ...state, cvv: e.error ?? "" })));
      elements.current = { ...elements.current, cvv };

      elementsContext.create({
        elementType: "cardHolderName",
        value: "Not Available"
      });
    };

    init();
  }, []);

  return {
    moneyhash,
    cardNumber,
    expiryMonth,
    expiryYear,
    cvv,
    submitCard,
    pay,
    handle3ds,
    getBinDetails
  };
};
