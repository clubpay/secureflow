import { useRef } from "react";
import PaymentAPIManager from "@/api/gateways";
import { useCommonStore } from "@/stores/commonStore";
import { PaymentOptions } from "@/types";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";

const useGooglePay = (props: PaymentOptions) => {
  const { qlub } = props;
  const api = props.pg.config.apiManager ?? PaymentAPIManager.getInstance();
  const gatewayId = props.pg.id;

  const {
    state: { consumer }
  } = useCommonStore((state: any) => state);

  let paymentHandler = null;
  const merchantId = useRef("");
  const gatewayNameRef = useRef("");
  let onPaymentComplete = props.pg.config?.events?.onPaymentSuccess;
  const environmentRef = useRef<any>("");

  switch (props.pg.name) {
    case "checkout":
    case "checkoutltd":
      paymentHandler = api.checkout.payByGoogle;
      gatewayNameRef.current = "checkoutltd";
      merchantId.current = props.pg.config.publicKey || "";
      environmentRef.current = props.pg.config?.extraConfig?.sandbox ? "TEST" : "PRODUCTION";
      break;
    case "maf":
    case "mafv2":
      paymentHandler = api.maf.payByGoogle;
      gatewayNameRef.current = "cybersource";
      merchantId.current = props.pg.config.publicKey || "";
      environmentRef.current = props.pg.config?.extraConfig?.sandbox ? "TEST" : "PRODUCTION";
      break;
    case "tuna":
      paymentHandler = api.tuna.payByGoogle;
      gatewayNameRef.current = props.pg.name;
      merchantId.current = props.pg.config.extraConfig.merchantID || props.pg.config.extraConfig.googleMerchantId || "";
      environmentRef.current = props.pg.config?.extraConfig?.sandbox ? "TEST" : "PRODUCTION";
      break;

    case "ccpp":
      paymentHandler = api.ccpp.payByGoogle;
      gatewayNameRef.current = "2c2p";
      merchantId.current = props.pg.config.publicKey || "";
      environmentRef.current = props.pg.config?.extraConfig?.sandbox ? "TEST" : "PRODUCTION";
      break;
    case "tyro":
      paymentHandler = api.tyro.payByGoogle;
      gatewayNameRef.current = "mpgs";
      merchantId.current = props.pg.config.extraConfig?.merchantId || "";
      environmentRef.current = props.pg.config?.extraConfig?.env === "test" ? "TEST" : "PRODUCTION";
      break;

    case "adyen":
      paymentHandler = api.adyen.payByGoogle;
      gatewayNameRef.current = "adyen";
      onPaymentComplete = props.pg.config?.events?.onPaymentPending;
      merchantId.current = props.pg.config?.extraConfig?.merchantAccount || "";
      environmentRef.current = props.pg.config?.extraConfig?.sandbox ? "TEST" : "PRODUCTION";

      break;
    default:
      paymentHandler = api.checkout.payByGoogle;
      gatewayNameRef.current = "checkoutltd";
      merchantId.current = "";
      environmentRef.current = props.pg.config?.extraConfig?.sandbox ? "TEST" : "PRODUCTION";
  }

  const getPayload = (methodName: string, paymentData: any): any => {
    switch (gatewayNameRef.current) {
      case "checkoutltd":
      case "checkout": {
        switch (methodName) {
          case "handlePay":
            return {
              id: getSession(),
              diningSessionID: qlub?.diningSessionId,
              tipAmount: qlub?.tip?.toFixed(props.qlub?.currencyPrecision || 0) || "0.00",
              googleToken: paymentData.paymentMethodData.tokenizationData.token,
              reference: paymentData.reference,
              gatewayID: gatewayId,
              cardType: paymentData.paymentMethodData.info?.cardNetwork || "",
              successUrl: paymentData.returnUrl.success,
              failureUrl: paymentData.returnUrl.fail
            };
          default:
            return {};
        }
      }

      case "2c2p": {
        switch (methodName) {
          case "handlePay":
            return {
              id: getSession(),
              diningSessionID: qlub?.diningSessionId,
              tipAmount: qlub?.tip?.toFixed(props.qlub?.currencyPrecision || 0) || "0.00",
              googleToken: btoa(JSON.stringify(JSON.parse(paymentData.paymentMethodData.tokenizationData.token))),
              reference: paymentData.reference,
              gatewayID: gatewayId,
              cardType: paymentData.paymentMethodData.info?.cardNetwork || "",
              responseUrl: paymentData.returnUrl.pending
            };
          default:
            return {};
        }
      }

      case "adyen": {
        switch (methodName) {
          case "handlePay":
            return {
              id: getSession(),
              diningSessionID: qlub?.diningSessionId,
              tipAmount: qlub?.tip?.toFixed(props.qlub?.currencyPrecision || 0) || "0.00",
              paymentMethod: {
                type: "googlepay",
                googlePayToken: paymentData.paymentMethodData.tokenizationData.token
              },
              reference: paymentData.reference,
              gatewayID: gatewayId,
              cardType: paymentData.paymentMethodData.info?.cardNetwork || "",
              returnUrl: paymentData.returnUrl.pending
            };
          default:
            return {};
        }
      }
      case "mpgs":
      case "tyro": {
        switch (methodName) {
          case "handlePay":
            return {
              id: getSession(),
              diningSessionID: qlub?.diningSessionId,
              tipAmount: qlub?.tip?.toFixed(props.qlub?.currencyPrecision || 0) || "0.00",
              googleToken: paymentData.paymentMethodData.tokenizationData.token,
              reference: paymentData.reference,
              gatewayID: gatewayId,
              cardType: paymentData.paymentMethodData.info?.cardNetwork || "",
              responseUrl: paymentData.returnUrl.pending,
              successUrl: paymentData.returnUrl.success,
              failureUrl: paymentData.returnUrl.fail,
              tyroSessionId: window.tyroSessionId
            };
          default:
            return {};
        }
      }
      case "tuna": {
        switch (methodName) {
          case "handlePay":
            return {
              id: getSession(),
              diningSessionID: qlub?.diningSessionId,
              tipAmount: qlub?.tip?.toFixed(props.qlub?.currencyPrecision || 0) || "0.00",
              googleToken: paymentData.paymentMethodData.tokenizationData.token,
              reference: paymentData.reference,
              gatewayID: gatewayId,
              sessionToken: paymentData.tunaSessionToken,
              method: "1",
              ...paymentData.documentData
            };
          default:
            return {};
        }
      }

      default: {
        switch (methodName) {
          case "handlePay":
            return {
              id: getSession(),
              diningSessionID: qlub?.diningSessionId,
              tipAmount: qlub?.tip?.toFixed(props.qlub?.currencyPrecision || 0) || "0.00",
              googleToken: paymentData.paymentMethodData.tokenizationData.token,
              reference: paymentData.reference,
              gatewayID: gatewayId,
              cardType: paymentData.paymentMethodData.info?.cardNetwork || ""
            };
          default:
            return {};
        }
      }
    }
  };

  return {
    handlePay: paymentHandler,
    getPayload,
    gatewayName: gatewayNameRef.current,
    onPaymentComplete,
    merchantId: merchantId.current,
    environment: environmentRef.current
  };
};

export default useGooglePay;
