import { useEffect } from "react";
import { useCommonStore } from "@/stores/commonStore";
import { sumAmounts } from "@clubpay/customer-common-module/src/utility/k_math";

const useStorePaymentData = (props: any) => {
  const { totalAmount: totalByClient } = props;
  const totalAmount =
    typeof totalByClient !== "undefined"
      ? totalByClient
      : sumAmounts(props?.qlub?.currencyPrecision || 0, props.amount || 0, props.qlub?.tip || 0);

  const { setTotal } = useCommonStore((store) => store);

  useEffect(() => {
    setTotal(totalAmount);
  }, [totalAmount]);

  return null;
};

export default useStorePaymentData;
