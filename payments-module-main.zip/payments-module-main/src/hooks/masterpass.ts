import { useRef, useState } from "react";
import PaymentAPIManager from "@/api/gateways";
import {
  MASTERPASS_RESPONSE_CODE,
  getlListOfCards,
  payWithRegisteredCard,
  purchaseAndRegister,
  registerMasterPassForm,
  removeSlashesAndReverse
} from "@/components/PaymentMethods/Card/Gateways/Masterpass/Masterpass.util";
import { IMasterpassCard, MasterpassModalScreens } from "@/components/PaymentMethods/Card/Gateways/Masterpass/types";
import {
  resendOTP,
  verifyOTPForm
} from "@/components/PaymentMethods/Card/Gateways/MasterpassDirect/MasterpassDirect.util";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { useMasterpassStore } from "@/stores/masterpassStore";
import { PaymentOptions } from "@/types";
import { MASTERPASS_PF_BANK_ICA, getAdditionalParameters } from "@/utils";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { sumAmounts } from "@clubpay/customer-common-module/src/utility/k_math";
import useToast from "./toast";

const useMasterpass = (props: PaymentOptions) => {
  const qlub = props.qlub;
  const amount = props.amount || 0;

  const [open, setOpen] = useState(false);
  const [onReady, setOnReady] = useState(false);
  const { displayMessage } = useToast();

  const { state, setOTPProcess, setMasterpassDisplay, setCardsList, resetOTPProcess, removeCard } = useMasterpassStore(
    (state) => state
  );
  const gatewayId = props.pg.id;
  const gatewayName = props.pg.name;

  const { setProcessing } = usePayment();
  const { getCallbackUrl } = useConfirmCallback();

  const { login, isLogin, setDrawerConstants, isAuthorizedUser } = useAuth();
  const config = props.pg.config;

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).masterpass;

  const reference = useRef<any>(null);

  const toggleDrawer = () => setOpen(!open);

  const closeDrawer = () => setOpen(false);

  const openDrawer = () => setOpen(true);

  const { cards } = state.state;

  const totalAmount = qlub?.exchange?.isApplied
    ? qlub?.exchange.total
    : sumAmounts(qlub?.currencyPrecision || 0, amount || 0, qlub?.tip || 0);

  const checkMasterpass = (token: string, customerPhone: string) => {
    registerMasterPassForm(
      {
        referenceNo: reference.current,
        token,
        userId: customerPhone
      },
      (responseCode, response) => {
        console.log("responseCode", responseCode);
        console.log("response", response);
      }
    );
  };

  const initiateMasterpass = async () => {
    try {
      const referenceRes = await api.generateReference();

      reference.current = referenceRes.data.reference;

      const masterpassResponse = await api.generateToken({
        gatewayID: gatewayId,
        verbose: true,
        reference: reference.current,
        forRegisterCard: false,
        computeReturnURL: false,
        id: getSession(),
        diningSessionID: qlub?.diningSessionId
      });
      checkMasterpass(masterpassResponse.data?.token, masterpassResponse.data?.customerPhone);
      handleFetchCardsList({
        customerPhone: masterpassResponse.data?.customerPhone,
        token: masterpassResponse.data?.token
      });
    } catch (error: any) {
      console.log("error:initiateMasterpass", error);
      //TODO: error utilize codes
    } finally {
      setProcessing(false);
    }
  };

  const handleLogin = async () => {
    setProcessing(true);

    setDrawerConstants({
      text: {
        phone: {
          title: t("Qlub verification"),
          description: t("Enter your phone number in order to use Masterpass"),
          buttonText: t("Confirm")
        },
        otp: {
          title: t("Qlub verification"),
          description: t("Enter the code sent to your mobile from qlub"),
          buttonText: t("Confirm")
        },
        done: {
          title: t("Redirecting..."),
          description: t("Your phone number has been verified. You are being redirected."),
          buttonText: ""
        }
      },
      numInputs: 5
    });

    try {
      if (!isLogin || !isAuthorizedUser) {
        const validated = await login({ closeTimeout: 3000 });

        if (validated) {
          initiateMasterpass();
        } else {
          // showError({});
        }
      } else {
        initiateMasterpass();
      }
    } catch (e: any) {
      // dispatch({
      //     type: MasterpassActionTypeEnum.CLOSE_DRAWER,
      // });
      // return;
      // showError({});
    }
  };

  const resendCodeFromBank = async () => {
    try {
      const token = window.MFS?.getLastToken();
      if (!token) return;
      resendOTP(token, "tur", (responseCode, response) => {
        if ([MASTERPASS_RESPONSE_CODE.OTP, MASTERPASS_RESPONSE_CODE.OTHER_OTP].includes(response?.responseCode)) {
          resetOTPProcess();

          setOTPProcess({
            status: true
          });
        } else if (response?.responseCode === MASTERPASS_RESPONSE_CODE.HAS_REACHED_THE_SMS_LIMIT) {
          displayMessage(response?.responseDescription, "error", { autoHide: true });
        } else {
          displayMessage(response?.responseDescription, "error", { autoHide: true });
        }
      });
    } catch (error: any) {
      console.log("error", error);
    }
  };

  const verifyMasterpassCode = (code: string) => {
    verifyOTPForm(
      {
        referenceNo: reference.current,
        validationCode: code
      },
      (_status, response) => {
        if (response.responseCode === MASTERPASS_RESPONSE_CODE.OTP || response.responseCode === "") {
          initiateMasterpass().then(() => {
            setMasterpassDisplay(MasterpassModalScreens.QLUB_ACCOUNT_SUCCESS);
          });
        } else {
          displayMessage(response?.responseDescription, "error", { autoHide: true });
          closeDrawer();
        }
      }
    );
  };

  const deleteCard = async (cardID: string, cardName: string) => {
    removeCard(cardID);

    try {
      const genTokenResponse = await api.generateToken({
        gatewayID: gatewayId,
        verbose: true,
        reference: reference.current,
        forRegisterCard: false,
        computeReturnURL: false,
        id: getSession(),
        diningSessionID: qlub?.diningSessionId
      });

      removeCard(
        {
          referenceNo: reference.current,
          msisdn: genTokenResponse.data?.customerPhone,
          token: genTokenResponse.data?.token,
          accountAliasName: cardName
        },
        () => {}
      );
    } catch (error: any) {
      console.log("error: deleteCard");
    }
  };

  const handleFetchCardsList = async (payload: any) => {
    try {
      getlListOfCards(payload.customerPhone, payload?.token, (responseCode, response) => {
        if (!response?.cards || response?.cards?.length === 0) {
          setMasterpassDisplay(MasterpassModalScreens.NONE);

          openDrawer();

          return;
        }

        const cards = response.cards.map((card: IMasterpassCard) => ({
          selected: false,
          mask: card?.Value1?.match(/.{1,4}/g)?.join(" "), // to seperate card number with space 123456******7890 -> 1234 56** **** 7890
          ...card
        }));

        setCardsList(cards);

        setMasterpassDisplay(MasterpassModalScreens.QLUB_ACCOUNT_SUCCESS);

        openDrawer();
      });
    } catch (error: any) {
      console.log("error: handleFetchCardsList", error);
    }
  };

  const initBankOtpOperation = () => {
    setMasterpassDisplay(MasterpassModalScreens.BANK_OTP_STEP);

    resetOTPProcess();

    setOTPProcess();
    openDrawer();
  };

  const handlePay = async (newCard = false, payload: any) => {
    setProcessing(true);
    try {
      const returnUrl = getCallbackUrl({
        ref: reference.current,
        method: gatewayName,
        paymentElement: PaymentElementEnum.CardPay,
        tip: qlub?.tip ? qlub.tip.toFixed(2) : "0.00",
        dsi: qlub?.diningSessionId || "",
        sid: getSession(),
        amount: amount.toFixed(qlub?.currencyPrecision || 0),
        currencySymbol: props.country
      });

      const selectedCard = cards?.find((card: any) => card.selected);
      const genTokenResponse = await api.generateToken({
        gatewayID: gatewayId,
        verbose: true,
        reference: reference.current,
        forRegisterCard: newCard,
        computeReturnURL: true,
        id: getSession(),
        diningSessionID: qlub?.diningSessionId,
        failURL: returnUrl.fail,
        successURL: returnUrl.success,
        tipAmount: qlub?.tip ? qlub.tip.toFixed(2) : "0.00"
      });

      const totalAmount = (sumAmounts(qlub?.currencyPrecision, amount, qlub?.tip || 0) * 100).toFixed(0);

      const additionalParameters = getAdditionalParameters({
        total: totalAmount,
        bankIca: config.extraConfig?.bankICA || MASTERPASS_PF_BANK_ICA.ipara,
        restaurantUnique: props.pg.vendor?.unique
      });

      if (newCard) {
        purchaseAndRegister(
          {
            referenceNo: reference.current,
            msisdn: genTokenResponse?.data.customerPhone,
            amount: totalAmount,
            accountAliasName: payload.cardLabel || "",
            expiryDate: removeSlashesAndReverse(payload.expirationDate),
            token: genTokenResponse?.data.token,
            orderNo: genTokenResponse?.data.orderID,
            rtaPan: payload.cardNumber.replace(/\s/g, ""),
            userId:
              config.extraConfig?.bankICA === MASTERPASS_PF_BANK_ICA.sipay
                ? genTokenResponse.data.customerID
                : genTokenResponse.data.customerPhone,
            ...additionalParameters
          },
          async (_responseCode, response) => {
            if (response?.responseCode === MASTERPASS_RESPONSE_CODE.SUCCESS_REDIRECT_TO_3D) {
              const returnURL = genTokenResponse?.data.computedCallbackURL;
              if (!returnURL) {
                displayMessage(response?.responseDescription, "error", { autoHide: true });
                closeDrawer();
                return;
              }

              window.location.assign(`${response?.url3D}&returnUrl=${returnURL}`);
            } else if (
              [MASTERPASS_RESPONSE_CODE.OTP, MASTERPASS_RESPONSE_CODE.OTHER_OTP].includes(response?.responseCode)
            ) {
              initBankOtpOperation();
            } else {
              displayMessage(response?.responseDescription, "error", { autoHide: true });
              closeDrawer();
            }
          }
        );
      } else {
        payWithRegisteredCard(
          {
            msisdn: genTokenResponse.data.customerPhone,
            token: genTokenResponse.data.token,
            orderNo: genTokenResponse.data.orderID,
            userId:
              config.extraConfig?.bankICA === MASTERPASS_PF_BANK_ICA.sipay
                ? genTokenResponse.data.customerID
                : genTokenResponse.data.customerPhone,
            referenceNo: reference.current,
            listAccountName: selectedCard?.Name,
            amount: totalAmount,
            ...additionalParameters
          },
          async (responseCode, response) => {
            const returnURL = genTokenResponse.data.computedCallbackURL;

            if (response?.responseCode === MASTERPASS_RESPONSE_CODE.SUCCESS_REDIRECT_TO_3D) {
              // 3D Secure
              window.location.assign(`${response?.url3D}&returnUrl=${returnURL}`);
            } else if (
              [MASTERPASS_RESPONSE_CODE.OTP, MASTERPASS_RESPONSE_CODE.OTHER_OTP].includes(response?.responseCode)
            ) {
              setMasterpassDisplay(MasterpassModalScreens.BANK_OTP_STEP);

              setOTPProcess({
                status: true
              });

              openDrawer();
            } else {
              console.log("error", response?.responseDescription);
              console.log("responseCode", responseCode);
            }
          }
        );
      }
    } catch (error: any) {
      console.log("error", error);
    } finally {
      setProcessing(false);
    }
  };

  return {
    state: {
      open,
      totalAmount,
      onReady
    },
    methods: {
      checkMasterpass,
      handlePay,
      handleFetchCardsList,
      deleteCard,
      handleLogin,
      toggleDrawer,
      closeDrawer,
      setOnReady,
      openDrawer,
      resendCodeFromBank,
      verifyMasterpassCode,
      initBankOtpOperation
    }
  };
};

export default useMasterpass;
