import storage from "@/constants/storage";
import { PaymentMetaTypes, PaymentOptions, PaymentProfile } from "@/types";
import { getCustomerId } from "@/utils";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";

interface Props {
  paymentOptions: PaymentOptions;
  paymentMethod: PaymentElementEnum;
}

export const usePaymentProfile = ({ paymentOptions, paymentMethod }: Props) => {
  const { pg, qlub } = paymentOptions;
  const pgName = pg.name;
  const pgId = pg.id;
  const exchange = qlub?.exchange;

  const writeToProfile = (data: PaymentMetaTypes, keyName?: keyof PaymentProfile) => {
    const paymentProfile = localStorage.getItem(storage.CUSTOMER_PAYMENT_PROFILE);

    let updatedProfile = {};
    if (paymentProfile) {
      updatedProfile = { ...JSON.parse(paymentProfile), ...(keyName ? { [keyName]: data } : data) };
    } else {
      updatedProfile = { customerId: getCustomerId(), ...(keyName ? { [keyName]: data } : data) };
    }

    localStorage.setItem(storage.CUSTOMER_PAYMENT_PROFILE, JSON.stringify(updatedProfile));
  };

  const saveLastPayment = (data: PaymentMetaTypes = {}) => {
    const lastPayment: PaymentMetaTypes = {
      paymentMethod,
      paymentGateway: pgName,
      pgId,
      isForexPayment: !!exchange?.isApplied,
      isForexInterrupted: !!exchange?.isInterrupted,
      forexCurrencyCode: exchange?.currencyCode,
      ...data
    };

    writeToProfile(lastPayment, "lastPayment");
  };

  return { saveLastPayment };
};
