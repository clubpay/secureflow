import { useEffect } from "react";
import { v4 as uuidv4 } from "uuid";
import { useCommonStore } from "@/stores/commonStore";
import axiosInstance from "@clubpay/customer-common-module/src/repository/axios";

const useSentryInit = () => {
  const {
    state: { paymentTraceId },
    setPaymentTraceId
  } = useCommonStore((store) => store);

  useEffect(() => {
    const id = sessionStorage.getItem("paymentTraceId");
    if (!id) {
      const randId = uuidv4();
      sessionStorage.setItem("paymentTraceId", randId);
      setPaymentTraceId(randId);
    } else {
      setPaymentTraceId(id);
    }
  }, []);

  useEffect(() => {
    if (paymentTraceId) axiosInstance.axios.defaults.headers.common["payment-trace-id"] = paymentTraceId;
  }, [paymentTraceId]);

  return {};
};

export default useSentryInit;
