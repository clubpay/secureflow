import { useCallback } from "react";
import storage from "@/constants/storage";
import { PaymentOptions } from "@/types";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";

type Props = {
  paymentOptions: PaymentOptions;
  paymentMethod: PaymentElementEnum;
};

export const usePgEvent = ({ paymentOptions, paymentMethod }: Props) => {
  const { pg, qlub } = paymentOptions;

  const diningSessionId = qlub?.diningSessionId;
  const restaurantName = pg.vendor.name;
  const restaurantConfig = pg.vendor.config;
  const pgName = pg.name;

  const sendEvent = useCallback((eventName: string, params?: Record<string, unknown>) => {
    window.dataLayer?.push({
      event: eventName,
      pg_name: `${pgName}_${params?.paymentMethod ?? paymentMethod}`?.toLowerCase(),
      restaurant_name: restaurantName,
      diningSessionId,
      forex_ui: restaurantConfig.forexUI ?? "v2",
      is_forex_limited: Boolean(sessionStorage.getItem(storage.LIMIT_FOREX)),
      is_new_payment_module: Boolean(restaurantConfig.enableNewPaymentModule),
      version: "4.0.0",
      ...params
    });
  }, []);

  return { sendEvent };
};
