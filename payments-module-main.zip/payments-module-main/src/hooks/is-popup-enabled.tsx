import { useEffect, useState } from "react";

const useIsPopupEnabled = () => {
  const [isEnabled, setIsEnabled] = useState(false);

  const isPopupBlocked = () => {
    let testPopup = window.open("", "_blank");

    if (!testPopup || testPopup.closed || typeof testPopup.closed === "undefined") {
      return true;
    } else {
      testPopup.close();
      return false;
    }
  };

  useEffect(() => {
    setIsEnabled(!isPopupBlocked());
  }, []);

  return isEnabled;
};

export default useIsPopupEnabled;
