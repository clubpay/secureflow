import { useRef, useState } from "react";
import CPFDrawer from "@/components/PaymentMethods/Card/components/Tuna/CPFDrawer";

interface PropTypes {
  paymentCB: (e: any) => Promise<void> | VoidFunction;
  cpfRequired?: boolean;
  enabled?: boolean;
  content?: {
    title: string;
    subtitle: String;
  };
}

const useCPFDrawer = (props: PropTypes) => {
  const [cpfOpen, setCpfOpen] = useState(false);
  const [additionalData, setAdditionalData] = useState({
    document: "",
    documentType: ""
  });

  const { paymentCB, enabled, ...rest } = props;

  const openCPFDrawer = () => {
    if (enabled) setCpfOpen(true);
    else paymentCB({});
  };

  const closeCPFDrawer = () => setCpfOpen(false);

  const handleOnChange = (value: string, type: string) => {
    setAdditionalData({
      document: value,
      documentType: type
    });
  };

  const handleProceed = () => {
    closeCPFDrawer();
    paymentCB({});
  };

  const DrawerElement = (
    <CPFDrawer open={cpfOpen} onClose={closeCPFDrawer} onChange={handleOnChange} onProceed={handleProceed} {...rest} />
  );

  return {
    additionalData: enabled ? additionalData : {},
    DrawerElement,
    handleProceed,
    openCPFDrawer,
    closeCPFDrawer
  };
};

export default useCPFDrawer;
