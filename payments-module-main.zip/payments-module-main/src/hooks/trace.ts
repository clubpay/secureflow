import { useMemo } from "react";
import { useCommonStore } from "@/stores/commonStore";
import { PaymentGatewayConfig } from "@/types";

const useTrace = (pg: PaymentGatewayConfig) => {
  const {
    state: { paymentTraceId }
  } = useCommonStore((store) => store);
  return useMemo(() => pg.config.events?.onTraceStart?.(pg.id, paymentTraceId), [paymentTraceId]);
};

export default useTrace;
