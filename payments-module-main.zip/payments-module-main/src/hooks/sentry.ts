import { useState } from "react";
import { useCommonStore } from "@/stores/commonStore";
import { PaymentOptions } from "@/types/payments";
import * as Sentry from "@sentry/nextjs";

const useSentry = (props: PaymentOptions) => {
  const pgName = props.pg.name;
  const dineSessionId = props.qlub?.diningSessionId;

  const [paymentMethod, setPaymentMethod] = useState("");

  const { state } = useCommonStore((store) => store);

  const isPaymentTraceRequired =
    props.pg.vendor?.config?.paymentTrace || props.pg.vendor?.country?.config?.paymentTrace;

  const startTrace = (location: string, paymentMethodForTrace: string, callback: any) => {
    setPaymentMethod(paymentMethodForTrace);
    if (isPaymentTraceRequired) {
      Sentry.startSpan({ name: `${pgName}-${paymentMethodForTrace}`, op: "payment" }, callback);
      const span = Sentry.getActiveSpan();
      span?.setTag("qlub.payment_trace_id", state.paymentTraceId);
      span?.setTag("qlub.payment_gateway", pgName);
      span?.setTag("qlub.payment_method", paymentMethodForTrace);
      span?.setTag("qlub.dine_session_id", dineSessionId);
      span?.setTag("qlub.location", location);
    } else {
      callback();
    }
  };

  const captureException = (e: any) => {
    if (isPaymentTraceRequired) Sentry?.captureException(e);
  };

  const infoLog = (message: string, data?: any) => {
    Sentry.addBreadcrumb({
      category: `${pgName}-${paymentMethod}`,
      message,
      level: "info",
      data
    });
  };

  const errorLog = (message: string, data?: any) => {
    Sentry.addBreadcrumb({
      category: `${pgName}-${paymentMethod}`,
      message,
      level: "error",
      data
    });
  };

  return {
    startTrace,
    captureException,
    infoLog,
    errorLog
  };
};

export default useSentry;
