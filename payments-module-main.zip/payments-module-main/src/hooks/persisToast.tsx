import { ReactElement } from "react-markdown/lib/react-markdown";
import { OptionsObject, SnackbarAction, SnackbarKey, useSnackbar } from "notistack";
import { t } from "@/locales";
import { Button } from "@qlub-dev/qlub-kit";

const persisToast = () => {
  const { enqueueSnackbar, closeSnackbar } = useSnackbar();

  const actionButton: SnackbarAction = (key?: SnackbarKey) => (
    <Button
      onClick={() => closeSnackbar(key)}
      size="small"
      variant="text"
      color="inherit"
      sx={{
        backgroundColor: "transparent !important",
        border: "none !important",
        py: 0
      }}
    >
      {t("OK")}
    </Button>
  );

  const triggerSnackBar = (msg: string | ReactElement, options?: OptionsObject, autoHide?: boolean) => {
    enqueueSnackbar(msg, {
      persist: !autoHide,
      ...options
    });
  };

  const showMessage = (msg: string, variant = "warning", options?: any) => {
    const { autoHide, actionButton: button } = options ?? {};
    triggerSnackBar(
      msg,
      {
        variant: variant as any,
        action: button ? button : actionButton,
        autoHideDuration: 2000,
        ...(options ? options : {})
      },
      autoHide || false
    );
  };

  return {
    showMessage
  };
};

export default persisToast;
