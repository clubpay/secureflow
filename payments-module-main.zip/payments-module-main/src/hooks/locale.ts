import { useEffect, useState } from "react";
import { load } from "@/locales";
import { useCommonStore } from "@/stores/commonStore";

const rtlLocales = ["ar"];

const useLocale = (locale: string) => {
  const [currentLocale, setCurrentLocale] = useState("");
  const {
    setRTL,
    state: { isRTL }
  } = useCommonStore((store) => store);

  useEffect(() => {
    load(locale).then((l) => {
      setCurrentLocale(l);
      setRTL(rtlLocales.includes(l));
    });
  }, [locale]);

  return { locale: currentLocale, isRTL };
};

export default useLocale;
