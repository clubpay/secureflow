import { t } from "@/locales";
import { snackBar } from "@clubpay/customer-common-module/src/hook/snackBar";

type ErrorKeys = "multiple-frame" | "card-number" | "expiry-date" | "cvv" | "otp" | "generic" | "card-generic";

const errorTypes = {
  "multiple-frame": t("Card information is invalid. Please check the details and retry."),
  "card-number": t("Card number is invalid. Please check the details and retry."),
  "expiry-date": t("Expiry date is invalid. Please check the details and retry."),
  "card-generic": t("Entered card details are invalid. Please check the details and retry."),
  "cvv": t("CVV is invalid. Please check the details and retry."),
  "otp": t("OTP is invalid. Please check the details and retry."),
  "generic": t("Payment did not proceed. Please check the details and retry.")
};

const useToast = () => {
  const { triggerSnackBar: enqueueSnackbar, actionButton } = snackBar();
  const showMessage = (msg: string, variant = "warning", options?: any) => {
    const { autoHide, actionButton: button } = options ?? {};
    enqueueSnackbar(
      msg,
      {
        variant: variant as any,
        action: button ? button : actionButton,
        autoHideDuration: 2000,
        ...(options ? options : {})
      },
      autoHide || false
    );
  };

  const displayMessage = (msg: string, variant = "warning", options = {}) => {
    showMessage(msg, variant, options);
  };

  const displayError = (key?: ErrorKeys) => {
    const error = key ? errorTypes[key] : errorTypes["generic"];
    showMessage(error, "warning");
  };

  return { displayMessage, displayError };
};

export default useToast;
