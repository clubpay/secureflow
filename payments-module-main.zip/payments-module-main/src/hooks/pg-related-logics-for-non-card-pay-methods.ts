import { useEffect, useRef } from "react";
import PaymentAPIManager from "@/api/gateways";
import { PaymentOptions } from "@/types";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";

const usePgRelatedLogicsForNonCardPayMethods = (props: PaymentOptions) => {
  const api = PaymentAPIManager.getInstance();

  let paymentHandler = null;
  let gatewayName = null;
  const gatewayId = props.pg.id;

  const dataRef = useRef<any>({});

  switch (props.pg.name) {
    case "tuna":
      paymentHandler = api.tuna;
      gatewayName = "tuna";
      break;
    default:
  }

  const tunaInit = async () => {
    const reference = getRandomString();
    try {
      const response = await paymentHandler?.session({
        gatewayID: gatewayId,
        reference: reference,
        diningSessionID: props.qlub?.diningSessionId || "",
        id: getSession()
      });

      dataRef.current.tunaSessionToken = response?.data.sessionToken;
    } catch (error: any) {
      console.log("error", error);
    }
  };

  const run = () => {
    switch (gatewayName) {
      case "tuna":
        tunaInit();
        break;
    }
  };

  useEffect(() => {
    run();
  }, []);

  return {
    data: dataRef.current
  };
};

export default usePgRelatedLogicsForNonCardPayMethods;
