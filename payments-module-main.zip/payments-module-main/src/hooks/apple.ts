import { useState } from "react";
import PaymentAPIManager from "@/api/gateways";
import { ApplePayProps } from "@/components/PaymentMethods/ApplePay/Gateways/Direct/Direct";
import { useCommonStore } from "@/stores/commonStore";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";

type MethodNames =
  | "onvalidatemerchant"
  | "onpaymentauthorized"
  | "onpaymentmethodselected"
  | "onshippingmethodselected"
  | "onshippingcontactselected"
  | "oncancel"
  | "completeMerchantValidation";

const useApplePay = (props: ApplePayProps) => {
  const api = props.pg.config.apiManager ?? PaymentAPIManager.getInstance();
  const qlub = props.qlub;
  const gatewayId = props.pg.id;
  const isSubscriptionPayment = props.isSubscriptionPayment;

  const config = props.pg.config;

  let paymentHandler = null;
  let gatewayName = props.pg.name;
  let onPaymentComplete = props.pg.config?.events?.onPaymentSuccess;

  const [loading, setLoading] = useState(false);

  switch (props.pg.name) {
    case "checkout":
    case "checkoutltd":
      paymentHandler = api.checkout;
      gatewayName = "checkoutltd";
      break;
    case "maf":
    case "mafv2":
      paymentHandler = api.maf;
      gatewayName = "maf";
      break;
    case "moyasarv2":
    case "moysarv2":
    case "moyasarV2":
      paymentHandler = api.moyasarV2;
      gatewayName = "moyasar";
      break;
    case "ngenius":
      paymentHandler = api.ngenius;
      gatewayName = "ngenius";
      break;
    case "mashreq":
      paymentHandler = api.mashreq;
      gatewayName = "mashreq";
      break;
    case "ccpp":
      paymentHandler = api.ccpp;
      gatewayName = "ccpp";
      break;
    case "adyen":
      paymentHandler = api.adyen;
      gatewayName = "adyen";
      onPaymentComplete = props.pg.config?.events?.onPaymentPending;
      break;
    case "tyro":
      paymentHandler = api.tyro;
      gatewayName = "tyro";
      break;
    case "tuna":
      paymentHandler = api.tuna;
      gatewayName = "tuna";
      break;
  }

  const getPayload = (methodName: MethodNames, eventData: any) => {
    switch (gatewayName) {
      case "checkout":
      case "checkoutltd":
        switch (methodName) {
          case "onvalidatemerchant":
            return {
              diningSessionID: qlub?.diningSessionId || "",
              applePayUrl: eventData?.validationURL,
              gatewayID: gatewayId,
              hostname: window.location.hostname
            };
          case "onpaymentauthorized":
            return {
              id: eventData.additonalData?.id,
              diningSessionID: qlub?.diningSessionId,
              tipAmount: (qlub?.tip ?? 0).toFixed(qlub?.currencyPrecision || 0),
              appleToken: JSON.stringify(eventData.payment?.token || {}),
              shippingContact: eventData.payment?.shippingContact,
              billingContact: eventData.payment?.billingContact,
              reference: eventData.additonalData?.refId,
              gatewayID: gatewayId,
              cardType: eventData.payment?.network || "",
              hostname: window.location.hostname,
              isSplitPayment: props.pg?.hasSplitPayment || false,
              exchangeDecision: eventData.additonalData?.exchangeDecision,
              subscribe: isSubscriptionPayment
            };
          case "onpaymentmethodselected":
            return {
              newTotal: {
                label: "Qlub_",
                type: "final",
                amount: eventData.additonalData?.amount
              }
            };
          case "onshippingmethodselected":
            return {};
          case "onshippingcontactselected":
            return {};
          case "oncancel":
            return {};
          case "completeMerchantValidation":
            return JSON.parse(eventData.data.jsonData);
          default:
            return {};
        }

      case "tuna":
        switch (methodName) {
          case "onvalidatemerchant":
            return {
              diningSessionID: qlub?.diningSessionId || "",
              applePayUrl: eventData?.validationURL,
              gatewayID: gatewayId
            };
          case "onpaymentauthorized":
            return {
              id: eventData.additonalData?.id,
              diningSessionID: qlub?.diningSessionId,
              tipAmount: (qlub?.tip ?? 0).toFixed(qlub?.currencyPrecision || 0),
              appleToken: JSON.stringify(eventData.payment?.token?.paymentData || {}),
              shippingContact: eventData.payment?.shippingContact,
              billingContact: eventData.payment?.billingContact,
              reference: eventData.additonalData?.refId,
              gatewayID: gatewayId,
              cardType: eventData.payment?.token?.paymentMethod?.network || "",
              hostname: window.location.hostname,
              method: "1",
              sessionToken: eventData.additonalData?.tunaSessionToken,
              ...eventData?.additonalData?.documentData
            };
          case "onpaymentmethodselected":
            return {
              newTotal: {
                label: "Qlub_",
                type: "final",
                amount: eventData.additonalData?.amount
              }
            };
          case "onshippingmethodselected":
            return {};
          case "onshippingcontactselected":
            return {};
          case "oncancel":
            return {};
          case "completeMerchantValidation":
            return JSON.parse(eventData.data.jsonData);
          default:
            return {};
        }

      case "moyasar":
      case "moyasarv2":
      case "moysarv2":
      case "moyasarV2":
        switch (methodName) {
          case "onvalidatemerchant":
            return {
              validation_url: eventData.validationURL,
              display_name: "qlub",
              domain_name: config.extraConfig?.domain,
              publishable_api_key: config.extraConfig?.publishableKey
            };
          case "onpaymentauthorized":
            return {
              id: eventData.additonalData?.id,
              diningSessionID: qlub?.diningSessionId,
              tipAmount: (qlub?.tip ?? 0).toFixed(qlub?.currencyPrecision || 0),
              appleToken: JSON.stringify(eventData.payment?.token || {}),
              shippingContact: eventData.payment?.shippingContact,
              billingContact: eventData.payment?.billingContact,
              reference: eventData.additonalData?.refId,
              gatewayID: gatewayId,
              cardType: eventData.payment?.token?.paymentMethod?.network || "",
              hostname: window.location.hostname,
              isSplitPayment: !!props.pg?.hasSplitPayment,
              exchangeDecision: eventData.additonalData?.exchangeDecision
            };
          case "onpaymentmethodselected":
            return {
              newTotal: {
                label: "Qlub_",
                type: "final",
                amount: eventData.additonalData?.amount
              }
            };
          case "onshippingmethodselected":
            return {};
          case "onshippingcontactselected":
            return {};
          case "oncancel":
            return {};
          case "completeMerchantValidation":
            return eventData.data;
          default:
            return {};
        }

      case "ngenius":
        switch (methodName) {
          case "onvalidatemerchant":
            return {
              diningSessionID: qlub?.diningSessionId || "",
              applePayUrl: eventData?.validationURL,
              gatewayID: gatewayId
            };
          case "onpaymentauthorized":
            return {
              id: eventData.additonalData?.id,
              diningSessionID: qlub?.diningSessionId,
              tipAmount: (qlub?.tip ?? 0).toFixed(qlub?.currencyPrecision || 0),
              appleToken: JSON.stringify(eventData.payment?.token || {}),
              shippingContact: eventData.payment?.shippingContact,
              billingContact: eventData.payment?.billingContact,
              reference: eventData.additonalData?.refId,
              gatewayID: gatewayId,
              cardType: eventData.payment?.network,
              hostname: window.location.hostname,
              isSplitPayment: !!props.pg?.hasSplitPayment,
              exchangeDecision: eventData.additonalData?.exchangeDecision
            };
          case "onpaymentmethodselected":
            return {
              newTotal: {
                label: "Qlub_",
                type: "final",
                amount: eventData.additonalData?.amount
              }
            };
          case "onshippingmethodselected":
            return {};
          case "onshippingcontactselected":
            return {};
          case "oncancel":
            return {};
          case "completeMerchantValidation":
            return JSON.parse(eventData.data.jsonData);
          default:
            return {};
        }
      case "mashreq":
        switch (methodName) {
          case "onvalidatemerchant":
            return {
              diningSessionID: qlub?.diningSessionId || "",
              applePayUrl: eventData?.validationURL,
              gatewayID: gatewayId,
              hostname: window.location.hostname
            };
          case "onpaymentauthorized":
            return {
              id: eventData.additonalData?.id,
              diningSessionID: qlub?.diningSessionId,
              tipAmount: (qlub?.tip ?? 0).toFixed(qlub?.currencyPrecision || 0),
              appleToken: JSON.stringify(eventData.payment?.token || {}),
              shippingContact: eventData.payment?.shippingContact,
              billingContact: eventData.payment?.billingContact,
              reference: eventData.additonalData?.refId,
              gatewayID: gatewayId,
              cardType: eventData.payment?.token?.paymentMethod?.network || "",
              hostname: window.location.hostname,
              mashreqSessionId: window.mashreqSessionId
            };
          case "onpaymentmethodselected":
            return {
              newTotal: {
                label: "Qlub_",
                type: "final",
                amount: eventData.additonalData?.amount
              }
            };
          case "onshippingmethodselected":
            return {};
          case "onshippingcontactselected":
            return {};
          case "oncancel":
            return {};
          case "completeMerchantValidation":
            return JSON.parse(eventData.data.jsonData);
          default:
            return {};
        }

      case "ccpp":
        switch (methodName) {
          case "onvalidatemerchant":
            return {
              diningSessionID: qlub?.diningSessionId || "",
              applePayUrl: eventData?.validationURL,
              gatewayID: gatewayId,
              hostname: window.location.hostname
            };
          case "onpaymentauthorized":
            return {
              id: eventData.additonalData?.id,
              diningSessionID: qlub?.diningSessionId,
              tipAmount: (qlub?.tip ?? 0).toFixed(qlub?.currencyPrecision || 0),
              appleToken: btoa(JSON.stringify(eventData.payment?.token?.paymentData)),
              shippingContact: eventData.payment?.shippingContact,
              billingContact: eventData.payment?.billingContact,
              reference: eventData.additonalData?.refId,
              gatewayID: gatewayId,
              cardType: eventData.payment?.network || "",
              hostname: window.location.hostname,
              isSplitPayment: props.pg?.hasSplitPayment || false,
              exchangeDecision: eventData.additonalData?.exchangeDecision
            };
          case "onpaymentmethodselected":
            return {
              newTotal: {
                label: "Qlub_",
                type: "final",
                amount: eventData.additonalData?.amount
              }
            };
          case "onshippingmethodselected":
            return {};
          case "onshippingcontactselected":
            return {};
          case "oncancel":
            return {};
          case "completeMerchantValidation":
            return JSON.parse(eventData.data.jsonData);
          default:
            return {};
        }

      case "adyen":
        switch (methodName) {
          case "onvalidatemerchant":
            return {
              diningSessionID: qlub?.diningSessionId || "",
              applePayUrl: eventData?.validationURL,
              gatewayID: gatewayId,
              hostname: window.location.hostname
            };
          case "onpaymentauthorized":
            return {
              id: eventData.additonalData?.id,
              diningSessionID: qlub?.diningSessionId,
              tipAmount: (qlub?.tip ?? 0).toFixed(qlub?.currencyPrecision || 0),
              paymentMethod: {
                type: "applepay",
                applePayToken: btoa(JSON.stringify(eventData.payment?.token?.paymentData))
              },
              shippingContact: eventData.payment?.shippingContact,
              billingContact: eventData.payment?.billingContact,
              reference: eventData.additonalData?.refId,
              gatewayID: gatewayId,
              cardType: eventData.payment?.network || "",
              hostname: window.location.hostname,
              isSplitPayment: props.pg?.hasSplitPayment || false,
              exchangeDecision: eventData.additonalData?.exchangeDecision
            };
          case "onpaymentmethodselected":
            return {
              newTotal: {
                label: "Qlub_",
                type: "final",
                amount: eventData.additonalData?.amount
              }
            };
          case "completeMerchantValidation":
            return JSON.parse(eventData.data.jsonData);
          default:
            return {};
        }
      case "tyro":
        switch (methodName) {
          case "onvalidatemerchant":
            return {
              diningSessionID: qlub?.diningSessionId || "",
              applePayUrl: eventData?.validationURL,
              gatewayID: gatewayId,
              hostname: window.location.hostname
            };
          case "onpaymentauthorized":
            return {
              id: eventData.additonalData?.id,
              diningSessionID: qlub?.diningSessionId,
              tipAmount: (qlub?.tip ?? 0).toFixed(qlub?.currencyPrecision || 0),
              appleToken: JSON.stringify(eventData.payment?.token || {}),
              shippingContact: eventData.payment?.shippingContact,
              billingContact: eventData.payment?.billingContact,
              reference: eventData.additonalData?.refId,
              gatewayID: gatewayId,
              cardType: eventData.payment?.network || "",
              hostname: window.location.hostname,
              isSplitPayment: props.pg?.hasSplitPayment || false,
              exchangeDecision: eventData.additonalData?.exchangeDecision,
              tyroSessionId: window.tyroSessionId
            };
          case "onpaymentmethodselected":
            return {
              newTotal: {
                label: "Qlub_",
                type: "final",
                amount: eventData.additonalData?.amount
              }
            };
          case "onshippingmethodselected":
            return {};
          case "onshippingcontactselected":
            return {};
          case "oncancel":
            return {};
          case "completeMerchantValidation":
            return JSON.parse(eventData.data.jsonData);
          default:
            return {};
        }

      default:
        return {};
    }
  };

  const completeApplePayPayment = (applePaySession: ApplePaySession, isSuccess: boolean = true) => {
    try {
      applePaySession.completePayment(isSuccess ? ApplePaySession.STATUS_SUCCESS : ApplePaySession.STATUS_FAILURE);
    } catch (_) {}
  };

  return {
    loading,
    paymentHandler,
    gatewayName,
    onPaymentComplete,
    getPayload,
    completeApplePayPayment,
    setLoading
  };
};

export default useApplePay;
