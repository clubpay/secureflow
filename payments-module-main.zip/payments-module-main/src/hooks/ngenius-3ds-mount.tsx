import { useEffect, useRef } from "react";

export const useNgenius3dsMount = () => {
  const is3dsMounted = useRef(false);
  const threeDsContainerRef = useRef(null);

  const reset3dsMounted = () => {
    is3dsMounted.current = false;
  };

  useEffect(() => {
    const config = { childList: true, subtree: true };

    if (threeDsContainerRef.current) {
      observer.observe(threeDsContainerRef?.current, config);
    }

    return () => {
      observer.disconnect();
    };
  }, []);

  const observer = new MutationObserver((mutationsList) => {
    mutationsList.forEach((mutation) => {
      if (mutation.type === "childList") {
        if (mutation.addedNodes.length > 0) {
          is3dsMounted.current = true;
          window.scrollTo({ top: 0 });
        }
        if (mutation.removedNodes.length > 0) {
          document.body.style.overflow = "scroll";
        }
      }
    });
  });

  return { is3dsMounted, reset3dsMounted, threeDsContainerRef };
};
