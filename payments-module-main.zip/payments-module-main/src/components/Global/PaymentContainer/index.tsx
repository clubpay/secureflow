import { ReactNode } from "react";
import classnames from "classnames";
import styles from "./paymentContainer.module.scss";

interface Props {
  hideCard?: boolean;
  selected: boolean;
  pgGroup: boolean;
  children: ReactNode;
}

const PaymentContainer = ({ hideCard, selected, pgGroup, children }: Props) => {
  return (
    <div
      className={classnames(styles.root, {
        [styles.selected]: pgGroup && selected,
        [styles.hide]: (pgGroup && !selected) || hideCard
      })}
    >
      {children}
    </div>
  );
};

export default PaymentContainer;
