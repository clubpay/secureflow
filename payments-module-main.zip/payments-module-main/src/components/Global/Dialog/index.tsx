import { ReactElement } from "react";
import { Dialog, DialogContent, DialogProps } from "@mui/material";
import { Typography } from "@qlub-dev/qlub-kit";
import styles from "./dialog.module.scss";

interface Props extends DialogProps {
  open: boolean;
  title: string;
  description: string;
  icon?: ReactElement | null;
  action: ReactElement | null;
  onClose?: VoidFunction;
  isRTL?: boolean;
}

const DialogBox = ({ open, title, description, icon, action, isRTL, onClose }: Props) => {
  return (
    <Dialog open={open} classes={{ paper: styles.paper }} fullWidth maxWidth="xs" onClose={onClose}>
      <DialogContent className={styles.content}>
        {icon && <div className={styles.icon}>{icon}</div>}
        <Typography typo="headline_md" style={isRTL ? { direction: "ltr" } : {}}>
          {title}
        </Typography>
        <Typography typo="body_sm" className={styles.description} style={isRTL ? { direction: "ltr" } : {}}>
          {description}
        </Typography>
        {action}
      </DialogContent>
    </Dialog>
  );
};

export default DialogBox;
