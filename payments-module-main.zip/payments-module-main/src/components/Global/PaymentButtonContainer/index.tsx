import { ReactNode } from "react";
import { Divider } from "@qlub-dev/qlub-kit";
import PaymentTerms from "../PaymentTerms";
import styles from "./paymentContainer.module.scss";

interface Props {
  hideTerms?: boolean;
  children: ReactNode;
}

const PaymentButtonContainer = ({ hideTerms, children }: Props) => {
  return (
    <div>
      {!hideTerms && (
        <>
          <PaymentTerms className={styles.payTerms} />
          <Divider />
        </>
      )}
      {children}
    </div>
  );
};

export default PaymentButtonContainer;
