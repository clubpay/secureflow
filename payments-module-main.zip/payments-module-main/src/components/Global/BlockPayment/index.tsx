import styles from "./blockPayment.module.scss";

const BlockPayment = () => {
  return (
    <div className={styles.tempUnavailableContainer}>
      <span className={styles.tempUnavailbleTxt}>Payments are temporarily unavailable.</span>
    </div>
  );
};

export default BlockPayment;
