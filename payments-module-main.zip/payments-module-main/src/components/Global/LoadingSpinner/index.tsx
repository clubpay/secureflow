import ScaleLoader from "react-spinners/ScaleLoader";
import { Backdrop } from "@mui/material";

interface Props {
  open: boolean;
}

const LoadingSpinner = ({ open }: Props) => {
  return (
    <Backdrop
      open={open}
      sx={{
        zIndex: "2"
      }}
    >
      <ScaleLoader height={80} width={12} />
    </Backdrop>
  );
};

export default LoadingSpinner;
