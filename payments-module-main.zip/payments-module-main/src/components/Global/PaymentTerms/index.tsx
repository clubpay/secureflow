import Link from "next/link";
import { APPLE_PAY_CONSENT_COOKIE_NAME } from "@/constants";
import { useCommonStore } from "@/stores/commonStore";
import { usePGGroupStore } from "@/stores/pgGroupStore";
import { ConsumerTypes } from "@/types";
import { getCookie } from "@/utils";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";
import { useQlubRouter } from "@clubpay/customer-common-module/src/hook/router";
import { interpolateT, useTranslation } from "@clubpay/customer-common-module/src/hook/translations";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { Checkbox, FormControlLabel } from "@mui/material";
import styles from "./terms.module.scss";

export interface PaymentTermsProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {}

const PaymentTerms = ({ children, className = "", ...props }: PaymentTermsProps) => {
  const { url, lang } = useQlubRouter();

  const { t } = useTranslation("common");

  const { state } = usePGGroupStore((state) => state);

  const {
    state: { consumer }
  } = useCommonStore((state: any) => state);

  const paymentMethodName = state.pgGroupInteractionData.currentSelected?.split("-")?.[1];

  const {
    state: { countryCode, applePayConsent, applePayConsentCountryFlag },
    setApplePayConsent
  } = useCommonStore((state) => state);

  const { isAuthorizedUser } = useAuth();

  const handleChange = (event: any) => {
    const value = event.target.checked;
    setApplePayConsent(value);
  };

  const shouldShowConsentWidget = () => {
    if (isAuthorizedUser) return false;

    if (getCookie(APPLE_PAY_CONSENT_COOKIE_NAME)) return false;

    if (paymentMethodName !== PaymentElementEnum.ApplePay) return false;

    return true;
  };

  if (consumer === ConsumerTypes.PAYMENT_LINK) return null;

  if (applePayConsentCountryFlag && shouldShowConsentWidget())
    return (
      <div className={styles.consentContainer}>
        <FormControlLabel
          control={<Checkbox checked={applePayConsent} onChange={handleChange} color="primary" />}
          label={
            <span className={styles.consentText}>
              {interpolateT(
                t("I have read and agree to the <privacy> and <terms>, and I consent to receive communications"),
                {
                  terms: (
                    <Link
                      href={{
                        pathname: "/qr/[cc]/terms",
                        query: {
                          cc: url.cc || countryCode,
                          ...(lang ? { lang } : {})
                        }
                      }}
                      className={styles.privacyText}
                    >
                      {t("Terms and Conditions")}
                    </Link>
                  ),
                  privacy: t("Privacy Policy")
                }
              )}
            </span>
          }
        />
      </div>
    );

  return (
    <a {...props} className={`${styles.footerCaption} ${className}`}>
      {interpolateT(t("By clicking on pay you agree with qlub’s <terms>"), {
        terms: (
          <Link
            href={{
              pathname: "/qr/[cc]/terms",
              query: {
                cc: url.cc || countryCode,
                ...(lang ? { lang } : {})
              }
            }}
            className={styles.termsLink}
          >
            {t("Terms of use")}
          </Link>
        )
      })}
    </a>
  );
};

export default PaymentTerms;
