import QlubQR from "@/icons/QlubQR";
import QlubText from "@/icons/QlubText";
import { useTranslation } from "@clubpay/customer-common-module/src/hook/translations";
import { Box, Dialog } from "@mui/material";
import { Typography } from "@qlub-dev/qlub-kit";
import styles from "./index.module.scss";

interface Props {
  open: boolean;
}

const PaymentLoadingDialog = ({ open }: Props) => {
  const { t } = useTranslation("common");
  return (
    <Dialog open={open} classes={{ paper: styles.dialogPaper }} fullWidth maxWidth="xs">
      <div className={styles.container}>
        <Box gap="12px" display="flex" alignItems="center">
          <QlubText color="var(--iris)" height={37} />
          <QlubQR color="var(--iris)" height={20} className={styles.spinner} />
        </Box>
        <Typography typo="title_sm" textAlign="center" className={styles.title}>
          {t("Processing, Please wait")}
        </Typography>
        <Typography typo="body_sm" textAlign="center" className={styles.description}>
          {t("Please wait while we are processing your request")}
        </Typography>
      </div>
    </Dialog>
  );
};

export default PaymentLoadingDialog;
