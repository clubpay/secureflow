import VerifiedUser from "@/icons/VerifiedUser";
import { t } from "@/locales";
import styles from "./tagline.module.scss";

const SecureTagline = () => {
  return (
    <div className={styles.container}>
      <VerifiedUser outlined className={styles.icon} />
      <div className={styles.text}>{t("100% Secure payments")}</div>
    </div>
  );
};

export default SecureTagline;
