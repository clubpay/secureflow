import Button from "@/components/Core/Button";
import styles from "./googlePay.module.scss";

const GooglePay = (props: any) => {
  const { children, ...rest } = props;
  return <Button id="gooogle-pay-btn" className={styles.gButton} {...rest} />;
};

export default GooglePay;
