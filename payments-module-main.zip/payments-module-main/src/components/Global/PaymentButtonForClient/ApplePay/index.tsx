import Button, { ButtonProps } from "@/components/Core/Button";
import ApplePayIcon from "@/icons/ApplePay";
import { t } from "@/locales";
import styles from "./applePay.module.scss";

const ApplePay = ({ loading, ...props }: ButtonProps) => {
  return (
    <Button className={styles.appleButton} disabled={loading} loading={loading} {...props}>
      {t("Pay with")}
      <span>
        <ApplePayIcon />
      </span>
    </Button>
  );
};

export default ApplePay;
