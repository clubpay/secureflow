import Button from "@/components/Core/Button";
import { t } from "@/locales";
import ticketIcon from "@clubpay/customer-common-module/src/component/SVG/ticketwhite.png";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import styles from "./ticketPay.module.scss";

const TicketPay = (props: any) => {
  const { children, ...rest } = props;
  return (
    <Button
      id="payment-action-btn"
      {...rest}
      className={styles["pay-btn"]}
      prefixIcon={() => <img src={ticketIcon.src} />}
      postfixIcon={() => <ArrowForwardIosIcon.default />}
      type="submit"
    >
      {t("Pay with Ticket")}
    </Button>
  );
};

export default TicketPay;
