import { Button } from "@/components/Core";
import { t } from "@/locales";
import { useCommonStore } from "@/stores/commonStore";
import { usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import ApplePay from "./ApplePay";
import GooglePay from "./GooglePay";
import QPay from "./QPay";
import StcPay from "./StcPay";
import TicketPay from "./TicketPay";

const PaymentButtonForClient = (props: any) => {
  const { state } = usePGGroupStore((state) => state);
  const {
    state: { isPayButtonTextChangeEnabled }
  } = useCommonStore((state) => state);

  const paymentMethodName = state.pgGroupInteractionData.currentSelected?.split("-")?.[1];

  let PayBtnElement = Button;

  switch (paymentMethodName) {
    case PaymentElementEnum.ApplePay:
      PayBtnElement = ApplePay;
      break;
    case PaymentElementEnum.GooglePay:
      PayBtnElement = GooglePay;
      break;
    case PaymentElementEnum.CardPay:
      PayBtnElement = Button;
      break;
    case PaymentElementEnum.STCPay:
      PayBtnElement = StcPay;
      break;
    case PaymentElementEnum.QPay:
      PayBtnElement = QPay;
      break;
    case PaymentElementEnum.TicketPay:
      PayBtnElement = TicketPay;
      break;
  }

  const isChangeBtnLabelNeeded = () => {
    if (
      paymentMethodName === PaymentElementEnum.CardPay &&
      isPayButtonTextChangeEnabled &&
      props.name === "stripeConnect"
    )
      return true;
    return false;
  };

  return <PayBtnElement {...props} {...(isChangeBtnLabelNeeded() ? { children: t("Pay bill") } : {})} />;
};

export default PaymentButtonForClient;
