import Button from "@/components/Core/Button";
import { t } from "@/locales";

const StcPay = (props: any) => {
  const { children, ...rest } = props;
  return <Button {...rest}>{t("Pay with STC pay")}</Button>;
};

export default StcPay;
