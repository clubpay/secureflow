import Button from "@/components/Core/Button";
import { t } from "@/locales";
import { usePGGroupStore } from "@/stores/pgGroupStore";

const QPay = (props: any) => {
  const { children, ...rest } = props;

  const { state } = usePGGroupStore((state) => state);

  const hasPgGroup = state.isPGGroupEnabled;

  return <Button {...rest}>{hasPgGroup ? t("Pay") : t("NAPS Debit Card")}</Button>;
};

export default QPay;
