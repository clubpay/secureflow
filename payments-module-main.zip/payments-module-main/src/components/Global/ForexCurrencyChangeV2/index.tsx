import React from "react";
import { setForex, useForexStore } from "@/stores/forexStore";
import { useTranslation } from "@clubpay/customer-common-module/src/hook/translations";
import ErrorIcon from "@mui/icons-material/Error";
import { Alert, ToggleButton, ToggleButtonGroup } from "@mui/material";
import { Typography } from "@qlub-dev/qlub-kit";
import styles from "./index.module.scss";

const ForexCurrencyChangeV2 = () => {
  const { t } = useTranslation("common");

  const { exchangeRate, currencyCode, vendorCurrencyCode, isApplied } = useForexStore((state) => state);

  const selectedCurrency = isApplied ? currencyCode : vendorCurrencyCode;

  const handleChange = (currency: string) => {
    if (currency === currencyCode) setForex({ isApplied: true });
    else setForex({ isApplied: false });
  };

  if (!exchangeRate) return null;

  return (
    <div>
      <ToggleButtonGroup
        value={selectedCurrency}
        exclusive
        className={styles.toggleButtonGroup}
        onChange={(_, value) => handleChange(value)}
      >
        <ToggleButton
          classes={{
            root: styles.toggleButtonLeft,
            selected: styles.toggleButtonSelected
          }}
          value={currencyCode || ""}
        >
          {currencyCode}
        </ToggleButton>
        <ToggleButton
          classes={{
            root: styles.toggleButtonRight,
            selected: styles.toggleButtonSelected
          }}
          value={vendorCurrencyCode || ""}
        >
          {vendorCurrencyCode}
        </ToggleButton>
      </ToggleButtonGroup>

      {!isApplied && (
        <Alert icon={<ErrorIcon color="primary" fontSize="small" />} className={styles.alertMessage}>
          {t("Qlub can not guarantee exchange rates, additional fees might apply by your bank")}
        </Alert>
      )}

      <div className={styles.exchangeDetails}>
        <Typography typo="caption_overline">{t("Exchange rate")}</Typography>
        <Typography typo="caption_overline" className={styles.exchangeDetailsText}>
          1 {t(`${vendorCurrencyCode?.toUpperCase()} = ${exchangeRate} ${currencyCode}`)}
        </Typography>
      </div>
    </div>
  );
};

export default ForexCurrencyChangeV2;
