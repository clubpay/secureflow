import { useEffect, useState } from "react";
import CheckCircleRounded from "@mui/icons-material/CheckCircleRounded";
import Circle from "@mui/icons-material/Circle";
import CreditCardIcon from "@mui/icons-material/CreditCard";
import { Box } from "@mui/material";
import styles from "./pgPaymentBox.module.scss";

const PGPaymentBox = ({ icon, name, selected, toggleVisibility, icons }: any) => {
  const [isMultiple, setIsMultiple] = useState(false);

  const renderIcons = () => {
    if (icons) {
      return icons;
    }

    return icon ?? <CreditCardIcon.default />;
  };

  useEffect(() => {
    setIsMultiple(Boolean(icons));
  }, []);

  return (
    <Box className={selected ? styles.parentContainerSelected : styles.parentContainer} onClick={toggleVisibility}>
      <div className={styles.leftCont}>
        {selected ? (
          <CheckCircleRounded.default sx={{ fill: "var(--iris)" }} />
        ) : (
          <Circle.default style={{ color: "rgb(235, 236, 242)" }} />
        )}
        <div className={styles.pgMethodBoxName}>{name}</div>
      </div>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          columnGap: isMultiple ? "6px" : 0
        }}
      >
        {renderIcons()}
      </div>
    </Box>
  );
};

export default PGPaymentBox;
