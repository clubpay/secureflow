import { createPortal } from "react-dom";

const ReactPortal = ({ children, domNode }: any) => {
  if (!domNode) return <></>;

  return createPortal(children, domNode);
};

export default ReactPortal;
