import React, { ComponentType, useEffect, useState } from "react";

export interface WithDelayProps {
  delay?: number;
}

function withDelay<T extends object>(
  WrappedComponent: ComponentType<T>,
  delay: number = 1000
): React.FC<T & WithDelayProps> {
  return (props: T & WithDelayProps) => {
    const [show, setShow] = useState(false);

    useEffect(() => {
      const timer = setTimeout(() => {
        setShow(true);
      }, delay);

      return () => clearTimeout(timer);
    }, [delay]);

    return show ? <WrappedComponent {...props} /> : null;
  };
}

export default withDelay;
