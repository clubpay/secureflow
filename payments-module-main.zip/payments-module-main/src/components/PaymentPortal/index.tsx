import { ComponentType, Fragment, Suspense, forwardRef, lazy, useEffect, useMemo, useState } from "react";
import { enableMapSet } from "immer";
import endsWith from "lodash/endsWith";
import isBoolean from "lodash/isBoolean";
import isEmpty from "lodash/isEmpty";
import minBy from "lodash/minBy";
import orderBy from "lodash/orderBy";
import range from "lodash/range";
import some from "lodash/some";
import zipObject from "lodash/zipObject";
import Head from "next/head";
import { ROUTING_OVERIDING_COUNTRIES } from "@/constants";
import { useLocale, useSnackbar } from "@/hooks";
import { useSentryInit, useStorePaymentData } from "@/hooks";
import usePaymentRefFunctionToClient from "@/hooks/sync-payment-ref-function-to-client";
import { CardProvider, PaymentProvider } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { resetForex } from "@/stores/forexStore";
import { usePGGroupStore } from "@/stores/pgGroupStore";
import { setPaymentMethods } from "@/stores/pgStore";
import { useStripeStore } from "@/stores/stripeStore";
import { useToastStore } from "@/stores/toastStore";
import { LazyComponentInventory, PaymentGatewayConfig, PaymentOptions, PaymentProfile } from "@/types";
import { StripeConfig } from "@/types/payments/config/stripe";
import { StripeConnectConfig } from "@/types/payments/config/stripeConnect";
import { getPaymentProfile } from "@/utils";
import {
  getPGNameFromId,
  getPaymentMethodOrder,
  handleForexRouting,
  handleGeneralForex,
  isSafari,
  shouldPaymentModuleEnableBlockMode
} from "@/utils";
import { clearEventFlags } from "@/utils/events";
import { handleForexWithLastPayment, handleLimitForex } from "@/utils/payments/exchange";
import { setHeaders } from "@/utils/payments/fraud";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { Divider } from "@mui/material";
import BlockPayment from "../Global/BlockPayment";
import DialogBox from "../Global/Dialog";
import PaymentTerms from "../Global/PaymentTerms";
import CardLayoutSkeleton from "../PaymentMethods/Card/Layout/Skeleton";
import styles from "./portal.module.scss";
import { handleSubscriptionPayment, shouldActivateSkeleton, shouldExcludePayMethodHelper, wallets } from "./util";

const elements: LazyComponentInventory = {
  [PaymentElementEnum.ApplePay]: lazy(() => import("../PaymentMethods/ApplePay")),
  [PaymentElementEnum.GooglePay]: lazy(() => import("../PaymentMethods/GooglePay")),
  [PaymentElementEnum.CardPay]: lazy(() => import("../PaymentMethods/Card"))
};

interface PortalPaymentOptions extends Omit<PaymentOptions, "pg"> {
  pg: PaymentGatewayConfig | PaymentGatewayConfig[];
}

const defaultElements: PaymentElementEnum[] = [
  PaymentElementEnum.CardPay,
  PaymentElementEnum.GooglePay,
  PaymentElementEnum.ApplePay
];

enableMapSet();

const PaymentPortal = ({ elementSequence = defaultElements, ...props }: PortalPaymentOptions, ref: any) => {
  const originalGateways = Array.isArray(props.pg) ? props.pg : [props.pg];

  const { isSubscriptionPayment } = props;

  const exchange = props.qlub?.exchange;
  useSentryInit();
  const { login, isLogin } = useAuth();
  useSnackbar(props.plugins?.snackbar);
  useStorePaymentData(props);
  useLocale(props.locale);
  usePaymentRefFunctionToClient(props.onPaymentMethodSelect);

  const {
    state: { isLocked, priority, forexPGData },
    setConsumer,
    setPriority,
    setPayNowBtnLabelChange,
    setReallocationMode,
    setCountryCode,
    setApplePayConsentCountryFlag,
    setLastPaymentForDefaultSelect,
    resetLastPaymentDefault
  } = useCommonStore((state) => state);

  const { open, title, description, actionButton, icon } = useToastStore((state) => state);

  const gateways = originalGateways;

  const isForexReallocateSupportMode = forexPGData.reallocationMode == 1;

  const {
    setPGGroupStatus,
    setDefaultPGData,
    toggleVisibility,
    setPreferenceStatus,
    state: {
      isPGGroupEnabled,
      availablePGMethods,
      pgGroupInteractionData,
      pgDependedPaymentMethodsData,
      isPreferenceEmpty
    }
  } = usePGGroupStore((state) => state);

  const {
    state: { isMultiUIModeActive, isApplePayEvaluated }
  } = useStripeStore((store) => store);

  const deps = useMemo(() => JSON.stringify(gateways.map((pgItem: any) => pgItem.id)), [gateways.length]);

  const shouldShowSkeleton = useMemo(
    () => !priority.isEnabled && shouldActivateSkeleton(gateways),
    [gateways.length, isApplePayEvaluated, priority.isEnabled]
  );

  const skeletonStyle = shouldShowSkeleton ? { style: { display: "none" } } : {};

  const shouldExcludeMainPaymentMethod = (pg: PaymentGatewayConfig, paymentElement: PaymentElementEnum) => {
    const { config, id } = pg;

    const subscriptionPaymentResult = handleSubscriptionPayment(pg, paymentElement, isSubscriptionPayment);
    if (isBoolean(subscriptionPaymentResult)) return subscriptionPaymentResult;

    if (
      !isForexReallocateSupportMode &&
      priority.isEnabled &&
      (priority.blockedPgs?.includes(id) || !config.priority || config.priority > priority.currentPriority)
    ) {
      return true;
    }

    const forexRoutingResult = handleForexRouting(pg, paymentElement, exchange);
    if (isBoolean(forexRoutingResult)) return forexRoutingResult;

    const limitForexResult = handleLimitForex(pg, paymentElement);
    if (isBoolean(limitForexResult)) return limitForexResult;

    const forexWithLastPaymentResult = handleForexWithLastPayment(pg, paymentElement);
    if (isBoolean(forexWithLastPaymentResult)) return forexWithLastPaymentResult;

    const generalForexResult = handleGeneralForex(pg, paymentElement, exchange);
    if (isBoolean(generalForexResult)) return generalForexResult;

    return shouldExcludePayMethodHelper(pg, paymentElement);
  };

  const shouldExcludeWallet = (pg: PaymentGatewayConfig, paymentElement: PaymentElementEnum) => {
    const { config, id } = pg;

    if (isSubscriptionPayment) return true;

    if (
      !isForexReallocateSupportMode &&
      priority.isEnabled &&
      (priority.blockedPgs?.includes(id) || !config.priority || config.priority > priority.currentPriority)
    ) {
      return true;
    }

    if (paymentElement === PaymentElementEnum.STCPay && !pg.config.extraConfig?.enableStcPay) return true;
    if (paymentElement === PaymentElementEnum.KNET && !pg.config.extraConfig?.enableKnet) return true;
    if (paymentElement === PaymentElementEnum.QPay && !pg.config.extraConfig?.enableQPay) return true;
    if (paymentElement === PaymentElementEnum.MealVoucherPay && !pg.config.extraConfig?.supportMealVoucher) return true;
    if (
      paymentElement === PaymentElementEnum.KNetApplePay &&
      (!pg.config.extraConfig?.enableKNetApplePay || !isSafari())
    )
      return true;
    if (paymentElement === PaymentElementEnum.UnionPay && !pg.config.extraConfig?.enableUnionPay) return true;
    if (paymentElement === PaymentElementEnum.Fps && !pg.config.extraConfig?.enableFps) return true;
    if (paymentElement === PaymentElementEnum.PayNoW && !(pg.config as StripeConfig | StripeConnectConfig).paynow)
      return true;

    return false;
  };

  const renderPGModePayButtonContent = (forOutSideUsage = false) => {
    if (!forOutSideUsage) {
      if (isMultiUIModeActive) return <></>;
      if (pgGroupInteractionData.defaultSelected || pgGroupInteractionData.currentSelected)
        return (
          <>
            <PaymentTerms className={styles.payTerms} />
            <Divider sx={{ margin: "16px 0 0 0" }} />
          </>
        );
    } else {
      if (
        availablePGMethods.length === 1 &&
        !availablePGMethods?.[0]?.includes("card") &&
        !availablePGMethods?.[0]?.includes("fps")
      )
        return (
          <>
            <PaymentTerms className={styles.payTerms} />
            <Divider sx={{ margin: "16px 0 0 0" }} />
          </>
        );
    }

    return <></>;
  };

  const setDefaultPGMethodAccordingToConfig = () => {
    const customOrder = [PaymentElementEnum.ApplePay, PaymentElementEnum.GooglePay, PaymentElementEnum.CardPay];
    const orderMap = zipObject(customOrder, range(customOrder.length));
    const availablePgs = availablePGMethods.map((pg: any) => ({ id: pg.split("-")[0], method: pg.split("-")[1] }));

    const sortedPgs = orderBy(gateways, ["config.pgDefaultSelected", "config.pgOrder"], ["desc", "asc"]);
    const sortedAvailablePgs = orderBy(availablePgs, (pg) => orderMap[pg.method]);

    let defaultPg: any;
    sortedPgs?.forEach((sortedPg) => {
      if (defaultPg) return;

      const defaultSelectedMethods = sortedPg.config.pgDefaultSelectedElem || [];

      if (!isEmpty(defaultSelectedMethods)) {
        sortedAvailablePgs?.forEach((availablePg: any) => {
          if (defaultPg) return;

          if (sortedPg.id === availablePg.id) {
            defaultSelectedMethods?.forEach((method: string) => {
              if (defaultPg) return;

              if (method === availablePg.method) {
                defaultPg = {
                  pgId: sortedPg.id,
                  paymentMethod: method,
                  name: sortedPg.name
                };
              }
            });
          }
        });
      }
    });

    if (!defaultPg) {
      defaultPg = {
        pgId: sortedAvailablePgs[0].id,
        paymentMethod: sortedAvailablePgs[0].method,
        name: getPGNameFromId(sortedAvailablePgs[0].id, originalGateways)
      };
    }

    setDefaultPGData(defaultPg || {});
  };

  const setDefaultPGMethodAccordingToProfile = (paymentProfile: PaymentProfile) => {
    const name = paymentProfile.lastPayment.paymentMethod;
    const pgName = paymentProfile.lastPayment.paymentGateway || "";

    const lastUsedData = { pgName, method: name };

    const mappedAvailablePGMethods = availablePGMethods.map(
      (pgSignature: string) =>
        `${getPGNameFromId(pgSignature.split("-")?.[0], originalGateways)}-${pgSignature.split(
          "-"
        )?.[1]}-${pgSignature.split("-")?.[0]}`
    );

    const isMatchedWithPGAndMethod = mappedAvailablePGMethods.find((pgSignature: string) =>
      pgSignature.startsWith(`${lastUsedData.pgName}-${lastUsedData.method}`)
    );

    const matchedPGId = isMatchedWithPGAndMethod?.split("-")?.[2];

    if (matchedPGId) {
      setLastPaymentForDefaultSelect({
        id: matchedPGId,
        method: lastUsedData.method ?? "",
        name: lastUsedData.pgName
      });
      setDefaultPGData({
        pgId: matchedPGId,
        paymentMethod: lastUsedData.method,
        name: lastUsedData.pgName
      });
    } else {
      setDefaultPGMethodAccordingToConfig();
    }
  };

  const availablePaymentMethods = useMemo(() => {
    const paymentMethods: {
      element: ComponentType<any>;
      pg: PaymentGatewayConfig;
      name: PaymentElementEnum;
      order: number;
    }[] = [];

    gateways?.forEach((pg) => {
      /** add google,apple, card pay */
      elementSequence?.forEach((pm) => {
        if (!shouldExcludeMainPaymentMethod(pg, pm)) {
          paymentMethods.push({
            name: pm,
            element: elements[pm],
            pg,
            order: getPaymentMethodOrder(pm, pg.config, pg.name)
          });
        }
      });

      /** add wallets */
      wallets[pg.name]?.forEach((wallet) => {
        if (!shouldExcludeWallet(pg, wallet.name)) {
          paymentMethods.push({
            name: wallet.name,
            element: wallet.element,
            pg,
            order: getPaymentMethodOrder(wallet.name, pg.config, pg.name)
          });
        }
      });
    });

    setPaymentMethods(paymentMethods.map((pm) => ({ name: pm.name, pg: pm.pg })));

    return paymentMethods;
  }, [
    props.totalAmount,
    props.amount,
    props.qlub?.tip,
    props.qlub?.exchange,
    isPGGroupEnabled,
    availablePGMethods,
    pgGroupInteractionData,
    pgDependedPaymentMethodsData,
    isPreferenceEmpty,
    exchange,
    priority,
    isForexReallocateSupportMode,
    gateways,
    isSubscriptionPayment
  ]);

  useEffect(() => {
    setPGGroupStatus(props.hasPgGroup);
    setConsumer(props.consumer);
  }, [props.hasPgGroup]);

  useEffect(() => {
    const minPriority = minBy(gateways, "config.extraConfig.priority")?.config?.extraConfig?.priority;
    setPriority({ isEnabled: !!minPriority, currentPriority: minPriority });
  }, []);

  useEffect(() => {
    const evaluatePGGroupView = () => {
      const size = availablePGMethods.length;
      if (size && !exchange?.isInterrupted) {
        if (size === 1) {
          setPGGroupStatus(false);
          const pgData = availablePGMethods?.[0]?.split("-");
          if (pgData.length >= 2) {
            setDefaultPGData({
              pgId: pgData[0],
              paymentMethod: pgData[1],
              name: getPGNameFromId(pgData[0], originalGateways)
            });
          }
        } else {
          setPGGroupStatus(true);
        }
      }
    };
    if (props.hasPgGroup) evaluatePGGroupView();
  }, [availablePGMethods, props.hasPgGroup, priority]);

  useEffect(() => {
    const defElements = gateways.flatMap((pgItem: any) => pgItem.config.extraConfig.pgDefaultSelectedElem ?? []);
    if (defElements.length === 0) setPreferenceStatus(true);
  }, [deps]);

  useEffect(() => {
    if (availablePGMethods?.length && isPGGroupEnabled && gateways.length && !exchange?.isInterrupted) {
      const paymentProfile = getPaymentProfile();
      const restaurantConfig = gateways[0]?.vendor.config;
      const doesPayNowExist = some(availablePGMethods, (pg) => endsWith(pg, PaymentElementEnum.PayNoW));

      if (paymentProfile?.lastPayment?.paymentMethod && restaurantConfig.enableDynamicPreselect && !doesPayNowExist) {
        setDefaultPGMethodAccordingToProfile(paymentProfile);
      } else {
        resetLastPaymentDefault();
        setDefaultPGMethodAccordingToConfig();
      }
    }
  }, [availablePGMethods, isPGGroupEnabled, isPreferenceEmpty, priority]);

  useEffect(() => {
    if (
      ROUTING_OVERIDING_COUNTRIES.includes(props.countryCode?.toLowerCase() ?? "") &&
      exchange?.paymentMethod &&
      exchange?.isRoutingApplied &&
      pgGroupInteractionData.currentSelected &&
      !availablePGMethods?.includes(pgGroupInteractionData.currentSelected)
    ) {
      const findSubstitute = availablePGMethods.find((pgSignature: string) =>
        pgSignature.includes(pgGroupInteractionData.currentSelected?.split("-")?.[1] ?? "")
      );

      if (findSubstitute) {
        const pgData = findSubstitute.split("-");
        toggleVisibility({
          pgId: pgData?.[0],
          paymentMethod: pgData?.[1],
          name: getPGNameFromId(pgData?.[0], originalGateways)
        });
      }
    }
  }, [availablePGMethods]);

  useEffect(() => {
    const isPayButtonTextChangeEnabled = originalGateways?.[0]?.vendor.config.changePayNowButtonTextForSG === "enable";
    if (isPayButtonTextChangeEnabled) {
      setPayNowBtnLabelChange(isPayButtonTextChangeEnabled);
    }
  }, [props.pg]);

  useEffect(() => {
    if (props.countryCode) setCountryCode(props.countryCode);

    if (props.vendor?.country?.config?.enableConsentApplePay)
      setApplePayConsentCountryFlag(props.vendor?.country?.config?.enableConsentApplePay);
  }, [props.countryCode, props.vendor?.country?.config?.enableConsentApplePay]);

  useEffect(() => {
    setHeaders();
    clearEventFlags();
    return () => resetForex();
  }, []);

  useEffect(() => {
    if (forexPGData.reallocationMode === 0 && originalGateways) {
      const doesReallocatePGExist = originalGateways.find(
        (pg) => pg.config.extraConfig?.forexPgReallocationSupportedPaymentMethods
      );

      if (doesReallocatePGExist) setReallocationMode(1);
      else setReallocationMode(2);
    }
  }, [originalGateways]);

  useEffect(() => {
    if (!isLogin) {
      login({ guest: true });
    }
  }, [isLogin]);

  if (!gateways.length) return null;

  if (
    shouldPaymentModuleEnableBlockMode(
      gateways?.[0]?.vendor?.country?.config?.enableBlockPayment,
      gateways?.[0]?.vendor?.config?.enableBlockPayment
    )
  )
    return <BlockPayment />;

  return (
    <PaymentProvider>
      <CardProvider>
        <>
          <Head>
            <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1" />
          </Head>
          <Suspense fallback={<Fragment />}>
            <div style={{ width: "100%" }}>
              <DialogBox
                open={open}
                title={title}
                description={description}
                action={actionButton ?? <></>}
                icon={icon ?? <></>}
              />
              {isLocked && <div className={styles.lockOverlay} />}
              {!isPGGroupEnabled && <div>{renderPGModePayButtonContent(true)}</div>}
              {shouldShowSkeleton && <CardLayoutSkeleton />}
              <div id="pg-container" className={styles.base} {...skeletonStyle}>
                {availablePaymentMethods?.map((pm) => {
                  const Element = pm.element;
                  return (
                    <div style={{ order: pm.order }} className={styles.pgMethodContainer}>
                      <Element {...props} pg={pm.pg} />
                    </div>
                  );
                })}
              </div>
            </div>
          </Suspense>

          <div {...(!isPGGroupEnabled ? { style: { width: "100%", display: "none" } } : { width: "100%" })}>
            {renderPGModePayButtonContent()}
            <div id="pg-group-paybtn-container" className={styles.pgGroupBtnContainer} ref={ref} {...skeletonStyle} />
          </div>
        </>
      </CardProvider>
    </PaymentProvider>
  );
};

export default forwardRef(PaymentPortal);
