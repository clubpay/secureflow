import { ComponentType } from "react";
import dynamic from "next/dynamic";
import { useStripeStore } from "@/stores/stripeStore";
import { PaymentGatewayConfig } from "@/types";
import { isSafari } from "@/utils";
import { PGNameEnum, PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";

interface PaymentMethodConditions {
  applePay?: boolean;
  card?: boolean;
}

const gPayAndApplePayDirectUnsupportList = [
  "stripeConnect",
  "stripeconnect",
  PGNameEnum.Stripe,
  PGNameEnum.StripeConnect,
  PGNameEnum.Moyasar,
  PGNameEnum.Ticket,
  PGNameEnum.MasterPass,
  PGNameEnum.MasterPassDirect,
  PGNameEnum.Divit,
  PGNameEnum.Moneyhash
];

const applePayUnavailableList = [""];

const googlePayUnavailableList = ["mashreq", "ngenius", "moyasarV2", "moyasarv2"];

export const shouldExcludePayMethodHelper = (
  pg: PaymentGatewayConfig,
  paymentElement: PaymentElementEnum,
  conditons?: PaymentMethodConditions
) => {
  const { name, config } = pg;

  if (paymentElement === PaymentElementEnum.ApplePay) {
    return !!(
      applePayUnavailableList.includes(name) ||
      gPayAndApplePayDirectUnsupportList.includes(name) ||
      config.extraConfig.hideApplePay ||
      !isSafari() ||
      conditons?.applePay
    );
  }
  if (paymentElement === PaymentElementEnum.GooglePay) {
    return !!(
      googlePayUnavailableList.includes(name) ||
      gPayAndApplePayDirectUnsupportList.includes(name) ||
      config.extraConfig.hideGooglePay ||
      (pg.name !== "tuna" && isSafari())
    );
  }

  if (paymentElement === PaymentElementEnum.CardPay) {
    return !!(config.extraConfig.hideCardPay || conditons?.card);
  }

  return false;
};

export const wallets: { [key: string]: { name: PaymentElementEnum; element: ComponentType<any> }[] } = {
  [PGNameEnum.Tuna]: [
    { name: PaymentElementEnum.PixPay, element: dynamic(() => import("../PaymentMethods/Wallets/Gateways/Tuna/Pix")) },
    {
      name: PaymentElementEnum.MealVoucherPay,
      element: dynamic(() => import("../PaymentMethods/Wallets/Gateways/Tuna/MealVoucher"))
    }
  ],
  [PGNameEnum.Checkout]: [
    {
      name: PaymentElementEnum.STCPay,
      element: dynamic(() => import("../PaymentMethods/Wallets/Gateways/Checkout/StcPay"))
    },
    {
      name: PaymentElementEnum.KNET,
      element: dynamic(() => import("../PaymentMethods/Wallets/Gateways/Checkout/KNet"))
    },
    {
      name: PaymentElementEnum.QPay,
      element: dynamic(() => import("../PaymentMethods/Wallets/Gateways/Checkout/QPay"))
    }
  ],
  [PGNameEnum.Moyasar]: [
    {
      name: PaymentElementEnum.STCPay,
      element: dynamic(() => import("../PaymentMethods/Wallets/Gateways/Moyasar/StcPay"))
    }
  ],
  [PGNameEnum.MoyasarV2]: [
    {
      name: PaymentElementEnum.STCPay,
      element: dynamic(() => import("../PaymentMethods/Wallets/Gateways/Moyasar/StcPay"))
    }
  ],
  [PGNameEnum.MyFatoorah]: [
    {
      name: PaymentElementEnum.KNetApplePay,
      element: dynamic(() => import("../PaymentMethods/Wallets/Gateways/MyFatoorah/KNetApplePay"))
    },
    {
      name: PaymentElementEnum.KNET,
      element: dynamic(() => import("../PaymentMethods/Wallets/Gateways/MyFatoorah/KNet"))
    }
  ],
  [PGNameEnum.NGenius]: [
    {
      name: PaymentElementEnum.UnionPay,
      element: dynamic(() => import("../PaymentMethods/Wallets/Gateways/Ngenius/UnionPay"))
    }
  ],
  [PGNameEnum.Divit]: [
    {
      name: PaymentElementEnum.Fps,
      element: dynamic(() => import("../PaymentMethods/Wallets/Gateways/Divit/Fps"))
    }
  ],
  [PGNameEnum.Stripe]: [
    {
      name: PaymentElementEnum.PayNoW,
      element: dynamic(() => import("../PaymentMethods/Wallets/Gateways/Stripe/PayNow"))
    }
  ],
  [PGNameEnum.StripeConnect]: [
    {
      name: PaymentElementEnum.PayNoW,
      element: dynamic(() => import("../PaymentMethods/Wallets/Gateways/StripeConnect/PayNow"))
    }
  ]
};
export const handleSubscriptionPayment = (
  pg: PaymentGatewayConfig,
  paymentElement: PaymentElementEnum,
  isSubscriptionPayment?: boolean
) => {
  if (isSubscriptionPayment) {
    /** enable subscription payment for checkout card and applepay */
    if (
      pg.name === PGNameEnum.Checkout &&
      (paymentElement === PaymentElementEnum.ApplePay || paymentElement === PaymentElementEnum.CardPay)
    ) {
      return shouldExcludePayMethodHelper(pg, paymentElement);
    } else return true;
  }
  return null;
};
export const shouldHideViaCSS = (pgName: string, config: any) => {
  const store = useStripeStore.getState();

  console.log("shouldHideViaCSS", store.state.isMultiUIModeActive);
  switch (pgName) {
    case "stripe":
      if (config.hideCardElement) return "none";
      return "block";
    case "stripeConnect":
    case "stripeconnect":
      if (config.hideCardElement && !store.state.isMultiUIModeActive) return "none";
      return "block";
    default:
      return "block";
  }
};

export const shouldActivateSkeleton = (gateways: any[]) => {
  const stripeEnums = ["stripeConnect", PGNameEnum.StripeConnect, "stripeconnect"];
  const isApplePayEvaluated = useStripeStore.getState().state.isApplePayEvaluated;

  const pgNames = gateways?.map((pg: any) => pg.name);
  const set1 = new Set(stripeEnums);
  const matches = pgNames.filter((value) => set1.has(value));

  if (matches.length) return !isApplePayEvaluated;

  return false;
};
