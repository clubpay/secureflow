import React, { ReactNode, lazy, useEffect } from "react";
import { Button, Checkbox, Divider } from "@/components/Core";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import ReactPortal from "@/components/Global/ReactPortal";
import { Amex, JCB, Mastercard, UnionPay, Visa } from "@/icons";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { hasSavedCardClicked, useCardStore } from "@/stores/cardStore";
import { useCommonStore } from "@/stores/commonStore";
import { usePGGroupStore } from "@/stores/pgGroupStore";
import { isPaymethodChoosed } from "@/stores/pgGroupStore";
import { ConsumerTypes, KeyValue, PaymentOptions } from "@/types";
import { getExpiryPlaceHolder } from "@/utils";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { Box, Skeleton } from "@mui/material";
import Collapse from "@mui/material/Collapse";
import AddCard from "../components/common/AddCard";
import styles from "./layout.module.scss";

const PaymentTerms = lazy(() => import("@/components/Global/PaymentTerms"));
const SecureTagline = lazy(() => import("@/components/Global/SecureTagline"));

export interface Extras extends KeyValue {
  saveCard: boolean;
}

interface Atoms {
  card: React.FC;
  expiry?: React.FC;
  cvv: React.FC;
  name?: React.FC;
  expiryMonth?: React.FC;
  expiryYear?: React.FC;
}

interface CardLayoutProps extends PaymentOptions {
  elements: Atoms | React.ReactNode;
  formAttributes?: React.FormHTMLAttributes<HTMLFormElement> | undefined;
  onSubmit?: (
    e: React.MouseEvent<HTMLButtonElement>,
    extra?: Extras
  ) => Promise<void> | ((e: React.MouseEvent<HTMLButtonElement>, extra: Extras) => void);
  disablePayButton?: boolean;
  api?: {
    cardStorage?: {
      fetchSavedCards: Function;
    };
  };
  isSaveCardSelected?: boolean;
  slots?: React.ReactNode[] | any;
  paymentCallbackFn?: any;
  hide?: boolean;
  onAddCard?: Function;
  visible?: boolean;
  isAdding?: boolean;
  locale: string;
  paymentMethodData?: any;
  savedCardSlot?: React.ReactNode;
  icons?: React.ReactNode[];
  amount?: any;
  onPGElementClick?: Function;
  shouldPayBtnEnable?: () => boolean;
  loading?: boolean;
  addCardText?: string;
}

const CardLayout = ({
  variant,
  elements,
  formAttributes = {},
  onSubmit,
  disablePayButton = false,
  tagline = true,
  networks = true,
  enableCardSaving,
  paymentTerms: paymentTermAttributes,
  pg,
  isSaveCardSelected,
  paymentCallbackFn: parentPaymentCallbackFn,
  hide = false,
  loading = false,
  slots,
  onAddCard,
  isAdding,
  paymentMethodData = {},
  savedCardSlot,
  amount,
  qlub,
  onPGElementClick,
  shouldPayBtnEnable,
  icons,
  addCardText
}: CardLayoutProps) => {
  const { name, icon, element } = paymentMethodData;

  const pgSignature = `${pg.id}-${element ?? PaymentElementEnum.CardPay}`;

  const { processing } = usePayment();

  const { setSaveCard } = useCardStore((store) => store);

  const isSavedCard = hasSavedCardClicked(pgSignature);

  const {
    state: { consumer }
  } = useCommonStore((state: any) => state);

  const addCardModeActive = Boolean(onAddCard);

  const paymentCallbackFn = parentPaymentCallbackFn
    ? parentPaymentCallbackFn
    : (event: React.MouseEvent) => onSubmit?.(event as any);

  const localOnSubmit = (e: React.MouseEvent) => {
    e.preventDefault();

    if (pg.config.events?.onPrePayment)
      pg.config.events?.onPrePayment(paymentCallbackFn, element || PaymentElementEnum.CardPay);
    else {
      paymentCallbackFn(e);
    }
  };

  const { toggleVisibility, state, setAddPGMethod, setPaymentMethodReference, removePGMethod } = usePGGroupStore(
    (state) => state
  );
  const hasPgGroup = state.isPGGroupEnabled;

  const hasChoosen = isPaymethodChoosed({ pgId: pg.id, paymentMethod: element || PaymentElementEnum.CardPay });

  const handleShouldPayBtnEnable = () => {
    if (shouldPayBtnEnable) return shouldPayBtnEnable();

    return !(disablePayButton || processing);
  };

  const buttonElement = (
    <Button
      id="payment-action-btn"
      variant={variant}
      className={styles["pay-btn"]}
      type="submit"
      disabled={!handleShouldPayBtnEnable()}
      loading={processing}
      onClick={localOnSubmit}
    >
      {t("Pay")}
    </Button>
  );

  const getStyles = () => {
    if (hide)
      return {
        display: "none"
      };

    if (hasPgGroup) {
      if (hasChoosen)
        return {
          display: "block"
        };

      return {
        display: "none"
      };
    }
    return {
      display: "block"
    };
  };

  const getStylesForBody = () => {
    return {
      display: isSaveCardSelected ? "none" : "block",
      paddingTop: hasPgGroup && !addCardModeActive ? "18px" : "0"
    };
  };

  const checkSaveCardCheckbox = () => setSaveCard(pgSignature);

  const getAvailablePayIcons = () => {
    const icons: any[] = [];

    const supportNetworksList =
      pg.config.extraConfig.supportedNetworksList ?? pg.config.extraConfig.supportedNetworks ?? [];

    const isAmexDisabled = pg.config.extraConfig?.disableAmexCard;

    if (supportNetworksList.length === 0) return [<Visa />, <Mastercard />, <Amex />, <JCB />, <UnionPay />];

    if (supportNetworksList?.includes("visa")) {
      icons.push(<Visa />);
    }
    if (supportNetworksList?.includes("masterCard")) {
      icons.push(<Mastercard />);
    }
    if (supportNetworksList?.includes("amex") && !isAmexDisabled) {
      icons.push(<Amex />);
    }
    if (supportNetworksList?.includes("jcb")) {
      icons.push(<JCB />);
    }
    if (supportNetworksList?.includes("unionPay") || supportNetworksList?.includes("chinaUnionPay")) {
      icons.push(<UnionPay />);
    }
    return icons;
  };

  const layoutBody = (
    <div className="card-layout-container">
      <form className={`${styles.form} ${formAttributes?.className ?? ""}`} {...formAttributes}>
        <div className={styles.container} style={getStylesForBody()}>
          {typeof elements === "object" && elements !== null && "card" in elements ? (
            <div className={styles["element-container"]}>
              {elements?.name && (
                <div className={styles["card-element-row"]}>
                  {elements?.name?.({
                    id: "cardHolder",
                    label: t("Cardholder Name"),
                    placeholder: t("Cardholder Name"),
                    variant
                  })}
                </div>
              )}

              {elements.card({ label: t("Card number"), placeholder: t("4242 4242 4242 4242"), variant })}
              {networks && <div className={styles.schemes}>{icons ?? getAvailablePayIcons()}</div>}
              <div className={styles["card-element-row"]}>
                {elements?.expiry ? (
                  elements.expiry({
                    id: "expirationDate",
                    name: "expirationDate",
                    label: t("Expiry date"),
                    placeholder: getExpiryPlaceHolder(),
                    variant
                  })
                ) : (
                  <div className={styles["month-year-container"]}>
                    {elements?.expiryMonth &&
                      elements?.expiryMonth({
                        id: "expirationDate",
                        label: t("Expiry month"),
                        placeholder: getExpiryPlaceHolder("month"),
                        variant
                      })}
                    {elements?.expiryYear &&
                      elements?.expiryYear({
                        label: t("Expiry year"),
                        placeholder: getExpiryPlaceHolder("year"),
                        variant
                      })}
                  </div>
                )}
                {elements.cvv({ label: t("Security code"), placeholder: "123", variant })}
              </div>
            </div>
          ) : (
            elements
          )}
          {enableCardSaving && (
            <div style={{ paddingTop: "6px" }}>
              <Checkbox
                label={t("Save this card")}
                checked={isSavedCard}
                onChange={(_value) => setSaveCard(pgSignature)}
                className={styles["save-card"]}
              />
            </div>
          )}
        </div>
        <div className={styles["submit-area"]}>
          {Array.isArray(slots) && slots.map((item: ReactNode | boolean) => item)}
          {tagline && <SecureTagline />}
          {!hasPgGroup && (
            <>
              <PaymentTerms className={styles.terms} {...paymentTermAttributes} />
              <Divider />
              {pg.config?.enableCardPayment && buttonElement}
            </>
          )}
        </div>
      </form>
    </div>
  );

  const renderContent = () => {
    if (!addCardModeActive) return layoutBody;
    return (
      <Collapse in={isAdding} style={isAdding ? { paddingTop: "12px" } : {}}>
        {layoutBody}
      </Collapse>
    );
  };

  const renderPGElementBox = () => {
    if (hide || !hasPgGroup) return null;

    return (
      <PGPaymentBox
        name={name || t("Card")}
        icon={icon}
        selected={hasChoosen}
        toggleVisibility={() => {
          onPGElementClick?.();
          toggleVisibility({ pgId: pg.id, paymentMethod: element || PaymentElementEnum.CardPay });
        }}
      />
    );
  };

  useEffect(() => {
    setPaymentMethodReference({
      pgId: pg.id,
      paymentMethod: element || PaymentElementEnum.CardPay,
      fn: paymentCallbackFn
    });
  }, [amount, isSaveCardSelected, qlub?.tip]);

  useEffect(() => {
    if (enableCardSaving) {
      checkSaveCardCheckbox();
    }
  }, [enableCardSaving]);

  useEffect(() => {
    if (!hide) {
      setAddPGMethod({ pgId: pg.id, paymentMethod: element || PaymentElementEnum.CardPay });
    }
  }, [hide]);

  useEffect(() => {
    return () => removePGMethod({ pgId: pg.id, paymentMethod: element || PaymentElementEnum.CardPay });
  }, []);

  return (
    <>
      <div id="npm-layout-container">
        {renderPGElementBox()}
        <div style={typeof loading !== "undefined" ? { display: loading ? "none" : "block" } : {}}>
          {savedCardSlot && <div className={styles.savedCardContainer}>{savedCardSlot}</div>}
          <div style={getStyles()}>
            {addCardModeActive && (
              <div
                className="add-card-container"
                style={{
                  marginTop: "1rem"
                }}
              >
                <AddCard isAdding={isAdding} onToggle={() => onAddCard?.()} text={addCardText} />
              </div>
            )}
            {renderContent()}
          </div>
        </div>
        {loading && (
          <div style={getStyles()}>
            <Skeleton height="64px" width="100%" />
            <Box display="flex" gap={1}>
              <Skeleton height="64px" width="50%" />
              <Skeleton height="64px" width="50%" />
            </Box>
            <Skeleton height="64px" width="100%" />
          </div>
        )}
      </div>
      {hasChoosen && (
        <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{buttonElement}</ReactPortal>
      )}
    </>
  );
};

export default CardLayout;
