import { Divider, Skeleton } from "@/components/Core";
import layoutStyles from "../layout.module.scss";
import styles from "./skeleton.module.scss";

const CardLayoutSkeleton = () => {
  return (
    <div className={styles.base}>
      <div className={layoutStyles.container}>
        <div className={layoutStyles["element-container"]}>
          <Skeleton className={styles.input} />
          <Skeleton containerClassName={styles["schemes"]} className={styles["card-scheme"]} count={5} />
          <div className={layoutStyles["card-element-row"]}>
            <Skeleton containerClassName={styles.input} />
            <Skeleton containerClassName={styles.input} />
          </div>
        </div>
        <Skeleton className={styles["save-card"]} />
      </div>
      <div className={layoutStyles["submit-area"]}>
        <Skeleton containerClassName={styles["tagline-container"]} className={styles["tagline"]} count={2} />
        <Divider className={styles["divider"]} />
        <Skeleton className={styles["pay-btn"]} />
      </div>
    </div>
  );
};

export default CardLayoutSkeleton;
