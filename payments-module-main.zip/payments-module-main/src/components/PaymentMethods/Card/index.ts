export { default, CardPayPortal } from "./Portal";
