import { Suspense, lazy } from "react";
import { shouldHideViaCSS } from "@/components/PaymentPortal/util";
import { useLocale, useSnackbar } from "@/hooks";
import { CardStorageProvider, PaymentProvider } from "@/providers";
import { LazyComponentInventory, PaymentGateways, PaymentOptions } from "@/types";
import { default as CardLayoutSkeleton } from "./Layout/Skeleton";

const gateways: LazyComponentInventory = {
  checkout: lazy(() => import("./Gateways/Checkout")),
  maf: lazy(() => import("./Gateways/Maf")),
  mafv2: lazy(() => import("./Gateways/Maf")),
  stripe: lazy(() => import("./Gateways/Stripe")),
  stripeconnect: lazy(() => import("./Gateways/StripeConnect")),
  stripeConnect: lazy(() => import("./Gateways/StripeConnect")),
  moyasar: lazy(() => import("./Gateways/Moyasar")),
  tuna: lazy(() => import("./Gateways/Tuna")),
  ngenius: lazy(() => import("./Gateways/Ngenius")),
  mashreq: lazy(() => import("./Gateways/Mashreq")),
  ticketpg: lazy(() => import("./Gateways/Ticket")),
  masterpass: lazy(() => import("./Gateways/Masterpass")),
  masterpassdirect: lazy(() => import("./Gateways/MasterpassDirect")),
  ccpp: lazy(() => import("./Gateways/CCPP")),
  moyasarV2: lazy(() => import("./Gateways/Moyasar")),
  moyasarv2: lazy(() => import("./Gateways/Moyasar")),
  adyen: lazy(() => import("./Gateways/Adyen")),
  tyro: lazy(() => import("./Gateways/Tyro")),
  myfatoorah: lazy(() => import("./Gateways/MyFatoorah")),
  moneyhash: lazy(() => import("./Gateways/Moneyhash"))
};

export const CardPayPortal = (props: PaymentOptions) => {
  const Gateway = gateways[props.pg?.name ?? PaymentGateways.Checkout];

  useLocale(props.locale);
  useSnackbar(props.plugins?.snackbar);

  if (!Gateway) return null;

  return (
    <div
      style={{
        display: shouldHideViaCSS(props.pg.name, props.pg.config.extraConfig)
      }}
    >
      <PaymentProvider>
        <CardStorageProvider>
          <Suspense fallback={<CardLayoutSkeleton />}>{<Gateway {...props} />}</Suspense>
        </CardStorageProvider>
      </PaymentProvider>
    </div>
  );
};

export default CardPayPortal;
