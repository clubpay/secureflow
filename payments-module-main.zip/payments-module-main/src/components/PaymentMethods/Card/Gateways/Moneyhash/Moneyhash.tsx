import { useEffect, useRef } from "react";
import PaymentAPIManager from "@/api/gateways";
import { useLockUnlock, useSentry } from "@/hooks";
import { useExchangeInterruption } from "@/hooks/exchange";
import { useMoneyhashElements } from "@/hooks/moneyhash";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { usePayment } from "@/providers";
import { usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { MoneyhashConfig } from "@/types/payments/config/moneyhash";
import { getPaymentExchangeDecision } from "@/utils/payments/exchange";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { IntentStateDetails } from "@moneyhash/js-sdk/headless";
import CardLayout from "../../Layout/layout";

const Moneyhash = (props: PaymentOptions) => {
  const { variant = "primary", amount, qlub, pg, country, locale, consumer } = props;

  const gatewayId = pg.id;
  const pgName = pg.name;
  const pgConfig = pg.config as MoneyhashConfig;
  const isSplitPayment = qlub.isSplitPayment;
  const exchange = qlub?.exchange;
  const tipAmount = qlub?.tip ?? 0;
  const billAmount = amount;
  const diningSessionId = qlub.diningSessionId!;
  const { onBeforePayment, onPaymentFailure, onPrePayment, onPaymentPending } = pgConfig.events;
  const api = (pgConfig.apiManager ?? PaymentAPIManager.getInstance()).moneyhash;

  const reference = useRef<string>();

  const { setProcessing } = usePayment();
  const { startTrace, captureException } = useSentry(props);

  const { cardNumber, expiryMonth, expiryYear, cvv, submitCard, pay, handle3ds, getBinDetails } = useMoneyhashElements({
    pgConfig,
    onComplete: () => onPaymentPending({ paymentElement: PaymentElementEnum.CardPay, refId: reference.current }),
    onFail: () => onPaymentFailure({ paymentElement: PaymentElementEnum.CardPay, refId: reference.current })
  });

  const { setAddPGMethod, removePGMethod, setPaymentMethodReference } = usePGGroupStore((state) => state);
  const { lock, unlock } = useLockUnlock(props);
  const { getCallbackUrl } = useConfirmCallback();
  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });
  const { triggerInterruption } = useExchangeInterruption({
    paymentOptions: props,
    paymentMethod: PaymentElementEnum.CardPay
  });
  const paymentCallBack = async () => {
    startTrace("pay", PaymentElementEnum.CardPay, async () => {
      reference.current = getRandomString();
      const event = {
        paymentElement: PaymentElementEnum.CardPay,
        refId: reference.current
      };

      try {
        const returnUrl = getCallbackUrl({
          ref: reference.current,
          method: pgName,
          paymentElement: PaymentElementEnum.UnionPay,
          dsi: diningSessionId,
          currencySymbol: country,
          amount: amount,
          lang: locale
        });

        setProcessing(true);
        const { cardData, validationError } = await submitCard();
        if (validationError) return;

        const binResponse = await getBinDetails(cardData!);

        const onBeforeResponse = await onBeforePayment({
          gatewayId,
          paymentElement: PaymentElementEnum.CardPay,
          tip: tipAmount
        });
        if (!onBeforeResponse) return;

        const lockResponse = await lock(event);
        if (!lockResponse) return;

        const exchangeDecision = getPaymentExchangeDecision(exchange, pgName);

        saveLastPayment();

        const paymentResponse = await api.payByCard({
          id: getSession(),
          tipAmount: tipAmount?.toFixed(qlub?.currencyPrecision || 0),
          diningSessionID: diningSessionId,
          gatewayID: gatewayId,
          reference: reference.current,
          bin: binResponse?.firstSixDigits,
          last4: cardData?.last_four_digits,
          cardBrand: binResponse?.brand,
          cardType: binResponse?.cardType,
          productType: binResponse?.product,
          issuerCountry: binResponse?.issuerCountryCode,
          pendingUrl: returnUrl.pending,
          exchangeDecision,
          isSplitPayment,
          annotations: {
            paymentMethod: PaymentElementEnum.CardPay,
            funnel: consumer
          }
        });

        const intentId = paymentResponse.data.intentId;

        if (paymentResponse.data.exchangeData) {
          unlock();
          triggerInterruption(paymentResponse.data);
          return;
        }

        const response = await pay({ intentId, cardData: cardData! });
        const stateDetails = response?.stateDetails as IntentStateDetails<"URL_TO_RENDER">;

        if (response?.state === "URL_TO_RENDER") {
          await handle3ds(intentId, stateDetails.url);
        } else if (response?.state === "INTENT_PROCESSED") {
          onPaymentPending(event);
        } else {
          onPaymentFailure(event);
        }
      } catch (error: any) {
        captureException(error);
        onPaymentFailure(event);
      } finally {
        unlock();
        setProcessing(false);
      }
    });
  };

  const handlePay = async () => {
    if (onPrePayment) onPrePayment(paymentCallBack, PaymentElementEnum.CardPay);
    else paymentCallBack();
  };

  useEffect(() => {
    setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay });
    return () => removePGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay });
  }, []);

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.CardPay,
      fn: paymentCallBack
    });
  }, [billAmount, tipAmount]);

  return (
    <>
      <CardLayout
        elements={{ card: cardNumber, expiryMonth, expiryYear, cvv }}
        variant={variant}
        onSubmit={handlePay}
        {...props}
      />
    </>
  );
};

export default Moneyhash;
