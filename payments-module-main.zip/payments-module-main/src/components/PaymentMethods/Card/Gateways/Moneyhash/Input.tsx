import { ReactElement } from "react";
import classNames from "classnames";
import styles from "./Moneyhash.module.scss";

interface Props {
  id: string;
  label: string;
  error: string;
  icon: ReactElement;
}

const Input = ({ id, label, error, icon }: Props) => {
  return (
    <div className={styles.container}>
      <div className={styles.icon}>{icon}</div>
      <label className={styles.label}>{label}</label>
      <div id={id} className={classNames(styles.input)} />
      {error && <div className={styles.errorLabel}>{error}</div>}
    </div>
  );
};

export default Input;
