import * as valid from "card-validator";
import { isEmpty, keys, pickBy } from "lodash";
import { ErrorMessageKey, ErrorMessages } from "@/utils";

type CardBrandType = "visa" | "master" | "mastercard" | "amex" | "american express" | "vr" | "sodexo" | "unknown";

const CardTypes = {
  "american-express": "amex",
  "visa": "Visa",
  "mastercard": "Mastercard"
};

export const parseExpirationDate = (expirationDate?: string) => {
  const [expMonth = null, expYearRaw = null] = expirationDate?.split("/").map((e) => e.trim()) ?? [];
  const expYear = expYearRaw?.length === 2 ? `20${expYearRaw}` : expYearRaw;

  return { expYear, expMonth };
};

export const parseBrand = (bin: string): CardBrandType => {
  const cardInfo = valid.number(bin);
  if (cardInfo.card) {
    return CardTypes[cardInfo.card.type as keyof typeof CardTypes] as CardBrandType;
  }
  return "unknown";
};

export const extractTunaError = (error: any) => {
  if (error.toString().includes("[ERR:07]")) {
    return ErrorMessages[ErrorMessageKey.Generic];
  }
  return null;
};

export const validateFormState = (formState: any) => {
  const emptyFields = keys(pickBy(formState, isEmpty));

  if (!emptyFields?.length) return false;

  if (emptyFields.length > 1) return ErrorMessages[ErrorMessageKey.Generic];

  return ErrorMessages[emptyFields?.[0] as ErrorMessageKey] || null;
};

export const validateCardNumber = (cardNo: string, cvv: string) => {
  const cardNumber = cardNo.replace(/\s/g, "");

  if (cardNumber.length < 15) return ErrorMessages[ErrorMessageKey.Card];

  if (cardNumber.length === 15) {
    const ammexRegex = /^3[47][0-9]{13}$/;

    if (!ammexRegex.test(cardNumber)) {
      return ErrorMessages[ErrorMessageKey.Card];
    }

    if (ammexRegex.test(cardNumber) && cvv.length !== 4) {
      return ErrorMessages[ErrorMessageKey.Cvv];
    }

    return false;
  }

  if (cardNumber.length === 16) {
    if (cvv.length !== 3) {
      return ErrorMessages[ErrorMessageKey.Cvv];
    }

    return false;
  }
  return false;
};
