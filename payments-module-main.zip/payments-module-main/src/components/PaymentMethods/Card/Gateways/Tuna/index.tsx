import TunaCloak from "@/components/GatewayCloaks/TunaCloak";
import { useSnackbar } from "@/hooks";
import { PaymentOptions } from "@/types";
import Tuna from "./Tuna";

export default function (props: PaymentOptions) {
  useSnackbar(props.plugins?.snackbar);

  return (
    <TunaCloak>
      <Tuna {...props} />
    </TunaCloak>
  );
}
