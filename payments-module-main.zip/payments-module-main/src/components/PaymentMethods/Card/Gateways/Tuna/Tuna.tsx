import { useCallback, useEffect, useRef, useState } from "react";
import PaymentAPIManager from "@/api/gateways";
import { default as Input } from "@/components/Core/Input";
import { isCardMealVoucher } from "@/components/PaymentMethods/Wallets/Gateways/Tuna/MealVoucher/MealVoucher.util";
import { useLockUnlock, useTrace } from "@/hooks";
import { useToast } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { usePgEvent } from "@/hooks/pg-events";
import useSentry from "@/hooks/sentry";
import useCPFDrawer from "@/hooks/useCPFDrawer";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { getSelectedCard, hasSavedCardClicked, useCardStore } from "@/stores/cardStore";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { ErrorMessageKey, ErrorMessages, validateExpiryDateWithLongYear } from "@/utils";
import { ICard, formatMaskedCard } from "@/utils";
import { IStartSpanResponse } from "@clubpay/customer-common-module/src/hook/useSentryTrace";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { Span } from "@sentry/nextjs/types/client";
import CardLayout from "../../Layout/layout";
import SavedCard from "../../components/common/SavedCard";
import { extractTunaError, parseBrand, parseExpirationDate, validateCardNumber, validateFormState } from "./Tuna.util";

const Tuna = (props: PaymentOptions) => {
  const { variant = "primary", amount = 2, currency = "AED", qlub, pg } = props;

  const pgSignature = `${props.pg.id}-${PaymentElementEnum.CardPay}`;

  const gatewayName = pg.name;

  const [formState, setFormState] = useState<any>({});
  const [saveCardCvv, setSaveCardCvv] = useState<Record<string, string>>({});

  const tunaDataRef = useRef({
    tunaSession: "",
    tunaCustomerId: ""
  });

  const isSavedCard = hasSavedCardClicked(pgSignature);

  const tunaInstanceRef = useRef(null);

  const referenceIdRef = useRef("");

  const formStateRef = useRef<any>({});

  const ranRef = useRef(false);

  const {
    state: cardStore,
    setCardList,
    setSelectedCard,
    setNewCardData,
    setDiselectNewCardData,
    removeCard
  } = useCardStore((store) => store);

  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const { lock: lockUI } = useCommonStore((store) => store);

  const config = props.pg.config;

  const hasChoosen = isPaymethodChoosed({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.CardPay });

  const selectedCard = getSelectedCard(pgSignature);

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).tuna;
  const gatewayId = props.pg.id;
  const { state } = usePGGroupStore((state) => state);

  const hasPgGroup = state.isPGGroupEnabled;

  const tipAmount = qlub?.tip || 0.0;

  const { onBeforePayment, onPaymentSuccess, onPaymentFailure, onTraceClose } = config.events ?? {};

  const traceStart = useTrace(props.pg);

  const { startTrace, infoLog, errorLog } = useSentry(props);

  const { displayMessage } = useToast();

  const { sendEvent } = usePgEvent({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });

  const traceRef = useRef<IStartSpanResponse | undefined>();

  const { setProcessing } = usePayment();

  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });

  const handleUpdateFormState = (key: string, value: string) => {
    if (key === "card") {
      if (value?.length >= 20) return;
      const inputNumber = value.replace(/\D/g, "");
      const formattedNumber = inputNumber.replace(/(\d{4})(?=\d)/g, "$1 ");

      setFormState((prevState: any) => ({ ...prevState, [key]: formattedNumber }));
    } else if (key === "expiry") {
      const inputMonth = value.replace(/\D/g, "");
      const formattedMonth = inputMonth.slice(0, 6).replace(/(\d{2})(?=\d)/, "$1/");
      setFormState((prevState: any) => ({ ...prevState, [key]: formattedMonth }));
    } else if (key === "name") {
      setFormState((prevState: any) => ({ ...prevState, [key]: value }));
    } else {
      const ammexRegex = /^3[47][0-9]{13}$/;
      const condition = ammexRegex.test(formState.card?.replace(/\s/g, "")) ? value?.length >= 5 : value?.length >= 4;
      if (condition) return;
      setFormState((prevState: any) => ({ ...prevState, [key]: value }));
    }
  };

  const handleSelectCard = (token: string) => setSelectedCard(pgSignature, token);

  const getEventSuffix = () => {
    return Boolean(selectedCard) ? "saved" : "";
  };

  const getTunaSession = async () => {
    referenceIdRef.current = getRandomString();

    const response = await api.session({
      gatewayID: gatewayId,
      reference: referenceIdRef.current,
      diningSessionID: qlub?.diningSessionId || "",
      id: getSession()
    });

    if (response) {
      tunaDataRef.current.tunaSession = response.data.sessionToken;
      tunaDataRef.current.tunaCustomerId = response.data.customerID;
      tunaInstanceRef.current = window?.Tuna?.(tunaDataRef.current.tunaSession);
    }
    handleGetSavedCards();
  };

  const handleGetSavedCards = async () => {
    const tunaInstance: any = tunaInstanceRef.current;
    const tokenizer = await tunaInstance?.tokenizator();
    const list = await tokenizer?.list();

    if (!list.tokens.length) return;

    const fetchedCards = list.tokens
      ?.filter((card: ICard) => !isCardMealVoucher(card.bin))
      ?.map((card: ICard) => {
        return {
          ...card,
          maskedNumber: formatMaskedCard(card.maskedNumber),
          brand: card.brand === "unknown" ? parseBrand(card.bin) : card.brand
        };
      });

    setCardList({
      name: pgSignature,
      list: fetchedCards
    });
    setDiselectNewCardData(pgSignature);
  };

  const renderSavedCard = () => {
    const savedCards = cardStore.savedCardsData.get(pgSignature)?.cardsList;
    if (!savedCards || !Boolean(savedCards) || !savedCards?.length) return null;

    if (!hasPgGroup || hasChoosen) {
      return (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            rowGap: "1rem"
          }}
        >
          {savedCards?.map((card: ICard) => (
            <SavedCard
              manualCVV
              disableEdit
              cvv={saveCardCvv[card.token]}
              selected={card.selected}
              maskedNumber={card.maskedNumber}
              brand={card.brand?.toLocaleLowerCase()}
              onSelect={() => {
                setDiselectNewCardData(pgSignature);
                handleSelectCard(card.token);
              }}
              onChangeClick={() => {
                setDiselectNewCardData(pgSignature);
                handleSelectCard(card.token);
              }}
              onUnsaveClick={() => {
                removeCardHandler(card);
              }}
              onCVVChange={(ev: any) => {
                const text = ev.target.value;
                const condition = ["amex"].includes((card.brand ?? "").toLowerCase())
                  ? text?.length > 4
                  : text?.length > 3;
                const regex = /^[0-9/]*$/;
                const found = regex.test(text);

                if (condition || !found) return;

                setSaveCardCvv((prevState) => ({
                  ...prevState,
                  [card.token]: text
                }));
              }}
            />
          ))}
        </div>
      );
    }

    return null;
  };

  const card = useCallback(
    (props: any) => (
      <Input
        value={formState?.["card"] || ""}
        onChange={(e: any) => {
          const value = e.target.value;
          const regex = /^[0-9 ]*$/;
          const found = regex.test(value);
          found && handleUpdateFormState("card", value);
        }}
        {...props}
        forceLTR
      />
    ),
    [formState]
  );

  const expiry = useCallback(
    (props: any) => (
      <Input
        {...props}
        value={formState?.["expiry"] || ""}
        onChange={(e: any) => {
          const value = e.target.value;
          if (value.length > 7) return;
          const regex = /^[0-9/]*$/;
          const found = regex.test(value);

          found && handleUpdateFormState("expiry", e.target.value);
        }}
        forceLTR
      />
    ),
    [formState]
  );

  const cvv = useCallback(
    (props: any) => (
      <Input
        value={formState?.["cvv"] || ""}
        {...props}
        onChange={(e: any) => {
          const value = e.target.value;
          const regex = /^[0-9/]*$/;
          const found = regex.test(value);
          found && handleUpdateFormState("cvv", value);
        }}
        forceLTR
      />
    ),
    [formState]
  );

  const name = useCallback(
    (props: any) => (
      <Input
        value={formState?.["name"] || ""}
        {...props}
        onChange={(e: any) => {
          const value = e.target.value;
          if (value !== "") {
            const regex = /^[a-zA-Z ]+$/;
            const found = regex.test(value);
            found && handleUpdateFormState("name", value);
            return;
          }
          handleUpdateFormState("name", "");
        }}
        forceLTR
      />
    ),
    [formState]
  );

  const performValidation = () => {
    if (!selectedCard) {
      const status = validateFormState({
        name: formStateRef.current?.name || "",
        card: formStateRef.current?.card || "",
        cvv: formStateRef.current?.cvv || "",
        expiry: formStateRef.current?.expiry || ""
      });

      if (status) {
        displayMessage(t(status));
        return true;
      }

      const cardNoStatus = validateCardNumber(formStateRef.current?.card, formStateRef.current?.cvv);

      if (cardNoStatus) {
        displayMessage(t(cardNoStatus));
        return true;
      }

      const expiryDateStatus = validateExpiryDateWithLongYear(formStateRef.current?.expiry);
      if (expiryDateStatus) {
        displayMessage(t(expiryDateStatus));
        return true;
      }
    } else {
      const isAmex = selectedCard.brand?.toLocaleLowerCase() === "amex";

      if (!saveCardCvv[selectedCard.token]?.length) {
        displayMessage(t(ErrorMessages[ErrorMessageKey.Cvv]));
        return true;
      }

      if (isAmex && saveCardCvv[selectedCard.token]?.length < 4) {
        displayMessage(t(ErrorMessages[ErrorMessageKey.Cvv]));
        return true;
      }

      if (!isAmex && saveCardCvv[selectedCard.token]?.length < 3) {
        displayMessage(t(ErrorMessages[ErrorMessageKey.Cvv]));
        return true;
      }

      return false;
    }

    return false;
  };

  const handleSubmit = async (e: any) => {
    startTrace("submission", PaymentElementEnum.CardPay, async (span: Span) => {
      const event = {
        gatewayId,
        paymentElement: PaymentElementEnum.CardPay,
        refId: referenceIdRef.current as string,
        traceId: span?.traceId,
        tip: qlub?.tip ?? 0,
        meta: {
          gaEventSuffix: getEventSuffix(),
          saved: Boolean(selectedCard)
        }
      };

      const { expMonth, expYear } = parseExpirationDate(formStateRef.current.expiry);
      const cardNo = formStateRef.current.card?.replace(/\D/g, "");
      const cvv = formStateRef.current.cvv;
      const customerName = formStateRef.current.name;

      const status = performValidation();

      if (status) return;

      lockUI(15000);

      traceRef.current = traceStart?.startSpan({
        dataName: gatewayName ?? "anonymous",
        span: {
          element: PaymentElementEnum.CardPay,
          refId: referenceIdRef.current
        }
      });

      setProcessing(true);

      try {
        const onBeforeRes = await onBeforePayment?.(event);

        if (!onBeforeRes) {
          infoLog("onBefore api Fail");
          setProcessing(false);
          return;
        }
        infoLog("onBefore api Success");

        infoLog("locking mechanism Initialize");

        const lockResponse = await lock(event);

        if (!lockResponse) {
          infoLog("locking mechanism Fail");
          setProcessing(false);
          return;
        }

        infoLog("locking mechanism Success");
        const pgNameForGA = selectedCard
          ? `${props.pg.name}_${PaymentElementEnum.CardPay}_saved`?.toLowerCase()
          : `${props.pg.name}_${PaymentElementEnum.CardPay}`?.toLowerCase();

        sendEvent("payment_initialized", {
          pg_name: pgNameForGA
        });

        const tunaInstance: any = tunaInstanceRef.current;
        let response: any;
        if (selectedCard) {
          const cvv = saveCardCvv[selectedCard.token];

          const tz = await tunaInstance?.tokenizator();

          if (!tz) {
            setProcessing(false);
            return;
          }

          await tz.bind(selectedCard.token, cvv);

          response = {
            cardData: {
              cardHolderName: selectedCard.cardHolderName,
              cardNumber: selectedCard.bin,
              expirationMonth: Number(selectedCard.expirationMonth),
              expirationYear: Number(selectedCard.expirationYear),
              cvv,
              singleUse: false
            },
            tokenData: {
              token: selectedCard.token,
              brand: selectedCard.brand
            },
            success: true
          };
        } else {
          response = await tunaInstance?.getCheckoutData({
            cardHolderName: customerName,
            cardNumber: cardNo,
            expirationMonth: Number(expMonth),
            expirationYear: Number(expYear),
            cvv: cvv,
            singleUse: !isSavedCard,
            iD: tunaDataRef.current.tunaCustomerId
          });
        }

        if (response.success) {
          infoLog("tuna getCheckoutData api Success");

          const payRes = await api.cardPayment({
            gatewayID: gatewayId,
            diningSessionID: qlub?.diningSessionId || "",
            reference: referenceIdRef.current,
            id: getSession(),
            tipAmount: tipAmount.toString(),
            cardToken: response.tokenData.token,
            sessionToken: tunaDataRef.current.tunaSession,
            cardExpireMonth: response.cardData.expirationMonth,
            cardExpiryYear: response.cardData.expirationYear,
            cardHolderName: response.cardData.cardHolderName,
            tokenSingleUse: response.cardData.singleUse || true,
            cardBrand: response.tokenData.brand,
            cardBin: response.tokenData.bin,
            method: "1",
            document: "",
            documentType: "",
            ...additionalData
          });

          saveLastPayment();

          if (payRes.data.success) {
            infoLog("payment api call Success");
            infoLog("onSuccess CB call Success");

            onPaymentSuccess?.(event);
          } else {
            infoLog("payment api call Fail");

            onTraceClose?.({
              error: payRes.data,
              location: "tunaCardPayment.onFail",
              traceRef,
              traceStart
            });
            onPaymentFailure?.(event);
          }
        }
      } catch (e) {
        errorLog("Payment flow Fail");
        unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
        onTraceClose?.({
          error: e,
          location: "tunaCardPayment.onFail",
          traceRef,
          traceStart
        });
        // console.log("exception", e);
        const error = extractTunaError(e);
        if (error) displayMessage(t(error));
      } finally {
        setProcessing(false);
      }
    });
  };

  const handleAddCard = (force?: boolean) => {
    handleSelectCard("");
    setNewCardData(pgSignature, force);
  };

  const handleOnPGPaymentBoxClick = () => {
    if (selectedCard || cardStore.savedCardsData.get(pgSignature)?.cardsList) return;
    handleAddCard(true);
  };

  const removeCardHandler = async (card: any) => {
    removeCard(pgSignature, card.token);

    const tunaInstance: any = tunaInstanceRef.current;
    try {
      const tokenizer = await tunaInstance?.tokenizator();
      tokenizer?.delete(card.token);

      displayMessage(t("Your card details archived."), "info");
    } catch {}
  };

  const { DrawerElement, openCPFDrawer, additionalData } = useCPFDrawer({
    paymentCB: handleSubmit,
    enabled: pg.config.extraConfig.enableDocumentCollection
  });

  const handleLocalSubmit = () => {
    openCPFDrawer();
  };

  useEffect(() => {
    formStateRef.current = formState;
  }, [formState]);

  useEffect(() => {
    if (state.pgGroupInteractionData.currentSelected === pgSignature && !ranRef.current) {
      ranRef.current = true;
      handleOnPGPaymentBoxClick();
    }
  }, [state.pgGroupInteractionData.currentSelected]);

  useEffect(() => {
    getTunaSession();
  }, []);

  return (
    <>
      {DrawerElement}
      <CardLayout
        elements={{ card, expiry, cvv, name }}
        onSubmit={handleLocalSubmit as any}
        variant={variant}
        amount={amount}
        currency={currency}
        {...props}
        enableCardSaving={!config?.extraConfig?.disableSavedCard}
        hide={config?.extraConfig?.hideCardPay}
        api={{
          cardStorage: { fetchSavedCards: () => {} }
        }}
        isAdding={cardStore.newCardsData?.get(pgSignature)?.hasAdded}
        onAddCard={handleAddCard}
        savedCardSlot={renderSavedCard()}
        onPGElementClick={handleOnPGPaymentBoxClick}
        shouldPayBtnEnable={() => {
          if (selectedCard) {
            const isAmex = selectedCard.brand?.toLocaleLowerCase() === "amex";

            return isAmex
              ? saveCardCvv[selectedCard.token]?.length === 4
              : saveCardCvv[selectedCard.token]?.length === 3;
          }
          return Boolean(cardStore.newCardsData?.get(pgSignature)?.hasAdded);
        }}
      />
    </>
  );
};
export default Tuna;
