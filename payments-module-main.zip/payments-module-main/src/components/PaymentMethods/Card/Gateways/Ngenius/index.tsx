import { default as NgeniusCloak } from "@/components/GatewayCloaks/Ngenius";
import { useSnackbar } from "@/hooks";
import { PaymentOptions } from "@/types";
import { default as NgeniusCardPayment } from "./Ngenius";

export default function (props: PaymentOptions) {
  useSnackbar(props.plugins?.snackbar);

  return (
    <NgeniusCloak onReady={props.pg.config.events?.onReady} config={props.pg.config.extraConfig}>
      <NgeniusCardPayment {...props} />
    </NgeniusCloak>
  );
}
