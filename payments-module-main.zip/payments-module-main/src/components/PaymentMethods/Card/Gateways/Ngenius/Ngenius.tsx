import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import classNames from "classnames";
import PaymentAPIManager from "@/api/gateways";
import { Button } from "@/components/Core";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import PaymentLoadingDialog from "@/components/Global/PaymentLoadingDialog";
import PaymentTerms from "@/components/Global/PaymentTerms";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock, useSentry, useToast, useTrace } from "@/hooks";
import { useExchangeInterruption } from "@/hooks/exchange";
import { useNgenius3dsMount } from "@/hooks/ngenius-3ds-mount";
import { useScript } from "@/hooks/ngenius-script";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { usePgEvent } from "@/hooks/pg-events";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { NGeniusPaymentStatus } from "@/types/payments/config/ngenius";
import { NGeniusValidateEvent } from "@/types/payments/config/ngenius";
import { getPaymentExchangeDecision } from "@/utils/payments/exchange";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { snackBar } from "@clubpay/customer-common-module/src/hook/snackBar";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { Divider } from "@mui/material";
import { Span } from "@sentry/nextjs/types/client";
import CardSkeleton from "./CardSkeleton";
import styles from "./Ngenius.module.scss";

const style = {
  main: {
    overflow: "hidden"
  },
  base: {
    fontUrl: "https://fonts.googleapis.com/css?family=Roboto&display=swap",
    fontFamily: "Roboto",
    padding: "0px"
  },
  input: {
    borderWidth: "2px",
    borderColor: "#E5E5E5",
    borderStyle: "solid",
    borderRadius: "6px",
    padding: "10px 10px"
  }
};

const NgeniusCardPayment = (props: PaymentOptions) => {
  const { variant = "primary", amount, qlub, pg, locale, totalAmount } = props;

  const exchange = qlub?.exchange;
  const gatewayId = pg.id;
  const pgName = pg.name;
  const config = pg.config;
  const hideCardPay = config.extraConfig.hideCardPay;
  const tipAmount = qlub?.tip;
  const billAmount = amount;
  const diningSessionId = qlub?.diningSessionId;
  const enableNIRedirectToPendingOnTimeOut = pg.vendor.country.config.redirectToPendingOnTimeOut;

  const { onBeforePayment, onPaymentSuccess, onPaymentFailure, onPaymentPending, onPrePayment } = config.events ?? {};
  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).ngenius;

  const [isCardDetailsValid, setIsCardDetailsValid] = useState(false);

  const containerRef = useRef(null);

  const { startTrace, infoLog, errorLog } = useSentry(props);

  const { triggerInterruption } = useExchangeInterruption({
    paymentOptions: props,
    paymentMethod: PaymentElementEnum.CardPay
  });

  const { is3dsMounted, reset3dsMounted, threeDsContainerRef } = useNgenius3dsMount();

  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });

  const mountCardInput = () => {
    window.NI?.mountCardInput("ngenius-container", {
      apiKey: config.extraConfig.hostedSessionApiKey,
      outletRef: config.extraConfig.outlet_ref,
      style,
      firstName: "Not",
      lastName: "Available",
      language: locale,
      onChangeValidStatus: (e: NGeniusValidateEvent) => {
        setIsCardDetailsValid(e.isCVVValid && e.isExpiryValid && e.isNameValid && e.isPanValid);
      },
      onSuccess: () => setLoadingSdk(false),
      hideLoadingBehavior: true
    });
  };

  const { loadingSdk, setLoadingSdk, loadSdk } = useScript({
    onLoad: mountCardInput,
    containerRef,
    sandbox: config.sandbox
  });

  const { getCallbackUrl } = useConfirmCallback();

  const { displayMessage } = useToast();

  const { processing, setProcessing } = usePayment();

  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const { triggerSnackBar, actionButton } = snackBar();

  const { sendEvent } = usePgEvent({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });

  const {
    state: pgGroupState,
    toggleVisibility,
    setAddPGMethod,
    removePGMethod,
    setPaymentMethodReference
  } = usePGGroupStore((state) => state);

  const hasChoosen = isPaymethodChoosed({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay });
  const hasPgGroup = pgGroupState.isPGGroupEnabled;

  const getStyles = () => {
    if (hasPgGroup) {
      if (hasChoosen)
        return {
          display: "block",
          paddingTop: "10px"
        };

      return {
        display: "none"
      };
    }
    return {
      display: "block"
    };
  };

  const paymentCallBack = async () => {
    startTrace("pay", PaymentElementEnum.CardPay, async (span: Span) => {
      const refId = getRandomString();
      const event = {
        paymentElement: PaymentElementEnum.CardPay,
        refId,
        traceId: span?.traceId,
        meta: {
          isExchangeInterrupted: Boolean(exchange),
          isExchangeUsed: Boolean(exchange?.isApplied)
        }
      };

      let paymentResponse: any;
      let ngeniusResponse: any;

      let cardPayApiStartTimeStamp = 0;

      try {
        setProcessing(true);
        const tipCheckResponse = await onBeforePayment?.({
          gatewayId,
          paymentElement: PaymentElementEnum.CardPay,
          tip: tipAmount ?? 0,
          checkTipOnly: true
        });

        if (!tipCheckResponse) {
          infoLog("Tip check Fail");
          return;
        }
        infoLog("Tip check Success");

        if (!isCardDetailsValid) {
          displayMessage(t("The card information is incorrect, Please check the details and retry"), "error", {
            autoHide: true
          });
          infoLog("Card validation Fail");
          return;
        }

        reset3dsMounted();

        infoLog("Reset 3ds mount");

        const returnUrl = getCallbackUrl({
          ref: refId as string,
          method: pgName,
          paymentElement: PaymentElementEnum.CardPay,
          dsi: diningSessionId || "",
          amount: billAmount || "",
          currencySymbol: props.country,
          is3ds: true
        });

        const onBeforeResponse = await onBeforePayment?.({
          gatewayId,
          paymentElement: PaymentElementEnum.CardPay,
          tip: tipAmount ?? 0
        });
        if (!onBeforeResponse) {
          infoLog("onBefore api Fail");
          return;
        }

        infoLog("onBefore api Success");

        const lockResponse = await lock(event);
        if (!lockResponse) return;

        /** handle token expiration */
        let nGeniusSessionId: string | undefined;
        let nGeniusSessionId2: string | undefined;

        try {
          infoLog("Generate session Start");
          const sessionResponse = await window.NI?.generateSessionId();
          const sessionResponse2 = await window.NI?.generateSessionId();

          nGeniusSessionId = sessionResponse?.session_id;
          nGeniusSessionId2 = sessionResponse2?.session_id;

          infoLog("Generate session Success");
        } catch (_) {
          infoLog("Generate session Fail");
          triggerSnackBar(
            t("The payment did not proceed Please try again"),
            {
              variant: "error",
              action: actionButton
            },
            true
          );
          unlock?.();
          sendEvent("payment_initialized", { status: "failed", error: "ngenius_token_expired" });
          loadSdk();
          return;
        }

        /** get exchange decision before call saveLastPayment. don't change the order */
        const exchangeDecision = getPaymentExchangeDecision(exchange, pgName);

        saveLastPayment();

        try {
          cardPayApiStartTimeStamp = Date.now();

          paymentResponse = await api.payByToken({
            id: getSession(),
            reference: refId,
            gatewayID: gatewayId,
            diningSessionID: diningSessionId || "",
            tipAmount: tipAmount ? tipAmount.toFixed(2) : "0.00",
            sessionId: nGeniusSessionId,
            sessionIdLocalCurrency: nGeniusSessionId2,
            successUrl: returnUrl.success,
            failureUrl: returnUrl.fail,
            isSplitPayment: props.pg?.hasSplitPayment || false,
            exchangeDecision
          });
        } catch (error: any) {
          if (!error?.data) {
            infoLog("Pay api Fail : network or timeout issue");

            const cardPayApiEndTime = Date.now();

            const duration = cardPayApiEndTime - cardPayApiStartTimeStamp;

            const isLessThanThreshold = duration < 15000;

            if (enableNIRedirectToPendingOnTimeOut && !isLessThanThreshold) {
              onPaymentPending?.({ ...event, is3ds: is3dsMounted.current });
            } else {
              onPaymentFailure?.({ ...event, is3ds: is3dsMounted.current });
            }
            return;
          } else throw error;
        }

        span?.setData("payment_response", paymentResponse);
        span?.setTag("qlub.order_reference", paymentResponse.data?.orderReference);

        if (paymentResponse.data.exchangeData) {
          unlock?.();
          triggerInterruption(paymentResponse.data);
          return;
        }

        infoLog("Handle payment response Start");

        ngeniusResponse = await window.NI?.handlePaymentResponse(paymentResponse.data, {
          mountId: "ngenius-3ds"
        });

        span?.setData("ngenius_response", ngeniusResponse);
        infoLog("Handle payment response Success");

        if (
          !(
            ngeniusResponse?.status === NGeniusPaymentStatus.AUTHORISED ||
            ngeniusResponse?.status === NGeniusPaymentStatus.CAPTURED
          )
        ) {
          onPaymentPending?.({ ...event, is3ds: is3dsMounted.current });
          unlock();
          return;
        }

        infoLog("Capture api Start");

        await api.capture({
          id: getSession(),
          reference: refId,
          gatewayID: gatewayId,
          diningSessionID: diningSessionId || "",
          tipAmount: tipAmount ? tipAmount.toFixed(2) : "0.00",
          sessionId: nGeniusSessionId,
          paymentURL: paymentResponse.data._links.self.href,
          exchangeDecision: getPaymentExchangeDecision(exchange, pgName)
        });

        infoLog("Capture api Success");

        onPaymentSuccess?.({ ...event, is3ds: is3dsMounted.current });

        infoLog("Payment flow Success");
      } catch (error: any) {
        errorLog("Payment flow Fail");

        const cardPayApiEndTime = Date.now();

        const duration = cardPayApiEndTime - cardPayApiStartTimeStamp;

        const isLessThanThreshold = duration < 15000;

        if (enableNIRedirectToPendingOnTimeOut && !isLessThanThreshold) {
          onPaymentPending?.({ ...event, is3ds: is3dsMounted.current });
        } else {
          onPaymentFailure?.({ ...event, is3ds: is3dsMounted.current });
        }
      } finally {
        setProcessing(false);
        span?.setTag("qlub.ngenius_status", ngeniusResponse?.status ?? NGeniusPaymentStatus.UNDECIDED);
        span?.finish();
      }
    });
  };

  const renderPGElementBox = () => {
    if (!hasPgGroup || hideCardPay) return null;
    return (
      <PGPaymentBox
        name={t("Card")}
        selected={hasChoosen}
        toggleVisibility={() => {
          toggleVisibility({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay, name: "stripeConnect" });
          loadSdk();
        }}
      />
    );
  };

  const handlePay = () => {
    if (onPrePayment) onPrePayment(paymentCallBack, PaymentElementEnum.UnionPay);
    else paymentCallBack();
  };

  const buttonElement = (
    <Button
      id="payment-action-btn"
      variant={variant}
      className={styles["pay-btn"]}
      type="submit"
      disabled={processing}
      loading={processing}
      onClick={handlePay}
    >
      {t("Pay")}
    </Button>
  );

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.CardPay,
      fn: paymentCallBack
    });
  }, [billAmount, tipAmount, totalAmount, isCardDetailsValid]);

  useEffect(() => {
    if (!hideCardPay) {
      setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay });
    }
  }, [hideCardPay]);

  useEffect(() => {
    return () => removePGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay });
  }, []);

  return (
    <div ref={containerRef}>
      {renderPGElementBox()}
      <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
        {!hideCardPay && (
          <div style={getStyles()}>
            <PaymentLoadingDialog open={processing} />
            {loadingSdk && <CardSkeleton />}
            <div
              id="ngenius-container"
              className={classNames(styles.container, { [styles.containerHide]: loadingSdk })}
            />
            {createPortal(
              <div id="ngenius-3ds" ref={threeDsContainerRef} className={styles.iframeContainer} />,
              document.body
            )}
            {!hasPgGroup && (
              <div style={{ paddingTop: "20px" }}>
                <PaymentTerms className={styles.payTerms} />
                <Divider sx={{ margin: "16px 0 0 0" }} />
                {buttonElement}
              </div>
            )}
          </div>
        )}
        {hasChoosen && (
          <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{buttonElement}</ReactPortal>
        )}
      </div>
    </div>
  );
};

export default NgeniusCardPayment;
