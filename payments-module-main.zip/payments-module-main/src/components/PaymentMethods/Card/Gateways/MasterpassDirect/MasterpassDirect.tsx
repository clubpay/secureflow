// import React, { useEffect, useRef, useState } from "react";
import { useRef } from "react";
import { useFormik } from "formik";
// import { t as t2 } from "@/locales";
// import { useToast } from "@/hooks";
import Scripts from "next/script";
import * as Yup from "yup";
import PaymentAPIManager from "@/api/gateways";
import { default as Input } from "@/components/Core/Input";
import { useToast } from "@/hooks";
import useMasterpass from "@/hooks/masterpass";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { PaymentOptions } from "@/types";
import { MASTERPASS_PF_BANK_ICA, getAdditionalParameters, getCVVLength, sanitizeCardInput } from "@/utils";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { sumAmounts } from "@clubpay/customer-common-module/src/utility/k_math";
import { default as CardLayout } from "../../Layout/layout";
import VerificationModal from "../../components/Masterpass/VerificationModal";
import { MASTERPASS_BASE_ENDPOINT, MASTERPASS_RESPONSE_CODE } from "../Masterpass/Masterpass.util";
import { directPurchase, removeSlashesAndReverse } from "./MasterpassDirect.util";

const MasterpassDirect = (props: PaymentOptions) => {
  const gatewayId = props.pg.id;
  const gatewayName = props.pg.name;
  const qlub = props.qlub;
  const config = props.pg.config;
  const amount = props.amount || 0;
  const variant = props.variant;
  const {
    state: { open },
    methods: {
      handlePay,
      toggleDrawer,
      deleteCard,
      closeDrawer,
      resendCodeFromBank,
      verifyMasterpassCode,
      initBankOtpOperation
    }
  } = useMasterpass(props);

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).masterpassDirect;
  const apiMasterpass = (config.apiManager ?? PaymentAPIManager.getInstance()).masterpass;
  const { getCallbackUrl } = useConfirmCallback();
  const { setProcessing } = usePayment();
  const { displayMessage } = useToast();
  const { login, isLogin, isAuthorizedUser, logout } = useAuth();

  const reference = useRef<any>(null);

  const formik = useFormik({
    initialValues: {
      cardNumber: "",
      expiry: "",
      cvv: ""
    },
    validationSchema: Yup.object({
      cardNumber: Yup.number().required("Required"),
      expiry: Yup.number().required("Required"),
      cvv: Yup.number().required("Required")
    }),
    onSubmit: (values) => {
      alert(JSON.stringify(values, null, 2));
    }
  });

  const totalAmount = qlub?.exchange?.isApplied
    ? qlub?.exchange.total
    : sumAmounts(qlub?.currencyPrecision || 0, amount || 0, qlub?.tip || 0);

  const handleSubmit = async (e: any) => {
    console.log("handleSubmit", e);
    setProcessing(true);
    try {
      const returnUrl = getCallbackUrl({
        ref: reference.current,
        method: gatewayName,
        paymentElement: PaymentElementEnum.CardPay,
        tip: qlub?.tip ? qlub.tip.toFixed(2) : "0.00",
        dsi: qlub?.diningSessionId || "",
        sid: getSession(),
        amount: amount.toFixed(qlub?.currencyPrecision || 0),
        currencySymbol: props.country
      });

      const genTokenResponse = await api.generateToken({
        gatewayID: gatewayId,
        verbose: true,
        reference: reference.current,
        forRegisterCard: false,
        computeReturnURL: true,
        id: getSession(),
        diningSessionID: qlub?.diningSessionId,
        failURL: returnUrl.fail,
        successURL: returnUrl.success,
        tipAmount: qlub?.tip ? qlub.tip.toFixed(2) : "0.00"
      });

      const newTotalAmount = (totalAmount * 100).toFixed(0);

      const additionalParameters = getAdditionalParameters({
        total: newTotalAmount,
        bankIca: config.extraConfig?.bankICA || MASTERPASS_PF_BANK_ICA.ipara,
        restaurantUnique: props.pg.vendor?.unique
      });

      directPurchase(
        {
          msisdn: genTokenResponse.data.customerPhone,
          token: genTokenResponse.data.token,
          orderNo: genTokenResponse.data.orderID,
          userId:
            config.extraConfig?.bankICA === MASTERPASS_PF_BANK_ICA.sipay
              ? genTokenResponse.data.customerID
              : genTokenResponse.data.customerPhone,
          referenceNo: reference.current,
          expiryDate: removeSlashesAndReverse(formik.values.expiry),
          rtaPan: formik.values.cardNumber.replace(/\s/g, ""),
          amount: newTotalAmount,
          ...additionalParameters
        },
        async (responseCode: any, response: any) => {
          const returnURL = genTokenResponse.data.computedCallbackURL;
          const commitPurchasePattern = /\/masterpass-turkiye\/commit-purchase\/.*/;

          if (response?.responseCode === MASTERPASS_RESPONSE_CODE.SUCCESS_REDIRECT_TO_3D) {
            // 3D Secure
            window.location.assign(`${response?.url3D}&returnUrl=${returnURL}`);
          } else if (commitPurchasePattern.test(genTokenResponse?.data.computedCallbackURL ?? "")) {
            window.location.assign(`${response?.directPurchase}`);
          } else if (
            [MASTERPASS_RESPONSE_CODE.OTP, MASTERPASS_RESPONSE_CODE.OTHER_OTP].includes(response?.responseCode)
          ) {
            initBankOtpOperation();
          } else {
            console.log("error", response?.responseDescription);
            console.log("responseCode", responseCode);
          }
        }
      );
    } catch (error: any) {
      console.log("error", error);
    } finally {
      setProcessing(false);
    }
  };

  const card = (props: any) => (
    <Input
      id="cardNumber"
      name="cardNumber"
      onChange={(e) => {
        const formatted = sanitizeCardInput("card", e.target.value);
        if (typeof formatted === "undefined") return;
        formik.setFieldValue("cardNumber", formatted);
      }}
      value={formik.values.cardNumber}
      {...props}
    />
  );

  const expiry = (props: any) => (
    <Input
      id="expiry"
      name="expiry"
      onChange={(e) => {
        const formatted = sanitizeCardInput("expiry", e.target.value);
        if (typeof formatted === "undefined") return;
        formik.setFieldValue("expiry", formatted);
      }}
      value={formik.values.expiry}
      {...props}
    />
  );

  const cvv = (props: any) => (
    <Input
      id="cvv"
      name="cvv"
      onChange={(e) => {
        const formatted = sanitizeCardInput("cvv", e.target.value, getCVVLength(formik.values.cardNumber));
        if (typeof formatted === "undefined") return;
        formik.setFieldValue("cvv", formatted);
      }}
      value={formik.values.cvv}
      {...props}
    />
  );

  const setMasterpassInitialStep = async () => {
    try {
      const ref = await apiMasterpass.generateReference();
      reference.current = ref.data.reference;
    } catch (error: any) {
      const errData = error?.response?.data || error || {};

      if ([400, 403].includes(errData?.code || 0)) {
        logout();
        displayMessage(t("Please try again!"), "error", { autoHide: true });
      } else {
        displayMessage(error?.message, "error", { autoHide: true });
      }
    }
  };

  const handleLogin = async () => {
    try {
      if (!isLogin || !isAuthorizedUser) {
        const validated = await login({ guest: true });

        if (validated) {
          await setMasterpassInitialStep();
        } else {
          displayMessage("login error occured", "error", { autoHide: true });
        }
      } else {
        await setMasterpassInitialStep();
      }
    } catch (e: any) {
      console.log(e);
    }
  };

  const handleMasterpassReady = () => {
    window.MFS.setClientId(props.pg.config.extraConfig.clientId);
    window.MFS.setAddress(MASTERPASS_BASE_ENDPOINT[props.pg.config.extraConfig.env]);

    handleLogin();
  };

  return (
    <div style={{ paddingTop: "12px" }}>
      <CardLayout
        elements={{ card, expiry, cvv }}
        variant={variant}
        amount={amount}
        currency={props?.pg?.vendor?.country?.currencySymbol}
        qlub={qlub}
        hide={config?.extraConfig?.hideCardPay}
        onSubmit={handleSubmit}
        {...props}
      />
      <VerificationModal
        open={open}
        toggleDrawer={toggleDrawer}
        onPay={handlePay}
        currency={props?.pg?.vendor?.country?.currencySymbol}
        amount={totalAmount?.toFixed(2) || "0.00"}
        onDelete={deleteCard}
        onResend={resendCodeFromBank}
        onVerify={verifyMasterpassCode}
        onClose={closeDrawer}
      />

      <Scripts
        id="mfs-client-direct"
        src="/pg_sdk/mfs-client.min.js?direct=true"
        strategy="afterInteractive"
        onLoad={handleMasterpassReady}
      />
    </div>
  );
};

export default MasterpassDirect;
