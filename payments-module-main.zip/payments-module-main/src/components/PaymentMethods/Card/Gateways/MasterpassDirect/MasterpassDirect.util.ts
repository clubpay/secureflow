import $ from "jquery";
import { omit } from "lodash";
import { createForm } from "../Masterpass/Masterpass.util";
import { IDirectPurchase, IOTPFromValues } from "../Masterpass/types";

export const removeSlashesAndReverse = (str: string) => {
  return str?.split("/")?.reverse()?.join("") || "";
};

export const directPurchase = (
  values: Partial<IDirectPurchase>,
  callback: (status: number, response: any) => any
): void => {
  const defaultValues = {
    msisdn: "",
    rtaPan: "",
    expiryDate: "",
    cvc: "",
    cardHolderName: "",
    amount: "",
    token: "",
    referenceNo: "",
    sendSmsLanguage: "",
    macroMerchantId: "",
    orderNo: "",
    sendSms: "Y"
  };

  const newValues = omit(values, ["additionalParameters"]);

  Object.assign(newValues, defaultValues);
  const form = createForm(values);

  document.body.append(form);
  if (values.additionalParameters) {
    console.log("additional form values", { values });
    window.MFS.setAdditionalParameters(values.additionalParameters);
  }
  window.MFS.directPurchase($(form), callback);
};

export const verifyOTPForm = (values: Partial<IOTPFromValues>, callback: (status: number, response: any) => any) => {
  const defaultValues = {
    pinType: "otp",
    sendSms: "Y",
    sendSmsLanguage: "tur"
  };
  Object.assign(values, defaultValues);
  const form = createForm(values);

  document.body.append(form);

  window.MFS.validateTransaction($(form), callback);
};

export const resendOTP = (token: string, lang: string, callback: (status: number, response: any) => any) => {
  return window.MFS.resendOtp(token, lang, callback);
};
