import { PaymentOptions } from "@/types";
import MasterpassDirect from "./MasterpassDirect";

const Index = (props: PaymentOptions) => {
  return <MasterpassDirect {...props} />;
};

export default Index;
