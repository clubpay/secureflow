import { Dispatch, ReactNode, SetStateAction, createContext, useContext, useState } from "react";

type HandlePayFunction = {
  funcRef: (payload: any) => void; // Adjust the function signature accordingly
};

// Type definition for the context value
type MashreqContextType = {
  handlePayFunctionRef: HandlePayFunction;
  setHandlePayFunctionRef: Dispatch<SetStateAction<HandlePayFunction>>;
  mashreqSessionId: string;
  setMashreqSessionId: any;
};

// Create the context with the specified type
export const MashreqContext = createContext<MashreqContextType | undefined>(undefined);

// MashreqProvider component with type definition for children
export const MashreqProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [handlePayFunctionRef, setHandlePayFunctionRef] = useState<HandlePayFunction>({
    funcRef: () => {}
  });
  const [mashreqSessionId, setMashreqSessionId] = useState<string>("");

  const contextValue: MashreqContextType = {
    handlePayFunctionRef,
    setHandlePayFunctionRef,
    mashreqSessionId,
    setMashreqSessionId
  };

  return <MashreqContext.Provider value={contextValue}>{children}</MashreqContext.Provider>;
};

// Custom hook to conveniently access the context
export const useMashreqContext = () => {
  const context = useContext(MashreqContext);
  if (!context) {
    throw new Error("useMashreqContext must be used within a MashreqProvider");
  }
  return context;
};
