import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import PaymentAPIManager from "@/api/gateways";
import { default as Input } from "@/components/Core/Input";
import { useLockUnlock, useToast, useTrace } from "@/hooks";
import { usePayment } from "@/providers";
import { PaymentOptions } from "@/types";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { IStartSpanResponse } from "@clubpay/customer-common-module/src/hook/useSentryTrace";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { checkNetworkError } from "@clubpay/customer-common-module/src/utility/checkNetworkError";
import { parseJSON } from "@clubpay/customer-common-module/src/utility/k_json";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import CardLayout from "../../Layout/layout";
import { retrieveError } from "./Mashreq.util";
import { useMashreqContext } from "./MashreqContext";

const MashreqCard = ({ variant = "primary", amount = 2, currency = "AED", qlub, ...props }: PaymentOptions) => {
  const { setHandlePayFunctionRef, mashreqSessionId } = useMashreqContext();
  const { setProcessing } = usePayment();

  const { getCallbackUrl } = useConfirmCallback();

  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const gatewayId = props.pg.id;
  const gatewayName = props.pg.name;

  const config = props.pg.config;

  const traceRef = useRef<IStartSpanResponse | undefined>();
  const traceStart = useTrace(props.pg);

  const [open3DS, setOpen3DS] = useState(false);
  const [iframeHtml, setIframeHtml] = useState<string | undefined>(undefined);

  const sessionRef = useRef("");
  const amountRef = useRef<any>("");

  useEffect(() => {
    sessionRef.current = mashreqSessionId;
    window.mashreqSessionId = mashreqSessionId;
  }, [mashreqSessionId]);

  useEffect(() => {
    amountRef.current = amount;
  }, [amount]);

  const { onBeforePayment, onPaymentSuccess, onPaymentFailure, onPaymentPending, onTraceClose } = config.events ?? {};

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).mashreq;
  const referenceRef = useRef<null | string>(null);
  const { displayMessage } = useToast();

  const handlePay = async ({ cardBrand, sessId }: any) => {
    setProcessing(true);

    referenceRef.current = getRandomString();
    traceRef.current = traceStart?.startSpan({
      dataName: gatewayName ?? "anonymous",
      span: {
        element: PaymentElementEnum.CardPay,
        refId: referenceRef.current
      }
    });

    const event = {
      paymentElement: PaymentElementEnum.CardPay,
      refId: referenceRef.current,
      traceId: traceStart?.traceId,
      meta: {
        isExchangeInterrupted: !!qlub?.exchange,
        isExchangeUsed: qlub?.exchange?.isApplied
      }
    };

    const returnUrl = getCallbackUrl({
      ref: referenceRef.current,
      method: gatewayName,
      paymentElement: PaymentElementEnum.CardPay,
      dsi: qlub?.diningSessionId || "",
      amount: amount || "",
      currencySymbol: props.country,
      traceId: traceStart?.traceId,
      lang: props.locale || ""
    });

    try {
      const onBeforeRes = await onBeforePayment?.({
        gatewayId,
        paymentElement: PaymentElementEnum.CardPay,
        tip: qlub?.tip ?? 0
      });

      if (!onBeforeRes) {
        setProcessing(false);
        return;
      }

      const lockResponse = await lock(event);

      if (!lockResponse) {
        setProcessing(false);
        return;
      }

      const response = await api.pay({
        id: getSession(),
        diningSessionID: qlub?.diningSessionId,
        cardBrand,
        billingCountry: props.pg?.vendor?.country?.code,
        failureUrl: returnUrl.fail,
        gatewayID: gatewayId,
        mashreqSessionId: sessId,
        reference: referenceRef.current,
        successUrl: returnUrl.success,
        tipAmount: qlub?.tip ? qlub.tip.toFixed(2) : "0.00"
      });

      if (response.data.needVerification) {
        if (!response.data.redirectUrl && !response.data.redirectHtml) {
          displayMessage(retrieveError(), "error");
          unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
          setProcessing(false);
          return;
        }

        if (response.data.redirectHtml) {
          setIframeHtml(response.data.redirectHtml);
          setOpen3DS(true);
        } else if (response.data.redirectUrl) {
          window.location.href = response.data.redirectUrl;
        } else {
          displayMessage(retrieveError(), "error");
        }
      } else {
        onPaymentSuccess?.(event);
      }
    } catch (err: any) {
      onTraceClose?.({
        error: err,
        location: "paymentCheckoutPayByToken",
        traceRef,
        traceStart
      });

      const isNetworkError = checkNetworkError(err);

      if (isNetworkError) {
        onPaymentPending?.();
      } else {
        const error = {
          ...event,
          ...(err?.response?.data || {})
        };
        onPaymentFailure?.(error);
      }
    } finally {
      setProcessing(false);
    }
  };

  const handle3DSResponse = async (event: Event) => {
    const { data } = event as MessageEvent;
    if (!data) {
      return;
    }
    const threeDsData = parseJSON(data) as { result: string };
    if (!threeDsData || !threeDsData.result) {
      return;
    }

    const { result } = threeDsData;

    setOpen3DS(false);
    setIframeHtml(undefined);

    if (result !== "SUCCESS") {
      onPaymentFailure?.({
        paymentElement: PaymentElementEnum.CardPay,
        refId: referenceRef.current || "",
        traceId: traceStart?.traceId
      });
      return;
    }

    const response = await api.authorize({ mashreqSessionId: sessionRef.current });

    switch (response.data.status) {
      case "success":
        onPaymentSuccess?.({
          paymentElement: PaymentElementEnum.CardPay,
          refId: referenceRef.current || "",
          traceId: traceStart?.traceId
        });
        break;
      case "pending":
      default:
        onPaymentPending?.();
        break;
    }
  };

  const handleSubmit = async (e?: React.MouseEvent, payload?: any) => {
    window.PaymentSession?.updateSessionFromForm("card");
  };

  const card = (props: any) => <Input id="card-number" readOnly {...props} />;

  const expiryMonth = (props: any) => <Input {...props} id="expiry-month" readOnly />;

  const expiryYear = (props: any) => <Input {...props} id="expiry-year" readOnly />;

  const cvv = (props: any) => <Input {...props} id="security-code" readOnly />;

  useEffect(() => {
    window?.addEventListener("message", handle3DSResponse);
    return () => window?.removeEventListener("message", handle3DSResponse);
  }, []);

  useEffect(() => {
    if (!open3DS || !iframeHtml) return;

    const script = document.getElementById("authenticate-payer-script") as HTMLScriptElement;
    if (script) {
      eval(script.text);
    }
  }, [open3DS, iframeHtml]);

  useEffect(() => {
    setHandlePayFunctionRef({ funcRef: handlePay });
  }, []);

  return (
    <>
      <CardLayout
        elements={{ card, expiryMonth, expiryYear, cvv }}
        onSubmit={handleSubmit}
        variant={variant}
        amount={amount}
        currency={currency}
        qlub={qlub}
        enableCardSaving={!config?.extraConfig?.disableSavedCard}
        hide={config?.extraConfig?.hideCardPay}
        slots={[
          open3DS && createPortal(<div id="3ds" dangerouslySetInnerHTML={{ __html: iframeHtml }} />, document.body)
        ]}
        {...props}
      />
    </>
  );
};

export default MashreqCard;
