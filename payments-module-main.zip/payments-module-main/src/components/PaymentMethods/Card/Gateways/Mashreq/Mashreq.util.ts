import { t } from "@/locales";

const incompleteFormErrs = ["incomplete_number", "incomplete_expiry", "incomplete_cvc", "incomplete_zip"];

export const retrieveError = (err?: any, message?: any) => {
  if (err && err.code) {
    if (incompleteFormErrs.indexOf(err.code) > -1)
      return t("The card information is incorrect, Please check the details and retry");

    if (err.code === 416 && err.items === "PAYMENT_AMOUNT_IS_ZERO")
      return t("You are trying to pay for a bill that is already paid for");

    if (err.code === 416 && err.items === "PAYMENT_AMOUNT_IS_TOO_LARGE") return t("You’re paying too much");
  }

  if (message) {
    return message;
  }
  return t("The payment did not proceed Please try again");
};
