import MashreqCloak from "@/components/GatewayCloaks/Mashreq";
import { PaymentOptions } from "@/types";
import MashreqCard from "./Mashreq";
import { MashreqProvider } from "./MashreqContext";

export default function (props: PaymentOptions) {
  return (
    <MashreqProvider>
      <MashreqCloak onReady={props.pg.config.events?.onReady} {...props}>
        <MashreqCard {...props} />
      </MashreqCloak>
    </MashreqProvider>
  );
}
