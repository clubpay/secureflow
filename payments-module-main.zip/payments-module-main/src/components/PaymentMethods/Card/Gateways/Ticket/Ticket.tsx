import { useEffect, useRef } from "react";
import PaymentAPIManager from "@/api/gateways";
import { Button } from "@/components/Core";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock, useTrace } from "@/hooks";
import useSentry from "@/hooks/sentry";
import useCPFDrawer from "@/hooks/useCPFDrawer";
import TicketPayRed from "@/icons/TicketPayRed";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import ticketIcon from "@clubpay/customer-common-module/src/component/SVG/ticketwhite.png";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { IStartSpanResponse } from "@clubpay/customer-common-module/src/hook/useSentryTrace";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import { Span } from "@sentry/nextjs/types/client";
import styles from "./Ticket.module.scss";

const Ticket = (props: PaymentOptions) => {
  const { variant = "primary", amount = 2, qlub } = props;

  const gatewayId = props.pg.id;
  const gatewayName = props.pg.name;

  const config = props.pg.config;

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).ticket;

  const traceStart = useTrace(props.pg);

  const { startTrace, infoLog, errorLog } = useSentry(props);

  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const { onBeforePayment, onTraceClose } = config.events ?? {};

  const { processing, setProcessing } = usePayment();

  const { getCallbackUrl } = useConfirmCallback();
  const { state, setPaymentMethodReference, setAddPGMethod, toggleVisibility, removePGMethod } = usePGGroupStore(
    (state) => state
  );

  const {
    state: { total }
  } = useCommonStore((store) => store);

  const hasPgGroup = state.isPGGroupEnabled;

  const traceRef = useRef<IStartSpanResponse | undefined>();

  const hasChoosen = isPaymethodChoosed({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.TicketPay });

  const hide = config.extraConfig.hideTicket;

  const localSubmit = () => {
    openCPFDrawer();
  };

  const handlePayCB = () => {
    if (config.events?.onPrePayment) config.events?.onPrePayment(localSubmit, "");
    else localSubmit();
  };

  const handlePay = async () => {
    startTrace("pay", PaymentElementEnum.TicketPay, async (_span: Span) => {
      setProcessing(true);
      const refId = getRandomString();
      traceRef.current = traceStart?.startSpan({
        dataName: gatewayName ?? "anonymous",
        span: {
          element: PaymentElementEnum.TicketPay,
          refId
        }
      });

      const event = {
        paymentElement: PaymentElementEnum.TicketPay,
        refId,
        traceId: traceStart?.traceId
      };

      try {
        const onBeforeRes = await onBeforePayment?.({
          gatewayId,
          paymentElement: PaymentElementEnum.TicketPay,
          tip: qlub?.tip ?? 0
        });

        if (!onBeforeRes) {
          infoLog("onBefore api Fail");
          setProcessing(false);
          return;
        }

        infoLog("onBefore api Success");

        infoLog("locking mechanism Initialize");

        const lockResponse = await lock(event);

        if (!lockResponse) {
          infoLog("locking mechanism Fail");

          setProcessing(false);
          return;
        }

        infoLog("locking mechanism Success");

        const orderId = getRandomString();

        const returnUrl = getCallbackUrl({
          ref: refId,
          method: gatewayName,
          paymentElement: PaymentElementEnum.TicketPay,
          dsi: qlub?.diningSessionId || "",
          amount: amount || "",
          currencySymbol: props.country,
          traceId: traceStart?.traceId,
          lang: props.locale || "",
          orderId,
          sid: getSession()
        });

        const response = await api.generateLink({
          diningSessionID: qlub?.diningSessionId,
          gatewayID: gatewayId,
          id: getSession(),
          reference: refId,
          tipAmount: qlub?.tip ? qlub.tip.toFixed(2) : "0.00",
          successURL: returnUrl.success,
          failureURL: returnUrl.fail,
          ...documentData
        });

        if (response?.data) {
          infoLog("generate link api Success");

          if (response.data?.paymentURL === returnUrl.fail) {
            infoLog("generate link api returned failURL");

            onTraceClose?.({
              error: response,
              location: "payTicketGenerateLink.then",
              traceRef,
              traceStart
            });
            setProcessing(false);
            return;
          }
          infoLog("redirecting success");
          window.location.href = `${response.data?.paymentURL}`;
        } else {
          infoLog("generate link api Fail");

          unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
        }
      } catch (error: any) {
        errorLog("Payment flow Fail");
        onTraceClose?.({
          error: error,
          location: "payTicketGenerateLink.catch",
          traceRef,
          traceStart
        });
        unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
      } finally {
        setProcessing(false);
      }
    });
  };

  const buttonElement = (
    <Button
      id="payment-action-btn"
      variant={variant}
      className={styles["pay-btn"]}
      prefixIcon={() => <img src={ticketIcon.src} />}
      postfixIcon={() => <ArrowForwardIosIcon.default />}
      type="submit"
      disabled={processing}
      loading={processing}
      onClick={handlePayCB}
    >
      {t("Pay with Ticket")}
    </Button>
  );

  const getStyles = () => {
    if (hide)
      return {
        display: "none"
      };
    if (hasPgGroup) {
      return {
        display: "none"
      };
    }

    return {
      display: "block"
    };
  };

  const renderPGElementBox = () => {
    if (hide || !hasPgGroup) return null;

    return (
      <PGPaymentBox
        name={t("Ticket")}
        icon={<TicketPayRed />}
        selected={hasChoosen}
        toggleVisibility={() => toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.TicketPay })}
      />
    );
  };

  const {
    DrawerElement,
    openCPFDrawer,
    additionalData: documentData
  } = useCPFDrawer({
    paymentCB: handlePay as any,
    enabled: props.pg.config.extraConfig.enableDocumentCollection
  });

  useEffect(() => {
    setPaymentMethodReference({
      pgId: props.pg.id,
      paymentMethod: PaymentElementEnum.TicketPay,
      fn: localSubmit
    });
  }, [total]);

  useEffect(() => {
    if (!hide) {
      setAddPGMethod({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.TicketPay });
    }
  }, [hide]);

  return (
    <>
      {DrawerElement}
      {renderPGElementBox()}
      <div style={getStyles()}>{buttonElement}</div>
      {hasChoosen && (
        <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{buttonElement}</ReactPortal>
      )}
    </>
  );
};
export default Ticket;
