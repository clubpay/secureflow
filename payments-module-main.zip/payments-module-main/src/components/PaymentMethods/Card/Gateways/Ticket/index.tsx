import TicketCloak from "@/components/GatewayCloaks/Ticket";
import { useSnackbar } from "@/hooks";
import { PaymentOptions } from "@/types";
import Ticket from "./Ticket";

export default function (props: PaymentOptions) {
  useSnackbar(props.plugins?.snackbar);

  return (
    <TicketCloak>
      <Ticket {...props} />
    </TicketCloak>
  );
}
