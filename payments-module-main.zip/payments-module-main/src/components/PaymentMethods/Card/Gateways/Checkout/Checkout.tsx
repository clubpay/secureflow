import React, { ReactElement, useEffect, useRef, useState } from "react";
import {
  CardNumber,
  Cvv,
  ExpiryDate,
  FrameCardBinChangedEvent,
  FrameCardTokenizationFailedEvent,
  FrameCardTokenizedEvent,
  FrameValidationChangedEvent,
  Frames
} from "frames-react";
import PaymentAPIManager from "@/api/gateways";
import { Button } from "@/components/Core";
import { default as Input } from "@/components/Core/Input";
import { default as InputStyles } from "@/components/Core/Input/styles";
import Dialog from "@/components/Global/Dialog";
import { cardValidations } from "@/constants/cards";
import storage from "@/constants/storage";
import { useCard, useLocale } from "@/hooks";
import { useLockUnlock, usePersistToast, useSavedCards, useToast } from "@/hooks";
import { useExchangeInterruption } from "@/hooks/exchange";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { usePgEvent } from "@/hooks/pg-events";
import useSentry from "@/hooks/sentry";
import Naps from "@/icons/Naps";
import NoBalanceIcon from "@/icons/NoBalanceIcon";
import { t as t2 } from "@/locales";
import { usePayment } from "@/providers";
import { hasSavedCardClicked } from "@/stores/cardStore";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { ConsumerTypes } from "@/types";
import { PaymentOptions } from "@/types";
import { CheckoutConfig } from "@/types/payments/config/checkout";
import { constructBasePaymentPayload, gaEventSuffix } from "@/utils";
import { getExpiryPlaceHolder } from "@/utils";
import { getPaymentExchangeDecision } from "@/utils/payments/exchange";
import { AmericanExpressLogoIcon } from "@clubpay/customer-common-module/src/component/SVG";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { Span } from "@sentry/nextjs/types/client";
import CardLayoutSkeleton from "../../Layout/Skeleton";
import { default as CardLayout } from "../../Layout/layout";
import SavedCard from "../../components/common/SavedCard";
import "./Checkout.module.scss";
import {
  getLocaleCardText,
  isAmexCard,
  isCheckoutError,
  isNapsBin,
  maskAndFormatNumber,
  retrieveCheckoutError,
  shouldPersistMessage,
  shouldShowInNewToast
} from "./Checkout.util";

interface ToastContent {
  title: string;
  message: string;
  button: ReactElement | null;
  icon: ReactElement | null;
}

const CheckoutCardPayment = (props: PaymentOptions) => {
  const { variant = "primary", amount = 2, currency = "AED", qlub, pg, isSubscriptionPayment } = props;
  const gatewayId = pg.id;
  const pgName = pg.name;
  const exchange = qlub?.exchange;
  const config = pg.config as CheckoutConfig;

  const pgSignature = `${props.pg.id}-${PaymentElementEnum.CardPay}`;

  const countryCode = (config?.countryCode || pg.vendor.country.code)?.toUpperCase();

  const [showNapsDialog, setShowNapsDialog] = useState(false);

  const { startTrace, infoLog } = useSentry(props);

  const { sendEvent } = usePgEvent({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });

  const { totalAmount: totalByClient } = props;
  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });

  const [openToast, setOpenToast] = useState(false);

  const toastContentRef = useRef<ToastContent>({
    title: "",
    message: "",
    button: null,
    icon: null
  });

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).checkout;

  const { savedCards, setSavedCards, setSelectedCard, selectedCard } = useSavedCards(props);

  const { triggerInterruption } = useExchangeInterruption({
    paymentOptions: props,
    paymentMethod: PaymentElementEnum.CardPay
  });

  const {
    state: { consumer }
  } = useCommonStore((state: any) => state);

  const [frameValidation, setFrameValidation] = useState({
    "card-number": { element: "card-number", isValid: false, isEmpty: false },
    "expiry-date": { element: "expiry-date", isValid: false, isEmpty: false },
    "cvv": { element: "cvv", isValid: false, isEmpty: false }
  });

  const { displayMessage, displayError } = useToast();
  const { showMessage: showPersistMessage } = usePersistToast();

  const billMetaDataRef = useRef<any>(null);

  const traceIdRef = useRef("");

  const totalAmount = typeof totalByClient !== "undefined" ? totalByClient : amount;

  billMetaDataRef.current = { tip: qlub?.tip ? qlub.tip.toFixed(2) : "0.00" };

  const { onBeforePayment, onPaymentSuccess, onPaymentFailure, onPaymentPending } = config.events ?? {};

  const { isCardMada, cardNumber, expiryDate, securityCode, setCardNumber, setExpiryDate, setSecurityCode, setBin } =
    useCard();

  const isSavedCard = hasSavedCardClicked(pgSignature);

  const { setProcessing } = usePayment();

  const { getCallbackUrl } = useConfirmCallback();

  const { isRTL } = useLocale(props.locale);

  const referenceRef = useRef<null | string>(null);
  const [componentKey, setComponentKey] = useState(getRandomString());

  const isCustomCardTextAvailable = getLocaleCardText(config?.extraConfig, props.locale);

  const handleChangeInput = (e: any) => {
    const { element, isValid, isEmpty } = e;
    const error = isValid || isEmpty ? null : cardValidations["invalid"][element];
    if (element === "card-number") {
      setCardNumber({ ...cardNumber, error });
    } else if (element === "expiry-date") {
      setExpiryDate({ ...expiryDate, error });
    } else if (element === "cvv") {
      setSecurityCode({ ...securityCode, error });
    }
    if (!error) Frames.enableSubmitForm();
  };

  const onBinChange = (e: FrameCardBinChangedEvent) => {
    setBin(e.bin);
    if (isAmexCard(e.bin) && pg.config.extraConfig?.disableAmexCard) {
      toastContentRef.current.title = t2("AMEX card detected");
      toastContentRef.current.message = t2("American Express is not supported, please try another card.");
      toastContentRef.current.button = <Button onClick={handleToastClose}>{t2("Try another card")}</Button>;
      toastContentRef.current.icon = <AmericanExpressLogoIcon />;

      setOpenToast(true);
      return;
    }
    if (isNapsBin(e.bin) && countryCode === "QA") {
      sessionStorage.setItem(storage.NAPS_ALERT_TRIGGERED, "true");
      setShowNapsDialog(true);
      sendEvent("naps_alert_triggered");
    }
  };

  const handleToastClose = () => {
    setOpenToast(false);
    Frames.init();
  };

  const makePayment = async (e?: FrameCardTokenizedEvent) => {
    let response = null;
    const event = {
      paymentElement: PaymentElementEnum.CardPay,
      refId: referenceRef.current as string,
      traceId: traceIdRef.current,
      meta: {
        gaEventSuffix: gaEventSuffix(savedCards),
        isExchangeInterrupted: !!qlub?.exchange,
        isExchangeUsed: qlub?.exchange?.isApplied
      }
    };

    const returnUrl = getCallbackUrl({
      ref: referenceRef.current as string,
      method: pgName,
      paymentElement: PaymentElementEnum.CardPay,
      dsi: qlub?.diningSessionId || "",
      amount: amount || "",
      currencySymbol: props.country,
      traceId: traceIdRef.current,
      lang: props.locale || "",
      is3ds: true
    });

    try {
      const payload = {
        ...constructBasePaymentPayload(
          gatewayId,
          traceIdRef.current,
          qlub,
          referenceRef.current as string,
          billMetaDataRef.current.tip
        ),
        isSplitPayment: qlub.isSplitPayment,
        exchangeDecision: getPaymentExchangeDecision(exchange, pgName)
      };

      saveLastPayment({ isSavedCard: Boolean(selectedCard), cardBrand: e?.scheme });

      try {
        if (savedCards && selectedCard) {
          response = await api.payBySavedCard({
            ...payload,
            id: getSession(),
            failureUrl: returnUrl.fail,
            successUrl: returnUrl.success,
            sourceId: savedCards.sourceId,
            isMada: savedCards.isMada,
            annotations: {
              paymentMethod: "saved_card",
              funnel: consumer
            }
          });
        } else {
          response = await api.payByToken({
            cardToken: e?.token,
            cardType: isCardMada() ? "mada" : e?.card_type,
            diningSessionID: qlub?.diningSessionId,
            exchangeDecision: getPaymentExchangeDecision(exchange, pgName),
            failureUrl: returnUrl.fail,
            gatewayID: gatewayId,
            id: getSession(),
            isSplitPayment: props.pg?.hasSplitPayment || false,
            issuerCountry: e?.issuer_country,
            reference: referenceRef.current as string,
            saveCard: isSavedCard,
            scheme: e?.scheme,
            successUrl: returnUrl.success,
            tipAmount: billMetaDataRef.current.tip,
            productType: e?.product_type,
            subscribe: isSubscriptionPayment,
            annotations: {
              paymentMethod: PaymentElementEnum.CardPay,
              funnel: consumer
            }
          });
        }

        if (response?.data?.exchangeData) {
          unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
          triggerInterruption(response.data);

          return;
        }
        if (response?.data?.needVerification) {
          if (!response.data.redirectUrl) {
            displayMessage(t2(retrieveCheckoutError(frameValidation, "otp")), undefined, { autoHide: true });
          }

          sendEvent("payment_initialized", {
            status: "3ds",
            isExchangeInterrupted: Boolean(exchange),
            isExchangeUsed: Boolean(exchange?.isApplied)
          });

          window.location.href = response.data.redirectUrl;
        } else {
          onPaymentSuccess?.(event);
          !config.extraConfig?.disableToast && displayMessage(t2("Successfully Paid!"), "success");
        }
      } catch (error: any) {
        if (!error?.data && consumer != ConsumerTypes.PAYMENT_LINK) {
          onPaymentPending?.(event);
          return;
        } else throw error;
      }
    } catch (err: any) {
      const errorMessage = err?.response?.data?.message || err?.data?.message;
      const match = isCheckoutError(errorMessage);
      if (match) {
        if (shouldShowInNewToast(errorMessage)) {
          toastContentRef.current.title = t2("Insufficient balance");
          toastContentRef.current.message = t2(
            "Payment failed because of insufficient balance on this card. Click below to retry payment with a different card."
          );
          toastContentRef.current.button = <Button onClick={handleToastClose}>{t2("Try another card")}</Button>;
          toastContentRef.current.icon = <NoBalanceIcon />;

          setOpenToast(true);
        } else {
          const messageContent = retrieveCheckoutError(frameValidation, errorMessage);
          const shouldPersist = shouldPersistMessage(messageContent);
          if (shouldPersist) {
            showPersistMessage(t2(messageContent));
          } else {
            displayMessage(t2(messageContent), undefined, {
              autoHide: true
            });
          }
        }
        unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
      } else {
        const error = {
          ...event,
          ...(err?.response?.data || {})
        };
        onPaymentFailure?.(error);
      }
    } finally {
      setProcessing(false);
    }
  };

  const { state, toggleVisibility } = usePGGroupStore((state) => state);
  const hasPgGroup = state.isPGGroupEnabled;

  const hasChoosen = isPaymethodChoosed({ pgId: props?.pg.id, paymentMethod: PaymentElementEnum.CardPay });

  const renderSavedCard = () => {
    if (!savedCards) return null;

    if (!hasPgGroup || (hasPgGroup && hasChoosen)) {
      return (
        <SavedCard
          selected={selectedCard}
          maskedNumber={maskAndFormatNumber(savedCards.bin, savedCards.last4)}
          brand={savedCards.scheme.toLowerCase()}
          onSelect={() => {
            setSelectedCard(true);
          }}
          onChangeClick={() => {
            setSelectedCard(false);
          }}
          onUnsaveClick={() => {
            unsaveCardHandler();
          }}
        />
      );
    }
    return null;
  };

  const handleSubmit = async (e?: React.MouseEvent, payload?: any) => {
    e?.preventDefault();

    startTrace("pay", PaymentElementEnum.CardPay, async (span: Span) => {
      setProcessing(true);
      referenceRef.current = getRandomString();
      traceIdRef.current = span?.traceId;
      const event = {
        paymentElement: PaymentElementEnum.CardPay,
        refId: referenceRef.current as string,
        traceId: traceIdRef.current,
        meta: {
          gaEventSuffix: gaEventSuffix(savedCards),
          isExchangeInterrupted: !!qlub?.exchange,
          isExchangeUsed: qlub?.exchange?.isApplied
        }
      };

      try {
        const onBeforeRes = await onBeforePayment?.({
          gatewayId,
          paymentElement: PaymentElementEnum.CardPay,
          tip: billMetaDataRef.current.tip,
          meta: {
            gaEventSuffix: gaEventSuffix(savedCards)
          }
        });

        if (!onBeforeRes) {
          infoLog("onBefore api Fail");
          setProcessing(false);
          return;
        }
        infoLog("onBefore api Success");

        infoLog("locking mechanism Initialize");

        const lockResponse = await lock(event);

        if (!lockResponse) {
          infoLog("locking mechanism Fail");
          setProcessing(false);
          return;
        }

        infoLog("locking mechanism Success");

        if (selectedCard && savedCards) {
          if (onBeforeRes) await makePayment();
        } else if (Frames.isCardValid()) {
          const response = await Frames.submitCard();
          await makePayment(response);
        } else {
          infoLog("Checkout Error");
          checkoutCardErrorHandler();
          throw "Card is not valid";
        }
      } catch (e: any) {
        infoLog("Checkout Error");
        console.log("checkout error", e);
        unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
      } finally {
        setProcessing(false);
        Frames.enableSubmitForm();
      }
    });
  };

  const onCardTokenizeFailure = (e: FrameCardTokenizationFailedEvent) => {
    displayError("card-generic");
  };

  const unsaveCardHandler = async () => {
    if (!savedCards) {
      return;
    }
    try {
      const response = await api.unsaveCard();

      if (response.data.result) {
        setSavedCards(null);
        setSelectedCard(false);
        displayMessage(t2("Card has been deleted"), "success");
        return;
      }
      displayMessage(t2("Something went wrong while deleting card"), "error");
    } catch (e) {
      console.log("e", e);
      displayMessage(t2("Something went wrong while deleting card"), "error");
    }
  };

  const frameValidationChangeHandler = (e: FrameValidationChangedEvent) => {
    setFrameValidation((prevState) => ({ ...prevState, [e.element]: { ...e } }));
  };

  const checkoutCardErrorHandler = () => {
    displayMessage(t2(retrieveCheckoutError(frameValidation)), undefined, { autoHide: true });
  };

  const handleRetryPayment = () => {
    setShowNapsDialog(false);
    toggleVisibility({ pgId: pg.id, paymentMethod: PaymentElementEnum.QPay });
  };

  const card = (props: any) => <Input element={CardNumber} error={cardNumber.error} {...props} />;

  const expiry = (props: any) => <Input element={ExpiryDate} error={expiryDate.error} {...props} />;

  const cvv = (props: any) => <Input element={Cvv} error={securityCode.error} {...props} />;

  useEffect(() => {
    if (isRTL) {
      setComponentKey(getRandomString());
    }
  }, [isRTL]);

  if (!config.publicKey) return <CardLayoutSkeleton />;

  return (
    <Frames
      key={componentKey}
      config={{
        publicKey: config.publicKey,
        localization: {
          cardNumberPlaceholder: "1234 1234 1234 1234",
          expiryMonthPlaceholder: getExpiryPlaceHolder("month"),
          expiryYearPlaceholder: getExpiryPlaceHolder("year"),
          cvvPlaceholder: "123"
        },
        modes: isRTL ? ["right_to_left"] : undefined,
        style: {
          base: InputStyles[variant]?.input.attributes,
          invalid: { color: "#9e2146" },
          placeholder: {
            base: {
              color: "#b0acac80"
            }
          }
        }
      }}
      cardBinChanged={onBinChange}
      cardTokenizationFailed={onCardTokenizeFailure}
      cardValidationChanged={handleChangeInput}
      frameValidationChanged={frameValidationChangeHandler}
    >
      <Dialog
        open={showNapsDialog}
        title={t2("NAPS card detected")}
        description={t2("For NAPS card please retry using the NAPS payment field")}
        icon={<Naps height={48} width={48} />}
        action={<Button onClick={handleRetryPayment}>{t2("Retry payment")}</Button>}
      />
      <Dialog
        open={openToast}
        title={toastContentRef.current.title}
        description={toastContentRef.current.message}
        action={toastContentRef.current.button}
        icon={toastContentRef.current.icon}
        isRTL={isRTL}
      />
      <CardLayout
        isSaveCardSelected={selectedCard}
        elements={{ card, expiry, cvv }}
        onSubmit={handleSubmit}
        variant={variant}
        amount={totalAmount}
        currency={currency}
        qlub={qlub}
        api={{
          cardStorage: { fetchSavedCards: api.getSavedCardDetails }
        }}
        enableCardSaving={!config?.extraConfig?.disableSavedCard}
        hide={config?.extraConfig?.hideCardPay}
        savedCardSlot={renderSavedCard()}
        paymentMethodData={{
          name:
            countryCode?.toLowerCase() === "qa" && Boolean(isCustomCardTextAvailable)
              ? isCustomCardTextAvailable
              : false
        }}
        {...props}
      />
    </Frames>
  );
};

export default CheckoutCardPayment;
