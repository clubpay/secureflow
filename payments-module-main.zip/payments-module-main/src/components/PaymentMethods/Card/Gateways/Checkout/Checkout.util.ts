import { pickBy, size, some } from "lodash";
import { t } from "@/locales";
import { parseJSON } from "@clubpay/customer-common-module/src/utility/k_json";

interface frameData {
  element: string;
  isValid: boolean;
  isEmpty: boolean;
}

interface CardData {
  ["card-number"]: frameData;
  ["expiry-date"]: frameData;
  cvv: frameData;
}

const baseError = (message?: string): string | undefined => message?.replace(/(\[.+])/g, "");

const napsBins = [
  401633, 405750, 406626, 411981, 412585, 414393, 415180, 416639, 416966, 417391, 420375, 42037500, 421537, 421602,
  423926, 428246, 428681, 428682, 428683, 428684, 428685, 428686, 432229, 433033, 434141, 434204, 443993, 447526,
  457658, 465002, 467895, 471258, 471354, 472839, 484823, 489328, 494047, 49404700, 510463, 510471, 514679, 516076,
  518189, 522237, 526040, 526729, 526900, 526904, 527158, 531801, 532704, 532715, 532716, 533103, 533106, 533123,
  535849, 535868, 536335, 536547, 543726, 555479, 557628, 557649, 557685, 557686, 564149, 589455, 622016, 63995000,
  63995001, 63995002, 63995003, 63995004, 63995005, 63995006, 63995007, 63995008, 63995009, 63995010, 63995011,
  63995012, 63995017, 63995020, 63995021, 63995022, 63995023, 63995024, 63995025, 63995026
];

export const isNapsBin = (bin: string) => {
  return !!napsBins.find((napsBin) => bin.startsWith(napsBin.toString()));
};

const extractError = (message?: string): string | undefined => {
  if (!message) return;
  let extractedError = baseError(message);
  const errorCode = message?.match(/\[(\d+)\]/)?.[1];
  if (!errorCode) return extractedError;
  switch (errorCode) {
    case "20005":
    case "20059":
    case "20183":
    case "20179":
      extractedError =
        "The payment has been declined by your bank. Please try a different card or contact your bank for further support";
      break;
    case "20151":
      extractedError =
        "The payment has been declined due to failed 3DS authentication. Please try again with the same card, or use a different card";
      break;
    case "20153":
      extractedError =
        "The payment failed due to a technical issue. Please try again with the same card, or use a different card";
      break;
    case "20154":
      extractedError = "The payment declined by the bank. Please try again with the same card, or use a different card";
      break;
    case "20182":
      extractedError = "The payment failed, please check your card details and try again with the same or another card";
      break;
  }
  return extractedError;
};

export const errors = {
  isCheckoutError: (message?: string) => Boolean(baseError(message)),
  show: (message?: string) => {
    message = extractError(message);
    window.snackbar.enqueue(t(message ?? "Payment did not proceed. Please check the details and retry"), {
      variant: "warning"
    });
  }
};

export const formatMaskedCard = (cardNumber: string) => {
  return cardNumber
    .replace(/x/g, "•")
    .replace(/(.{4})/g, "$1 ")
    .trim();
};

export const maskAndFormatNumber = (binStr: string, last4: string): string => {
  return formatMaskedCard(`${binStr}${"*".repeat(6)}${last4}`);
};

export const isCheckoutError = (message?: string) => {
  return Boolean(message?.replace(/(\[.+])/g, ""));
};

const getErrorMessage = (message?: string) => {
  if (!message) {
    return;
  }
  const extractedError = message?.replace(/(\[.+])/g, "");

  const errorCodeMatch = message?.match(/\[(\d+)\]/);

  const errorCode = errorCodeMatch ? errorCodeMatch[1] : null;
  if (!errorCode) {
    return extractedError;
  }

  let errorContent = "";

  switch (errorCode) {
    case "20005":
      errorContent =
        "The payment has been declined by your bank. Please try a different card or contact your bank for further support";

      break;
    case "20151":
      errorContent =
        "The payment has been declined due to failed 3DS authentication. Please try again with the same card, or use a different card";

      break;
    case "20059":
      errorContent =
        "The payment has been declined by your bank. Please try a different card or contact your bank for further support";

      break;
    case "20153":
      errorContent =
        "The payment failed due to a technical issue. Please try again with the same card, or use a different card";

      break;
    case "20154":
      errorContent = "The payment declined by the bank. Please try again with the same card, or use a different card";

      break;
    case "20179":
      errorContent =
        "The payment has been declined by your bank. Please try a different card or contact your bank for further support";

      break;
    case "20182":
      errorContent =
        "The payment has been declined by your bank. Please try a different card or contact your bank for further support";

      break;
    case "20183":
      errorContent =
        "The payment has been declined by your bank. Please try a different card or contact your bank for further support";

      break;
    case "20082":
      errorContent = "The payment failed, please check your card details and try again with the same or another card";

      break;
    case "20051":
      errorContent = "Please try another card, the one used does not have sufficient balance";

      break;
    default:
      errorContent = extractedError;
      break;
  }

  return errorContent;
};

export const retrieveCheckoutError = (cardData: CardData, errorMsg?: string) => {
  const errorTypes: Record<string, string> = {
    "multiple-frame": "Card information is invalid. Please check the details and retry",
    "card-number": "Card number is invalid. Please check the details and retry",
    "expiry-date": "Expiry date is invalid. Please check the details and retry",
    "cvv": "CVV is invalid. Please check the details and retry",
    "otp": "OTP is invalid. Please check the details and retry",
    "generic": "Payment did not proceed. Please check the details and retry"
  };

  if (errorMsg !== undefined) {
    const errorMessage = getErrorMessage(errorMsg);
    if (errorMessage) {
      return errorMessage || errorMsg;
    }
  }

  const notValidCounter = size(
    pickBy(cardData, (obj: any) => {
      return !obj.isValid;
    })
  );

  const hasAnyError = some(cardData, (obj: any) => {
    return !obj.isValid;
  });

  if (notValidCounter >= 2 && hasAnyError) {
    return errorTypes["multiple-frame"];
  }

  const error = Object.keys(cardData).find((key) => !cardData[key as keyof CardData].isValid);

  if (error) {
    return errorTypes[error];
  }
  return errorTypes["generic"];
};

export const shouldPersistMessage = (message: string) => {
  return ["Please try another card, the one used does not have sufficient balance"].includes(message);
};

export const shouldShowInNewToast = (message: string) => {
  const pattern = /\[(\d+)\]/;

  const match = message.match(pattern);

  if (match && match.length >= 2) return ["20051"].includes(match[1]);

  return false;
};

export const isAmexCard = (bin: string = "") => {
  return /^(34|37)/.test(bin);
};

export const getLocaleCardText = (config: any, lang: string | string[]) => {
  const locale = parseJSON(config?.cardCustomText)?.find((item: any) => item.locale === lang);
  return locale?.value ?? false;
};
