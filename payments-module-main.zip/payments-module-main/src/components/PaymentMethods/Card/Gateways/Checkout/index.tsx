import { default as CheckoutCloak } from "@/components/GatewayCloaks/Checkout";
import { useSnackbar } from "@/hooks";
import { PaymentOptions } from "@/types";
import { default as CheckoutCardPayment } from "./Checkout";

export default function (props: PaymentOptions) {
  useSnackbar(props.plugins?.snackbar);

  const handleReady = () => props.pg.config.events?.onReady?.();

  return (
    <CheckoutCloak onReady={handleReady} pg={props.pg}>
      <CheckoutCardPayment {...props} />
    </CheckoutCloak>
  );
}
