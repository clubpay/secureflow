import { default as MoyasarCloak } from "@/components/GatewayCloaks/Moyasar";
import { useSnackbar } from "@/hooks";
import { getTotal } from "@/stores/commonStore";
import { PaymentOptions } from "@/types";
import MoyasarPayment from "./Moyasar";

export default function (props: PaymentOptions) {
  useSnackbar(props.plugins?.snackbar);

  const shouldMoyasarDeactive =
    props.billPaidStatus == "paid-true" ||
    props.billPaidStatus == "partial-true" ||
    props.billPaidStatus == "paid-false";
  return (
    <MoyasarCloak onReady={props.pg.config.events?.onReady}>
      {!shouldMoyasarDeactive ? <MoyasarPayment {...props} /> : <></>}
    </MoyasarCloak>
  );
}
