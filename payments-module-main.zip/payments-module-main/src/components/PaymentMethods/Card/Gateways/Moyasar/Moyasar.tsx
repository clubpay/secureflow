import { useEffect, useRef, useState } from "react";
import PaymentAPIManager from "@/api/gateways";
import BillAPIManager from "@/api/general/bill";
import { Button, Divider } from "@/components/Core";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import PaymentLoadingDialog from "@/components/Global/PaymentLoadingDialog";
import PaymentTerms from "@/components/Global/PaymentTerms";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLocale, useLockUnlock, useToast, useTrace } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { usePgEvent } from "@/hooks/pg-events";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { getTotal, useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { ConsumerTypes, PaymentOptions } from "@/types";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { IStartSpanResponse } from "@clubpay/customer-common-module/src/hook/useSentryTrace";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import styles from "./Moyasar.module.scss";
import { createStatementDescriptor } from "./Moyasar.util";

export default ({ variant = "primary", amount = 2, qlub, ...props }: PaymentOptions) => {
  const total = getTotal();
  const { getCallbackUrl } = useConfirmCallback();

  const generalAPI = BillAPIManager.getInstance();

  const { state: store, lock: lockUI } = useCommonStore((store) => store);
  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });

  const isLoaded = store.loadedState?.["moysarV1"];

  const [initialized, setInitialized] = useState(false);
  const traceStart = useTrace(props.pg);
  const { displayMessage, displayError } = useToast();

  const traceRef = useRef<IStartSpanResponse | undefined>();
  const moysarFormRef = useRef<any>(null);
  const referenceRef = useRef<null | string>(null);

  const { processing, setProcessing } = usePayment();

  const {
    state: { isLocked }
  } = useCommonStore((state) => state);

  const config = props.pg.config;
  const gatewayId = props.pg.id;
  const gatewayName = props.pg.name;
  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).moyasarV2;

  const locale = props?.locale;

  const tipAmount = qlub?.tip ? qlub.tip.toFixed(2) : "0.00";

  const { state, toggleVisibility, setAddPGMethod, setPaymentMethodReference } = usePGGroupStore((state) => state);

  const hasPgGroup = state.isPGGroupEnabled;

  const hasChoosen = isPaymethodChoosed({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.CardPay });

  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const { sendEvent } = usePgEvent({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });

  const { onBeforePayment, onPaymentFailure } = config.events ?? {};

  const { isRTL } = useLocale(props.locale);

  const {
    state: { consumer }
  } = useCommonStore((state: any) => state);

  const statementDescriptor: string = createStatementDescriptor(props?.pg?.vendor ?? {});

  const initMoyasar = () => {
    if (total) init();
  };

  const handleInitating = async (reference: string) => {
    traceRef.current = traceStart?.startSpan({
      dataName: gatewayName ?? "anonymous",
      span: {
        element: PaymentElementEnum.CardPay,
        refId: reference
      }
    });

    sendEvent("payment_initialized", {
      paymentMethod: PaymentElementEnum.CardPay
    });

    setProcessing(true);
    const event = {
      paymentElement: PaymentElementEnum.CardPay,
      refId: reference,
      traceId: traceStart?.traceId
    };

    try {
      const onBeforeRes = await onBeforePayment?.({
        gatewayId,
        paymentElement: PaymentElementEnum.CardPay,
        tip: qlub?.tip ?? 0
      });

      if (!onBeforeRes) {
        setProcessing(false);
        return false;
      }

      const lockResponse = await lock(event);

      if (!lockResponse) {
        setProcessing(false);
        throw "FORCE_FAILED";
      }

      await api.initiatePayment({
        gatewayId: gatewayId,
        reference: referenceRef.current,
        tipAmount: tipAmount,
        diningSessionID: qlub?.diningSessionId || "",
        id: getSession(),
        paymentMethod: PaymentElementEnum.CardPay,
        source: "creditcard",
        annotations: {
          paymentMethod: PaymentElementEnum.CardPay,
          funnel: consumer
        }
      });

      return true;
    } catch (e) {
      initMoyasar();
      unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
      if (!config.extraConfig?.disableToast && e !== "FORCE_FAILED") displayError();
      setProcessing(false);
      if (store.consumer === ConsumerTypes.PAYMENT_LINK) return Promise.reject(e);
      return false;
    }
  };

  const handleComplete = () => {
    try {
      generalAPI.getStatus({
        reference: referenceRef.current,
        diningSessionID: qlub?.diningSessionId || "",
        id: getSession(),
        source: "creditcard"
      });

      saveLastPayment({});
    } catch (e: any) {
      unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
    }
  };

  const paymentCallbackFn = (event: React.MouseEvent) => {
    event?.preventDefault();
    moysarFormRef.current?.querySelector(".mysr-form-card button.mysr-form-button")?.click();
    lockUI(6000);
  };

  const localOnSubmit = (e: React.MouseEvent) => {
    e?.preventDefault();

    if (props.pg.config.events?.onPrePayment)
      props.pg.config.events?.onPrePayment(paymentCallbackFn, PaymentElementEnum.CardPay);
    else {
      paymentCallbackFn(e);
    }
  };

  const handleFailure = (payload: any) => {
    if (store.consumer === ConsumerTypes.PAYMENT_LINK) {
      const error = payload.endsWith("FORCE_FAILED") ? "FORCE_FAILED" : payload;
      onPaymentFailure?.(error);
    }
    if (store.consumer === ConsumerTypes.CUSTOMER_APP) {
      if (payload?.startsWith("3-D Secure transaction attempt failed")) {
        displayMessage(payload, "error", {
          style: {
            direction: "ltr"
          }
        });
      }
    }
  };

  const init = async () => {
    const moyasar = (window as any)?.Moyasar ?? null;
    if (!moyasar) {
      return Promise.reject("select tip");
    }

    referenceRef.current = getRandomString();

    console.log("REFERENCE::", referenceRef.current);

    const returnUrl = getCallbackUrl({
      ref: referenceRef.current ?? "",
      method: gatewayName || "",
      paymentElement: PaymentElementEnum.CardPay,
      dsi: qlub?.diningSessionId || "",
      amount: amount || "",
      currencySymbol: props.country,
      traceId: traceStart?.traceId,
      lang: locale
    });

    moyasar.init({
      element: ".mysr-form-card",
      metadata: {
        reference: referenceRef.current,
        diningSessionId: qlub?.diningSessionId || "",
        partyId: getSession()
      },
      amount: total * 100 + 0.5 || 0,
      currency: props.pg.vendor.country.currencyCode?.toUpperCase() || "",
      description: "Payment for order",
      publishable_api_key: config.publicKey,
      callback_url: returnUrl.pending,
      methods: ["creditcard"],
      direction: isRTL ? "RTL" : "LTR",
      fixed_width: false,
      language: locale,
      statement_descriptor: statementDescriptor,
      on_initiating: () => handleInitating(referenceRef.current || ""),
      on_completed: () => handleComplete(),
      on_failure: (error: any) => {
        setProcessing(false);
        unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
        initMoyasar();
        handleFailure(error);
      }
    });
    setInitialized(true);
  };

  const buttonElement = (
    <Button
      variant={variant}
      className={styles["pay-btn"]}
      disabled={processing}
      loading={processing}
      onClick={localOnSubmit}
    >
      {t("Pay")}
    </Button>
  );

  const getStyles = () => {
    if (hasPgGroup) {
      if (hasChoosen)
        return {
          display: "block",
          paddingTop: "12px"
        };

      return {
        display: "none"
      };
    }
    return {
      display: "block"
    };
  };

  const renderContent = () => {
    if (hasPgGroup) return null;
    return (
      <div className={styles["submit-area"]}>
        <PaymentTerms className={styles.terms} />
        <Divider />
        {buttonElement}
      </div>
    );
  };

  const addAlertContainerObserver = () => {
    const element = document.querySelectorAll(".mysr-form-alertContainer")?.[1];

    if (element)
      alertmutationObserver.observe(element, {
        childList: true,
        subtree: true
      });
  };

  const mutationObserver = new MutationObserver(async () => {
    const buttons = moysarFormRef.current?.querySelectorAll(".mysr-form-card button.mysr-form-button");
    if (buttons?.length) {
      addAlertContainerObserver();
      buttons?.[buttons?.length - 1]?.style.setProperty("display", "none");
    }
  });

  const alertmutationObserver = new MutationObserver(async () => {
    const element: any = document.querySelectorAll(".mysr-form-card .mysr-form-alertContainer")?.[1];
    if (element) {
      element?.style.setProperty("display", "none");
    }
  });

  useEffect(() => {
    const moyasar = (window as any)?.Moyasar ?? null;
    const element = document.getElementById("mysr-form-form-el");

    if (!moyasar || !element) {
      return;
    }

    if (moyasar && Number(total) > 0) {
      moyasar.setAmount(Math.round(total * 100));
    }
  }, [total, initialized]);

  useEffect(() => {
    if (isLoaded) initMoyasar();
  }, [isLoaded, total, locale]);

  useEffect(() => {
    if (isLoaded) {
      setAddPGMethod({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.CardPay });
    }
  }, [isLoaded]);

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.CardPay,
      fn: paymentCallbackFn
    });
  }, [amount, tipAmount]);

  useEffect(() => {
    if (moysarFormRef.current) {
      mutationObserver.observe(moysarFormRef.current, {
        childList: true,
        subtree: true
      });
    }

    return () => {
      mutationObserver.disconnect();
      alertmutationObserver.disconnect();
    };
  }, []);

  return (
    <>
      <PaymentLoadingDialog open={isLocked || processing} />
      {hasPgGroup && (
        <PGPaymentBox
          name={t("Card")}
          selected={hasChoosen}
          toggleVisibility={() => toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.CardPay })}
        />
      )}

      <div style={getStyles()}>
        {total === 0 ? (
          <div className={styles.hint}>{t("Amount cannot be zero")}</div>
        ) : (
          <>
            <div className="mysr-form-card" ref={moysarFormRef} />
            {renderContent()}
          </>
        )}
      </div>

      {hasChoosen && (
        <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{buttonElement}</ReactPortal>
      )}
    </>
  );
};
