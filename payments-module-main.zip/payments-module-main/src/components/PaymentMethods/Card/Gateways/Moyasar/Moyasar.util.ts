export const createStatementDescriptor = (vendor: any) => {
  const specialCharactersRegex = /[^a-zA-Z0-9\s]/g;
  const { unique } = vendor || {};

  let restaurantName: string = vendor?.name || unique;
  if (restaurantName.length > 13) {
    restaurantName = restaurantName.substring(0, 13);
  }

  let restaurantUnique: string = unique;
  if (restaurantUnique.length > 13) {
    restaurantUnique = restaurantUnique.substring(0, 13);
  }

  const nameOrUnique = restaurantName || restaurantUnique;

  const nameOrUniqueWithoutSpecialCharacters = nameOrUnique.replace(specialCharactersRegex, "");

  return `${nameOrUniqueWithoutSpecialCharacters} qlub ${vendor.country.code}`.toLowerCase();
};

export const PL_FORCE_FAILED_NEEDED_ERROR_LIST = ["Invalid handler result false"];
