import { useRef } from "react";
import PaymentAPIManager from "@/api/gateways";
import { default as Input } from "@/components/Core/Input";
import { useTrace } from "@/hooks";
import { useLockUnlock, useToast } from "@/hooks";
import useSentry from "@/hooks/sentry";
import { usePayment } from "@/providers";
import { PaymentOptions } from "@/types";
import { CCPPCardResponse } from "@/types/payments/config/ccpp";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { useTranslation } from "@clubpay/customer-common-module/src/hook/translations";
import { IStartSpanResponse } from "@clubpay/customer-common-module/src/hook/useSentryTrace";
import { onPushEvent } from "@clubpay/customer-common-module/src/lib/gtm";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { checkNetworkError } from "@clubpay/customer-common-module/src/utility/checkNetworkError";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { Span } from "@sentry/nextjs/types/client";
import CardLayout from "../../Layout/layout";
import { extractError } from "./CCPP.util";

const CCPPCardPayment = (props: PaymentOptions) => {
  const { variant = "primary", amount = 2, currency = "AED", qlub, locale } = props;

  const gatewayId = props.pg.id;
  const gatewayName = props.pg.name;
  const config = props.pg.config;
  const tipAmount = qlub?.tip;
  const diningSessionId = qlub?.diningSessionId;

  const traceStart = useTrace(props.pg);
  const traceRef = useRef<IStartSpanResponse | undefined>();
  const { totalAmount: totalByClient } = props;

  const { setProcessing } = usePayment();
  const { lock, unlock } = useLockUnlock({ ...props, qlub });
  const { getCallbackUrl } = useConfirmCallback();

  const { t } = useTranslation("common");
  const cvvRef = useRef<HTMLInputElement>(null);

  const { startTrace, infoLog, errorLog } = useSentry(props);

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).ccpp;

  const { displayMessage } = useToast();

  const totalAmount = typeof totalByClient !== "undefined" ? totalByClient : amount;

  const { onBeforePayment, onPaymentSuccess, onPaymentFailure, onPaymentPending, onTraceClose } = config.events ?? {};

  const handlePay = async (cardResponse: CCPPCardResponse, errorCode: number) => {
    startTrace("pay", PaymentElementEnum.CardPay, async (span: Span) => {
      const refId = getRandomString();
      const event = {
        paymentElement: PaymentElementEnum.CardPay,
        refId,
        traceId: span?.traceId
      };
      try {
        infoLog("check tip Initialize");
        const tipCheckResponse = await onBeforePayment({
          checkTipOnly: true,
          gatewayId,
          paymentElement: PaymentElementEnum.CardPay,
          tip: tipAmount ?? 0
        });

        if (!tipCheckResponse) {
          infoLog("check tip Fail");
          return;
        }

        infoLog("check tip Sucess");

        const callbackUrl = getCallbackUrl({
          ref: refId,
          method: gatewayName,
          paymentElement: PaymentElementEnum.CardPay,
          dsi: diningSessionId || "",
          amount: amount || "",
          currencySymbol: props.country,
          traceId: traceStart?.traceId,
          lang: locale
        });

        traceRef.current = traceStart?.startSpan({
          dataName: gatewayName,
          span: {
            element: PaymentElementEnum.CardPay,
            refId
          }
        });

        setProcessing(true);
        if (errorCode) {
          displayMessage(t(extractError(errorCode)), "error", { autoHide: true });
        } else if (!cardResponse.maskedCardInfo) {
          displayMessage(t(extractError(1)), "error", { autoHide: true });
        } else if (!cvvRef.current?.value) {
          displayMessage(t(extractError(11)), "error", { autoHide: true });
        } else {
          const onBeforeResponse = await onBeforePayment?.({
            gatewayId,
            paymentElement: PaymentElementEnum.CardPay,
            tip: tipAmount ?? 0
          });
          if (!onBeforeResponse) {
            infoLog("onBefore api Fail");
            return;
          }

          infoLog("onBefore api Success");

          infoLog("locking mechanism Initialize");

          const lockResponse = await lock(event);
          if (!lockResponse) {
            infoLog("locking mechanism Fail");
            return;
          }

          infoLog("locking mechanism Success");

          infoLog("payment api call Initialize");

          const paymentResponse = await api.payByCard({
            id: getSession(),
            reference: refId,
            gatewayID: gatewayId,
            diningSessionID: diningSessionId,
            tipAmount: tipAmount ? tipAmount.toFixed(2) : "0.00",
            securePayToken: cardResponse.encryptedCardInfo,
            cardNumber: cardResponse.maskedCardInfo,
            responseUrl: callbackUrl.pending,
            locale
          });

          if (paymentResponse.data.redirectUrl) {
            infoLog("payment api received redirect url Success");

            onPushEvent("payment_initialized", {
              pg_name: props.pg.name,
              status: "3ds",
              restaurant_name: qlub?.restaurant?.unique,
              diningSessionId: diningSessionId
            });
            window.location.href = paymentResponse.data.redirectUrl;
            return;
          }

          infoLog("payment api call Success");

          onPaymentSuccess?.({
            paymentElement: PaymentElementEnum.CardPay,
            refId,
            traceId: span?.traceId
          });
        }
      } catch (error: any) {
        errorLog("Payment flow Fail");
        onTraceClose?.({
          error,
          location: "payment_ccpp_card",
          traceRef,
          traceStart
        });

        unlock(event);
        const isNetworkError = checkNetworkError(error);

        if (isNetworkError) {
          onPaymentPending?.(gatewayId, event);
        } else {
          onPaymentFailure?.(event);
        }
      } finally {
        setProcessing(false);
      }
    });
  };

  const handleSubmit = async () => window.My2c2p.getEncrypted("2c2p-payment-form", handlePay);

  const card = (props: any) => <Input type="text" data-encrypt="cardnumber" maxlength="16" {...props} />;

  const expiryMonth = (props: any) => <Input type="text" data-encrypt="month" maxlength="2" {...props} />;

  const expiryYear = (props: any) => (
    <Input type="text" data-encrypt="year" maxlength="4" {...props} placeholder="2025" />
  );

  const cvv = (props: any) => (
    <Input ref={cvvRef} type="password" data-encrypt="cvv" maxlength="4" autocomplete="off" {...props} />
  );

  return (
    <CardLayout
      elements={{ card, expiryMonth, expiryYear, cvv }}
      onSubmit={handleSubmit}
      variant={variant}
      amount={totalAmount}
      currency={currency}
      qlub={qlub}
      hide={config?.extraConfig?.hideCardPay}
      formAttributes={{ id: "2c2p-payment-form" }}
      locale={locale}
      {...props}
    />
  );
};

export default CCPPCardPayment;
