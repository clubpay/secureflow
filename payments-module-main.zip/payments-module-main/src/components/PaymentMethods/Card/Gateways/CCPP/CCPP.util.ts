export const extractError = (errorCode: number) => {
  switch (errorCode) {
    case 1:
      return "Card number is required";
    case 2:
      return "Card number is invalid";
    case 3:
      return "Expiry month is required";
    case 4:
      return "Expiry month is invalid";
    case 5:
      return "Expiry year is required";
    case 6:
      return "Expiry year is invalid";
    case 7:
      return "Card expired";
    case 8:
      return "Card expired";
    case 9:
      return "Expiry month is invalid";
    case 10:
      return "CVV is invalid";
    case 11:
      return "CVV is required";
    default:
      return "Payment did not proceed. Please check the details and retry";
  }
};
