import CCPPCloak from "@/components/GatewayCloaks/CCPP";
import { useSnackbar } from "@/hooks";
import { PaymentOptions } from "@/types";
import { default as CardPayment } from "./CCPP";

export default function (props: PaymentOptions) {
  useSnackbar(props.plugins?.snackbar);

  return (
    <CCPPCloak config={props.pg.config}>
      <CardPayment {...props} />
    </CCPPCloak>
  );
}
