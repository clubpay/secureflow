import { t } from "@/locales";
import { ConsumerType, ConsumerTypes } from "@/types";
import { PaymentTypeEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { qlubSessionStorage } from "@clubpay/customer-common-module/src/service/storage/sessionStorage";
import { StripeElementLocale } from "@stripe/stripe-js";

export const disableApplePayBilling = () => {
  qlubSessionStorage.set("qlub.payment.apple.disable_billing", "true");
};

export const getApplePayShippingBillingConfig: any = (config: any, paymentGateway: PaymentTypeEnum) => {
  const isCanceled = qlubSessionStorage.get("qlub.payment.apple.disable_billing");
  if (isCanceled) return {};

  if (paymentGateway === PaymentTypeEnum.Stripe || paymentGateway === PaymentTypeEnum.StripeConnect) {
    const stripeConfig = {
      requestPayerName: false,
      requestPayerEmail: false,
      requestPayerPhone: false
    };

    if (config.applePayShippingDetails) {
      stripeConfig.requestPayerName = true;
      stripeConfig.requestPayerEmail = true;
      stripeConfig.requestPayerPhone = true;
    }
    if (config.applePayBillingDetails) {
      stripeConfig.requestPayerEmail = true;
      stripeConfig.requestPayerPhone = true;
    }

    return stripeConfig;
  }

  if (paymentGateway === PaymentTypeEnum.Tapp) {
    const tappConfig: Pick<
      ApplePayJS.ApplePayPaymentRequest,
      "requiredShippingContactFields" | "requiredBillingContactFields"
    > = {};

    if (config.applePayShippingDetails) {
      tappConfig.requiredShippingContactFields = ["phone", "email", "name"];
    }
    if (config.applePayBillingDetails) {
      tappConfig.requiredBillingContactFields = ["phone", "email", "name"];
    }

    return tappConfig;
  }

  const defaultConfig: Pick<
    ApplePayJS.ApplePayPaymentRequest,
    "requiredShippingContactFields" | "requiredBillingContactFields"
  > = {};

  if (config.applePayShippingDetails) {
    defaultConfig.requiredShippingContactFields = ["phone", "email", "name"];
  }
  if (config.applePayBillingDetails) {
    defaultConfig.requiredBillingContactFields = ["phone", "email", "name"];
  }

  return defaultConfig;
};

export const doesConsumerNeedThisError = (consumer: ConsumerType, error: string) => {
  let doesNeed = false;
  if (consumer === ConsumerTypes.PAYMENT_LINK) {
    if (error === "stripe payment hasn't confirmed") doesNeed = true;
  } else if (consumer === ConsumerTypes.CUSTOMER_APP) {
    doesNeed = true;
  }

  return doesNeed;
};

const incompleteFormErrs = ["incomplete_number", "incomplete_expiry", "incomplete_cvc", "incomplete_zip"];

export const extractError = (err?: any, message?: any) => {
  const extractedMessage = { message: t("The payment did not proceed Please try again"), variant: "error" };

  if (err && err.code) {
    if (incompleteFormErrs.indexOf(err.code) > -1) {
      extractedMessage.message = t("The card information is incorrect, Please check the details and retry");
      extractedMessage.variant = "warning";
      return extractedMessage;
    }

    if (err.code === 416 && err.items === "PAYMENT_AMOUNT_IS_ZERO") {
      extractedMessage.message = t("You are trying to pay for a bill that is already paid for");
      extractedMessage.variant = "error";

      return extractedMessage;
    }

    if (err.code === 416 && err.items === "PAYMENT_AMOUNT_IS_TOO_LARGE") {
      extractedMessage.message = t("You’re paying too much");
      extractedMessage.variant = "warning";

      return extractedMessage;
    }
  }

  if (message) {
    extractedMessage.message = message;
    extractedMessage.variant = "error";
    return extractedMessage;
  }

  return extractedMessage;
};

export const getLocale = (locale?: string) => {
  if (!locale) return "en";

  if (locale?.toLowerCase() === "hk") return "zh-HK";
  return locale as StripeElementLocale;
};

export const WAITING_MSG_SHOW_PAY_METHODS = ["paynow"];
