import React, { useEffect, useRef, useState } from "react";
import { PaymentElement, useElements, useStripe } from "@stripe/react-stripe-js";
import isEmpty from "lodash/isEmpty";
import PaymentAPIManager from "@/api/gateways";
import Button from "@/components/Core/Button";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import PaymentLoadingDialog from "@/components/Global/PaymentLoadingDialog";
import PaymentTerms from "@/components/Global/PaymentTerms";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock, useToast, useTrace } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import useSentry from "@/hooks/sentry";
import Apple from "@/icons/Apple";
import ApplePayIcon from "@/icons/ApplePay";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions, StripePaymentMethod } from "@/types";
import { StripeConfig } from "@/types/payments/config/stripe";
import { getPaymentMethodOrder } from "@/utils";
import { isEmailDisabled, isLoadingDialogRequired } from "@/utils/payments/stripe";
import { GooglePay as GPayIC } from "@clubpay/customer-common-module/src/component/SVG";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { IStartSpanResponse } from "@clubpay/customer-common-module/src/hook/useSentryTrace";
import {
  PaymentElementEnum,
  PaymentTypeEnum
} from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { trimCurrency } from "@clubpay/customer-common-module/src/utility/k_currency";
import { sumAmounts } from "@clubpay/customer-common-module/src/utility/k_math";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { Divider } from "@mui/material";
import { Span } from "@sentry/nextjs/types/client";
import type { StripeElements } from "@stripe/stripe-js";
import { PaymentRequestWallet } from "@stripe/stripe-js/types/stripe-js/payment-request";
import PGGroupViewWrapper from "../../components/common/PGGroupViewWrapper";
import styles from "./Stripe.module.scss";
import {
  WAITING_MSG_SHOW_PAY_METHODS,
  disableApplePayBilling,
  extractError,
  getApplePayShippingBillingConfig
} from "./Stripe.util";

const StripeCardPayment = (props: PaymentOptions) => {
  const { variant = "primary", amount = 2, currency = "AED", qlub } = props;

  const gatewayId = props.pg.id;
  const gatewayName = props.pg.name;

  const { totalAmount: totalByClient } = props;

  const config = props.pg.config as StripeConfig;

  const { getCallbackUrl } = useConfirmCallback();

  const enableHideGooglePay = config.extraConfig.hideGooglePay;
  const enableHideApplePay = config.extraConfig.hideApplePay;

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).stripe;

  const traceStart = useTrace(props.pg);

  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });

  const {
    state,
    setPGDependedPaymentMethodsData,
    setAddPGMethod,
    removePGMethod,
    setPaymentMethodReference,
    toggleVisibility
  } = usePGGroupStore((state: any) => state);
  const {
    state: { isPayButtonTextChangeEnabled, consumer, total },
    lock: lockUI,
    unlock: unlockUI
  } = useCommonStore((state: any) => state);

  const isFullTotalSentByClient = typeof totalByClient !== "undefined";

  const enableHideCardElement = config.extraConfig.hideCardElement;

  const hasChoosen = isPaymethodChoosed({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.CardPay });

  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const referenceIdRef = useRef("");

  const stripe = useStripe();
  const elements = useElements();

  const paymentRequestRef = useRef<any>(null);

  const [paymentRequestResult, setPaymentRequestResult] = useState<any>(null);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<StripePaymentMethod>();

  const [mobilePayButtons, setMobilePayButtons] = useState<{ applePay?: boolean; googlePay?: boolean }>({});

  const mobilePayTiggeredType = useRef<any>(null);

  const hasPgGroup = state.isPGGroupEnabled;

  const { processing, setProcessing } = usePayment();

  const { displayMessage, displayError } = useToast();

  const { startTrace, infoLog, errorLog } = useSentry(props);

  const { onBeforePayment, onPaymentSuccess, onPaymentFailure, onPaymentPending } = config.events ?? {};

  const getPaymentIntent = async (e?: any) => {
    const tipAmount = qlub?.tip || 0;

    try {
      const response = await api.createPaymentIntent({
        id: getSession(),
        reference: referenceIdRef.current,
        diningSessionID: qlub?.diningSessionId || "",
        gatewayID: gatewayId,
        automaticPaymentMethodParams: true,
        tipAmount: tipAmount.toString(),
        paymentMethod: selectedPaymentMethod,
        ...(e?.paymentMethod?.card?.country ? { issuerCountry: e.paymentMethod.card.country } : {})
      });
      if (response) {
        return response;
      }
    } catch (_) {}
  };

  const run = () => paymentRequestRef.current.show();

  const handleMobilePay = (typeName: PaymentElementEnum) => {
    mobilePayTiggeredType.current = typeName;
    if (config.events?.onPrePayment) config.events?.onPrePayment(run, "");
    else run();
  };

  const appleButtonElement = (
    <Button
      id="apple-pay-btn"
      className={styles.appleButton}
      onClick={() => handleMobilePay(PaymentElementEnum.ApplePay)}
    >
      {t("Pay with")}
      <span>
        <ApplePayIcon />
      </span>
    </Button>
  );

  const googleButtonElement = (
    <Button
      id="gooogle-pay-btn"
      className={styles.gButton}
      variant={variant}
      onClick={() => handleMobilePay(PaymentElementEnum.GooglePay)}
      loading={processing}
    />
  );

  const renderMobilePayBtns = () => {
    const buttonList: any = [];

    if (mobilePayButtons.applePay) {
      buttonList.push(
        <ReactPortal domNode={document.getElementById("pg-container")}>
          <div style={{ order: getPaymentMethodOrder(PaymentElementEnum.ApplePay, config, gatewayName) }}>
            {hasPgGroup ? (
              <PGGroupViewWrapper
                name={t("Apple Pay")}
                gatewayID={gatewayId}
                paymentMethod={PaymentElementEnum.ApplePay}
                icon={<Apple />}
              >
                {appleButtonElement}
              </PGGroupViewWrapper>
            ) : (
              appleButtonElement
            )}
          </div>
        </ReactPortal>
      );
    }
    if (mobilePayButtons.googlePay) {
      buttonList.push(
        <ReactPortal domNode={document.getElementById("pg-container")}>
          <div style={{ order: getPaymentMethodOrder(PaymentElementEnum.GooglePay, config, gatewayName) }}>
            {hasPgGroup ? (
              <PGGroupViewWrapper
                name={t("Google Pay")}
                gatewayID={gatewayId}
                paymentMethod={PaymentElementEnum.GooglePay}
                icon={<GPayIC />}
              >
                {googleButtonElement}
              </PGGroupViewWrapper>
            ) : (
              googleButtonElement
            )}
          </div>
        </ReactPortal>
      );
    }

    return buttonList;
  };

  const handleStoreEligiblePaymentMethods = (result: any) => {
    if (result?.applePay && !enableHideApplePay) {
      setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.ApplePay });
      setMobilePayButtons((state) => ({ ...state, applePay: true }));
    }

    if (result?.googlePay && !enableHideGooglePay) {
      setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.GooglePay });
      setMobilePayButtons((state) => ({ ...state, googlePay: true }));
    }
  };

  const makePayment = async (mobilePay = false, e: any = {}) => {
    const paymentMethod = mobilePay ? mobilePayTiggeredType.current : selectedPaymentMethod;

    startTrace("pay", paymentMethod, async (span: Span) => {
      const event = {
        paymentElement: paymentMethod,
        refId: referenceIdRef.current as string,
        traceId: span?.traceId,
        method: gatewayName
      };

      const tipAmount = qlub?.tip || 0;

      try {
        infoLog("payment intent api Initialize");

        saveLastPayment({ cardBrand: e?.paymentMethod.card?.brand, paymentMethod });

        const intentRes = await getPaymentIntent(e);
        if (intentRes?.data) {
          infoLog("payment intent api Success");

          infoLog("payment api call Initialize");

          const paymentRes = await api.pay({
            id: getSession(),
            reference: referenceIdRef.current,
            diningSessionID: qlub?.diningSessionId || "",
            tipAmount: tipAmount.toString(),
            gatewayID: gatewayId,
            intentID: intentRes.data?.intentID,
            annotations: {
              paymentMethod,
              funnel: consumer
            }
          });

          infoLog("payment api call Success");

          let confirmRes = null;

          if (mobilePay) {
            confirmRes = await stripe?.confirmCardPayment(
              intentRes.data?.clientSecret,
              {
                payment_method: e.paymentMethod.id
              },
              { handleActions: false }
            );

            await api.verify({
              id: getSession(),
              reference: referenceIdRef.current,
              diningSessionID: qlub?.diningSessionId || "",
              gatewayID: gatewayId,
              intentID: intentRes.data?.intentID,
              success: confirmRes?.paymentIntent?.status === "succeeded",
              billAmount:
                totalByClient?.toString() ||
                sumAmounts(qlub?.currencyPrecision || 0, amount || 0, qlub?.tip || 0).toString(),
              tipAmount: tipAmount.toFixed(qlub?.currencyPrecision ?? 0)
            });

            e.complete(confirmRes?.paymentIntent?.status === "succeeded" ? "success" : "fail");
          } else {
            const returnUrl = getCallbackUrl({
              ref: referenceIdRef.current as string,
              method: qlub?.name || "",
              paymentElement: PaymentElementEnum.CardPay,
              dsi: qlub?.diningSessionId || "",
              amount: amount || "",
              currencySymbol: props.country,
              lang: props.locale || ""
            });

            // WAITING_MSG_SHOW_PAY_METHODS?.includes(selectedPaymentMethod ?? "") &&
            //   displayMessage(t("Payment is currently processing, please do not close this page."), "warning", {
            //     anchorOrigin: {
            //       vertical: "top",
            //       horizontal: "center"
            //     }
            //   });

            confirmRes = await stripe?.confirmPayment({
              clientSecret: intentRes.data?.clientSecret,
              confirmParams: {
                return_url: returnUrl.pending,
                payment_method: e?.paymentMethod?.id
              }
            });
          }
          if (confirmRes?.error) {
            throw confirmRes?.error;
          } else {
            infoLog("payment verify api call Success");

            await stripe?.retrievePaymentIntent(intentRes.data?.clientSecret);
          }

          infoLog("retreive intent api call Success");

          if (paymentRes && confirmRes) {
            const paymentPendingResponse = await onPaymentPending?.(event);
            if (typeof paymentPendingResponse !== "undefined") {
              if (paymentPendingResponse) {
                infoLog("onSuccess CB call Success");

                onPaymentSuccess?.(event);
              } else {
                onPaymentFailure?.(event);
              }
            } else {
              infoLog("onSuccess CB call Success");

              onPaymentSuccess?.(event);
            }
          }
        }
      } catch (error: any) {
        errorLog("Payment flow Fail");

        if (mobilePay) {
          paymentRequestRef.current?.abort?.();
          e.complete("fail");
        }
        const { message, variant } = extractError(error?.response?.data || error || {}, error?.message);

        displayMessage(message, variant);
        unlockUI();
        setProcessing(false);
      } finally {
        setProcessing(false);
      }
    });
  };

  const handleSubmit = async (e?: React.MouseEvent | any, mobilePay?: boolean) => {
    startTrace("submission", selectedPaymentMethod ?? PaymentElementEnum.CardPay, async (span: Span) => {
      e?.preventDefault?.();
      setProcessing(true);

      referenceIdRef.current = getRandomString();

      const event = {
        paymentElement: selectedPaymentMethod,
        refId: referenceIdRef.current,
        traceId: traceStart?.traceId,
        gatewayId,
        tip: qlub?.tip ?? 0,
        method: gatewayName
      };

      try {
        lockUI(20000);
        const response = await onBeforePayment?.(event);

        if (!response) {
          infoLog("onBefore api Fail");
          setProcessing(false);
          unlockUI();
          return;
        }

        infoLog("onBefore api Success");

        infoLog("locking mechanism Initialize");

        const lockResponse = await lock(event);

        if (!lockResponse) {
          infoLog("locking mechanism Fail");
          unlockUI();
          setProcessing(false);
          return;
        }

        infoLog("locking mechanism Success");

        let createMethodResponse: any = {};

        if (!mobilePay) {
          const submitResponse = await elements?.submit();
          if (submitResponse?.error) {
            setProcessing(false);
            unlockUI();
            return;
          }

          createMethodResponse = await stripe?.createPaymentMethod({
            elements: elements as StripeElements,
            params: {
              billing_details: {
                email: isEmailDisabled(selectedPaymentMethod) ? "qlub-payment@qlub.io" : undefined,
                address: {
                  country: config?.countryCode || "US"
                }
              }
            }
          });

          if (createMethodResponse?.error) {
            setProcessing(false);
            unlockUI();
            return;
          }

          console.log("createMethodResponse", createMethodResponse);
        }
        await makePayment(mobilePay, mobilePay ? e : { paymentMethod: createMethodResponse?.paymentMethod });
      } catch (error) {
        setProcessing(false);
        mobilePay && e.complete("fail");
        unlockUI();
        unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });

        if (error !== "FORCE_FAILED")
          onPaymentFailure?.({
            paymentElement: PaymentElementEnum.CardPay,
            refId: referenceIdRef.current as string,
            traceId: traceStart?.traceId
          });
        !config.extraConfig?.disableToast && displayError("generic");
      }
    });
  };

  useEffect(() => {
    if (!stripe || !elements) {
      return;
    }

    const disableWallets: PaymentRequestWallet[] = ["browserCard"];
    const totalAmount = sumAmounts(qlub?.currencyPrecision, amount, qlub?.tip || 0);

    paymentRequestRef.current = stripe.paymentRequest({
      country: config?.countryCode?.toUpperCase() || "US",
      currency: props.pg?.vendor.country.currencyCode.toLocaleLowerCase(),
      total: {
        label: "Total",
        amount: isFullTotalSentByClient
          ? trimCurrency(totalByClient, qlub?.currencyPrecision ?? 0)
          : trimCurrency(totalAmount, qlub?.currencyPrecision ?? 0)
      },
      requestPayerName: false,
      disableWallets,
      ...getApplePayShippingBillingConfig(config, PaymentTypeEnum.Stripe)
    });

    paymentRequestRef.current.canMakePayment().then((result: any) => {
      if (result && paymentRequestResult === null) {
        setPaymentRequestResult(result);
        handleStoreEligiblePaymentMethods(result);
      }
    });

    paymentRequestRef.current.on("paymentmethod", async (ev: any) => {
      try {
        await handleSubmit(ev, true);
      } catch (e) {
        ev?.complete("fail");
      }
    });

    paymentRequestRef.current.on("cancel", () => {
      disableApplePayBilling();
      if (!isEmpty(getApplePayShippingBillingConfig(config, PaymentTypeEnum.Stripe))) {
        setPaymentRequestResult(null);
      }
    });

    paymentRequestRef.current.on("shippingaddresschange", async (ev: any) => {
      if (ev.shippingAddress.country !== "US") {
        ev.updateWith({ status: "invalid_shipping_address" });
      }
    });
  }, [stripe, elements, total]);

  const getStyles = () => {
    if (hasPgGroup) {
      if (hasChoosen)
        return {
          display: "block",
          paddingTop: "10px"
        };

      return {
        display: "none"
      };
    }
    return {
      display: "block"
    };
  };

  const renderPGElementBox = () => {
    if (!hasPgGroup || enableHideCardElement) return null;

    return (
      <PGPaymentBox
        name={t("Card and others")}
        selected={hasChoosen}
        toggleVisibility={() =>
          toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.CardPay, name: "stripe" })
        }
      />
    );
  };

  const paymentCallbackFn = (event: React.MouseEvent) => handleSubmit?.(event as any);

  const localOnSubmit = (e: React.MouseEvent) => {
    e?.preventDefault();

    if (props.pg.config.events?.onPrePayment)
      props.pg.config.events?.onPrePayment(paymentCallbackFn, { name: "stripe" });
    else paymentCallbackFn(e);
  };

  const buttonElement = (
    <Button id="payment-action-btn-2" variant={variant} type="submit" loading={processing} onClick={localOnSubmit}>
      {isPayButtonTextChangeEnabled ? t("Pay bill") : t("Pay")}
    </Button>
  );

  useEffect(() => {
    setPaymentMethodReference({
      pgId: props.pg.id,
      paymentMethod: PaymentElementEnum.ApplePay,
      fn: run
    });

    setPaymentMethodReference({
      pgId: props.pg.id,
      paymentMethod: PaymentElementEnum.GooglePay,
      fn: run
    });

    setPaymentMethodReference({
      pgId: props.pg.id,
      paymentMethod: PaymentElementEnum.CardPay,
      fn: handleSubmit
    });
  }, [total, elements]);

  useEffect(() => {
    if (!enableHideCardElement) {
      setAddPGMethod({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.CardPay });
    }
  }, [enableHideCardElement]);

  useEffect(() => {
    return () => {
      removePGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.GooglePay });
      removePGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.ApplePay });
      removePGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay });
    };
  }, []);

  return (
    <>
      {renderMobilePayBtns()}
      {renderPGElementBox()}
      <PaymentLoadingDialog open={processing && isLoadingDialogRequired(selectedPaymentMethod)} />
      <div className={styles.stripeCardContainer}>
        {!enableHideCardElement && (
          <div style={getStyles()}>
            <PaymentElement
              id="payment-element-stripe"
              options={{
                wallets: {
                  applePay: "never",
                  googlePay: "never"
                },
                fields: {
                  billingDetails: {
                    email: isEmailDisabled(selectedPaymentMethod) ? "never" : "auto",
                    address: {
                      country: "never"
                    }
                  }
                },
                layout: {
                  type: "accordion",
                  defaultCollapsed: false,
                  radios: true,
                  spacedAccordionItems: false
                },

                paymentMethodOrder:
                  config.stripeElementOrder || props.pg.config.extraConfig?.pgKoreanElementsOrder || []
              }}
              onChange={(e) => setSelectedPaymentMethod(e.value.type as StripePaymentMethod)}
            />
            {!hasPgGroup && (
              <div style={{ paddingTop: "20px" }}>
                <PaymentTerms className={styles.payTerms} />
                <Divider sx={{ margin: "16px 0 0 0" }} />
                {buttonElement}
              </div>
            )}
          </div>
        )}
        {hasChoosen && (
          <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{buttonElement}</ReactPortal>
        )}
      </div>
    </>
  );
};

export default StripeCardPayment;
