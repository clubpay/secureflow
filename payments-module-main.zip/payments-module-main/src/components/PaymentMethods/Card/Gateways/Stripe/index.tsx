import { default as StripeCloak } from "@/components/GatewayCloaks/Stripe";
import { useSnackbar } from "@/hooks";
import { PaymentOptions } from "@/types";
import { StripeConfig } from "@/types/payments/config/stripe";
import { getPaymentMethods } from "@/utils/payments/stripe";
import { sumAmounts } from "@clubpay/customer-common-module/src/utility/k_math";
import { default as StripeCardPayment } from "./Stripe";
import { getLocale } from "./Stripe.util";

export default function (props: PaymentOptions) {
  useSnackbar(props.plugins?.snackbar);

  const total =
    Math.round(sumAmounts(props.qlub?.currencyPrecision, props?.amount || 0, props.qlub?.tip || 0) * 100) || 0;

  if (!props.pg.config.publicKey || !Boolean(total)) return <></>;

  return (
    <StripeCloak
      pg={props.pg}
      options={{
        locale: getLocale(props.locale),
        amount: total,
        paymentMethodTypes: getPaymentMethods(props.pg.config as StripeConfig)
      }}
    >
      <StripeCardPayment {...props} />
    </StripeCloak>
  );
}
