import { default as MafCloak } from "@/components/GatewayCloaks/Maf";
import { useSnackbar } from "@/hooks";
import { PaymentOptions } from "@/types";
import { default as MafCardPayment } from "./Maf";

export default function (props: PaymentOptions) {
  useSnackbar(props.plugins?.snackbar);
  return (
    <MafCloak onReady={props.pg.config.events?.onReady}>
      <MafCardPayment {...props} />
    </MafCloak>
  );
}
