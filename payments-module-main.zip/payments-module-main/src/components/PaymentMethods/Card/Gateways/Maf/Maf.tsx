import { useCallback, useEffect, useRef, useState } from "react";
import {
  MafpayCardCvc,
  MafpayCardExpiry,
  MafpayCardNumber,
  MafpayCardSubmit,
  MafpayThreedsComponent
} from "@mafpay/weblib-react";
import PaymentAPIManager from "@/api/gateways";
import { default as Input } from "@/components/Core/Input";
import { useCard, useLocale, useLockUnlock, useToast, useTrace } from "@/hooks";
import { usePayment } from "@/providers";
import { PaymentOptions } from "@/types";
import { MAFConfig } from "@/types/payments/config/maf";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { IStartSpanResponse } from "@clubpay/customer-common-module/src/hook/useSentryTrace";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { default as CardLayout } from "../../Layout/layout";
import styles from "./Maf.module.scss";
import { getErr } from "./Maf.util";

const MafCardPayment = ({ variant = "primary", amount = 2, currency = "AED", qlub, ...props }: PaymentOptions) => {
  const { cardNumber, expiryDate, securityCode, setCardNumber, setExpiryDate, setSecurityCode, reset } = useCard();
  const referenceRef = useRef<null | string>(null);

  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const gatewayId = props.pg.id;
  const gatewayName = props.pg.name;

  const config = props.pg.config as MAFConfig;

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).maf;

  const [threeDsAuthId, setThreeDsAuthId] = useState("");

  const { onBeforePayment, onPaymentSuccess, onPaymentFailure, onTraceClose } = config.events ?? {};

  const { getCallbackUrl } = useConfirmCallback();

  const traceStart = useTrace(props.pg);

  const traceRef = useRef<IStartSpanResponse | undefined>();

  const { displayError } = useToast();

  useLocale(props.locale);

  const { setProcessing } = usePayment();

  const onCardNumberStatus = useCallback(
    (e: CustomEvent) => setCardNumber({ ...cardNumber, error: getErr(e, "card-number") }),
    []
  );

  const onCardExpiryStatus = useCallback(
    (e: CustomEvent) => setExpiryDate({ ...expiryDate, error: getErr(e, "expiry-date") }),
    []
  );

  const onCardCvcStatus = useCallback(
    (e: CustomEvent) => setSecurityCode({ ...securityCode, error: getErr(e, "cvv") }),
    []
  );

  const makePayment = async (token = "", cardBin = "", cardBrand = "") => {
    let response = null;
    const event = {
      paymentElement: PaymentElementEnum.CardPay,
      refId: referenceRef.current as string,
      traceId: traceStart?.traceId,
      meta: {
        isExchangeInterrupted: !!qlub?.exchange,
        isExchangeUsed: qlub?.exchange?.isApplied
      }
    };

    const returnUrl = getCallbackUrl({
      ref: referenceRef.current as string,
      method: gatewayName,
      paymentElement: PaymentElementEnum.CardPay,
      dsi: qlub?.diningSessionId || "",
      amount: amount || "",
      currencySymbol: props.country,
      traceId: traceStart?.traceId,
      lang: props.locale || ""
    });

    try {
      response = await api.pay({
        cardToken: token,
        cardBin,
        cardBrand,
        customerEmail: "",
        diningSessionID: qlub?.diningSessionId,
        failureUrl: returnUrl.fail,
        gatewayID: gatewayId,
        id: getSession(),
        reference: referenceRef.current as string,
        successUrl: returnUrl.success,
        tipAmount: qlub?.tip ? qlub.tip.toFixed(2) : "0.00"
      });

      if (response.data.responseCode === "000" || response.data.responseCode === "700") {
        if (response.data.threeDsAuthId) {
          setThreeDsAuthId(response.data.threeDsAuthId);
        } else {
          onPaymentSuccess?.(event);
        }
      } else {
        displayError("generic");
      }
    } catch (err: any) {
      unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
      onPaymentFailure?.(event);
    }
  };

  const handleSubmit = async (e: any, data?: any) => {
    referenceRef.current = `${getRandomString()}c`;
    traceRef.current = traceStart?.startSpan({
      dataName: gatewayName ?? "anonymous",
      span: {
        element: PaymentElementEnum.CardPay,
        refId: referenceRef.current
      }
    });

    const event = {
      paymentElement: PaymentElementEnum.CardPay,
      refId: referenceRef.current as string,
      traceId: traceStart?.traceId
    };

    try {
      const onBeforeRes = await onBeforePayment?.({
        gatewayId,
        paymentElement: PaymentElementEnum.CardPay,
        tip: qlub?.tip ?? 0
      });

      if (!onBeforeRes) {
        setProcessing(false);
        return;
      }

      const lockResponse = await lock(event);

      if (!lockResponse) {
        setProcessing(false);
        return;
      }

      await makePayment(e.detail.cardToken, e.detail.cardBin, e.detail.cardBrand);
    } catch (e) {
      unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
      displayError("generic");
      onTraceClose?.({
        error: e,
        location: "paymentMafPayByToken",
        traceRef,
        traceStart
      });
    } finally {
      setProcessing(false);
    }
  };

  useEffect(() => {
    reset();
  }, []);

  const card = useCallback(
    (props: any) => (
      <Input
        element={MafpayCardNumber}
        className={styles[`${variant}-input-maf-card`]}
        overrideStyle
        onCardNumberStatus={onCardNumberStatus}
        error={cardNumber.error}
        {...props}
      />
    ),
    [cardNumber.error]
  );

  const expiry = useCallback(
    (props: any) => (
      <Input
        element={MafpayCardExpiry}
        className={styles[`${variant}-input-maf`]}
        overrideStyle
        onCardExpiryStatus={onCardExpiryStatus}
        error={expiryDate.error}
        {...props}
      />
    ),
    [expiryDate.error]
  );

  const cvv = useCallback(
    (props: any) => (
      <Input
        element={MafpayCardCvc}
        className={styles[`${variant}-input-maf`]}
        overrideStyle
        onCardCvcStatus={onCardCvcStatus}
        error={securityCode.error}
        {...props}
      />
    ),
    [securityCode.error]
  );

  const boilerPLateInputs = (
    <>
      <input type="hidden" name="merchantId" value="STSTZBTK993566" />
      <input type="hidden" name="apiKey" value="tp2mu5x7lsRJ2K20F02b9dkegi7p8b" />
      <input type="hidden" name="command" value="tokenize" />
      <input type="hidden" name="tokenizev2" value="true" />
    </>
  );

  const payThreedsComponent = threeDsAuthId && (
    <MafpayThreedsComponent
      onProcessComplete={() =>
        onPaymentSuccess?.({
          paymentElement: PaymentElementEnum.CardPay,
          refId: referenceRef.current as string
        })
      }
      threedsauthid={threeDsAuthId}
    />
  );

  const mafPayBtnRef = useRef<any>(null);

  return (
    <CardLayout
      enableCardSaving={false}
      elements={{ card, expiry, cvv }}
      onSubmit={handleSubmit}
      variant={variant}
      amount={amount}
      currency={currency}
      formAttributes={{
        method: "POST",
        action: "https://payment.sandbox.mafpayments.com/tokenize",
        noValidate: true
      }}
      paymentCallbackFn={() => {
        setProcessing(true);
        mafPayBtnRef.current?.children?.[0].click();
      }}
      slots={[
        boilerPLateInputs,
        <MafpayCardSubmit style={{ display: "none" }} ref={mafPayBtnRef} onTokenizationComplete={handleSubmit} />,
        payThreedsComponent
      ]}
      hide={config?.extraConfig?.hideCardPay}
      {...props}
    />
  );
};

export default MafCardPayment;
