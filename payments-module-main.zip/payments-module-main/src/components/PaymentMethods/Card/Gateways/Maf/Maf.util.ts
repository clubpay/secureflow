import { cardValidations } from "@/constants/cards";

export const getErr = (e: CustomEvent, element: string) => {
  if (e.detail?.status === "VALID" || e.detail?.error?.errorCode?.includes("EMPTY")) return null;
  switch (e.detail?.error?.errorCode) {
    case "CARD_NUMBER_INCOMPLETE":
      return cardValidations.incomplete["card-number"];
    case "CARD_NUMBER_INVALID":
      return cardValidations.invalid["card-number"];
    case "EXPIRY_DATE_EXPIRED":
    case "INVALID_EXPIRY_DATE":
      return cardValidations.invalid["expiry-date"];
    case "INVALID_CVC":
      return cardValidations.invalid["cvv"];
    default:
      return cardValidations.invalid[element];
  }
};
