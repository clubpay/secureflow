import StripeConnectCloak from "@/components/GatewayCloaks/StripeConnect";
import { useSnackbar } from "@/hooks";
import { CardStorageProvider, PaymentProvider } from "@/providers";
import { PaymentOptions } from "@/types";
import { StripeConnectConfig } from "@/types/payments/config/stripeConnect";
import { getPaymentMethods } from "@/utils/payments/stripe";
import { sumAmounts } from "@clubpay/customer-common-module/src/utility/k_math";
import { getLocale } from "../Stripe/Stripe.util";
import { default as StripeConnectPayment } from "./StripeConnect";

export default function (props: PaymentOptions) {
  useSnackbar(props.plugins?.snackbar);
  const qlub = props.qlub;

  const total = Math.round(sumAmounts(qlub?.currencyPrecision, props?.amount || 0, qlub?.tip || 0) * 100) || 0;

  if (!props.pg.config.publicKey || !Boolean(total)) return <></>;

  return (
    <PaymentProvider>
      <CardStorageProvider>
        <StripeConnectCloak
          pg={props.pg}
          options={{
            appearance: {
              theme: "stripe",
              variables: {
                fontSizeBase: "18px"
              }
            },
            locale: getLocale(props.locale),
            amount: total,
            paymentMethodTypes: getPaymentMethods(props.pg.config as StripeConnectConfig)
          }}
        >
          <StripeConnectPayment {...props} />
        </StripeConnectCloak>
      </CardStorageProvider>
    </PaymentProvider>
  );
}
