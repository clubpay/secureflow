import React, { useEffect, useRef, useState } from "react";
import { PaymentElement, useElements, useStripe } from "@stripe/react-stripe-js";
import PaymentAPIManager from "@/api/gateways";
import { Button } from "@/components/Core";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import PaymentLoadingDialog from "@/components/Global/PaymentLoadingDialog";
import PaymentTerms from "@/components/Global/PaymentTerms";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock, useToast, useTrace } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { usePgEvent } from "@/hooks/pg-events";
import useSentry from "@/hooks/sentry";
import { AliPay } from "@/icons";
import Apple from "@/icons/Apple";
import ApplePayIcon from "@/icons/ApplePay";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { useStripeStore } from "@/stores/stripeStore";
import { ConsumerTypes, PaymentOptions, StripePaymentMethod } from "@/types";
import { StripeConnectConfig } from "@/types/payments/config/stripeConnect";
import { getPaymentMethodOrder } from "@/utils";
import { isMultiPG } from "@/utils";
import { disableApplePayShippingBilling, getApplePayShippingBillingConfig } from "@/utils/payments/shippingBilling";
import { isLoadingDialogRequired } from "@/utils/payments/stripe";
import { GooglePay as GPayIC } from "@clubpay/customer-common-module/src/component/SVG";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import {
  PaymentElementEnum,
  PaymentTypeEnum
} from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { trimCurrency } from "@clubpay/customer-common-module/src/utility/k_currency";
import { sumAmounts } from "@clubpay/customer-common-module/src/utility/k_math";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import CreditCardIcon from "@mui/icons-material/CreditCard";
import { Box } from "@mui/material";
import { Divider } from "@mui/material";
import { Span } from "@sentry/nextjs/types/client";
import { PaymentRequestWallet } from "@stripe/stripe-js/types/stripe-js/payment-request";
import PaymentContainer from "../../../../Global/PaymentContainer";
import AlipayAlert from "../../components/common/AlipayAlert";
import PGGroupViewWrapper from "../../components/common/PGGroupViewWrapper";
import PaymentDrawer from "../../components/common/PaymentDrawer";
import { WAITING_MSG_SHOW_PAY_METHODS, extractError } from "../Stripe/Stripe.util";
import styles from "./StripeConnect.module.scss";

interface StripeConnectPaymentTypes extends PaymentOptions {}

const StripeConnectCardPayment = (props: StripeConnectPaymentTypes) => {
  const { variant = "primary", amount = 2, qlub } = props;

  const gatewayId = props.pg.id;
  const gatewayName = props.pg.name;
  const { totalAmount: totalByClient } = props;
  const config = props.pg.config as StripeConnectConfig;
  const referenceIdRef = useRef("");
  const enableHideGooglePay = config.extraConfig.hideGooglePay;
  const enableHideApplePay = config.extraConfig.hideApplePay;

  const enableHideCardElement = config.extraConfig.hideCardElement;

  const isFullTotalSentByClient = typeof totalByClient !== "undefined";

  const paynowUI = config.paynowUI ?? "v0";

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).stripeConnect;

  const [disableBilling, setDisableBilling] = useState(false);

  const [mobilePayButtons, setMobilePayButtons] = useState<{ applePay?: boolean; googlePay?: boolean }>({});

  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<StripePaymentMethod>();

  const traceStart = useTrace(props.pg);

  const { startTrace, infoLog, errorLog } = useSentry(props);

  const stripe = useStripe();
  const elements = useElements();
  const { processing, setProcessing } = usePayment();
  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });

  const {
    state: { isPayButtonTextChangeEnabled, consumer },
    lock: lockUI,
    unlock: unlockUI
  } = useCommonStore((state) => state);

  const {
    state: { isMultiUIModeActive },
    setMultiUIMode,
    setApplePayEvaluate
  } = useStripeStore((store) => store);

  const { sendEvent } = usePgEvent({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });

  const [mobilePayProcessing, setMobilePayProcessing] = useState<boolean>(false);

  const [paymentRequest, setPaymentRequest] = useState<any>(false);

  const [showPaymentDrawer, setShowPaymentDrawer] = useState(false);

  const paymentRequestRef = useRef<any>(null);

  const mobilePayTiggeredType = useRef<any>(null);

  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const { displayMessage } = useToast();

  const {
    toggleVisibility,
    state,
    setAddPGMethod,
    removePGMethod,
    setPGDependedPaymentMethodsData,
    setPaymentMethodReference
  } = usePGGroupStore((state) => state);

  const hasPgGroup = state.isPGGroupEnabled;

  const hasChoosen = isPaymethodChoosed({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.CardPay });

  const getIcons = () => {
    const item = [];
    if (config.extraConfig.alipay) item.push(<AliPay />);
    item.push(<CreditCardIcon.default />);

    return item;
  };

  const renderPGElementBox = () => {
    if (!hasPgGroup || enableHideCardElement) return null;

    return (
      <PGPaymentBox
        name={t("Card and others")}
        selected={hasChoosen}
        toggleVisibility={() =>
          toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.CardPay, name: "stripeConnect" })
        }
        icons={getIcons()}
      />
    );
  };

  const { onBeforePayment, onPaymentSuccess, onPaymentPending } = config.events ?? {};

  const run = () => paymentRequestRef.current.show();

  const handleMobilePay = (typeName: PaymentElementEnum) => {
    mobilePayTiggeredType.current = typeName;
    if (config.events?.onPrePayment) config.events?.onPrePayment(run, "");
    else run();
  };

  const appleButtonElement = (
    <Button
      id="apple-pay-btn"
      className={styles.appleButton}
      onClick={() => handleMobilePay(PaymentElementEnum.ApplePay)}
    >
      {t("Pay with")}
      <span>
        <ApplePayIcon />
      </span>
    </Button>
  );

  const googleButtonElement = (
    <Button
      id="gooogle-pay-btn"
      className={styles.gButton}
      variant={variant}
      onClick={() => handleMobilePay(PaymentElementEnum.GooglePay)}
      loading={mobilePayProcessing}
    />
  );

  const handleStoreEligiblePaymentMethods = (result: any) => {
    if (result?.applePay && !enableHideApplePay) {
      setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.ApplePay });
      setMobilePayButtons((state) => ({ ...state, applePay: true }));
    }
    if (result?.googlePay && !enableHideGooglePay) {
      setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.GooglePay });
      setMobilePayButtons((state) => ({ ...state, googlePay: true }));
    }
  };

  const getPaymentIntent = async (e?: any) => {
    const tipAmount = qlub?.tip || 0;

    try {
      const response = await api.createPaymentIntent({
        id: getSession(),
        reference: referenceIdRef.current,
        diningSessionID: qlub?.diningSessionId || "",
        gatewayID: gatewayId,
        automaticPaymentMethodParams: true,
        tipAmount: tipAmount.toString(),
        paymentMethod: selectedPaymentMethod,
        ...(e?.paymentMethod?.card?.country ? { issuerCountry: e.paymentMethod.card.country } : {})
      });
      if (response) {
        return response;
      }
    } catch (_) {}
    return null;
  };

  const { getCallbackUrl } = useConfirmCallback();

  const makePayment = async (mobilePay = false, payload: any = {}) => {
    const paymentElement = mobilePay
      ? mobilePayTiggeredType.current
      : payload?.paymentMethod?.type ?? PaymentElementEnum.CardPay;
    startTrace("pay", paymentElement, async (_span: Span) => {
      const event = {
        paymentElement,
        refId: referenceIdRef.current as string,
        traceId: traceStart?.traceId,
        method: gatewayName,
        meta: {
          isExchangeInterrupted: !!qlub?.exchange,
          isExchangeUsed: qlub?.exchange?.isApplied
        }
      };

      const tipAmount = qlub?.tip || 0;

      sendEvent("payment_initialized", {
        paymentMethod: paymentElement
      });

      try {
        infoLog("payment intent api Initialize");

        saveLastPayment({ cardBrand: payload?.paymentMethod.card?.brand, paymentMethod: paymentElement });

        const intentRes = await getPaymentIntent(payload);
        if (intentRes?.data) {
          infoLog("payment intent api Success");
          const paymentPayload = mobilePay
            ? {
                id: getSession(),
                reference: referenceIdRef.current,
                diningSessionID: qlub?.diningSessionId || "",
                tipAmount: tipAmount.toString(),
                gatewayID: gatewayId,
                intentID: intentRes.data?.intentID,
                shippingContact: {
                  payerName: payload.payerName,
                  payerEmail: payload.payerEmail,
                  payerPhone: payload.payerPhone
                },
                cardBrand: payload?.paymentMethod.card?.brand,
                issuerCountry: payload?.paymentMethod.card?.country,
                paymentMethod: payload?.paymentMethod.type,
                funding: payload?.paymentMethod.card?.funding,
                annotations: {
                  paymentMethod: mobilePayTiggeredType.current,
                  funnel: consumer
                }
              }
            : {
                id: getSession(),
                reference: referenceIdRef.current,
                diningSessionID: qlub?.diningSessionId || "",
                tipAmount: tipAmount.toString(),
                gatewayID: gatewayId,
                intentID: intentRes.data?.intentID,
                cardBrand: payload?.paymentMethod.card?.brand,
                issuerCountry: payload?.paymentMethod.card?.country,
                paymentMethod: payload?.paymentMethod.type,
                funding: payload?.paymentMethod.card?.funding,
                annotations: {
                  paymentMethod: paymentElement,
                  funnel: consumer
                }
              };

          infoLog("payment api call Initialize");

          const paymentRes = await api.pay(paymentPayload);

          let confirmRes = null;

          if (mobilePay) {
            confirmRes = await stripe?.confirmCardPayment(
              intentRes.data?.clientSecret,
              {
                payment_method: payload.paymentMethod.id
              },
              { handleActions: false }
            );

            infoLog("payment api call Success");

            infoLog("payment verify api call Initialize");

            await api.verify({
              id: getSession(),
              reference: referenceIdRef.current,
              diningSessionID: qlub?.diningSessionId || "",
              gatewayID: gatewayId,
              intentID: intentRes.data?.intentID,
              success: confirmRes?.paymentIntent?.status === "succeeded",
              billAmount:
                totalByClient?.toString() ||
                sumAmounts(qlub?.currencyPrecision || 0, amount || 0, qlub?.tip || 0).toString(),
              tipAmount: (qlub?.tip ?? 0).toString(),
              paymentMethod: payload?.paymentMethod.type
            });

            infoLog("payment verify api call Success");

            infoLog("pending CB call Success");

            await onPaymentPending({
              paymentElement: payload?.paymentMethod.type,
              refId: referenceIdRef.current,
              traceId: traceStart?.traceId
            });

            if (consumer === ConsumerTypes.PAYMENT_LINK) {
              if (paymentRes && confirmRes) {
                onPaymentSuccess?.(event);
              }
            }

            payload?.complete(confirmRes?.paymentIntent?.status === "succeeded" ? "success" : "fail");
          } else {
            infoLog("confirm payment api call Initialize");

            // WAITING_MSG_SHOW_PAY_METHODS?.includes(selectedPaymentMethod ?? "") &&
            //   displayMessage(t("Payment is currently processing, please do not close this page."), "warning", {
            //     anchorOrigin: {
            //       vertical: "top",
            //       horizontal: "center"
            //     }
            //   });

            confirmRes = await stripe?.confirmPayment({
              clientSecret: intentRes.data?.clientSecret,
              confirmParams: {
                return_url: payload?.returnUrl.pending,
                payment_method: payload?.paymentMethod.id
              }
            });

            infoLog("confirm payment api call Initialize");
          }

          if (confirmRes?.error) {
            throw confirmRes?.error;
          } else {
            infoLog("retreive intent api call Initialize");

            await stripe?.retrievePaymentIntent(intentRes.data?.clientSecret);

            infoLog("retreive intent api call Success");
          }

          if (paymentRes && confirmRes && !mobilePay) {
            infoLog("onSuccess CB call Success");

            onPaymentSuccess?.(event);
          }
        }
      } catch (error: any) {
        errorLog("Payment flow Fail");
        console.log("error", error);
        const { message, variant } = extractError(error?.response?.data || error || {}, error?.message);
        displayMessage(message, variant);
        setProcessing(false);
        setMobilePayProcessing(false);
        unlockUI();
        throw error;
      } finally {
        setProcessing(false);
      }
    });
  };

  const handleSubmit = async (e?: React.MouseEvent) => {
    startTrace("submission", PaymentElementEnum.CardPay, async (span: Span) => {
      e?.preventDefault();

      referenceIdRef.current = getRandomString();
      setProcessing(true);
      if (!stripe || !elements) {
        return;
      }

      const event = {
        gatewayId,
        paymentElement: selectedPaymentMethod,
        refId: referenceIdRef.current,
        tip: qlub?.tip ?? 0,
        traceId: span?.traceId,
        method: gatewayName
      };

      try {
        lockUI(20000);
        const response = await onBeforePayment?.(event);

        if (!response) {
          infoLog("onBefore api Fail");
          unlockUI();
          return;
        }

        infoLog("onBefore api Success");

        infoLog("locking mechanism Initialize");

        const lockResponse = await lock(event, 20000);

        if (!lockResponse) {
          unlockUI();
          infoLog("locking mechanism Fail");
          return;
        }

        infoLog("locking mechanism Success");

        const { error: submitError } = await elements?.submit();
        if (submitError) throw submitError;

        const { error: paymentMethodError, paymentMethod } = await stripe.createPaymentMethod({
          elements,
          params: {
            billing_details: {
              address: {
                country: config?.countryCode || "US"
              }
            }
          }
        });

        if (paymentMethodError) throw paymentMethodError;

        const paymentElement = (paymentMethod.type ?? PaymentElementEnum.CardPay) as PaymentElementEnum;

        const returnUrl = getCallbackUrl({
          ref: referenceIdRef.current,
          method: gatewayName,
          paymentElement: paymentElement,
          dsi: qlub?.diningSessionId || "",
          amount: amount || "",
          currencySymbol: props.country,
          traceId: traceStart?.traceId,
          lang: props.locale || ""
        });

        infoLog("pay handler method call Initialize");
        await makePayment(false, { paymentMethod, returnUrl });
      } catch (e: any) {
        setProcessing(false);
        errorLog("Payment flow Fail");
        unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
      }
    });
  };

  const paymentCallbackFn = (event: React.MouseEvent) => handleSubmit?.(event as any);

  const localOnSubmit = (e: React.MouseEvent) => {
    e?.preventDefault();

    if (props.pg.config.events?.onPrePayment)
      props.pg.config.events?.onPrePayment(paymentCallbackFn, { name: "stripeConnect" });
    else paymentCallbackFn(e);
  };

  const buttonElement = (
    <Button id="payment-action-btn-2" variant={variant} type="submit" loading={processing} onClick={localOnSubmit}>
      {isPayButtonTextChangeEnabled ? t("Pay bill") : t("Pay")}
    </Button>
  );

  const domNode = isMultiUIModeActive
    ? document.getElementById("pg-stripe-container")
    : document.getElementById("pg-container");

  const PaymentWrapper = isMultiUIModeActive ? PaymentDrawer : "div";

  const renderMobilePayBtns = () => {
    const buttonList: any = [];

    if (mobilePayButtons.applePay) {
      buttonList.push(
        <ReactPortal domNode={domNode}>
          <div style={{ order: getPaymentMethodOrder(PaymentElementEnum.ApplePay, config, gatewayName) }}>
            {hasPgGroup ? (
              <PGGroupViewWrapper
                name={t("Apple Pay")}
                gatewayID={gatewayId}
                paymentMethod={PaymentElementEnum.ApplePay}
                icon={<Apple />}
                drawerMode={isMultiUIModeActive}
              >
                {appleButtonElement}
              </PGGroupViewWrapper>
            ) : (
              appleButtonElement
            )}
          </div>
        </ReactPortal>
      );
    }
    if (mobilePayButtons.googlePay) {
      buttonList.push(
        <ReactPortal domNode={domNode}>
          <div style={{ order: getPaymentMethodOrder(PaymentElementEnum.GooglePay, config, gatewayName) }}>
            {hasPgGroup ? (
              <PGGroupViewWrapper
                name={t("Google Pay")}
                gatewayID={gatewayId}
                paymentMethod={PaymentElementEnum.GooglePay}
                icon={<GPayIC />}
                drawerMode={isMultiUIModeActive}
              >
                {googleButtonElement}
              </PGGroupViewWrapper>
            ) : (
              googleButtonElement
            )}
          </div>
        </ReactPortal>
      );
    }

    return buttonList;
  };
  const walletAndCardButton = (
    <Box className={styles.parentContainer} onClick={() => setShowPaymentDrawer(true)}>
      <div className={styles.pgMethodBoxName}>{t("Wallets & Cards")}</div>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          columnGap: 0
        }}
      >
        <CreditCardIcon.default />
      </div>
    </Box>
  );

  const areAll3MainPayMethodsDisabled = enableHideApplePay && enableHideGooglePay && enableHideCardElement;

  const renderBottomUI = () => {
    if (isMultiUIModeActive) {
      if (!hasChoosen)
        return (
          <div style={{ paddingTop: "20px" }}>
            <PaymentTerms className={styles.payTerms} />
            <Divider sx={{ margin: "16px 0 0 0" }} />
            {buttonElement}
          </div>
        );
    } else {
      if (!hasPgGroup)
        return (
          <div style={{ paddingTop: "20px" }}>
            <PaymentTerms className={styles.payTerms} />
            <Divider sx={{ margin: "16px 0 0 0" }} />
            {buttonElement}
          </div>
        );
    }

    return <></>;
  };

  useEffect(() => {
    if (!stripe || !elements) {
      return;
    }
    const disableWallets: PaymentRequestWallet[] = ["browserCard"];
    const totalAmount = sumAmounts(qlub?.currencyPrecision, amount, qlub?.tip || 0);
    const shippingBillingConfig = getApplePayShippingBillingConfig(config, PaymentTypeEnum.Stripe);

    paymentRequestRef.current = stripe.paymentRequest({
      country: config?.countryCode?.toUpperCase() || "US",
      currency: props.pg?.vendor.country.currencyCode.toLocaleLowerCase(),
      total: {
        label: "Total",
        amount: isFullTotalSentByClient
          ? trimCurrency(totalByClient, qlub?.currencyPrecision ?? 0)
          : trimCurrency(totalAmount, qlub?.currencyPrecision ?? 0)
      },
      requestPayerName: false,
      disableWallets,
      ...shippingBillingConfig
    });

    paymentRequestRef.current.canMakePayment().then((result: any) => {
      setPaymentRequest(result);
      console.log("canMakePayment");
      setApplePayEvaluate(true);
      if (result) {
        handleStoreEligiblePaymentMethods(result);
      }
    });

    paymentRequestRef.current.on("paymentmethod", async (e: { complete: (arg0: string) => void }) => {
      referenceIdRef.current = getRandomString();
      const event = {
        paymentElement: mobilePayTiggeredType.current,
        refId: referenceIdRef.current,
        traceId: traceStart?.traceId,
        gatewayId,
        tip: qlub?.tip ?? 0,
        method: gatewayName
      };
      setMobilePayProcessing(true);
      try {
        const onBeforeRes = await onBeforePayment?.(event);

        if (!onBeforeRes) {
          return;
        }

        const lockResponse = await lock(event, 15000);

        if (!lockResponse) {
          return;
        }

        await makePayment(true, e);
      } catch (error) {
        paymentRequestRef.current?.abort?.();
        e.complete("fail");
        unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
      } finally {
        setMobilePayProcessing(false);
      }
    });

    paymentRequestRef.current.on("cancel", () => {
      disableApplePayShippingBilling();
      setDisableBilling(true);
    });
  }, [stripe, elements, amount, qlub?.tip, totalByClient, disableBilling]);

  useEffect(() => {
    if (!enableHideCardElement) {
      setAddPGMethod({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.CardPay });
    }
  }, [enableHideCardElement]);

  useEffect(() => {
    const isMultiPGLocal = isMultiPG(state.availablePGMethods);

    const isMultiUIModeActive = paynowUI != "v0" && !isMultiPGLocal;

    setMultiUIMode(isMultiUIModeActive);
  }, [state.availablePGMethods]);

  useEffect(() => {
    setPaymentMethodReference({
      pgId: props.pg.id,
      paymentMethod: PaymentElementEnum.CardPay,
      fn: handleSubmit
    });

    setPaymentMethodReference({
      pgId: props.pg.id,
      paymentMethod: PaymentElementEnum.ApplePay,
      fn: run
    });

    setPaymentMethodReference({
      pgId: props.pg.id,
      paymentMethod: PaymentElementEnum.GooglePay,
      fn: run
    });
  }, [amount, qlub?.tip, totalByClient]);

  useEffect(() => {
    return () => {
      removePGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.GooglePay });
      removePGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.ApplePay });
      removePGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay });
    };
  }, []);

  if (areAll3MainPayMethodsDisabled) return <></>;

  return (
    <div>
      {renderMobilePayBtns()}
      <PaymentLoadingDialog open={processing && isLoadingDialogRequired(selectedPaymentMethod)} />
      {isMultiUIModeActive && walletAndCardButton}
      <PaymentWrapper open={showPaymentDrawer} onClose={() => setShowPaymentDrawer(false)}>
        <div>
          {isMultiUIModeActive && <div style={{ paddingBottom: "18px" }}>{props.slots?.paymentDrawer?.youPay}</div>}
          <div id="pg-stripe-container" className={styles.stripeContainer}>
            {renderPGElementBox()}
            {!enableHideCardElement && (
              <PaymentContainer hideCard={enableHideCardElement} selected={hasChoosen} pgGroup={hasPgGroup}>
                <PaymentElement
                  id="payment-element"
                  options={{
                    wallets: {
                      applePay: "never",
                      googlePay: "never"
                    },
                    fields: {
                      billingDetails: {
                        address: {
                          country: "never"
                        }
                      }
                    },
                    layout: {
                      type: "accordion",
                      defaultCollapsed: false,
                      radios: true,
                      spacedAccordionItems: false
                    },
                    paymentMethodOrder: config.stripeElementOrder || []
                  }}
                  onChange={(e) => setSelectedPaymentMethod(e.value.type as StripePaymentMethod)}
                />
                {selectedPaymentMethod === "alipay" && <AlipayAlert />}
                {renderBottomUI()}
                {hasChoosen && (
                  <ReactPortal
                    domNode={document.querySelector(
                      isMultiUIModeActive ? "#inner-pg-group-paybtn-container" : "#pg-group-paybtn-container"
                    )}
                  >
                    {buttonElement}
                  </ReactPortal>
                )}
              </PaymentContainer>
            )}
          </div>
        </div>
      </PaymentWrapper>
    </div>
  );
};

export default StripeConnectCardPayment;
