import { PaymentOptions } from "@/types";
import AdyenCardPayment from "./Adyen";

export default function (props: PaymentOptions) {
  return <AdyenCardPayment {...props} />;
}
