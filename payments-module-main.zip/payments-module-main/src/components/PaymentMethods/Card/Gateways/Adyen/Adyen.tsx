import { useEffect, useRef, useState } from "react";
import PaymentAPIManager from "@/api/gateways";
import { Button } from "@/components/Core";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import PaymentTerms from "@/components/Global/PaymentTerms";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock, useTrace } from "@/hooks";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { AdyenConfig, IAdyenPaymentRequest } from "@/types/payments/config/adyen";
import AdyenCheckout from "@adyen/adyen-web";
import "@adyen/adyen-web/dist/adyen.css";
import CardElement from "@adyen/adyen-web/dist/types/components/Card/Card";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { IStartSpanResponse } from "@clubpay/customer-common-module/src/hook/useSentryTrace";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { Divider } from "@mui/material";

const AdyenCardPayment = (props: PaymentOptions) => {
  const { variant = "primary", amount, qlub, pg, locale } = props;

  const gatewayId = pg.id;
  const gatewayName = pg.name;
  const config = pg.config as AdyenConfig;
  const hideCardPay = config.extraConfig.hideCardPay;
  const tipAmount = qlub?.tip;
  const billAmount = amount;
  const diningSessionId = qlub?.diningSessionId;

  const { onBeforePayment, onPaymentPending, onTraceClose, onPaymentFailure, onPrePayment } = config.events ?? {};
  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).adyen;

  const [cardElement, setCardElement] = useState<CardElement>();
  const traceRef = useRef<IStartSpanResponse | undefined>();
  const paymentContainer = useRef(null);
  const onBeforePaymentRef = useRef(onBeforePayment);
  const tipAmountRef = useRef(tipAmount);

  const traceStart = useTrace(pg);

  const { getCallbackUrl } = useConfirmCallback();

  const { processing, setProcessing } = usePayment();

  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const {
    state: pgGroupState,
    toggleVisibility,
    setAddPGMethod,
    setPaymentMethodReference
  } = usePGGroupStore((state) => state);

  const {
    state: { consumer }
  } = useCommonStore((state: any) => state);

  const isSelected = isPaymethodChoosed({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay });
  const hasPgGroup = pgGroupState.isPGGroupEnabled;

  const getStyles = () => {
    if (hasPgGroup) {
      if (isSelected)
        return {
          display: "block",
          paddingTop: "10px"
        };

      return {
        display: "none"
      };
    }
    return {
      display: "block"
    };
  };

  const handlePayCallback = () => cardElement?.submit();

  const handlePay = () => onPrePayment?.(handlePayCallback, PaymentElementEnum.CardPay);

  const handleSubmit = async (e: IAdyenPaymentRequest) => {
    const refId = getRandomString();
    const event = {
      paymentElement: PaymentElementEnum.CardPay,
      refId,
      traceId: traceStart?.traceId
    };

    try {
      setProcessing(true);

      traceRef.current = traceStart?.startSpan({
        dataName: gatewayName,
        span: {
          element: PaymentElementEnum.CardPay,
          refId
        }
      });

      const callbackUrl = getCallbackUrl({
        ref: refId as string,
        method: gatewayName,
        paymentElement: PaymentElementEnum.CardPay,
        dsi: diningSessionId || "",
        amount: billAmount || "",
        currencySymbol: props.country,
        traceId: traceStart?.traceId
      });

      const onBeforeResponse = await onBeforePaymentRef.current?.({
        gatewayId,
        paymentElement: PaymentElementEnum.CardPay,
        tip: tipAmountRef.current ?? 0
      });
      if (!onBeforeResponse) return;

      const lockResponse = await lock(event);
      if (!lockResponse) return;

      try {
        await api.payByCard({
          id: getSession(),
          reference: refId,
          gatewayID: gatewayId,
          diningSessionID: diningSessionId,
          tipAmount: tipAmountRef.current ? tipAmountRef.current.toFixed(2) : "0.00",
          returnUrl: callbackUrl.pending,
          paymentMethod: e.data.paymentMethod,
          annotations: {
            paymentMethod: PaymentElementEnum.CardPay,
            funnel: consumer
          }
        });
      } catch (error: any) {
        if (!error?.data) {
          onPaymentPending?.(event);
          return;
        } else throw error;
      }

      onPaymentPending?.(event);
    } catch (error: any) {
      onTraceClose?.({
        error: error,
        location: "payment_adyen_card",
        traceRef,
        traceStart
      });
      onPaymentFailure?.(event);
    } finally {
      setProcessing(false);
      unlock();
      cardElement?.update({});
    }
  };

  const renderPGElementBox = () => {
    if (!hasPgGroup || hideCardPay) return null;
    return (
      <PGPaymentBox
        name={t("Card")}
        selected={isSelected}
        toggleVisibility={() => {
          toggleVisibility({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay, name: "adyen" });
        }}
      />
    );
  };

  const buttonElement = (
    <Button
      id="payment-action-btn"
      variant={variant}
      type="submit"
      disabled={processing}
      loading={processing}
      onClick={handlePay}
    >
      {t("Pay")}
    </Button>
  );

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.CardPay,
      fn: handlePayCallback
    });
  }, [billAmount, tipAmount]);

  useEffect(() => {
    setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay });
  }, []);

  useEffect(() => {
    const initiate = async () => {
      try {
        const checkout = await AdyenCheckout({
          locale,
          environment: config.sandbox ? "test" : "live",
          clientKey: config.clientKey,
          onSubmit: handleSubmit
        });
        if (paymentContainer.current) {
          const card = checkout.create("card").mount(paymentContainer.current);
          setCardElement(card);
        }
      } catch (_) {}
    };

    initiate();
  }, []);

  useEffect(() => {
    onBeforePaymentRef.current = onBeforePayment;
    tipAmountRef.current = tipAmount;
  }, [onBeforePayment, tipAmount]);

  return (
    <div>
      {renderPGElementBox()}
      <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
        <div style={getStyles()}>
          <div id="card-container">
            <div ref={paymentContainer} />
          </div>
          {!hasPgGroup && (
            <div style={{ paddingTop: "20px" }}>
              <PaymentTerms />
              <Divider sx={{ margin: "16px 0 0 0" }} />
              {buttonElement}
            </div>
          )}
        </div>

        {isSelected && (
          <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{buttonElement}</ReactPortal>
        )}
      </div>
    </div>
  );
};

export default AdyenCardPayment;
