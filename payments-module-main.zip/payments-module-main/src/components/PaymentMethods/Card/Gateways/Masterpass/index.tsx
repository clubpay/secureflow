import { PaymentOptions } from "@/types";
import Masterpass from "./Masterpass";

const Index = (props: PaymentOptions) => {
  return <Masterpass {...props} />;
};

export default Index;
