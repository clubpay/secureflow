import $ from "jquery";
import { omit } from "lodash";
import { FormTypes, ICheckMasterpassValues, IDeleteCard, IPurchase, IPurchaseAndRegister } from "./types";

export const MASTERPASS_RESPONSE_CODE = {
  OTP: "5001",
  OTHER_OTP: "5008",
  SUCCESS: "0000",
  SUCCESS_REDIRECT_TO_3D: "5010",
  CONFLICT_WITH_ANOTHER_ORDERID: "1999",
  HAS_REACHED_THE_SMS_LIMIT: "1430"
};

export const removeSlashesAndReverse = (str: string) => {
  return str?.split("/")?.reverse()?.join("") || "";
};

export const createForm = (values: any) => {
  const form = document.createElement("form");
  form.id = "mfs-client-form";
  form.style.display = "none";
  const inputNames = Object.keys(values);
  const inputs = inputNames.map((name) => {
    const input = document.createElement("input");
    input.name = name;
    input.setAttribute("value", values[name as keyof FormTypes] as string);

    input.value = values[name as keyof FormTypes] as string;

    return input;
  });

  form.append(...inputs);

  return form;
};

export const registerMasterPassForm = (
  values: Partial<ICheckMasterpassValues>,
  callback: (status: number, response: any) => any
) => {
  const defaultValues = {
    sendSms: "Y",
    sendSmsLanguage: "tur"
  };

  Object.assign(values, defaultValues);

  const form = createForm(values);

  document.body.append(form);

  window.MFS.checkMasterPass($(form), callback);
};

export const getlListOfCards = (msisdn: string, token: string, callback: (status: number, response: any) => any) => {
  window.MFS.listCards(msisdn, token, callback);
};

export const MASTERPASS_BASE_ENDPOINT = {
  test: "https://test.masterpassturkiye.com/MasterpassJsonServerHandler/v2",
  uat: "https://uatui.masterpassturkiye.com/v2",
  prod: "https://ui.masterpassturkiye.com/v2"
};

export const detectCardType = (cardMask: string) => {
  let card = cardMask.split(" ").join("");
  card = card.replaceAll("*", "0") || card;
  const re = {
    electron: /^(4026|417500|4405|4508|4844|4913|4917)\d+$/,
    maestro: /^(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d+$/,
    dankort: /^(5019)\d+$/,
    interpayment: /^(636)\d+$/,
    unionpay: /^(62|88)\d+$/,
    visa: /^4[0-9]{12}(?:[0-9]{3})?$/,
    mastercard: /^5[1-5][0-9]{14}$/,
    amex: /^3[47][0-9]{13}$/,
    diners: /^3(?:0[0-5]|[68][0-9])[0-9]{11}$/,
    discover: /^6(?:011|5[0-9]{2})[0-9]{12}$/,
    jcb: /^(?:2131|1800|35\d{3})\d{11}$/
  };

  return Object.entries(re).find(([, val]) => val.test(card))?.[0] || "";
};

export const payWithRegisteredCard = (values: Partial<IPurchase>, callback: (status: number, response: any) => any) => {
  const defaultValues = {
    sendSmsLanguage: "tur",
    sendSms: "Y",
    aav: "aav",
    sendSmsMerchant: "Y",
    clientIp: "",
    encCPin: "",
    encPassword: "",
    password: "",
    macroMerchantId: ""
  };

  const newValues = omit(values, ["additionalParameters"]);

  Object.assign(newValues, defaultValues);
  const form = createForm(newValues);

  document.body.append(form);

  if (values.additionalParameters) {
    window.MFS.setAdditionalParameters(values.additionalParameters);
  }
  window.MFS.purchase($(form), callback);
};

export const purchaseAndRegister = (values: IPurchaseAndRegister, callback: (status: number, response: any) => any) => {
  const defaultValues = {
    actionType: "A",
    sendSms: "Y",
    sendSmsLanguage: "tur",
    macroMerchantId: ""
  };

  const newValues = omit(values, ["additionalParameters"]);

  Object.assign(newValues, defaultValues);
  const form = createForm(newValues);

  document.body.append(form);

  if (values.additionalParameters) {
    window.MFS.setAdditionalParameters(values.additionalParameters);
  }

  window.MFS.purchaseAndRegister($(form), callback);
};

export const removeCard = (values: IDeleteCard, callback: (status: number, response: any) => any) => {
  const defaultValues = {
    sendSms: "Y",
    sendSmsLanguage: "tur"
  };

  Object.assign(values, defaultValues);
  const form = createForm(values);

  document.body.append(form);
  window.MFS.deleteCard($(form), callback);
};
