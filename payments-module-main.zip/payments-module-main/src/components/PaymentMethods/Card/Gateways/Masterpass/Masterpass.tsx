import Scripts from "next/script";
import { Button } from "@/components/Core";
import useMasterpass from "@/hooks/masterpass";
import { t } from "@/locales";
import { PaymentOptions } from "@/types";
import { MasterpassLogo } from "@clubpay/customer-common-module/src/component/SVG";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import VerificationModal from "../../components/Masterpass/VerificationModal";
import { MASTERPASS_BASE_ENDPOINT } from "./Masterpass.util";

const Masterpass = (props: PaymentOptions) => {
  const {
    state: { open, totalAmount, onReady },
    methods: {
      handleLogin,
      toggleDrawer,
      deleteCard,
      closeDrawer,
      handlePay,
      setOnReady,
      resendCodeFromBank,
      verifyMasterpassCode
    }
  } = useMasterpass(props);

  const handleMasterpassReady = () => {
    setOnReady(true);
    window.MFS.setClientId(props.pg.config.extraConfig.clientId);
    window.MFS.setAddress(MASTERPASS_BASE_ENDPOINT[props.pg.config.extraConfig.env]);
  };

  return (
    <div style={{ paddingTop: "12px" }}>
      <VerificationModal
        open={open}
        toggleDrawer={toggleDrawer}
        onPay={handlePay}
        currency={props?.pg?.vendor?.country?.currencySymbol}
        amount={totalAmount?.toFixed(2) || "0.00"}
        onDelete={deleteCard}
        onClose={closeDrawer}
        onResend={resendCodeFromBank}
        onVerify={verifyMasterpassCode}
      />

      <Button onClick={handleLogin} disabled={!onReady}>
        Pay by masterpass
      </Button>
      <Scripts
        id="mfs-client"
        src="/pg_sdk/mfs-client.min.js"
        onLoad={handleMasterpassReady}
        strategy="afterInteractive"
      />
    </div>
  );
};

export default Masterpass;
