import { useEffect, useRef, useState } from "react";
import PaymentAPIManager from "@/api/gateways";
import { default as Input } from "@/components/Core/Input";
import { useLocale, useLockUnlock, useSentry, useToast, useTrace } from "@/hooks";
import { usePayment } from "@/providers";
import { useTyroStore } from "@/stores/tyroStore";
import { PaymentOptions } from "@/types";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { IStartSpanResponse } from "@clubpay/customer-common-module/src/hook/useSentryTrace";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { checkNetworkError } from "@clubpay/customer-common-module/src/utility/checkNetworkError";
import { parseJSON } from "@clubpay/customer-common-module/src/utility/k_json";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { CustomerDrawer } from "@qlub-dev/qlub-kit";
import { Span } from "@sentry/nextjs/types/client";
import CardLayout from "../../Layout/layout";
import { retrieveError } from "../Mashreq/Mashreq.util";

const Tyro = ({ variant = "primary", amount = 2, currency = "AED", qlub, ...props }: PaymentOptions) => {
  const {
    state: { tyroSessionId, initiated },
    setPaymentFuncRef
  } = useTyroStore((store) => store);

  const { isRTL } = useLocale(props.locale);

  const { setProcessing } = usePayment();

  const { getCallbackUrl } = useConfirmCallback();

  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const gatewayId = props.pg.id;
  const gatewayName = props.pg.name;

  const config = props.pg.config;

  const traceRef = useRef<IStartSpanResponse | undefined>();
  const traceStart = useTrace(props.pg);

  const { startTrace, infoLog } = useSentry(props);

  const [open3DS, setOpen3DS] = useState(false);
  const [iframeHtml, setIframeHtml] = useState<string | undefined>(undefined);

  const sessionRef = useRef("");
  const amountRef = useRef<any>("");

  useEffect(() => {
    sessionRef.current = tyroSessionId;
  }, [tyroSessionId]);

  useEffect(() => {
    amountRef.current = amount;
  }, [amount]);

  const { onBeforePayment, onPaymentSuccess, onPaymentFailure, onPaymentPending, onTraceClose } = config.events ?? {};

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).tyro;
  const referenceRef = useRef<null | string>(null);
  const { displayMessage } = useToast();

  const billMetaDataRef = useRef<any>(null);

  billMetaDataRef.current = { tip: qlub?.tip ? qlub.tip.toFixed(2) : "0.00", onBeforePayment };

  const handlePay = async ({ cardBrand, sessId }: any) => {
    startTrace("pay", PaymentElementEnum.CardPay, async (span: Span) => {
      setProcessing(true);

      referenceRef.current = getRandomString();
      traceRef.current = traceStart?.startSpan({
        dataName: gatewayName ?? "anonymous",
        span: {
          element: PaymentElementEnum.CardPay,
          refId: referenceRef.current
        }
      });

      const event = {
        paymentElement: PaymentElementEnum.CardPay,
        refId: referenceRef.current,
        traceId: span?.traceId,
        meta: {
          isExchangeInterrupted: !!qlub?.exchange,
          isExchangeUsed: qlub?.exchange?.isApplied
        }
      };

      const returnUrl = getCallbackUrl({
        ref: referenceRef.current,
        method: gatewayName || "",
        paymentElement: PaymentElementEnum.CardPay,
        dsi: qlub?.diningSessionId || "",
        amount: amount || "",
        currencySymbol: props.country,
        traceId: span?.traceId,
        lang: props.locale || ""
      });

      try {
        const onBeforeRes = await billMetaDataRef.current.onBeforePayment?.({
          gatewayId,
          paymentElement: PaymentElementEnum.CardPay,
          tip: billMetaDataRef.current.tip
        });

        if (!onBeforeRes) {
          infoLog("onBefore api Fail");
          setProcessing(false);
          return;
        }

        infoLog("onBefore api Success");

        infoLog("locking mechanism Initialize");

        const lockResponse = await lock(event);

        if (!lockResponse) {
          infoLog("locking mechanism Fail");
          setProcessing(false);
          return;
        }

        infoLog("locking mechanism Success");

        const response = await api.pay({
          id: getSession(),
          diningSessionID: qlub?.diningSessionId || "",
          cardBrand,
          billingCountry: props.pg?.vendor?.country?.code,
          failureUrl: returnUrl.fail,
          gatewayID: gatewayId,
          tyroSessionId: sessId,
          reference: referenceRef.current,
          successUrl: returnUrl.success,
          tipAmount: billMetaDataRef.current.tip
        });

        if (response.data.needVerification) {
          infoLog("verification process started");

          if (!response.data.redirectUrl && !response.data.redirectHtml) {
            displayMessage(retrieveError(), "error");
            unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
            setProcessing(false);
            infoLog("verification process fail");
            return;
          }

          if (response.data.redirectHtml) {
            infoLog("3ds process started");
            setIframeHtml(response.data.redirectHtml);
            setOpen3DS(true);
          } else if (response.data.redirectUrl) {
            window.location.href = response.data.redirectUrl;
          } else {
            displayMessage(retrieveError(), "error");
          }
        } else {
          onPaymentSuccess?.(event);
        }
      } catch (err: any) {
        infoLog("Tyro Error");

        const isNetworkError = checkNetworkError(err);

        if (isNetworkError) {
          onPaymentPending?.();
        } else {
          const error = {
            ...event,
            ...(err?.response?.data || {})
          };
          onPaymentFailure?.(error);
        }
      } finally {
        setProcessing(false);
      }
    });
  };

  const handle3DSResponse = async (event: Event) => {
    startTrace("3ds Response handler", PaymentElementEnum.CardPay, async (span: Span) => {
      const { data } = event as MessageEvent;
      if (!data) {
        infoLog("3ds response receive fail");
        return;
      }

      infoLog("3ds response receive success");

      const threeDsData = parseJSON(data) as { result: string };
      if (!threeDsData || !threeDsData.result) {
        infoLog("3ds response parse fail");
        return;
      }

      const { result } = threeDsData;
      infoLog("3ds response parse success");

      setOpen3DS(false);
      setIframeHtml(undefined);

      if (result !== "SUCCESS") {
        infoLog("3ds response returned fail response");

        infoLog("redirecting to fail page");

        onPaymentFailure?.({
          paymentElement: PaymentElementEnum.CardPay,
          refId: referenceRef.current || "",
          traceId: span?.traceId
        });
        return;
      }

      infoLog("payment authorize begin");

      const response: any = await api.payAuthorize({ tyroSessionId: sessionRef.current });

      switch (response.data.status) {
        case "success":
          infoLog("payment authorize returned success");
          onPaymentSuccess?.({
            paymentElement: PaymentElementEnum.CardPay,
            refId: referenceRef.current || "",
            traceId: traceStart?.traceId
          });
          break;
        case "pending":
        default:
          infoLog("payment authorize returned pending");
          onPaymentPending?.();
          break;
      }
    });
  };

  const handleSubmit = async (e?: React.MouseEvent, payload?: any) => {
    setProcessing(true);
    window.PaymentSession?.updateSessionFromForm("card");
  };

  const card = (props: any) => <Input id="card-number" {...props} readOnly forceLTR />;

  const expiryMonth = (props: any) => <Input {...props} id="expiry-month" readOnly forceLTR />;

  const expiryYear = (props: any) => <Input {...props} id="expiry-year" readOnly forceLTR />;

  const cvv = (props: any) => <Input {...props} id="security-code" readOnly forceLTR />;

  useEffect(() => {
    window?.addEventListener("message", handle3DSResponse);
    return () => window?.removeEventListener("message", handle3DSResponse);
  }, []);

  useEffect(() => {
    if (!open3DS || !iframeHtml) return;

    const script = document.getElementById("authenticate-payer-script") as HTMLScriptElement;
    if (script) {
      eval(script.text);
    }
  }, [open3DS, iframeHtml]);

  useEffect(() => {
    setPaymentFuncRef(handlePay);
  }, []);

  useEffect(() => {
    return () => {
      unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
      setPaymentFuncRef(null);
    };
  }, []);

  return (
    <>
      <CardLayout
        elements={{ card, expiryMonth, expiryYear, cvv }}
        onSubmit={handleSubmit}
        variant={variant}
        amount={amount}
        currency={currency}
        qlub={qlub}
        enableCardSaving={false}
        loading={!initiated}
        hide={config?.extraConfig?.hideCardPay}
        slots={[
          <CustomerDrawer
            disablePortal
            open={open3DS}
            onClose={() => {
              setOpen3DS(false);
              unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
            }}
            classes={{
              root: "3ds-modal"
            }}
            headerTitle="3D Secure"
          >
            <div>
              <div id="3ds" dangerouslySetInnerHTML={{ __html: iframeHtml ?? "" }} />
            </div>
          </CustomerDrawer>
        ]}
        {...props}
      />
    </>
  );
};

export default Tyro;
