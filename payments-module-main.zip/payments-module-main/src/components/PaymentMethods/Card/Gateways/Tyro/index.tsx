import TyroCloak from "@/components/GatewayCloaks/Tyro";
import { PaymentOptions } from "@/types";
import Tyro from "./Tyro";

export default function (props: PaymentOptions) {
  return (
    <TyroCloak onReady={props.pg.config.events?.onReady} {...props}>
      <Tyro {...props} />
    </TyroCloak>
  );
}
