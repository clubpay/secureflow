import { useEffect } from "react";

export default function useScriptRefresh(url: string, onLoad: any, onScriptRemove: any) {
  useEffect(() => {
    const script = document.createElement("script");
    script.src = url;
    script.async = true;
    script.onload = onLoad;
    document.body.appendChild(script);

    return () => {
      const existingScript = document.querySelector(`script[src*="${url}"]`);
      if (existingScript) {
        existingScript.remove();
        window.PaymentSession = undefined;
      }

      onScriptRemove();
    };
  }, []);
}
