import { t } from "@/locales";
import { ErrorMessageKey, ErrorMessages } from "@/utils";

export type FormSessionResponse = {
  status: ResponseStatus;
  sourceOfFunds: {
    provided: {
      card: {
        securityCode: string;
        scheme: string;
      };
    };
  };
  errors?: FormErrors;
  session: {
    id: string;
  };
};
export type FormErrors = {
  cardNumber?: FormErrorType;
  expiryYear?: FormErrorType;
  expiryMonth?: FormErrorType;
  securityCode?: FormErrorType;
  cardHolderName?: FormErrorType;
  message?: string;
};
export type FormErrorType = "invalid" | "missing";

export enum ResponseStatus {
  OK = "ok",
  ERROR_IN_FIELDS = "fields_in_error",
  REQUEST_TIMEOUT = "request_timeout",
  SYSTEM_ERROR = "system_error"
}

type ErrorTranslations = {
  SYSTEM_ERROR: string;
  REQUEST_TIMEOUT: string;
  ERROR_IN_FIELDS: {
    [key in keyof FormErrors]: {
      [type in FormErrorType]: string;
    };
  } & {
    default: string;
  };
};

export const errorTranslations: ErrorTranslations = {
  SYSTEM_ERROR: t("The payment did not proceed, please try again"),
  REQUEST_TIMEOUT: t("The payment transaction has been timed out, please try again"),
  ERROR_IN_FIELDS: {
    cardNumber: {
      invalid: t("Card number is invalid"),
      missing: t("Card number is required")
    },
    cardHolderName: {
      invalid: t("Card holder name is invalid"),
      missing: t("Card holder name is required")
    },
    expiryYear: {
      invalid: t("Expiry year is invalid"),
      missing: t("Expiry year is required")
    },
    expiryMonth: {
      invalid: t("Expiry month is invalid"),
      missing: t("Expiry month is required")
    },
    securityCode: {
      invalid: t("Security code is invalid"),
      missing: t("Security code is required")
    },
    default: t("Form is invalid. Please check and try again.")
  }
} as const;

const handleValidationError = (errs?: FormErrors) => {
  if (!errs) {
    return errorTranslations.ERROR_IN_FIELDS.default;
  }

  const errors: FormErrors = errs || {};
  const errorKeys = Object.keys(errors) as Array<keyof FormErrors>;
  const firstErr = errorKeys.find((key) => errors[key] === "missing" || errors[key] === "invalid");
  const message = firstErr ? errorTranslations.ERROR_IN_FIELDS[firstErr] : undefined;

  if (!message || !firstErr) {
    return errorTranslations.ERROR_IN_FIELDS.default;
  }

  return message[errors[firstErr] as FormErrorType];
};

export const extractError = (response: FormSessionResponse) => {
  switch (response.status) {
    case ResponseStatus.SYSTEM_ERROR:
      return errorTranslations.SYSTEM_ERROR;

    case ResponseStatus.ERROR_IN_FIELDS:
      handleValidationError(response.errors);
      break;
    case ResponseStatus.REQUEST_TIMEOUT:
      return errorTranslations.REQUEST_TIMEOUT;
  }

  return errorTranslations.SYSTEM_ERROR;
};

export const extractErrorV2 = (errors: any) => {
  if (Object.keys(errors).length > 1) return ErrorMessages[ErrorMessageKey.Generic];

  if (errors["cardNumber"]) return ErrorMessages[ErrorMessageKey.Card];

  if (errors["expiryMonth"]) return ErrorMessages[ErrorMessageKey.Expiry];

  if (errors["expiryYear"]) return ErrorMessages[ErrorMessageKey.Expiry];

  if (errors["securityCode"]) return ErrorMessages[ErrorMessageKey.Cvv];

  return false;
};
