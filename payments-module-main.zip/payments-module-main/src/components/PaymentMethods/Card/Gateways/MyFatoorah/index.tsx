import MyFatoorahCloak from "@/components/GatewayCloaks/MyFatoorah";
import { PaymentOptions } from "@/types";
import MyFatoorahCardPayment from "./MyFatoorah";

export default function (props: PaymentOptions) {
  return (
    <MyFatoorahCloak pg={props.pg}>
      <MyFatoorahCardPayment {...props} />
    </MyFatoorahCloak>
  );
}
