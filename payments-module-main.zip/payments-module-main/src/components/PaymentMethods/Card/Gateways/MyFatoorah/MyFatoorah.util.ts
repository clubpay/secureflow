export const getSdkUrl = (countryCode: string, isSandbox: boolean) => {
  if (isSandbox) return "https://demo.myfatoorah.com/cardview/v2/session.js";
  if (countryCode === "SAU") return "https://sa.myfatoorah.com/cardview/v2/session.js";
  if (countryCode === "QAT") return "https://qa.myfatoorah.com/cardview/v2/session.js";
  else return "https://portal.myfatoorah.com/cardview/v2/session.js";
};
