import { useEffect, useState } from "react";
import PaymentAPIManager from "@/api/gateways";
import { Button } from "@/components/Core";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import PaymentTerms from "@/components/Global/PaymentTerms";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock, useSentry } from "@/hooks";
import { usePgEvent } from "@/hooks/pg-events";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { snackBar } from "@clubpay/customer-common-module/src/hook/snackBar";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomId, getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { Divider } from "@mui/material";

const MyFatoorahCardPayment = (props: PaymentOptions) => {
  const { variant = "primary", amount, qlub, pg, locale } = props;

  const gatewayId = pg.id;
  const gatewayName = pg.name;
  const config = pg.config;
  const hideCardPay = config.extraConfig.hideCardPay;
  const tipAmount = qlub?.tip;
  const billAmount = amount;
  const diningSessionId = qlub?.diningSessionId;
  const currencyCode = pg.vendor.country.currencyCode?.toUpperCase();

  const { onBeforePayment, onPaymentSuccess, onPaymentFailure, onPaymentPending } = config.events ?? {};
  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).myFatoorah;

  const [isMounted, setIsMounted] = useState(false);

  const [cardViewId] = useState(`card-view-${getRandomId()}`);

  const { startTrace, captureException } = useSentry(props);

  const { getCallbackUrl } = useConfirmCallback();

  const { processing, setProcessing } = usePayment();

  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const { triggerSnackBar, actionButton } = snackBar();

  const { sendEvent } = usePgEvent({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });

  const {
    state: { loadedState, consumer }
  } = useCommonStore((store) => store);

  const {
    state: pgGroupState,
    toggleVisibility,
    setAddPGMethod,
    removePGMethod,
    setPaymentMethodReference
  } = usePGGroupStore((state) => state);

  const isSelected = isPaymethodChoosed({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay });
  const hasPgGroup = pgGroupState.isPGGroupEnabled;

  const getStyles = () => {
    if (hasPgGroup) {
      if (isSelected)
        return {
          display: "block",
          paddingTop: "10px"
        };

      return {
        display: "none"
      };
    }
    return {
      display: "block"
    };
  };

  const handlePay = async (sessionId: string, cardBrand: string) => {
    startTrace("pay", PaymentElementEnum.CardPay, async () => {
      const refId = getRandomString();
      const event = {
        paymentElement: PaymentElementEnum.CardPay,
        refId
      };

      const returnUrl = getCallbackUrl({
        ref: refId as string,
        method: gatewayName,
        paymentElement: PaymentElementEnum.CardPay,
        dsi: diningSessionId || "",
        amount: billAmount || "",
        currencySymbol: props.country
      });

      try {
        const onBeforeResponse = await onBeforePayment({ ...event, tip: tipAmount ?? 0 });
        if (!onBeforeResponse) return;

        const lockResponse = await lock({ ...event, tip: tipAmount ?? 0 });
        if (!lockResponse) return;

        try {
          const response = await api.payByCard({
            id: getSession(),
            reference: refId,
            gatewayID: gatewayId,
            diningSessionID: diningSessionId,
            tipAmount: tipAmount ? tipAmount.toFixed(2) : "0.00",
            cardBrand,
            sessionId,
            errorUrl: returnUrl.fail,
            callBackUrl: returnUrl.success,
            annotations: {
              paymentMethod: PaymentElementEnum.CardPay,
              funnel: consumer
            }
          });
          if (response.data.redirectUrl) {
            sendEvent("payment_initialized", { status: "3ds" });
            window.location.href = response.data.redirectUrl;
            return;
          }
          onPaymentSuccess(event);
        } catch (error: any) {
          if (!error?.data) {
            onPaymentPending(event);
            return;
          } else throw error;
        }
      } catch (error) {
        onPaymentFailure(event);
      } finally {
        unlock();
        setProcessing(false);
      }
    });
  };

  const handleSubmit = async () => {
    try {
      setProcessing(true);
      const response = await window.myFatoorah.submit();
      handlePay(response.sessionId, response.cardBrand);
    } catch (error) {
      triggerSnackBar(
        t("Card information is invalid. Please check the details and retry"),
        {
          variant: "error",
          action: actionButton
        },
        true
      );
      setProcessing(false);
      captureException(error);
    }
  };

  const renderPGElementBox = () => {
    if (!hasPgGroup || hideCardPay) return null;
    return (
      <PGPaymentBox
        name={t("Card")}
        selected={isSelected}
        toggleVisibility={() => {
          toggleVisibility({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay, name: "myfatoorah" });
        }}
      />
    );
  };

  const buttonElement = (
    <Button
      id="payment-action-btn"
      variant={variant}
      type="submit"
      disabled={processing}
      loading={processing}
      onClick={handleSubmit}
    >
      {t("Pay")}
    </Button>
  );

  useEffect(() => {
    const init = async () => {
      try {
        const response = await api.initiateSession({
          diningSessionID: diningSessionId,
          gatewayID: gatewayId
        });
        const sessionId = response.data.sessionID;
        const countryCode = response.data.countryCode;

        const options = {
          sessionId,
          countryCode,
          currencyCode,
          cardViewId,
          supportedNetworks: "v,m,md,ae",

          style: {
            hideCardIcons: false,
            direction: locale === "ar" ? "rtl" : "ltr",
            cardHeight: 240,
            tokenHeight: 180,
            input: {
              color: "black",
              fontSize: "16px",
              inputHeight: "43px",
              inputMargin: "14px",
              borderColor: "c7c7c7",
              borderWidth: "1px",
              borderRadius: "8px",
              placeHolder: {
                holderName: t("Cardholder Name"),
                cardNumber: "1234 1234 1234 1234",
                expiryDate: "MM / YY",
                securityCode: "CVV"
              }
            },
            text: {
              saveCard: t("Save this card"),
              addCard: t("Use another Card"),
              deleteAlert: {
                title: t("Delete"),
                message: t("Are you sure you want to remove this card"),
                confirm: t("Yes"),
                cancel: t("No")
              }
            }
          }
        };
        window.myFatoorah.init(options);
        setIsMounted(true);
        window.addEventListener("message", window.myFatoorah.recievedMessage);
      } catch (error) {
        captureException(error);
      }
    };
    if (loadedState.myFatoorah && !isMounted) init();

    return () => {
      window.removeEventListener("message", window.myFatoorah.recievedMessage);
    };
  }, [loadedState.myFatoorah]);

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.CardPay,
      fn: handleSubmit
    });
  }, [billAmount, tipAmount]);

  useEffect(() => {
    if (!hideCardPay) {
      setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay });
    }
  }, [hideCardPay]);

  useEffect(() => {
    return () => removePGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.CardPay });
  }, []);

  return (
    <div>
      {renderPGElementBox()}
      <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
        {!hideCardPay && (
          <div style={getStyles()}>
            <div id={cardViewId}></div>
            {!hasPgGroup && (
              <div style={{ paddingTop: "20px" }}>
                <PaymentTerms />
                <Divider sx={{ margin: "16px 0 0 0" }} />
                {buttonElement}
              </div>
            )}
          </div>
        )}
        {isSelected && (
          <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{buttonElement}</ReactPortal>
        )}
      </div>
    </div>
  );
};

export default MyFatoorahCardPayment;
