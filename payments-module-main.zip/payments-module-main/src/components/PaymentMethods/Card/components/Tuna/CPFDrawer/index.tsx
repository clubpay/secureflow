import { useState } from "react";
import { Button } from "@/components/Core";
import { default as Input } from "@/components/Core/Input";
import { useScreenSize } from "@/hooks";
import { t } from "@/locales";
import { Box, Typography } from "@mui/material";
import { SwipeableCustomerDrawer } from "@qlub-dev/qlub-kit";

interface Props {
  open: boolean;
  onClose: VoidFunction;
  onChange: (value: string, type: string) => void;
  onProceed: VoidFunction;
  cpfRequired?: boolean;
  content?: {
    title: string;
    subtitle: String;
  };
}

const TYPES = {
  CPF: "999.999.999-99",
  CNPJ: "99.999.999/9999-99"
} as const;

const clear = (value: string): string => value.replace(/[^0-9]/g, "");

const CPFDrawer = ({ open, onClose, onChange, onProceed, cpfRequired, content }: Props) => {
  const dims = useScreenSize();

  const MAX_LENGTH = clear(TYPES.CNPJ).length;

  const [value, setValue] = useState("");

  const shouldDisable = () => {
    return value.length === 14 || value.length === 18;
  };

  const onLocalChange = (ev: React.ChangeEvent<HTMLInputElement>) => {
    let value = clear(ev.target.value);
    const mask = getMask(value);

    if (value.length > MAX_LENGTH) return;

    value = applyMask(value, TYPES[mask]);

    console.log("value", value);
    setValue(value);
    onChange(value, mask);
  };

  const getMask = (value: string): keyof typeof TYPES => (value.length > 11 ? "CNPJ" : "CPF");

  const applyMask = (value: string, mask: string): string => {
    let result = "";

    let inc = 0;
    Array.from(value).forEach((letter, index) => {
      if (!mask[index + inc].match(/[0-9]/)) {
        result += mask[index + inc];
        inc++;
      }
      result += letter;
    });
    return result;
  };

  return (
    <SwipeableCustomerDrawer
      sx={{
        zIndex: 1100
      }}
      PaperProps={{
        sx: {
          maxWidth: "552px",
          margin: "0 auto"
        }
      }}
      open={open}
      headerTitle={content?.title ? content?.title : t("Would you like to include CPF/CNPJ in invoice?")}
      onClose={onClose}
      onOpen={() => {}}
    >
      <Box sx={{ flexGrow: 1, maxHeight: dims.height - 80, overflowY: "auto", overflowX: "hidden" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
          <Typography>
            {content?.subtitle ? content.subtitle : t("Fill in or leave it in blank if you do not wish to inform")}
          </Typography>
          <Input type="tel" value={value} onChange={onLocalChange} />
          <Button
            id="payment-action-btn"
            style={{ marginTop: "16px" }}
            onClick={onProceed}
            {...(cpfRequired ? { disabled: !shouldDisable() } : {})}
          >
            {t("Proceed")}
          </Button>
        </div>
      </Box>
    </SwipeableCustomerDrawer>
  );
};

export default CPFDrawer;
