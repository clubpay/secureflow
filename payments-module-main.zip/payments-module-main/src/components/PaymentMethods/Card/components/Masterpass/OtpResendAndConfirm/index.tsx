import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/Core";
import { useMasterpassStore } from "@/stores/masterpassStore";
import { Typography } from "@mui/material";
import styles from "./otpResendAndConfirm.module.scss";

const OtpResendAndConfirm = ({ onResend, onVerify }: any) => {
  const { state, setOTPProcess } = useMasterpassStore((state) => state);
  const [seconds, setSeconds] = useState(state.state.otp.duration);
  const timerRef = useRef<any>(null);

  const shouldConfirmBtnActive = () => {
    if (seconds > 0 && state.state.otp.isCompleted) return true;
    return false;
  };

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setSeconds((prevState: any) => prevState - 1);
    }, 1000);

    return () => clearInterval(timerRef.current);
  }, [seconds]);

  useEffect(() => {
    if (seconds === 0) {
      clearInterval(timerRef.current);
      setOTPProcess({
        status: false
      });
    }
  }, [seconds]);

  return (
    <div>
      <div style={{ padding: "20px 0" }}>
        {seconds > 0 ? (
          <Typography>{`${seconds} seconds remaining`}</Typography>
        ) : (
          <button className={styles.resendBtn} onClick={onResend}>
            I didnt receive
          </button>
        )}{" "}
      </div>
      <div>
        <Button onClick={onVerify} disabled={!shouldConfirmBtnActive()}>
          Confirm code
        </Button>
      </div>
    </div>
  );
};

export default OtpResendAndConfirm;
