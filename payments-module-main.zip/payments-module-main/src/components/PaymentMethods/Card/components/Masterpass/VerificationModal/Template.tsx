import { Close } from "@mui/icons-material";
import { Typography } from "@mui/material";
import IconButton from "@mui/material/IconButton";
import styles from "./template.module.scss";

const Template = ({ title, subtitle, slot1, bottomCTA, amount, currency, onClose, completeBottom }: any) => {
  return (
    <div className={styles.templateParent}>
      <div className={styles.headerContainer}>
        <div className={styles.headerLeftCont}>
          <Typography sx={{ fontSize: "22px", fontWeight: 500 }}>{title || "title"}</Typography>
        </div>
        <div className={styles.headerRightCont}>
          <IconButton onClick={onClose}>
            <Close.default />
          </IconButton>
        </div>
      </div>
      <div className={styles.subtitleContainer}>
        <Typography className={styles.subtitle} sx={{ fontSize: "14px" }}>
          {subtitle || "subtitle"}
        </Typography>
      </div>
      {slot1 && <div className={styles.slotContainer}>{slot1}</div>}
      {completeBottom ? (
        completeBottom
      ) : (
        <>
          <div className={styles.dividerContainer}>
            <div className={styles.divider} />
          </div>
          <div className={styles.paymentDetailsContainer}>
            <div className={styles.paymentDetailsText}>
              <div className={styles.paymentTextContainer}>
                <Typography className={styles.paymentText} sx={{ fontWeight: 500 }}>
                  You are paying
                </Typography>
              </div>
              <div className={styles.paymentSubTextContainer}>
                <Typography className={styles.paymentSubText} sx={{ fontSize: "12px" }}>
                  Includes tip, taxes and charges
                </Typography>
              </div>
            </div>
            <div className={styles.paymentAmountContainer}>
              <Typography className={styles.paymentAmount}>{`${currency} ${amount}`}</Typography>
            </div>
          </div>
          <div className={styles.payButtonContainer}>{bottomCTA && bottomCTA}</div>
        </>
      )}
    </div>
  );
};

export default Template;
