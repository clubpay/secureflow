import { forwardRef } from "react";
import { Formik } from "formik";
import * as Yup from "yup";
import { Input } from "@/components/Core";

const AddCard = (props: any, ref: any) => {
  return (
    <Formik
      initialValues={{ cardLabel: "", cardNumber: "", expirationDate: "" }}
      validationSchema={Yup.object({
        cardLabel: Yup.string().required("Card label is required"),
        cardNumber: Yup.string().required("Card number is required"),
        expirationDate: Yup.string().required("Expiration date is required")
      })}
      onSubmit={(values, { setSubmitting }) => {
        console.log("onSubmit: setSubmitting", setSubmitting);
        props.onPay(true, values);
      }}
    >
      {(formik) => (
        <form onSubmit={formik.handleSubmit}>
          <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
            <Input
              label="Card Label"
              id="cardLabel"
              type="text"
              error={formik.touched.cardLabel && formik.errors.cardLabel}
              hideFieldError
              {...formik.getFieldProps("cardLabel")}
            />
            <Input
              label="Card Number"
              id="cardNumber"
              type="text"
              error={formik.touched.cardNumber && formik.errors.cardNumber}
              hideFieldError
              {...formik.getFieldProps("cardNumber")}
              onChange={(e) => {
                const content = e.target.value;
                if (content?.length >= 20) return;
                const inputNumber = content.replace(/\D/g, "");
                const formattedNumber = inputNumber.replace(/(\d{4})(?=\d)/g, "$1 ");
                formik.setFieldValue("cardNumber", formattedNumber);
              }}
              value={formik.values.cardNumber}
            />

            <Input
              label="Expiration Date"
              id="expirationDate"
              type="text"
              error={formik.touched.expirationDate && formik.errors.expirationDate}
              hideFieldError
              {...formik.getFieldProps("expirationDate")}
              onChange={(e) => {
                const content = e.target.value;
                if (content?.length >= 20) return;
                const inputMonth = content.replace(/\D/g, "");
                const formatted = inputMonth.slice(0, 4).replace(/(\d{2})(?=\d)/, "$1/");
                formik.setFieldValue("expirationDate", formatted);
              }}
              value={formik.values.expirationDate}
            />
            <button type="submit" style={{ display: "none" }} ref={ref}>
              Submit
            </button>
          </div>
        </form>
      )}
    </Formik>
  );
};

export default forwardRef(AddCard);
