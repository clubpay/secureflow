import { useMasterpassStore } from "@/stores/masterpassStore";
import {
  AmericanExpressLogoIcon,
  MasterpassLogo,
  VisaLogoIcon
} from "@clubpay/customer-common-module/src/component/SVG";
import { CheckCircleRounded, DeleteRounded, RadioButtonUncheckedRounded } from "@mui/icons-material";
import { IconButton, Typography } from "@mui/material";
import { detectCardType } from "../../../Gateways/Masterpass/Masterpass.util";
import styles from "./savedCard.module.scss";

const SavedCard = ({ card, onDelete }: any) => {
  const { setSelectedCard } = useMasterpassStore((state) => state);

  const getCardIcon = (type: string) => {
    switch (type) {
      case "visa":
        return <VisaLogoIcon />;
      case "mastercard":
        return <VisaLogoIcon />;
      case "amex":
        return <AmericanExpressLogoIcon />;
      default:
        return <MasterpassLogo />;
    }
  };

  return (
    <div
      className={styles.parent}
      style={{
        background: card.selected ? "rgba(125, 0, 212, 0.08)" : "#fff"
      }}
    >
      <div className={styles.leftChild}>
        <div
          className={styles.item}
          onClick={() => {
            setSelectedCard(card.UniqueId);
          }}
        >
          {card.selected ? <CheckCircleRounded sx={{ fill: "#7d00d4" }} /> : <RadioButtonUncheckedRounded />}
        </div>
        <div className={styles.item}>
          <Typography>{getCardIcon(detectCardType(card.mask))}</Typography>
        </div>
        <div className={styles.item}>
          <Typography>{`${card.mask} (${card.Name})`}</Typography>
        </div>
      </div>
      <div className={styles.rgihtChild}>
        <div className={styles.item}>
          <IconButton onClick={() => onDelete(card.UniqueId, card.Name)}>
            <DeleteRounded />
          </IconButton>
        </div>
      </div>
    </div>
  );
};

export default SavedCard;
