import { useRef } from "react";
import { Button } from "@/components/Core";
import { usePayment } from "@/providers";
import { useMasterpassStore } from "@/stores/masterpassStore";
import { AddCircleRounded } from "@mui/icons-material";
import { Typography } from "@mui/material";
import SwipeableDrawer from "@mui/material/SwipeableDrawer";
import { MasterpassModalScreens } from "../../../Gateways/Masterpass/types";
import OtpInput from "../../common/OtpInput";
import AddCard from "../AddCard";
import OtpResendAndConfirm from "../OtpResendAndConfirm";
import SavedCard from "../SavedCard";
import Template from "./Template";
import styles from "./template.module.scss";

const VerificationModal = ({
  open,
  toggleDrawer,
  onPay,
  currency,
  amount,
  onDelete,
  onClose,
  onVerify,
  onResend
}: any) => {
  const { state, setMasterpassDisplay } = useMasterpassStore((state) => state);
  const { cards, displayName } = state.state;
  const proceedBtnRef = useRef<any>(null);
  const { processing } = usePayment();
  const isCardSelected = Boolean(cards?.find((card: any) => card.selected));

  const handleDisplayToAddCard = () => {
    setMasterpassDisplay(MasterpassModalScreens.ADD_NEW_CARD);
  };

  const getTemplatePageContent = () => {
    switch (displayName) {
      case MasterpassModalScreens.QLUB_ACCOUNT_SUCCESS:
        return {
          title: "Select your card and pay",
          subtitle: "Select your card and pay",
          slot1: (
            <div>
              <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                {cards.map((card: any) => (
                  <SavedCard card={card} onDelete={onDelete} />
                ))}
              </div>
              <div className={styles.addCardArea} onClick={handleDisplayToAddCard}>
                <AddCircleRounded sx={{ color: "rgb(125, 0, 212)" }} />
                <Typography sx={{ fontSize: "20px" }}>Add a new card</Typography>
              </div>
            </div>
          ),
          bottomCTA: (
            <Button onClick={() => onPay()} disabled={!isCardSelected} loading={processing}>
              Pay now
            </Button>
          )
        };

      case MasterpassModalScreens.BANK_OTP_STEP:
        return {
          title: "Masterpass verification",
          subtitle: "Enter the code sent to card holder’s mobile number.",
          slot1: (
            <div>
              <OtpInput length={6} onVerify={onVerify} />
            </div>
          ),
          completeBottom: <OtpResendAndConfirm onResend={onResend} onVerify={onVerify} />
        };

      case MasterpassModalScreens.ADD_NEW_CARD:
        return {
          title: "Add new card and pay",
          subtitle: "Add new card and pay",
          slot1: (
            <div>
              <div></div>
              <div>
                <AddCard ref={proceedBtnRef} onPay={onPay} />
              </div>
            </div>
          ),
          bottomCTA: <Button onClick={() => proceedBtnRef.current?.click?.()}>Continue</Button>
        };
      default:
        return {};
    }
  };

  return (
    <>
      <SwipeableDrawer
        anchor="bottom"
        open={open}
        onClose={toggleDrawer}
        onOpen={toggleDrawer}
        className={styles.customDrawer}
      >
        <Template {...getTemplatePageContent()} currency={currency} amount={amount} onClose={onClose} />
      </SwipeableDrawer>
    </>
  );
};

export default VerificationModal;
