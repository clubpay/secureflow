import { ReactNode } from "react";
import { useScreenSize } from "@/hooks";
import { t } from "@/locales";
import { Box } from "@mui/material";
import { SwipeableCustomerDrawer } from "@qlub-dev/qlub-kit";
import styles from "./paymentDrawer.module.scss";

interface Props {
  open: boolean;
  children: ReactNode;
  onClose: VoidFunction;
}

const PaymentDrawer = ({ open, children, onClose }: Props) => {
  const dims = useScreenSize();

  return (
    <SwipeableCustomerDrawer
      sx={{
        zIndex: 1100
      }}
      PaperProps={{
        sx: {
          maxWidth: "552px",
          margin: "0 auto"
        }
      }}
      open={open}
      headerTitle={t("Choose Payment Method")}
      onClose={onClose}
      onOpen={() => {}}
    >
      <Box sx={{ flexGrow: 1, maxHeight: dims.height - 80, overflowY: "auto", overflowX: "hidden" }}>
        {children}
        <div>
          <div id="inner-pg-group-paybtn-container" className={styles.pgGroupBtnContainer} />
        </div>
      </Box>
    </SwipeableCustomerDrawer>
  );
};

export default PaymentDrawer;
