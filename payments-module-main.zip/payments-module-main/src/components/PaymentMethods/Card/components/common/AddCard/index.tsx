import { t } from "@/locales";
import AddCardIcon from "@mui/icons-material/AddCard";
import CheckCircleRounded from "@mui/icons-material/CheckCircleRounded";
import RadioButtonUncheckedRoundedIcon from "@mui/icons-material/RadioButtonUncheckedRounded";
import styles from "./index.module.scss";

const AddCard = ({ isAdding, onToggle, text }: any) => (
  <div
    className={styles.container}
    onClick={onToggle}
    style={
      !isAdding
        ? {
            backgroundColor: "#fff"
          }
        : {}
    }
  >
    <div className={styles.leftContainer}>
      <div className={styles.leftCheckMark}>
        {isAdding ? (
          <CheckCircleRounded.default sx={{ fill: "var(--iris)" }} />
        ) : (
          <RadioButtonUncheckedRoundedIcon.default />
        )}
      </div>
      <div className={styles.leftCardDetailsCont}>
        <div>{text ?? t("Add new card")}</div>
      </div>
    </div>
    <div className={styles.rightContainer}>
      <div className={styles.clickble}>
        <AddCardIcon.default />
      </div>
    </div>
  </div>
);

export default AddCard;
