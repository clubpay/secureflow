import React from "react";
import { SnackbarContent, SnackbarKey, SnackbarMessage, useSnackbar } from "notistack";
import CurrencyExchangeIcon from "@mui/icons-material/CurrencyExchange";
import { Alert, Typography } from "@mui/material";

interface ExchangeAlertProps {
  id?: SnackbarKey;
  message?: SnackbarMessage;
}

const ExchangeAlert = React.forwardRef<HTMLDivElement, ExchangeAlertProps>((props, ref) => {
  const { id, message, ...other } = props;
  const { closeSnackbar } = useSnackbar();

  return (
    <SnackbarContent ref={ref} role="alert" {...other}>
      <Alert
        variant="filled"
        severity="warning"
        icon={<CurrencyExchangeIcon.default fontSize="small" />}
        sx={{ borderRadius: 2, py: 1.5, width: "100%" }}
        onClose={() => closeSnackbar(id)}
      >
        <Typography sx={{ fontWeight: "400", fontSize: "13px", px: "25px" }}>{message}</Typography>
      </Alert>
    </SnackbarContent>
  );
});

export default ExchangeAlert;
