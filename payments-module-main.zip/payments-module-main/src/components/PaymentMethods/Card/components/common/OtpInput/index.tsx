import { useEffect, useState } from "react";
import OtpInput from "react-otp-input";
import { useMasterpassStore } from "@/stores/masterpassStore";
import styles from "./otpInput.module.scss";

const Index = ({ length }: any) => {
  const [otp, setOtp] = useState("");

  const { setOTPCode, resetOTPProcess } = useMasterpassStore((state) => state);
  const hanldeChange = (code: string) => {
    setOtp(code);
    setOTPCode({
      code,
      isCompleted: code.length === length
    });
  };

  useEffect(() => {
    return () => resetOTPProcess();
  }, []);

  return (
    <OtpInput
      value={otp}
      onChange={hanldeChange}
      numInputs={length}
      renderSeparator={<span style={{ width: "10px" }}></span>}
      renderInput={(props) => <input {...props} className={styles.otpInput} />}
    />
  );
};

export default Index;
