import { ReactNode, forwardRef } from "react";
import { Dialog, Slide } from "@mui/material";
import { TransitionProps } from "@mui/material/transitions";

const Transition = forwardRef(function Transition(
  props: TransitionProps & {
    children: React.ReactElement<unknown>;
  },
  ref: React.Ref<unknown>
) {
  return <Slide direction="up" ref={ref} {...props} />;
});

interface ThreeDsDialogProps {
  open: boolean;
  children: ReactNode;
  onClose?: VoidFunction;
}

const ThreeDsDialog = ({ open, children, onClose }: ThreeDsDialogProps) => {
  return (
    <Dialog open={open} fullScreen onClose={onClose} TransitionComponent={Transition}>
      {children}
    </Dialog>
  );
};

export default ThreeDsDialog;
