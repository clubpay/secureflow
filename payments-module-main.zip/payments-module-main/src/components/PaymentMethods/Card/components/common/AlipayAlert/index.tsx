import { t } from "@/locales";
import InfoIcon from "@mui/icons-material/Info";
import { Alert } from "@mui/material";
import styles from "./alipayAlert.module.scss";

const AlipayAlert = () => {
  return (
    <Alert
      classes={{
        message: styles.message,
        icon: styles.icon,
        root: styles.root
      }}
      icon={<InfoIcon.default />}
    >
      {t("Only Alipay China is supported, not Alipay Hong Kong")}
    </Alert>
  );
};

export default AlipayAlert;
