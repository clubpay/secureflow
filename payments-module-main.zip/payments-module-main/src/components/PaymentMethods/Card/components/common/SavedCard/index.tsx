import { ReactNode } from "react";
import { CVCHint } from "@/icons";
import { t } from "@/locales";
import { useCommonStore } from "@/stores/commonStore";
import {
  AmericanExpressLogoIcon,
  MasterCardLogoIcon,
  SodexoLogoIcon,
  VRLogoIcon,
  VisaLogoIcon
} from "@clubpay/customer-common-module/src/component/SVG";
import CheckCircleRounded from "@mui/icons-material/CheckCircleRounded";
import DeleteIcon from "@mui/icons-material/Delete";
import ModeEditIcon from "@mui/icons-material/ModeEdit";
import RadioButtonUncheckedRoundedIcon from "@mui/icons-material/RadioButtonUncheckedRounded";
import inputStyles from "../../../../../Core/Input/styles/input.module.scss";
import styles from "./index.module.scss";

type CardBrandType =
  | "Visa"
  | "visa"
  | "master"
  | "mastercard"
  | "Amex"
  | "amex"
  | "american express"
  | "vr"
  | "sodexo"
  | "unknown";

const SavedCard = (props: any) => {
  const variant = "primary";
  const {
    state: { isRTL }
  } = useCommonStore((store) => store);

  const getCardIcon = (cardType: CardBrandType | undefined) => {
    switch (cardType) {
      case "Visa":
      case "visa":
        return <VisaLogoIcon />;
      case "master":
      case "mastercard":
        return <MasterCardLogoIcon />;
      case "Amex":
      case "amex":
      case "american express":
        return <AmericanExpressLogoIcon />;
      case "vr":
        return <VRLogoIcon />;
      case "sodexo":
        return <SodexoLogoIcon />;

      default:
        return <MasterCardLogoIcon />;
    }
  };

  return (
    <div>
      <div
        {...(props?.disableEdit ? { onClick: props?.onSelect } : {})}
        className={styles.container}
        style={
          !props?.selected
            ? {
                backgroundColor: "#fff"
              }
            : {}
        }
      >
        <div className={styles.leftContainer} {...(!props?.disableEdit ? { onClick: props?.onSelect } : {})}>
          <div className={styles.leftCheckMark}>
            {props?.selected ? (
              <CheckCircleRounded.default sx={{ fill: "var(--iris)" }} />
            ) : (
              <RadioButtonUncheckedRoundedIcon.default />
            )}
          </div>
          <div className={styles.leftCardDetailsCont}>
            <div className={styles.cardIcCont}>{getCardIcon(props?.brand)}</div>
            <div style={{ direction: "ltr" }}>{props.maskedNumber}</div>
          </div>
        </div>
        <div className={styles.rightContainer}>
          {!props?.disableEdit && (
            <div className={styles.clickble} onClick={props?.onChangeClick}>
              <ModeEditIcon.default />
            </div>
          )}
          <div className={styles.clickble} onClick={props?.onUnsaveClick}>
            <DeleteIcon.default />
          </div>
        </div>
      </div>
      {props?.selected && props?.manualCVV && (
        <div style={{ marginTop: "2px" }}>
          <label className={`${inputStyles.label}`} style={{ display: "inline-block", padding: "4px 0" }}>
            {t("Security code")}
          </label>
          <div className={inputStyles.inputWrapper}>
            <input
              className={`${inputStyles[`${variant}-base`]} ${inputStyles[`${variant}-input`]}`}
              value={props?.cvv ?? ""}
              onChange={props?.onCVVChange}
            />
            {!isRTL && (
              <span className={inputStyles.infoWrapper}>
                <CVCHint />
              </span>
            )}
          </div>
        </div>
      )}

      {props?.selected && Array.isArray(props?.slots) && props?.slots?.map((item: ReactNode | boolean) => item)}
    </div>
  );
};

export default SavedCard;
