import { useEffect } from "react";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import ReactPortal from "@/components/Global/ReactPortal";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";

interface PropsTypes {
  gatewayID: string;
  paymentMethod: string;
  name: string;
  children: React.ReactNode;
  icon?: any;
  drawerMode?: boolean;
}

export default ({ gatewayID, paymentMethod, name, icon, children, drawerMode = false }: PropsTypes) => {
  const { toggleVisibility } = usePGGroupStore((state) => state);

  const hasChoosen = isPaymethodChoosed({ pgId: gatewayID, paymentMethod });

  return (
    <div>
      <PGPaymentBox
        icon={icon}
        name={name}
        selected={hasChoosen}
        toggleVisibility={() => toggleVisibility({ pgId: gatewayID, paymentMethod })}
      />
      {hasChoosen && (
        <ReactPortal
          domNode={document.querySelector(
            drawerMode ? "#inner-pg-group-paybtn-container" : "#pg-group-paybtn-container"
          )}
        >
          {children}
        </ReactPortal>
      )}
    </div>
  );
};
