export { default, ApplePayPortal } from "./Portal";
