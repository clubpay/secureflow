import { lazy, useEffect, useState } from "react";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import Apple from "@/icons/Apple";
import { t as t2 } from "@/locales";
import { PaymentProvider } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { LazyComponentInventory, PaymentOptions } from "@/types";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";

const gateways: LazyComponentInventory = {
  direct: lazy(() => import("./Gateways/Direct")),
  myfatoorah: lazy(() => import("./Gateways/MyFatoorah"))
};

export const ApplePayPortal = (props: PaymentOptions) => {
  const [applePayAvailable, setApplePayAvailable] = useState(false);

  const Gateway = gateways[props.pg?.name] ?? gateways.direct;

  const { state, toggleVisibility } = usePGGroupStore((state) => state);
  const hasPgGroup = state.isPGGroupEnabled;

  const hasChosen = isPaymethodChoosed({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.ApplePay });

  const {
    state: { loadedState }
  } = useCommonStore((store) => store);

  const getName = () => {
    if (props.pg.name?.toLowerCase() == "tuna") return `Apple Pay (${t2("Credit Card")})`;

    return t2("Apple Pay");
  };

  useEffect(() => {
    if (loadedState.applePay) {
      setApplePayAvailable(window?.ApplePaySession && ApplePaySession?.canMakePayments());
    }
  }, [loadedState.applePay]);

  return (
    <PaymentProvider>
      <div id="apple-pay-container">
        {applePayAvailable && hasPgGroup && (
          <PGPaymentBox
            icon={<Apple />}
            name={getName()}
            selected={hasChosen}
            toggleVisibility={() => toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.ApplePay })}
          />
        )}
        <Gateway {...props} />
      </div>
    </PaymentProvider>
  );
};

export default ApplePayPortal;
