import React, { useEffect, useRef, useState } from "react";
import Scripts from "next/script";
import PaymentAPIManager from "@/api/gateways";
import ApplePay from "@/components/Global/PaymentButtonForClient/ApplePay";
import PaymentLoadingDialog from "@/components/Global/PaymentLoadingDialog";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock, useSentry } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { usePgEvent } from "@/hooks/pg-events";
import { usePayment } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { MyFatoorahConfig, MyFatoorahResponse } from "@/types/payments/config/myFatoorah";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { sumAmounts } from "@clubpay/customer-common-module/src/utility/k_math";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { Span } from "@sentry/nextjs/types/client";
import { getSdkUrl } from "./MyFatoorah.util";

const MyFatoorahApplePay = (props: PaymentOptions) => {
  const { amount, qlub, pg, locale, country, totalAmount: totalByClient } = props;

  const gatewayId = pg.id;
  const gatewayName = pg.name;
  const config = pg.config as MyFatoorahConfig;
  const tipAmount = qlub?.tip;
  const billAmount = amount;
  const diningSessionId = qlub?.diningSessionId;
  const countryCode = pg.vendor.country.isoCode?.toUpperCase();
  const currencyCode = pg.vendor.country.currencyCode?.toUpperCase();

  const totalAmount = totalByClient ?? sumAmounts(qlub?.currencyPrecision || 0, billAmount || 0, tipAmount || 0);

  const { onBeforePayment, onPaymentPending, onPaymentComplete, onPaymentFailure, onPrePayment } = config.events ?? {};
  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).myFatoorah;

  const [applePayAvailable, setApplePayAvailable] = useState(false);
  const onBeforePaymentRef = useRef(onBeforePayment);
  const tipAmountRef = useRef(tipAmount);

  const {
    state: pgGroupState,
    setPaymentMethodReference,
    setAddPGMethod,
    removePGMethod
  } = usePGGroupStore((state) => state);

  const { startTrace, infoLog, captureException } = useSentry(props);
  const { processing, setProcessing } = usePayment();
  const { getCallbackUrl } = useConfirmCallback();
  const { lock, unlock } = useLockUnlock(props);
  const { sendEvent } = usePgEvent({ paymentOptions: props, paymentMethod: PaymentElementEnum.ApplePay });
  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.ApplePay });

  const {
    setLoadedState,
    state: { loadedState, consumer }
  } = useCommonStore((store) => store);

  const hasPgGroup = pgGroupState.isPGGroupEnabled;

  const hasChosen = isPaymethodChoosed({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.ApplePay });

  const paymentCallBack = () => window?.myFatoorahAP?.initPayment();

  const handleSubmit = () => {
    if (onPrePayment) onPrePayment(paymentCallBack, PaymentElementEnum.ApplePay);
    else paymentCallBack();
  };

  const handlePay = (response: MyFatoorahResponse) => {
    startTrace("pay", PaymentElementEnum.ApplePay, async (span: Span) => {
      const refId = getRandomString();
      const event = {
        paymentElement: PaymentElementEnum.ApplePay,
        refId,
        traceId: span?.traceId
      };

      const returnUrl = getCallbackUrl({
        ref: refId,
        method: gatewayName,
        paymentElement: PaymentElementEnum.ApplePay,
        dsi: diningSessionId || "",
        amount: billAmount,
        currencySymbol: country,
        lang: locale || "",
        is3ds: true
      });
      try {
        setProcessing(true);
        const onBeforeResponse = await onBeforePaymentRef.current?.({
          gatewayId,
          paymentElement: PaymentElementEnum.ApplePay,
          tip: tipAmountRef.current ?? 0
        });

        if (!onBeforeResponse) return;

        const lockResponse = await lock({
          paymentElement: PaymentElementEnum.ApplePay,
          refId,
          tip: tipAmountRef.current ?? 0
        });

        if (!lockResponse) return;

        saveLastPayment({ cardBrand: response.cardBrand });

        try {
          await api.payByApple({
            id: getSession(),
            reference: refId,
            gatewayID: gatewayId,
            diningSessionID: diningSessionId,
            tipAmount: tipAmountRef.current ? tipAmountRef.current.toFixed(2) : "0.00",
            sessionId: response.sessionId,
            callBackUrl: returnUrl.success,
            errorUrl: returnUrl.fail,
            cardBrand: response.cardBrand,
            annotations: {
              paymentMethod: PaymentElementEnum.ApplePay,
              funnel: consumer
            }
          });
          infoLog("Authorization Success");
          onPaymentComplete(event);
        } catch (error: any) {
          if (!error?.data) {
            infoLog("Authorization Pending : Network error");
            onPaymentPending(event);
          } else throw error;
        }
      } catch (error) {
        infoLog("Authorization Fail");
        captureException(error);
        onPaymentFailure(event);
      } finally {
        setProcessing(false);
        unlock();
      }
    });
  };

  const handleCancel = () => {
    sendEvent("applepay_cancel");
  };

  useEffect(() => {
    if (window.myFatoorahAP) {
      window.myFatoorahAP.updateAmount(totalAmount);
    }

    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.ApplePay,
      fn: paymentCallBack
    });
  }, [totalAmount]);

  useEffect(() => {
    const init = async () => {
      try {
        const response = await api.initiateSession({
          diningSessionID: diningSessionId,
          gatewayID: gatewayId
        });
        const sessionId = response.data.sessionID;

        const options = {
          sessionId,
          countryCode,
          currencyCode,
          amount: totalAmount,
          callback: handlePay,
          sessionCanceled: handleCancel
        };

        window.myFatoorahAP.init(options);
        setApplePayAvailable(window?.ApplePaySession && ApplePaySession?.canMakePayments());
      } catch (error) {
        captureException(error);
      }
    };

    if (loadedState.applePay) init();
  }, [loadedState.applePay]);

  useEffect(() => {
    onBeforePaymentRef.current = onBeforePayment;
    tipAmountRef.current = tipAmount;
  }, [onBeforePayment, tipAmount]);

  useEffect(() => {
    if (applePayAvailable) {
      setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.ApplePay });
    }
    return () => removePGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.ApplePay });
  }, [applePayAvailable]);

  return (
    <div>
      <div>
        <div id="card-element"></div>
      </div>
      <div
        style={{
          display: hasPgGroup ? "none" : "block"
        }}
      >
        {applePayAvailable && <ApplePay onClick={handleSubmit} />}
      </div>

      <PaymentLoadingDialog open={processing} />

      {hasChosen && (
        <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>
          <ApplePay loading={processing} onClick={handleSubmit} />
        </ReactPortal>
      )}
      <Scripts src={getSdkUrl(countryCode, config.sandbox)} onLoad={() => setLoadedState("applePay")} />
    </div>
  );
};

export default MyFatoorahApplePay;
