export const getSdkUrl = (countryCode: string, isSandbox: boolean) => {
  if (isSandbox) return "https://demo.myfatoorah.com/applepay/v3/applepay.js";
  if (countryCode === "SAU") return "https://sa.myfatoorah.com/applepay/v3/applepay.js";
  if (countryCode === "QAT") return "https://qa.myfatoorah.com/applepay/v3/applepay.js";
  else return "https://portal.myfatoorah.com/applepay/v3/applepay.js";
};
