import isEmpty from "lodash/isEmpty";

export enum FlowType {
  GENERAL_FLOW = "GENERAL_FLOW",
  PREFFERED_NETWORK_FLOW = "PREFFERED_NETWORK_FLOW",
  PREFFERED_MERCHANT_FLOW = "PREFFERED_MERCHANT_FLOW"
}

export const determineFlow = (name: string, config: any) => {
  const preferredMerchantEnabledPGs = ["checkout"];

  // if both configs set, follow generalized value flow
  if (
    preferredMerchantEnabledPGs.includes(name?.toLowerCase()) &&
    !isEmpty(config?.preferredNetworks) &&
    !isEmpty(config?.preferredMerchantCapabilitiesList)
  )
    return FlowType.GENERAL_FLOW;

  if (preferredMerchantEnabledPGs.includes(name?.toLowerCase()) && !isEmpty(config?.preferredMerchantCapabilitiesList))
    return FlowType.PREFFERED_MERCHANT_FLOW;

  return FlowType.PREFFERED_NETWORK_FLOW;
};
