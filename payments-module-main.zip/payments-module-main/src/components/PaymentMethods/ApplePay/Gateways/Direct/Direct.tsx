import { useEffect, useMemo, useRef, useState } from "react";
import isEmpty from "lodash/isEmpty";
import isUndefined from "lodash/isUndefined";
import Scripts from "next/script";
import ApplePay from "@/components/Global/PaymentButtonForClient/ApplePay";
import PaymentLoadingDialog from "@/components/Global/PaymentLoadingDialog";
import ReactPortal from "@/components/Global/ReactPortal";
import { APPLE_PAY_CONSENT_COOKIE_NAME } from "@/constants";
import storage from "@/constants/storage";
import { useLocale } from "@/hooks";
import { useLockUnlock } from "@/hooks";
import useApplePay from "@/hooks/apple";
import { useExchangeInterruption } from "@/hooks/exchange";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { usePgEvent } from "@/hooks/pg-events";
import usePgRelatedLogicsForNonCardPayMethods from "@/hooks/pg-related-logics-for-non-card-pay-methods";
import useSentry from "@/hooks/sentry";
import useCPFDrawer from "@/hooks/useCPFDrawer";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { setCookie } from "@/utils";
import { getPaymentExchangeDecision } from "@/utils/payments/exchange";
import { disableApplePayShippingBilling, getApplePayShippingBillingConfig } from "@/utils/payments/shippingBilling";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { sumAmounts } from "@clubpay/customer-common-module/src/utility/k_math";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { Span } from "@sentry/nextjs/types/client";
import { FlowType, determineFlow } from "./util";

export interface ApplePayProps extends PaymentOptions {}

export const Direct = (props: ApplePayProps) => {
  const { pg, qlub, amount, totalAmount: totalByClient } = props;
  const gatewayId = pg.id;
  const config = pg.config;
  const tipAmount = qlub?.tip || 0;
  const billAmount = amount || 0;
  const currencyPrecision = qlub?.currencyPrecision || 0;
  const exchange = qlub?.exchange;
  const pgName = pg.name;

  const { onPaymentPending, onPaymentFailure } = config.events ?? {};

  const { startTrace, infoLog } = useSentry(props);

  const enableDocumentCollection = props.pg.config.extraConfig.enableDocumentCollection;

  const [applePayAvailalbe, setApplePayAvailalbe] = useState(false);
  const [showLoadingDialog, setShowLoadingDialog] = useState(false);
  const initialSession = useRef<ApplePaySession | null>(null);
  const retrySession = useRef<ApplePaySession | null>(null);

  const {
    setLoadedState,
    state: { loadedState, applePayConsent, consumer }
  } = useCommonStore((store) => store);

  const { triggerInterruption } = useExchangeInterruption({
    paymentOptions: props,
    paymentMethod: PaymentElementEnum.ApplePay
  });

  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.ApplePay });
  const { sendEvent } = usePgEvent({ paymentOptions: props, paymentMethod: PaymentElementEnum.ApplePay });

  useLocale(props.locale);

  const { lock, unlock } = useLockUnlock(props);

  const { loading, paymentHandler, getPayload, onPaymentComplete, completeApplePayPayment, setLoading } =
    useApplePay(props);

  const { data } = usePgRelatedLogicsForNonCardPayMethods(props);

  const { setAddPGMethod, removePGMethod, setPaymentMethodReference } = usePGGroupStore((state) => state);

  const totalAmount = useMemo(() => {
    if (exchange?.isApplied) return exchange.total;
    if (!isUndefined(totalByClient)) return totalByClient;
    return sumAmounts(currencyPrecision, billAmount, tipAmount);
  }, [billAmount, tipAmount, totalByClient, exchange]);

  const createSession = (request: ApplePayJS.ApplePayPaymentRequest, shouldRetry = false) => {
    const applePaySession = new ApplePaySession(config?.appleSDKVersion || 3, request);

    const refId = getRandomString();

    applePaySession.onvalidatemerchant = async (e) => {
      startTrace("onvalidatemerchant", PaymentElementEnum.ApplePay, async () => {
        try {
          setLoading(true);

          if (applePayConsent) {
            setCookie(APPLE_PAY_CONSENT_COOKIE_NAME, "true");
          }

          const onBeforeResponse = await config?.events?.onBeforePayment?.({
            gatewayId,
            paymentElement: PaymentElementEnum.ApplePay,
            tip: qlub?.tip || 0
          });

          if (!onBeforeResponse) {
            infoLog("onBefore api Fail");
            applePaySession?.abort();
            return;
          }
          infoLog("onBefore api Success");

          infoLog("locking mechanism Initialize");

          const lockResponse = await lock({
            paymentElement: PaymentElementEnum.ApplePay,
            refId,
            tip: qlub?.tip || 0,
            traceId: ""
          });

          if (!lockResponse) {
            infoLog("locking mechanism Fail");
            applePaySession?.abort();
            return;
          }

          infoLog("locking mechanism Success");

          infoLog("apple pay validation Initialize");
          const response = await paymentHandler?.validateApplePaySession(getPayload("onvalidatemerchant", e));

          if (response) {
            applePaySession.completeMerchantValidation(getPayload("completeMerchantValidation", response));

            infoLog("apple pay validation Success");
          } else {
            infoLog("apple pay validation Fail");
          }
        } catch (e) {
          infoLog("onvalidatemerchant Error");
          applePaySession?.abort();
          unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
        } finally {
          setLoading(false);
        }
      });
    };

    applePaySession.onpaymentauthorized = async (e) => {
      startTrace("onpaymentauthorized", PaymentElementEnum.ApplePay, async () => {
        const event = {
          paymentElement: PaymentElementEnum.ApplePay,
          refId,
          meta: {
            isExchangeInterrupted: !!qlub?.exchange,
            isExchangeUsed: !!qlub?.exchange?.isApplied
          }
        };
        try {
          setLoading(true);
          /** get exchange decision before call saveLastPayment */
          const exchangeDecision = getPaymentExchangeDecision(qlub?.exchange, pgName);

          saveLastPayment({ cardBrand: e?.payment?.token?.paymentMethod?.network });

          const response = await paymentHandler?.payByApple({
            ...(getPayload("onpaymentauthorized", {
              payment: {
                token: e?.payment?.token,
                shippingContact: e?.payment?.shippingContact,
                billingContact: e?.payment?.billingContact,
                network: e?.payment?.token?.paymentMethod?.network
              },
              additonalData: {
                id: getSession(),
                exchangeDecision,
                refId,
                documentData,
                ...data
              }
            }) as any),
            annotations: {
              paymentMethod: PaymentElementEnum.ApplePay,
              funnel: consumer
            }
          });

          if (response?.data.exchangeData) {
            setLoading(false);
            infoLog("Forex interruption Success");
            unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
            completeApplePayPayment(applePaySession, false);
            triggerInterruption(response.data);
            return;
          } else {
            infoLog("Authorization Success");
            completeApplePayPayment(applePaySession);
            setShowLoadingDialog(true);
            onPaymentComplete?.(event);
          }
        } catch (error: any) {
          setLoading(false);
          infoLog("Authorization Fail");
          completeApplePayPayment(applePaySession, false);
          setShowLoadingDialog(true);
          if (!error?.data) {
            onPaymentPending?.(event);
          } else {
            onPaymentFailure?.(event);
          }
        }
      });
    };

    applePaySession.onpaymentmethodselected = (e) => {
      //* * assume there is no active card in the wallet */

      startTrace("onpaymentmethodselected", PaymentElementEnum.ApplePay, async (_span: Span) => {
        if (!e.paymentMethod?.type) {
          initialSession.current?.abort();
          setTimeout(() => {
            retrySession.current?.begin();
          }, config.applepayRetryingTimeout || 500);
          return;
        }

        applePaySession.completePaymentMethodSelection(
          getPayload("onpaymentmethodselected", {
            additonalData: {
              amount: totalAmount.toFixed(qlub?.currencyPrecision || 0)
            }
          }) as any
        );
      });
    };

    applePaySession.onshippingmethodselected = () => {
      applePaySession.completeShippingMethodSelection({} as any);
    };

    applePaySession.onshippingcontactselected = () => {
      applePaySession.completeShippingContactSelection({} as any);
    };

    applePaySession.oncancel = () => {
      startTrace("oncancel", PaymentElementEnum.ApplePay, async (_span: Span) => {
        disableApplePayShippingBilling();
        unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
        infoLog("oncancel Success");
        sendEvent("applepay_cancel");
        if (shouldRetry) {
          setTimeout(() => {
            retrySession.current?.begin();
          }, config.applepayRetryingTimeout || 500);
        }
      });
    };

    return applePaySession;
  };

  const setupSessionCreation = () => {
    const responseFlow = determineFlow(pg.name, pg.config.extraConfig);

    if (responseFlow === FlowType.PREFFERED_NETWORK_FLOW) {
      const isAttempted = sessionStorage.getItem(storage.ATTEMPT_WITH_PREFERRED_NETWORKS);

      const supportedNetworks = config?.supportedNetworks || ["visa", "masterCard", "amex", "discover"];
      const preferredNetworks = config?.preferredNetworks || [];

      const supportedMerchantCapabilities = config?.merchantCapabilitiesList || ["supports3DS"];

      let shouldRetry = false;

      if (exchange?.isInterrupted) {
        shouldRetry = !isEmpty(preferredNetworks);
      } else {
        shouldRetry = !isEmpty(preferredNetworks) && !isAttempted;
      }

      if (!supportedMerchantCapabilities.includes("supports3DS")) {
        supportedMerchantCapabilities.push("supports3DS");
      }

      const request = {
        countryCode: (config?.countryCode || pg.vendor.country.code)?.toUpperCase() || "AE",
        currencyCode: (qlub?.exchange?.isApplied
          ? qlub?.exchange?.currencyCode
          : pg.vendor.country.currencyCode
        )?.toUpperCase(),
        merchantCapabilities: supportedMerchantCapabilities,
        supportedNetworks,
        total: {
          label: "Qlub_",
          type: "final",
          amount: totalAmount.toFixed(qlub?.currencyPrecision || 0)
        },
        ...getApplePayShippingBillingConfig({ ...config, applePayConsent })
      };

      initialSession.current = createSession(
        {
          ...request,
          supportedNetworks: shouldRetry ? preferredNetworks : supportedNetworks
        },
        shouldRetry
      );

      infoLog("create session Success");

      if (shouldRetry) {
        retrySession.current = createSession(request);
        infoLog("retrySession session Success");
      }

      initialSession.current?.begin();
      sessionStorage.setItem(storage.ATTEMPT_WITH_PREFERRED_NETWORKS, "true");
    } else if (responseFlow === FlowType.PREFFERED_MERCHANT_FLOW) {
      const supportedNetworks = ["visa", "masterCard", "amex", "discover"];

      const supportedMerchantCapabilities = config?.merchantCapabilitiesList || [
        "supportsDebit",
        "supportsCredit",
        "supports3DS"
      ];

      const preferredMerchantCapabilitiesList = config.preferredMerchantCapabilitiesList;

      const isAttempted = sessionStorage.getItem(storage.ATTEMPT_WITH_PREFERRED_MERCHANT_CAPABILITIES);

      if (!supportedMerchantCapabilities.includes("supports3DS")) {
        supportedMerchantCapabilities.push("supports3DS");
      }

      if (!preferredMerchantCapabilitiesList.includes("supports3DS")) {
        preferredMerchantCapabilitiesList.push("supports3DS");
      }

      const request = {
        countryCode: (config?.countryCode || pg.vendor.country.code)?.toUpperCase() || "AE",
        currencyCode: (qlub?.exchange?.isApplied
          ? qlub?.exchange?.currencyCode
          : pg.vendor.country.currencyCode
        )?.toUpperCase(),
        merchantCapabilities: supportedMerchantCapabilities,
        supportedNetworks,
        total: {
          label: "Qlub_",
          type: "final",
          amount: totalAmount.toFixed(qlub?.currencyPrecision || 0)
        },
        ...getApplePayShippingBillingConfig({ ...config, applePayConsent })
      };

      infoLog("create session Success");

      initialSession.current = createSession(
        {
          ...request,
          merchantCapabilities: !isAttempted ? preferredMerchantCapabilitiesList : supportedMerchantCapabilities
        },
        !isAttempted
      );

      infoLog("create session Success");

      if (!isAttempted) {
        retrySession.current = createSession(request);
        infoLog("retrySession session Success");
      }

      initialSession.current?.begin();

      sessionStorage.setItem(storage.ATTEMPT_WITH_PREFERRED_MERCHANT_CAPABILITIES, "true");
    } else {
      const supportedNetworks = config?.supportedNetworks || ["visa", "masterCard", "amex", "discover"];

      const request = {
        countryCode: (config?.countryCode || pg.vendor.country.code)?.toUpperCase() || "AE",
        currencyCode: (qlub?.exchange?.isApplied
          ? qlub?.exchange?.currencyCode
          : pg.vendor.country.currencyCode
        )?.toUpperCase(),
        merchantCapabilities: ["supportsDebit", "supportsCredit", "supports3DS"],
        supportedNetworks,
        total: {
          label: "Qlub_",
          type: "final",
          amount: totalAmount.toFixed(qlub?.currencyPrecision || 0)
        },
        ...getApplePayShippingBillingConfig({ ...config, applePayConsent })
      };

      initialSession.current = createSession(request);

      infoLog("create session Success");

      initialSession.current?.begin();
    }
  };

  const handlePayment = async () => {
    startTrace("handlePayment", PaymentElementEnum.ApplePay, async (_span: Span) => {
      if (!window?.ApplePaySession) {
        return;
      }

      setupSessionCreation();
    });
  };

  const paymentCallbackFn = () => handlePayment();

  const localSubmit = () => {
    openCPFDrawer();
  };

  const handleSubmit = (e: any) => {
    if (pg.config.events?.onPrePayment) pg.config.events?.onPrePayment(localSubmit, PaymentElementEnum.ApplePay);
    else {
      localSubmit();
    }
  };

  const { state } = usePGGroupStore((state) => state);

  const hasPgGroup = state.isPGGroupEnabled;

  const hasChoosen = isPaymethodChoosed({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.ApplePay });

  const checkApplePayAvailability = () =>
    window.ApplePaySession && setApplePayAvailalbe(ApplePaySession && ApplePaySession?.canMakePayments());

  const {
    DrawerElement,
    openCPFDrawer,
    additionalData: documentData
  } = useCPFDrawer({
    paymentCB: paymentCallbackFn,
    enabled: props.pg.name === "tuna" && props.pg.config.extraConfig.enableDocumentCollection
  });

  useEffect(() => {
    if (loadedState.applePay) checkApplePayAvailability();
  }, [loadedState.applePay]);

  useEffect(() => {
    if (applePayAvailalbe) {
      setAddPGMethod({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.ApplePay });

      infoLog("Initialization Success");
    }
  }, [applePayAvailalbe]);

  useEffect(() => {
    setPaymentMethodReference({
      pgId: props.pg.id,
      paymentMethod: PaymentElementEnum.ApplePay,
      fn: localSubmit
    });
  }, [amount, totalAmount]);

  useEffect(() => {
    return () => removePGMethod({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.ApplePay });
  }, []);

  if (loadedState.applePay && !applePayAvailalbe) return false;

  return (
    <div>
      {DrawerElement}
      <PaymentLoadingDialog open={showLoadingDialog} />
      <div
        style={{
          display: hasPgGroup ? "none" : "block"
        }}
      >
        {applePayAvailalbe && <ApplePay onClick={handleSubmit} />}
      </div>

      {hasChoosen && (
        <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>
          <ApplePay loading={loading} onClick={handleSubmit} />
        </ReactPortal>
      )}
      <Scripts src="/pg_sdk/apple-pay-sdk.js" onLoad={() => setLoadedState("applePay")} />
    </div>
  );
};

export default Direct;
