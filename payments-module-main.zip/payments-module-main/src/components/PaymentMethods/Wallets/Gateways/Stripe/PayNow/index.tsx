import StripeCloak from "@/components/GatewayCloaks/Stripe";
import { getLocale } from "@/components/PaymentMethods/Card/Gateways/Stripe/Stripe.util";
import { PaymentOptions } from "@/types";
import { sumAmounts } from "@clubpay/customer-common-module/src/utility/k_math";
import PayNow from "../../../components/PayNow";

export default function (props: PaymentOptions) {
  const total =
    Math.round(sumAmounts(props.qlub?.currencyPrecision, props?.amount || 0, props.qlub?.tip || 0) * 100) || 0;

  if (total > 0) {
    return (
      <StripeCloak
        pg={props.pg}
        options={{
          locale: getLocale(props.locale),
          amount: total
        }}
      >
        <PayNow {...props} />
      </StripeCloak>
    );
  }

  return null;
}
