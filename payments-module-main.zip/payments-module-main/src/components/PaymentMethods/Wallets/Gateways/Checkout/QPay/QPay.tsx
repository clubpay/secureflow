import { useEffect, useRef, useState } from "react";
import PaymentAPIManager from "@/api/gateways";
import { Button } from "@/components/Core";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { QPay as QPayIcon } from "@/icons";
import { t } from "@/locales";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";

export const QPay = ({ variant = "primary", qlub, ...props }: PaymentOptions) => {
  const config = props.pg.config;
  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).checkout;

  const { toggleVisibility, state, setAddPGMethod, setPaymentMethodReference } = usePGGroupStore((state) => state);
  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.QPay });

  const { onBeforePayment } = config.events ?? {};

  const hasPgGroup = state.isPGGroupEnabled;

  const gatewayId = props.pg.id;
  const gatewayName = props.pg.name;

  const [loading, setLoading] = useState(false);

  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const { getCallbackUrl } = useConfirmCallback();

  const referenceRef = useRef<null | string>(null);

  const billMetaDataRef = useRef<any>(null);

  billMetaDataRef.current = { tip: qlub?.tip ? qlub.tip.toFixed(2) : "0.00" };

  const event = {
    gatewayId,
    paymentElement: PaymentElementEnum.QPay,
    tip: billMetaDataRef.current.tip
  };

  const handlePayRequest = async () => {
    setLoading(true);
    referenceRef.current = getRandomString();
    const returnUrl = getCallbackUrl({
      ref: referenceRef.current as string,
      method: gatewayName,
      paymentElement: PaymentElementEnum.CardPay,
      dsi: qlub?.diningSessionId || "",
      currencySymbol: props.country,
      lang: props.locale || ""
    });

    try {
      await lock(event);
      saveLastPayment();
      const response = await api.payByQPayRequest({
        diningSessionID: qlub?.diningSessionId || "",
        failure_url: returnUrl.fail,
        gatewayID: gatewayId,
        id: getSession(),
        reference: referenceRef.current as string,
        success_url: returnUrl.success,
        tipAmount: billMetaDataRef.current.tip
      });

      if (response.data._links.redirect.href) window.location.href = response.data._links.redirect.href;
    } catch (e: any) {
      console.log("error occured:", e);
    } finally {
      setLoading(false);
      unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
    }
  };

  const handlePay = () => {
    const run = () => {
      onBeforePayment(event);
      handlePayRequest();
    };
    if (config.events?.onPrePayment) config.events?.onPrePayment(run, "");
    else run();
  };

  const button = (
    <Button id="qpay-btn" variant={variant} onClick={handlePay} loading={loading}>
      {hasPgGroup ? t("Pay") : t("NAPS Debit Card")}
    </Button>
  );

  const getStyles = () => {
    if (hasPgGroup) {
      return {
        display: "none"
      };
    }
    return {
      display: "block"
    };
  };

  const hasChoosen = isPaymethodChoosed({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.QPay });

  useEffect(() => {
    setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.QPay });
  }, []);

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.QPay,
      fn: handlePay
    });
  }, [props.amount]);

  return (
    <div>
      <div style={getStyles()}>{button}</div>
      {hasPgGroup && (
        <PGPaymentBox
          name={t("NAPS Debit Card")}
          icon={<QPayIcon />}
          selected={hasChoosen}
          toggleVisibility={() => toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.QPay })}
        />
      )}
      {hasChoosen && <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{button}</ReactPortal>}
    </div>
  );
};

export default QPay;
