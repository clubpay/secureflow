import { useEffect, useRef } from "react";
import PaymentAPIManager from "@/api/gateways";
import { Button } from "@/components/Core";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock, useTrace } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { usePgEvent } from "@/hooks/pg-events";
import { KNET as KNETIcon } from "@/icons";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { IStartSpanResponse } from "@clubpay/customer-common-module/src/hook/useSentryTrace";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";

export const KNET = (props: PaymentOptions) => {
  const { variant = "primary", amount, qlub, pg, country, locale } = props;
  const config = pg.config;
  const diningSessionId = qlub?.diningSessionId || "";
  const gatewayId = pg.id;
  const gatewayName = pg.name;
  const tipAmount = qlub?.tip;
  const { onBeforePayment, onTraceClose, onPaymentFailure } = config.events ?? {};
  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).checkout;

  const traceRef = useRef<IStartSpanResponse | undefined>();
  const traceStart = useTrace(pg);

  const { processing, setProcessing } = usePayment();

  const { sendEvent } = usePgEvent({ paymentOptions: props, paymentMethod: PaymentElementEnum.KNET });
  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.KNET });

  const {
    toggleVisibility,
    state: pgGroupState,
    setAddPGMethod,
    setPaymentMethodReference
  } = usePGGroupStore((state) => state);
  const hasPgGroup = pgGroupState.isPGGroupEnabled;

  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const { getCallbackUrl } = useConfirmCallback();

  const isSelected = isPaymethodChoosed({ pgId: gatewayId, paymentMethod: PaymentElementEnum.KNET });

  const handlePay = async () => {
    setProcessing(true);
    const reference = getRandomString();
    const event = {
      paymentElement: PaymentElementEnum.KNET,
      refId: reference,
      traceId: traceStart?.traceId
    };

    try {
      traceRef.current = traceStart?.startSpan({
        dataName: gatewayName,
        span: {
          element: PaymentElementEnum.KNET,
          refId: reference
        }
      });

      const returnUrl = getCallbackUrl({
        ref: reference,
        method: gatewayName,
        paymentElement: PaymentElementEnum.KNET,
        dsi: diningSessionId,
        currencySymbol: country,
        traceId: traceStart?.traceId,
        amount: amount,
        lang: locale
      });

      const onBeforeResponse = await onBeforePayment?.({
        gatewayId,
        paymentElement: PaymentElementEnum.KNET,
        tip: tipAmount ?? 0
      });
      if (!onBeforeResponse) return;

      const lockResponse = await lock(event);
      if (!lockResponse) return;

      saveLastPayment();
      const response = await api.payByKNET({
        id: getSession(),
        tipAmount: tipAmount?.toFixed(qlub?.currencyPrecision || 0) || "0.00",
        diningSessionID: diningSessionId,
        gatewayID: gatewayId,
        reference: reference,
        success_url: returnUrl.success,
        failure_url: returnUrl.fail
      });

      if (response.data._links.redirect.href) {
        sendEvent("payment_initialized", { status: "redirect" });
        window.location.href = response.data._links.redirect.href;
      }
    } catch (error: any) {
      onTraceClose?.({
        error: error,
        location: "payment_checkout_knet",
        traceRef,
        traceStart
      });
      onPaymentFailure?.(event);
    } finally {
      setProcessing(false);
      unlock?.();
    }
  };

  const button = (
    <Button variant={variant} loading={processing} disabled={processing} onClick={handlePay}>
      {hasPgGroup ? t("Pay") : "KNET"}
    </Button>
  );

  const getStyles = () => {
    if (hasPgGroup) {
      return {
        display: "none"
      };
    }
    return {
      display: "block"
    };
  };

  useEffect(() => {
    setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.KNET });
  }, []);

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.KNET,
      fn: handlePay
    });
  }, [amount, tipAmount]);

  return (
    <div>
      <div style={getStyles()}>{button}</div>
      {hasPgGroup && (
        <PGPaymentBox
          name="KNET"
          icon={<KNETIcon />}
          selected={isSelected}
          toggleVisibility={() => toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.KNET })}
        />
      )}
      {isSelected && <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{button}</ReactPortal>}
    </div>
  );
};

export default KNET;
