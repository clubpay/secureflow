export { default } from "./KNET";
