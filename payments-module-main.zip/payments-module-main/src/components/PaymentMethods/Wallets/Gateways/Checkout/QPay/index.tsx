export { default } from "./QPay";
