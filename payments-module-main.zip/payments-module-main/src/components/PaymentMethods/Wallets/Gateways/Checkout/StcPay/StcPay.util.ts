export const splitPhoneNumber = (phoneNumber: string) => {
  const arr = phoneNumber.split(" ");

  const countryCode = arr.shift()?.substring(1) || "";
  const number = arr.join("").replace(/[()-]/g, "");

  return { countryCode, number };
};
