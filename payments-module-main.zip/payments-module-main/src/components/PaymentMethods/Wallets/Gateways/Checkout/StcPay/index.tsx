export { default } from "./StcPay";
