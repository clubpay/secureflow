import { useEffect, useRef, useState } from "react";
import PaymentAPIManager from "@/api/gateways";
import Button from "@/components/Core/Button";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock, useToast, useTrace } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { STCPayLogo } from "@/icons";
import { t } from "@/locales";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { IStartSpanResponse } from "@clubpay/customer-common-module/src/hook/useSentryTrace";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import STCDrawer from "../../../components/Checkout/STCDrawer";
import { splitPhoneNumber } from "./StcPay.util";

export const StcPay = ({ variant = "primary", qlub, ...props }: PaymentOptions) => {
  const config = props.pg.config;
  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).moyasarV2;
  const gatewayId = props.pg.id;
  const traceRef = useRef<IStartSpanResponse | undefined>();
  const { lock, unlock } = useLockUnlock({ ...props, qlub });
  const { displayMessage } = useToast();

  const [phoneNumber, setPhoneNumber] = useState("");
  const [open, setOpen] = useState(false);
  const [stcPaymentId, setStcPaymentId] = useState("");
  const [transactionURL, setTransactionURL] = useState("");
  const [step, setStep] = useState<"mobile" | "otp">("mobile");
  const [loading, setLoading] = useState(false);

  const referenceRef = useRef<null | string>(null);

  const billMetaDataRef = useRef<any>(null);

  const { toggleVisibility, state, setAddPGMethod, removePGMethod, setPaymentMethodReference } = usePGGroupStore(
    (state) => state
  );

  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.STCPay });

  const toggleDrawer = () => setOpen(!open);

  const handleCloseDrawer = () => {
    setStep("mobile");
    setPhoneNumber("");
    setOpen(false);
  };

  const hasPgGroup = state.isPGGroupEnabled;

  const hasChoosen = isPaymethodChoosed({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.STCPay });

  const { onBeforePayment, onPaymentSuccess, onPaymentPending, onTraceClose } = config.events ?? {};

  const traceStart = useTrace(props.pg);

  billMetaDataRef.current = { tip: qlub?.tip ? qlub.tip.toFixed(2) : "0.00" };

  const event = {
    gatewayId,
    paymentElement: PaymentElementEnum.STCPay,
    tip: billMetaDataRef.current.tip
  };

  const handleConfirmPhoneNumber = async (value: string) => {
    referenceRef.current = getRandomString();
    setLoading(true);

    traceRef.current = traceStart?.startSpan({
      dataName: name,
      span: {
        element: PaymentElementEnum.STCPay,
        refId: referenceRef.current
      }
    });

    try {
      const onBeforeRes = await onBeforePayment(event);
      if (!onBeforeRes) return setLoading(false);

      const lockResponse = await lock(event);

      if (!lockResponse) {
        setLoading(false);
        return;
      }

      const { countryCode, number } = splitPhoneNumber(value);

      saveLastPayment();

      const response = await api.payByStcPay({
        id: getSession(),
        diningSessionID: qlub?.diningSessionId || "",
        tipAmount: billMetaDataRef.current.tip,
        reference: referenceRef.current as string,
        description: "",
        gatewayID: gatewayId,
        mobile: `0${number}`,
        cashier: ""
      });

      setStcPaymentId(response.data.id);
      setTransactionURL(response.data.source?.transaction_url ?? "");
      setPhoneNumber(value);
      setStep("otp");
      unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
    } catch (error) {
      displayMessage(t("The payment did not proceed Please try again"), "error", {
        autoHide: true
      });
      onTraceClose?.({
        error,
        location: "paymentCheckoutPayByStcPay",
        traceRef,
        traceStart
      });
      unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
    }

    setLoading(false);
  };

  const handleConfirmOtp = async (value: string) => {
    // referenceRef.current = getRandomString();
    setLoading(true);

    try {
      const response = await api.payBySTCPayCapture({
        id: getSession(),
        diningSessionID: qlub?.diningSessionId || "",
        tipAmount: billMetaDataRef.current.tip,
        reference: referenceRef.current as string,
        gatewayID: gatewayId,
        paymentId: stcPaymentId,
        otpValue: value,
        transactionURL,
        issuerCountry: "",
        funding: ""
      });

      if (config.extraConfig.saveStcPayPhoneNumber) {
        localStorage.setItem("qlub.stcpay_phone_number", phoneNumber);
      }
      setOpen(false);
      if (response.data.isPending) {
        onPaymentPending?.({
          refId: referenceRef.current as string,
          paymentElement: PaymentElementEnum.STCPay
        });
      } else {
        onPaymentSuccess?.({
          refId: referenceRef.current as string,
          paymentElement: PaymentElementEnum.STCPay
        });
      }
    } catch (error) {
      displayMessage(t("Payment did not proceed. Please check the details and retry."), "error", {
        autoHide: true
      });

      unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
      onTraceClose?.({
        error,
        location: "paymentCheckoutPayByStcPay",
        traceRef,
        traceStart
      });
    }
    setLoading(false);
  };

  const handlePay = () => {
    const run = () => {
      onBeforePayment(event);
      toggleDrawer();
    };

    if (config.events?.onPrePayment) config.events?.onPrePayment(run, "");
    else run();
  };

  const button = (
    <Button id="stc-pay-btn" variant={variant} onClick={handlePay} loading={loading}>
      {t("Pay with STC pay")}
    </Button>
  );

  const getStyles = () => {
    if (hasPgGroup) {
      return {
        display: "none"
      };
    }
    return {
      display: "block"
    };
  };

  useEffect(() => {
    setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.STCPay });
    return () => removePGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.STCPay });
  }, []);

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.STCPay,
      fn: handlePay
    });
  }, [props.amount]);

  return (
    <div>
      <div style={getStyles()}>{button}</div>
      {hasPgGroup && (
        <PGPaymentBox
          name={t("STC Pay")}
          icon={<STCPayLogo />}
          selected={hasChoosen}
          toggleVisibility={() => toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.STCPay })}
        />
      )}
      <STCDrawer
        open={open}
        onOpen={toggleDrawer}
        onClose={handleCloseDrawer}
        step={step}
        onConfirmOtp={handleConfirmOtp}
        onConfirmPhone={handleConfirmPhoneNumber}
        data={{
          loading,
          saveStcPayPhoneNumber: config.extraConfig.saveStcPayPhoneNumber ?? "",
          phoneNumber
        }}
      />
      {hasChoosen && <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{button}</ReactPortal>}
    </div>
  );
};

export default StcPay;
