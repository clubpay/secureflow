import React, { useEffect } from "react";
import PaymentAPIManager from "@/api/gateways";
import { Button } from "@/components/Core";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock, useSentry } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import Apple from "@/icons/Apple";
import KNET from "@/icons/KNET";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { MyFatoorahConfig } from "@/types/payments/config/myFatoorah";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { sumAmounts } from "@clubpay/customer-common-module/src/utility/k_math";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { Stack } from "@mui/material";
import { Span } from "@sentry/nextjs/types/client";

const KNetApplePay = (props: PaymentOptions) => {
  const { amount, qlub, pg, locale, country, totalAmount: totalByClient } = props;

  const gatewayId = pg.id;
  const gatewayName = pg.name;
  const config = pg.config as MyFatoorahConfig;
  const tipAmount = qlub?.tip;
  const billAmount = amount;
  const diningSessionId = qlub?.diningSessionId;
  const currencyCode = pg.vendor.country.currencyCode?.toUpperCase();

  const totalAmount = totalByClient ?? sumAmounts(qlub?.currencyPrecision || 0, billAmount || 0, tipAmount || 0);

  const { onBeforePayment, onPaymentPending, onPaymentFailure, onPrePayment } = config.events ?? {};
  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).myFatoorah;

  const {
    toggleVisibility,
    state: pgGroupState,
    setPaymentMethodReference,
    setAddPGMethod,
    removePGMethod
  } = usePGGroupStore((state) => state);

  const { startTrace, captureException } = useSentry(props);
  const { processing, setProcessing } = usePayment();
  const { getCallbackUrl } = useConfirmCallback();
  const { lock, unlock } = useLockUnlock(props);

  const hasPgGroup = pgGroupState.isPGGroupEnabled;

  const isSelected = isPaymethodChoosed({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.KNetApplePay });

  const { saveLastPayment } = usePaymentProfile({
    paymentOptions: props,
    paymentMethod: PaymentElementEnum.KNetApplePay
  });

  const {
    state: { consumer }
  } = useCommonStore((state: any) => state);

  const paymentCallBack = () => {
    startTrace("pay", PaymentElementEnum.KNetApplePay, async (span: Span) => {
      const refId = getRandomString();
      const event = {
        paymentElement: PaymentElementEnum.KNetApplePay,
        refId,
        traceId: span?.traceId
      };

      const returnUrl = getCallbackUrl({
        ref: refId,
        method: gatewayName,
        paymentElement: PaymentElementEnum.KNetApplePay,
        dsi: diningSessionId || "",
        amount: billAmount,
        currencySymbol: country,
        lang: locale || "",
        is3ds: true
      });
      try {
        setProcessing(true);
        const onBeforeResponse = await onBeforePayment({
          gatewayId,
          paymentElement: PaymentElementEnum.KNetApplePay,
          tip: tipAmount ?? 0
        });

        if (!onBeforeResponse) return;

        const lockResponse = await lock({
          paymentElement: PaymentElementEnum.KNetApplePay,
          refId,
          tip: tipAmount ?? 0
        });

        if (!lockResponse) return;

        saveLastPayment();

        try {
          const response = await api.payByKNetApple({
            id: getSession(),
            reference: refId,
            gatewayID: gatewayId,
            diningSessionID: diningSessionId,
            tipAmount: tipAmount ? tipAmount.toFixed(2) : "0.00",
            callBackUrl: returnUrl.pending,
            errorUrl: returnUrl.fail,
            currencyIso: currencyCode,
            annotations: {
              paymentMethod: PaymentElementEnum.KNetApplePay,
              funnel: consumer
            }
          });
          if (response.data.redirectUrl) {
            window.location.href = response.data.redirectUrl;
          }
        } catch (error: any) {
          if (!error?.data) {
            onPaymentPending(event);
          } else throw error;
        }
      } catch (error) {
        captureException(error);
        onPaymentFailure(event);
      } finally {
        setProcessing(false);
        unlock();
      }
    });
  };

  const handlePay = () => {
    if (onPrePayment) onPrePayment(paymentCallBack, PaymentElementEnum.KNetApplePay);
    else paymentCallBack();
  };

  const button = (
    <Button loading={processing} disabled={processing} onClick={handlePay}>
      {hasPgGroup ? t("Pay") : "Apple Pay Knet"}
    </Button>
  );

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.KNetApplePay,
      fn: paymentCallBack
    });
  }, [totalAmount]);

  useEffect(() => {
    setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.KNetApplePay });
    return () => removePGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.KNetApplePay });
  }, []);

  return (
    <div>
      <div
        style={{
          display: hasPgGroup ? "none" : "block"
        }}
      >
        {button}
      </div>
      {hasPgGroup && (
        <PGPaymentBox
          name="Apple Pay Knet"
          icon={
            <Stack spacing={1} direction="row" alignItems="center">
              <KNET />
              <Apple />
            </Stack>
          }
          selected={isSelected}
          toggleVisibility={() => toggleVisibility({ pgId: gatewayId, paymentMethod: PaymentElementEnum.KNetApplePay })}
        />
      )}
      {isSelected && <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{button}</ReactPortal>}
    </div>
  );
};

export default KNetApplePay;
