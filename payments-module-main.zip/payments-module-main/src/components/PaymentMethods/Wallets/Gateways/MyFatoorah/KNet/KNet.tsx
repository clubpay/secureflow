import { useEffect } from "react";
import PaymentAPIManager from "@/api/gateways";
import { Button } from "@/components/Core";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock, useSentry } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { usePgEvent } from "@/hooks/pg-events";
import { KNET as KNETIcon } from "@/icons";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";

export const KNet = (props: PaymentOptions) => {
  const { variant = "primary", amount, qlub, pg, country, locale } = props;
  const config = pg.config;
  const diningSessionId = qlub?.diningSessionId || "";
  const gatewayId = pg.id;
  const gatewayName = pg.name;
  const tipAmount = qlub?.tip;
  const currencyCode = pg.vendor.country.currencyCode?.toUpperCase();

  const { onBeforePayment, onPaymentFailure, onPrePayment } = config.events ?? {};
  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).myFatoorah;

  const { startTrace, captureException } = useSentry(props);
  const { processing, setProcessing } = usePayment();
  const { sendEvent } = usePgEvent({ paymentOptions: props, paymentMethod: PaymentElementEnum.KNET });
  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.KNET });
  const { lock, unlock } = useLockUnlock({ ...props, qlub });
  const { getCallbackUrl } = useConfirmCallback();

  const {
    toggleVisibility,
    state: pgGroupState,
    setAddPGMethod,
    setPaymentMethodReference
  } = usePGGroupStore((state) => state);
  const hasPgGroup = pgGroupState.isPGGroupEnabled;

  const {
    state: { consumer }
  } = useCommonStore((state: any) => state);

  const isSelected = isPaymethodChoosed({ pgId: gatewayId, paymentMethod: PaymentElementEnum.KNET });

  const paymentCallback = async () => {
    startTrace("pay", PaymentElementEnum.KNET, async () => {
      setProcessing(true);
      const reference = getRandomString();
      const event = {
        paymentElement: PaymentElementEnum.KNET,
        refId: reference
      };

      try {
        const returnUrl = getCallbackUrl({
          ref: reference,
          method: gatewayName,
          paymentElement: PaymentElementEnum.KNET,
          dsi: diningSessionId,
          currencySymbol: country,
          amount: amount,
          lang: locale
        });

        const onBeforeResponse = await onBeforePayment?.({
          gatewayId,
          paymentElement: PaymentElementEnum.KNET,
          tip: tipAmount ?? 0
        });
        if (!onBeforeResponse) return;

        const lockResponse = await lock(event);
        if (!lockResponse) return;

        saveLastPayment();
        const response = await api.payByKNet({
          id: getSession(),
          tipAmount: tipAmount?.toFixed(qlub?.currencyPrecision || 0) || "0.00",
          diningSessionID: diningSessionId,
          gatewayID: gatewayId,
          reference: reference,
          callBackUrl: returnUrl.success,
          failureUrl: returnUrl.fail,
          currencyIso: currencyCode,
          annotations: {
            paymentMethod: PaymentElementEnum.KNET,
            funnel: consumer
          }
        });

        if (response.data.redirectUrl) {
          sendEvent("payment_initialized", { status: "redirect" });
          window.location.href = response.data.redirectUrl;
        }
      } catch (error: any) {
        captureException(error);
        onPaymentFailure?.(event);
      } finally {
        setProcessing(false);
        unlock?.();
      }
    });
  };

  const handlePay = () => {
    if (onPrePayment) onPrePayment(paymentCallback, PaymentElementEnum.KNET);
    else paymentCallback();
  };

  const button = (
    <Button variant={variant} loading={processing} disabled={processing} onClick={handlePay}>
      {hasPgGroup ? t("Pay") : "KNET"}
    </Button>
  );

  const getStyles = () => {
    if (hasPgGroup) {
      return {
        display: "none"
      };
    }
    return {
      display: "block"
    };
  };

  useEffect(() => {
    setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.KNET });
  }, []);

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.KNET,
      fn: paymentCallback
    });
  }, [amount, tipAmount]);

  return (
    <div>
      <div style={getStyles()}>{button}</div>
      {hasPgGroup && (
        <PGPaymentBox
          name="KNET"
          icon={<KNETIcon />}
          selected={isSelected}
          toggleVisibility={() => toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.KNET })}
        />
      )}
      {isSelected && <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{button}</ReactPortal>}
    </div>
  );
};

export default KNet;
