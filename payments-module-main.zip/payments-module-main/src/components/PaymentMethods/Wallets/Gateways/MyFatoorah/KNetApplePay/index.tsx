export { default } from "./KNetApplePay";
