import { useEffect, useState } from "react";
import classNames from "classnames";
import PaymentAPIManager from "@/api/gateways";
import { Button } from "@/components/Core";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import PaymentContainer from "@/components/Global/PaymentContainer";
import ReactPortal from "@/components/Global/ReactPortal";
import withDelay from "@/components/HOC/withDelay";
import { useLockUnlock, useSentry } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { usePgEvent } from "@/hooks/pg-events";
import { DivitFpsNew } from "@/icons";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { DivitConfig } from "@/types/payments/config/divit";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { Typography } from "@qlub-dev/qlub-kit";
import styles from "./fps.module.scss";
import { banks } from "./utils";

const Fps = (props: PaymentOptions) => {
  const { variant = "primary", amount, qlub, pg, country, locale } = props;
  const config = pg.config as DivitConfig;
  const diningSessionId = qlub.diningSessionId!;
  const gatewayId = pg.id;
  const gatewayName = pg.name;
  const tipAmount = qlub?.tip;

  const { onBeforePayment, onPaymentFailure, onPrePayment } = config.events ?? {};
  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).divit;

  const [selectedBank, setSelectedBank] = useState("HSBC");

  const { startTrace, captureException } = useSentry(props);
  const { processing, setProcessing } = usePayment();
  const { sendEvent } = usePgEvent({ paymentOptions: props, paymentMethod: PaymentElementEnum.Fps });
  const { saveLastPayment } = usePaymentProfile({
    paymentOptions: props,
    paymentMethod: PaymentElementEnum.Fps
  });
  const { lock, unlock } = useLockUnlock({ ...props, qlub });
  const { getCallbackUrl } = useConfirmCallback();

  const {
    toggleVisibility,
    state: pgGroupState,
    setAddPGMethod,
    setPaymentMethodReference
  } = usePGGroupStore((state) => state);
  const isPgGroup = pgGroupState.isPGGroupEnabled;

  const {
    state: { consumer }
  } = useCommonStore((state: any) => state);

  const isSelected = isPaymethodChoosed({ pgId: gatewayId, paymentMethod: PaymentElementEnum.Fps });

  const paymentCallback = async () => {
    startTrace("pay", PaymentElementEnum.Fps, async () => {
      setProcessing(true);
      const reference = getRandomString();
      const event = {
        paymentElement: PaymentElementEnum.Fps,
        refId: reference
      };

      try {
        const returnUrl = getCallbackUrl({
          ref: reference,
          method: gatewayName,
          paymentElement: PaymentElementEnum.Fps,
          dsi: diningSessionId,
          currencySymbol: country,
          amount: amount,
          lang: locale
        });

        const onBeforeResponse = await onBeforePayment?.({
          gatewayId,
          paymentElement: PaymentElementEnum.Fps,
          tip: tipAmount ?? 0
        });
        if (!onBeforeResponse) return;

        const lockResponse = await lock(event);
        if (!lockResponse) return;

        saveLastPayment();
        const response = await api.payByFps({
          id: getSession(),
          tipAmount: tipAmount?.toFixed(qlub?.currencyPrecision || 0) || "0.00",
          diningSessionID: diningSessionId,
          gatewayID: gatewayId,
          reference: reference,
          failureUrl: returnUrl.fail,
          successUrl: returnUrl.success,
          pendingUrl: returnUrl.pending,
          annotations: {
            paymentMethod: PaymentElementEnum.Fps,
            funnel: consumer
          }
        });

        if (response.data.redirectUrl) {
          sendEvent("payment_initialized", { status: "redirect" });
          const hash = config.sandbox ? "#HKDDIVIT" : banks.find((bank) => bank.name === selectedBank)?.hash;
          window.location.href = response.data.redirectUrl + hash;
        }
      } catch (error: any) {
        captureException(error);
        onPaymentFailure?.(event);
      } finally {
        setProcessing(false);
        unlock?.();
      }
    });
  };

  const handlePay = () => {
    if (onPrePayment) onPrePayment(paymentCallback, PaymentElementEnum.Fps);
    else paymentCallback();
  };

  const button = (
    <Button variant={variant} loading={processing} disabled={processing} onClick={handlePay}>
      {t("Pay")}
    </Button>
  );

  useEffect(() => {
    setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.Fps });
  }, []);

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.Fps,
      fn: paymentCallback
    });
  }, [amount, tipAmount]);

  return (
    <div>
      {isPgGroup && (
        <PGPaymentBox
          name={t("Pay by Bank")}
          icon={<DivitFpsNew />}
          selected={isSelected}
          toggleVisibility={() => toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.Fps })}
        />
      )}
      <PaymentContainer selected={isSelected} pgGroup={isPgGroup}>
        <div className={styles.container}>
          {banks.map((bank) => (
            <button className={styles.item} onClick={() => setSelectedBank(bank.name)}>
              <div
                className={classNames(styles.icon, {
                  [styles.iconSelected]: selectedBank === bank.name
                })}
              >
                {bank.icon}
              </div>
              <Typography className={styles.name}>{bank.name}</Typography>
            </button>
          ))}
        </div>
        {!isPgGroup && button}
      </PaymentContainer>

      {isSelected && <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{button}</ReactPortal>}
    </div>
  );
};

export default withDelay(Fps, 500);
