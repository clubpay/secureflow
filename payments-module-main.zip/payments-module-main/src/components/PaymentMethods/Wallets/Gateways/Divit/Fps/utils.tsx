import { BEA, BOC, CitiHK, DBSHK, HSBC, HangSeng, SC, ZA } from "@/icons/DivitBanks";

export const banks = [
  {
    name: "HSBC",
    icon: <HSBC />,
    hash: "#HKDHSBC"
  },
  {
    name: "HangSeng",
    icon: <HangSeng />,
    hash: "#HKDHSB"
  },
  {
    name: "SC",
    icon: <SC />,
    hash: "#HKDSC"
  },
  {
    name: "CitiHK",
    icon: <CitiHK />,
    hash: "#HKDCITI"
  },
  {
    name: "BOC",
    icon: <BOC />,
    hash: "#HKDBOC"
  },
  {
    name: "ZA",
    icon: <ZA />,
    hash: "#HKDZA"
  },
  {
    name: "BEA",
    icon: <BEA />,
    hash: "#HKDBEA"
  },
  {
    name: "DBSHK",
    icon: <DBSHK />,
    hash: "#HKDDBS"
  }
];
