export { default, Pix } from "./Pix";
