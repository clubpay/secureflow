import { useEffect, useRef, useState } from "react";
import debounce from "lodash/debounce";
import PaymentAPIManager from "@/api/gateways";
import Button from "@/components/Core/Button";
import LoadingSpinner from "@/components/Global/LoadingSpinner";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import PaymentLoadingDialog from "@/components/Global/PaymentLoadingDialog";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock, useTrace } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import useCPFDrawer from "@/hooks/useCPFDrawer";
import PixIcon from "@/icons/Pix";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { ITunaPixPaymentResponse } from "@/types/api/tuna";
import Modal from "@clubpay/customer-common-module/src/component/Modal";
import { IStartSpanResponse } from "@clubpay/customer-common-module/src/hook/useSentryTrace";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { CircularProgress } from "@mui/material";
import styles from "./pix.module.scss";

interface TunaRetryData {
  startRetrying: number;
}

interface ApiCallData {
  processing: boolean;
  numOfTries: number;
}

export const Pix = ({ variant = "primary", qlub, ...props }: PaymentOptions) => {
  const config = props.pg.config;

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).tuna;
  const gatewayId = props.pg.id;
  const tipAmount = qlub?.tip || 0;

  const tunaDataRef = useRef({
    tunaSession: "",
    tunaCustomerId: ""
  });
  const referenceIdRef = useRef("");

  const { onBeforePayment, onPaymentSuccess, onPaymentPending, onTraceClose } = config.events ?? {};

  const traceStart = useTrace(props.pg);

  const { toggleVisibility, state, setAddPGMethod, removePGMethod, setPaymentMethodReference } = usePGGroupStore(
    (state) => state
  );

  const {
    state: { total }
  } = useCommonStore((store) => store);

  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.PixPay });

  const billMetaDataRef = useRef<any>(null);

  const tunaRetryDataRef = useRef<TunaRetryData>({ startRetrying: 0 });

  const apiCallDataRef = useRef<ApiCallData>({ processing: false, numOfTries: 0 });

  billMetaDataRef.current = { tip: qlub?.tip ? qlub.tip.toFixed(2) : "0.00" };

  const hasPgGroup = state.isPGGroupEnabled;

  const hasChoosen = isPaymethodChoosed({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.PixPay });

  const traceRef = useRef<IStartSpanResponse | undefined>();
  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const { setProcessing } = usePayment();

  const [pixOpen, setPixOpen] = useState(false);

  const [openSpinner, setOpenSpinner] = useState(false);

  const [loadingDialog, setLoadingDialog] = useState(false);

  const [pixLoading, setPixLoading] = useState(false);
  const pixParams = useRef<ITunaPixPaymentResponse | null>(null);
  const tunaInstanceRef = useRef<any>(null);

  const handleLoadQR = (res: ITunaPixPaymentResponse) => {
    const pixBoxOpts = {
      title: "",
      subtitle: "",
      copyCodeButtonText: "Copiar o código",
      showLoader: true,
      loaderText: "Aguardando pagamento…",
      instructions: [
        "Copie o código",
        'Opção PIX "Copia e cola" no aplicativo do seu banco',
        "Pague e retorne a esta página",
        "Seu pagamento deve ser confirmado em 1 minuto, é só esperar um pouquinho!"
      ],
      methodID: res.methodID,
      pixInfo: {
        qrImage: res.qrImage.includes("https") ? res.qrImage : `data:image/png;base64,${res.qrImage}`,
        qrContent: res.qrContent
      },
      paymentKey: res.paymentKey
    };

    pixParams.current = res;

    const tunaInstance = window?.Tuna(tunaDataRef.current.tunaSession);

    if (!tunaInstance) {
      alert("Tuna instance is not set");
    }

    tunaInstance.useQrCodePayment("#pixRoot", pixBoxOpts, (result: any) => {
      if (result.paymentApproved) {
        console.log("from qrcode");
        verifyPixPayment();
      }
    });
  };

  const verifyPixPayment = async () => {
    try {
      apiCallDataRef.current.processing = true;

      const response = await api.verifyPix({
        gatewayID: gatewayId,
        diningSessionID: qlub?.diningSessionId || "",
        reference: referenceIdRef.current,
        id: getSession()
      });

      if (response.data.success) {
        onPaymentSuccess?.({
          paymentElement: PaymentElementEnum.PixPay,
          refId: referenceIdRef.current,
          traceId: traceStart?.traceId
        });
        apiCallDataRef.current.processing = false;
      } else {
        apiCallDataRef.current.processing = false;

        onTraceClose?.({
          error: response,
          location: "tunaVerifyFix.pending",
          traceRef,
          traceStart
        });
        onPaymentPending?.({
          paymentElement: PaymentElementEnum.PixPay,
          refId: referenceIdRef.current,
          traceId: traceStart?.traceId
        });
      }
    } catch (e) {
      console.log("exception", e);
      unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
      apiCallDataRef.current.processing = false;
    }
  };

  const handlePixPayment = async () => {
    const event = {
      paymentElement: PaymentElementEnum.CardPay,
      refId: referenceIdRef.current as string,
      traceId: traceStart?.traceId
    };

    try {
      setPixLoading(true);
      traceRef.current = traceStart?.startSpan({
        dataName: "pix",
        span: {
          element: PaymentElementEnum.PixPay,
          refId: referenceIdRef.current
        }
      });

      saveLastPayment();
      const response = await api.pixPayment({
        gatewayID: gatewayId,
        diningSessionID: qlub?.diningSessionId || "",
        reference: referenceIdRef.current,
        id: getSession(),
        tipAmount: billMetaDataRef.current.tip,
        method: "D",
        sessionToken: tunaDataRef.current.tunaSession,
        ...additionalData
      });

      if (response.data) {
        handleLoadQR(response.data);

        const onBeforeRes = await onBeforePayment?.({
          gatewayId,
          paymentElement: PaymentElementEnum.PixPay,
          tip: billMetaDataRef.current.tip
        });

        if (!onBeforeRes) {
          setProcessing(false);
          setPixLoading(false);
          setPixOpen(false);
          return;
        }

        const lockResponse = await lock(event);

        if (!lockResponse) {
          setProcessing(false);
          setPixLoading(false);
          setPixOpen(false);
          return;
        }

        tunaRetryDataRef.current.startRetrying = 1;
      }
    } catch (e) {
      console.log("exeception", e);
      setPixOpen(false);
      unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
    }
  };

  const openPixHandler = async () => {
    try {
      setOpenSpinner(true);
      await getTunaSession();
      setOpenSpinner(false);
      setPixOpen(true);
      handlePixPayment();
    } catch (e: any) {
      console.log("error", e);
      setOpenSpinner(false);
    }
  };

  const localSubmit = () => {
    openCPFDrawer();
  };

  const handleInitPix = () => {
    if (props.pg.config.events?.onPrePayment)
      props.pg.config.events?.onPrePayment(localSubmit, PaymentElementEnum.PixPay);
    else {
      localSubmit();
    }
  };

  const closeHandler = () => {
    setPixOpen(false);
    unlock?.({ gatewayId, diningSessionID: qlub?.diningSessionId });
  };

  const getTunaSession = async () => {
    referenceIdRef.current = getRandomString();
    tunaRetryDataRef.current.startRetrying = 0;

    const response = await api.session({
      gatewayID: gatewayId,
      reference: referenceIdRef.current,
      diningSessionID: qlub?.diningSessionId || "",
      id: getSession()
    });

    if (response) {
      tunaDataRef.current.tunaSession = response.data.sessionToken;
      tunaDataRef.current.tunaCustomerId = response.data.customerID;
      tunaInstanceRef.current = window?.Tuna?.(tunaDataRef.current.tunaSession);
    }
  };

  const debouncedInitPix = debounce(async () => {
    handleInitPix();
  }, 500);

  const button = (
    <Button id="pix-pay-btn" variant={variant} onClick={debouncedInitPix}>
      {t("Pay")}
    </Button>
  );

  const getStyles = () => {
    if (hasPgGroup) {
      return {
        display: "none"
      };
    }
    return {
      display: "block"
    };
  };

  const handleTunaPolling = () => {
    console.log("pixParams.current?.methodID", pixParams.current?.methodID);

    console.log("pixParams.current?.paymentKey", pixParams.current?.paymentKey);

    if (typeof pixParams.current?.methodID !== "undefined" && pixParams.current?.paymentKey) {
      console.log("polling started");
      tunaInstanceRef.current?.doStatusLongPolling(
        (result: any) => {
          if (result.paymentApproved) {
            console.log("status poling activated");
            verifyPixPayment();
          }
        },
        pixParams.current.methodID,
        pixParams.current.paymentKey
      );
    }
  };

  const { DrawerElement, openCPFDrawer, additionalData } = useCPFDrawer({
    paymentCB: openPixHandler,
    enabled: props.pg.config.extraConfig.enableDocumentCollection
  });

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.PixPay,
      fn: debouncedInitPix
    });
  }, [total, tipAmount]);

  useEffect(() => {
    setAddPGMethod({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.PixPay });
    return () => removePGMethod({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.PixPay });
  }, []);

  useEffect(() => {
    const focusHandler = () => {
      if (tunaRetryDataRef.current.startRetrying > 0) {
        console.log("startRetrying ", tunaRetryDataRef.current.startRetrying);
        console.log("calling handleTunaPolling");

        handleTunaPolling();
        props.pg.config.extraConfig?.enablePixPopup && setLoadingDialog(true);
      }
    };

    window.addEventListener("focus", focusHandler);
    return () => {
      window.removeEventListener("focus", focusHandler);
    };
  }, []);

  return (
    <div>
      {DrawerElement}
      <PaymentLoadingDialog open={loadingDialog} />
      <LoadingSpinner open={openSpinner} />
      <div style={getStyles()}>{button}</div>
      {hasPgGroup && (
        <PGPaymentBox
          name={t("Pix")}
          icon={<PixIcon />}
          selected={hasChoosen}
          toggleVisibility={() => toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.PixPay })}
        />
      )}
      <Modal
        sx={{ zIndex: 100000001 }}
        open={pixOpen}
        openHandler={handleInitPix}
        closeHandler={closeHandler}
        noPadding
        key={tunaDataRef.current.tunaSession}
      >
        {pixLoading && (
          <div className={styles.modalLoading}>
            <CircularProgress size={24} />
          </div>
        )}
        <div className={styles.pixContainer}>
          <div id="pixRoot" />
        </div>
      </Modal>
      {hasChoosen && <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{button}</ReactPortal>}
    </div>
  );
};

export default Pix;
