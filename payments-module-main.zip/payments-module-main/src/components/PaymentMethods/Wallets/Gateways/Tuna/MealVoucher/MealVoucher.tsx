import { useCallback, useEffect, useRef, useState } from "react";
import { chunk } from "lodash";
import PaymentAPIManager from "@/api/gateways";
import { default as Input } from "@/components/Core/Input";
import { parseExpirationDate } from "@/components/PaymentMethods/Card/Gateways/Tuna/Tuna.util";
import { validateCardNumber, validateFormState } from "@/components/PaymentMethods/Card/Gateways/Tuna/Tuna.util";
import CardLayout from "@/components/PaymentMethods/Card/Layout/layout";
import SavedCard from "@/components/PaymentMethods/Card/components/common/SavedCard";
import { useLockUnlock, useToast, useTrace } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import useCPFDrawer from "@/hooks/useCPFDrawer";
import { Pluxee } from "@/icons";
import MealVoucherIcon from "@/icons/MealVoucher";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { getSelectedCard, hasSavedCardClicked, useCardStore } from "@/stores/cardStore";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { ICard, formatMaskedCard, validateExpiryDate } from "@/utils";
import { SodexoLogoIcon, VRLogoIcon } from "@clubpay/customer-common-module/src/component/SVG";
import { IStartSpanResponse } from "@clubpay/customer-common-module/src/hook/useSentryTrace";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { getCardMealVoucherType, isCardMealVoucher } from "./MealVoucher.util";

export const MealVoucher = ({ variant = "primary", amount = 2, currency = "AED", qlub, ...props }: PaymentOptions) => {
  const [formState, setFormState] = useState<any>({});
  const [cpf, setCpf] = useState("");
  const tunaDataRef = useRef({
    tunaSession: "",
    tunaCustomerId: ""
  });

  const { lock: lockUI } = useCommonStore((store) => store);

  const pgSignature = `${props.pg.id}-${PaymentElementEnum.MealVoucherPay}`;

  const [saveCardCvv, setSaveCardCvv] = useState<Record<string, string>>({});

  const tunaInstanceRef = useRef(null);

  const ranRef = useRef(false);

  const referenceIdRef = useRef("");

  const formStateRef = useRef<any>({});

  const config = props.pg.config;

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).tuna;
  const gatewayId = props.pg.id;
  const gatewayName = props.pg.name;

  const { state } = usePGGroupStore((state) => state);

  const hasPgGroup = state.isPGGroupEnabled;

  const isSavedCard = hasSavedCardClicked(pgSignature);

  const tipAmount = qlub?.tip || 0;

  const enableDocumentCollection = props.pg.config.extraConfig.enableDocumentCollection;

  const { onBeforePayment, onPaymentSuccess, onPaymentFailure, onTraceClose } = config.events ?? {};

  const traceStart = useTrace(props.pg);

  const { lock } = useLockUnlock({ ...props, qlub });

  const traceRef = useRef<IStartSpanResponse | undefined>();

  const { setProcessing } = usePayment();

  const { displayMessage } = useToast();

  const { saveLastPayment } = usePaymentProfile({
    paymentOptions: props,
    paymentMethod: PaymentElementEnum.MealVoucherPay
  });

  const {
    state: cardStore,
    setCardList,
    setSelectedCard,
    setNewCardData,
    setDiselectNewCardData,
    removeCard
  } = useCardStore((store) => store);

  const selectedCard = getSelectedCard(pgSignature);

  const hasChoosen = isPaymethodChoosed({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.MealVoucherPay });

  const handleUpdateFormState = (key: string, value: string) => {
    if (key === "card") {
      if (value?.length >= 20) return;
      const inputNumber = value.replace(/\D/g, "");
      const formattedNumber = inputNumber.replace(/(\d{4})(?=\d)/g, "$1 ");

      setFormState((prevState: any) => ({ ...prevState, [key]: formattedNumber }));
    } else if (key === "expiry") {
      const inputMonth = value.replace(/\D/g, "");
      const formattedMonth = inputMonth.slice(0, 4).replace(/(\d{2})(?=\d)/, "$1/");
      setFormState((prevState: any) => ({ ...prevState, [key]: formattedMonth }));
    } else if (key === "name") {
      setFormState((prevState: any) => ({ ...prevState, [key]: value }));
    } else {
      const ammexRegex = /^3[47][0-9]{13}$/;
      const condition = ammexRegex.test(formState.card?.replace(/\s/g, "")) ? value?.length >= 5 : value?.length >= 4;
      if (condition) return;
      setFormState((prevState: any) => ({ ...prevState, [key]: value }));
    }
  };

  const getEventSuffix = () => {
    return Boolean(selectedCard) ? "saved" : "";
  };

  const getTunaSession = async () => {
    referenceIdRef.current = getRandomString();

    const response = await api.session({
      gatewayID: gatewayId,
      reference: referenceIdRef.current,
      diningSessionID: qlub?.diningSessionId || "",
      id: getSession()
    });

    if (response) {
      tunaDataRef.current.tunaSession = response.data.sessionToken;
      tunaDataRef.current.tunaCustomerId = response.data.customerID;
      tunaInstanceRef.current = window?.Tuna(tunaDataRef.current.tunaSession);
    }
    handleGetSavedCards();
  };

  const handleSelectCard = (token: string) => setSelectedCard(pgSignature, token);

  const handleGetSavedCards = async () => {
    const tunaInstance: any = tunaInstanceRef.current;
    const tokenizer = await tunaInstance?.tokenizator();
    const list = await tokenizer?.list();

    if (!list.tokens.length) return;

    const fetchedCards = list.tokens
      .filter((card: ICard) => isCardMealVoucher(card.bin))
      .map((card: ICard) => {
        return {
          ...card,
          maskedNumber: formatMaskedCard(card.maskedNumber),
          brand: getCardMealVoucherType(card.bin)
        };
      });
    setCardList({
      name: pgSignature,
      list: fetchedCards
    });
    setDiselectNewCardData(pgSignature);
  };

  const removeCardHandler = async (card: any) => {
    removeCard(pgSignature, card.token);

    const tunaInstance: any = tunaInstanceRef.current;
    try {
      const tokenizer = await tunaInstance?.tokenizator();
      tokenizer?.delete(card.token);

      displayMessage(t("Your card details archived."), "info");
    } catch {}
  };

  const getIcons = () => [
    <div
      style={{
        backgroundColor: "white",
        width: "32px",
        height: "26px",
        padding: "2px",
        borderRadius: "5px"
      }}
    >
      <SodexoLogoIcon width="100%" height="100%" />
    </div>,
    <VRLogoIcon />,
    <Pluxee />
  ];

  const renderSavedCard = () => {
    const savedCards = cardStore.savedCardsData.get(pgSignature)?.cardsList;

    if (!savedCards || !Boolean(savedCards) || !savedCards?.length) return null;

    if (!hasPgGroup || hasChoosen) {
      return (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            rowGap: "1rem"
          }}
        >
          {savedCards?.map((card: ICard) => (
            <SavedCard
              manualCVV
              selected={card.selected}
              cvv={saveCardCvv[card.token]}
              disableEdit
              maskedNumber={card.maskedNumber}
              brand={card.brand?.toLocaleLowerCase()}
              onSelect={() => {
                setDiselectNewCardData(pgSignature);
                handleSelectCard(card.token);
              }}
              onChangeClick={() => {
                setDiselectNewCardData(pgSignature);
                handleSelectCard(card.token);
              }}
              onUnsaveClick={() => {
                removeCardHandler(card);
              }}
              onCVVChange={(ev: any) => {
                const text = ev.target.value;
                const condition = ["amex"].includes((card.brand ?? "").toLowerCase())
                  ? text?.length > 4
                  : text?.length > 3;

                if (condition) return;
                setSaveCardCvv((prevState) => ({
                  ...prevState,
                  [card.token]: text
                }));
              }}
              slots={[
                <div
                  style={{
                    margin: "10px 0"
                  }}
                >
                  <div
                    style={{
                      marginBottom: "10px",
                      fontSize: "14px"
                    }}
                  >
                    CPF
                  </div>
                  <Input
                    value={cpf}
                    style={{ height: "36px", fontSize: "12px" }}
                    placeholder="000.000.000-00"
                    onChange={handleCPFChange}
                  />
                </div>
              ]}
            />
          ))}
        </div>
      );
    }

    return null;
  };

  const card = useCallback(
    (props: any) => (
      <Input
        forceLTR
        value={formState?.["card"] || ""}
        onChange={(e: any) => {
          const value = e.target.value;
          const regex = /^[0-9 ]*$/;
          const found = regex.test(value);
          found && handleUpdateFormState("card", value);
        }}
        {...props}
      />
    ),
    [formState]
  );

  const expiry = useCallback(
    (props: any) => (
      <Input
        forceLTR
        value={formState?.["expiry"] || ""}
        {...props}
        onChange={(e: any) => {
          const value = e.target.value;
          if (value.length > 5) return;
          const regex = /^[0-9/]*$/;
          const found = regex.test(value);

          found && handleUpdateFormState("expiry", e.target.value);
        }}
      />
    ),
    [formState]
  );

  const cvv = useCallback(
    (props: any) => (
      <Input
        forceLTR
        value={formState?.["cvv"] || ""}
        {...props}
        onChange={(e: any) => {
          const value = e.target.value;
          const regex = /^[0-9/]*$/;
          const found = regex.test(value);
          found && handleUpdateFormState("cvv", value);
        }}
      />
    ),
    [formState]
  );

  const name = useCallback(
    (props: any) => (
      <Input
        forceLTR
        value={formState?.["name"] || ""}
        {...props}
        onChange={(e: any) => {
          const value = e.target.value;
          if (value !== "") {
            const regex = /^[a-zA-Z ]+$/;
            const found = regex.test(value);
            found && handleUpdateFormState("name", value);
            return;
          }
          handleUpdateFormState("name", "");
        }}
      />
    ),
    [formState]
  );

  const performValidation = () => {
    if (!selectedCard) {
      const status = validateFormState({
        name: formStateRef.current?.name || "",
        card: formStateRef.current?.card || "",
        cvv: formStateRef.current?.cvv || "",
        expiry: formStateRef.current?.expiry || ""
      });

      if (status) {
        displayMessage(t(status));
        return true;
      }

      const cardNoStatus = validateCardNumber(formStateRef.current?.card, formStateRef.current?.cvv);

      if (cardNoStatus) {
        displayMessage(t(cardNoStatus));
        return true;
      }

      const expiryDateStatus = validateExpiryDate(formStateRef.current?.expiry);
      if (expiryDateStatus) {
        displayMessage(t(expiryDateStatus));
        return true;
      }

      if (enableDocumentCollection) return false;

      if (!cpf.length) {
        displayMessage(t("CPF number is invalid. Please check the details and retry."));
        return true;
      }
      return false;
    } else {
      const status = validateFormState({
        cpf: cpf || ""
      });

      if (enableDocumentCollection) return false;

      if (status) {
        displayMessage(t(status));
        return true;
      }
      return false;
    }
  };

  const handleSubmit = async (ev: any) => {
    const event = {
      paymentElement: PaymentElementEnum.CardPay,
      refId: referenceIdRef.current as string,
      traceId: traceStart?.traceId,
      meta: {
        gaEventSuffix: getEventSuffix()
      }
    };

    const status = performValidation();

    if (status) return;

    lockUI(14000);

    traceRef.current = traceStart?.startSpan({
      dataName: gatewayName ?? "anonymous",
      span: {
        element: PaymentElementEnum.CardPay,
        refId: referenceIdRef.current
      }
    });

    const additionalParameters = {
      method: "F",
      document: cpf,
      documentType: "CPF"
    };

    setProcessing(true);

    try {
      const onBeforeRes = await onBeforePayment?.({
        gatewayId,
        paymentElement: PaymentElementEnum.CardPay,
        tip: qlub?.tip ?? 0
      });

      if (!onBeforeRes) {
        setProcessing(false);
        return;
      }

      const lockResponse = await lock(event);

      if (!lockResponse) {
        setProcessing(false);
        return;
      }

      const tunaInstance: any = tunaInstanceRef.current;

      let response: any;
      if (selectedCard) {
        const cvv = saveCardCvv[selectedCard.token];

        const tz = await tunaInstance?.tokenizator();

        if (!tz) {
          setProcessing(false);
          return;
        }

        await tz.bind(selectedCard.token, cvv);

        response = {
          cardData: {
            cardHolderName: selectedCard.cardHolderName,
            cardNumber: selectedCard.bin,
            expirationMonth: Number(selectedCard.expirationMonth),
            expirationYear: Number(selectedCard.expirationYear),
            cvv,
            singleUse: false
          },
          tokenData: {
            token: selectedCard.token,
            brand: selectedCard.brand
          },
          success: true
        };
      } else {
        const { expMonth, expYear } = parseExpirationDate(formStateRef.current.expiry);
        const cardNo = formStateRef.current.card?.replace(/\D/g, "");
        const cvv = formStateRef.current.cvv;
        const customerName = formStateRef.current.name;

        response = await tunaInstance?.getCheckoutData({
          cardHolderName: customerName,
          cardNumber: cardNo,
          expirationMonth: Number(expMonth),
          expirationYear: Number(expYear),
          cvv: cvv,
          singleUse: !isSavedCard,
          customer: {
            ...(cpf ? { cpf } : {}),
            iD: tunaDataRef.current.tunaCustomerId
          }
        });
      }

      if (response?.success) {
        saveLastPayment({ isSavedCard: selectedCard, cardBrand: response.tokenData.brand });
        const payRes = await api.cardPayment({
          gatewayID: gatewayId,
          diningSessionID: qlub?.diningSessionId || "",
          reference: referenceIdRef.current,
          id: getSession(),
          tipAmount: tipAmount.toString(),
          cardToken: response.tokenData.token,
          sessionToken: tunaDataRef.current.tunaSession,
          cardExpireMonth: response.cardData.expirationMonth,
          cardExpiryYear: response.cardData.expirationYear,
          cardHolderName: response.cardData.cardHolderName,
          tokenSingleUse: response.cardData.singleUse || true,
          cardBrand: response.tokenData.brand,
          cardBin: response.tokenData.bin,
          ...additionalParameters,
          ...additionalData
        });
        if (payRes.data.success) {
          onPaymentSuccess?.(event);
        } else {
          onPaymentFailure?.(event);
        }
      } else {
        onPaymentFailure?.(event);
      }
    } catch (e) {
      onTraceClose?.({
        error: e,
        location: "tuna.payment",
        traceRef,
        traceStart
      });
    } finally {
      setProcessing(false);
    }
  };

  const handleCPFChange = (event: Event): void => {
    const inputElement = event.target as HTMLInputElement;
    const inputValue = inputElement.value;

    const numericInput = inputValue.replace(/\D/g, "");

    const chunks = chunk(numericInput, 3);
    let formattedInput = null;
    if (chunks.length > 3) {
      const headChunck = chunks.slice(0, 3);
      const tailChunck = chunks.slice(-1);

      const p1 = headChunck.map((subChunk: any[]) => subChunk.join("")).join(".");
      const p2 = tailChunck.map((subChunk: any[]) => subChunk.join("")).join("");
      formattedInput = `${p1}-${p2}`;
    } else {
      formattedInput = chunks.map((subChunk: any[]) => subChunk.join("")).join(".");
    }

    setCpf(formattedInput.slice(0, 14));
  };

  const handleAddCard = (force?: boolean) => {
    handleSelectCard("");
    setNewCardData(pgSignature, force);
  };

  const handleOnPGPaymentBoxClick = () => {
    if (selectedCard || cardStore.savedCardsData.get(pgSignature)?.cardsList) return;

    handleAddCard(true);
  };

  const { DrawerElement, openCPFDrawer, additionalData } = useCPFDrawer({
    paymentCB: handleSubmit,
    cpfRequired: true,
    enabled: enableDocumentCollection,
    content: {
      title: t("Input Data to Process Payment"),
      subtitle: t("CPF/CNPJ")
    }
  });

  const handleLocalSubmit = () => {
    openCPFDrawer();
  };

  useEffect(() => {
    formStateRef.current = formState;
  }, [formState]);

  useEffect(() => {
    if (state.pgGroupInteractionData.currentSelected === pgSignature && !ranRef.current) {
      ranRef.current = true;
      handleOnPGPaymentBoxClick();
    }
  }, [state.pgGroupInteractionData.currentSelected]);

  useEffect(() => {
    getTunaSession();
  }, []);

  return (
    <>
      <div>
        {DrawerElement}
        <CardLayout
          elements={{ card, expiry, cvv, name }}
          onSubmit={handleLocalSubmit as any}
          variant={variant}
          amount={amount}
          currency={currency}
          qlub={qlub}
          {...props}
          icons={getIcons()}
          enableCardSaving={!config?.extraConfig?.disableSavedCard}
          api={{
            cardStorage: { fetchSavedCards: () => {} }
          }}
          isAdding={cardStore.newCardsData?.get(pgSignature)?.hasAdded}
          onAddCard={handleAddCard}
          addCardText={t("Add Meal Card")}
          slots={
            !enableDocumentCollection && [
              <div
                style={{
                  margin: "10px 0"
                }}
              >
                <div
                  style={{
                    marginBottom: "10px",
                    fontSize: "14px"
                  }}
                >
                  CPF
                </div>
                <Input
                  value={cpf}
                  style={{ height: "36px", fontSize: "12px" }}
                  placeholder="000.000.000-00"
                  onChange={handleCPFChange}
                />
              </div>
            ]
          }
          savedCardSlot={renderSavedCard()}
          paymentMethodData={{
            element: PaymentElementEnum.MealVoucherPay,
            name: t("Meal Voucher"),
            icon: <MealVoucherIcon />
          }}
          shouldPayBtnEnable={() => {
            if (selectedCard) return saveCardCvv[selectedCard.token]?.length >= 3;
            return Boolean(cardStore.newCardsData?.get(pgSignature)?.hasAdded);
          }}
        />
      </div>
    </>
  );
};

export default MealVoucher;
