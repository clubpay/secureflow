import TunaCloak from "@/components/GatewayCloaks/TunaCloak";
import { PaymentOptions } from "@/types";
import MealVoucher from "./MealVoucher";

export default function (props: PaymentOptions) {
  return (
    <TunaCloak>
      <MealVoucher {...props} />
    </TunaCloak>
  );
}
