export const isValidCPF = (cpf: string): boolean => {
  const cleanedCPF = cpf.replace(/\D/g, "");

  if (cleanedCPF.length !== 11) {
    return false;
  }

  if (/^(\d)\1{10}$/.test(cleanedCPF)) {
    return false;
  }

  let sum = 0;
  for (let i = 0; i < 9; i++) {
    sum += parseInt(cleanedCPF.charAt(i)) * (10 - i);
  }
  let remainder = sum % 11;
  let digit = remainder < 2 ? 0 : 11 - remainder;

  if (parseInt(cleanedCPF.charAt(9)) !== digit) {
    return false;
  }

  sum = 0;
  for (let i = 0; i < 10; i++) {
    sum += parseInt(cleanedCPF.charAt(i)) * (11 - i);
  }
  remainder = sum % 11;
  digit = remainder < 2 ? 0 : 11 - remainder;

  if (parseInt(cleanedCPF.charAt(10)) !== digit) {
    return false;
  }

  return true;
};

const list = {
  vr: ["637036", "637201", "627416", "637202"],
  sodexo: ["606071", "603389", "606068", "606069"]
};

export const isCardMealVoucher = (bin: string): boolean => {
  return [...list.vr, ...list.sodexo].includes(bin);
};

export const getCardMealVoucherType = (bin: string) => {
  if (list.vr.includes(bin)) {
    return "vr";
  }
  if (list.sodexo.includes(bin)) {
    return "sodexo";
  }
  return "unknown";
};
