import { useEffect, useRef } from "react";
import PaymentAPIManager from "@/api/gateways";
import BillAPIManager from "@/api/general/bill";
import { Button } from "@/components/Core";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock, useScreenSize } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { usePgEvent } from "@/hooks/pg-events";
import UnionPayIcon from "@/icons/UnionPay";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";

export const UnionPay = (props: PaymentOptions) => {
  const { variant = "primary", amount, qlub, pg, country, locale } = props;
  const config = pg.config;
  const diningSessionId = qlub?.diningSessionId || "";
  const gatewayId = pg.id;
  const gatewayName = pg.name;
  const tipAmount = qlub?.tip;
  const billAmount = amount;
  const { onBeforePayment, onPaymentFailure, onPrePayment, onPaymentSuccess } = config.events ?? {};
  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).ngenius;

  const { processing, setProcessing } = usePayment();

  const enablePopupForNIRedirection = pg.vendor?.config?.enablePopupForNIRedirection;

  console.log("Rest config", enablePopupForNIRedirection);

  const dims = useScreenSize();

  const { sendEvent } = usePgEvent({ paymentOptions: props, paymentMethod: PaymentElementEnum.UnionPay });

  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });

  const {
    toggleVisibility,
    state: pgGroupState,
    setAddPGMethod,
    removePGMethod,
    setPaymentMethodReference
  } = usePGGroupStore((state) => state);
  const hasPgGroup = pgGroupState.isPGGroupEnabled;

  const generalAPI = BillAPIManager.getInstance();

  const { lock, unlock } = useLockUnlock({ ...props, qlub });

  const { getCallbackUrl } = useConfirmCallback();

  const intervalRef = useRef<any>(null);

  const {
    state: { consumer }
  } = useCommonStore((state: any) => state);

  const isSelected = isPaymethodChoosed({ pgId: gatewayId, paymentMethod: PaymentElementEnum.UnionPay });

  const paymentCallBack = async () => {
    setProcessing(true);
    const reference = getRandomString();
    const event = {
      paymentElement: PaymentElementEnum.UnionPay,
      refId: reference
    };

    try {
      const returnUrl = getCallbackUrl({
        ref: reference,
        method: gatewayName,
        paymentElement: PaymentElementEnum.UnionPay,
        dsi: diningSessionId,
        currencySymbol: country,
        amount: amount,
        lang: locale
      });

      const onBeforeResponse = await onBeforePayment?.({
        gatewayId,
        paymentElement: PaymentElementEnum.UnionPay,
        tip: tipAmount ?? 0
      });
      if (!onBeforeResponse) return;

      const lockResponse = await lock(event);
      if (!lockResponse) return;

      const response = await api.payByUnionPay({
        id: getSession(),
        tipAmount: tipAmount?.toFixed(qlub?.currencyPrecision || 0) || "0.00",
        diningSessionID: diningSessionId,
        gatewayID: gatewayId,
        reference: reference,
        redirectUrl: returnUrl.pending,
        annotations: {
          paymentMethod: PaymentElementEnum.UnionPay,
          funnel: consumer
        }
      });

      saveLastPayment({ paymentMethod: PaymentElementEnum.UnionPay });

      if (response.data.redirectUrl) {
        sendEvent("payment_initialized", { status: "redirect" });

        if (enablePopupForNIRedirection) {
          const win = window?.open(response.data.redirectUrl, "", `width=${dims.width},height=${dims.height}`);

          if (intervalRef.current) clearTimeout(intervalRef.current);

          intervalRef.current = setInterval(() => {
            generalAPI
              .getStatus({
                reference: reference,
                diningSessionID: diningSessionId || "",
                id: getSession()
              })
              .then((res) => {
                if (res.data.billStatus === "fullyPaid" || res.data.billStatus !== "unpaid") {
                  win?.close();
                  onPaymentSuccess(event);
                  clearTimeout(intervalRef.current);
                }
              });
          }, 8000);

          if (!win || typeof win.closed === "undefined") {
            window.location.href = response.data.redirectUrl;
          }
        } else {
          window.location.href = response.data.redirectUrl;
        }
      }
    } catch (error: any) {
      onPaymentFailure?.(event);
    } finally {
      setProcessing(false);
      unlock?.();
    }
  };

  const handlePay = () => {
    if (onPrePayment) onPrePayment(paymentCallBack, PaymentElementEnum.UnionPay);
    else paymentCallBack();
  };

  const button = (
    <Button variant={variant} loading={processing} disabled={processing} onClick={handlePay}>
      {hasPgGroup ? t("Pay") : "UnionPay"}
    </Button>
  );

  const getStyles = () => {
    if (hasPgGroup) {
      return {
        display: "none"
      };
    }
    return {
      display: "block"
    };
  };

  useEffect(() => {
    setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.UnionPay });
    return () => removePGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.UnionPay });
  }, []);

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.UnionPay,
      fn: paymentCallBack
    });
  }, [billAmount, tipAmount]);

  return (
    <div>
      <div style={getStyles()}>{button}</div>

      {hasPgGroup && (
        <PGPaymentBox
          name="UnionPay"
          icon={<UnionPayIcon />}
          selected={isSelected}
          toggleVisibility={() => toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.UnionPay })}
        />
      )}
      {isSelected && <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{button}</ReactPortal>}
    </div>
  );
};

export default UnionPay;
