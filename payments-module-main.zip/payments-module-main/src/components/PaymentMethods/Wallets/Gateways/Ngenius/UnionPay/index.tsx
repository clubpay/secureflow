export { default } from "./UnionPay";
