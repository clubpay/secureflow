import { t } from "@/locales";
import { SwipeableCustomerDrawer } from "@qlub-dev/qlub-kit";
import STCMobileNumber from "../STCMobileNumber";
import STCOtp from "../STCOtp";

const STCDrawer = ({ open, onOpen, onClose, step, onConfirmOtp, onConfirmPhone, sandbox, data }: any) => {
  const { loading, phoneNumber, saveStcPayPhoneNumber } = data;

  const renderContent = () => {
    switch (step) {
      case "mobile":
        return (
          <STCMobileNumber
            loading={loading}
            saveStcPayPhoneNumber={saveStcPayPhoneNumber}
            sandbox={sandbox}
            onConfirm={onConfirmPhone}
          />
        );
      case "otp":
        return <STCOtp loading={loading} phoneNumber={phoneNumber} onConfirm={onConfirmOtp} />;
      default:
        return <div></div>;
    }
  };

  return (
    <>
      <SwipeableCustomerDrawer
        open={open}
        headerTitle={t(step === "mobile" ? "Enter phone number" : "Enter OTP")}
        onClose={onClose}
        onOpen={onOpen}
        ModalProps={{ keepMounted: false }}
      >
        {renderContent()}
      </SwipeableCustomerDrawer>
    </>
  );
};

export default STCDrawer;
