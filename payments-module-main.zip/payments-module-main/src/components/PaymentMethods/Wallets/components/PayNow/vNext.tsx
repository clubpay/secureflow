import { useEffect } from "react";
import { useStripe } from "@stripe/react-stripe-js";
import PaymentAPIManager from "@/api/gateways";
import PaymentLoadingDialog from "@/components/Global/PaymentLoadingDialog";
import { useLockUnlock, useSentry } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { PayNowV1 } from "@/icons";
import { PayNowV2 } from "@/icons";
import { PayNowV3 } from "@/icons";
import { PayNowMoreIcons } from "@/icons";
import { ArrowRight } from "@/icons";
import { usePayment } from "@/providers";
import { usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { StripeConnectConfig } from "@/types/payments/config/stripeConnect";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { PGNameEnum, PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import styles from "./paynow.module.scss";

export const VNext = (props: PaymentOptions) => {
  const { variant = "primary", amount, qlub, pg, country, locale, consumer } = props;
  const config = props.pg.config as StripeConnectConfig;
  const diningSessionId = qlub.diningSessionId!;
  const gatewayId = pg.id;
  const gatewayName = pg.name;
  const tipAmount = qlub?.tip ?? 0;
  const tipAmountString = tipAmount?.toFixed(qlub?.currencyPrecision || 0);
  const apiManager = config.apiManager ?? PaymentAPIManager.getInstance();

  const { onBeforePayment, onPaymentFailure, onPrePayment, onPaymentPending } = config.events;
  const api = gatewayName === PGNameEnum.Stripe ? apiManager.stripe : apiManager.stripeConnect;

  const { startTrace, captureException } = useSentry(props);
  const { processing, setProcessing } = usePayment();
  const { saveLastPayment } = usePaymentProfile({
    paymentOptions: props,
    paymentMethod: PaymentElementEnum.PayNoW
  });

  const {
    toggleVisibility,
    state: pgGroupState,
    setAddPGMethod,
    setPaymentMethodReference
  } = usePGGroupStore((state) => state);
  const isPgGroup = pgGroupState.isPGGroupEnabled;

  const paynowUI = (props.pg.config as StripeConnectConfig).paynowUI;

  const { lock, unlock } = useLockUnlock({ ...props, qlub });
  const { getCallbackUrl } = useConfirmCallback();

  const stripe = useStripe();

  const paymentCallback = async () => {
    startTrace("pay", PaymentElementEnum.PayNoW, async () => {
      setProcessing(true);
      const reference = getRandomString();
      const event = {
        paymentElement: PaymentElementEnum.PayNoW,
        refId: reference
      };

      try {
        const returnUrl = getCallbackUrl({
          ref: reference,
          method: gatewayName,
          paymentElement: PaymentElementEnum.PayNoW,
          dsi: diningSessionId,
          currencySymbol: country,
          amount: amount,
          lang: locale
        });

        const onBeforeResponse = await onBeforePayment?.({
          gatewayId,
          paymentElement: PaymentElementEnum.PayNoW,
          tip: tipAmount
        });
        if (!onBeforeResponse) return;

        const lockResponse = await lock(event);
        if (!lockResponse) return;

        const paymentIntentResponse = await api.createPaymentIntent({
          id: getSession(),
          tipAmount: tipAmountString,
          diningSessionID: diningSessionId,
          gatewayID: gatewayId,
          reference: reference,
          paymentMethod: PaymentElementEnum.PayNoW
        });

        await api.pay({
          id: getSession(),
          tipAmount: tipAmountString,
          diningSessionID: diningSessionId,
          gatewayID: gatewayId,
          reference: reference,
          intentID: paymentIntentResponse.data.intentID,
          paymentMethod: PaymentElementEnum.PayNoW,
          annotations: {
            paymentMethod: PaymentElementEnum.PayNoW,
            funnel: consumer
          }
        });

        saveLastPayment();
        await stripe?.confirmPayNowPayment(paymentIntentResponse.data.clientSecret, {
          return_url: returnUrl.pending
        });

        onPaymentPending(event);
      } catch (error: any) {
        captureException(error);
        onPaymentFailure(event);
      } finally {
        setProcessing(false);
        unlock();
      }
    });
  };

  const handlePay = () => {
    if (onPrePayment) onPrePayment(paymentCallback, PaymentElementEnum.PayNoW);
    else paymentCallback();
  };

  const handleSelect = () => {
    if (isPgGroup) {
      toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.PayNoW });
    }
    handlePay();
  };

  const renderButton = () => {
    switch (paynowUI) {
      case "v1":
        return (
          <div className={styles.payNowV1ButtonContainer} onClick={handleSelect}>
            <div className={styles.leftContainer}>
              <span className={styles.leftText}>PayNow</span>
              <PayNowMoreIcons />
            </div>
            <PayNowV1 />
          </div>
        );
      case "v2":
        return (
          <div className={styles.payNowV2ButtonContainer} onClick={handleSelect}>
            <div className={styles.leftContainer}>
              <PayNowV2 />
              <span className={styles.leftText}>PayNow</span>
              <PayNowMoreIcons />
            </div>
            <ArrowRight />
          </div>
        );

      default:
        return (
          <div className={styles.payNowV3ButtonContainer} onClick={handleSelect}>
            <div className={styles.leftContainer}>
              <PayNowV3 />
              <div className={styles.nestedContainer}>
                <span className={styles.leftText}>PayNow</span>
                <PayNowMoreIcons />
              </div>
            </div>
            <ArrowRight />
          </div>
        );
    }
  };

  useEffect(() => {
    setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.PayNoW });
  }, []);

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.PayNoW,
      fn: paymentCallback
    });
  }, [amount, tipAmount]);

  return (
    <div>
      <PaymentLoadingDialog open={processing} />
      {renderButton()}
    </div>
  );
};

export default VNext;
