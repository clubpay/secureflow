import { useStripeStore } from "@/stores/stripeStore";
import { PaymentOptions } from "@/types";
import V1 from "./v1";
import VNext from "./vNext";

export default (props: PaymentOptions) => {
  const {
    state: { isMultiUIModeActive }
  } = useStripeStore((store) => store);

  if (isMultiUIModeActive) {
    return <VNext {...props} />;
  }
  return <V1 {...props} />;
};
