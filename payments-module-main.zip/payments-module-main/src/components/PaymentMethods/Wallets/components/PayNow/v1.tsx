import { useEffect } from "react";
import { useStripe } from "@stripe/react-stripe-js";
import PaymentAPIManager from "@/api/gateways";
import { Button } from "@/components/Core";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import PaymentLoadingDialog from "@/components/Global/PaymentLoadingDialog";
import ReactPortal from "@/components/Global/ReactPortal";
import { useLockUnlock, useSentry } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { PayNow as PayNowIcon } from "@/icons";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { StripeConnectConfig } from "@/types/payments/config/stripeConnect";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { PGNameEnum, PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";

export const V1 = (props: PaymentOptions) => {
  const { variant = "primary", amount, qlub, pg, country, locale, consumer } = props;
  const config = props.pg.config as StripeConnectConfig;
  const diningSessionId = qlub.diningSessionId!;
  const gatewayId = pg.id;
  const gatewayName = pg.name;
  const tipAmount = qlub?.tip ?? 0;
  const tipAmountString = tipAmount?.toFixed(qlub?.currencyPrecision || 0);
  const apiManager = config.apiManager ?? PaymentAPIManager.getInstance();

  const { onBeforePayment, onPaymentFailure, onPrePayment, onPaymentPending } = config.events;
  const api = gatewayName === PGNameEnum.Stripe ? apiManager.stripe : apiManager.stripeConnect;

  const { startTrace, captureException } = useSentry(props);
  const { processing, setProcessing } = usePayment();
  const { saveLastPayment } = usePaymentProfile({
    paymentOptions: props,
    paymentMethod: PaymentElementEnum.PayNoW
  });

  const {
    toggleVisibility,
    state: pgGroupState,
    setAddPGMethod,
    setPaymentMethodReference
  } = usePGGroupStore((state) => state);
  const isPgGroup = pgGroupState.isPGGroupEnabled;

  const { lock, unlock } = useLockUnlock({ ...props, qlub });
  const { getCallbackUrl } = useConfirmCallback();

  const isSelected = isPaymethodChoosed({ pgId: gatewayId, paymentMethod: PaymentElementEnum.PayNoW });

  const stripe = useStripe();

  const paymentCallback = async () => {
    startTrace("pay", PaymentElementEnum.PayNoW, async () => {
      setProcessing(true);
      const reference = getRandomString();
      const event = {
        paymentElement: PaymentElementEnum.PayNoW,
        refId: reference
      };

      try {
        const returnUrl = getCallbackUrl({
          ref: reference,
          method: gatewayName,
          paymentElement: PaymentElementEnum.PayNoW,
          dsi: diningSessionId,
          currencySymbol: country,
          amount: amount,
          lang: locale
        });

        const onBeforeResponse = await onBeforePayment?.({
          gatewayId,
          paymentElement: PaymentElementEnum.PayNoW,
          tip: tipAmount
        });
        if (!onBeforeResponse) return;

        const lockResponse = await lock(event);
        if (!lockResponse) return;

        const paymentIntentResponse = await api.createPaymentIntent({
          id: getSession(),
          tipAmount: tipAmountString,
          diningSessionID: diningSessionId,
          gatewayID: gatewayId,
          reference: reference,
          paymentMethod: PaymentElementEnum.PayNoW
        });

        await api.pay({
          id: getSession(),
          tipAmount: tipAmountString,
          diningSessionID: diningSessionId,
          gatewayID: gatewayId,
          reference: reference,
          intentID: paymentIntentResponse.data.intentID,
          paymentMethod: PaymentElementEnum.PayNoW,
          annotations: {
            paymentMethod: PaymentElementEnum.PayNoW,
            funnel: consumer
          }
        });

        saveLastPayment();
        await stripe?.confirmPayNowPayment(paymentIntentResponse.data.clientSecret, {
          return_url: returnUrl.pending
        });

        onPaymentPending(event);
      } catch (error: any) {
        captureException(error);
        onPaymentFailure(event);
      } finally {
        setProcessing(false);
        unlock();
      }
    });
  };

  const handlePay = () => {
    if (onPrePayment) onPrePayment(paymentCallback, PaymentElementEnum.PayNoW);
    else paymentCallback();
  };

  const button = (
    <Button variant={variant} loading={processing} disabled={processing} onClick={handlePay}>
      {isPgGroup ? t("Pay") : t("PayNow")}
    </Button>
  );

  useEffect(() => {
    setAddPGMethod({ pgId: gatewayId, paymentMethod: PaymentElementEnum.PayNoW });
  }, []);

  useEffect(() => {
    setPaymentMethodReference({
      pgId: gatewayId,
      paymentMethod: PaymentElementEnum.PayNoW,
      fn: paymentCallback
    });
  }, [amount, tipAmount]);

  return (
    <div>
      <PaymentLoadingDialog open={processing} />
      {isPgGroup && (
        <PGPaymentBox
          name="PayNow"
          icon={<PayNowIcon />}
          selected={isSelected}
          toggleVisibility={() => toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.PayNoW })}
        />
      )}
      {!isPgGroup && button}
      {isSelected && <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{button}</ReactPortal>}
    </div>
  );
};

export default V1;
