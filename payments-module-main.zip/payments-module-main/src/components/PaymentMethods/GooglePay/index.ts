export { default, GooglePay } from "./GooglePay";
