import React, { useEffect, useRef, useState } from "react";
import GooglePayButton from "@google-pay/button-react";
import { Button } from "@/components/Core";
import DialogBox from "@/components/Global/Dialog";
import PGPaymentBox from "@/components/Global/PGPaymentBox";
import storage from "@/constants/storage";
import { useGooglePay, useLocale, useSentry } from "@/hooks";
import { useLockUnlock } from "@/hooks";
import { usePaymentProfile } from "@/hooks/payment-profile";
import { usePgEvent } from "@/hooks/pg-events";
import usePgRelatedLogicsForNonCardPayMethods from "@/hooks/pg-related-logics-for-non-card-pay-methods";
import useCPFDrawer from "@/hooks/useCPFDrawer";
import Naps from "@/icons/Naps";
import { t } from "@/locales";
import { PaymentProvider } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { isPaymethodChoosed, usePGGroupStore } from "@/stores/pgGroupStore";
import { PaymentOptions } from "@/types";
import { CheckoutConfig } from "@/types/payments/config/checkout";
import { GooglePay as GPayIC } from "@clubpay/customer-common-module/src/component/SVG";
import { useConfirmCallback } from "@clubpay/customer-common-module/src/hook/payment";
import { PaymentElementEnum } from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { sumAmounts } from "@clubpay/customer-common-module/src/utility/k_math";
import { getRandomString } from "@clubpay/customer-common-module/src/utility/random";
import { Span } from "@sentry/nextjs/types/client";
import ReactPortal from "../../Global/ReactPortal";
import styles from "./GooglePay.module.scss";

export const GooglePay: React.FC<any> = (props: PaymentOptions) => {
  const { qlub, amount, totalAmount: totalByClient } = props;
  const { data } = usePgRelatedLogicsForNonCardPayMethods(props);

  const gatewayId = props.pg.id;
  const config = props.pg?.config as CheckoutConfig;

  const { onPaymentPending } = config.events ?? {};

  const [showNapsDialog, setShowNapsDialog] = useState(false);

  useLocale(props.locale);
  const { lock, unlock } = useLockUnlock(props);

  const { toggleVisibility, state, setAddPGMethod, removePGMethod, setPaymentMethodReference } = usePGGroupStore(
    (state) => state
  );

  const {
    state: { consumer }
  } = useCommonStore((state: any) => state);

  const { sendEvent } = usePgEvent({ paymentOptions: props, paymentMethod: PaymentElementEnum.CardPay });

  const hasPgGroup = state.isPGGroupEnabled;

  const hasChoosen = isPaymethodChoosed({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.GooglePay });

  const { startTrace, infoLog } = useSentry(props);

  const { handlePay, gatewayName, getPayload, onPaymentComplete, merchantId, environment } = useGooglePay(props);

  const { getCallbackUrl } = useConfirmCallback();

  const { saveLastPayment } = usePaymentProfile({ paymentOptions: props, paymentMethod: PaymentElementEnum.GooglePay });

  const tipAmount = props.qlub?.tip || 0;

  const checkoutTotalAmount = sumAmounts(props.qlub?.currencyPrecision, props?.amount || 0, tipAmount);

  const totalAmount = typeof totalByClient !== "undefined" ? totalByClient : checkoutTotalAmount;

  const makePayment = async (paymentData: google.payments.api.PaymentData) => {
    startTrace("pay", PaymentElementEnum.GooglePay, async (span: Span) => {
      const newRef = getRandomString();
      const event = {
        paymentElement: PaymentElementEnum.GooglePay,
        refId: newRef,
        traceId: span?.traceId
      };

      try {
        const onBeforeRes = await config?.events?.onBeforePayment?.({
          gatewayId,
          paymentElement: PaymentElementEnum.GooglePay,
          tip: props.qlub?.tip ?? 0
        });

        if (!onBeforeRes) {
          infoLog("onBefore api Fail");
          return;
        }

        infoLog("onBefore api Success");

        infoLog("locking mechanism Initialize");

        const lockResponse = await lock({
          gatewayId,
          paymentElement: PaymentElementEnum.GooglePay,
          tip: props.qlub?.tip ?? 0
        });

        if (!lockResponse) {
          infoLog("locking mechanism Fail");
          return;
        }

        infoLog("locking mechanism Success");

        const returnUrl = getCallbackUrl({
          ref: newRef as string,
          method: props.pg.name,
          paymentElement: PaymentElementEnum.CardPay,
          dsi: qlub?.diningSessionId || "",
          amount: amount || "",
          currencySymbol: props.country,
          traceId: span?.traceId,
          lang: props.locale || ""
        });

        try {
          const response: any = await handlePay?.({
            ...getPayload("handlePay", {
              ...paymentData,
              returnUrl: returnUrl,
              reference: newRef,
              documentData,
              ...data
            }),
            customerEmail: paymentData.email,
            annotations: {
              paymentMethod: PaymentElementEnum.GooglePay,
              funnel: consumer
            }
          });

          saveLastPayment({ cardBrand: paymentData.paymentMethodData.info?.cardNetwork });

          infoLog("googlePay core-edge-api Success");

          if (response?.data) {
            if (response.data?.needVerification && response.data?.redirectUrl) {
              infoLog("googlePay redirection Initialize");
              sendEvent("payment_initialized", { status: "3ds" });
              window.location.href = response.data.redirectUrl;

              infoLog("googlePay redirection Success");
            } else {
              infoLog("googlePay paymentSuccess callback called Success");
              onPaymentComplete?.({
                paymentElement: PaymentElementEnum.GooglePay,
                refId: newRef,
                traceId: span?.traceId
              });
            }
          }
        } catch (error: any) {
          if (!error?.data) onPaymentPending?.(event);
          else if (error?.data?.items === "GOOGLE_NAPS_CARD_FAILURE") {
            unlock();
            setShowNapsDialog(true);
            sessionStorage.setItem(storage.NAPS_ALERT_TRIGGERED, "true");
            sendEvent("naps_alert_triggered");
          } else throw error;
        }
      } catch (error: any) {
        infoLog("googlePay Error");
        if (error !== "FORCE_FAILED")
          props?.pg?.config?.events?.onPaymentFailure?.({ ...event, ...error?.response?.data });
      }
    });
  };

  const handleNapsRetryPayment = () => {
    setShowNapsDialog(false);
    toggleVisibility({ pgId: gatewayId, paymentMethod: PaymentElementEnum.QPay });
  };

  const googlePayBtnRef = useRef<any>(null);

  const localSubmit = () => {
    openCPFDrawer();
  };

  const paymentCallbackFn = () => googlePayBtnRef.current.manager.handleClick({});

  const gPayBtnContent = (
    <div>
      <div
        style={{
          position: "relative"
        }}
      >
        <div
          style={{
            position: "absolute",
            top: 0,
            right: 0,
            left: 0,
            bottom: 0,
            zIndex: 101,
            cursor: "pointer"
          }}
          onClick={() => {
            if (config?.events?.onPrePayment) config?.events?.onPrePayment(localSubmit, PaymentElementEnum.GooglePay);
            else {
              localSubmit();
            }
          }}
        ></div>
        <GooglePayButton
          ref={googlePayBtnRef}
          buttonType="pay"
          buttonSizeMode="fill"
          environment={environment}
          className={styles.googleCustomBtn}
          buttonRadius={24}
          style={{
            width: "100%",
            height: "48px"
          }}
          paymentRequest={{
            apiVersion: 2,
            apiVersionMinor: 0,
            emailRequired: !!config.googlePayCustomerEmail,
            allowedPaymentMethods: [
              {
                type: "CARD",
                parameters: {
                  allowedAuthMethods: config?.extraConfig?.googleAllowedAuthMethods || ["PAN_ONLY", "CRYPTOGRAM_3DS"],
                  allowedCardNetworks: config?.extraConfig?.googleAllowedCardNetworks || ["MASTERCARD", "VISA"]
                },
                tokenizationSpecification: {
                  type: "PAYMENT_GATEWAY",
                  parameters: {
                    gateway: gatewayName,
                    gatewayMerchantId: merchantId
                  }
                }
              }
            ],
            merchantInfo: {
              merchantId: config?.googleMerchantId || "12345678901234567890",
              merchantName: "qlub"
            },
            transactionInfo: {
              totalPriceStatus: "FINAL",
              //  totalPriceLabel: "Total",
              totalPrice: totalAmount.toFixed(props.qlub?.currencyPrecision || 0),
              countryCode: config?.countryCode?.toUpperCase() || props.pg?.vendor?.country?.code?.toUpperCase() || "AE",
              currencyCode: props.pg?.vendor?.country?.currencyCode?.toUpperCase() || ""
            }
          }}
          onLoadPaymentData={makePayment}
          buttonLocale={props.locale ?? "en"}
        />
      </div>
      <div>
        {/* <Button
          className={styles.button}
          onClick={() => {
            if (config?.events?.onPrePayment)
              config?.events?.onPrePayment(paymentCallbackFn, PaymentElementEnum.GooglePay);
            else {
              paymentCallbackFn();
            }
          }}
        /> */}
      </div>
    </div>
  );

  const getStyles = () => {
    if (hasPgGroup) {
      return {
        display: "none"
      };
    }
    return {
      display: "block"
    };
  };

  const getName = () => {
    if (props.pg.name?.toLowerCase() == "tuna") return `Google Pay (${t("Credit Card")})`;

    return t("Google Pay");
  };

  const {
    DrawerElement,
    openCPFDrawer,
    additionalData: documentData
  } = useCPFDrawer({
    paymentCB: paymentCallbackFn,
    enabled: props.pg.name === "tuna" && props.pg.config.extraConfig.enableDocumentCollection
  });

  useEffect(() => {
    if (merchantId && gatewayName) setAddPGMethod({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.GooglePay });
  }, [gatewayName]);

  useEffect(() => {
    return () => removePGMethod({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.GooglePay });
  }, []);

  useEffect(() => {
    setPaymentMethodReference({
      pgId: props.pg.id,
      paymentMethod: PaymentElementEnum.GooglePay,
      fn: localSubmit
    });
  }, [amount, totalAmount]);

  if (!merchantId || gatewayName === "") return false;

  return (
    <div>
      {DrawerElement}
      <DialogBox
        open={showNapsDialog}
        title={t("NAPS card detected")}
        description={t("For NAPS card please retry using the NAPS payment field")}
        icon={<Naps height={48} width={48} />}
        action={<Button onClick={handleNapsRetryPayment}>{t("Retry payment")}</Button>}
      />
      {hasPgGroup && (
        <PGPaymentBox
          name={getName()}
          icon={<GPayIC />}
          selected={hasChoosen}
          toggleVisibility={() => toggleVisibility({ pgId: props.pg.id, paymentMethod: PaymentElementEnum.GooglePay })}
        />
      )}
      <PaymentProvider>
        <div style={getStyles()}>{gPayBtnContent}</div>
      </PaymentProvider>
      {hasChoosen && (
        <ReactPortal domNode={document.querySelector("#pg-group-paybtn-container")}>{gPayBtnContent}</ReactPortal>
      )}
    </div>
  );
};

export default GooglePay;
