export { default as ApplePay } from "./PaymentMethods/ApplePay";
export { default as GooglePay } from "./PaymentMethods/GooglePay";
export { default as CardPay } from "./PaymentMethods/Card/Portal";
export { default as PaymentPortal } from "./PaymentPortal";
export { default as PaymentButtonForClient } from "./Global/PaymentButtonForClient";
export { default as ForexCurrencyChangeV2 } from "./Global/ForexCurrencyChangeV2";
