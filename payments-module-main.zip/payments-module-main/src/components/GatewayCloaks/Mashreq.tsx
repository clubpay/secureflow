import { useEffect, useState } from "react";
import Script from "next/script";
import PaymentAPIManager from "@/api/gateways";
import { PaymentOptions } from "@/types";
import { useMashreqContext } from "../PaymentMethods/Card/Gateways/Mashreq/MashreqContext";

export interface MashreqCloakProps extends PaymentOptions {
  config: any;
  children: JSX.Element;
  onReady?: () => void;
}

const SCRIPT_URL = {
  PROD: "https://ap-gateway.mastercard.com/form/version/72/merchant/",
  TEST: "https://test-gateway.mastercard.com/form/version/72/merchant/"
};

export type FormSessionResponse = {
  status: ResponseStatus;
  sourceOfFunds: {
    provided: {
      card: {
        securityCode: string;
        scheme: string;
      };
    };
  };
  errors?: FormErrors;
  session: {
    id: string;
  };
};
export type FormErrors = {
  cardNumber?: FormErrorType;
  expiryYear?: FormErrorType;
  expiryMonth?: FormErrorType;
  securityCode?: FormErrorType;
  cardHolderName?: FormErrorType;
  message?: string;
};
export type FormErrorType = "invalid" | "missing";

export enum ResponseStatus {
  OK = "ok",
  ERROR_IN_FIELDS = "fields_in_error",
  REQUEST_TIMEOUT = "request_timeout",
  SYSTEM_ERROR = "system_error"
}

const MashreqCloak = ({ qlub, onReady, children, ...props }: MashreqCloakProps) => {
  const gatewayId = props.pg.id;
  const config = props.pg.config;
  const { handlePayFunctionRef, mashreqSessionId, setMashreqSessionId } = useMashreqContext();

  const env = (config.extraConfig?.env?.toUpperCase() as "PROD" | "TEST") || "PROD";

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).mashreq;

  const url = new URL(`${config.extraConfig?.merchantId}/session.js`, SCRIPT_URL[env]);

  const [load, setLoad] = useState<boolean>(false);

  console.log("handlePayFunctionRef 0", handlePayFunctionRef);

  const setting = {
    session: mashreqSessionId,
    fields: {
      card: {
        number: "#card-number",
        securityCode: "#security-code",
        expiryMonth: "#expiry-month",
        expiryYear: "#expiry-year"
      }
    },
    frameEmbeddingMitigation: ["javascript", "x-frame-options", "csp"],
    locale: "en",
    callbacks: {
      initialized(response: any) {
        // handleEvents();
        console.log("before initialized", response);
      },
      formSessionUpdate(response: FormSessionResponse) {
        console.log(response);
        if (response?.status === ResponseStatus.OK) {
          const { session } = response;
          //    setMashreqSessionId(session.id);
          console.log("mashreqSessionId: init time", mashreqSessionId);
          if (!response.sourceOfFunds.provided.card.securityCode) {
            //   showError(errorTranslations.ERROR_IN_FIELDS.securityCode!.missing);
            return;
          }

          //   console.log("handlePayFunctionRef 1", handlePayFunctionRef)
          handlePayFunctionRef.funcRef?.({
            cardBrand: response.sourceOfFunds.provided.card.scheme,
            sessId: session.id
          });
          // makeQlubPayment({
          //     cardBrand: response.sourceOfFunds.provided.card.scheme,
          //     sessId: session.id,
          // });
        } else {
          // handleError(response);
        }
      }
    },
    interaction: {
      displayControl: {
        formatCard: "EMBOSSED",
        invalidFieldCharacters: "REJECT"
      }
    }
  };

  const init = () => {
    if (window.PaymentSession && typeof window.PaymentSession.configure === "function") {
      window.PaymentSession.configure(setting);
      console.log("PAYMENT SESSION", window.PaymentSession);
      onReady?.();
    } else {
      console.error("PaymentSession object is not available after script loading.");
    }
  };

  const generateSession = async () => {
    try {
      const response = await api.generateSession({
        diningSessionID: qlub?.diningSessionId || "",
        gatewayID: gatewayId
      });

      if (response.data) {
        setMashreqSessionId(response.data.sessionId);
      }
    } catch (error) {
      console.log("error", error);
    }
  };

  useEffect(() => {
    generateSession();
  }, []);

  useEffect(() => {
    if (load && mashreqSessionId) {
      init();
    }
  }, [load, mashreqSessionId]);

  return (
    <>
      <Script src={url.toString()} onLoad={() => setLoad(true)} />
      {children}
    </>
  );
};

export default MashreqCloak;
