import { useEffect, useState } from "react";
import Scripts from "next/script";
import { useCommonStore } from "@/stores/commonStore";
import CardLayoutSkeleton from "../PaymentMethods/Card/Layout/Skeleton";

export interface CheckoutCloakProps {
  children: JSX.Element;
  onReady?: () => void;
  pg: any;
}

const CheckoutCloak = ({ children, onReady, pg }: CheckoutCloakProps) => {
  const {
    setLoadedState,
    setPriority,
    state: { loadedState, priority }
  } = useCommonStore((store) => store);

  const onLoad = (initial?: boolean) => {
    if (initial) {
      onReady?.();
      setLoadedState("checkout");
    }
  };

  const handleOnError = () => {
    if (priority.isEnabled) {
      setPriority({
        currentPriority: (pg.config.priority || 0) + 1,
        blockedPgs: [...priority.blockedPgs, pg.id]
      });
    }
  };

  return (
    <>
      <Scripts
        src="https://cdn.checkout.com/js/framesv2.min.js"
        onLoad={() => {
          onLoad(true);
        }}
        onError={handleOnError}
      />
      {loadedState.checkout ? children : <CardLayoutSkeleton />}
    </>
  );
};

export default CheckoutCloak;
