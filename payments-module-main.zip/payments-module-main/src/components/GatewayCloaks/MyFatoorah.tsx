import Scripts from "next/script";
import { useCommonStore } from "@/stores/commonStore";
import { PaymentGatewayConfig } from "@/types";
import { getSdkUrl } from "../PaymentMethods/Card/Gateways/MyFatoorah/MyFatoorah.util";
import CardLayoutSkeleton from "../PaymentMethods/Card/Layout/Skeleton";

export interface MyFatoorahCloakProps {
  children: JSX.Element;
  onReady?: VoidFunction;
  pg: PaymentGatewayConfig;
}

const MyFatoorahCloak = ({ children, onReady, pg }: MyFatoorahCloakProps) => {
  const countryCode = pg.vendor?.country?.isoCode?.toUpperCase();
  const sandbox = pg.config?.sandbox;

  const {
    setLoadedState,
    setPriority,
    state: { loadedState, priority }
  } = useCommonStore((store) => store);

  const onLoad = (initial?: boolean) => {
    if (initial) {
      onReady?.();
      setLoadedState("myFatoorah");
    }
  };

  const handleOnError = () => {
    if (priority.isEnabled) {
      setPriority({
        currentPriority: (pg.config.priority || 0) + 1,
        blockedPgs: [...priority.blockedPgs, pg.id]
      });
    }
  };

  return (
    <>
      <Scripts
        src={getSdkUrl(countryCode, sandbox)}
        onLoad={() => {
          onLoad(true);
        }}
        onError={handleOnError}
      />
      {loadedState.myFatoorah ? children : <CardLayoutSkeleton />}
    </>
  );
};

export default MyFatoorahCloak;
