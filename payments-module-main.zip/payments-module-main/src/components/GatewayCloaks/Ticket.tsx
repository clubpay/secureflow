export interface NgeniusCloakProps {
  children: JSX.Element;
  onReady?: () => void;
}

const Ticket = ({ children }: NgeniusCloakProps) => {
  return <>{children}</>;
};

export default Ticket;
