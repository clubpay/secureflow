import Head from "next/head";
import Scripts from "next/script";
import { useCommonStore } from "@/stores/commonStore";

export interface TunaCloakProps {
  children: JSX.Element;
  onReady?: () => void;
}

const TunaCloak = ({ children, onReady }: TunaCloakProps) => {
  const {
    setLoadedState,
    state: { loadedState }
  } = useCommonStore((store) => store);

  const onLoad = (initial?: boolean) => {
    if (initial) {
      onReady?.();
      setLoadedState("tuna");
    }
  };

  return (
    <>
      <Head>
        <link rel="stylesheet" type="text/css" href="https://js.tuna.uy/css/components.min.css" />
      </Head>
      {loadedState.tuna && children}
      <Scripts id="tunaCode" src="https://js.tuna.uy/tuna.js" onLoad={() => onLoad(true)} />
    </>
  );
};

export default TunaCloak;
