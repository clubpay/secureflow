import Head from "next/head";
import Scripts from "next/script";
import { useCommonStore } from "@/stores/commonStore";

export interface MoyasarCloakProps {
  children: JSX.Element;
  onReady?: () => void;
}

const MoyasarCloak = ({ children, onReady }: MoyasarCloakProps) => {
  const { setLoadedState } = useCommonStore((store) => store);

  const onLoad = (initial?: boolean) => {
    if (initial) {
      onReady?.();
      setLoadedState("moysarV1");
    }
  };

  return (
    <>
      <Head>
        <link rel="stylesheet" type="text/css" href="https://cdn.moyasar.com/mpf/1.10.0/moyasar.css" />
      </Head>
      {children}
      <Scripts id="polyfill" src="https://polyfill.io/v3/polyfill.min.js?features=fetch" />
      <Scripts
        src="https://cdn.moyasar.com/mpf/1.11.0/moyasar.js"
        onLoad={() => {
          onLoad(true);
        }}
      />
    </>
  );
};

export default MoyasarCloak;
