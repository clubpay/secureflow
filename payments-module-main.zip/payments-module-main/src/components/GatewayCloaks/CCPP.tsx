import Scripts from "next/script";
import { useCommonStore } from "@/stores/commonStore";
import { CCPPConfig } from "@/types/payments/config/ccpp";
import CardLayoutSkeleton from "../PaymentMethods/Card/Layout/Skeleton";

export interface CCPPCloakProps {
  config: CCPPConfig;
  children: JSX.Element;
}

const CCPPCloak = ({ config, children }: CCPPCloakProps) => {
  const {
    setLoadedState,
    state: { loadedState }
  } = useCommonStore((store) => store);

  return (
    <>
      <Scripts
        src={
          config.sandbox
            ? "https://demo2.2c2p.com/2C2PFrontEnd/SecurePayment/api/my2c2p.1.6.9.min.js"
            : "https://t.2c2p.com/SecurePayment/api/my2c2p.1.7.3.min.js"
        }
        onLoad={() => {
          setLoadedState("ccpp");
        }}
      />
      {loadedState.ccpp ? children : <CardLayoutSkeleton />}
    </>
  );
};

export default CCPPCloak;
