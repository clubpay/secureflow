import { Elements } from "@stripe/react-stripe-js";
import { useCommonStore } from "@/stores/commonStore";
import { PaymentGatewayConfig } from "@/types";
import { StripeElementsOptionsMode, loadStripe } from "@stripe/stripe-js";

export interface StripeCloakProps {
  children: JSX.Element;
  pg: PaymentGatewayConfig;
  options: StripeElementsOptionsMode;
}

const StripeCloak = ({ children, pg, options }: StripeCloakProps) => {
  const stripePromise = loadStripe(pg.config.publicKey!, {
    locale: options.locale,
    betas: ["blocked_card_brands_beta_2"]
  });

  const {
    setPriority,
    state: { priority }
  } = useCommonStore((store) => store);

  stripePromise.catch((_) => {
    if (priority.isEnabled) {
      setPriority({
        currentPriority: (pg.config.priority || 0) + 1,
        blockedPgs: [...priority.blockedPgs, pg.id]
      });
    }
  });

  return (
    <Elements
      stripe={stripePromise}
      options={{
        mode: "payment",
        paymentMethodCreation: "manual",
        currency: pg?.vendor?.country?.currencyCode?.toLowerCase(),
        ...(pg.config?.extraConfig.allowedCardBrands?.length
          ? { allowedCardBrands: pg.config?.extraConfig.allowedCardBrands }
          : {}),
        ...options
      }}
    >
      {children}
    </Elements>
  );
};

export default StripeCloak;
