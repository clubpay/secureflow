import { useEffect } from "react";
import { defineCustomElements } from "@mafpay/weblib";

export interface MAFCloakProps {
  children: JSX.Element;
  onReady?: () => void;
}

const MAFCloak = ({ children }: MAFCloakProps) => {
  useEffect(() => {
    defineCustomElements();
    window.MafPay = {
      ...window.MafPay,
      env: "sandbox"
    };
  }, []);

  return children;
};

export default MAFCloak;
