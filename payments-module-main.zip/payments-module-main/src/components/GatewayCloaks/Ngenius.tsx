import Scripts from "next/script";
import { usePayment } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";

export interface NgeniusCloakProps {
  children: JSX.Element;
  onReady?: () => void;
  config: any;
}

const NgeniusCloak = ({ children, onReady, config }: NgeniusCloakProps) => {
  const {
    setLoadedState,
    state: { loadedState }
  } = useCommonStore((store) => store);

  const onLoad = (initial?: boolean) => {
    if (initial) {
      onReady?.();
      setLoadedState("ngenius");
    }
  };

  return (
    <>
      {loadedState.ngenius && children}
      <Scripts
        src={
          config.sandbox
            ? "https://paypage.sandbox.ngenius-payments.com/hosted-sessions/sdk.js"
            : "https://paypage.ngenius-payments.com/hosted-sessions/sdk.js"
        }
        onLoad={() => onLoad(true)}
      />
    </>
  );
};

export default NgeniusCloak;
