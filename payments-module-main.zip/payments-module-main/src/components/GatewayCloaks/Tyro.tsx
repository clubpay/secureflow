import { useEffect, useRef, useState } from "react";
import PaymentAPIManager from "@/api/gateways";
import { useToast } from "@/hooks";
import { t } from "@/locales";
import { usePayment } from "@/providers";
import { useCommonStore } from "@/stores/commonStore";
import { useTyroStore } from "@/stores/tyroStore";
import { PaymentOptions } from "@/types";
import { ErrorMessageKey, ErrorMessages } from "@/utils";
import { validateExpiryDate } from "@/utils";
import { extractErrorV2 } from "../PaymentMethods/Card/Gateways/Tyro/Tyro.util";
import { extractError } from "../PaymentMethods/Card/Gateways/Tyro/Tyro.util";
import { ResponseStatus } from "../PaymentMethods/Card/Gateways/Tyro/Tyro.util";
import useScriptRefresh from "../PaymentMethods/Card/Gateways/Tyro/useScriptRefresh";

export interface TyroCloakProps extends PaymentOptions {
  config: any;
  children: JSX.Element;
  onReady?: () => void;
}

const SCRIPT_URL = {
  PROD: "https://tyro.gateway.mastercard.com/form/version/81/merchant/",
  TEST: "https://test-tyro.mtf.gateway.mastercard.com/form/version/81/merchant/"
};

const TyroCloak = ({ qlub, onReady, children, locale, ...props }: TyroCloakProps) => {
  const gatewayId = props.pg.id;
  const config = props.pg.config;
  const env = (config.extraConfig?.env?.toUpperCase() as "PROD" | "TEST") || "PROD";

  const initRanRef = useRef(false);
  const handPayCBRef = useRef<any>(null);

  const url = new URL(`${config.extraConfig?.merchantId}/session.js`, SCRIPT_URL[env]);

  useScriptRefresh(
    url.toString(),
    () => {
      setLoadedState("tyro");
    },
    () => {
      setLoadedState("tyro", false);
      setInitStatus(false);
    }
  );

  const { setProcessing } = usePayment();

  const { displayMessage } = useToast();

  const {
    state: { handlePayFunctionRef, tyroSessionId },
    setTyroSessionId,
    setInitStatus
  } = useTyroStore((store) => store);

  handPayCBRef.current = handlePayFunctionRef;

  const api = (config.apiManager ?? PaymentAPIManager.getInstance()).tyro;

  const [tyroSessionIdLocal, setTyroSessionIdLocal] = useState("");

  const {
    setLoadedState,
    state: { loadedState }
  } = useCommonStore((store) => store);

  const setting = {
    session: tyroSessionId,
    fields: {
      card: {
        number: "#card-number",
        securityCode: "#security-code",
        expiryMonth: "#expiry-month",
        expiryYear: "#expiry-year"
      }
    },
    frameEmbeddingMitigation: ["javascript", "x-frame-options", "csp"],
    locale: locale || "en",
    callbacks: {
      initialized(response: any) {
        console.log("initialized", response);
        setInitStatus(true);
      },
      formSessionUpdate(response: any) {
        if (response?.status === ResponseStatus.OK) {
          const { session } = response;

          if (!response.sourceOfFunds.provided.card.securityCode) {
            displayMessage(t(ErrorMessages[ErrorMessageKey.Cvv]));
            setProcessing(false);
            return;
          }

          const expiryYear = response.sourceOfFunds.provided.card.expiry.year;
          let expiryMonth = response.sourceOfFunds.provided.card.expiry.month;

          if (expiryYear && expiryMonth) {
            expiryMonth = expiryMonth < 10 ? `0${expiryMonth}` : expiryMonth;
            const expiry = `${expiryMonth}/${expiryYear}`;
            const expiryDateStatus = validateExpiryDate(expiry);
            if (expiryDateStatus) {
              displayMessage(t(expiryDateStatus));
              setProcessing(false);
              return;
            }
          }

          console.log("func called", handPayCBRef.current);
          handPayCBRef.current?.({
            cardBrand: response.sourceOfFunds.provided.card.scheme,
            sessId: session.id
          });
        } else if (response.status === ResponseStatus.ERROR_IN_FIELDS) {
          const error = extractErrorV2(response.errors);
          if (error) displayMessage(t(error));
          setProcessing(false);
        } else {
          setProcessing(false);
          displayMessage(extractError(response), "error");
        }
      }
    },
    interaction: {
      displayControl: {
        formatCard: "EMBOSSED",
        invalidFieldCharacters: "REJECT"
      }
    }
  };

  const init = () => {
    console.log("tyro:: init", window.PaymentSession);
    if (window.PaymentSession && typeof window.PaymentSession.configure === "function") {
      window.PaymentSession.configure(setting);
      console.log("PAYMENT SESSION", window.PaymentSession);
      console.log("configured", setting);
      onReady?.();
    } else {
      console.error("PaymentSession object is not available after script loading.");
    }
  };

  const generateSession = async () => {
    try {
      const response = await api.session({
        diningSessionID: qlub?.diningSessionId || "",
        gatewayID: gatewayId
      });

      if (response.data) {
        setTyroSessionId(response.data.sessionId);
        setTyroSessionIdLocal(response.data.sessionId);
        window.tyroSessionId = response.data.sessionId;
      }
    } catch (error) {
      console.log("error", error);
    }
  };

  useEffect(() => {
    generateSession();
  }, []);

  useEffect(() => {
    if (loadedState.tyro && tyroSessionIdLocal && !initRanRef.current) {
      initRanRef.current = true;
      init();
    }
  }, [loadedState.tyro, tyroSessionIdLocal]);

  return <>{tyroSessionId && children}</>;
};

export default TyroCloak;
