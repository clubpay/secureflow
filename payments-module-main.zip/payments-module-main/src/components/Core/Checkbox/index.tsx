import { useEffect, useState } from "react";
import { Check } from "@/icons";
import { DesignVariants } from "@/types";
import defaultStyles from "./styles/checkbox.module.scss";

interface CheckboxProps extends Omit<React.HTMLAttributes<HTMLElement>, "onChange">, DesignVariants {
  label: string;
  checked: boolean;
  overrideStyle?: boolean;
  onChange: (e: boolean) => void;
}

const Checkbox: React.FC<CheckboxProps> = ({
  variant = "primary",
  label,
  className = "",
  overrideStyle,
  onChange,
  ...props
}) => {
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    setChecked(props.checked);
  }, [props.checked]);

  const onClick = () => {
    setChecked(!checked);
    onChange(!checked);
  };

  return (
    <div {...props} className={overrideStyle ? className : `${defaultStyles.container} ${className}`} onClick={onClick}>
      <div className={defaultStyles[`${variant}-${checked ? "box-checked" : "box-unchecked"}`]}>
        <Check />
      </div>
      <span className={defaultStyles.label}>{label}</span>
    </div>
  );
};

export default Checkbox;
