import { default as SkeletonLoader } from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import { KeyValue } from "@/types";
import styles from "./skeleton.module.scss";

interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
  containerClassName?: string;
  className?: string;
  shade?: "dark" | "normal";
  count?: number;
}

const shadeMap: KeyValue = {
  dark: {
    baseColor: "#ececec",
    highlightColor: "#f0f0f0"
  },
  normal: {
    baseColor: "#f8f8f8",
    highlightColor: "#f2f2f2"
  }
};

const Skeleton: React.FC<SkeletonProps> = ({ containerClassName = "", className = "", shade = "normal", ...props }) => {
  return (
    <SkeletonLoader
      containerClassName={containerClassName}
      className={`${styles.base} ${className}`}
      baseColor={shadeMap[shade]?.baseColor}
      highlightColor={shadeMap[shade]?.highlightColor}
      {...props}
    />
  );
};

export default Skeleton;
