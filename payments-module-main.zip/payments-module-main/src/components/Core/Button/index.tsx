import { ThreeDots } from "react-loader-spinner";
import { DesignVariants } from "@/types";
import defaultStyles from "./styles/button.module.scss";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement>, DesignVariants {
  loading?: boolean;
  overrideStyle?: boolean;
  prefixIcon?: React.FunctionComponent<React.SVGProps<SVGSVGElement>>;
  postfixIcon?: React.FunctionComponent<React.SVGProps<SVGSVGElement>>;
}

const Button: React.FC<ButtonProps> = ({
  variant = "primary",
  children,
  className = "",
  overrideStyle,
  loading = false,
  prefixIcon: PrefixIcon,
  postfixIcon: PostfixIcon,
  ...props
}) => {
  if (!overrideStyle) className += ` ${defaultStyles[`${variant}-base`]}`;
  if (loading) className += ` ${defaultStyles[`base-loading`]}`;
  return (
    <button {...props} className={className}>
      {PrefixIcon && <PrefixIcon />}
      {children}
      {PostfixIcon && <PostfixIcon />}
      <ThreeDots ariaLabel="button-loading" wrapperClass={defaultStyles.loader} visible={loading} />
    </button>
  );
};

export default Button;
