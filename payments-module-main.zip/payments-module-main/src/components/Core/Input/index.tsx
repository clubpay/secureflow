import React, { forwardRef, useMemo } from "react";
import classNames from "classnames";
import { CVCHint, ExpireHint, FieldError, NoCard } from "@/icons";
import { useCommonStore } from "@/stores/commonStore";
import { DesignVariants } from "@/types";
import defaultStyles from "./styles/input.module.scss";

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement>, DesignVariants {
  element?: React.FunctionComponent<any> | string;
  overrideStyle?: boolean;
  error?: string | null;
  [key: string]: any;
  hideFieldError?: boolean;
  forceLTR?: boolean;
}

const Input = forwardRef(
  (
    {
      element: InputElement = "input",
      variant = "primary",
      className = "",
      label,
      error,
      overrideStyle,
      hideFieldError = false,
      forceLTR = false,
      ...props
    }: InputProps,
    ref
  ) => {
    const id = useMemo(
      () => props.id ?? `${label?.toLowerCase().replace(" ", "-")}-${Math.random().toString(36).substr(2, 9)}}`,
      [props.id]
    );

    const {
      state: { isRTL }
    } = useCommonStore((store) => store);

    const styleClasses = classNames(`${defaultStyles[`${variant}-base`]} ${defaultStyles[`${variant}-input`]}`, {
      [defaultStyles[`${variant}-error`]]: error,
      [className]: className,
      [defaultStyles.forceLTR]: forceLTR && isRTL
    });

    return (
      <div className={defaultStyles.container}>
        {label && (
          <label htmlFor={id} className={`${defaultStyles.label} ${error ? defaultStyles["label-error"] : ""}`}>
            {label}
          </label>
        )}
        <div className={defaultStyles.inputWrapper}>
          <InputElement {...props} id={id} ref={ref} className={overrideStyle ? className : styleClasses} />
          {!hideFieldError && (
            <span className={defaultStyles.infoWrapper}>
              {error ? (
                <FieldError />
              ) : (
                <>
                  {label === "Card number" && <NoCard />}
                  {["Expiry date", "Expiry month", "Expiry year"].includes(label) && <ExpireHint />}
                  {label === "Security code" && <CVCHint />}
                </>
              )}
            </span>
          )}
        </div>
        {error && <span className={defaultStyles.error}>{error}</span>}
      </div>
    );
  }
);

export default Input;
