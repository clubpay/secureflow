import { extractStyles } from "@/utils";
import styles from "./input.module.scss";

export const inputVariants = styles.variants.split(", ");

export default extractStyles(styles, inputVariants);
