import defaultStyles from "./divider.module.scss";

interface DividerProps extends React.HTMLAttributes<HTMLElement> {
  overrideStyle?: boolean;
}

const Divider: React.FC<DividerProps> = ({ className = "", overrideStyle, ...props }) => {
  return <div {...props} className={overrideStyle ? className : `${defaultStyles.base} ${className}`} />;
};

export default Divider;
