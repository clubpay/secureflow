# Qlub Payment Kit

This library contains all Payment Web UI components that can be used across Web projects in Qlub
this has fixes for PAYM-722 and PAYM-723

## Usage

Run `yarn add @clubpay/payment-kit` with appropriate authentication to incorporate into your project <br/> <br/>


```js
import { PaymentPortal } from "@clubpay/payment-kit";

export default function Checkout() {
  return (
    <>
      <PaymentPortal
        pg={{
          name: "checkout",
          config: {
            sandbox: true,
            publicKey: "<public-key>",
            supportedNetworks: ["visa", "mastercard", "amex", "discover"],
            refundType: "full",
            googleMerchantId: "<merchant-id>",
            googleAllowedCardNetworks: ["visa", "mastercard", "amex", "discover"]
          }
        }}
        {...props}
      />
    </>
  );
}
```

## Development Setup

- Create a file named `.npmrc` at the root of your project with the following content

```
save-exact=true
enable-pre-post-scripts=true
auto-install-peers=true

@qlub-dev:registry=https://npm.pkg.github.com
@clubpay:registry=https://npm.pkg.github.com

//npm.pkg.github.com/:_authToken={{access_token}}
```

- Useful commands

  - Run `yarn install` to install all dependencies
  - Run `yarn storybook` to start the storybooks dev server
  - Run `yarn build-storybook` to build the project for a web release
  - Run `yarn build` to build the project for a package release

## Commit messages

- We follow conventional commits during our development workflow as a good practice. More information can be found at their official [documentation](https://www.conventionalcommits.org/en/v1.0.0-beta.4/#examples)

## Additional tools

- This project is bootstrapped with [Lefthook](https://evilmartians.com/opensource/lefthook), [Eslint](https://eslint.org/) and [Prettier](https://prettier.io/). Please make good use of them.

<br/>
