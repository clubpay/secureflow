/// <reference types="vitest" />
import { glob } from "glob";
import { fileURLToPath } from "node:url";
import path from "path";
import { defineConfig } from "vite";
import dts from "vite-plugin-dts";
import { libInjectCss, scanEntries } from "vite-plugin-lib-inject-css";

export const cssOptions = {
  preprocessorOptions: {
    scss: {
      additionalData: `
        @import "@/styles/global/index.scss";
      `
    }
  }
};

const plugins: any[] = [];

if (!process.env.STATIC) {
  plugins.push(
    ...[
      libInjectCss({
        entry: {
          index: "src/index.ts",
          ...scanEntries(["src/components"])
        }
      }),
      dts({
        entryRoot: "src"
      })
    ]
  );
}

export default defineConfig({
  define: {
    "process.env": `({})`
  },
  plugins,
  resolve: {
    alias: {
      "@/": `${path.resolve(__dirname, "./src")}/`
    }
  },
  css: cssOptions,
  build: {
    minify: true,
    sourcemap: "hidden",
    emptyOutDir: true,
    assetsDir: ".",
    rollupOptions: {
      external: [
        "react",
        "react-dom",
        "next/script",
        "next/head",
        "next/router",
        "@clubpay/customer-common-module/src/service/session/dsi",
        "@clubpay/customer-common-module/src/context/auth",
        "@clubpay/customer-common-module/src/hook/payment",
        "@clubpay/customer-common-module/src/repository/axios",
        "@clubpay/customer-common-module/src/component/SVG",
        "@sentry/nextjs",
        "@mui/material",
        "@mui/icons-material",
        "@clubpay/customer-common-module/src/repository/axios",
        "@clubpay/customer-common-module/src/hook/snackBar",
        "@clubpay/customer-common-module/src/hook/translations",
        "notistack",
        "@clubpay/customer-common-module/src/component/SVG/ticket.svg",
        "@mui/material/SwipeableDrawer",
        "jquery",
        "yup",
        "formik",
        "@mui/material/IconButton",
        "@mui/icons-material/RadioButtonUncheckedRounded",
        "@mui/icons-material/CheckCircleRounded",
        "@mui/icons-material/AddCard",
        "@mui/icons-material/CurrencyExchange",
        "@mui/icons-material/Delete",
        "@mui/icons-material/ModeEdit",
        "@mui/icons-material/RadioButtonUncheckedRounded",
        "@mui/icons-material/ArrowForwardIos",
        "@mui/icons-material/Circle",
        "@mui/icons-material/CreditCard",
        "@mui/icons-material/Info",
        "@mui/material/Collapse",
        "react-otp-input",
        "zustand",
        "immer",
        "@qlub-dev/qlub-kit",
        "@clubpay/customer-common-module/src/hook/router",
        "@sentry/nextjs",
        "@clubpay/customer-common-module/src/component/SVG/ticketwhite.png",
        "next/link"
      ],
      input: Object.fromEntries(
        glob
          .sync("src/**/*.{ts,tsx}")
          .map((file) => [
            path.relative("src", file.slice(0, file.length - path.extname(file).length)),
            fileURLToPath(new URL(file, import.meta.url))
          ])
      ),
      output: {
        globals: {
          react: "React",
          window: "global/window"
        },
        format: "esm",
        dir: "dist"
      }
    }
  },
  test: {
    globals: true,
    environment: "happy-dom",
    coverage: {
      provider: "v8"
    }
  }
});
