module.exports = {
  testEnvironment: "jsdom"
};
