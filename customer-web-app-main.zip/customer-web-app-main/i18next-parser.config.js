module.exports = {
    input: ['src/**/*.{js,jsx,ts,tsx}', 'node_modules/@clubpay/*/src/**/*.{js,jsx,ts,tsx}'],
    output: './public/locales/$LOCALE/$NAMESPACE.json',
    locales: ['en', 'ar', 'ja', 'de', 'tr', 'pt', 'zh', 'hk', 'es', 'en-sg', 'ko', 'ru'],
    contextSeparator: false,
    keySeparator: false,
    namespaceSeparator: false,
    pluralSeparator: false,
    verbose: true,
};
