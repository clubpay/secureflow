#!/usr/bin/env bash

cd "$CI_PROJECT_DIR" || exit

# Login to the docker registry
docker login -u gitlab-ci-token -p "$CI_BUILD_TOKEN" "$CI_REGISTRY"

docker build --pull -t "$CI_REGISTRY_IMAGE":"$API_VER" .
docker push "$CI_REGISTRY_IMAGE":"$API_VER"
