/*
 * Creation Time: {today.year} - {today.month} - {today.day}
 */

// __mocks__/fileMock.js
module.exports = {
    src: '/img.jpg',
    height: 24,
    width: 24,
    blurDataURL: 'data:image/png;base64,imagedata',
};
