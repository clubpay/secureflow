/*
 * Creation Time: {today.year} - {today.month} - {today.day}
 */

module.exports = {
    process() {
        return { code: 'module.exports = {};' };
    },
    getCacheKey() {
        // The output is always the same.
        return 'svgTransform';
    },
};
