/*
 * Creation Time: {today.year} - {today.month} - {today.day}
 */

// __mocks__/styleMock.js
module.exports = {};
