/*
 * Creation Time: {today.year} - {today.month} - {today.day}
 */

import React from 'react';
import { render as defaultRender } from '@testing-library/react';

import { NextRouter } from 'next/router';
// import { RouterContext } from 'next/dist/shared/lib/router-context.shared-runtime';

export * from '@testing-library/react';

// --------------------------------------------------
// Override the default test render with our own
//
// You can override the router mock like this:
//
// const { baseElement } = render(<MyComponent />, {
//   router: { pathname: '/my-custom-pathname' },
// });
// --------------------------------------------------

const mockRouter: any = {
    isLocaleDomain: false,
    get isPreview(): boolean {
        return false;
    },
    isReady: false,
    basePath: '',
    pathname: '/',
    route: '/',
    asPath: '/',
    query: {},
    push: jest.fn(),
    replace: jest.fn(),
    reload: jest.fn(),
    back: jest.fn(),
    prefetch: jest.fn(),
    beforePopState: jest.fn(),
    events: {
        on: jest.fn(),
        off: jest.fn(),
        emit: jest.fn(),
    },
    isFallback: false,
};
type DefaultParams = Parameters<typeof defaultRender>;
type RenderUI = DefaultParams[0];
type RenderOptions = DefaultParams[1] & { router?: Partial<NextRouter> };

export function render(ui: RenderUI, { wrapper, router, ...options }: RenderOptions = {}) {
    if (!wrapper) {
        // wrapper = ({ children }) => (
        //     <RouterContext.Provider value={{ ...mockRouter, ...router }}>{children}</RouterContext.Provider>
        // );
    }

    return defaultRender(ui, { wrapper, ...options });
}
