/*
 * Creation Time: March 29 - 2023
 * Created By: yasincelebi
 * Name: test-data.ts
 * Copyright 2023 customer-web-app
 */

import { DiscountTypeEnum, SplitModeEnum } from '@clubpay/customer-common-module/src/repository/vendor';

export const VENDOR_TEST_DATA = {
    country: {
        code: 'TR',
        currencyCode: 'TRY',
        isoCode: 'TR',
        currencySymbol: '₺',
        languageCode: 'tr',
        name: 'Turkey',
        phonePrefix: '+90',
    },
    config: {
        splitMode: SplitModeEnum.Disabled,
        previewBill: false,
        hideLogo: false,
        hideTableName: true,
        hideTableId: true,
    },
    name: 'Sallamasyon',
    id: '5f9f9b9b0f9b9c0001b0b0b0',
    address1: 'Sallamasyon',
    address2: 'Sallamasyon',
    area: 'Sallamasyon',
    backgroundUrl: 'https://s3-eu-west-1.amazonaws.com/foodfleet-dev/5f9f9b9b0f9b9c0001b0b0b0/background.jpg',
    city: 'Sallamasyon',
    email: '',
    brand: {
        name: 'Sallamasyon',
    },
    externalMenuUrl: 'https://sallamasyon.com',
    logoBigUrl: 'https://s3-eu-west-1.amazonaws.com/foodfleet-dev/5f9f9b9b0f9b9c0001b0b0b0/logo-big.png',
    phone: '123456789',
    primaryColour: '#000000',
    secondaryColour: '#000000',
    title: 'Sallamasyon',
    unique: 'sallamasyon',
    paymentGatewayList: {
        itemsList: [],
        total: 0,
        hasPgGroup: false,
    },
    externalMenuFormat: 'web',
    googlePlaceId: 'ChIJN1t_tDeuEmsRUsoyG83frY4',
    discount: {
        type: DiscountTypeEnum.Percentage,
        amount: '0',
    },
    logoSmallUrl: 'https://s3-eu-west-1.amazonaws.com/foodfleet-dev/5f9f9b9b0f9b9c0001b0b0b0/logo-small.png',
    posVendor: {
        config: {
            id: 1,
        },
    },
    opsMode: 'dinein',
    paymentGateways: [],
    timezone: {
        timezone: 'Europe/Istanbul',
        countryCode: 'TR',
    },
    orderMode: null,
};
