import { Config } from 'jest';

const nextJest = require('next/jest');

const createJestConfig = nextJest({
    // Provide the path to your Next.js app to load next.config.js and .env files in your test environment
    dir: './',
});

const config: Config = {
    verbose: true,
    collectCoverageFrom: [
        '**/*.{js,jsx,ts,tsx}',
        '!**/*.d.ts',
        '!**/node_modules/**',
        '!<rootDir>/out/**',
        '!<rootDir>/.next/**',
        '!<rootDir>/*.config.js',
        '!<rootDir>/coverage/**',
        '!<rootDir>/public/**',
    ],
    moduleNameMapper: {
        // Handle CSS imports (without CSS modules)
        '^.+\\.(css|sass|scss)$': '<rootDir>/__test__/__mocks__/styleMock.js',

        // Handle image imports
        // https://jestjs.io/docs/webpack#handling-static-assets
        '^.+\\.(png|jpg|jpeg|gif|webp|avif|ico|bmp|svg)$/i': `<rootDir>/__test__/__mocks__/fileMock.js`,

        '^@/(.*)$': '<rootDir>/src/$1',
        uuid: require.resolve('uuid'),
    },

    setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],
    testEnvironment: 'jest-environment-jsdom',
    // if you need to transform the svgs
    /* transform: {
        '^.+\\.svg$': '<rootDir>/__test__/__mocks__/svgTransform.js',
    }, */

    coverageReporters: ['json', 'html'],
    testMatch: ['**/__tests__/**/*.[jt]s?(x)', '**/(*.)+(spec|test).[jt]s?(x)'],
    coverageThreshold: {
        global: {
            branches: 0,
            functions: 0,
            lines: 0,
            statements: 0,
        },
    },
    modulePathIgnorePatterns: ['<rootDir>/node_modules/canvas'],
};

export default createJestConfig(config);
