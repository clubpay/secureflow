const path = require('path');

module.exports = {
    i18n: {
        defaultLocale: 'en',
        locales: ['en', 'ae', 'jp', 'de', 'pt', 'tr', 'zh', 'hk', 'es', 'en-sg', 'ko', 'ru'],
    },
    ns: ['common'], // the namespaces need to be listed here, to make sure they got preloaded
    serializeConfig: false,
    ...(typeof window === 'undefined' ? { localePath: path.resolve('./public/locales') } : {}),
};
