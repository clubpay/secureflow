import { create } from 'zustand';

type State = {
    email?: string;
    otpId?: string;
    isOtpValid?: boolean;
    voucherCode?: string;
    hasDiscountBeenApplied: boolean;
    amount?: string;
};

type Action = {
    updateEmail: (email: string) => void;
    updateOtpId: (otpId: string) => void;
    updateIsOtpValid: (isOtpValid: boolean) => void;
    updateVoucherCode: (voucherCode: string) => void;
    updateHasDiscountBeenApplied: (hasDiscountBeenApplied: boolean) => void;
    updateDiscountAmount: (amount?: string) => void;
    reset: () => void;
};

const initialState: State = {
    email: undefined,
    otpId: undefined,
    isOtpValid: undefined,
    voucherCode: undefined,
    hasDiscountBeenApplied: false,
    amount: undefined,
};

const useDiscountStore = create<State & Action>((set) => ({
    ...initialState,
    updateEmail: (email) => set(() => ({ email })),
    updateOtpId: (otpId) => set(() => ({ otpId })),
    updateIsOtpValid: (isOtpValid) => set(() => ({ isOtpValid })),
    updateVoucherCode: (voucherCode) => set(() => ({ voucherCode })),
    updateHasDiscountBeenApplied: (hasDiscountBeenApplied) => set(() => ({ hasDiscountBeenApplied })),
    updateDiscountAmount: (amount) => set(() => ({ amount })),
    reset: () => {
        set(initialState);
    },
}));

export default useDiscountStore;
