import { produce } from 'immer';
import { create } from 'zustand';

const initialState: any = {
    isPGGroupEnabled: false,
    paymentHandler: null,
    currentlySelectedPGData: {
        name: '',
    },
    billPaidStatus: '',
};

export const usePGGroupStore = create<any, []>((set) => ({
    state: initialState,
    setPGGroupStatus: (status: boolean) =>
        set(
            produce((store: any) => {
                store.state.isPGGroupEnabled = status;
            }),
        ),
    setCurrentActivePGData: (payload: any) =>
        set(
            produce((store: any) => {
                store.state.currentlySelectedPGData.name = payload.name;
            }),
        ),
    setPaymentHandler: (fn: VoidFunction) =>
        set(
            produce((store: any) => {
                store.state.paymentHandler = fn;
            }),
        ),
    setBillPaidStatus: (status: string) =>
        set(
            produce((store: any) => {
                store.state.billPaidStatus = status;
            }),
        ),
}));
