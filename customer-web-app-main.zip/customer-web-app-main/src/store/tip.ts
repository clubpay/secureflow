import { ITip } from '@/components/Tip/normal/types';
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

type State = {
    normalTip?: ITip;
    isDirty: boolean;
    nonModalDefaultTipOption?: number;
    mostCommonTipOption?: number;
    isNormalTipVisible: boolean;
    isSmartTipOneLinerVisible: boolean;
};

type Action = {
    updateNormalTip: (tip?: ITip) => void;
    updateDirtiness: (isDirty: boolean) => void;
    updateMostCommonTipOption: (mostCommonTipOption?: number) => void;
    updateNonModalDefaultTipOption: (defaultTipOption?: number) => void;
    updateNormalTipVisibility: (isVisible: boolean) => void;
    updateSmartTipOneLinerVisibility: (isVisible: boolean) => void;
    reset: () => void;
};

const initialState: State = {
    normalTip: undefined,
    isDirty: false,
    nonModalDefaultTipOption: undefined,
    mostCommonTipOption: undefined,
    isNormalTipVisible: true,
    isSmartTipOneLinerVisible: false,
};

const useTipStore = create<State & Action>()(
    persist(
        (set) => ({
            ...initialState,
            updateNormalTip: (normalTip) => set(() => ({ normalTip })),
            updateDirtiness: (isDirty) => set(() => ({ isDirty })),
            updateMostCommonTipOption: (mostCommonTipOption) => set(() => ({ mostCommonTipOption })),
            updateNonModalDefaultTipOption: (nonModalDefaultTipOption) => set(() => ({ nonModalDefaultTipOption })),
            updateNormalTipVisibility: (isVisible) => set(() => ({ isNormalTipVisible: isVisible })),
            updateSmartTipOneLinerVisibility: (isVisible) => set(() => ({ isSmartTipOneLinerVisible: isVisible })),
            reset: () => {
                set(initialState);
            },
        }),
        {
            name: 'qlub.tip-store',
            storage: createJSONStorage(() => sessionStorage),
        },
    ),
);

export default useTipStore;
