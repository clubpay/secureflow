import { IPaymentDetails, IPaymentStatus } from '@/repositories/bill/';
import { create } from 'zustand';

export enum PaymentStatus {
    SUCCESS = 'success',
    FAILED = 'failed',
    PENDING = 'pending',
}

export enum DetailedPaymentStatus {
    FULLY_PAID = 'fullyPaid',
    PARTIALLY_PAID = 'partiallyPaid',
    UNPAID = 'unpaid',
    DONE = 'done',
    PENDING = 'pending',
    UNSET = '',
}

type State = {
    isLoading: boolean;
    status: PaymentStatus | undefined;
    detailedPaymentStatus: DetailedPaymentStatus;
    statusData: IPaymentStatus | undefined;
    details: IPaymentDetails | undefined;
    hasMaxTryCountBeenReached: boolean;
};

type Action = {
    updateIsLoading: (isLoading: boolean) => void;
    updatePaymentStatus: (status: PaymentStatus | undefined) => void;
    updateDetailedPaymentStatus: (detailedPaymentStatus: DetailedPaymentStatus | undefined) => void;
    updatePaymentStatusData: (statusData: IPaymentStatus | undefined) => void;
    updatePaymentDetails: (details: IPaymentDetails) => void;
    updateHasMaxTryCountBeenReached: (hasMaxTryCountBeenReached: boolean) => void;
    reset: () => void;
};

const initialState = {
    isLoading: true,
    status: undefined,
    detailedPaymentStatus: DetailedPaymentStatus.UNSET,
    statusData: undefined,
    details: undefined,
    hasMaxTryCountBeenReached: false,
};

const usePaymentStore = create<State & Action>((set) => ({
    ...initialState,
    updateIsLoading: (isLoading) => set(() => ({ isLoading })),
    updatePaymentStatus: (status) => set(() => ({ status })),
    updateDetailedPaymentStatus: (detailedPaymentStatus) => set(() => ({ detailedPaymentStatus })),
    updatePaymentStatusData: (statusData) => set(() => ({ statusData })),
    updatePaymentDetails: (details) => set(() => ({ details })),
    updateHasMaxTryCountBeenReached: (hasMaxTryCountBeenReached) => set(() => ({ hasMaxTryCountBeenReached })),
    reset: () => {
        set(initialState);
    },
}));

export default usePaymentStore;
