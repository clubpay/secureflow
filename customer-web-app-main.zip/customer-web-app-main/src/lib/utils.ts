export const filterEmptyArrays = (arr: any[] | null | undefined): any[] | null => {
    if (arr && arr.length && arr.length > 0) {
        return arr;
    }

    return null;
};

export const addOrBringToStartOfArray = (arr: Array<any>, value: any) => {
    const index = arr?.indexOf(value);

    if (index === -1) {
        arr.unshift(value);
    }

    return arr;
};

export const removeItemFromArrOnce = (arr: Array<any>, value: any) => {
    const index = arr.indexOf(value);

    if (index > -1) {
        arr.splice(index, 1);
    }

    return arr;
};

export const removeItemsFromArr = (arr: Array<any>, value: any) => {
    let i = 0;

    while (i < arr.length) {
        if (arr[i] === value) {
            arr.splice(i, 1);
        } else {
            ++i;
        }
    }

    return arr;
};
