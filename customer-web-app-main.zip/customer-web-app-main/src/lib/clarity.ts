import forEach from 'lodash/forEach';

export const setClarityTags = (tags: { [key: string]: string | undefined }) => {
    if (window.clarity) {
        forEach(tags, (value, key) => window.clarity('set', key, value));
    }
};
