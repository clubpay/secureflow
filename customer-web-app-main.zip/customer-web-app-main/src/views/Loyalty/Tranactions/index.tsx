import Head from 'next/head';
import { NextPageWithLayout } from '@/layout/types';
import TransactionsUI from '@clubpay/loyalty/dist/drivers/customer/Transactions';

export const Transactions: NextPageWithLayout = () => {
    return (
        <>
            <Head>
                <title>Qlub_ | Loyalty | Transactions</title>
            </Head>
            <TransactionsUI />
        </>
    );
};

export default Transactions;
