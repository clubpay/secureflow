import Head from 'next/head';
import { NextPageWithLayout } from '@/layout/types';
import VenuesUI from '@clubpay/loyalty/dist/drivers/customer/Venues';

export const Venues: NextPageWithLayout = () => {
    return (
        <>
            <Head>
                <title>Qlub_ | Loyalty | Venues</title>
            </Head>
            <VenuesUI />
        </>
    );
};

export default Venues;
