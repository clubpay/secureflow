import Head from 'next/head';
import { NextPageWithLayout } from '@/layout/types';
import VenuesUISEO from '@clubpay/loyalty/dist/drivers/customer/Venues/seo';

export const VenuesSEO: NextPageWithLayout = () => {
    return (
        <>
            <Head>
                <title>Qlub_ | Loyalty | Venues</title>
            </Head>
            <VenuesUISEO />
        </>
    );
};

export default VenuesSEO;
