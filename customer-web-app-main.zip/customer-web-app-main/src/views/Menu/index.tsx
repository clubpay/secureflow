/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import { useEffect } from 'react';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getMenuPath } from '@clubpay/customer-common-module/src/utility/menuLink';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';

const Menu = () => {
    const { routerPush } = useQlubRouter();
    const { vendor } = useVendor();
    const { config: countryConfig } = useConfigContext();

    useEffect(() => {
        if (!vendor || !countryConfig) {
            return;
        }

        routerPush(getMenuPath({ vendor, countryConfig }));
    }, [vendor, countryConfig]);

    return null;
};

export default Menu;
