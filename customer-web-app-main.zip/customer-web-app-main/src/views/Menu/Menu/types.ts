import { ILocaleValue } from '@clubpay/customer-common-module/src/component/MultiLocale';

export type MenuColor = 'green' | 'pink' | 'purple' | 'orange' | 'blue';
export interface ISelectedMenuLink {
    link: IMenuLink;
    languageBasedMenuLink: string;
    pdfPriority: string[] | string;
}

export interface IMenuLinks {
    links?: IMenuLink[];
    languageBasedMenu?: Array<ILocaleValue>;
    pdfPriority: string[] | string;
    advanced: boolean | undefined;
}

export interface IMenuLink {
    title: Array<ILocaleValue>;
    description: Array<ILocaleValue>;
    image: string;
    link: string;
    linkWithLocale: Array<ILocaleValue>;
    color: MenuColor;
    status: boolean;
    redirect?: boolean;
    newTab?: boolean;
}
