import React, { useEffect, useState } from 'react';
import Head from 'next/head';
import { QSRRouterModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { getAvailableLang } from '@clubpay/customer-common-module/src/utility/k_lang';
import { getDiningSession, getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { useTheme } from '@mui/material';
import { NextPageWithLayout } from '@/layout/types';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import MenuSubHeader from '@/components/Menu/SubHeader/MenuSubHeader';
import MenuContent from '@/components/Menu/MenuContent/MenuContent';
import Loading from '@qlub-dev/qlub-kit/dist/components/Loading';
import VendorAPIManager, {
    IQrDetailsResponse,
    MenuPageDescriptionModeEnum,
} from '@clubpay/customer-common-module/src/repository/vendor';
import { viewMenuEvent } from '@clubpay/customer-common-module/src/utility/menuLink';
import BillAPIManager from '@/repositories/bill';
import { FetchModeEnum } from '@/repositories/bill/enums';

import styles from './index.module.scss';

const Menu: NextPageWithLayout = () => {
    const [loading, setLoading] = useState(true);
    const { url, push, lang, source, isQSR } = useQlubRouter();
    const { vendor, error, loading: vendorLoading } = useVendor();
    const { config } = useConfigContext();
    const theme = useTheme();

    const [qrDetails, setQrDetails] = useState<IQrDetailsResponse | undefined>(undefined);
    const diningSessionPayload = getDiningSession(url);

    /**
     * Handles the first visit log to the menu page.
     * @returns {void}
     */
    const handleFirstVisitLog = () => {
        const onlyMenuVendor = vendor?.config.onlyMenuVendor === undefined ? false : vendor?.config.onlyMenuVendor;

        onPushEvent(viewMenuEvent, {
            opsMode: vendor?.opsMode,
            restaurant_name: url.slug,
            source,
            diningSessionId: diningSessionPayload?.id,
            pg_name: vendor?.availablePGs,
            menuPageMode: 'new',
            onlyMenuVendor,
            menuMode: vendor?.config.menuMode,
        });
    };

    /**
     * Fetches qr details asynchronously.
     * @returns {Promise<void>} A promise that resolves once the qr details are fetched.
     */
    const getQrDetails = () => {
        switch (vendor?.config.menuPageDescriptionMode || config?.menuPageDescriptionMode) {
            case MenuPageDescriptionModeEnum.TableName:
                BillAPIManager.getInstance()
                    .getDetails(
                        {
                            id: getSession(),
                            diningSessionID: diningSessionPayload?.id || '0',
                            cc: url.cc,
                            restaurantUnique: url.slug,
                            tableID: url.id,
                            f1: url.f1,
                            f2: url.f2,
                            hash: url.hash,
                            forceFresh: false,
                            jwt: diningSessionPayload?.jwt || undefined,
                            fetchMode: url.fetchMode as FetchModeEnum,
                            payUrl: url.qPayUrl,
                        },
                        {
                            vendor,
                            cc: url.cc,
                            qsr: isQSR && url.qsr !== QSRRouterModeEnum.Mixed,
                        },
                    )
                    .then((res) => {
                        setQrDetails({
                            table: {
                                id: res.tableID,
                                preferredName: res.tablePreferredName || '',
                                revenueCenter: url.f1,
                                section: url.f2,
                                tableName: res.tableName || '',
                            },
                        });
                    })
                    .catch(() => {
                        setQrDetails({
                            table: {
                                id: url.id,
                                tableName: '',
                                section: '',
                                revenueCenter: '',
                                preferredName: '',
                            },
                        });
                    });
                break;
            default:
                VendorAPIManager.getInstance()
                    .getQrDetails({
                        cc: url.cc,
                        restaurantUnique: url.slug,
                        tableID: url.id,
                        f1: url.f1,
                        f2: url.f2,
                        hash: url.hash,
                    })
                    .then((res) => {
                        setQrDetails(res);
                    })
                    .catch(() => {
                        setQrDetails({
                            table: {
                                id: url.id,
                                tableName: '',
                                section: '',
                                revenueCenter: '',
                                preferredName: '',
                            },
                        });
                    });
                break;
        }
    };

    useEffect(() => {
        if (!vendor || vendorLoading || !url.id || url.id === '_') {
            return;
        }

        getQrDetails();
        handleFirstVisitLog();
    }, [vendor, vendorLoading, url.id]);

    useEffect(() => {
        if (!error) {
            return;
        }
        push({
            pathname: '/',
            query: {
                ...getAvailableLang(lang),
            },
        });
    }, [error]);

    /**
     * Renders the subheader component based on 'vendor' and 'qrDetails' props.
     *
     * @returns {React.ReactElement|null} The rendered subheader component or null if 'vendor' or 'qrDetails' is falsy.
     */
    const renderSubHeader = () => {
        if (!vendor || !config) return null;

        return <MenuSubHeader vendor={vendor} qrDetails={qrDetails} url={url} theme={theme} countryConfig={config} />;
    };

    /**
     * Renders the wrapper component based on 'vendor' and 'qrDetails' props.
     *
     * @returns {React.ReactElement|null} The rendered wrapper component or null if 'vendor' is falsy or not a menu vendor.
     */
    const renderWrapper = () => {
        if (vendor && config) {
            return (
                <div className={styles.menu}>
                    {renderSubHeader()}

                    {loading && (
                        <div className={styles.loading}>
                            <Loading color="outlined" />
                        </div>
                    )}
                    <div
                        style={
                            loading
                                ? {
                                      display: 'none',
                                      visibility: 'hidden',
                                      opacity: 0,
                                      transition: 'visibility 300ms linear 300ms, opacity 300ms display 300ms',
                                  }
                                : {}
                        }
                    >
                        {vendor.config.onlyMenuVendor && renderSubHeader}
                        <div
                            style={
                                !vendor.config.onlyMenuVendor
                                    ? {
                                          minHeight: 'calc(100vh - 152px)',
                                      }
                                    : {}
                            }
                        >
                            <MenuContent
                                vendor={vendor}
                                qrDetails={qrDetails}
                                theme={theme}
                                lang={lang}
                                countryConfig={config}
                                setLoading={setLoading}
                                loading={loading}
                            />
                        </div>
                    </div>
                </div>
            );
        }
        return null;
    };

    return (
        <>
            <Head>
                <title>Qlub_ | {url.slug} Menu</title>
            </Head>
            {renderWrapper()}
        </>
    );
};

export default Menu;
