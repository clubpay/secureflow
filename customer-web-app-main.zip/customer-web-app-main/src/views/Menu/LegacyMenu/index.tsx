/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useEffect, useMemo, useState } from 'react';
import Head from 'next/head';
import { Drawer, Grid, IconButton, useTheme } from '@mui/material';
import PDFWidget from '@/components/Menu/PDF';
import { QSRRouterModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { getAvailableLang } from '@clubpay/customer-common-module/src/utility/k_lang';
import { NextPageWithLayout } from '@/layout/types';
import MenuList from '@/components/Menu/Legacy/MenuList';
import { CustomerGrid, Divider, Button, SubHeader, Trivia } from '@qlub-dev/qlub-kit';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { ILocaleValue } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { MenuModeEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Link from 'next/link';
import { KeyboardArrowLeftRounded, KeyboardArrowRightRounded } from '@mui/icons-material';
import Router from 'next/router';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { getDiningSession, getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import TableName from '@/components/Bill/TableName';
import { qlubLocalStorage } from '@clubpay/customer-common-module/src/service/storage/localStorage';
import Loading from '@qlub-dev/qlub-kit/dist/components/Loading';
import BillAPIManager, { IPaymentDetails } from '@/repositories/bill';
import { FetchModeEnum } from '@/repositories/bill/enums';

import styles from './index.module.scss';

export interface ISelectedMenuLink {
    link: IMenuLink;
    pdfPriority: string[] | string;
}

export interface IMenuLinks {
    links?: IMenuLink[];
    pdfPriority: string[] | string;
    advanced: boolean | undefined;
}

export type MenuColor = 'green' | 'pink' | 'purple' | 'orange' | 'blue';

export interface IMenuLink {
    title: Array<ILocaleValue>;
    description: Array<ILocaleValue>;
    image: string;
    link: string;
    color: MenuColor;
    status: boolean;
    redirect?: boolean;
    newTab?: boolean;
}

const Menu: NextPageWithLayout = () => {
    const { vendor, error, tableInfo } = useVendor();
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const { url, lang, push, getRouterParam, source, isQSR } = useQlubRouter();
    const theme = useTheme();
    const [, setMultiLink] = useState(false);
    const { t } = useTranslation('common');
    const [isInfo, setIsInfo] = useState(false);

    const [drawerOpen, setDrawerOpen] = useState(false);
    const [selectedMenu, setSelectedMenu] = useState<ISelectedMenuLink | undefined>(undefined);
    const [details, setDetails] = useState<IPaymentDetails | undefined>(undefined);
    const [newLoading, setNewLoading] = useState(true);

    const infoClickHandler = () => {
        qlubLocalStorage.set('qlub.digital_menu.visited', 'true');
        setIsInfo(true);
        onPushEvent('tapOnInformingBox', {
            vendor: vendor?.title,
        });
    };

    useEffect(() => {
        const diningSessionPayload = getDiningSession(url);
        const onlyMenuVendor = vendor?.config.onlyMenuVendor === undefined ? false : vendor?.config.onlyMenuVendor;

        onPushEvent('view_menu', {
            opsMode: vendor?.opsMode,
            restaurant_name: url.slug,
            source,
            diningSessionId: diningSessionPayload?.id,
            pg_name: vendor?.availablePGs,
            menuPageMode: 'old',
            onlyMenuVendor,
            menuMode: vendor?.config.menuMode,
        });

        const visited = qlubLocalStorage.get('qlub.digital_menu.visited') === 'true';
        setIsInfo(visited);
    }, []);

    const getDetails = () => {
        if (!url.id || url.id === '_') {
            return;
        }
        const diningSessionPayload = getDiningSession(url);

        BillAPIManager.getInstance()
            .getDetails(
                {
                    id: getSession(),
                    diningSessionID: diningSessionPayload?.id || '0',
                    cc: url.cc,
                    restaurantUnique: url.slug,
                    tableID: url.id,
                    f1: url.f1,
                    f2: url.f2,
                    hash: url.hash,
                    forceFresh: false,
                    jwt: diningSessionPayload?.jwt || undefined,
                    fetchMode: url.fetchMode as FetchModeEnum,
                    payUrl: url.qPayUrl,
                },
                {
                    cc: url.cc,
                    vendor,
                    qsr: isQSR && url.qsr !== QSRRouterModeEnum.Mixed,
                },
            )
            .then((res) => {
                setDetails(res);
            });
    };

    useEffect(() => {
        if (vendor?.config?.previewBill) {
            getDetails();
        }
    }, [vendor?.config.previewBill]);

    useEffect(() => {
        if (error) {
            push({
                pathname: '/',
                query: {
                    ...getAvailableLang(lang),
                },
            });
        }
    }, [error]);

    const iframeLoadHandler = () => {
        setNewLoading(false);
    };

    const getMenuLinks = (): IMenuLinks | null => {
        try {
            if (vendor?.config?.menuLinks) {
                return JSON.parse(vendor.config.menuLinks);
            }
        } catch (err) {
            console.log('Error parsing JSON at get menu links:', err, vendor?.config);
        }
        return null;
    };

    const toggleDrawerHandler = (open: boolean, menu?: ISelectedMenuLink) => {
        if (open) {
            setSelectedMenu(menu);

            setTimeout(() => {
                setDrawerOpen(open);
            }, 100);
            return;
        }
        setDrawerOpen(open);
        setTimeout(() => {
            setSelectedMenu(undefined);
        }, 100);
    };

    const menuContent = useMemo(() => {
        if (!vendor) {
            return null;
        }

        const getMultiMenu = (ml: IMenuLinks | null) => {
            return (
                <MenuList
                    menuLinks={ml}
                    toggleDrawer={toggleDrawerHandler}
                    vendorTitle={vendor.title}
                    setNewLoading={setNewLoading}
                />
            );
        };

        const getExternalMenu = () => {
            return (
                <Grid container xs={12}>
                    <div className={styles.iframe}>
                        <iframe
                            title="External Menu"
                            src={vendor.config.externalMenuUrl}
                            onError={(err: any) => {
                                enqueueSnackbar(err.message, { variant: 'error' });
                            }}
                            onLoad={iframeLoadHandler}
                        />
                    </div>
                </Grid>
            );
        };

        const getPDFMenu = () => {
            return (
                <Grid container xs={12} sx={{ padding: '24px 24px 0px 24px' }}>
                    <PDFWidget
                        url={vendor.externalMenuUrl}
                        priority={vendor.config.pdfPriority || []}
                        setNewLoading={setNewLoading}
                    />
                </Grid>
            );
        };

        const getDefault = () => {
            const menuLinks = getMenuLinks();
            if (menuLinks?.links && menuLinks?.links.length > 0 && menuLinks?.links.some((link) => link.status)) {
                setMultiLink(true);
                return getMultiMenu(menuLinks);
            }
            setMultiLink(false);

            if (vendor.config.externalMenuUrl) {
                return getExternalMenu();
            }

            if (vendor.externalMenuUrl) {
                return getPDFMenu();
            }

            return null;
        };

        setMultiLink(false);

        switch (vendor.config?.menuMode) {
            default:
                return getDefault();
            case MenuModeEnum.ExternalUrl:
            case MenuModeEnum.ExternalUrlSameTab:
                return getExternalMenu();
            case MenuModeEnum.PdfMenuIOSRedirect:
            case MenuModeEnum.PDFMenu:
                return getPDFMenu();
            case MenuModeEnum.MultiMenu: {
                const menuLinks = getMenuLinks();
                if (menuLinks?.links && menuLinks?.links.length > 0 && menuLinks?.links.some((link) => link.status)) {
                    setMultiLink(true);
                    return getMultiMenu(menuLinks);
                }
            }
        }
        return getDefault();
    }, [lang, vendor, theme.direction, newLoading]);

    const drawerMenuContent = useMemo(() => {
        if (!selectedMenu) {
            return null;
        }

        return (
            <Drawer
                anchor="bottom"
                open={drawerOpen}
                onClose={() => toggleDrawerHandler(false)}
                BackdropProps={{ sx: { background: '#00000099' } }}
                PaperProps={{
                    elevation: 0,
                    sx: {
                        height: '100vh',
                        background: 'white',
                        position: 'relative',
                        maxWidth: '552px',
                        width: '100%',
                    },
                }}
                sx={{ display: 'flex', justifyContent: 'center' }}
            >
                {newLoading && (
                    <div className={styles.loading}>
                        <Loading color="outlined" />
                    </div>
                )}
                <div className={styles.subHeader}>
                    <SubHeader
                        subTitle={vendor?.title || ''}
                        title={<TableName tableInfo={tableInfo} vendor={vendor} details={details} />}
                        initialIcon={
                            vendor?.config.onlyMenuVendor === false && (
                                <IconButton
                                    sx={{
                                        height: '24px',
                                        width: '24px',
                                        color: theme.qlub.palette.onSurfaceColors.highEmphasis,
                                        marginRight: '16px',
                                    }}
                                    onClick={() => toggleDrawerHandler(false)}
                                >
                                    {theme.direction === 'ltr' ? (
                                        <KeyboardArrowLeftRounded />
                                    ) : (
                                        <KeyboardArrowRightRounded />
                                    )}
                                </IconButton>
                            )
                        }
                        CTA={
                            vendor?.config.onlyMenuVendor === false && (
                                <Button variant="text" sx={{ px: 0, width: '100%' }} disableRipple>
                                    <Link
                                        href={getRouterParam('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice', {
                                            source: 'menuPage',
                                        })}
                                    >
                                        {t('Pay the bill')}
                                    </Link>
                                </Button>
                            )
                        }
                        sx={{ marginTop: '16px', padding: ' 0px 16px 6px 16px' }}
                    />
                    <Divider type="fullWidth" />
                </div>
                <div className={styles.drawer}>
                    {selectedMenu && (
                        <PDFWidget
                            url={selectedMenu?.link.link}
                            priority={selectedMenu?.pdfPriority}
                            isCalledFromDrawer
                            setNewLoading={setNewLoading}
                        />
                    )}
                </div>
            </Drawer>
        );
    }, [selectedMenu, lang, drawerOpen, newLoading]);

    return (
        <>
            <Head>
                <title>Qlub_ | {url.slug} Menu</title>
            </Head>
            <div className={styles.menu}>
                <div className={styles.subHeader}>
                    <SubHeader
                        subTitle={vendor?.title || ''}
                        title={<TableName tableInfo={tableInfo} vendor={vendor} details={details} />}
                        initialIcon={
                            vendor?.config.onlyMenuVendor === false && (
                                <IconButton
                                    sx={{
                                        height: '24px',
                                        width: '24px',
                                        color: theme.qlub.palette.onSurfaceColors.highEmphasis,
                                        marginRight: '16px',
                                    }}
                                    onClick={() => Router.back()}
                                >
                                    {theme.direction === 'ltr' ? (
                                        <KeyboardArrowLeftRounded />
                                    ) : (
                                        <KeyboardArrowRightRounded />
                                    )}
                                </IconButton>
                            )
                        }
                        CTA={
                            vendor?.config.onlyMenuVendor === false && (
                                <Button variant="text" sx={{ px: 0, width: '100%' }} disableRipple>
                                    <Link
                                        href={getRouterParam('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice', {
                                            source: 'menuPage',
                                        })}
                                    >
                                        {t('Pay the bill')}
                                    </Link>
                                </Button>
                            )
                        }
                        sx={{ padding: ' 8px 16px 6px 16px' }}
                    />
                    {vendor?.title && <Divider type="fullWidth" />}
                </div>

                <div className={styles.menuContent}>
                    {!vendor?.config.onlyMenuVendor && !isInfo && (
                        <div className={styles.info}>
                            <Trivia
                                textOverrides={{
                                    flex: '1 1',
                                }}
                                message={t('Did you know you can pay for your bill on qlub too?')}
                                onClickClose={() => infoClickHandler()}
                            />
                        </div>
                    )}
                    <CustomerGrid container spacing={0}>
                        {menuContent}
                    </CustomerGrid>
                </div>
                {newLoading && (
                    <div className={styles.loading}>
                        <Loading color="outlined" />
                    </div>
                )}
                {drawerMenuContent}
            </div>
        </>
    );
};
export default Menu;
