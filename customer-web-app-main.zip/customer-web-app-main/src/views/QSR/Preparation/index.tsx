import React, { useCallback, useEffect, useState } from 'react';
import { Paper, SwipeableDrawer } from '@mui/material';
import Head from 'next/head';
import { CustomerContainer, SplitPriceLabel, TotalPrice, Trivia } from '@qlub-dev/qlub-kit';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import MenuAPIManager from '@/repositories/menu';
import { useLayout } from '@clubpay/customer-common-module/src/context/layout';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { QSRRouterModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { BasketContextProvider, useBasket } from '@/contexts/basket';
import { getSSBasket, removeSSBasket, setBasketOrderId } from '@/services/session/basket';
import { IEventOrder, SocketEventEnum, SocketService } from '@/services/socket';
import { IProduct, IQSROrder, OrderPaymentStatusEnum, OrderStatusEnum } from '@/repositories/menu/types';
import QSRPreparationOrder from '@/components/QSR/QSRPreparationOrder';
import MultiLocale, { validateMultiLocale } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { debounce, isNil, omitBy } from 'lodash';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import { CustomerDetailsModeEnum, OrderPaymentMethodEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import QSRCustomerDetailsWrapper from '@/components/QSR/QSRCustomerDetailsWrapper';
import { NextPageWithLayout } from '@/layout/types';
import Format from '@qlub-dev/qlub-kit/dist/components/Format';
import QSRPreparationFooter from '@/components/QSR/QSRPreparationFooter';
import QSROrderBatchList from '@/components/QSR/QSROrderBatchList';
import { PGNameEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import getMenuLink from '@clubpay/customer-common-module/src/utility/menuLink';
import { OrderModeEnum, OrderPricePresentationEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';
import SkeletonComponent from '@/components/QSR/QSRPreparationFooter/skeleton';
import SocialMedia from '@/components/Bill/SocialMedia';
import BillAPIManager from '@/repositories/bill';
import { IPaymentStatusRes } from '@/repositories/bill/types';
import { getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import LoyaltyEarn from '@clubpay/loyalty/dist/drivers/customer/Earn';
import useLoyaltyEvents from '@clubpay/loyalty/dist/hooks/analytics';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import { CheckCircleRounded } from '@mui/icons-material';
import Review from '@/components/Review';
import { resetDiningOption } from '@/components/QSR/QSRDiningOptionModal';
import QSRPreparationStatus from '@/components/QSR/QSRPreparationStatus';
import { getUrlStringFromUrlData } from '@/services/utils/k_qsr';
import BannerAPIManager from '@/repositories/banner';
import { SliderLocationEnum, SliderPositionEnum } from '@clubpay/customer-common-module/src/component/KSlider/enums';
import QSRBanner from '@/components/QSR/QSRBanner';

import styles from './index.module.scss';

const QSRPreparation: NextPageWithLayout = () => {
    const { t } = useTranslation('common');
    const { setBackFn } = useLayout();
    const { url, lang, routerPush, query, push: urlPush, back } = useQlubRouter();
    const { dsi, ref, sid } = query as {
        dsi: string;
        ref: string;
        sid?: string;
    };
    const { method: vendorGateway } = query as {
        method?: string;
        paymentElement?: string;
    };
    const { qOrderId: orderId } = url;
    const { vendor, currencyFormat } = useVendor();
    const { setBasket } = useBasket();
    const loyaltyEvents = useLoyaltyEvents();

    const menuApi = MenuAPIManager.getInstance();
    const socketService = SocketService.getInstance();
    const apiManager = BillAPIManager.getInstance();
    const bannerApi = BannerAPIManager.getInstance();

    const [order, setOrder] = useState<IQSROrder | undefined>(undefined);
    const [paymentStatus, setPaymentStatus] = useState<IPaymentStatusRes | undefined>(undefined);
    const [drawerOpen, setDrawerOpen] = useState(false);
    const [drawerLoading, setDrawerLoading] = useState(false);
    const [orderLoading, setOrderLoading] = useState(false);
    const [productMap, setProductMap] = useState<{
        [key: string]: IProduct;
    }>({});
    const [showInfo, setShowInfo] = useState(true);
    const [bannerPosition, setBannerPosition] = useState<SliderPositionEnum | null>(null);

    const {
        qsr: { qsrPageViewEvent, qsrPayNowButtonSelected },
    } = useQsrEventsCenter();

    const menuLink = getMenuLink(url, lang, 'preparation');

    const backHandler = useCallback(() => {
        if (vendor?.orderConfig?.paymentMethod !== OrderPaymentMethodEnum.Default) {
            back();
        }
        routerPush(
            vendor?.orderMode === OrderModeEnum.Mixed
                ? '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice'
                : '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice/checkout',
            {
                qsr: vendor?.orderMode === OrderModeEnum.Mixed ? QSRRouterModeEnum.Mixed : QSRRouterModeEnum.True,
                qOrderId: orderId,
                source: 'menuPage',
            },
        );
    }, []);

    useEffect(() => {
        setBackFn(backHandler);
    }, [backHandler]);

    useEffect(() => {
        qsrPageViewEvent('qsrPreparation');
        window.addEventListener('visibilitychange', debouncedGetOrderHandler);
        window.addEventListener('focus', debouncedGetOrderHandler);

        return () => {
            window.removeEventListener('visibilitychange', debouncedGetOrderHandler);
            window.removeEventListener('focus', debouncedGetOrderHandler);
        };
    }, []);

    useEffect(() => {
        if (!vendor?.config.comoV2EarnWithoutLogin && !ref) {
            return;
        }

        if (OrderPaymentStatusEnum.Success) {
            loyaltyEvents.general.checkAndFireServiceEnabled();
        }
    }, [vendor?.config, ref]);

    useEffect(() => {
        if (!vendor?.config.comoV2EarnWithoutLogin) {
            return;
        }

        if (!order || !(ref || order.meta?.reference)) {
            setPaymentStatus(undefined);
            return;
        }

        apiManager
            .getStatus({
                id: getSession(sid),
                reference: ref || order.meta?.reference || '',
                diningSessionID: dsi || order.meta?.dsi || '',
            })
            .then((res) => {
                setPaymentStatus(res);
            })
            .catch((err: any) => {
                console.log(err, 'err');
            });
    }, [order, ref, vendor]);

    useEffect(() => {
        if (!url.cc || !url.slug || !url.id) {
            return;
        }

        resetDiningOption();
        removeSSBasket();
        setBasket(getSSBasket());

        if (url.qsr && orderId) {
            getOrder();
            socketService
                .connect({
                    orderId,
                })
                .catch((err) => {
                    // TODO: catch error
                    console.log(err);
                });

            const cancellers = [
                socketService.on(SocketEventEnum.Order, orderUpdateHandler),
                socketService.on(SocketEventEnum.Disconnect, socketDisconnectHandler),
            ];

            return () => {
                socketService.destroy();
                cancellers.forEach((fn) => {
                    fn();
                });
            };
        }
    }, [url.qsr, orderId]);

    useEffect(() => {
        bannerApi
            .getBanner(url, SliderLocationEnum.QSRPreparationPage)
            .then((res) => {
                if (res?.rows?.length > 0) {
                    const position = res.rows[0].meta?.placement;
                    setBannerPosition(position ? (position as SliderPositionEnum) : SliderPositionEnum.Middle);
                }
            })
            .catch((err) => console.log(err));
    }, [url]);

    useEffect(() => {
        if (!orderId) {
            return;
        }
        setOrderLoading(true);
        menuApi
            .getOrder(url, orderId, { vendor })
            .then((res: IQSROrder) => {
                setOrder({
                    ...res,
                });
            })
            .catch((err) => console.log(err))
            .finally(() => setOrderLoading(false));
    }, [orderId]);

    const newVendorGateway = vendorGateway?.toLowerCase() as PGNameEnum;

    const debouncedGetOrderHandler = useCallback(
        debounce(() => {
            if (document.hidden !== true) {
                getOrder();
            }
        }, 512),
        [],
    );

    const showPayment = Boolean(
        vendor &&
            order &&
            ![
                OrderStatusEnum.DECLINED,
                OrderStatusEnum.CANCELLED,
                OrderStatusEnum.FAILED,
                OrderStatusEnum.SYNC_FAILED,
            ].includes(order?.orderStatus || OrderStatusEnum.PENDING) &&
            vendor?.orderConfig?.paymentMethod === OrderPaymentMethodEnum.PayLater &&
            order?.paymentStatus !== OrderPaymentStatusEnum.Success,
    );

    const showPrices = vendor?.orderConfig?.pricePresentation !== OrderPricePresentationEnum.HidePrice;

    const orderUpdateHandler = (e: IEventOrder) => {
        setOrder((o) => {
            if (!o) {
                return e.details;
            }
            return {
                ...o,
                ...omitBy(e.details, isNil),
            };
        });
    };

    const getOrder = () => {
        if (!orderId) {
            return;
        }
        setOrderLoading(true);
        menuApi
            .getOrder(url, orderId, { vendor })
            .then((res: IQSROrder) => {
                setOrder({
                    ...res,
                });
            })
            .catch((err: any) => console.log(err))
            .finally(() => setOrderLoading(false));
    };

    const socketDisconnectHandler = () => {
        getOrder();
    };

    const infoClickHandler = () => {
        setShowInfo(false);
        onPushEvent('tapOnInformingBox', {
            vendor: vendor?.title,
        });
    };

    const drawerHandler = (open: boolean) => {
        if (!order) {
            return;
        }
        setDrawerOpen(open);
        if (open) {
            setDrawerLoading(true);
            menuApi
                .getManyProduct(
                    url,
                    order.orderData.items.map((o) => ({ productId: o.id, menuId: o.menuId })),
                    vendor,
                )
                .then((res) => {
                    setProductMap(res);
                })
                .finally(() => {
                    setDrawerLoading(false);
                });
        }
    };

    const payNowHandler = useCallback(() => {
        qsrPayNowButtonSelected();
        routerPush(
            vendor?.orderMode === OrderModeEnum.Mixed
                ? '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice'
                : '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice/checkout',
            {
                source: 'preparation',
                ...(order?.paymentUrlData?.tableId ? { qPayUrl: getUrlStringFromUrlData(order.paymentUrlData) } : {}),
            },
        );
    }, [vendor, order]);

    const modifyBasketHandler = (modify?: boolean) => {
        if (modify && showPayment && order?.orderData) {
            setBasketOrderId(order.refId);
            setBasket({ ...order?.orderData, note: order.customerComment });
        }
        urlPush(menuLink);
    };

    return (
        <BasketContextProvider>
            <Head>
                <title>Qlub_ | Preparing</title>
            </Head>
            <CustomerContainer maxWidth="sm" className={styles.mainContainer}>
                <Paper elevation={0} className={styles.paper}>
                    <QSRPreparationStatus
                        order={order}
                        loading={orderLoading}
                        showPayment={showPayment}
                        bannerComponent={
                            bannerPosition === SliderPositionEnum.Top ||
                            bannerPosition === SliderPositionEnum.Middle ? (
                                <QSRBanner location={SliderLocationEnum.QSRPreparationPage} position={bannerPosition} />
                            ) : undefined
                        }
                    />
                    {paymentStatus?.loyalty?.redemptions && (
                        <TypographyT
                            typo="body_sm"
                            sx={{
                                paddingTop: '8px',
                                fontSize: '12px',
                            }}
                        >
                            <CheckCircleRounded className={styles.checkIcon} />
                            {interpolateT(t('You redeemed <price>'), {
                                price: (
                                    <Format
                                        currencyFormat={currencyFormat}
                                        value={paymentStatus?.loyalty?.redemptions[0].amount.toString() || ''}
                                        sx={{
                                            fontFamily: 'inherit',
                                            fontColor: '#22A958',
                                            fontWeight: '500',
                                            fontSize: '14px',
                                            letterSpacing: '0.0015em',
                                        }}
                                    />
                                ),
                            })}
                        </TypographyT>
                    )}
                    {paymentStatus && (
                        <LoyaltyEarn
                            gatewayPaymentMethod={paymentStatus?.record?.gatewayPaymentMethod}
                            gatewayVendor={paymentStatus?.record?.gatewayVendor}
                            earnings={paymentStatus?.loyalty?.earnings}
                            redemptions={paymentStatus?.loyalty?.redemptions}
                            api={{
                                bill: BillAPIManager.getInstance() as any,
                            }}
                        />
                    )}
                    <QSROrderBatchList order={order} payLater={showPayment} loading={orderLoading} />
                    {bannerPosition === SliderPositionEnum.Bottom && (
                        <QSRBanner
                            location={SliderLocationEnum.QSRPreparationPage}
                            position={SliderPositionEnum.Bottom}
                        />
                    )}
                    {vendor?.orderConfig?.customerDetailsMode === CustomerDetailsModeEnum.Preparation && (
                        <QSRCustomerDetailsWrapper withButton diningOption={order?.diningOption} />
                    )}
                    <div className={styles.gap} />
                    {showInfo &&
                        !vendor?.orderConfig?.preparationInfoDisable &&
                        validateMultiLocale(vendor?.orderConfig?.preparationInfoText || '') && (
                            <div className={styles.prepInfo}>
                                <Trivia
                                    message={
                                        <MultiLocale
                                            value={vendor?.orderConfig?.preparationInfoText || ''}
                                            lang={lang}
                                            Component="p"
                                        />
                                    }
                                    onClickClose={infoClickHandler}
                                />
                            </div>
                        )}
                    {showPrices &&
                        showPayment &&
                        (orderLoading && !order ? (
                            <SkeletonComponent />
                        ) : (
                            <div className={styles.bill}>
                                <TotalPrice
                                    priceData={[
                                        {
                                            label: SplitPriceLabel.yourShare,
                                            text: t('Total Bill'),
                                            value: order?.total,
                                        },
                                    ]}
                                    footerText={t('Inclusive of all taxes and charges', { useLocale: true })}
                                    currencyFormat={currencyFormat}
                                />
                            </div>
                        ))}
                    {(order?.meta?.dsi || dsi) && (
                        <Review
                            show={
                                order?.paymentStatus === OrderPaymentStatusEnum.Success &&
                                order?.orderStatus !== OrderStatusEnum.SCHEDULED
                            }
                            paymentGateway={newVendorGateway}
                            dividerPosition="top"
                        />
                    )}
                    <SocialMedia />
                    <QSRPreparationFooter
                        order={order}
                        payLater={showPayment}
                        showPrices={showPrices}
                        onPay={payNowHandler}
                        obModify={modifyBasketHandler}
                    />
                </Paper>
            </CustomerContainer>
            <SwipeableDrawer
                anchor="bottom"
                open={drawerOpen}
                onClose={() => drawerHandler(false)}
                onOpen={() => drawerHandler(true)}
                BackdropProps={{ sx: { background: '#00000099' } }}
                PaperProps={{
                    elevation: 0,
                    sx: {
                        minHeight: 'calc((var(--vh, 1vh) * 100))',
                        maxWidth: '552px',
                        margin: 'auto',
                        background: 'white',
                    },
                }}
            >
                <QSRPreparationOrder
                    loading={drawerLoading}
                    productMap={productMap}
                    order={order}
                    onClose={() => drawerHandler(false)}
                />
            </SwipeableDrawer>
        </BasketContextProvider>
    );
};

export default QSRPreparation;
