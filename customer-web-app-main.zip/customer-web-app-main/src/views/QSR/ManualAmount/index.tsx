import React, { useMemo, useRef, useState } from 'react';
import Head from 'next/head';
import { NextPageWithLayout } from '@/layout/types';
import { Button, NewLoading, Price } from '@qlub-dev/qlub-kit';
import { IOrderData, IQSROrder } from '@/repositories/menu/types';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { v4 as uuidv4 } from 'uuid';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { calculateTotalPrice } from '@/services/utils/k_order';
import MenuAPIManager from '@/repositories/menu';
import { getBasketOrderId, setBasketOrderId } from '@/services/session/basket';
import { BasketContextProvider, useBasket } from '@/contexts/basket';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import { SubmitFuncType } from '@/components/QSR/QSRCustomerDetails';
import { CustomerDetailsModeEnum, OrderPaymentMethodEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import QSRCustomerDetailsWrapper from '@/components/QSR/QSRCustomerDetailsWrapper';
import classNames from 'classnames';
import { TextField } from '@mui/material';
import { faToEn } from '@clubpay/customer-common-module/src/utility/localize';
import { getCurrencyPrecision } from '@clubpay/customer-common-module/src/utility/k_currency';
import { useQsrError } from '@/hooks/qsrError';

import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import styles from './index.module.scss';

const QSRManualAmount: NextPageWithLayout = () => {
    const menuApi = MenuAPIManager.getInstance();
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const { basket, setBasket } = useBasket();
    const { vendor, currencyFormat } = useVendor();
    const { url, routerPush } = useQlubRouter();
    const [loading, setLoading] = useState(false);
    const customerDetailsFetchRef = useRef<SubmitFuncType | undefined>(undefined);
    const { handleError } = useQsrError();

    const { getRecaptchaToken } = useAuth();

    const {
        qsr: { qsrProceedToCheckoutEvent },
    } = useQsrEventsCenter();

    const goToInvoice = (order: IQSROrder) => {
        qsrProceedToCheckoutEvent();
        routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice', {
            id: order.urlData.tableId,
            f1: order.urlData.f1 || '_',
            f2: order.urlData.f2 || '_',
            ...(order.urlData.hash ? { hash: order.urlData.hash } : {}),
            qsr: 'true',
            qsrMA: 'true',
            qOrderId: order.refId,
            source: 'manualAmount',
        });
    };

    const updateOrder = (orderPayload: IOrderData, retry?: number) => {
        setLoading(true);
        menuApi
            .editOrder(url, orderPayload, {
                multiOrder: vendor?.orderConfig?.paymentMethod
                    ? [OrderPaymentMethodEnum.PayLater, OrderPaymentMethodEnum.NoPayment].includes(
                          vendor?.orderConfig?.paymentMethod,
                      )
                    : false,
                vendor,
            })
            .then((res) => {
                goToInvoice(res);
            })
            .catch((err) => {
                const trimmedErr = err?.response?.data || err?.data;
                handleError(trimmedErr, basket.items);
                setBasketOrderId(uuidv4());
                setLoading(false);
                if (!retry) {
                    // eslint-disable-next-line @typescript-eslint/no-use-before-define
                    orderHandler((retry || 0) + 1);
                }
            });
    };

    const orderHandler = async (retry?: number) => {
        if (!basket || loading) {
            return;
        }

        const orderPayload: IOrderData = {
            refId: getBasketOrderId(),
            orderData: basket,
            customerComment: '',
            diningOption: basket.diningOption,
            totalAmount: basket.totalAmount,
        };

        if (
            (vendor?.orderConfig?.customerDetailsMode || CustomerDetailsModeEnum.None) !==
                CustomerDetailsModeEnum.None &&
            customerDetailsFetchRef.current
        ) {
            orderPayload.userInfo = await customerDetailsFetchRef.current();
        }

        setLoading(true);
        getRecaptchaToken(true, true)
            .then((token) => {
                if (!token) {
                    enqueueSnackbar(t('empty recaptcha token'), { variant: 'error' });
                    return;
                }
                menuApi
                    .postOrder(url, orderPayload, token, {
                        multiOrder: vendor?.orderConfig?.paymentMethod
                            ? [OrderPaymentMethodEnum.PayLater, OrderPaymentMethodEnum.NoPayment].includes(
                                  vendor?.orderConfig?.paymentMethod,
                              )
                            : false,
                        vendor,
                    })
                    .then((res) => {
                        goToInvoice(res);
                    })
                    .catch((err) => {
                        const trimmedErr = err?.response?.data || err?.data;
                        if (trimmedErr?.message === 'DUPLICATE_REF_ID') {
                            updateOrder(orderPayload, retry);
                        } else {
                            handleError(trimmedErr, basket.items);
                            setLoading(false);
                        }
                    });
            })
            .catch((recaptchaErr) => {
                enqueueSnackbar(recaptchaErr, { variant: 'error' });
            });
    };

    const submitFnHandler = (fn: SubmitFuncType) => {
        customerDetailsFetchRef.current = fn;
    };

    const currencyPrecision = useMemo(() => getCurrencyPrecision(vendor?.country.currencySymbol), [vendor]);

    const amount = useMemo(() => {
        return calculateTotalPrice(basket, { currencyPrecision, vendor });
    }, [basket, vendor, currencyPrecision]);

    return (
        <BasketContextProvider>
            <div
                className={classNames(styles.container, {
                    [styles.noLogo]: !vendor?.logoBigUrl,
                })}
            >
                <Head>
                    <title>{t('Qlub_ | Manual Amount')}</title>
                </Head>
                <div className={styles.title}>{t('Enter the amount')}</div>
                <div className={styles.amount}>
                    <TextField
                        variant="outlined"
                        type="number"
                        fullWidth
                        autoFocus
                        inputProps={{
                            inputMode: 'decimal',
                            placeholder: '0.00',
                            min: 0,
                        }}
                        value={basket?.totalAmount || undefined}
                        onChange={(e) => {
                            const enVal = faToEn(e.target.value);
                            setBasket({
                                ...basket,
                                totalAmount: Number(enVal),
                            });
                        }}
                    />
                </div>
                {vendor?.orderConfig?.customerDetailsMode === CustomerDetailsModeEnum.OrderDetails && (
                    <QSRCustomerDetailsWrapper submitFn={submitFnHandler} />
                )}
                <div className={styles.gap} />
                <Button
                    className={styles.button}
                    disabled={amount === 0}
                    variant="contained"
                    color="primary"
                    fullWidth
                    onClick={() => {
                        orderHandler();
                    }}
                >
                    {loading ? (
                        <NewLoading />
                    ) : (
                        <>
                            {t('Proceed to payment')}
                            <Price
                                value={String(amount)}
                                bold
                                sx={{ paddingLeft: '5px' }}
                                currencyFormat={{
                                    ...currencyFormat,
                                    currencyPrecision: currencyPrecision || currencyFormat?.currencyPrecision,
                                }}
                            />
                        </>
                    )}
                </Button>
            </div>
        </BasketContextProvider>
    );
};

export default QSRManualAmount;
