/*
    Creation Time: 2024 - Jan - 24
    Created by:  (burakcelik)
    Maintainers:
       1.  burakcelik (burakkclkk@gmail.com)
       2.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: burakcelil
    Copyright Qlub_ 2024
*/

import Head from 'next/head';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { NextPageWithLayout } from '@/layout/types';
import QSRSocialVendorList from '@/components/QSR/QSRSocialVendorList';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';

import styles from './index.module.scss';

const QSRSocialMenu: NextPageWithLayout = () => {
    const { vendor } = useVendor();
    const { t } = useTranslation('common');

    return (
        <>
            <Head>
                <title>{t('Qlub_ | Social Dining Menu')}</title>
            </Head>
            <div className={styles.menu}>
                <div className={styles.title}>{vendor?.title}</div>
                <QSRSocialVendorList />
            </div>
        </>
    );
};

export default QSRSocialMenu;
