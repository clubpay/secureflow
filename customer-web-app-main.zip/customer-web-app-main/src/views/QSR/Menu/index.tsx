/*
    Creation Time: 2022 - Aug - 26
    Created by:  (burakcelik)
    Maintainers:
       1.  burakcelik (burakkclkk@gmail.com)
    Auditor: burakcelil
    Copyright Qlub_ 2022
*/
import { useCallback, useEffect, useMemo, useState } from 'react';
import Head from 'next/head';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import MenuAPIManager from '@/repositories/menu';
import { NextPageWithLayout } from '@/layout/types';
import { IBasket, IMenu, MenuTypeEnum, UIVariantEnum } from '@/repositories/menu/types';
import QSRLanding from '@/components/QSR/QSRLanding';
import { IProductSelect } from '@/components/QSR/QSRProduct';
import ActiveMenu from '@/components/QSR/QSRActiveMenu';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { calculateOrderCount } from '@/services/utils/k_order';
import { EmbedModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useLayout } from '@clubpay/customer-common-module/src/context/layout';
import { QSRSelectFunc } from '@/components/QSR/QSRProductList';
import { useBasket } from '@/contexts/basket';
import classNames from 'classnames';
import { getCurrencyPrecision } from '@clubpay/customer-common-module/src/utility/k_currency';
import QSRProductDrawer from '@/components/QSR/QSRProductDrawer';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import { useSplash } from '@clubpay/customer-common-module/src/context/splash';
import QSRDiningOptionModal from '@/components/QSR/QSRDiningOptionModal';
import QSRReviewOrderButton from '@/components/QSR/QSRReviewOrderButton';
import { useBridge } from '@/contexts/bridge';
import { trimPathnameForEmbed } from '@/services/utils/k_qsr';
import QSREmbedHeader from '@/components/QSR/QSREmbedHeader';
import { getSocialMenuParams } from '@/components/QSR/QSRSocialVendorList';
import { useQsrError } from '@/hooks/qsrError';
import { useQrPasscode } from '@/contexts/qrPasscode';

import styles from './index.module.scss';

const QSRMenu: NextPageWithLayout = () => {
    const menuApi = MenuAPIManager.getInstance();
    const { t } = useTranslation('common');
    const { url, urlStr, query, routerPush, isQSR, pathname } = useQlubRouter();
    const { handleError } = useQsrError();
    const { setBackFn, forceBackVisibility } = useLayout();
    const { handleLoad, handleBack } = useBridge();
    const [selectedProduct, setSelectedProduct] = useState<IProductSelect | undefined>(undefined);
    const [loading, setLoading] = useState(true);
    const [productDrawerOpen, setProductDrawerOpen] = useState(false);
    const [searchDrawerOpen, setSearchDrawerOpen] = useState(false);
    const [menus, setMenus] = useState<IMenu[]>([]);
    const { vendor, currencyFormat } = useVendor();
    const { hide } = useSplash();
    const { basket, setBasket } = useBasket();
    const {
        qsr: { qsrProductModalEvent },
    } = useQsrEventsCenter();
    const { passcode } = useQrPasscode();

    const { menu: selectedMenuId } = query as {
        menu: string;
    };

    const embedVendor = url.embed === EmbedModeEnum.Vendor;
    const ui: UIVariantEnum = vendor?.orderConfig?.menuItemCellV2 ? UIVariantEnum.V2 : UIVariantEnum.V1;

    const backHandler = useCallback(() => {
        routerPush(trimPathnameForEmbed('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr', pathname), {});
    }, [pathname]);

    useEffect(() => {
        if (pathname === '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr/[menu]') {
            setBackFn(backHandler);
            if (!selectedMenuId) {
                handleBack(false);
            } else {
                handleBack(true, backHandler);
            }
        } else {
            const socialParams = getSocialMenuParams();
            if (socialParams) {
                setTimeout(() => {
                    forceBackVisibility(true);
                    const fn = () => {
                        routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/social', socialParams);
                    };
                    setBackFn(fn);
                    if (!selectedMenuId) {
                        handleBack(false);
                    } else {
                        handleBack(true, fn);
                    }
                }, 100);
            } else if (!selectedMenuId) {
                handleBack(false);
            } else {
                handleBack(true);
            }
        }
    }, [backHandler, pathname]);

    const isSim = useMemo(() => window.location.href.includes('sim=true'), []);

    const basketChangeHandler = (bsk: IBasket) => {
        setBasket(bsk);
    };

    const selectProductHandler: QSRSelectFunc = ({ product, menu, category, selected }) => {
        qsrProductModalEvent(product.name);
        setProductDrawerOpen(true);
        setSelectedProduct({
            product,
            selectionId: selected?.selectionId,
            menu,
            category,
            menuId: product.menuId || selected?.menuId || '',
            full: false,
        });
    };

    const currencyPrecision = useMemo(() => getCurrencyPrecision(vendor?.country?.currencyCode), [vendor]);

    const basketOrderCount = useMemo(
        () =>
            calculateOrderCount(basket, {
                vendor,
                isEmbedVendor: embedVendor,
            }),
        [basket, vendor, embedVendor],
    );

    useEffect(() => {
        if (
            !url.cc ||
            !url.slug ||
            !url.id ||
            !url.f1 ||
            !url.f2 ||
            embedVendor ||
            !vendor?.orderConfig?.qrDynamicPasscodeEnable
        ) {
            return;
        }

        menuApi.validateDynamicQr(url, passcode).catch((err) => {
            const trimmedErr = err?.response?.data || err?.data;
            handleError(trimmedErr, []);
        });
    }, [urlStr, embedVendor, vendor, passcode]);

    useEffect(() => {
        if (!url.cc || !url.slug || !url.id || !url.f1 || !url.f2) {
            return;
        }

        hide();
        setLoading(true);
        menuApi
            .getMenu(url, { page: 0, limit: 100 }, vendor)
            .then((res) => {
                setMenus(res.rows.filter((menu) => menu.type !== MenuTypeEnum.UPSELL));
            })
            .catch((err) => console.log(err))
            .finally(() => {
                setLoading(false);
                handleLoad();
            });
    }, [urlStr, selectedMenuId]);

    return (
        <>
            <Head>
                <title>{t('Qlub_ | Menu')}</title>
            </Head>
            <div
                className={classNames(styles.menu, {
                    [styles.noLogo]: !vendor?.logoBigUrl,
                })}
            >
                <QSREmbedHeader />
                {selectedMenuId ? (
                    <ActiveMenu
                        isQSR={isQSR}
                        menuId={selectedMenuId}
                        currencyPrecision={currencyPrecision}
                        ui={ui}
                        onSelect={selectProductHandler}
                        onSearchOpen={(val) => {
                            setSearchDrawerOpen(val);
                        }}
                    />
                ) : (
                    <QSRLanding menu={menus} loading={loading} />
                )}
                <div className={styles.gap} />
                <QSRReviewOrderButton
                    basket={basket}
                    basketOrderCount={basketOrderCount}
                    currencyPrecision={currencyPrecision}
                    vendor={vendor}
                    isSim={isSim}
                    isQSR={isQSR}
                    isEmbedVendor={embedVendor}
                    currencyFormat={currencyFormat}
                    searchOpen={searchDrawerOpen}
                />
            </div>
            <QSRProductDrawer
                qsr={isQSR}
                vendor={vendor}
                selectedProduct={selectedProduct}
                basket={basket}
                currencyPrecision={currencyPrecision}
                open={productDrawerOpen}
                isEmbedVendor={embedVendor}
                currencyFormat={currencyFormat}
                ui={ui}
                onBasketChange={basketChangeHandler}
                onClose={() => {
                    setProductDrawerOpen(false);
                    setTimeout(() => {
                        setSelectedProduct(undefined);
                    }, 100);
                }}
                onOpen={() => {
                    setProductDrawerOpen(true);
                }}
            />
            {vendor?.orderConfig?.diningOptionEnable && <QSRDiningOptionModal />}
        </>
    );
};

export default QSRMenu;
