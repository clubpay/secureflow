import { Box, Grid, Skeleton } from '@mui/material';

import styles from './index.module.scss';

const SkeletonComponent = () => {
    return (
        <div className={styles.skeleton}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '16px' }}>
                <Skeleton variant="text" width="80%" height={150} />
                <Grid container justifyContent="space-between" alignItems="space-between">
                    <Skeleton variant="text" width="30%" height={40} />
                    <Skeleton variant="text" width="80%" height={40} />
                </Grid>
            </Box>
        </div>
    );
};
export default SkeletonComponent;
