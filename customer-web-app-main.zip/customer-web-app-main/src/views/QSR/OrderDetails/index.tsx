import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Box, Button, IconButton, TextField, Paper, useTheme } from '@mui/material';
import Head from 'next/head';
import { NextPageWithLayout } from '@/layout/types';
import BorderColorIcon from '@mui/icons-material/BorderColor';
import { CustomerContainer, Divider, MenuItemCell, QlubKitTheme, Typography } from '@qlub-dev/qlub-kit';
import {
    IBasket,
    IOrderData,
    IOrderItem,
    IOrderVendorId,
    IProduct,
    IQSROrder,
    StepperStatusEnum,
    UIVariantEnum,
} from '@/repositories/menu/types';
import { EmbedModeEnum, QSRRouterModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getAvailableLang, isValidText } from '@clubpay/customer-common-module/src/utility/k_lang';
import { v4 as uuidv4 } from 'uuid';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { calculateItemPrice, calculateOrderCount, calculateTotalPrice } from '@/services/utils/k_order';
import MenuAPIManager from '@/repositories/menu';
import { convertMultiLocaleStringToObject } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { getBasketOrderId, setBasketOrderId } from '@/services/session/basket';
import { getMediaFirstItem } from '@/services/utils/k_media';
import { BasketContextProvider, getVendorId, useBasket } from '@/contexts/basket';
import DeleteForeverRoundedIcon from '@mui/icons-material/DeleteForeverRounded';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import EditNoteIcon from '@qlub-dev/qlub-kit/dist/assets/icons/EditNoteIcon';
import { IProductSelect } from '@/components/QSR/QSRProduct';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { getCurrencyPrecision } from '@clubpay/customer-common-module/src/utility/k_currency';
import { QSRSelectFunc } from '@/components/QSR/QSRProductList';
import QSRProductDrawer from '@/components/QSR/QSRProductDrawer';
import QSRProductNoteDrawer from '@/components/QSR/QSRProductNoteDrawer';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import QSRModifierDisplay from '@/components/QSR/QSRModifierDisplay';
import { SubmitFuncType } from '@/components/QSR/QSRCustomerDetails';
import {
    CustomerDetailsModeEnum,
    OrderModeEnum,
    OrderPaymentMethodEnum,
} from '@clubpay/customer-common-module/src/repository/vendor';
import QSRCustomerDetailsWrapper from '@/components/QSR/QSRCustomerDetailsWrapper';
import QSRPrice from '@/components/QSR/QSRPrice';
import QSRScheduledOrder, { IScheduledTime, ScheduledOrderEnum } from '@/components/QSR/QSRScheduledOrder';
import { useQrPasscode } from '@/contexts/qrPasscode';
import {
    createDateBasedOnDay,
    getUrlStringFromUrlData,
    translator,
    trimPathnameForEmbed,
} from '@/services/utils/k_qsr';
import { useQsrError } from '@/hooks/qsrError';
import QSRStepper from '@/components/QSR/QSRStepper';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import QSRConfirmOrderButton from '@/components/QSR/QSRConfirmOrderButton';
import { useBridge } from '@/contexts/bridge';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import QSREmbedHeader from '@/components/QSR/QSREmbedHeader';
import { mergeBasket } from '@/components/QSR/QSRProduct/utils';
import Skeleton from './skeleton';

import styles from './index.module.scss';

const QSROrderDetails: NextPageWithLayout = () => {
    const menuApi = MenuAPIManager.getInstance();
    const { t } = useTranslation('common');
    const theme = useTheme();
    const { config } = useConfigContext();
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const { getRecaptchaToken } = useAuth();
    const { basket, setBasket } = useBasket();
    const { vendorToken, handleSubmitOrder, handleOrderError, handleBack } = useBridge();
    const [customerNote, setCustomerNote] = useState('');
    const [error, setError] = useState<boolean>(false);
    const { vendor, tableInfo, currencyFormat } = useVendor();
    const { url, urlStr, lang, routerPush, pathname, getRouterParam, query, back: routeBack } = useQlubRouter();
    const [loading, setLoading] = useState(false);
    const [orderLoading, setOrderLoading] = useState(false);
    const [productMap, setProductMap] = useState<{ [key: string]: IProduct }>({});
    const [drawerOpen, setDrawerOpen] = useState(false);
    const [noteDrawerOpen, setNoteDrawerOpen] = useState(false);
    const [selectedProduct, setSelectedProduct] = useState<IProductSelect | undefined>(undefined);
    const customerDetailsFetchRef = useRef<SubmitFuncType | undefined>(undefined);
    const { passcode } = useQrPasscode();
    const { handleError } = useQsrError();
    const [scheduledAt, setScheduledAt] = useState<IScheduledTime>({
        type: ScheduledOrderEnum.ASAP,
    });

    const isPickupOnly = Boolean(vendor?.orderConfig?.pickupOnly);
    const embedVendor = url.embed === EmbedModeEnum.Vendor;
    const ui: UIVariantEnum = vendor?.orderConfig?.menuItemCellV2 ? UIVariantEnum.V2 : UIVariantEnum.V1;

    const [specialRequestTitle, specialRequestDesc] = useMemo(() => {
        const defaultRequestText = t('Special Request');
        const defaultDescText = t('Allergies, dietary restrictions and etc');
        return [
            convertMultiLocaleStringToObject(
                vendor?.orderConfig?.specialRequestTitle || (vendor?.config as any)?.specialRequestTitle || '',
                defaultRequestText,
            )[lang] || defaultRequestText,
            convertMultiLocaleStringToObject(
                vendor?.orderConfig?.specialRequestDesc || (vendor?.config as any)?.specialRequestDesc || '',
                defaultDescText,
            )[lang] || defaultDescText,
        ];
    }, [vendor, lang, t]);

    const {
        qsr: {
            qsrSpecialRequestEvent,
            qsrProductModalEvent,
            qsrProceedToCheckoutEvent,
            qsrPageViewEvent,
            qsrProductRemoveChartEvent,
        },
    } = useQsrEventsCenter();

    useEffect(() => {
        handleBack(true, routeBack);
    }, []);

    useEffect(() => {
        qsrPageViewEvent('qsrOrderDetails');
        if (!basket || !url.cc || !url.slug) {
            return;
        }

        setCustomerNote(basket.note || '');
        setLoading(true);
        menuApi
            .getManyProduct(
                url,
                basket.items
                    .filter((o) => !o.timestamp || embedVendor)
                    .map((o) => ({ menuId: o.menuId, productId: o.id })),
                vendor,
            )
            .then((res) => {
                setProductMap(res);
            })
            .catch((err) => console.log(err))
            .finally(() => {
                setLoading(false);
            });
    }, [urlStr, basket?.items, embedVendor]);

    const paymentMethod = vendor?.orderConfig?.paymentMethod;

    const multiOrder = paymentMethod
        ? [OrderPaymentMethodEnum.PayLater, OrderPaymentMethodEnum.NoPayment].includes(paymentMethod)
        : false;

    const isPrepaid = vendor?.orderConfig?.paymentMethod === OrderPaymentMethodEnum.Default;

    const noteChangeHandler = useCallback((e: any) => {
        setCustomerNote(e.target.value);
    }, []);

    const blurHandler = useCallback(
        (e: any) => {
            const val = e.target.value;
            if (val) {
                qsrSpecialRequestEvent();
            }

            const allowedLanguages = vendor?.orderConfig?.allowedInputLanguages || [];
            if (allowedLanguages.length === 0) {
                return;
            }

            setError(val ? !isValidText(val, allowedLanguages, false) : false);
        },
        [vendor],
    );

    const goToInvoice = useCallback(
        (order: IQSROrder) => {
            const qsrPayment = vendor?.orderConfig?.paymentMethod || OrderPaymentMethodEnum.Default;
            const params = {
                id: order.urlData.tableId,
                f1: order.urlData.f1 || '_',
                f2: order.urlData.f2 || '_',
                ...(order.urlData.hash ? { hash: order.urlData.hash } : {}),
                qsr: vendor?.orderMode === OrderModeEnum.Mixed ? QSRRouterModeEnum.Mixed : QSRRouterModeEnum.True,
                qsrPayment,
                qOrderId: order.refId,
                source: 'menuPage',
                ...(order.paymentUrlData?.tableId
                    ? {
                          qPayUrl: getUrlStringFromUrlData(order.paymentUrlData),
                      }
                    : {}),
                ...(order.scheduledAt && order.pickupAt ? { pickupAt: order.pickupAt } : {}),
                ...getAvailableLang(query?.lang),
            };

            if ([EmbedModeEnum.Vendor, EmbedModeEnum.SoftPos].includes(url.embed as EmbedModeEnum)) {
                const { query: submitOrderParam } = getRouterParam(pathname, params);

                setLoading(false);
                // setOrderLoading(false);
                handleSubmitOrder(submitOrderParam, order);
                return;
            }

            if (qsrPayment === OrderPaymentMethodEnum.Default) {
                qsrProceedToCheckoutEvent();
                routerPush(
                    vendor?.orderMode === OrderModeEnum.Mixed && qsrPayment !== OrderPaymentMethodEnum.Default
                        ? '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice'
                        : '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice/checkout',
                    params,
                );
            } else {
                routerPush(
                    trimPathnameForEmbed('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr/preparation', pathname),
                    params,
                );
            }
        },
        [vendor, pathname, url.embed],
    );

    const removingItem = useCallback(
        (removedItem: IOrderItem, vendorId: IOrderVendorId) => {
            setBasket(
                mergeBasket(
                    basket,
                    {
                        ...removedItem,
                        quantity: 0,
                    },
                    { vendorId, isEmbedVendor: embedVendor },
                ),
            );
        },
        [basket, embedVendor],
    );

    const basketChangeHandler = useCallback((bsk: IBasket) => {
        setBasket(bsk);
    }, []);

    const updateOrder = useCallback(
        (orderPayload: IOrderData, retry?: number) => {
            setOrderLoading(true);
            menuApi
                .editOrder(url, orderPayload, {
                    multiOrder,
                    qrpc: passcode,
                    vendor,
                    vendorToken,
                    unifyTimestamp: embedVendor,
                })
                .then((res) => {
                    goToInvoice(res);
                })
                .catch((err) => {
                    const trimmedErr = err?.response?.data || err?.data;
                    handleError(trimmedErr, basket.items);
                    setBasketOrderId(uuidv4());
                    setOrderLoading(false);
                    if (!retry && !embedVendor) {
                        // eslint-disable-next-line @typescript-eslint/no-use-before-define
                        orderHandler((retry || 0) + 1);
                    }
                });
        },
        [urlStr, passcode, multiOrder, vendor, vendorToken, embedVendor],
    );

    const focusOnInvalidInputs = useCallback(() => {
        setTimeout(() => {
            const el = document.querySelector('[aria-invalid="true"]') as HTMLElement;
            if (!el) {
                return;
            }

            el.parentElement?.scrollIntoView({
                block: 'start',
                behavior: 'smooth',
            });
        }, 50);
    }, []);

    const scrollToScheduler = useCallback(() => {
        const schedulerElement = document.querySelector<HTMLDivElement>('[data-testid="qsr-scheduler"]');
        if (schedulerElement) {
            schedulerElement.scrollIntoView({
                behavior: 'smooth',
                block: 'center',
            });

            schedulerElement.setAttribute('data-show-animation', 'true');
            setTimeout(() => {
                schedulerElement.removeAttribute('data-show-animation');
            }, 2100);
        }
    }, []);

    const isValidScheduledTime = useCallback((scheduledTime: IScheduledTime) => {
        return (
            scheduledTime.type === ScheduledOrderEnum.Scheduled &&
            scheduledTime.value?.date &&
            scheduledTime.value?.timePeriod
        );
    }, []);

    const orderHandler = useCallback(
        async (retry?: number) => {
            if (!basket || orderLoading) {
                return;
            }

            if (error) {
                focusOnInvalidInputs();
                return;
            }

            if (isPickupOnly && !isValidScheduledTime(scheduledAt)) {
                scrollToScheduler();
                return;
            }

            const { ...rest } = basket;

            const orderPayload: IOrderData = {
                refId: getBasketOrderId(),
                customerComment: customerNote,
                diningOption: basket.diningOption,
                orderData: { ...rest, lang },
            };

            if (
                !embedVendor &&
                (vendor?.orderConfig?.customerDetailsMode || CustomerDetailsModeEnum.None) !==
                    CustomerDetailsModeEnum.None &&
                customerDetailsFetchRef.current
            ) {
                orderPayload.userInfo = await customerDetailsFetchRef.current();
            }

            if (scheduledAt.type !== ScheduledOrderEnum.ASAP) {
                orderPayload.scheduledAt = createDateBasedOnDay(
                    scheduledAt.value?.date,
                    scheduledAt.value?.timePeriod?.start,
                );
            }

            setOrderLoading(true);
            getRecaptchaToken(true)
                .then((token) => {
                    if (!token) {
                        enqueueSnackbar(t('empty recaptcha token'), { variant: 'error' });
                        return;
                    }

                    menuApi
                        .postOrder(url, orderPayload, token, {
                            multiOrder,
                            qrpc: passcode,
                            vendor,
                            vendorToken,
                            unifyTimestamp: embedVendor,
                        })
                        .then((res) => {
                            goToInvoice(res);
                        })
                        .catch((err) => {
                            const trimmedErr = err?.response?.data || err?.data;
                            if (trimmedErr?.message === 'DUPLICATE_REF_ID') {
                                updateOrder(orderPayload, retry);
                            } else {
                                handleError(trimmedErr, basket.items);
                                handleOrderError(trimmedErr);
                                setOrderLoading(false);
                            }
                        });
                })
                .catch((recaptchaErr) => {
                    enqueueSnackbar(recaptchaErr, { variant: 'error' });
                })
                .finally(() => {
                    if (!multiOrder) {
                        setBasket({
                            ...basket,
                            note: customerNote,
                            diningOption: basket.diningOption,
                        });
                    }
                });
        },
        [basket, customerNote, scheduledAt, urlStr, passcode, multiOrder, vendor, embedVendor, vendorToken, error],
    );

    const currencyPrecision = useMemo(() => getCurrencyPrecision(vendor?.country?.currencyCode), [vendor]);

    const selectProductHandler = useCallback<QSRSelectFunc>(({ product, selected }) => {
        qsrProductModalEvent(product.name);
        setDrawerOpen(true);
        setSelectedProduct({
            product,
            selectionId: selected?.selectionId,
            menuId: product.menuId || selected?.menuId || '',
            full: false,
        });
    }, []);

    const itemNoteOpenHandler = useCallback<QSRSelectFunc>(({ product, selected }) => {
        setSelectedProduct({
            product,
            selectionId: selected?.selectionId,
            menuId: product.menuId || selected?.menuId || '',
            full: false,
        });
        setNoteDrawerOpen(true);
    }, []);

    const basketOrderCount = useMemo(
        () =>
            calculateOrderCount(basket, {
                vendor,
                isEmbedVendor: embedVendor,
            }),
        [basket, vendor, embedVendor],
    );

    const amount = useMemo(
        () =>
            calculateTotalPrice(basket, {
                currencyPrecision,
                vendor,
                isEmbedVendor: embedVendor,
            }),
        [basket, vendor, embedVendor],
    );

    const submitFnHandler = useCallback((fn: SubmitFuncType) => {
        customerDetailsFetchRef.current = fn;
    }, []);

    const addItemsHandler = useCallback(() => {
        MenuAPIManager.getInstance()
            .getMenu(url, { page: 0, limit: 2 }, vendor)
            .then((res) => {
                if (res?.rows?.length === 1) {
                    routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/embed/qsr/[menu]', {
                        menu: res.rows[0].id || '_',
                    });
                } else {
                    routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/embed/qsr');
                }
            });
    }, [urlStr, vendor]);

    return (
        <BasketContextProvider>
            <Head>
                <title>{t('Qlub_ | Your Order')}</title>
            </Head>
            <CustomerContainer maxWidth="sm" className={styles.mainContainer}>
                <Paper elevation={0} className={styles.paper}>
                    <div className={styles.container}>
                        {!embedVendor && (
                            <div className={styles.stepperContainer}>
                                <QSRStepper
                                    config={config}
                                    vendor={vendor}
                                    tableInfo={tableInfo}
                                    status={StepperStatusEnum.BASKET}
                                />
                            </div>
                        )}
                        <QSREmbedHeader />
                        <div className={styles.items}>
                            <div className={styles.title}>{t('Items')}</div>
                            {basket?.items?.map((item, index) => {
                                if (!embedVendor && item.timestamp) {
                                    return null;
                                }

                                if (loading) {
                                    return <Skeleton />;
                                }

                                const product = { ...productMap[item.id], menuId: item.menuId };
                                if (!product) {
                                    return null;
                                }

                                return (
                                    <div key={index} className={styles.item}>
                                        <MenuItemCell
                                            key={index}
                                            quantity={item.quantity}
                                            onClick={(e) => {
                                                if (
                                                    vendor?.orderConfig?.basketEdit &&
                                                    !['path', 'svg', 'button'].includes((e as any)?.target?.nodeName)
                                                ) {
                                                    selectProductHandler({ product, selected: item });
                                                }
                                            }}
                                            numberCircleColor={theme.qlub.palette.dim.main}
                                            title={translator(product.name, product.nameTranslations, lang)}
                                            badges={product.priceAdditiveName && [product.priceAdditiveName]}
                                            subTitle={translator(product.subTitle, product.subTitleTranslations, lang)}
                                            description={
                                                <QSRModifierDisplay item={item} product={product} lang={lang} />
                                            }
                                            direction="row-reverse"
                                            image={getMediaFirstItem(product?.media)}
                                            classes={{
                                                containerOverrides: { padding: '0px', cursor: 'pointer' },
                                            }}
                                            footer={
                                                <>
                                                    <div style={{ display: 'flex', alignItems: 'center' }}>
                                                        <IconButton
                                                            onClick={() => {
                                                                qsrProductRemoveChartEvent({
                                                                    pageName: 'qsrOrderDetails,',
                                                                    productName: product.name,
                                                                    quantity: 0,
                                                                });
                                                                removingItem(item, getVendorId(url));
                                                            }}
                                                            sx={{
                                                                p: '2px',
                                                            }}
                                                        >
                                                            <DeleteForeverRoundedIcon
                                                                fontSize="medium"
                                                                sx={{ color: theme.qlub.palette.iris.main }}
                                                            />
                                                        </IconButton>
                                                        <QSRPrice
                                                            value={(item
                                                                ? calculateItemPrice(item, {
                                                                      currencyPrecision,
                                                                      vendor,
                                                                  })
                                                                : product.price
                                                            ).toFixed(currencyPrecision)}
                                                            currencyFormat={{
                                                                ...currencyFormat,
                                                                currencyPrecision:
                                                                    currencyPrecision ||
                                                                    currencyFormat?.currencyPrecision,
                                                            }}
                                                            sx={{ paddingX: '8px' }}
                                                        />
                                                        {vendor?.orderConfig?.basketEdit && (
                                                            <BorderColorIcon
                                                                fontSize="small"
                                                                onClick={() => {
                                                                    selectProductHandler({ product, selected: item });
                                                                }}
                                                                sx={{
                                                                    marginLeft: '16px',
                                                                    color: theme.qlub.palette.iris.main,
                                                                }}
                                                            />
                                                        )}
                                                    </div>
                                                    {vendor?.orderConfig?.enableProductBasedComment && (
                                                        <Box
                                                            className={styles.productComment}
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                itemNoteOpenHandler({ product, selected: item });
                                                            }}
                                                        >
                                                            <EditNoteIcon />

                                                            {item.note ? (
                                                                <Typography
                                                                    sx={{ fontSize: '12px', fontWeight: '500' }}
                                                                >
                                                                    {item.note}
                                                                </Typography>
                                                            ) : (
                                                                <Typography
                                                                    sx={{ fontSize: '14px', fontWeight: '500' }}
                                                                >
                                                                    {t('Add a request')}
                                                                </Typography>
                                                            )}
                                                        </Box>
                                                    )}
                                                </>
                                            }
                                        />
                                        {index !== basket?.items.length - 1 && <Divider sx={{ width: '%100' }} />}
                                    </div>
                                );
                            })}
                            {embedVendor && url.embed !== EmbedModeEnum.SoftPos && (
                                <div className={styles.addItem}>
                                    <Button
                                        className={styles.addItemButton}
                                        variant="outlined"
                                        startIcon={<AddRoundedIcon />}
                                        fullWidth
                                        onClick={addItemsHandler}
                                        sx={{
                                            backgroundColor: QlubKitTheme.qlub.palette.purple?.main,
                                            color: QlubKitTheme.qlub.palette.white.main,
                                            '&:hover': { backgroundColor: QlubKitTheme.qlub.palette.purple?.dark },
                                        }}
                                    >
                                        {t('Add more items to basket')}
                                    </Button>
                                </div>
                            )}
                        </div>
                        <Divider />
                        {!vendor?.orderConfig?.hideComment && (
                            <Box className={styles.request}>
                                <div>{specialRequestTitle}</div>
                                <TextField
                                    inputProps={{
                                        maxLength: 255,
                                        sx: {
                                            '&::placeholder': {
                                                color: '#9B9EAB',
                                            },
                                        },
                                    }}
                                    classes={{
                                        root: styles.inputBox,
                                    }}
                                    placeholder={specialRequestDesc}
                                    defaultValue={basket.note}
                                    onBlur={blurHandler}
                                    onChange={noteChangeHandler}
                                    value={customerNote}
                                    maxRows={6}
                                    multiline
                                    fullWidth
                                    error={error}
                                    helperText={error ? t('This language is not supported') : ''}
                                />
                            </Box>
                        )}
                        {!embedVendor &&
                            vendor?.orderConfig?.customerDetailsMode === CustomerDetailsModeEnum.OrderDetails && (
                                <QSRCustomerDetailsWrapper
                                    submitFn={submitFnHandler}
                                    diningOption={basket?.diningOption}
                                />
                            )}
                        {!embedVendor && vendor?.orderConfig?.scheduledOrderEnable && (
                            <QSRScheduledOrder
                                value={scheduledAt}
                                setValue={setScheduledAt}
                                isPickupOnly={isPickupOnly}
                            />
                        )}
                        <div className={styles.gap} />
                        <QSRConfirmOrderButton
                            basket={basket}
                            basketOrderCount={basketOrderCount}
                            amount={amount}
                            vendor={vendor}
                            currencyPrecision={currencyPrecision}
                            prepaid={isPrepaid}
                            embedVendor={embedVendor}
                            loading={orderLoading}
                            currencyFormat={currencyFormat}
                            onConfirm={() => {
                                orderHandler();
                            }}
                        />
                    </div>
                </Paper>
            </CustomerContainer>
            {vendor?.orderConfig?.basketEdit && (
                <QSRProductDrawer
                    qsr
                    vendor={vendor}
                    selectedProduct={selectedProduct}
                    basket={basket}
                    open={drawerOpen}
                    currencyPrecision={currencyPrecision}
                    isEmbedVendor={embedVendor}
                    currencyFormat={currencyFormat}
                    ui={ui}
                    onClose={() => setDrawerOpen(false)}
                    onBasketChange={basketChangeHandler}
                    onOpen={() => setDrawerOpen(true)}
                />
            )}
            {vendor?.orderConfig?.enableProductBasedComment && (
                <QSRProductNoteDrawer
                    vendor={vendor}
                    basket={basket}
                    onBasketChange={basketChangeHandler}
                    selectedProduct={selectedProduct}
                    isEmbedVendor={embedVendor}
                    onClose={() => setNoteDrawerOpen(false)}
                    open={noteDrawerOpen}
                />
            )}
        </BasketContextProvider>
    );
};

export default QSROrderDetails;
