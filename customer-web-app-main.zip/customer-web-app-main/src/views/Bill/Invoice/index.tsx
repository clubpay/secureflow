/* eslint-disable max-lines */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import Head from 'next/head';
import { Box, Paper } from '@mui/material';
import UpdateManager, { UpdateMSG } from '@/services/sdk/server/updateManager';
import Pay from '@/views/Bill/Invoice/components/pay';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import InvoiceError, { isNoOrderErr } from '@clubpay/customer-common-module/src/component/InvoiceError';
import { timeUnix } from '@clubpay/customer-common-module/src/utility/k_time';
import SubscribeElsewhere from '@clubpay/loyalty/dist/drivers/customer/Subscription/SubscribeElsewhere';
import { useGlobalStore } from '@clubpay/loyalty/dist/store/global';
import { cloneDeep } from 'lodash';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { Error as IError } from '@clubpay/customer-common-module/src/repository/common/type';
import InvoiceSkeleton from '@/components/Bill/InvoiceSkeleton';
import InvoiceTable from '@/components/Bill/InvoiceTable';
import { NotificationTypeEnum, useInvoiceDifference } from '@/views/Bill/Invoice/difference';
import { NextPageWithLayout } from '@/layout/types';
import { Button, CustomerContainer } from '@qlub-dev/qlub-kit';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import {
    getDefaultJwt,
    getDiningSession,
    getSession,
    removeDiningSession,
    setDiningSession,
} from '@clubpay/customer-common-module/src/service/session/dsi';
import classNames from 'classnames';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import * as Sentry from '@sentry/browser';
import SplitSection from '@/components/Split';
import useEventsCenter from '@/hooks/eventsCenter';
import { useSplash } from '@clubpay/customer-common-module/src/context/splash';
import BillAPIManager, {
    IPaymentDetails,
    IOrderItemView,
    IUpdatePaymentDetails,
    parsePaymentDetails,
} from '@/repositories/bill';
import { EnableEnum, SplitModeTypeEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import {
    IGatewayPayHandler,
    IPayBeforePaymentHandler,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { useLoyaltySplitConditions } from '@clubpay/loyalty/dist/hooks';
import { setClarityTags } from '@/lib/clarity';
import { shouldNewPaymentModuleAcitvate } from '@/components/Bill/PaymentGateway/utils';
import { RefreshFuncType } from '@clubpay/customer-common-module/src/context/layout/types';
import { useLayout } from '@clubpay/customer-common-module/src/context/layout';
import { getODFDefault, setODF } from '@/components/Bill/OptionalDinerFee/utils';
import usePaymentStore from '@/store/payment';
import { removeSpecificEventsFromEventStore } from '@clubpay/customer-common-module/src/lib/utils';
import { TipToggleFunc } from '@/components/Tip/normal/types';
import { isSplitActive } from '@/components/Split/utils';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { ISmartTipModalHandler } from '@/components/Tip/smart';
import { FetchModeEnum } from '@/repositories/bill/enums';
import { diffItems, isQSRMode, isSplashScreenActive } from './utils';
import Loyalty from './loyalty';
import { IGetDetailsOption } from './types';

import styles from './index.module.scss';

export const Invoice: NextPageWithLayout = () => {
    const [details, setDetails] = useState<IPaymentDetails | undefined>(undefined);
    const [loading, setLoading] = useState(false);
    const [split, setSplit] = useState(false);
    const [error, setError] = useState<IError | undefined>(undefined);
    const [, setLastFreshTime] = useState<number>(0);
    const [newOrderIds, setNewOrderIds] = useState<string[]>([]);
    const [init, setInit] = useState(false);
    const [canUpdate, setCanUpdate] = useState(false);
    const [billUpdateTriggered, setBillUpdateTriggered] = useState(0);

    const splitSection = useRef<HTMLDivElement | null>(null);
    const paySection = useRef<HTMLDivElement | null>(null);
    const orderList = useRef<IOrderItemView[]>([]);
    const lastPullToRefreshTime = useRef<number>(0);
    const tipModalOpenFunc = useRef<TipToggleFunc | undefined>(undefined);
    const tipOptionValue = useRef<number>();
    const smartTipModalHandleRef = useRef<ISmartTipModalHandler>(null);

    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar, closeSnackbar, actionButton } = snackBar();
    const { setPullFn } = useLayout();
    const { vendor, tableName, currencyFormat } = useVendor();
    const { config } = useConfigContext();
    const { lang, url, urlStr, routerPush, source, isQSR: routeIsQSR } = useQlubRouter();
    const { notifyChanges: notifyChangesHook } = useInvoiceDifference(lang);
    const { bill: billGA, tip: tipGA, voucherCampaign: campaignGA, payment: paymentGA } = useEventsCenter();
    const { show, hide } = useSplash();

    const hasQSRMode = isQSRMode(url, routeIsQSR);
    const isQSR = hasQSRMode && !url.qsrMA;

    const resetPaymentStore = usePaymentStore((state) => state.reset);

    const notifyChanges = (type: NotificationTypeEnum) => {
        notifyChangesHook(type);
        if (type !== NotificationTypeEnum.None) {
            setBillUpdateTriggered((o) => o + 1);
        }
    };

    const [optionalDinerFee, setOptionalDinerFee] = useState(getODFDefault({ vendor, config: config ?? undefined }));

    const loyaltySplitConditions = useLoyaltySplitConditions();

    useEffect(() => {
        if (!vendor || !config) {
            return;
        }

        setOptionalDinerFee(getODFDefault({ vendor, config }));
    }, [vendor, config]);

    useEffect(() => {
        if (!vendor) {
            return;
        }

        const diningSessionPayload = getDiningSession(url);

        const vendorData = {
            vendorName: vendor.title,
            country: url.cc,
            tableId: url.id,
            tableName,
            tableSessionId: diningSessionPayload?.id,
        };
        Sentry.setContext('vendorData', vendorData);
        Sentry.setTag('vendorDataTag', JSON.stringify(vendorData));

        setClarityTags({ diningSessionID: diningSessionPayload?.id });

        if (vendor?.config?.paymentTraceReplay || vendor?.country?.config?.paymentTraceReplay) {
            const sentryClient = Sentry?.getCurrentHub()?.getClient();
            const sentryReply = sentryClient?.getIntegration(Sentry.Replay);

            if (sentryClient?.addIntegration && !sentryReply) {
                sentryClient.addIntegration(new Sentry.Replay());
            }
        }
    }, [vendor, tableName, url.cc, url.id]);

    useEffect(() => {
        if (details) useGlobalStore.getState().setPaymentDetails(details as any);
    }, [details]);

    useEffect(() => {
        useGlobalStore.getState().setPaymentDetailsLoading(loading);
    }, [loading]);

    const getDetails = ({ force, inRetry, silent, ignoreCache, odf }: IGetDetailsOption) => {
        if ((loading && !odf) || !url.slug || !url.id || !vendor) {
            return Promise.resolve(null);
        }

        const diningSessionPayload = vendor?.config?.invoiceRefreshDsi && !init ? undefined : getDiningSession(url);
        setLoading(true);
        return BillAPIManager.getInstance()
            .getDetails(
                {
                    restaurantUnique: url.slug,
                    id: getSession(),
                    cc: url.cc,
                    tableID: url.id,
                    f1: url.f1,
                    f2: url.f2,
                    hash: url.hash,
                    diningSessionID: diningSessionPayload?.id || '0',
                    forceFresh: force || false,
                    jwt: diningSessionPayload?.jwt || undefined,
                    fetchMode: url.fetchMode as FetchModeEnum,
                    payUrl: url.qPayUrl,
                    ...(odf ? { optionalDinerFee: odf } : {}),
                },
                {
                    cc: url.cc,
                    qsr: hasQSRMode,
                    vendor,
                    ignoreCache: !!odf || ignoreCache,
                    debounce: !!odf,
                },
            )
            .then((res) => {
                hide(true);
                setDiningSession(url, { id: res.diningSessionID, jwt: res.jwt });
                if (!init) {
                    setDetails(res);
                    setInit(true);
                    setTimeout(() => {
                        setCanUpdate(true);
                    }, 1023);
                    if (res.diningSessionID !== '') {
                        return BillAPIManager.getInstance()
                            .addParty(
                                {
                                    id: getSession(),
                                    diningSessionID: res.diningSessionID,
                                    country: url.cc,
                                    restaurantUnique: url.slug,
                                    jwt: res.jwt,
                                },
                                {
                                    cc: url.cc,
                                    vendor,
                                },
                            )
                            .then((partyRes) => {
                                UpdateManager.getInstance().subscribe({
                                    id: getSession(),
                                    diningSessionID: res.diningSessionID,
                                    country: url.cc,
                                    restaurantUnique: url.slug,
                                });

                                return partyRes;
                            });
                    }
                }

                return res;
            })
            .then((res) => {
                if (!split) {
                    setSplit((res.parties || []).length > 0);
                }
                if (force) {
                    setInit(true);
                }
                if (force || init) {
                    setLastFreshTime(timeUnix());
                    const removedIds = diffItems(orderList.current, res._orderItems);
                    const addedIds = diffItems(res._orderItems, orderList.current);
                    const oldCount = orderList.current.length;
                    const newCount = res._orderItems.length;
                    orderList.current = cloneDeep(res._orderItems || []);

                    if (force && !silent) {
                        setNewOrderIds(addedIds);
                        if (
                            (removedIds.length > 0 && addedIds.length > 0) ||
                            addedIds.length > 0 ||
                            oldCount < newCount
                        ) {
                            notifyChanges(NotificationTypeEnum.Added);
                        } else if (removedIds.length > 0 || oldCount > newCount) {
                            notifyChanges(NotificationTypeEnum.Removed);
                        } else {
                            notifyChanges(NotificationTypeEnum.None);
                        }
                    }
                } else if (orderList.current.length === 0) {
                    orderList.current = cloneDeep(res._orderItems || []);
                } else {
                    const removedIds = diffItems(orderList.current, res._orderItems);
                    const addedIds = diffItems(res._orderItems, orderList.current);
                    const oldCount = orderList.current.length;
                    const newCount = res._orderItems.length;

                    if (removedIds.length > 0 || addedIds.length > 0 || oldCount < newCount || oldCount > newCount) {
                        orderList.current = cloneDeep(res._orderItems || []);
                    }
                    if (addedIds.length > 0) {
                        setNewOrderIds(addedIds);
                    }
                }
                setDiningSession(url, { id: res.diningSessionID, jwt: res.jwt });
                setDetails(res);
                setError(undefined);

                return res;
            })
            .catch((err: any) => {
                console.log({ err });
                const errData = err?.response?.data || err?.data || {};
                if (isNoOrderErr(errData)) {
                    removeDiningSession(url);
                    if (!inRetry) {
                        getDetails({ force, inRetry: true });
                    } else {
                        setError(errData);
                    }
                } else {
                    setError(errData);
                }
            })
            .finally(() => {
                setLoading(false);
            });
    };

    const pullToRefreshHandler: RefreshFuncType = useCallback(() => {
        if (timeUnix() - lastPullToRefreshTime.current > 15) {
            lastPullToRefreshTime.current = timeUnix();
            return getDetails({ force: true });
        }

        return new Promise((resolve) =>
            setTimeout(() => {
                resolve(null);
            }, 2000),
        );
    }, [details]);

    useEffect(() => {
        setPullFn(pullToRefreshHandler);
    }, [pullToRefreshHandler]);

    const checkGlobalDifference = (data: IPaymentDetails) => {
        if (orderList.current.length === 0) {
            orderList.current = cloneDeep(data._orderItems || []);
        }
        const removedIds = diffItems(orderList.current, data?._orderItems || []);
        const addedIds = diffItems(data?._orderItems || [], orderList.current);
        const oldCount = orderList.current.length;
        const newCount = data?._orderItems.length;

        if (removedIds.length > 0 || addedIds.length > 0 || oldCount < newCount || oldCount > newCount) {
            orderList.current = cloneDeep(data?._orderItems || []);
        }
        if (addedIds.length > 0) {
            setNewOrderIds(addedIds);
        }
        if ((removedIds.length > 0 && addedIds.length > 0) || addedIds.length > 0 || oldCount < newCount) {
            notifyChanges(NotificationTypeEnum.Added);
        } else if (removedIds.length > 0 || oldCount > newCount) {
            notifyChanges(NotificationTypeEnum.Removed);
        }
    };

    const updatePaymentDetailsHandler = (update: IUpdatePaymentDetails) => {
        if (!update.details || !vendor) {
            return;
        }
        const updateDetails = parsePaymentDetails(update.details, { vendor });
        setDetails(updateDetails);
    };

    const updateNetworkConnectHandler = () => {
        if (canUpdate) {
            getDetails({});
        }
    };

    useEffect(() => {
        if (!vendor) {
            return;
        }

        const updateManager = UpdateManager.getInstance();
        const fn = updateManager.listen(UpdateMSG.UpdatePaymentDetails, updatePaymentDetailsHandler);
        const fnOnConnect = updateManager.listen(UpdateMSG.UpdateNetworkConnect, updateNetworkConnectHandler);
        return () => {
            if (fn) {
                fn();
            }
            if (fnOnConnect) {
                fnOnConnect();
            }
        };
    }, [vendor]);

    useEffect(() => {
        if (!url.cc || !url.slug || !url.id || !vendor) {
            return;
        }

        const enableOptionalDinerFee =
            vendor?.config?.commissionOptionalDinerFee === EnableEnum.Enable
                ? vendor?.config?.commissionOptionalDinerFee
                : !vendor?.config?.commissionOptionalDinerFee
                ? config?.commissionOptionalDinerFee
                : false;

        if (enableOptionalDinerFee) {
            setODF(optionalDinerFee);
        }

        getDetails({
            odf: enableOptionalDinerFee ? (optionalDinerFee ? 'enable' : 'disable') : undefined,
        }).then((res) => {
            const discount = Number(vendor?.discount?.amount || 0);
            const billAmount = res?.billNumber?.total || 0;

            billGA.view(billAmount, discount);
        });
    }, [urlStr, vendor, isQSR, optionalDinerFee]);

    const retryHandler = () => {
        getDetails({ force: true });
    };

    useEffect(() => {
        if (isQSR) {
            return;
        }

        if (!details) {
            if (isSplashScreenActive(config ?? undefined, vendor)) {
                show({ countryConfig: config ?? undefined, vendor });
            } else {
                hide(true);
            }
        } else {
            hide(true);
        }
    }, [config, vendor, details]);

    useEffect(() => {
        // Ensure the pending page is displayed when retrying payment after navigating back from it
        resetPaymentStore();
        // make the failed payment event fire even after navigating back from confirmation page and retrying
        removeSpecificEventsFromEventStore(['payment_failed']);
    }, []);

    if (error) {
        hide(false);

        return (
            <InvoiceError vendor={vendor} url={url} err={error} lang={lang} loading={loading} onRetry={retryHandler} />
        );
    }

    if (!details || !vendor) {
        return <InvoiceSkeleton />;
    }

    const splitChangeHandler = (enable: boolean) => {
        setSplit(enable);
    };

    const payUnlockPaymentHandler = (gatewayId: string): Promise<boolean> => {
        const sessionID = getSession();
        const diningSessionPayload = getDiningSession(url);
        return BillAPIManager.getInstance()
            .unlockPayment({
                id: sessionID,
                diningSessionID: diningSessionPayload?.id || '0',
                gatewayID: gatewayId,
            })
            .then((res) => {
                return res.result;
            })
            .catch(() => {
                return false;
            });
    };

    // TODO: remove isComoFullPayment
    const payDoneHandler = (payload: IGatewayPayHandler, isComoFullPayment?: boolean) => {
        const { traceId, amount, tip, meta, gatewayId, method, refId, tableName: pgTableName, is3ds } = payload;
        let { paymentElement } = payload;
        let pgName = `${method}_${paymentElement}`.toLowerCase();

        if (meta?.gaEventSuffix) {
            pgName += `_${meta?.gaEventSuffix}`;
            paymentElement = `${paymentElement}_${meta?.gaEventSuffix}` as PaymentElementEnum;
        }

        const diningSessionPayload = getDiningSession(url);
        setClarityTags({ paymentGateway: method, paymentElement, diningSessionID: diningSessionPayload?.id });

        paymentGA.initiated(true, pgName);

        const transactionData = {
            transactionTime: new Date(),
            paymentName: pgName,
        };

        Sentry.setContext('transactionData', transactionData);
        Sentry.setTag('transactionDataTag', JSON.stringify(transactionData));

        const jwt = getDefaultJwt();

        setTimeout(() => {
            routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice/success', {
                dsi: details?.diningSessionID || '',
                amount,
                currency_symbol: vendor?.country.currencySymbol || details?.currency || '',
                method,
                paymentElement,
                ref: refId,
                sid: getSession(),
                tip,
                jwt,
                lang,
                sentryTraceId: traceId,
                gatewayId,
                tableName: pgTableName,
                is3ds: is3ds ? 'true' : 'false',
                ...(meta?.saved ? { saved: 'true' } : {}),
            });
        }, 100);
    };

    const payPendingHandler = (payload: IGatewayPayHandler) => {
        const { traceId, amount, tip, meta, gatewayId, method, refId, tableName: pgTableName } = payload;
        let { paymentElement } = payload;

        if (meta?.gaEventSuffix) {
            paymentElement = `${paymentElement}_${meta?.gaEventSuffix}` as PaymentElementEnum;
        }
        const jwt = getDefaultJwt();

        const diningSessionPayload = getDiningSession(url);
        setClarityTags({ paymentGateway: method, paymentElement, diningSessionID: diningSessionPayload?.id });

        setTimeout(() => {
            routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice/pending', {
                dsi: details?.diningSessionID || '',
                amount,
                currency_symbol: vendor?.country.currencySymbol || details?.currency || '',
                method,
                paymentElement,
                ref: refId,
                sid: getSession(),
                tip,
                jwt,
                lang,
                sentryTraceId: traceId,
                gatewayId,
                tableName: pgTableName,
            });
        }, 100);
    };

    const payFailHandler = (payload: IGatewayPayHandler) => {
        const { traceId, amount, meta, gatewayId, method, refId, tableName: pgTableName, is3ds } = payload;

        let { paymentElement } = payload;
        let pgName = `${method}_${paymentElement}`.toLowerCase();

        if (meta?.gaEventSuffix) {
            pgName += `_${meta?.gaEventSuffix}`;
            paymentElement = `${paymentElement}_${meta?.gaEventSuffix}` as PaymentElementEnum;
        }

        const diningSessionPayload = getDiningSession(url);
        setClarityTags({ paymentGateway: method, paymentElement, diningSessionID: diningSessionPayload?.id });

        payUnlockPaymentHandler(gatewayId);

        paymentGA.initiated(false, pgName);

        const jwt = getDefaultJwt();

        setTimeout(() => {
            routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice/fail', {
                dsi: details?.diningSessionID || '',
                amount,
                currency_symbol: vendor?.country.currencySymbol || details?.currency || '',
                method,
                paymentElement,
                ref: refId,
                jwt,
                lang,
                sentryTraceId: traceId,
                gatewayId,
                tableName: pgTableName,
                is3ds: is3ds ? 'true' : 'false',
            });

            closeSnackbar();
        }, 100);
    };

    const paymentDetailsChangeHandler = (data: IPaymentDetails) => {
        setDetails(data);
        checkGlobalDifference(data);
    };

    const rowClickHandler = () => () => {
        billGA.tapBillItems();
    };

    const rowToppingClickHandler = () => () => {
        billGA.tapBillItems();
    };

    const refreshHandler = () => {
        billGA.refresh();
        getDetails({ force: true });
    };

    const scrollToElement = (element: 'invoice' | 'payment' | 'split') => {
        if (element === 'split') {
            splitSection.current?.scrollIntoView({ behavior: 'smooth' });
        } else if (element === 'payment') {
            paySection.current?.scrollIntoView({ behavior: 'smooth' });
            tipGA.tipBoxDisplayEvent();
        } else {
            document.body?.scrollIntoView({ behavior: 'smooth' });
        }
    };

    const dec = details ? 10 ** (details.currencyPrecision || 0) : 1;
    const yourAmount =
        Math.round(
            (details ? (Number.isNaN(details.bill?.yourShare) ? 0 : parseFloat(details.bill?.yourShare)) : 0) * dec,
        ) / dec;

    const setTipOptionValue = (option: number | undefined) => {
        if (option) {
            tipOptionValue.current = option;
        }
    };

    const performLock = ({ id, gatewayId, diningSessionPayload, method, paymentElement, payload }: any) => {
        return BillAPIManager.getInstance()
            .lockPayment({
                id,
                diningSessionID: diningSessionPayload?.id || '0',
                gatewayID: gatewayId,
            })
            .then((lockRes) => {
                if (lockRes.state === 'acquired') {
                    if (lockRes?.sessions?.length) {
                        enqueueSnackbar(t('You already paid'), {
                            variant: 'info',
                            action: (
                                <Button
                                    onClick={() => {
                                        const item = lockRes.sessions[lockRes.sessions.length - 1];
                                        if (item) {
                                            payDoneHandler({
                                                amount: Number(item.billAmount),
                                                method: method || '',
                                                paymentElement: paymentElement || PaymentElementEnum.None,
                                                refId: item.reference,
                                                tip: item.tipAmount,
                                                gatewayId: payload.gatewayId,
                                                traceId: '',
                                                tableName,
                                            });
                                        }
                                    }}
                                    size="small"
                                    variant="text"
                                    color="inherit"
                                    sx={{ background: 'transparent !important', border: 'none !important' }}
                                >
                                    {t('Invoice')}
                                </Button>
                            ),
                        });
                        return false;
                    }
                    return true;
                }
                if (lockRes.state === 'failedFull') {
                    enqueueSnackbar(t("Your payment didn't go through, The bill might already be fully paid"), {
                        variant: 'warning',
                        action: actionButton,
                    });
                }
                if (lockRes.state === 'failedPartial') {
                    enqueueSnackbar(
                        t(
                            "Your payment didn't go through, Overpayment might happen due to another transaction occurring for this bill",
                        ),
                        {
                            variant: 'warning',
                            action: actionButton,
                        },
                    );
                }
                if (lockRes.state === 'orderClosed') {
                    enqueueSnackbar(
                        t('Oops! It looks like this order has already been closed. Please check with the staff.'),
                        {
                            variant: 'warning',
                        },
                    );
                }
                return false;
            })
            .catch(() => {
                return false;
            });
    };

    const isNewPaymentModule = shouldNewPaymentModuleAcitvate(
        vendor.country.config?.enableNewPaymentModule,
        vendor.config?.enableNewPaymentModule,
    );

    const payBeforePaymentHandler = (payload: IPayBeforePaymentHandler): Promise<boolean> => {
        const diningSessionPayload = getDiningSession(url);
        const { paymentElement, tip, meta, gatewayId, method } = payload;

        setClarityTags({ paymentGateway: method, paymentElement });

        const sessionID = getSession();
        return (
            BillAPIManager.getInstance()
                .getDetails(
                    {
                        restaurantUnique: url.slug,
                        id: sessionID,
                        diningSessionID: diningSessionPayload?.id || '0',
                        tableID: url.id,
                        cc: url.cc,
                        f1: url.f1,
                        f2: url.f2,
                        hash: url.hash,
                        forceFresh: false,
                        jwt: diningSessionPayload?.jwt || undefined,
                        fetchMode: url.fetchMode as FetchModeEnum,
                        payUrl: url.qPayUrl,
                    },
                    {
                        ignoreCache: true,
                        cc: url.cc,
                        vendor,
                        qsr: hasQSRMode,
                    },
                )
                .then((res) => {
                    let pgName = `${method}_${paymentElement}`.toLowerCase();

                    if (meta?.gaEventSuffix) {
                        pgName += `_${meta?.gaEventSuffix}`;
                    }

                    paymentGA.tapPayBtn(yourAmount, pgName, tip, split);
                    campaignGA.tapOnPayWithPromoCodeEvent(!!details.campaignVoucher?.code);
                    tipGA.payTipEvents(tip, pgName, yourAmount, tipOptionValue.current);

                    const removedIds = diffItems(orderList.current || [], res._orderItems, true);
                    const addedIds = diffItems(res._orderItems, orderList.current || [], true);
                    const itemLength = orderList.current.length;
                    const yourShare = details?.bill.yourShare || 0;
                    orderList.current = cloneDeep(res._orderItems || []);
                    if (addedIds.length > 0 || removedIds.length > 0 || res._orderItems.length !== itemLength) {
                        notifyChanges(NotificationTypeEnum.Modified);
                    } else if (res.bill.yourShare !== yourShare) {
                        enqueueSnackbar(t('You’re paying too much'), {
                            variant: 'warning',
                            action: actionButton,
                        });
                    }
                    setDiningSession(url, { id: res.diningSessionID, jwt: res.jwt });
                    setNewOrderIds(addedIds);
                    setDetails(res);
                    return Promise.resolve(
                        addedIds.length === 0 &&
                            removedIds.length === 0 &&
                            res._orderItems.length === itemLength &&
                            res.bill.yourShare === yourShare,
                    );
                })
                .then((res) => {
                    if (!res) {
                        return false;
                    }
                    if (isNewPaymentModule || payload.isFromLoyaltyModule) return true;

                    return performLock({
                        id: sessionID,
                        gatewayId,
                        diningSessionPayload,
                        method,
                        paymentElement,
                        payload,
                    });
                })
                .catch((err) => {
                    const errData = err?.response?.data || err?.data || {};
                    if (isNoOrderErr(errData)) {
                        removeDiningSession(url);
                    }
                    setError(err);
                    return Promise.reject(new Error(t('Oops something went wrong!')));
                }) || Promise.resolve(true)
        );
    };

    const splitEnable = isSplitActive(vendor, isQSR) && loyaltySplitConditions;

    const hasSplitPayment =
        details.billSplit?.mode !== SplitModeTypeEnum.unknown && details.billSplit?.mode !== SplitModeTypeEnum.empty;

    const loyalty = (
        <Loyalty
            getDetails={getDetails}
            paymentDetailsChangeHandler={paymentDetailsChangeHandler}
            setLoading={setLoading}
            payBeforePaymentHandler={payBeforePaymentHandler}
            payDoneHandler={payDoneHandler}
        />
    );

    return (
        <>
            <Head>
                <title>
                    Qlub_ | Invoice {url.slug}, Table {url.id}
                </title>
            </Head>

            <CustomerContainer
                maxWidth="sm"
                className={classNames(styles.container, {
                    [styles.qsrMode]: isQSR,
                })}
            >
                <div
                    id="invoiceElement"
                    className={classNames({
                        [styles.stickyHelperPaid]: details.billNumber.remaining === 0 && !isQSR,
                        [styles.qsrMode]: isQSR,
                    })}
                >
                    <InvoiceTable
                        id={url.id}
                        details={details}
                        loading={loading}
                        lang={lang || 'en'}
                        onRefresh={refreshHandler}
                        newOrderIds={newOrderIds}
                        onOrderItemClick={rowClickHandler}
                        onOrderItemToppingClick={rowToppingClickHandler}
                        diningSessionID={details.diningSessionID}
                        onVoucherApply={paymentDetailsChangeHandler}
                    />
                </div>

                {!splitEnable && <Box className={styles.stickyAnchor}>{loyalty}</Box>}

                {splitEnable && (
                    <SplitSection
                        details={details}
                        isQSR={isQSR}
                        url={url}
                        billUpdateTriggered={billUpdateTriggered}
                        onScrollToElement={scrollToElement}
                        onSplitChangeHandler={splitChangeHandler}
                        onSetAmount={paymentDetailsChangeHandler}
                        onTipModalOpenRef={tipModalOpenFunc}
                        smartTipModalHandlerRef={smartTipModalHandleRef}
                        currencyFormat={currencyFormat}
                        loyalty={loyalty}
                    />
                )}
                <div ref={splitSection} />

                <SubscribeElsewhere />

                {details && vendor && (
                    <Paper elevation={0}>
                        <div
                            className={classNames(styles.pay, {
                                [styles.payMinHeight]: !isQSR && splitEnable,
                                [styles.payMinHeightPaid]: !isQSR && splitEnable && details.billNumber.remaining === 0,
                                [styles.payMinHeightFull]: !isQSR && !splitEnable,
                            })}
                            ref={paySection}
                        >
                            <Pay
                                diningSessionID={details.diningSessionID}
                                url={url}
                                loading={loading}
                                amount={yourAmount}
                                lang={lang || null}
                                tableName={tableName}
                                details={details}
                                paymentGateways={vendor.paymentGatewayList?.itemsList || []}
                                currencyPrecision={details.currencyPrecision}
                                onBeforePayment={payBeforePaymentHandler}
                                onUnlockPayment={payUnlockPaymentHandler}
                                onDone={payDoneHandler}
                                onPending={payPendingHandler}
                                onFail={payFailHandler}
                                onVoucherApply={paymentDetailsChangeHandler}
                                onRefresh={() => {
                                    return getDetails({ force: true, silent: true });
                                }}
                                remainingAmount={String(Number(details.bill.remaining || '0'))}
                                yourShareAmount={String(Number(details.bill.yourShare || '0'))}
                                setTipModalOpenFunc={(fn) => {
                                    tipModalOpenFunc.current = fn;
                                }}
                                hasSplitPayment={hasSplitPayment}
                                setTipOptionValue={setTipOptionValue}
                                optionalDinerFee={optionalDinerFee}
                                setOptionalDinerFee={setOptionalDinerFee}
                                currencyFormat={currencyFormat}
                                vendor={vendor}
                                config={config ?? undefined}
                                campaignVoucher={details?.campaignVoucher}
                                smartTipModalHandlerRef={smartTipModalHandleRef}
                            />
                        </div>
                    </Paper>
                )}
            </CustomerContainer>
        </>
    );
};

export default Invoice;
