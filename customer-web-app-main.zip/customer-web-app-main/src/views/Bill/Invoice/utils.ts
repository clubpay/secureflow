import { timeUnix } from '@clubpay/customer-common-module/src/utility/k_time';
import { differenceWith } from 'lodash';
import { IOrderItemView } from '@/repositories/bill';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import { IKeyValueOrder } from '@qlub-dev/qlub-kit/dist/types/InvoiceItemTypes';
import { IRestaurant, OrderPaymentMethodEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { IURLTopology, QSRRouterModeEnum } from '@clubpay/customer-common-module/src/hook/router';

export function getIdFromOrder(order: IKeyValueOrder, index?: number, dontUseTime?: boolean) {
    if (dontUseTime) {
        return `${order.title}_${order.qty}_${order.value}`;
    }
    if (index !== undefined) {
        return `${order.title}_${order.qty}_${order.value}_${order.updatedAt}_${index}`;
    }
    return `${order.title}_${order.qty}_${order.value}_${order.updatedAt}`;
}

export function diffItems(orders: IOrderItemView[], newOrders: IOrderItemView[], dontUseTime = true) {
    return differenceWith(
        orders.map((item) => {
            return getIdFromOrder(item.item, undefined, dontUseTime);
        }),
        newOrders.map((item) => {
            return getIdFromOrder(item.item, undefined, dontUseTime);
        }),
        (o1, o2) => o1 === o2,
    );
}

export function diffItemsByTime(orders: IOrderItemView[], initOrders: IOrderItemView[]) {
    const now = timeUnix();
    return differenceWith(
        orders.map((item) => {
            return {
                id: getIdFromOrder(item.item),
                item: item.item,
            };
        }),
        initOrders.map((item) => {
            return {
                id: getIdFromOrder(item.item),
                item: item.item,
            };
        }),
        (o1, o2) => o1.id === o2.id,
    )
        .filter((item) => {
            return now - (item.item.updatedAt || 0) > 30;
        })
        .map((item, idx) => getIdFromOrder(item.item, idx));
}

export function isSplashScreenActive(config?: IConfig, vendor?: IRestaurant) {
    if (vendor?.config?.splashEnable !== undefined) {
        return !!vendor?.config?.splashEnable;
    }

    if (vendor?.posVendor?.config?.splashEnable !== undefined) {
        return !!vendor?.posVendor?.config?.splashEnable;
    }

    if (config?.splashEnable !== undefined) {
        return !!config?.splashEnable;
    }
}

export function isQSRMode(url: IURLTopology, isQSR: boolean) {
    const { qsr } = url;
    if (!isQSR) {
        return false;
    }
    if (qsr !== QSRRouterModeEnum.Mixed) {
        return true;
    }
    return url.qsrPayment === OrderPaymentMethodEnum.Default;
}
