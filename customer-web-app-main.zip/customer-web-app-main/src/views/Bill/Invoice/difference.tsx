import { useCallback, useRef } from 'react';
import { merge } from 'lodash';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';

interface INotificationData {
    notModified?: boolean;
    added?: boolean;
    removed?: boolean;
    modified?: boolean;
}

export enum NotificationTypeEnum {
    None = 0,
    Added = 1,
    Removed = 2,
    Modified = 3,
}

export const useInvoiceDifference = (lang?: string) => {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();

    const notificationData = useRef<INotificationData>({});
    const notificationTimeout = useRef<any>(null);

    const notifyChanges = useCallback(
        (type: NotificationTypeEnum) => {
            clearTimeout(notificationTimeout.current);
            notificationTimeout.current = null;
            let payload: INotificationData = {};
            switch (type) {
                default:
                case NotificationTypeEnum.None:
                    payload = {
                        notModified: true,
                    };
                    break;
                case NotificationTypeEnum.Added:
                    payload = {
                        added: true,
                    };
                    break;
                case NotificationTypeEnum.Removed:
                    payload = {
                        removed: true,
                    };
                    break;
                case NotificationTypeEnum.Modified:
                    payload = {
                        modified: true,
                    };
                    break;
            }
            notificationData.current = merge(notificationData.current, payload);
            notificationTimeout.current = setTimeout(() => {
                const d = notificationData.current;
                if (d.modified) {
                    enqueueSnackbar(t('Your bill has been updated, please try to pay again'), {
                        variant: 'warning',
                    });
                } else if ((d.added && d.removed) || d.added) {
                    enqueueSnackbar(t('Your bill has been updated, new items added to the bill'), {
                        variant: 'success',
                    });
                } else if (d.removed) {
                    enqueueSnackbar(t('Your bill has been updated, some items removed from the bill'), {
                        variant: 'success',
                    });
                } else if (d.notModified) {
                    enqueueSnackbar(t('Your bill has not been modified'), { variant: 'info' });
                }
                notificationData.current = {};
                notificationTimeout.current = null;
            }, 500);
        },
        [lang, t],
    );

    return {
        notifyChanges,
    };
};
