import { IItemToPay } from '@/repositories/bill/types';

export interface ISplitOptions {
    totalShares?: number;
    yourShares?: number;
    items?: IItemToPay[];
}

export interface IGetDetailsOption {
    force?: boolean;
    inRetry?: boolean;
    silent?: boolean;
    ignoreCache?: boolean;
    odf?: 'disable' | 'enable';
}
