import React, { FC } from 'react';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import { ChevronRight } from '@mui/icons-material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import useEventsCenter from '@/hooks/eventsCenter';

import styles from './index.module.scss';

interface IProps {
    toggleDrawer: (open: boolean, drawerNo: number) => void;
    billAmount: number;
}

const CTA: FC<IProps> = ({ toggleDrawer, billAmount }) => {
    const { t } = useTranslation('common');
    const { corporateDiscounts: gaEvents } = useEventsCenter();

    const handleClick = () => {
        toggleDrawer(true, 1);
        gaEvents.tapOnCTA(billAmount);
    };

    return (
        <div className={styles.container} onClick={handleClick}>
            <TypographyT
                sx={{
                    color: 'white',
                }}
                typo="title_md"
            >
                {t('Discounts & Offers')}
            </TypographyT>
            <div className={styles.apply}>
                <TypographyT
                    sx={{
                        color: 'white',
                    }}
                    typo="title_sm"
                >
                    {t('Apply')}
                </TypographyT>
                <ChevronRight
                    sx={{
                        color: 'white',
                        fontSize: '20px',
                    }}
                />
            </div>
        </div>
    );
};

export default CTA;
