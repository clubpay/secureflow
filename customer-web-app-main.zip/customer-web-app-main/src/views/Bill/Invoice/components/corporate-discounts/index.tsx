import React, { FC, useRef } from 'react';
import useDiscountStore from '@/store/discounts';
import { CampaignDiscountTypeEnum, IPaymentDetails, IVoucher } from '@/repositories/bill/types';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { VisibilityEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import Drawer, { BottomSheetHandle } from './components/drawer';
import CTA from './components/cta';
import Banner from './components/banner';
import Email from './components/email';
import OTP from './components/otp';
import AppliedDiscount from './components/applied-discount';

interface IProps {
    campaignVoucher?: IVoucher;
    onDiscountApply: (data: IPaymentDetails) => void;
    billAmount: number;
}

const CorporateDiscounts: FC<IProps> = ({ campaignVoucher, onDiscountApply, billAmount }) => {
    const hasVentureDiscountBeenApplied =
        campaignVoucher?.discountType === CampaignDiscountTypeEnum.VENTURE && campaignVoucher.isVoucherOwner;

    const hasCorporateDiscountBeenApplied =
        campaignVoucher?.discountType === CampaignDiscountTypeEnum.CORPORATE && campaignVoucher.isVoucherOwner;

    const amount = useDiscountStore((state) => state.amount);

    const drawer1Ref = useRef<BottomSheetHandle>(null);
    const drawer2Ref = useRef<BottomSheetHandle>(null);
    const drawer3Ref = useRef<BottomSheetHandle>(null);

    const drawerRefs = [drawer1Ref, drawer2Ref, drawer3Ref];

    const { vendor } = useVendor();

    const toggleDrawer = (open: boolean, drawerNo: number) => {
        drawerRefs[drawerNo - 1]?.current?.toggleDrawer(open);
    };

    if (vendor?.config?.discountsAndOffers !== VisibilityEnum.Show || hasVentureDiscountBeenApplied) {
        return null;
    }

    return (
        <>
            {(!amount && !campaignVoucher?.amount) || !hasCorporateDiscountBeenApplied ? (
                <CTA toggleDrawer={toggleDrawer} billAmount={billAmount} />
            ) : (
                <AppliedDiscount amount={(amount || campaignVoucher?.amount)!} />
            )}
            <Drawer ref={drawer1Ref}>
                <Banner toggleDrawer={toggleDrawer} />
            </Drawer>
            <Drawer
                ref={drawer2Ref}
                onBackHandler={() => {
                    toggleDrawer(false, 2);
                    toggleDrawer(true, 1);
                }}
            >
                <Email toggleDrawer={toggleDrawer} billAmount={billAmount} />
            </Drawer>
            <Drawer
                ref={drawer3Ref}
                onBackHandler={() => {
                    toggleDrawer(false, 3);
                    toggleDrawer(true, 2);
                }}
            >
                <OTP toggleDrawer={toggleDrawer} onDiscountApply={onDiscountApply} />
            </Drawer>
        </>
    );
};

export default CorporateDiscounts;
