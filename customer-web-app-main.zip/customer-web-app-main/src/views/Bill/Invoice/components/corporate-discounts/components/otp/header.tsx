import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Typography from '@qlub-dev/qlub-kit/dist/components/Typography';
import React, { FC } from 'react';
import useDiscountStore from '@/store/discounts';
import { useTheme } from '@mui/material';

const Header: FC = () => {
    const email = useDiscountStore((state) => state.email);

    const { t } = useTranslation('common');
    const theme = useTheme();

    return (
        <div>
            <Typography typo="title_md" sx={{ pt: 2 }}>
                {t('Enter 5-digit code')}
            </Typography>
            <Typography
                sx={{ pt: 1, pb: 2, color: theme.qlub.palette.onSurfaceColors.mediumEmphasis }}
                typo="caption_overline"
            >
                {`${t('The 5-digit code is sent to {{email}}', { email })}`}
            </Typography>
        </div>
    );
};

export default Header;
