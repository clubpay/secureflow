import { FC, MouseEvent } from 'react';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getAvailableLang } from '@clubpay/customer-common-module/src/utility/k_lang';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

import styles from './terms.module.scss';

interface IProps {
    toggleDrawer: (open: boolean, drawerNo: number) => void;
}

const Terms: FC<IProps> = ({ toggleDrawer }) => {
    const { routerPush, url, lang } = useQlubRouter();
    const { t } = useTranslation('common');

    const handleClick = (redirectTo: string) => (e: MouseEvent<HTMLSpanElement>) => {
        e.preventDefault();

        toggleDrawer(false, 2);

        routerPush(`/qr/[cc]/${redirectTo}`, {
            cc: url.cc,
            ...getAvailableLang(lang),
        });
    };

    return (
        <div className={styles.message}>
            {interpolateT(t('By using qlub you accept our <terms> and <privacy>'), {
                terms: (
                    <span onClick={handleClick('terms')} className={styles.link}>
                        {t('Terms and Conditions')}
                    </span>
                ),
                privacy: (
                    <span onClick={handleClick('privacy')} className={styles.link}>
                        {t('Privacy Policy')}
                    </span>
                ),
            })}
        </div>
    );
};

export default Terms;
