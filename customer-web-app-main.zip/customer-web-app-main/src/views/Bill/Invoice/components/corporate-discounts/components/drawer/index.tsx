// TODO: move this bottom sheet to qlub-kit to avoid loyalty dependency
import BottomSheet from '@clubpay/loyalty/dist/components/Common/Core/BottomSheet';

import React, { forwardRef, ReactNode, useImperativeHandle, useState } from 'react';
import QlubLogoV2 from '@/assets/images/icons/qlub-logo-v2';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import styles from './index.module.scss';

interface IProps {
    children: ReactNode;
    onBackHandler?: () => void;
}

export interface BottomSheetHandle {
    toggleDrawer: (open: boolean) => void;
}

const Drawer = forwardRef<BottomSheetHandle, IProps>(({ children, onBackHandler }, ref) => {
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);

    const { vendor } = useVendor();

    const toggleDrawer = (open: boolean) => {
        setIsDrawerOpen(open);
    };

    useImperativeHandle(ref, () => ({
        toggleDrawer,
    }));

    return (
        <BottomSheet
            open={isDrawerOpen}
            headerIconComponent={
                vendor?.config?.hideLogo === true ? undefined : (
                    <QlubLogoV2
                        sx={{
                            color: 'var(--iris)',
                            position: 'absolute',
                            width: '100%',
                            height: '2rem',
                            left: 0,
                            pointerEvents: 'none',
                        }}
                    />
                )
            }
            onBackHandler={onBackHandler ?? (() => toggleDrawer(false))}
            headerClassName={styles.logo}
        >
            {children}
        </BottomSheet>
    );
});

export default Drawer;
