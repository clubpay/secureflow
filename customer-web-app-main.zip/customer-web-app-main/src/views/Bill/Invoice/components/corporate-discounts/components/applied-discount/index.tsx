import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { Price } from '@qlub-dev/qlub-kit';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import React, { FC } from 'react';
import DiscountIcon from '@clubpay/customer-common-module/src/component/Icons/DiscountIcon';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

import styles from './index.module.scss';

interface IProps {
    amount: string;
}

const AppliedDiscount: FC<IProps> = ({ amount }) => {
    const { t } = useTranslation('common');
    const { currencyFormat } = useVendor();

    return (
        <div className={styles.container}>
            <TypographyT
                typo="title_md"
                sx={{
                    margin: '12px 0',
                }}
            >
                {t('Discount Applied')}
            </TypographyT>
            <div className={styles.content}>
                <div className={styles.label}>
                    <DiscountIcon color="var(--success)" />
                    <TypographyT typo="title_sm">{t('Corporate discount')}</TypographyT>
                </div>
                <Price
                    value={amount}
                    currencyFormat={currencyFormat}
                    leading={<span>-</span>}
                    bold
                    sx={{
                        color: 'var(--success)',
                    }}
                />
            </div>
        </div>
    );
};

export default AppliedDiscount;
