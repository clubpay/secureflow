import { ChevronRight } from '@mui/icons-material';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import React, { FC } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import styles from './index.module.scss';
import useCheckCorporateDiscountAvailability from '../../hooks/discount-availability-check';
import BannerSkeleton from './skeleton';
import EmptyState from './empty-state';

interface IProps {
    toggleDrawer: (open: boolean, drawerNo: number) => void;
}

const Banner: FC<IProps> = ({ toggleDrawer }) => {
    const { t } = useTranslation('common');
    const { areDiscountsAvailable, isLoading, isError } = useCheckCorporateDiscountAvailability();

    if (isLoading) {
        return <BannerSkeleton />;
    }

    if (!areDiscountsAvailable || isError) {
        return <EmptyState />;
    }

    return (
        <div
            className={styles.container}
            onClick={() => {
                toggleDrawer(false, 1);
                toggleDrawer(true, 2);
            }}
        >
            <TypographyT
                sx={{
                    color: 'white',
                    marginBottom: '6px',
                }}
                typo="tip_single_line_percentage"
            >
                {t('Exclusive corporate discounts')}
            </TypographyT>
            <TypographyT
                sx={{
                    color: 'white',
                }}
                typo="caption_overline"
            >
                {t('Enter your corporate email to unlock special savings on your bill')}
            </TypographyT>
            <hr className={styles.divider} />
            <div className={styles.apply}>
                <TypographyT
                    sx={{
                        color: 'white',
                    }}
                    typo="body_sm"
                >
                    {t('Click here to apply')}
                </TypographyT>
                <ChevronRight
                    sx={{
                        color: 'white',
                        fontSize: '20px',
                    }}
                />
            </div>
        </div>
    );
};

export default Banner;
