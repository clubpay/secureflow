import React from 'react';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import DiscountTagIcon from '@/assets/images/icons/DiscountTag';

import styles from './index.module.scss';

const EmptyState = () => {
    const { t } = useTranslation('common');

    return (
        <div className={styles.container}>
            <div className={styles.content}>
                <div className={styles.iconContainer}>
                    <DiscountTagIcon
                        sx={{
                            color: 'var(--iris)',
                            fontSize: '94px',
                        }}
                    />
                </div>
                <TypographyT typo="title_md">{t('Oops! No discount available')}</TypographyT>
            </div>
        </div>
    );
};

export default EmptyState;
