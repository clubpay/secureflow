import DiscountAPIManager from '@/repositories/discount';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getDiningSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import { useEffect, useState } from 'react';

const useCheckCorporateDiscountAvailability = () => {
    const [areDiscountsAvailable, setAreDiscountsAvailable] = useState<boolean | undefined>(undefined);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [isError, setIsError] = useState<boolean>(false);

    const { url, query } = useQlubRouter();

    useEffect(() => {
        setIsLoading(true);

        if (!query) return;

        DiscountAPIManager.getInstance()
            .getAvailableDiscountTypes({
                countryCode: query?.cc,
                restaurantUnique: query?.slug,
                diningSessionID: query?.dsi || getDiningSession(url)?.id || '',
            })
            .then((res) => {
                setAreDiscountsAvailable(res.types?.includes('CORPORATE_VOUCHER'));
            })
            .catch((error) => {
                console.error('Disocunts(fetch-types): ', error);
                setIsError(true);
            })
            .finally(() => {
                setIsLoading(false);
            });
    }, []);

    return { areDiscountsAvailable, isLoading, isError };
};

export default useCheckCorporateDiscountAvailability;
