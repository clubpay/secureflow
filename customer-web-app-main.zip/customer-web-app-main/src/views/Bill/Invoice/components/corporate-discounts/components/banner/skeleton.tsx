import { Skeleton } from '@mui/material';

const BannerSkeleton = () => {
    return <Skeleton variant="rounded" height={125} />;
};

export default BannerSkeleton;
