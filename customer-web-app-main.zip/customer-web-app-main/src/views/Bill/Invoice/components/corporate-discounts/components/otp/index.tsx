import OtpSectionV2 from '@clubpay/customer-common-module/src/component/Login/OTP/OtpV1';
import React, { FC, useState } from 'react';
import { Button } from '@qlub-dev/qlub-kit';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IPaymentDetails } from '@/repositories/bill/types';
import useDiscountStore from '@/store/discounts';
import { getDiningSession, getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import DiscountAPIManager from '@/repositories/discount';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import BillAPIManager from '@/repositories/bill';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import useEventsCenter from '@/hooks/eventsCenter';
import Header from './header';

import styles from './index.module.scss';

interface IProps {
    toggleDrawer: (open: boolean, drawerNo: number) => void;
    onDiscountApply: (data: IPaymentDetails) => void;
}

const OTP: FC<IProps> = ({ toggleDrawer, onDiscountApply }) => {
    const requiredOtpLength = 5;

    const [otpCode, setOtpCode] = useState('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [isError, setIsError] = useState<boolean>(false);

    const [shouldResendTimerRun, setShouldResendTimerRun] = useState<boolean>(true);

    const otpId = useDiscountStore((state) => state.otpId);
    const isOtpValid = useDiscountStore((state) => state.isOtpValid);
    const email = useDiscountStore((state) => state.email);

    const updateOtpId = useDiscountStore((state) => state.updateOtpId);
    const updateIsOtpValid = useDiscountStore((state) => state.updateIsOtpValid);
    const updateVoucherCode = useDiscountStore((state) => state.updateVoucherCode);
    const updateHasDiscountBeenApplied = useDiscountStore((state) => state.updateHasDiscountBeenApplied);
    const updateDiscountAmount = useDiscountStore((state) => state.updateDiscountAmount);

    const { t } = useTranslation('common');
    const { url, query } = useQlubRouter();
    const { triggerSnackBar } = snackBar();
    const { corporateDiscounts: gaEvents } = useEventsCenter();

    const submitOTPHandler = () => {
        setIsLoading(true);

        DiscountAPIManager.getInstance()
            .validateOTP({
                countryCode: query?.cc,
                restaurantUnique: query?.slug,
                diningSessionID: query?.dsi || getDiningSession(url)?.id || '',
                otpID: otpId!,
                otpCode,
            })
            .then((res) => {
                updateIsOtpValid(!!res.code);
                updateVoucherCode(res.code);

                setShouldResendTimerRun(false);

                return res.code;
            })
            .catch((error) => {
                updateIsOtpValid(false);

                console.error('Error(discounts): failed to validate OTP - ', error);

                throw error;
            })
            .then((voucherCode) => {
                BillAPIManager.getInstance()
                    .validateVoucherCode({
                        code: voucherCode,
                        diningSessionID: query?.dsi || getDiningSession(url)?.id || '',
                        id: getSession(),
                    })
                    .then((res) => {
                        updateHasDiscountBeenApplied(true);
                        onDiscountApply(res.paymentDetails);

                        const discountAmount = res?.paymentDetails?.campaignVoucher?.amount;
                        updateDiscountAmount(discountAmount);

                        gaEvents.discountApplied(
                            email || '',
                            Number(discountAmount || 0),
                            res?.paymentDetails?.billNumber?.billAmount,
                        );

                        toggleDrawer(false, 3);
                    })
                    .catch((error) => {
                        console.error('Error(discounts): failed to apply voucher code - ', error);

                        triggerSnackBar(t('Unable to apply the discount. Please try again!'), {
                            variant: 'error',
                            persist: false,
                        });

                        throw error;
                    });
            })
            .catch(() => {
                setIsError(true);
            })
            .finally(() => {
                setIsLoading(false);
            });
    };

    const resendOTPHandler = () => {
        setIsLoading(true);
        setShouldResendTimerRun(false);

        DiscountAPIManager.getInstance()
            .checkDiscountEligibilty({
                countryCode: query?.cc,
                restaurantUnique: query?.slug,
                email: email || '',
                diningSessionID: query?.dsi || getDiningSession(url)?.id || '',
            })
            .then((res) => {
                updateOtpId(res?.otpID);
                setShouldResendTimerRun(true);
            })
            .catch((err) => {
                console.error('Error(discounts): failed to resend OTP - ', err);

                triggerSnackBar(t('Something went wrong. Please try again!'), {
                    variant: 'error',
                    persist: false,
                });
            })
            .finally(() => {
                setIsLoading(false);
            });
    };

    return (
        <div className={styles.container}>
            <div>
                <Header />
                <OtpSectionV2
                    numInputs={requiredOtpLength}
                    code={otpCode}
                    onSetCode={(val) => {
                        setOtpCode(val);
                    }}
                    showResendCode
                    resendSmsCooldown={30}
                    resendTimer={shouldResendTimerRun}
                    resendSms={() => resendOTPHandler()}
                    error={isError || isOtpValid === false}
                />
            </div>
            <Button
                variant="contained"
                className={styles.submit}
                onClick={submitOTPHandler}
                loading={isLoading}
                disabled={isLoading || otpCode.length < requiredOtpLength}
            >
                {t('Continue')}
            </Button>
        </div>
    );
};

export default OTP;
