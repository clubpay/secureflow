import Collapse from '@mui/material/Collapse';
import * as Yup from 'yup';
import TextField from '@mui/material/TextField';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import { Form, Formik, FormikConfig } from 'formik';
import React, { FC, useState } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Button } from '@qlub-dev/qlub-kit';
import DiscountAPIManager from '@/repositories/discount';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getDiningSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import useDiscountStore from '@/store/discounts';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import useEventsCenter from '@/hooks/eventsCenter';
import Terms from './terms';

import styles from './index.module.scss';

interface IProps {
    toggleDrawer: (open: boolean, drawerNo: number) => void;
    billAmount: number;
}

const Email: FC<IProps> = ({ toggleDrawer, billAmount }) => {
    const [isEligible, setIsEligible] = useState<boolean | undefined>();

    const updateEmail = useDiscountStore((state) => state.updateEmail);
    const updateOtpId = useDiscountStore((state) => state.updateOtpId);

    const { t } = useTranslation('common');
    const { url, query } = useQlubRouter();
    const { triggerSnackBar } = snackBar();
    const { corporateDiscounts: gaEvents } = useEventsCenter();

    const validationSchema = Yup.object().shape({
        email: Yup.string().required(t('Email is required!')).email(t('Email is not valid!')),
    });

    const formSubmitHandler: FormikConfig<{ email: string }>['onSubmit'] = (
        values: { email: string },
        { setSubmitting },
    ) => {
        setSubmitting(true);

        DiscountAPIManager.getInstance()
            .checkDiscountEligibilty({
                countryCode: query?.cc,
                restaurantUnique: query?.slug,
                email: values.email,
                diningSessionID: query?.dsi || getDiningSession(url)?.id || '',
            })
            .then((res) => {
                setIsEligible(res?.validated);

                updateOtpId(res?.otpID);
                updateEmail(values?.email);

                const emailDomain = values?.email.split('@')[1];
                gaEvents.submitEmail(emailDomain, billAmount);

                if (res?.validated === true) {
                    toggleDrawer(false, 2);
                    toggleDrawer(true, 3);
                } else {
                    triggerSnackBar(t('This email is not eligible for corporate discounts at the moment'), {
                        variant: 'error',
                        persist: false,
                    });
                }
            })
            .catch(() => {
                setIsEligible(undefined);

                triggerSnackBar(t('Something went wrong. Please try again!'), {
                    variant: 'error',
                    persist: false,
                });
            })
            .finally(() => {
                setSubmitting(false);
            });
    };

    return (
        <Formik
            initialValues={{
                email: '',
            }}
            enableReinitialize
            validationSchema={validationSchema}
            onSubmit={formSubmitHandler}
            validateOnMount={false}
            validateOnBlur
            validateOnChange={false}
        >
            {({ values, handleChange, handleBlur, errors, isSubmitting }): JSX.Element => {
                const isError = !!errors?.email || isEligible === false;
                const errorMessage =
                    errors?.email ?? (isEligible === false ? t("This email isn't eligible for a discount") : '');

                return (
                    <Form className={styles.container}>
                        <div>
                            <TypographyT
                                typo="title_md"
                                sx={{
                                    marginY: '1rem',
                                }}
                            >
                                {t('Enter your email')}
                            </TypographyT>
                            <TextField
                                fullWidth
                                placeholder={t('Your Email Address')}
                                onChange={(e) => {
                                    setIsEligible(undefined);
                                    handleChange(e);
                                }}
                                value={values.email}
                                name="email"
                                helperText={
                                    <Collapse in={isError} timeout={500}>
                                        <TypographyT typo="caption_overline" className={styles.errorMessage}>
                                            {errorMessage}
                                        </TypographyT>
                                    </Collapse>
                                }
                                error={isError}
                                className={styles.emailInput}
                                onBlur={handleBlur}
                            />
                        </div>
                        <div className={styles.bottomContent}>
                            <Terms toggleDrawer={toggleDrawer} />
                            <Button variant="contained" type="submit" disabled={isSubmitting} className={styles.submit}>
                                {t('Continue')}
                            </Button>
                        </div>
                    </Form>
                );
            }}
        </Formik>
    );
};

export default Email;
