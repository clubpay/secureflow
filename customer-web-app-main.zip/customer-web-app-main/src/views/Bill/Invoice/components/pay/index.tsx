import React, { Dispatch, FC, RefObject, SetStateAction, useMemo, useRef, useState } from 'react';
import OrderSummary from '@/components/Bill/OrderSummary';
import PaymentGateway from '@/components/Bill/PaymentGateway';
import VentureVoucher, { VoucherViewEnum } from '@/components/Bill/VentureVoucher';
import LoyaltyRedemptionDetails from '@clubpay/loyalty/dist/drivers/customer/Confirmation/Checkout';
import LoyaltyBurn from '@clubpay/loyalty/dist/drivers/customer/Redemption';
import { LoyaltyService } from '@clubpay/loyalty/dist/types';
import NormalTip from '@/components/Tip/normal';
import BillAPIManager, { IPaymentDetails, IVoucher } from '@/repositories/bill';
import { IURLTopology } from '@clubpay/customer-common-module/src/hook/router';
import {
    IGatewayPayHandler,
    IPayBeforePaymentHandler,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import { EnableEnum, IPaymentGatewayView, IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { timeUnix } from '@clubpay/customer-common-module/src/utility/k_time';
import { Divider } from '@qlub-dev/qlub-kit';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import OptionalDinerFee from '@/components/Bill/OptionalDinerFee';
import CorporateDiscounts from '@/views/Bill/Invoice/components/corporate-discounts';
import { TipToggleFunc } from '@/components/Tip/normal/types';
import useODFAvailabilityCheck from '@/hooks/odf-availability';
import SmartTip, { ISmartTipModalHandler } from '@/components/Tip/smart';

import styles from './index.module.scss';

interface IProps {
    diningSessionID: string;
    url: IURLTopology;
    loading: boolean;
    amount: number;
    vendor: IRestaurant;
    tableName: string;
    lang: string | null;
    details: IPaymentDetails;
    paymentGateways: IPaymentGatewayView[];
    currencyPrecision: number;
    config: IConfig | undefined;
    remainingAmount: string;
    yourShareAmount: string;
    hasSplitPayment: boolean;
    onBeforePayment: (payload: IPayBeforePaymentHandler) => Promise<boolean>;
    onUnlockPayment: (gatewayId: string) => Promise<boolean>;
    onDone: (payload: IGatewayPayHandler, isComoFullPayment?: boolean) => void;
    onPending: (payload: IGatewayPayHandler) => void;
    onFail: (payload: IGatewayPayHandler) => void;
    onVoucherApply: (data: IPaymentDetails) => void;
    onRefresh: () => Promise<any>;
    setTipModalOpenFunc: (fn: TipToggleFunc) => void;
    smartTipModalHandlerRef?: RefObject<ISmartTipModalHandler>;
    setTipOptionValue: (option: number | undefined) => void;
    optionalDinerFee: boolean;
    setOptionalDinerFee: Dispatch<SetStateAction<boolean>>;
    currencyFormat: CurrencyFormat;
    campaignVoucher?: IVoucher;
}

const Pay: FC<IProps> = ({
    diningSessionID,
    url,
    amount,
    loading: invoiceLoading,
    vendor,
    tableName,
    lang,
    paymentGateways,
    currencyPrecision,
    config,
    yourShareAmount,
    remainingAmount,
    details,
    hasSplitPayment,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onPending,
    onFail,
    onVoucherApply,
    onRefresh,
    setTipModalOpenFunc,
    smartTipModalHandlerRef,
    setTipOptionValue,
    optionalDinerFee,
    setOptionalDinerFee,
    currencyFormat,
    campaignVoucher,
}) => {
    const [normalTip, setNormalTip] = useState(0);
    const [smartTip, setSmartTip] = useState(0);

    const [tipModalOpen, setTipModalOpen] = useState<boolean>(false);
    const [paymentHeight, setPaymentHeight] = useState(0);
    const [loading, setLoading] = useState(false);

    const tipModalOpenFunc = useRef<TipToggleFunc | undefined>(undefined);
    const ref = useRef<HTMLDivElement | null>(null);

    const changeTipHandler = (val: number, option?: number) => {
        setTipOptionValue(option);
        setNormalTip(val);
    };

    const changeSmartTipHandler = (val: number) => {
        setSmartTip(val);
    };

    const setTipModalOpenFuncHandler = (fn: TipToggleFunc) => {
        tipModalOpenFunc.current = fn;
        setTipModalOpenFunc(fn);
    };

    const scrollToPay = () => {
        setTimeout(() => {
            ref.current?.scrollIntoView({ behavior: 'smooth' });
        }, 200);
    };

    const updateTimestamp = useMemo(() => {
        return timeUnix();
    }, [details]);

    const paymentGatewayLoadingHandler = (val: boolean) => {
        setLoading(val);
    };

    const tip = smartTip || normalTip || 0;

    const total = sumAmounts(currencyPrecision, amount, tip);

    const paymentOnTipModal = useMemo(() => {
        const activePaymentOnTipModal = vendor.config.tipModalWithPayment || config?.tipModalWithPayment;
        return Boolean(activePaymentOnTipModal ? vendor.paymentGatewayList.hasPgGroup : false);
    }, [vendor, config?.tipModalWithPayment]);

    const isODFAvailable = useODFAvailabilityCheck({ odf: details.bill.optionalDinerFee });
    const isSmartTipEnabled = (vendor?.config?.smartTip ?? config?.smartTip) === EnableEnum.Enable;

    return (
        <div className={styles.pay}>
            <NormalTip
                vendor={vendor}
                config={config}
                details={details}
                myTotal={total}
                lang={lang}
                disabled={loading}
                paymentOnTipModal={paymentOnTipModal}
                paymentHeight={paymentHeight}
                setTipModalOpenFunc={setTipModalOpenFuncHandler}
                onChange={changeTipHandler}
                onTipModalOpen={(open) => {
                    setTipModalOpen(open);
                }}
                currencyFormat={currencyFormat}
            />
            <div>
                <Divider type="fullWidth" />
            </div>
            <CorporateDiscounts
                onDiscountApply={onVoucherApply}
                campaignVoucher={campaignVoucher}
                billAmount={details?.billNumber?.billAmount}
            />
            <div>
                <Divider type="fullWidth" />
            </div>
            <LoyaltyBurn
                onBeforePayment={onBeforePayment}
                onRefresh={onRefresh}
                onDone={onDone}
                services={[LoyaltyService.Rotana, LoyaltyService.Qlub]}
                api={{
                    bill: BillAPIManager.getInstance() as any,
                }}
            />

            <LoyaltyRedemptionDetails />

            <VentureVoucher
                config={config}
                diningSessionID={diningSessionID}
                details={details}
                onVoucherApply={onVoucherApply}
                view={VoucherViewEnum.Card}
            />
            <OptionalDinerFee
                vendor={vendor}
                config={config}
                details={details}
                checked={optionalDinerFee}
                setChecked={setOptionalDinerFee}
                currencyFormat={currencyFormat}
            />
            <OrderSummary
                loading={invoiceLoading}
                currencyPrecision={currencyPrecision}
                tip={tip}
                total={total}
                yourShareAmount={yourShareAmount}
                details={details}
                lang={lang}
                vendor={vendor}
                id={url.id}
                scrollToElement={scrollToPay}
                hasSplitPayment={hasSplitPayment}
                currencyFormat={currencyFormat}
            />
            {isSmartTipEnabled && !isODFAvailable && (
                <SmartTip details={details} ref={smartTipModalHandlerRef} onChange={changeSmartTipHandler} />
            )}
            <PaymentGateway
                diningSessionID={diningSessionID}
                url={url}
                amount={amount}
                vendor={vendor}
                tableName={tableName}
                lang={lang}
                paymentGateways={paymentGateways}
                currencyPrecision={currencyPrecision}
                tip={tip}
                hasSplitPayment={hasSplitPayment}
                onBeforePayment={onBeforePayment}
                onUnlockPayment={onUnlockPayment}
                onDone={onDone}
                onPending={onPending}
                onFail={onFail}
                updateTimestamp={updateTimestamp}
                remainingAmount={Number(remainingAmount)}
                total={total}
                onTipModalOpenRef={tipModalOpenFunc}
                smartTipModalHandlerRef={smartTipModalHandlerRef}
                paymentOnTopLayer={paymentOnTipModal && tipModalOpen}
                onHeightChange={(height) => {
                    setPaymentHeight(height);
                }}
                onLoading={paymentGatewayLoadingHandler}
            />
            <div ref={ref} />
        </div>
    );
};

export default Pay;
