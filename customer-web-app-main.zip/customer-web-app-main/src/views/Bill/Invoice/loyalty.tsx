import { Dispatch, FC, SetStateAction } from 'react';
import LoyaltyOffers from '@clubpay/loyalty/dist/drivers/customer/Offers';
import LoyaltyBurn from '@clubpay/loyalty/dist/drivers/customer/Redemption';
import LoyaltySubscribe from '@clubpay/loyalty/dist/drivers/customer/Subscription/Checkout';
import BillAPIManager, { IPaymentDetails } from '@/repositories/bill';
import Divider from '@qlub-dev/qlub-kit/dist/components/Divider';
import { LoyaltyService } from '@clubpay/loyalty/dist/types';
import {
    IGatewayPayHandler,
    IPayBeforePaymentHandler,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IGetDetailsOption } from './types';

import styles from './loyalty.module.scss';

interface IInvoiceLoyaltyProps {
    getDetails: (options: IGetDetailsOption) => Promise<null> | Promise<void | IPaymentDetails>;
    paymentDetailsChangeHandler: (data: IPaymentDetails) => void;
    setLoading: Dispatch<SetStateAction<boolean>>;
    payBeforePaymentHandler: (payload: IPayBeforePaymentHandler) => Promise<boolean>;
    payDoneHandler: (payload: IGatewayPayHandler, isComoFullPayment?: boolean) => void;
}

const Loyalty: FC<IInvoiceLoyaltyProps> = ({
    getDetails,
    paymentDetailsChangeHandler,
    setLoading,
    payBeforePaymentHandler,
    payDoneHandler,
}) => {
    return (
        <>
            <LoyaltySubscribe
                api={{
                    bill: BillAPIManager.getInstance() as any,
                }}
                onRefresh={async () => {
                    getDetails({ force: true, silent: true });
                }}
                onSetAmount={paymentDetailsChangeHandler}
                setBillDetailsLoading={setLoading} // TODO: pass a fn wrapped around setState
            />
            <LoyaltyBurn
                onBeforePayment={payBeforePaymentHandler}
                onRefresh={async () => {
                    getDetails({ force: true, silent: true });
                }}
                onDone={payDoneHandler}
                enableTriggerTopDivider
                services={[LoyaltyService.Como]}
                api={{
                    bill: BillAPIManager.getInstance() as any,
                }}
            />

            <div className={styles.dividerContainer}>
                <Divider type="fullWidth" />
            </div>

            <LoyaltyOffers
                onRefresh={async () => {
                    getDetails({ force: true, silent: true });
                }}
            />
        </>
    );
};

export default Loyalty;
