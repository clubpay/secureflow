import React, { useEffect, useMemo, useState } from 'react';
import Head from 'next/head';
import { Error as IError } from '@clubpay/customer-common-module/src/repository/common/type';
import InvoiceSkeleton from '@/components/Bill/InvoiceSkeleton';
import InvoiceTable from '@/components/Bill/InvoiceTable';
import { NextPageWithLayout } from '@/layout/types';
import { Divider, PriceItem, SplitPriceLabel, TotalPrice } from '@qlub-dev/qlub-kit';
import BillAPIManager, { IPaymentDetails } from '@/repositories/bill';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import InvoiceError from '@clubpay/customer-common-module/src/component/InvoiceError';

import styles from './index.module.scss';

export const Receipt: NextPageWithLayout = () => {
    const { t } = useTranslation('common');
    const { vendor, currencyFormat } = useVendor();
    const { lang, url, query, isQSR: hasQSRMode } = useQlubRouter();
    const [details, setDetails] = useState<IPaymentDetails | undefined>(undefined);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<IError | undefined>(undefined);

    const { dsID: dsi, prID: pri } = query as unknown as { dsID: string; prID: string };

    const getDetails = () => {
        if (loading) {
            return Promise.resolve(null);
        }

        setLoading(true);
        return BillAPIManager.getInstance()
            .getReceiptReport(
                {
                    dsi,
                    pri,
                },
                {
                    cc: url.cc,
                    vendor,
                    qsr: hasQSRMode,
                    dsi,
                },
            )
            .then((res) => {
                setDetails(res);
                return res;
            })
            .catch((err: any) => {
                const errData = err?.response?.data || {};
                setError(errData);
            })
            .finally(() => {
                setLoading(false);
            });
    };

    useEffect(() => {
        if (!dsi || !pri || !vendor) {
            return;
        }

        getDetails();
    }, [dsi, pri, vendor]);

    const priceData = useMemo(() => {
        if (!details) {
            return [];
        }
        const array: PriceItem[] = [
            {
                label: SplitPriceLabel.yourShare,
                text: t('You pay'),
                value: details.billNumber.yourShare,
            },
        ];

        return array;
    }, [details, t]);

    if (error) {
        return <InvoiceError vendor={vendor} url={url} err={error} lang={lang} onRetry={getDetails} />;
    }

    if (!details || !vendor) {
        return <InvoiceSkeleton />;
    }

    return (
        <>
            <Head>
                <title>Qlub_ | Receipt {url.slug}</title>
            </Head>
            <div id="invoiceElement" className={styles.container}>
                <InvoiceTable
                    id={url.id}
                    details={details}
                    loading={loading}
                    lang={lang || 'en'}
                    onRefresh={getDetails}
                    newOrderIds={[]}
                    diningSessionID={details.diningSessionID}
                />
                {details && vendor && (
                    <>
                        <Divider type="fullWidth" />
                        <div className={styles.paid}>
                            <TotalPrice priceData={priceData} currencyFormat={currencyFormat} />
                        </div>
                    </>
                )}
            </div>
        </>
    );
};

export default Receipt;
