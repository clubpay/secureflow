import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';

export const useGetQlubBrandingMode = () => {
    const { vendor } = useVendor();
    const { config: countryConfig } = useConfigContext();

    if (vendor?.config.enableBrandingInConfirmationPage) {
        return vendor?.config.enableBrandingInConfirmationPage;
    }

    if (countryConfig?.enableBrandingInConfirmationPage) {
        return countryConfig?.enableBrandingInConfirmationPage;
    }

    return undefined;
};
