import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { EnableEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';
import { useMemo } from 'react';

const useFooterBannerConfigs = () => {
    const { vendor } = useVendor();
    const { config: countryConfig } = useConfigContext();
    const { lang } = useQlubRouter();

    const shouldShowFooterBanner = useMemo(() => {
        if (vendor?.config?.confirmationPageFooterMessageVisibility === EnableEnum.Enable) {
            return true;
        }

        if (vendor?.config?.confirmationPageFooterMessageVisibility === EnableEnum.Disable) {
            return false;
        }

        return countryConfig?.confirmationPageFooterMessageVisibility === EnableEnum.Enable;
    }, [
        countryConfig?.confirmationPageFooterMessageVisibility,
        vendor?.config?.confirmationPageFooterMessageVisibility,
    ]);

    const footerMessageLink =
        vendor?.config?.confirmationPageFooterMessageLink ?? countryConfig?.confirmationPageFooterMessageLink ?? '';

    const footerMessageText = useMemo(() => {
        const restaurantLevelFooterText = getLocaleText(
            vendor?.config?.confirmationPageFooterMessageText || '',
            lang,
            '',
        );

        const countryLevelFooterText = getLocaleText(countryConfig?.confirmationPageFooterMessageText || '', lang, '');

        return restaurantLevelFooterText || countryLevelFooterText;
    }, [vendor?.config?.confirmationPageFooterMessageText, countryConfig?.confirmationPageFooterMessageText, lang]);

    return {
        shouldShowFooterBanner,
        footerMessageText,
        footerMessageLink,
    };
};

export default useFooterBannerConfigs;
