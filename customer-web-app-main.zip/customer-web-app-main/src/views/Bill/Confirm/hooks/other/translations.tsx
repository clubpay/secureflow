import React, { useMemo } from 'react';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { Price } from '@qlub-dev/qlub-kit';
import { getCurrencyPrecision } from '@clubpay/customer-common-module/src/utility/k_currency';
import { ITranslation } from '../../types';

interface ITranslations {
    pending: ITranslation;
    done: ITranslation;
    fullyPaid: ITranslation;
    partiallyPaid: ITranslation;
    unpaid: (amount: string) => ITranslation;
}

const useTranslations = (): ITranslations => {
    const { vendor, currencyFormat } = useVendor();
    const { t } = useTranslation('common');
    const currencyPrecision = useMemo(() => getCurrencyPrecision(vendor?.country.currencySymbol), [vendor]);

    return {
        pending: {
            paymentMessage: t('Payment approval by the bank in progress'),
            badgeText: t('Pending'),
        },
        done: {
            badgeText: t('Payment Done'),
            paymentMessage: t('Your payment is done'),
        },
        fullyPaid: {
            badgeText: t('Fully Paid'),
            paymentMessage: t('Payment was successful'),
        },
        partiallyPaid: {
            badgeText: t('Partially Paid'),
            paymentMessage: t('Payment was successful'),
        },
        unpaid: (amount: string) => ({
            badgeText: t('Failed'),
            paymentDescText: t('Please try again'),
            paymentMessage: t('Payment was unsuccessful!'),
            hint: interpolateT(t(' <price>  is left to pay for your table'), {
                price: (
                    <Price
                        bold
                        value={amount}
                        currencyFormat={{
                            ...currencyFormat,
                            currencyPrecision: currencyPrecision || currencyFormat?.currencyPrecision,
                        }}
                    />
                ),
            }),
        }),
    };
};

export default useTranslations;
