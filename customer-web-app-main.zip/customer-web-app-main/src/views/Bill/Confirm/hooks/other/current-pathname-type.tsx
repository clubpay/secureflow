import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useMemo } from 'react';
import { PathnameType } from '../../enums';
import { failurePaths, pendingPaths, successPaths } from '../../constants';

const useGetCurrentPathnameType = () => {
    const { pathname } = useQlubRouter();

    const urlType = useMemo(() => {
        if (successPaths.indexOf(pathname) > -1) {
            return PathnameType.SUCCESS;
        }

        if (pendingPaths.indexOf(pathname) > -1) {
            return PathnameType.PENDING;
        }

        if (failurePaths.indexOf(pathname) > -1) {
            return PathnameType.FAILED;
        }
    }, [pathname]);

    return urlType;
};

export default useGetCurrentPathnameType;
