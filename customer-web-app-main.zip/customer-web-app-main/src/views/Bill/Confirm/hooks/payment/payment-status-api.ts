import BillAPIManager from '@/repositories/bill';
import usePaymentStore from '@/store/payment';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import useSentryTrace from '@clubpay/customer-common-module/src/hook/sentry/useSentryTrace';
import { IStartSpanResponse, ITransactionObject } from '@clubpay/customer-common-module/src/hook/sentry/types';
import { getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import { MutableRefObject, useCallback } from 'react';
import { captureException } from '@sentry/nextjs';
import { RecordStatusEnum } from '@/repositories/bill/enums';
import usePaymentFallbackData from './fallback-data';

interface IProps {
    spanRef: MutableRefObject<IStartSpanResponse>;
    traceRef: MutableRefObject<ITransactionObject>;
}

const usePaymentStatus = ({ spanRef, traceRef }: IProps) => {
    const updateHasMaxTryCountBeenReached = usePaymentStore((state) => state.updateHasMaxTryCountBeenReached);
    const updatePaymentStatusData = usePaymentStore((state) => state.updatePaymentStatusData);
    const updateIsLoading = usePaymentStore((state) => state.updateIsLoading);

    const paymentStatusData = usePaymentStore((state) => state.statusData);

    const { query } = useQlubRouter();
    const { finishTrace } = useSentryTrace();
    const { fallbackData } = usePaymentFallbackData();

    const fallbackFn = useCallback(() => {
        updatePaymentStatusData(fallbackData);
    }, [fallbackData]);

    const callGetPaymentStatus = useCallback(
        (force = false) => {
            if (paymentStatusData === undefined || query === undefined) {
                updateIsLoading(true);
            }

            if (query.ref) {
                BillAPIManager.getInstance()
                    .getStatus({
                        id: getSession(query.sid),
                        reference: query.ref,
                        diningSessionID: query.dsi || '',
                        force,
                    })
                    .then((res) => {
                        if (!res?.amount) {
                            res.amount = query.amount;
                        }
                        if (!res?.currency) {
                            res.currency = query.currencySymbol || '';
                        }

                        updatePaymentStatusData(res);

                        if (res?.record?.status === RecordStatusEnum.failed) {
                            updateHasMaxTryCountBeenReached(true);
                        }
                    })
                    .catch((err) => {
                        try {
                            spanRef.current.span.description = `${err?.message}`;
                            spanRef.current.span.setTag('qlub.error_location', 'paymentGetStatus');
                            traceRef.current.transaction.setTag('qlub.error_location', 'paymentGetStatus');
                            spanRef.current.finishSpan();
                            finishTrace(traceRef.current.transaction);
                        } catch (e) {
                            captureException(e);
                        }

                        fallbackFn();
                    })
                    .finally(() => {
                        updateIsLoading(false);
                    });
            } else {
                fallbackFn();
            }
        },
        [query, fallbackFn],
    );

    return callGetPaymentStatus;
};

export default usePaymentStatus;
