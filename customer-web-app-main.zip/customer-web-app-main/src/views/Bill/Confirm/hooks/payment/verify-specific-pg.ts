import PaymentAPIManager from '@clubpay/customer-payment-module/src/repository';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { PGNameEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';

const useVerifySpecificPG = () => {
    const { query } = useQlubRouter();
    const pgName = query.method as PGNameEnum;
    const apiManager = PaymentAPIManager.getInstance();

    const verifyStripe = async (isSuccessful: boolean) => {
        await apiManager.paymentStripeVerify({
            id: query.sid || '',
            diningSessionID: query.dsi || '',
            gatewayID: query.gwid as string,
            intentID: query.payment_intent as string,
            reference: query.ref,
            success: isSuccessful,
            billAmount: String(Number(query.amount) - Number(query.tip || '0')),
            tipAmount: query.tip || '0',
        });
    };

    const verifyStripeConnect = async (isSuccessful: boolean) => {
        await apiManager.paymentStripeConnectVerify({
            id: query.sid || '',
            diningSessionID: query.dsi || '',
            gatewayID: query.gwid as string,
            intentID: query.payment_intent as string,
            reference: query.ref,
            success: isSuccessful,
            billAmount: String(Number(query.amount) - Number(query.tip || '0')),
            tipAmount: query.tip || '0',
        });
    };

    const verifyMoyasar = async () => {
        await apiManager.payMoyasarVerify({
            diningSessionID: query.dsi || '',
            gatewayID: query.gwid as string,
            reference: query.ref,
        });
    };

    const verify = async () => {
        // eslint-disable-next-line default-case
        switch (pgName) {
            case PGNameEnum.Stripe:
                await verifyStripe(true);
                break;
            case PGNameEnum.StripeConnect:
                await verifyStripeConnect(true);
                break;
            case PGNameEnum.Moyasar:
                await verifyMoyasar();
                break;
        }

        return Promise.resolve();
    };

    return {
        verify,
    };
};

export default useVerifySpecificPG;
