import BillAPIManager from '@/repositories/bill';
import usePaymentStore from '@/store/payment';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { QSRRouterModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getDiningSession, getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import { FetchModeEnum } from '@/repositories/bill/enums';

const usePaymentDetails = () => {
    const updatePaymentDetails = usePaymentStore((store) => store.updatePaymentDetails);

    const { vendor } = useVendor();
    const { url, isQSR } = useQlubRouter();

    const callGetPaymentDetails = () => {
        const diningSessionPayload = getDiningSession(url);

        BillAPIManager.getInstance()
            .getDetails(
                {
                    id: getSession(),
                    diningSessionID: diningSessionPayload?.id || '0',
                    cc: url.cc,
                    restaurantUnique: url.slug,
                    tableID: url.id,
                    f1: url.f1,
                    f2: url.f2,
                    hash: url.hash,
                    forceFresh: false,
                    jwt: diningSessionPayload?.jwt || undefined,
                    fetchMode: url.fetchMode as FetchModeEnum,
                    payUrl: url.qPayUrl,
                },
                {
                    cc: url.cc,
                    vendor,
                    qsr: isQSR && url.qsr !== QSRRouterModeEnum.Mixed,
                },
            )
            .then((res) => {
                updatePaymentDetails(res);
            })
            .catch((err) => {
                console.error('error(payment-details-api): ', err);
            });
    };

    return callGetPaymentDetails;
};

export default usePaymentDetails;
