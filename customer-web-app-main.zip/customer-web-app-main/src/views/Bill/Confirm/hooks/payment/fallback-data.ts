import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { CampaignDiscountTypeEnum, IPaymentStatusRes } from '@/repositories/bill/types';
import { useMemo } from 'react';
import { BillStatusEnum, RecordStatusEnum } from '@/repositories/bill/enums';

const usePaymentFallbackData = () => {
    const { query, url } = useQlubRouter();

    const fallbackData: IPaymentStatusRes = useMemo(() => {
        return {
            amount: query.amount,
            currency: query.currencySymbol || '',
            bill: {
                currency: query.currencySymbol || '',
                orderID: '',
                remainingAmount: query.amount || '',
                status: BillStatusEnum.UNPAID,
                tableID: url.id,
                tableName: '',
                totalAmount: query.amount || '',
            },
            campaign: {
                appliedVouchers: [
                    {
                        discountType: CampaignDiscountTypeEnum.NONE,
                        amount: '',
                        code: '',
                        partyID: '',
                        redeemed: false,
                    },
                ],
            },
            record: {
                id: '',
                createdAt: 0,
                updatedAt: 0,
                accepted: false,
                billAmount: query.amount || '',
                customerCommission: '0.00',
                gatewayVendor: query.method || '',
                reference: '',
                status: RecordStatusEnum.pending,
                tipAmount: '',
                total: '',
                knetMetaData: {
                    knet_payment_id: '',
                    knet_transaction_id: '',
                    knet_result: '',
                },
                transactionDateTime: '',
            },
            verified: false,
        };
    }, [query, url]);

    return { fallbackData };
};

export default usePaymentFallbackData;
