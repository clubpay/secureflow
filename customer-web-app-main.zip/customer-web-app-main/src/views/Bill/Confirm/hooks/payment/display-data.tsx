import usePaymentStore, { DetailedPaymentStatus } from '@/store/payment';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import Format from '@qlub-dev/qlub-kit/dist/components/Format';
import { getCurrencyPrecision } from '@clubpay/customer-common-module/src/utility/k_currency';
import { kDecodeString } from '@clubpay/customer-common-module/src/utility/k_string';
import useTranslations from '../other/translations';
import { ITranslation } from '../../types';

interface IDisplayData extends ITranslation {
    displayStatus?: string;
    tableName?: string;
    showYouPaid?: boolean;
    amountComponent?: JSX.Element;
    hint?: any;
    currencySymbol?: string;
}

const usePaymentDisplayData = () => {
    const translations = useTranslations();
    const paymentStatusData = usePaymentStore((state) => state.statusData);
    const { query, lang } = useQlubRouter();
    const detailedPaymentStatus = usePaymentStore((state) => state.detailedPaymentStatus);
    const { vendor, currencyFormat } = useVendor();
    const getVendorInstruction = () => getLocaleText(vendor?.config?.vendorInstruction || '', lang, '');

    const tableName = kDecodeString(query.tableName || '');
    const currencySymbol = paymentStatusData?.currency.toUpperCase() || vendor?.country?.currencySymbol;

    const defaultData = {
        hint: getVendorInstruction(),
        currencySymbol,
        tableName,
        showYouPaid: false,
        amountComponent: (
            <Format
                bold
                value={paymentStatusData?.record?.total}
                currencyFormat={{
                    ...currencyFormat,
                    cs: currencySymbol || currencyFormat.cs,
                    currencyPrecision: getCurrencyPrecision(currencySymbol),
                }}
            />
        ),
    };

    const conditionalCardData = {
        fullyPaid: {
            displayStatus: 'success',
            partialPayment: false,
            showYouPaid: true,
            ...translations.fullyPaid,
        },
        partiallyPaid: {
            displayStatus: 'partial',
            partialPayment: true,
            showYouPaid: true,
            showLeftToPay: true,
            ...translations.partiallyPaid,
        },
        unpaid: {
            displayStatus: 'error',
            partialPayment: false,
            ...translations.unpaid(paymentStatusData?.bill?.totalAmount ?? query.amount),
        },
        done: {
            displayStatus: 'success',
            partialPayment: false,
            hint: '',
            ...translations.done,
        },
        pending: {
            displayStatus: 'pending',
            partialPayment: false,
            paymentDescText: '',
            ...translations.pending,
        },
    };

    const getPaymentStatusSpecificData = (): IDisplayData => {
        if (paymentStatusData === undefined || paymentStatusData?.hasLoyaltyFullPayment) return {};

        if (detailedPaymentStatus === DetailedPaymentStatus.UNSET) {
            return conditionalCardData[paymentStatusData.bill.status];
        }

        return conditionalCardData[detailedPaymentStatus];
    };

    return { ...defaultData, ...getPaymentStatusSpecificData() };
};

export default usePaymentDisplayData;
