import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { pendingPaths, pendingEnabledPGs } from '@/views/Bill/Confirm/constants';
import { PGNameEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';

const useIsPGPending = () => {
    const { query, pathname } = useQlubRouter();

    const isPendingUrl = pendingPaths.indexOf(pathname) > -1;
    const newVendorGateway = query.method?.toLowerCase() as PGNameEnum;

    const isPGPending = pendingEnabledPGs.includes(newVendorGateway) && isPendingUrl;

    return isPGPending;
};

export default useIsPGPending;
