import { useRef } from 'react';
import { editSessionApiCall, trimPathnameForEmbed } from '@/services/utils/k_qsr';
import { ISessionEditPayload } from '@/repositories/menu/types';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';

const useNavigateToQSRPreparationPage = () => {
    const { query, url, routerPush, pathname } = useQlubRouter();

    const hasNavigatedRef = useRef(false);

    const navigateToQSRPreparationPage = () => {
        if (hasNavigatedRef.current) return;
        hasNavigatedRef.current = true;

        const payload: ISessionEditPayload = {
            orderId: query.qOrderId,
            reference: query.ref,
            dsi: query.dsi,
        };

        if (query?.qOrderId && query?.ref && query?.dsi) {
            editSessionApiCall(url, payload);
        }

        const navigate = () => {
            routerPush(trimPathnameForEmbed('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr/preparation', pathname), {
                dsi: query.dsi,
                ref: query.ref,
                sid: query.sid,
                method: query.method,
                qOrderId: query.qOrderId,
                paymentElement: query.paymentElement,
            });
        };

        navigate();
    };

    return navigateToQSRPreparationPage;
};

export default useNavigateToQSRPreparationPage;
