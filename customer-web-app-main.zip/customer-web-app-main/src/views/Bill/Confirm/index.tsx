import React, { useEffect, useMemo, useRef } from 'react';
import { NextPageWithLayout } from '@/layout/types';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getDiningSession, setDiningSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import useSentryTrace from '@clubpay/customer-common-module/src/hook/sentry/useSentryTrace';
import { IStartSpanResponse, ITransactionObject } from '@clubpay/customer-common-module/src/hook/sentry/types';
import SplashScreen from '@/views/Bill/Confirm/components/other/splash-screen';
import useVerifySpecificPG from '@/views/Bill/Confirm/hooks/payment/verify-specific-pg';
import { ConfirmationPageBrandingLayoutEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import classNames from 'classnames';
import { useGetQlubBrandingMode } from '@/views/Bill/Confirm/hooks/other/qlub-branding-mode';
import useLoyaltyEvents from '@clubpay/loyalty/dist/hooks/analytics';
import { moveToPreparationCondition } from '@/services/utils/k_qsr';
import usePaymentStore, { DetailedPaymentStatus, PaymentStatus } from '@/store/payment';
import dynamic from 'next/dynamic';
import useEventsCenter from '@/hooks/eventsCenter';
import { setPaymentProfile } from '@clubpay/payment-kit';
import { RecordStatusEnum } from '@/repositories/bill/enums';
import { isEmpty } from 'lodash';
import usePaymentStatus from './hooks/payment/payment-status-api';
import useIsPGPending from './hooks/payment/pending-pg-check';
import useNavigateToQSRPreparationPage from './hooks/qsr/qsr-preparation-navigation';
import { PathnameType } from './enums';
import usePaymentDisplayData from './hooks/payment/display-data';
import useGetCurrentPathnameType from './hooks/other/current-pathname-type';
import styles from './index.module.scss';

const Success = dynamic(() => import('./sub-views/success'), { ssr: false });
const Failure = dynamic(() => import('./sub-views/failure'), { ssr: false });
const Pending = dynamic(() => import('./sub-views/pending'), { ssr: false });

const Confirm: NextPageWithLayout = () => {
    const traceRef = useRef<ITransactionObject>({} as ITransactionObject);
    const spanRef = useRef<IStartSpanResponse>({} as IStartSpanResponse);

    const { url, query, urlStr, getRedirectUri } = useQlubRouter();
    const { vendor } = useVendor();

    const events = useEventsCenter();
    const loyaltyEvents = useLoyaltyEvents();

    const currentPathnameType = useGetCurrentPathnameType();
    const qlubBrandingMode = useGetQlubBrandingMode();
    const isPendingPG = useIsPGPending();
    const { verify } = useVerifySpecificPG();
    const { fetchTrace } = useSentryTrace();
    const navigateToQSRPreparationPage = useNavigateToQSRPreparationPage();
    const paymentDisplayData = usePaymentDisplayData();

    const callGetPaymentStatus = usePaymentStatus({
        spanRef,
        traceRef,
    });

    const redirect = useMemo(() => {
        return getRedirectUri();
    }, []);

    const updatePaymentStatus = usePaymentStore((state) => state.updatePaymentStatus);
    const updateDetailedPaymentStatus = usePaymentStore((state) => state.updateDetailedPaymentStatus);

    const paymentStatusData = usePaymentStore((state) => state.statusData);
    const paymentStatus = usePaymentStore((state) => state.status);
    const hasMaxTryCountBeenReached = usePaymentStore((state) => state.hasMaxTryCountBeenReached);
    const isLoading = usePaymentStore((state) => state.isLoading);

    useEffect(() => {
        traceRef.current = fetchTrace({
            gatewayId: query.gatewayId,
            name: 'confirm',
            traceId: query.sentryTraceId,
            amount: Number(query.amount),
            tip: Number(query.tip),
            countryCode: url.cc,
            restaurantUniqueID: url.slug,
            paymentGateway: query.method || '',
            diningSessionID: query.dsi,
            participantID: query.sid || '',
        });

        spanRef.current = traceRef.current.startSpan({
            dataName: 'confirm',
            span: {
                element: query.paymentElement as PaymentElementEnum,
                refId: query.ref,
            },
        });
    }, [query, url]);

    useEffect(() => {
        if (query.jwt && url.slug && url.id) {
            setDiningSession(url, { id: query.dsi, jwt: query.jwt });
            getDiningSession(url);
        }

        verify().finally(() => {
            callGetPaymentStatus();
        });
    }, [urlStr, query.jwt, query.sid]);

    useEffect(() => {
        if (currentPathnameType === PathnameType.PENDING) {
            if (isPendingPG) {
                if (!paymentStatusData?.verified) {
                    updateDetailedPaymentStatus(
                        hasMaxTryCountBeenReached ? DetailedPaymentStatus.UNPAID : DetailedPaymentStatus.PENDING,
                    );
                } else {
                    updateDetailedPaymentStatus(DetailedPaymentStatus.UNSET);
                }
            } else {
                updateDetailedPaymentStatus(
                    paymentStatusData?.verified ? DetailedPaymentStatus.UNSET : DetailedPaymentStatus.UNPAID,
                );
            }
        } else if (currentPathnameType === PathnameType.SUCCESS) {
            updateDetailedPaymentStatus(
                paymentStatusData?.verified ? DetailedPaymentStatus.UNSET : DetailedPaymentStatus.DONE,
            );
        } else {
            updateDetailedPaymentStatus(DetailedPaymentStatus.UNPAID);
        }
    }, [paymentStatusData, hasMaxTryCountBeenReached, currentPathnameType, isPendingPG]);

    useEffect(() => {
        const isPaymentSuccessful = paymentStatusData?.verified || currentPathnameType === PathnameType.SUCCESS;
        if (isPaymentSuccessful) {
            updatePaymentStatus(PaymentStatus.SUCCESS);
            return;
        }

        const isPaymentPending = isPendingPG && !paymentStatusData?.verified && !hasMaxTryCountBeenReached;
        if (isPaymentPending) {
            updatePaymentStatus(PaymentStatus.PENDING);
            return;
        }

        const hasPaymentFailed =
            paymentDisplayData?.displayStatus === 'error' ||
            paymentStatusData?.record?.status === RecordStatusEnum.failed ||
            currentPathnameType === PathnameType.FAILED ||
            (isPendingPG && !paymentStatusData?.verified && hasMaxTryCountBeenReached);
        if (hasPaymentFailed) {
            updatePaymentStatus(PaymentStatus.FAILED);
        }
    }, [hasMaxTryCountBeenReached, paymentStatusData, hasMaxTryCountBeenReached, isPendingPG]);

    useEffect(() => {
        if (paymentStatus === PaymentStatus.SUCCESS) {
            loyaltyEvents.general.checkAndFireServiceEnabled();
        }
    }, [vendor?.config, paymentStatus]);

    useEffect(() => {
        if (!paymentStatusData) {
            return;
        }

        if (moveToPreparationCondition(url, paymentStatus === PaymentStatus.SUCCESS)) {
            navigateToQSRPreparationPage();
        } else if (paymentStatus === PaymentStatus.SUCCESS && redirect?.success) {
            window.location.href = redirect.success;
        } else if (paymentStatus === PaymentStatus.FAILED && redirect?.failure) {
            window.location.href = redirect.failure;
        }
    }, [url, paymentStatus, paymentStatusData]);

    useEffect(() => {
        if (vendor && (paymentStatusData || query)) {
            const pgName = `${
                paymentStatusData?.record?.gatewayVendor || paymentStatusData?.gatewayVendor || query?.method
            }_${paymentStatusData?.record?.gatewayPaymentMethod || query?.paymentElement}${
                query.saved && !query?.paymentElement?.includes('saved') ? '_saved' : ''
            }`.toLowerCase();

            const amount = Number(paymentStatusData?.record?.total ?? query?.amount ?? 0);
            const tip = Number(paymentStatusData?.record?.tipAmount || 0);

            if (amount === 0) return;

            if (paymentStatus === PaymentStatus.SUCCESS) {
                events.payment.success(pgName, amount, tip, paymentStatusData?.loyalty?.discounts);
                events.voucherCampaign.paymentSuccessfulWithPromoCodeEvent(
                    !!paymentStatusData?.activeCampaign?.redeemed,
                    pgName,
                );
            }

            if (paymentStatus === PaymentStatus.FAILED) {
                events.payment.failure(pgName, amount);
                events.voucherCampaign.paymentFailedWithPromoCodeEvent(
                    !!paymentStatusData?.activeCampaign?.redeemed,
                    pgName,
                );
            }
        }
    }, [paymentStatus, paymentStatusData, query]);

    const content = useMemo(() => {
        if (isLoading) {
            return <SplashScreen />;
        }

        switch (paymentStatus) {
            case PaymentStatus.SUCCESS:
                return <Success callGetPaymentStatus={callGetPaymentStatus} />;
            case PaymentStatus.PENDING:
                return <Pending callGetPaymentStatus={callGetPaymentStatus} />;
            case PaymentStatus.FAILED:
                return <Failure />;
            default:
                return <SplashScreen />;
        }
    }, [paymentStatus, isLoading]);

    useEffect(() => {
        const restaurantCountry = vendor?.country?.code;
        const cardIssuerCountry = paymentStatusData?.record?.issuerCountry;
        const was3dsUsed = paymentStatusData?.record?.threeDS;
        const cardBrand = paymentStatusData?.record?.cardBrand;

        const profileData: Record<string, any> = {};
        if (restaurantCountry && cardIssuerCountry) {
            setPaymentProfile({
                lastPayment: {
                    cardIssuerCountry,
                    isInternationalCard: restaurantCountry !== cardIssuerCountry?.toLowerCase(),
                },
            });
        }

        if (typeof was3dsUsed !== 'undefined') profileData.used3ds = was3dsUsed;

        if (typeof cardBrand !== 'undefined') profileData.cardBrand = cardBrand;

        if (!isEmpty(profileData)) {
            setPaymentProfile({
                lastPayment: profileData,
                previousUsedCardBrands: cardBrand ? [cardBrand] : [],
            });
        }
    }, [paymentStatusData?.record, vendor?.country]);

    return (
        <div
            className={classNames(styles.mainContainerPadding, {
                [styles.placeHolder]: qlubBrandingMode === ConfirmationPageBrandingLayoutEnum.Header,
            })}
        >
            <div className={styles.confirmContainer}>{content}</div>
        </div>
    );
};

export default Confirm;
