import { PGNameEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';

export const successPaths = ['/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice/success'];
export const pendingPaths = ['/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice/pending'];
export const failurePaths = ['/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice/fail'];

export const pendingEnabledPGs = [
    PGNameEnum.Maf,
    PGNameEnum.Checkout,
    PGNameEnum.CheckoutPlatform,
    PGNameEnum.Stripe,
    PGNameEnum.StripeConnect,
    PGNameEnum.Tuna,
    PGNameEnum.MafV2,
    PGNameEnum.Adyen,
    PGNameEnum.NGenius,
    PGNameEnum.Divit,
];
