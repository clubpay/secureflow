import { ReactNode } from 'react';

export interface IKnetInfo {
    paymentId?: string;
    transactionId?: string;
}

export interface IPaymentInfoDisplay {
    badgeText: string;
    paymentMessage: string;
    partialPayment: boolean;
    tableName: string;
    hint: string;
    paymentDescText: string;
    className: 'partial' | 'success' | 'error' | 'pending';
    amountComponent?: string | ReactNode;
    showLeftToPay?: boolean;
    showYouPaid?: boolean;
    knetInfo?: IKnetInfo;
}

export interface ITranslation {
    badgeText?: string;
    paymentMessage?: string;
    paymentDescText?: string;
    hint?: any;
}
