import { FC } from 'react';
import SocialMedia from '@/components/Bill/SocialMedia';
import QlubBranding from '../../components/other/qlub-branding';
import ConditionalCardWrapper from '../../components/payment/conditional-card-wrapper';
import ButtonsContainer from '../../components/other/btn-container';
import ResponseBoxWrapper from '../../components/payment/response-box-wrapper';

const Failure: FC = () => {
    return (
        <>
            <ResponseBoxWrapper />
            <QlubBranding />
            <ConditionalCardWrapper />
            <SocialMedia />
            <ButtonsContainer />
        </>
    );
};

export default Failure;
