import { FC } from 'react';
import { SliderPositionEnum } from '@clubpay/customer-common-module/src/component/KSlider/enums';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import LoyaltyEarn from '@clubpay/loyalty/dist/drivers/customer/Earn';
import LoyaltyEarnConfirmation from '@clubpay/loyalty/dist/drivers/customer/Confirmation';
import SubscriptionSavings from '@clubpay/loyalty/dist/drivers/customer/Subscription/Savings';
import WalletPartnersButton from '@clubpay/loyalty/dist/drivers/customer/WalletPartners';
import EarnedPoints from '@clubpay/loyalty/dist/drivers/customer/EarnedPoints';
import OrderSummary from '@/views/Bill/Confirm/components/payment/order-summary';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import BillAPIManager from '@/repositories/bill';
import ConditionalVentureBanner from '@/components/Bill/VentureBanner';
import Divider from '@qlub-dev/qlub-kit/dist/components/Divider';
import Review from '@/components/Review';
import { PGNameEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import SocialMedia from '@/components/Bill/SocialMedia';
import usePaymentStore from '@/store/payment';
import PaymentReceipt from '@/components/Common/PaymentReceipt';
import ConditionalCardWrapper from '../../components/payment/conditional-card-wrapper';
import QlubBranding from '../../components/other/qlub-branding';
import useFooterBannerConfigs from '../../hooks/other/footer-banner-configs';
import LoginButtons from '../../components/other/login-btns';
import FooterBanner from '../../components/other/footer-banner';
import Banner from '../../components/other/banner';
import ResponseBoxWrapper from '../../components/payment/response-box-wrapper';
import BackBtns from '../../components/other/back-btns';

import styles from './index.module.scss';

interface IProps {
    callGetPaymentStatus: (force: any) => void;
}

const Success: FC<IProps> = ({ callGetPaymentStatus }) => {
    const { query } = useQlubRouter();
    const { t } = useTranslation('common');
    const { shouldShowFooterBanner, footerMessageText, footerMessageLink } = useFooterBannerConfigs();

    const { config: countryConfig } = useConfigContext();
    const { vendor } = useVendor();

    const paymentStatusData = usePaymentStore((state) => state.statusData);

    const shouldRenderOrderSummary = (vendor?.config.orderSummary || countryConfig?.orderSummary) === 'show';
    const newVendorGateway = query.method?.toLowerCase() as PGNameEnum;

    return (
        <>
            <div className={styles.loyaltyEarned}>
                <EarnedPoints
                    earnings={paymentStatusData?.loyalty?.earnings ?? []}
                    earningsRefetchFn={callGetPaymentStatus}
                />
            </div>
            <ResponseBoxWrapper />
            <QlubBranding />
            <Banner position={SliderPositionEnum.Top} />
            <ConditionalCardWrapper />
            <LoyaltyEarnConfirmation
                redemption={paymentStatusData?.loyaltyRedemption as any}
                earnings={paymentStatusData?.loyalty?.earnings}
                earningsRefetchFn={callGetPaymentStatus}
            />
            {shouldRenderOrderSummary && <OrderSummary />}
            <Banner position={SliderPositionEnum.Middle} />
            <SubscriptionSavings
                appliedDiscounts={paymentStatusData?.loyalty?.discounts ?? []}
                className={styles.loyaltySubscriptionSavings}
            />
            <WalletPartnersButton />
            <LoyaltyEarn
                gatewayPaymentMethod={paymentStatusData?.record?.gatewayPaymentMethod}
                gatewayVendor={paymentStatusData?.record?.gatewayVendor}
                earnings={paymentStatusData?.loyalty?.earnings}
                redemptions={paymentStatusData?.loyalty?.redemptions}
                api={{
                    bill: BillAPIManager.getInstance() as any,
                }}
            />
            <ConditionalVentureBanner />
            {paymentStatusData?.loyaltyRedemption?.status !== 'ok' && <Divider />}
            {/** TODO: Condition check for review is a hotfix. Remove it later */}
            {paymentStatusData?.bill?.status !== 'unpaid' && (
                <>
                    <Review paymentGateway={newVendorGateway} show />
                    <Divider />
                </>
            )}
            <SocialMedia />
            <Divider />
            {/** TODO: Condition check for email receipt is a hotfix. Remove it later */}
            {paymentStatusData?.bill?.status !== 'unpaid' && <PaymentReceipt />}
            <BackBtns className={styles.backBtns} />
            <Banner position={SliderPositionEnum.Bottom} />
            {shouldShowFooterBanner ? (
                <FooterBanner
                    message={footerMessageText}
                    actionButtonText={t('Contact us')}
                    actionButtonLink={footerMessageLink}
                />
            ) : (
                <LoginButtons />
            )}
        </>
    );
};

export default Success;
