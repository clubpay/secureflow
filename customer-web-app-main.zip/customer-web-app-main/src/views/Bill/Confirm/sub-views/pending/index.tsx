import { FC } from 'react';
import PendingProgress from '../../components/payment/pending-progress';
import QlubBranding from '../../components/other/qlub-branding';
import ConditionalCardWrapper from '../../components/payment/conditional-card-wrapper';
import ResponseBoxWrapper from '../../components/payment/response-box-wrapper';

interface IProps {
    callGetPaymentStatus: (force: any) => void;
}

const Pending: FC<IProps> = ({ callGetPaymentStatus }) => {
    return (
        <>
            <ResponseBoxWrapper />
            <QlubBranding />
            <ConditionalCardWrapper />
            <PendingProgress getPaymentStatus={callGetPaymentStatus} />
        </>
    );
};

export default Pending;
