export enum PathnameType {
    SUCCESS = 'success',
    PENDING = 'pending',
    FAILED = 'failed',
}
