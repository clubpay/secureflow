import { InvoiceBill, InvoiceOrder } from '@/components/Bill/InvoiceItem';
import usePaymentStore from '@/store/payment';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import Divider from '@qlub-dev/qlub-kit/dist/components/Divider';
import { FC } from 'react';

const GeneralInvoice: FC = () => {
    const details = usePaymentStore((state) => state.details);
    const { lang } = useQlubRouter();

    if (!details) {
        return <></>;
    }

    return (
        <>
            <InvoiceOrder orderItems={details._orderItems} lang={lang} newOrderIds={[]} />
            <Divider type="fullWidth" />
            <InvoiceBill lang={lang} billItems={details?._billItems} qlubDiscount={details?.billNumber?.qlubDiscount} />
        </>
    );
};

export default GeneralInvoice;
