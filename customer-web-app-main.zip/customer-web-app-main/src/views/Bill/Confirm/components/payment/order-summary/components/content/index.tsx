import usePaymentStore from '@/store/payment';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { FC, useEffect } from 'react';
import usePaymentDetails from '@/views/Bill/Confirm/hooks/payment/payment-details-api';
import { SplitModeTypeEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import CircularProgress from '@mui/material/CircularProgress';
import PayByItemInvoice from './invoices/split-by-item';
import GeneralInvoice from './invoices/general';
import PayByShareInvoice from './invoices/split-by-share';

import styles from './index.module.scss';

const Content: FC = () => {
    const details = usePaymentStore((state) => state.details);

    const { urlStr } = useQlubRouter();
    const callGetPaymentDetails = usePaymentDetails();

    useEffect(() => {
        if (urlStr) {
            callGetPaymentDetails();
        }
    }, [urlStr]);

    if (!details) {
        return (
            <div className={styles.loadingContainer}>
                <CircularProgress size={24} />;
            </div>
        );
    }

    if (details?.yourSplitSettings?.billSplit?.splitMode === SplitModeTypeEnum.byShare) {
        return <PayByShareInvoice />;
    }

    if (details?.yourSplitSettings?.billSplit?.splitMode === SplitModeTypeEnum.byItem) {
        return <PayByItemInvoice />;
    }

    return <GeneralInvoice />;
};

export default Content;
