import { FC, useEffect, useMemo, useRef, useState } from 'react';
import { RefreshRounded } from '@mui/icons-material';
import Box from '@mui/material/Box';
import { Button, Divider, QSRCircular, Typography } from '@qlub-dev/qlub-kit';
import Link from 'next/link';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import usePaymentStore from '@/store/payment';
import { PGNameEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';

import styles from './index.module.scss';

interface IProps {
    getPaymentStatus: (force?: boolean) => void;
}

const PendingProgress: FC<IProps> = ({ getPaymentStatus }) => {
    const { vendor } = useVendor();
    const { getRouterParam, query } = useQlubRouter();
    const newVendorGateway = query.method?.toLowerCase() as PGNameEnum;
    const pgConfig = useMemo(
        () => vendor?.paymentGateways?.find((pg) => pg.name === newVendorGateway)?.config,
        [vendor],
    );
    const { t } = useTranslation('common');
    const [timerValue, setTimerValue] = useState(0);
    const initialSecond = useRef<number>(pgConfig?.statusCheckDelay || 15);
    const [remainingTimer, setRemainingTimer] = useState(initialSecond.current);
    const [tryCount, setTryCount] = useState(1);
    const maxTryCount = pgConfig?.statusCheckMaxTryCount || 5;
    const tick: { current: NodeJS.Timeout | null } = useRef(null);

    const paymentStatusData = usePaymentStore((state) => state.statusData);
    const updateHasMaxTryCountBeenReached = usePaymentStore((state) => state.updateHasMaxTryCountBeenReached);

    const resetTimer = () => {
        clearInterval(tick.current as NodeJS.Timeout);
        setRemainingTimer(initialSecond.current);
    };

    useEffect(() => {
        if (initialSecond.current !== 0) {
            setTimerValue(Math.floor((initialSecond.current - remainingTimer) * 100) / initialSecond.current);
        }

        tick.current = setInterval(() => {
            if (remainingTimer === 0) {
                if (tryCount >= maxTryCount) {
                    updateHasMaxTryCountBeenReached(true);
                    clearInterval(tick.current as NodeJS.Timeout);
                } else {
                    setTryCount((prev) => prev + 1);
                    resetTimer();
                    getPaymentStatus(true);
                }
            } else {
                setRemainingTimer((prev) => prev - 1);
            }
        }, 1000);

        return () => clearInterval(tick.current as NodeJS.Timeout);
    }, [remainingTimer]);

    const handleCheckStatus = () => {
        if (!paymentStatusData?.verified) {
            getPaymentStatus(true);
            resetTimer();
        }
    };

    return (
        <>
            <Divider sx={{ margin: '16px 0' }} />
            <Box className={styles.pendingCircularWrapper}>
                <Box className={styles.pendingCircularTop}>
                    <Typography>{t('Auto-refresh in:')}</Typography>
                    <Typography>{remainingTimer}</Typography>
                    <QSRCircular value={timerValue} size={180} thickness={3} />
                </Box>
                <Box className={styles.pendingCircularBottom}>
                    <Button
                        icon="left"
                        color="primary"
                        variant="contained"
                        fullWidth
                        startIcon={<RefreshRounded />}
                        onClick={handleCheckStatus}
                    >
                        {t('Check the status')}
                    </Button>
                    <Link
                        href={getRouterParam('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]', { source: 'confirmationPage' })}
                        passHref
                    >
                        <Button variant="containedLight" fullWidth>
                            {t('Back to home')}
                        </Button>
                    </Link>
                </Box>
            </Box>
        </>
    );
};

export default PendingProgress;
