import React, { useMemo } from 'react';
import { ConditionalCard, Price } from '@qlub-dev/qlub-kit';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { getCurrencyPrecision } from '@clubpay/customer-common-module/src/utility/k_currency';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { Locales } from '@clubpay/loyalty/dist/types';
import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { getZonedTime } from '@clubpay/customer-common-module/src/utility/k_time';
import usePaymentStore, { PaymentStatus } from '@/store/payment';
import { Format } from '@qlub-dev/qlub-kit/dist/components/Format';
import { CampaignDiscountTypeEnum } from '@/repositories/bill';
import usePaymentDisplayData from '../../../hooks/payment/display-data';

const ConditionalCardWrapper = () => {
    const { config: countryConfig } = useConfigContext();
    const { vendor, currencyFormat } = useVendor();

    const { lang } = useQlubRouter();
    const { t } = useTranslation('common');
    const paymentDisplayData = usePaymentDisplayData();

    const paymentStatusData = usePaymentStore((state) => state.statusData);
    const paymentStatus = usePaymentStore((state) => state.status);

    const {
        showQueueNumber,
        queueNumberDigit = 4,
        prependQueueNo = '',
        queueNumberDisplayGroup,
    } = vendor?.config || {};

    const { group } = vendor?.metaObject || {};

    const showTransactionTime =
        (paymentStatusData?.record?.knetMetaData?.knet_transaction_id &&
            paymentStatusData?.record?.knetMetaData?.knet_payment_id) ||
        countryConfig?.showTransactionTime;

    const renderQueueNumber = useMemo(() => {
        const handleQueueText = (orderID: string) => {
            const digitToSlice = orderID.length > queueNumberDigit ? queueNumberDigit : orderID.length;

            return prependQueueNo + orderID.slice(-digitToSlice);
        };

        switch (paymentStatusData?.bill.status) {
            case 'fullyPaid':
            case 'partiallyPaid':
                if (showQueueNumber && paymentStatusData?.bill.orderID) {
                    if (!queueNumberDisplayGroup || queueNumberDisplayGroup?.length === 0) {
                        return handleQueueText(paymentStatusData?.bill.orderID);
                    }

                    if (group === '' || group === undefined) {
                        return null;
                    }

                    if (queueNumberDisplayGroup && queueNumberDisplayGroup.toString().indexOf(group) > -1) {
                        return handleQueueText(paymentStatusData?.bill.orderID);
                    }
                }

                return null;
            default:
                return null;
        }
    }, [paymentStatusData?.bill.status, showQueueNumber, queueNumberDigit, prependQueueNo]);

    const currencyPrecision = useMemo(
        () => getCurrencyPrecision(paymentStatusData?.bill?.currency || vendor?.country?.currencySymbol),
        [paymentStatusData, vendor],
    );

    const loyalty = useMemo(() => {
        if (paymentStatus !== PaymentStatus.SUCCESS || !paymentStatusData?.loyaltyRedemption) {
            return;
        }

        const data = {
            title: t('Redeemed'),
            unit: getLocaleText(
                paymentStatusData?.loyaltyRedemption.pointName || vendor?.config?.loyaltyPointIdentifier || '',
                vendor?.config?.defaultLang ?? '',
                Locales.English,
            ),
            points: paymentStatusData?.loyaltyRedemption.points || 0,
            amount: paymentStatusData?.loyaltyRedemption.amount,
        };

        return {
            data,
            hidePaidAmount: paymentStatusData?.hasLoyaltyFullPayment,
        };
    }, [paymentStatusData?.bill.status, paymentStatus, paymentStatusData?.loyaltyRedemption, lang]);

    const transactionTime = useMemo(() => {
        if (!paymentStatusData?.record?.transactionDateTime || !vendor?.timezone?.timezone) {
            return;
        }

        const time = getZonedTime(paymentStatusData?.record?.transactionDateTime, vendor?.timezone?.timezone);

        const timeDisplay = <span dir="ltr">{time}</span>;

        return showTransactionTime
            ? {
                  instruction: '',
                  dateTimeMessage: time
                      ? paymentDisplayData?.displayStatus === 'error'
                          ? timeDisplay
                          : interpolateT(t('Paid on <date_time>'), {
                                date_time: timeDisplay,
                            })
                      : '',
              }
            : undefined;
    }, [
        paymentDisplayData?.displayStatus,
        paymentStatusData?.record?.transactionDateTime,
        vendor?.timezone?.timezone,
        lang,
    ]);

    return (
        <ConditionalCard
            queueNumber={renderQueueNumber}
            badgeText={paymentDisplayData?.badgeText}
            cardType={paymentDisplayData?.displayStatus as any}
            footer={paymentDisplayData.hint}
            headerText={paymentDisplayData?.tableName}
            loyalty={
                paymentStatusData?.loyaltyRedemption?.points && loyalty
                    ? {
                          ...loyalty.data,
                          amount: (
                              <Price
                                  value={String(loyalty.data.amount)}
                                  bold
                                  currencyFormat={{
                                      ...currencyFormat,
                                      currencyPrecision: currencyPrecision || currencyFormat?.currencyPrecision,
                                      cs: currencyFormat.cs || paymentStatusData.bill.currency,
                                  }}
                              />
                          ),
                      }
                    : undefined
            }
            leftToPay={
                paymentDisplayData?.displayStatus === 'partial'
                    ? {
                          text: t('Left to pay'),
                          amount: (
                              <Price
                                  value={paymentStatusData?.bill.remainingAmount}
                                  currencyFormat={{
                                      ...currencyFormat,
                                      currencyPrecision: currencyPrecision || currencyFormat?.currencyPrecision,
                                      cs: currencyFormat.cs || paymentStatusData?.bill.currency || '',
                                  }}
                                  bold
                              />
                          ),
                      }
                    : undefined
            }
            youPaid={
                paymentDisplayData?.showYouPaid && !loyalty?.hidePaidAmount
                    ? {
                          text: t('You paid') as string,
                          amount: paymentDisplayData?.amountComponent,
                      }
                    : undefined
            }
            paymentMetadata={{
                knet: {
                    paymentID: {
                        label: t('KNet Payment ID'),
                        value: paymentStatusData?.record?.knetMetaData?.knet_payment_id,
                    },
                    transactionID: {
                        label: t('KNet Transaction ID'),
                        value: paymentStatusData?.record?.knetMetaData?.knet_transaction_id,
                    },
                },
            }}
            transactionDateTime={transactionTime}
            corporateDiscount={
                paymentStatusData?.activeCampaign?.discountType === CampaignDiscountTypeEnum.CORPORATE &&
                paymentStatusData?.billNumber?.voucherAmount &&
                paymentStatusData?.billNumber?.voucherAmount > 0
                    ? {
                          text: t('Corporate discount'),
                          amount: (
                              <Format
                                  currencyFormat={currencyFormat}
                                  leading=" - "
                                  value={paymentStatusData?.activeCampaign?.amount}
                                  sx={{ color: '#22A958 !important', fontSize: '14px !important' }}
                                  typo="tip_multi_line_bottom_line_currency_unit"
                                  bold
                              />
                          ),
                      }
                    : undefined
            }
            sx={{
                '>div:first-of-type': {
                    justifyContent: 'space-between',
                },
            }}
            queueNumberLabel={t('queueNo')}
        />
    );
};

export default ConditionalCardWrapper;
