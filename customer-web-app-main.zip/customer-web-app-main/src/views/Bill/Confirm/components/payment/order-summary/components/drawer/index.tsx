import { SwipeableCustomerDrawer } from '@qlub-dev/qlub-kit/dist/components/Drawer';
import SummarizeOutlinedIcon from '@mui/icons-material/SummarizeOutlined';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { FC, useState } from 'react';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import Typography from '@qlub-dev/qlub-kit/dist/components/Typography';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Button from '@mui/material/Button';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { EnableEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';

import styles from './index.module.scss';

const Drawer: FC = ({ children }) => {
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);

    const { lang, url } = useQlubRouter();
    const { t } = useTranslation('common');
    const { vendor } = useVendor();

    const toggleDrawer = (open: boolean) => (event: React.KeyboardEvent | React.MouseEvent) => {
        if (
            event &&
            event.type === 'keydown' &&
            ((event as React.KeyboardEvent).key === 'Tab' || (event as React.KeyboardEvent).key === 'Shift')
        ) {
            return;
        }
        setIsDrawerOpen(open);
    };

    const showTableNumber = vendor?.config?.hideTableNumInOrderSummary !== EnableEnum.Enable;

    return (
        <>
            <Button
                data-qa-id="confirmation-order-summary"
                sx={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    color: '#1A1C23',
                    border: 'none !important',
                    textTransform: 'capitalize',
                    padding: '0 4px 4px 4px',
                }}
                fullWidth
                variant="text"
                startIcon={
                    <SummarizeOutlinedIcon
                        sx={{
                            "html[dir='rtl'] &": {
                                marginLeft: '8px',
                            },
                        }}
                    />
                }
                endIcon={
                    <ChevronRightIcon
                        sx={{
                            transform: lang === 'ar' ? 'rotate(180deg)' : '',
                        }}
                    />
                }
                onClick={toggleDrawer(true)}
            >
                <Typography
                    style={{ marginRight: lang !== 'ar' ? 'auto' : '', marginLeft: lang === 'ar' ? 'auto' : '' }}
                >
                    {t('Order Summary')}
                </Typography>
            </Button>
            <SwipeableCustomerDrawer
                headerTitle={
                    <div className={styles.headerTitle}>
                        <SummarizeOutlinedIcon />
                        <Typography fontSize="23px">{t('Order Summary')}</Typography>
                    </div>
                }
                hasRadius={false}
                hasOverflow
                anchor="bottom"
                open={isDrawerOpen}
                onClose={toggleDrawer(false)}
                onOpen={toggleDrawer(true)}
                slotProps={{
                    backdrop: {
                        sx: {
                            background: '#00000099',
                        },
                    },
                }}
                PaperProps={{
                    sx: { maxWidth: '552px', margin: '0 auto', background: '#fff', borderRadius: '2rem 2rem 0 0' },
                }}
                contentStyle={{
                    padding: 0,
                    '&>p': {
                        padding: '0 1.5rem',
                        color: 'red',
                    },
                }}
            >
                <div className={styles.content}>
                    <div className={styles.inner}>
                        {showTableNumber && (
                            <Typography typo="title_sm" sx={{ pb: '0.75rem', pt: '0rem' }}>
                                {t('Table {{id}}', { id: url.id })}
                            </Typography>
                        )}
                        {children}
                    </div>
                </div>
            </SwipeableCustomerDrawer>
        </>
    );
};

export default Drawer;
