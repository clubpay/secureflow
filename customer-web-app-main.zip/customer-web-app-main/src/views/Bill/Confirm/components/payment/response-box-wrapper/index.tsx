import ResponseBox from '@qlub-dev/qlub-kit/dist/components/ResponseBox';
import usePaymentDisplayData from '../../../hooks/payment/display-data';

const ResponseBoxWrapper = () => {
    const paymentDisplayData = usePaymentDisplayData();

    return (
        <ResponseBox
            description={paymentDisplayData?.paymentDescText}
            message={paymentDisplayData?.paymentMessage || ''}
            type={paymentDisplayData?.displayStatus as any}
            sx={{
                paddingBottom: 0,
                paddingTop: '8px',
            }}
        />
    );
};

export default ResponseBoxWrapper;
