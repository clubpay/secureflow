import { InvoiceBill, InvoiceOrder } from '@/components/Bill/InvoiceItem';
import usePaymentStore from '@/store/payment';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import Divider from '@qlub-dev/qlub-kit/dist/components/Divider';
import { FC } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Typography from '@qlub-dev/qlub-kit/dist/components/Typography';
import usePaymentDisplayData from '@/views/Bill/Confirm/hooks/payment/display-data';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';

import styles from './index.module.scss';

const PayByShareInvoice: FC = () => {
    const details = usePaymentStore((state) => state.details);
    const paymentDisplayData = usePaymentDisplayData();

    const { lang } = useQlubRouter();
    const { t } = useTranslation('common');

    if (!details) {
        return <></>;
    }

    return (
        <>
            <InvoiceOrder orderItems={details?._orderItems} lang={lang} newOrderIds={[]} />
            <Divider type="fullWidth" />
            <InvoiceBill lang={lang} billItems={details?._billItems} qlubDiscount={details?.billNumber?.qlubDiscount} />
            <Divider type="fullWidth" />
            <div className={styles.splitDetails}>
                <div className={styles.shareCount}>
                    <div className={styles.iconWrapper}>
                        <PersonOutlineOutlinedIcon />
                    </div>
                    <Typography typo="title_sm">
                        {t('Paid {{paidShares}} out of {{totalShares}}', {
                            paidShares: details?.yourSplitSettings?.billSplit?.share,
                            totalShares: details?.yourSplitSettings?.billSplit?.totalShares,
                        })}
                    </Typography>
                </div>
                {paymentDisplayData?.amountComponent}
            </div>
        </>
    );
};

export default PayByShareInvoice;
