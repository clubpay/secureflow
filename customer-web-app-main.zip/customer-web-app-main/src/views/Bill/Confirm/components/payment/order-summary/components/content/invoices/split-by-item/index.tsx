import { useBillItemTranslation, useOrderItemTranslation } from '@/components/Bill/InvoiceItem/hooks/translations_hook';
import usePaymentStore from '@/store/payment';
import usePaymentDisplayData from '@/views/Bill/Confirm/hooks/payment/display-data';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import Typography from '@qlub-dev/qlub-kit/dist/components/Typography';
import Divider from '@qlub-dev/qlub-kit/dist/components/Divider';
import { FC } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import InvoiceItem from '@qlub-dev/qlub-kit/dist/components/InvoiceItem';

import styles from './index.module.scss';

const PayByItemInvoice: FC = () => {
    const details = usePaymentStore((state) => state.details);
    const paymentDisplayData = usePaymentDisplayData();

    const { currencyFormat } = useVendor();
    const { lang } = useQlubRouter();
    const { t } = useTranslation('common');

    return (
        <>
            <div className={styles.items}>
                {details?.itemsSelectedByYou?.map((item, orderIndex) => {
                    if (!item.item) return;

                    return (
                        <InvoiceItem
                            key={orderIndex}
                            val={item.item}
                            lang={lang}
                            type="exploded-receipt-item"
                            useBillItemTranslation={useBillItemTranslation}
                            useOrderItemTranslation={useOrderItemTranslation}
                            currencyFormat={currencyFormat}
                        />
                    );
                })}
            </div>
            <Divider type="fullWidth" />
            <div className={styles.youPaid}>
                <Typography typo="title_md">{t('You paid')}</Typography>
                {paymentDisplayData?.amountComponent}
            </div>
        </>
    );
};

export default PayByItemInvoice;
