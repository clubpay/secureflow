import Drawer from './components/drawer';
import Content from './components/content';

import styles from './index.module.scss';

const OrderSummary = () => {
    return (
        <div className={styles.container}>
            <Drawer>
                <Content />
            </Drawer>
        </div>
    );
};

export default OrderSummary;
