import PaymentIcon from '@/views/Bill/Confirm/components/other/splash-icon';
import React from 'react';

import styles from './index.module.scss';

const SplashScreen = () => {
    return (
        <div className={styles.loadingContainer}>
            <div className={styles.loadingInner}>
                <PaymentIcon />
            </div>
        </div>
    );
};

export default SplashScreen;
