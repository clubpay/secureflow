import QlubLogo from '@/assets/images/icons/qlub-logo';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Typography } from '@qlub-dev/qlub-kit';
import { ConfirmationPageBrandingLayoutEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { FC } from 'react';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useGetQlubBrandingMode } from '../../../hooks/other/qlub-branding-mode';

import styles from './index.module.scss';

const QlubBranding: FC = () => {
    const { t } = useTranslation('common');
    const { lang } = useQlubRouter();
    const qlubBrandingMode = useGetQlubBrandingMode();

    if (qlubBrandingMode === undefined) {
        return null;
    }

    if (qlubBrandingMode === ConfirmationPageBrandingLayoutEnum.Header) {
        return (
            <div className={styles.header}>
                <div>
                    <QlubLogo />
                </div>
            </div>
        );
    }

    return (
        <div className={styles.branding}>
            <div>
                {['zh', 'hk'].includes(lang) ? (
                    <Typography typo="body_sm">
                        {interpolateT(t('by <qlub> Powered'), {
                            qlub: <QlubLogo />,
                        })}
                    </Typography>
                ) : (
                    <>
                        <Typography typo="body_sm">{t('Powered by')}</Typography>
                        <QlubLogo />
                    </>
                )}
            </div>
        </div>
    );
};

export default QlubBranding;
