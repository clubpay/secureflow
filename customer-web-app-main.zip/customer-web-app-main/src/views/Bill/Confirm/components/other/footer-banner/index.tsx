import { FC } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Typography } from '@qlub-dev/qlub-kit';
import { LogoQlub } from '@clubpay/customer-common-module/src/component/SVG';
import AnnounceIcon from '@/assets/images/icons/AnnounceIcon';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import Link from 'next/link';
import classNames from 'classnames';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';

import styles from './index.module.scss';

interface IProps {
    message: string;
    actionButtonText: React.ReactNode;
    actionButtonLink?: string;
}

const FooterBanner: FC<IProps> = ({ message, actionButtonText, actionButtonLink = '' }) => {
    const { t } = useTranslation('common');
    const { lang, theme } = useQlubRouter();

    const isRTL = lang === 'ar';
    const blackTheme = theme === 'black';

    return (
        <div className={styles.outerContainer}>
            <div className={styles.innerContainer}>
                <div className={styles.poweredBy}>
                    <Typography typo="caption_overline">{t('Powered by')}</Typography>
                    <LogoQlub width="38.63" height="38.63" />
                </div>

                <Link
                    href={actionButtonLink}
                    className={classNames(styles.button, {
                        [styles.disabledPointerEvent]: !actionButtonLink,
                    })}
                    passHref
                >
                    <div className={styles.iconAndMessageContainer}>
                        <AnnounceIcon
                            width="32"
                            height="32"
                            className={styles.icon}
                            color={blackTheme ? '#060201' : 'var(--iris)'}
                            backgroundColor={blackTheme ? '#F5F5F5' : 'var(--iris-selected)'}
                        />
                        <Typography
                            typo="tip_multi_line_top_line_percentage"
                            sx={{ textAlign: 'left' }}
                            className={styles.message}
                        >
                            {message}
                        </Typography>
                    </div>

                    <div className={styles.cta}>
                        <Typography
                            className={classNames({
                                [styles.blackThemeColor]: blackTheme,
                                [styles.defaultThemeColor]: !blackTheme,
                            })}
                            typo="caption_overline_medium"
                        >
                            {actionButtonText}
                        </Typography>
                        {isRTL ? (
                            <ArrowBackIosNewIcon
                                sx={{ fontSize: '0.7rem' }}
                                className={classNames({
                                    [styles.blackThemeColor]: blackTheme,
                                    [styles.defaultThemeColor]: !blackTheme,
                                })}
                            />
                        ) : (
                            <ArrowForwardIosIcon
                                sx={{ fontSize: '0.7rem' }}
                                className={classNames(styles.icon, {
                                    [styles.blackThemeColor]: blackTheme,
                                    [styles.defaultThemeColor]: !blackTheme,
                                })}
                            />
                        )}
                    </div>
                </Link>
            </div>
        </div>
    );
};
export default FooterBanner;
