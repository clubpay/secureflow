import { FC } from 'react';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { isUserProfileEnable } from '@clubpay/customer-common-module/src/repository/config';
import { Button, Divider } from '@qlub-dev/qlub-kit';
import Link from 'next/link';
import getMenuLink from '@clubpay/customer-common-module/src/utility/menuLink';
import useEventsCenter from '@/hooks/eventsCenter';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { ConfirmationPageRedirectEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';

import styles from './index.module.scss';

const LoginButtons: FC = () => {
    const { t } = useTranslation('common');
    const { url, lang, getRouterParam } = useQlubRouter();
    const { isAuthorizedUser, login, setDrawerConstants } = useAuth();
    const { vendor } = useVendor();
    const { config: countryConfig } = useConfigContext();
    const hasMenu = vendor?.config?.confirmationPageRedirect === ConfirmationPageRedirectEnum.Menu;

    const {
        userProfile: { tapOnLoginEvent },
    } = useEventsCenter();

    if (
        !(isUserProfileEnable(countryConfig, vendor?.config.enableUserProfile, vendor?.brand.id) && !isAuthorizedUser)
    ) {
        return null;
    }

    const handleLogin = () => {
        tapOnLoginEvent();
        setDrawerConstants({
            text: {
                phone: {
                    title: '',
                    description: '',
                    buttonText: t('Continue'),
                },
                otp: {
                    title: '',
                    description: '',
                    buttonText: t('Continue'),
                },
                done: {
                    title: '',
                    description: '',
                    buttonText: '',
                },
            },
            numInputs: 5,
        });
        login?.({ guest: false, isFullPage: true });
    };

    const href = hasMenu
        ? getMenuLink(url, lang, 'confirmationPage')
        : getRouterParam('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]');

    return (
        <>
            <div className={styles.placeHolder} />
            <div className={styles.stickyBtn}>
                <div className={styles.box}>
                    <Divider type="fullWidth" />
                    <div className={styles.container}>
                        <Link href={href} passHref>
                            <Button data-qa-id="confirmation-view-bill-menu" variant="containedLight" fullWidth>
                                {hasMenu ? t('View menu') : t('View bill')}
                            </Button>
                        </Link>
                        <Button variant="contained" fullWidth onClick={handleLogin}>
                            {t('Login')}
                        </Button>
                    </div>
                </div>
            </div>
        </>
    );
};
export default LoginButtons;
