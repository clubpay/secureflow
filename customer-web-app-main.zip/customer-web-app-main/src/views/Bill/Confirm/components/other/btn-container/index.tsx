import Link from 'next/link';
import { Button } from '@qlub-dev/qlub-kit';
import { RefreshRounded } from '@mui/icons-material';
import React from 'react';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import getMenuLink, { linkHardRefreshHandler } from '@clubpay/customer-common-module/src/utility/menuLink';
import { ConfirmationPageRedirectEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';

import styles from './index.module.scss';

const ButtonsContainer = () => {
    const { url, lang, getRouterParam } = useQlubRouter();
    const { t } = useTranslation('common');
    const { vendor } = useVendor();

    const hasMenu = vendor?.config?.confirmationPageRedirect === ConfirmationPageRedirectEnum.Menu;

    const href = hasMenu
        ? getMenuLink(url, lang, 'confirmationPage')
        : getRouterParam('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]');

    return (
        <div className={styles.buttonContainer}>
            <Link href={getRouterParam('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice')} passHref>
                <Button icon="left" color="primary" variant="contained" fullWidth startIcon={<RefreshRounded />}>
                    {t('Try Again')}
                </Button>
            </Link>
            <Link href={href} onClick={linkHardRefreshHandler(href)} passHref>
                <Button fullWidth variant="containedLight" color="primary" sx={{ marginTop: 0 }}>
                    {hasMenu ? t('Back to menu') : t('Back to home')}
                </Button>
            </Link>
        </div>
    );
};

export default ButtonsContainer;
