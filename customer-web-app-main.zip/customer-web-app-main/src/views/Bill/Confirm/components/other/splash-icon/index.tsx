import React from 'react';
import { CancelRounded, CheckCircleRounded } from '@mui/icons-material';
import usePaymentStore, { PaymentStatus } from '@/store/payment';

import styles from './index.module.scss';

const PaymentIcon = () => {
    const paymentStatus = usePaymentStore((state) => state.status);

    if (paymentStatus === PaymentStatus.SUCCESS) {
        return (
            <>
                <CheckCircleRounded sx={{ fill: '#22A958' }} className={styles.loadingIcon} />
                <div className={styles.checkBackground} />
            </>
        );
    }

    if (paymentStatus === PaymentStatus.FAILED) {
        return (
            <>
                <CancelRounded sx={{ fill: '#DF1D17' }} className={styles.loadingIcon} />
                <div className={styles.cancelBackground} />
            </>
        );
    }

    return null;
};

export default PaymentIcon;
