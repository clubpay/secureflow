import Banners from '@/components/Banner';
import { SliderLocationEnum, SliderPositionEnum } from '@clubpay/customer-common-module/src/component/KSlider/enums';
import React, { FC } from 'react';

import styles from './index.module.scss';

interface IProps {
    position: SliderPositionEnum;
    success?: boolean;
}

const ConfirmationPageBanner: FC<IProps> = ({ position }) => {
    return (
        <Banners
            location={SliderLocationEnum.ConfirmationPage}
            position={position}
            success
            carouselStyleOverrides={{
                commonContainer: styles.commonContainer,
                singleSlide: styles.singleSlide,
                multiSlide: styles.multiSlide,
            }}
        />
    );
};

export default ConfirmationPageBanner;
