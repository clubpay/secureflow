import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { isUserProfileEnable } from '@clubpay/customer-common-module/src/repository/config';
import { ConfirmationPageRedirectEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import getMenuLink, { linkHardRefreshHandler } from '@clubpay/customer-common-module/src/utility/menuLink';
import Button from '@qlub-dev/qlub-kit/dist/components/Button';
import Link from 'next/link';
import { FC, useMemo } from 'react';

interface IProps {
    className?: string;
}

const BackBtns: FC<IProps> = ({ className }) => {
    const { t } = useTranslation('common');
    const { lang, url, getRouterParam } = useQlubRouter();
    const { vendor } = useVendor();
    const { config: countryConfig } = useConfigContext();
    const { isLogin, isAuthorizedUser } = useAuth();

    const menuLink = getMenuLink(url, lang, 'confirmationPage');
    const homePage = getRouterParam('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]');
    const hasMenu = vendor?.config?.confirmationPageRedirect === ConfirmationPageRedirectEnum.Menu;
    const href = hasMenu ? menuLink : homePage;

    const showGuestUI = useMemo(() => {
        if (isUserProfileEnable(countryConfig, vendor?.config.enableUserProfile, vendor?.brand.id)) {
            return isLogin && !isAuthorizedUser;
        }
        return false;
    }, [isLogin, isAuthorizedUser, vendor?.brand.id, vendor?.config.enableUserProfile, countryConfig]);

    if (showGuestUI) {
        return <></>;
    }

    return (
        <div className={className}>
            <Link href={href} onClick={linkHardRefreshHandler(href)} passHref>
                <Button
                    data-qa-id="confirmation-back-to-menu-home"
                    type="button"
                    variant="containedLight"
                    color="primary"
                    fullWidth
                >
                    {hasMenu ? t('Back to menu') : t('Back to home')}
                </Button>
            </Link>
        </div>
    );
};

export default BackBtns;
