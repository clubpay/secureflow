import CarouselBanner from '@/components/Banner/Carousel';
import { SliderLocationEnum, SliderPositionEnum } from '@clubpay/customer-common-module/src/component/KSlider/enums';
import { FC } from 'react';

import styles from './index.module.scss';

const LandingPageBanner: FC = () => {
    return (
        <CarouselBanner
            location={SliderLocationEnum.LandingPage}
            position={SliderPositionEnum.Middle}
            styleOverrides={{
                multiSlide: styles.multiSlide,
                commonContainer: styles.commonContainer,
            }}
        />
    );
};

export default LandingPageBanner;
