import { Skeleton } from '@mui/material';
import { CustomerGrid } from '@qlub-dev/qlub-kit';
import styles from '../index.module.scss';

const SkeletonComponent = () => {
    return (
        <CustomerGrid className={styles.skeletoncontainer}>
            <Skeleton variant="text" width="80%" height={24} />
            {/* <Grid item md={12} xs={12} container justifyContent="space-between">
                <Grid xs={3} md={3} item>
                    <Skeleton variant="text" width="100%" height={30} />
                </Grid>
                <Grid item md={6} xs={6}>
                    <Skeleton variant="text" width="100%" height={30} />
                </Grid>
            </Grid>
            <Skeleton variant="text" width="100%" height={30} /> */}
        </CustomerGrid>
    );
};
export default SkeletonComponent;
