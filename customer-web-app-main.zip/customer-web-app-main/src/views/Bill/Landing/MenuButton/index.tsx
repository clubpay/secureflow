import React, { useCallback } from 'react';
import { Button } from '@qlub-dev/qlub-kit';
import MultiLocale, { validateMultiLocale } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Link from 'next/link';
import { linkHardRefreshHandler } from '@clubpay/customer-common-module/src/utility/menuLink';

interface IProps {
    viewMenuText?: string;
    lang: string;
    isLoyaltyBottomSheet?: {
        status?: boolean;
        action?: () => void;
    };
    menuUrl: any;
    variant?: 'contained' | 'outlined' | 'containedLight' | 'containedDestructive' | 'text' | 'textElevated' | 'grey';
    buttonText?: string;
}

const MenuButton: React.FC<IProps> = ({
    viewMenuText,
    lang,
    isLoyaltyBottomSheet,
    menuUrl,
    variant = 'text',
    buttonText = 'View menu',
}) => {
    const { t } = useTranslation('common');

    const renderContent = useCallback(() => {
        return viewMenuText && lang && validateMultiLocale(viewMenuText) ? (
            <MultiLocale value={viewMenuText} lang={lang} />
        ) : (
            t(buttonText)
        );
    }, [viewMenuText, lang, t, buttonText]);

    if (isLoyaltyBottomSheet?.status && isLoyaltyBottomSheet?.action) {
        return (
            <Button data-qa-id="landing-view-menu" variant={variant} fullWidth onClick={isLoyaltyBottomSheet?.action}>
                {renderContent()}
            </Button>
        );
    }

    return (
        <Button data-qa-id="landing-view-menu" variant={variant} fullWidth>
            <Link href={menuUrl} onClick={linkHardRefreshHandler(menuUrl)} passHref>
                {renderContent()}
            </Link>
        </Button>
    );
};

export default MenuButton;
