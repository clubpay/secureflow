import React, { useEffect, useMemo, useRef, useState } from 'react';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { isNoOrderErr } from '@clubpay/customer-common-module/src/component/InvoiceError';
import {
    DiscountTypeEnum,
    IRestaurant,
    BooleanEnum,
    OrderModeEnum,
    EnableEnum,
} from '@clubpay/customer-common-module/src/repository/vendor/type';
import { Badge, Button, NewLoading, Price, Typography } from '@qlub-dev/qlub-kit';
import { NextPageWithLayout } from '@/layout/types';
import { Grid } from '@mui/material';
import classNames from 'classnames';
import Head from 'next/head';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useLayout } from '@clubpay/customer-common-module/src/context/layout';
import { QSRRouterModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import {
    getDiningSession,
    getSession,
    removeDiningSession,
    setDiningSession,
} from '@clubpay/customer-common-module/src/service/session/dsi';
import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import BillAPIManager, { IPaymentDetails } from '@/repositories/bill';
import getMenuLink from '@clubpay/customer-common-module/src/utility/menuLink';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useSplash } from '@clubpay/customer-common-module/src/context/splash';
import Wallet from '@clubpay/loyalty/dist/drivers/customer/Wallet';
import { useProfile as useLoyaltyProfile } from '@clubpay/loyalty/dist/hooks/api';
import { useGlobalStore } from '@clubpay/loyalty/dist/store/global';
import { getLoyaltyRedirectionArgs } from '@clubpay/loyalty/dist/utils/query';
import { aggregateConfig } from '@/services/utils/config';
import useEventsCenter from '@/hooks/eventsCenter';
import TableName from '@/components/Bill/TableName';
import Banner from '@/views/Bill/Landing/Banner';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import dynamic from 'next/dynamic';
import { FetchModeEnum } from '@/repositories/bill/enums';
import { qlubLocalStorage } from '@clubpay/customer-common-module/src/service/storage/localStorage';
import { parseJSON } from '@clubpay/customer-common-module/src/utility/k_json';
import { ErrorBoundary } from '@sentry/nextjs';

import styles from './index.module.scss';

const ViewMenuBottomSheet = dynamic(() => import('./ViewMenuBottomSheet'));
const MenuButton = dynamic(() => import('@/views/Bill/Landing/MenuButton'));
const Tutorial = dynamic(() => import('@/components/Tutorial'));

const Landing: NextPageWithLayout = () => {
    const { url, lang, routerPush, isQSR } = useQlubRouter();
    const { t } = useTranslation('common');
    const { config } = useConfigContext();
    const { vendor, loading: vendorLoading, qsrLoading, tableInfo, currencyFormat } = useVendor();
    const { loyalty } = useLayout();
    const [loading, setLoading] = useState<boolean>(false);
    const [details, setDetails] = useState<IPaymentDetails | undefined>(undefined);
    const [loyaltyBottomSheetOpen, setLoyaltyBottomSheetOpen] = useState(false);
    const [hasPaidParty, setHasPaidParty] = useState<boolean>(false);
    const { isAuthorizedUser } = useAuth();
    const [isTutorialDrawerOpen, setIsTutorialDrawerOpen] = useState<boolean>(false);
    const isTutorialEnabled =
        vendor?.config?.landingPageTutorial === EnableEnum.Enable &&
        !parseJSON(qlubLocalStorage.get('qlub.payment.customer_payment_profile'))?.lastPayment &&
        !parseJSON(qlubLocalStorage.get('tutorialCompleted'));
    const { show } = useSplash();
    const { landing: GA } = useEventsCenter();

    const customPayNowText = useMemo(
        () => getLocaleText(vendor?.config?.landingPayNowText || '', lang, 'en'),
        [vendor?.config?.landingPayNowText, lang],
    );

    const errorRef = useRef(false);

    const handleTutorialDrawer = (value: boolean) => {
        setIsTutorialDrawerOpen(value);
    };

    const normalizeValue = (val: string | number) => {
        const dec = details ? 10 ** (details.currencyPrecision || 0) : 1;
        return (Math.round((typeof val === 'string' ? parseFloat(val) : val) * dec) / dec).toFixed(
            details?.currencyPrecision || 0,
        );
    };

    useEffect(() => {
        if (isTutorialEnabled) {
            handleTutorialDrawer(true);
        }
    }, [vendor?.config?.landingPageTutorial]);

    const getDetails = (ven: IRestaurant, force?: boolean, inRetry?: boolean) => {
        if (loading || !url.id || url.id === '_' || ven.orderMode === 'qsr' || vendor?.config?.disableFetchingOrder) {
            return;
        }

        setLoading(true);
        const diningSessionPayload = getDiningSession(url);
        BillAPIManager.getInstance()
            .getDetails(
                {
                    id: getSession(),
                    diningSessionID: diningSessionPayload?.id || '0',
                    cc: url.cc,
                    restaurantUnique: url.slug,
                    tableID: url.id,
                    f1: url.f1,
                    f2: url.f2,
                    hash: url.hash,
                    forceFresh: force || false,
                    jwt: diningSessionPayload?.jwt || undefined,
                    fetchMode: url.fetchMode as FetchModeEnum,
                    payUrl: url.qPayUrl,
                },
                {
                    cc: url.cc,
                    vendor,
                    qsr: isQSR && url.qsr !== QSRRouterModeEnum.Mixed,
                },
            )
            .then((res) => {
                setDetails(res);
                useGlobalStore.getState().setPaymentDetails(res as any);
                setDiningSession(url, { id: res.diningSessionID, jwt: res.jwt });
                setHasPaidParty(
                    res.parties?.some((party) => {
                        return party.paymentDone;
                    }) || false,
                );
                GA.billAvailable();
            })
            .catch((err) => {
                const errData = err?.response?.data || {};
                if (isNoOrderErr(errData)) {
                    removeDiningSession(url);
                    if (!inRetry) {
                        getDetails(ven, force, true);
                    }
                }
                if (!errorRef.current) {
                    errorRef.current = true;
                    GA.billUnavailable(errData);
                }
            })
            .finally(() => {
                setLoading(false);
            });
    };

    useEffect(() => {
        if (!vendor || vendorLoading) {
            return;
        }

        if (vendor.config?.previewBill !== false) {
            getDetails(vendor, true);
        } else {
            GA.noBillFetch();
        }
    }, [vendor, vendorLoading]);

    useEffect(() => {
        if (!qsrLoading) {
            return;
        }

        show({ countryConfig: config || undefined, vendor, legacy: true });
    }, [qsrLoading]);

    const payBillHandler = () => {
        GA.tapOnPayBill(customPayNowText ? 'configured' : 'default');

        if (url.id && url.id !== '_') {
            routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice', {
                source: 'landingPage',
                ...getLoyaltyRedirectionArgs(),
            });
        }
    };

    const loyaltyUserProfile = useLoyaltyProfile();

    const discountAmount = useMemo(() => {
        if (!vendor || !vendor.discount) {
            return '';
        }

        if (vendor.discount.type === DiscountTypeEnum.Fixed) {
            return normalizeValue(vendor?.discount?.amount || '0');
        }

        let amount = '';
        const postFix = vendor.discount.type === DiscountTypeEnum.Percentage && !hasPaidParty ? '%' : '';
        if (vendor.discount.type === DiscountTypeEnum.Percentage && details && hasPaidParty) {
            amount = normalizeValue(details.billNumber?.qlubDiscount);
        } else {
            amount = vendor.discount.amount;
        }
        return `${amount}${postFix}`;
    }, [vendor?.discount?.type, details?.billNumber?.qlubDiscount, hasPaidParty]);

    const hasDiscount = useMemo(() => {
        return !!(
            vendor &&
            vendor.discount &&
            vendor.discount.amount &&
            details &&
            parseFloat(String(details.billNumber?.qlubDiscount)) > 0
        );
    }, [vendor?.discount?.amount, details?.billNumber?.qlubDiscount]);

    const manualAmountHandler = () => {
        routerPush(`/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/manual_amount`, {
            qsr: QSRRouterModeEnum.True,
            qsrMA: 'true',
        });
    };

    const orderNowHandler = () => {
        routerPush(`/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr`, {
            qsr: QSRRouterModeEnum.Mixed,
        });
    };

    const menuUrl = getMenuLink(url, lang, 'landingPage');

    const onOpenLoyaltyBottomSheet = () => {
        setLoyaltyBottomSheetOpen(true);
    };
    const onCloseLoyaltyBottomSheet = () => {
        setLoyaltyBottomSheetOpen(false);
    };

    const payButtonContent = () => {
        if (vendor?.config?.disableFetchingOrder) {
            return null;
        }

        const changeButtonText =
            aggregateConfig(vendor?.config, config, 'changePayNowButtonTextForSG')?.changePayNowButtonTextForSG &&
            lang === 'en';

        return (
            <Button
                data-qa-id="landing-pay-now"
                variant="contained"
                fullWidth
                onClick={payBillHandler}
                className={classNames(styles.priceContainer, styles.containedBtn)}
            >
                <span className={loading ? styles.pay : undefined}>
                    {' '}
                    {customPayNowText || (changeButtonText ? t('Pay bill') : t('Pay now'))}
                </span>
                {details && vendor && vendor.config?.previewBill && !hasDiscount ? (
                    <span className={styles.dotContainer}>
                        <span className={styles.dot} />
                        <Price
                            value={String(details?.billNumber.payableAmount)}
                            bold
                            currencyFormat={{
                                ...currencyFormat,
                                currencyPrecision: details.currencyPrecision || currencyFormat?.currencyPrecision,
                            }}
                        />
                    </span>
                ) : (
                    loading && (
                        <span className={styles.buttonLoading}>
                            <NewLoading small />
                        </span>
                    )
                )}
            </Button>
        );
    };

    const orderButtonContent = () => {
        return (
            <>
                {vendor?.orderConfig?.manualAmount && (
                    <Button className={styles.containedBtn} variant="contained" fullWidth onClick={manualAmountHandler}>
                        {t('Enter Manual Amount')}
                    </Button>
                )}
                {vendor?.orderMode === OrderModeEnum.Mixed && (
                    <Button className={styles.containedBtn} variant="contained" fullWidth onClick={orderNowHandler}>
                        {t('Order now')}
                    </Button>
                )}
            </>
        );
    };

    const billButtonContent = () => {
        if (vendor?.config?.landingOrderButtonFirst === BooleanEnum.True) {
            return (
                <>
                    {orderButtonContent()}
                    {payButtonContent()}
                </>
            );
        }

        return (
            <>
                {payButtonContent()}
                {orderButtonContent()}
            </>
        );
    };

    const menuButtonContent = () => {
        if (vendor?.config?.hideViewMenuButton) {
            return null;
        }

        // checks for hard reload if menuUrl.link.refresh is true
        return (
            <MenuButton
                viewMenuText={vendor?.config?.viewMenuText}
                lang={lang}
                isLoyaltyBottomSheet={{
                    status: loyalty?.config?.displayMenuSheet && loyalty?.enabled && !isAuthorizedUser,
                    action: onOpenLoyaltyBottomSheet,
                }}
                menuUrl={menuUrl}
            />
        );
    };

    const buttonsContent = () => {
        if (vendor?.config?.landingMenuButtonFirst === BooleanEnum.True) {
            return (
                <>
                    {menuButtonContent()}
                    {billButtonContent()}
                </>
            );
        }

        return (
            <>
                {billButtonContent()}
                {menuButtonContent()}
            </>
        );
    };

    return (
        <Grid
            container
            className={classNames(styles.mainContainer, {
                [styles.withoutLogo]: !vendor?.logoBigUrl,
            })}
        >
            {vendor?.config?.hideLogo !== true && (
                <Head>
                    <title>Qlub_ | {url.slug}</title>
                </Head>
            )}

            {vendor?.orderMode === OrderModeEnum.Mixed && (
                <Grid item xs={12}>
                    <Typography data-qa-id="landing-rest-name" typo="title_md" className={styles.tableId}>
                        <TableName vendor={vendor} config={config} tableInfo={tableInfo} details={details} />
                    </Typography>
                </Grid>
            )}

            {hasDiscount && (
                <>
                    <Grid item xs={12}>
                        <div className={styles.gap} style={{ height: loyaltyUserProfile ? '0px' : '80px' }} />
                    </Grid>
                    <Grid item xs={12}>
                        <div className={styles.skeletoncontainer}>
                            <Badge
                                label={interpolateT(t(`Enjoy <discountAmount> discount by qlub`), {
                                    discountAmount:
                                        vendor?.discount?.type === DiscountTypeEnum.Fixed ? (
                                            <Price value={discountAmount} currencyFormat={currencyFormat} bold />
                                        ) : (
                                            <span>{discountAmount}</span>
                                        ),
                                })}
                            />
                        </div>
                    </Grid>
                </>
            )}

            <Grid
                item
                xs={12}
                className={classNames(styles.buttons, {
                    [styles.discountStyle]: hasDiscount,
                })}
            >
                <Wallet
                    billAmount={
                        details?.billNumber.payableAmount
                            ? details?.billNumber.payableAmount - details?.billNumber.commission
                            : undefined
                    }
                    loading={loading}
                    isLanding
                />
                {buttonsContent()}
                <Banner />
            </Grid>
            {loyalty?.enabled && loyalty?.config?.displayMenuSheet && !isAuthorizedUser && (
                <ViewMenuBottomSheet
                    visibilityControl={{
                        loyaltyBottomSheetOpen,
                        onCloseLoyaltyBottomSheet,
                        onOpenLoyaltyBottomSheet,
                        isLoyaltyBottomSheet:
                            loyalty?.config?.displayMenuSheet && loyalty?.enabled && !isAuthorizedUser,
                    }}
                    menuUrl={menuUrl}
                    payableAmount={details?.billNumber?.payableAmount}
                    commission={details?.billNumber?.commission}
                    viewMenuText={vendor?.config?.viewMenuText}
                    viewMenuButtonText={t('Continue to view menu')}
                />
            )}
            {isTutorialEnabled && (
                <ErrorBoundary fallback={<></>}>
                    <Tutorial open={isTutorialDrawerOpen} handleTutorialDrawer={handleTutorialDrawer} />
                </ErrorBoundary>
            )}
        </Grid>
    );
};

export default Landing;
