import React, { memo, useCallback } from 'react';
import LoyaltyMenuBottomSheetContent from '@clubpay/loyalty/dist/drivers/customer/Menu/BottomSheetContent';
import { SwipeableCustomerDrawer } from '@qlub-dev/qlub-kit';
import { StackElements } from '@qlub-dev/qlub-kit/dist/components/StackElements';
import MenuButton from '@/views/Bill/Landing/MenuButton';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import useEventsCenter from '@/hooks/eventsCenter';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';

interface IProps {
    visibilityControl: {
        loyaltyBottomSheetOpen: boolean;
        onCloseLoyaltyBottomSheet: () => void;
        onOpenLoyaltyBottomSheet: () => void;
        isLoyaltyBottomSheet: boolean;
    };
    menuUrl: any;
    payableAmount?: number;
    commission?: number;
    viewMenuText?: string;
    viewMenuButtonText: string;
}

const ViewMenuBottomSheet: React.FC<IProps> = ({
    visibilityControl,
    menuUrl,
    payableAmount,
    commission,
    viewMenuText,
    viewMenuButtonText,
}) => {
    const { lang, routerPush } = useQlubRouter();
    const {
        userProfile: { tapOnLoginEvent },
    } = useEventsCenter();
    const { t } = useTranslation('common');

    const { login, setDrawerConstants } = useAuth();

    const handleLogin = useCallback(() => {
        tapOnLoginEvent();

        if (visibilityControl?.onCloseLoyaltyBottomSheet) {
            visibilityControl.onCloseLoyaltyBottomSheet();
        }
        setDrawerConstants({
            text: {
                phone: {
                    title: '',
                    description: '',
                    buttonText: t('Continue'),
                },
                otp: {
                    title: '',
                    description: '',
                    buttonText: t('Continue'),
                },
                done: {
                    title: '',
                    description: '',
                    buttonText: '',
                },
            },
            numInputs: 5,
        });
        login?.({ guest: false, isFullPage: true });
    }, [menuUrl, routerPush, tapOnLoginEvent, t, login, visibilityControl]);

    return (
        <SwipeableCustomerDrawer
            anchor="bottom"
            open={visibilityControl?.loyaltyBottomSheetOpen}
            headerTitle=""
            onOpen={visibilityControl?.onOpenLoyaltyBottomSheet}
            onClose={visibilityControl?.onCloseLoyaltyBottomSheet}
            mobileWidth
        >
            <StackElements
                alignItems="center"
                justifyContent="center"
                direction="column"
                spacing={7}
                style={{
                    paddingTop: '10px',
                    paddingBottom: '14.2vh',
                }}
            >
                <LoyaltyMenuBottomSheetContent
                    billAmount={payableAmount}
                    billCommission={commission}
                    onLogin={handleLogin}
                />
                <MenuButton
                    variant="contained"
                    buttonText={viewMenuButtonText}
                    viewMenuText={viewMenuText}
                    lang={lang}
                    menuUrl={menuUrl}
                    isLoyaltyBottomSheet={{
                        status: visibilityControl?.isLoyaltyBottomSheet,
                    }}
                />
            </StackElements>
        </SwipeableCustomerDrawer>
    );
};

export default memo(ViewMenuBottomSheet);
