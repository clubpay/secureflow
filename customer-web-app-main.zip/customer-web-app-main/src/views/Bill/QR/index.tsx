/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React from 'react';
import Head from 'next/head';
import QRWidget from '@/components/Bill/QR';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

import { CustomerContainer } from '@qlub-dev/qlub-kit';
import styles from './index.module.scss';

export default function QR() {
    const { t } = useTranslation('common');

    return (
        <CustomerContainer centered className={styles.mainContainer}>
            <Head>
                <title>Qlub_ | QR</title>
            </Head>
            <div>{t('QR')}</div>
            <QRWidget />
        </CustomerContainer>
    );
}
