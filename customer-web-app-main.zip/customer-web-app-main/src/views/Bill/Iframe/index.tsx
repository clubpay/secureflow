/*
    Creation Time: 2022 - May - 10
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useEffect } from 'react';
import Head from 'next/head';
import { CircularProgress } from '@mui/material';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';

import styles from './index.module.scss';

export default function Iframe() {
    const { query } = useQlubRouter();
    const { status, Token } = query as {
        status: string;
        Token: string;
    };

    useEffect(() => {
        if (status === undefined) {
            return;
        }
        console.log({ status, Token });
        window.top?.postMessage(
            JSON.stringify({
                status,
                Token,
            }),
            window.location.origin,
        );
    }, [status, Token]);

    return (
        <>
            <Head>
                <title>Qlub_ | Iframe redirection</title>
            </Head>
            <div className={styles.loading}>
                <CircularProgress size={48} thickness={2} color="primary" />
            </div>
        </>
    );
}
