/*
    Creation Time: 2021 - Oct - 30
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useEffect, useMemo, useState } from 'react';
import Head from 'next/head';
import { Paper } from '@mui/material';
import ReactMarkdown from 'react-markdown';
import ConfigRepo from '@clubpay/customer-common-module/src/repository/config';
import { convertMultiLocaleStringToObject } from '@clubpay/customer-common-module/src/component/MultiLocale';
import termsData from '@/views/Bill/Static/markdown/terms';
import { CustomerContainer } from '@qlub-dev/qlub-kit';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { NextPageWithLayout } from '@/layout/types';
import { title } from 'process';

import styles from '../Static/markdown.module.scss';

const Markdown: NextPageWithLayout = () => {
    const { url, lang } = useQlubRouter();
    const [locales, setLocales] = useState<{ [key: string]: string }>({});

    useEffect(() => {
        ConfigRepo.getInstance()
            ?.getConfig(url.cc)
            ?.then((res) => {
                setLocales(convertMultiLocaleStringToObject(res.termsAndConditions || '', termsData));
            });
    }, [url.cc]);

    const markdown = useMemo(() => {
        return locales[lang || 'en'] || locales.default || '';
    }, [locales, lang]);

    return (
        <div className={styles.container}>
            <Head>
                <title>Qlub_ | {title}</title>
            </Head>
            <CustomerContainer padding="sm" maxWidth="md">
                <Paper elevation={0}>
                    <div className={styles.markdown}>
                        <ReactMarkdown>{markdown}</ReactMarkdown>
                    </div>
                </Paper>
            </CustomerContainer>
        </div>
    );
};

export default Markdown;
