import React from 'react';
import Head from 'next/head';
import { Paper } from '@mui/material';
import ReactMarkdown from 'react-markdown';
import { CustomerContainer } from '@qlub-dev/qlub-kit';
import { NextPageWithLayout } from '@/layout/types';

import styles from './markdown.module.scss';

interface IProps {
    title?: string;
    content?: string;
}

const Markdown: NextPageWithLayout<IProps> = (props) => {
    const { title = 'Default Title', content = 'No content available.' } = props;

    return (
        <div className={styles.container}>
            <Head>
                <title>Qlub_ | {title}</title>
            </Head>
            <CustomerContainer padding="sm" maxWidth="md">
                <div className={styles.title}>{title}</div>
                <Paper elevation={0}>
                    <div className={styles.markdown}>
                        <ReactMarkdown>{content}</ReactMarkdown>
                    </div>
                </Paper>
            </CustomerContainer>
        </div>
    );
};

export default Markdown;
