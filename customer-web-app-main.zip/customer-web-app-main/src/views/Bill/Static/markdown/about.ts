const data = `QlubPay India [tallah.com](https://tallah.com) is owned and operated by G R S DESIGN & FACILITIES

9996/1, NEW ROHTAK ROAD,G/F, KAROL BAGH, Central Delhi, Delhi, 110005

GSTIN 07CHYPS2348G1ZO.`;

export default data;
