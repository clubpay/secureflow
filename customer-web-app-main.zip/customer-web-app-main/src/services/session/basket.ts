import { IBasket } from '@/repositories/menu/types';
import { v4 as uuidv4 } from 'uuid';
import { qlubSessionStorage } from '@clubpay/customer-common-module/src/service/storage/sessionStorage';

const basketObject: {
    refId: string;
    order: IBasket;
} = {
    refId: uuidv4(),
    order: {
        extra: null,
        items: [],
        vendorId: {
            cc: '',
            slug: '',
        },
        tableData: undefined,
    },
};

export const setSSBasket = (order: IBasket) => {
    qlubSessionStorage.set('qlub.basket', JSON.stringify(order));
    basketObject.order = order;
};

export const getSSBasket = (): IBasket => {
    if (basketObject.order.items.length > 0) {
        return basketObject.order;
    }
    const s = qlubSessionStorage.get('qlub.basket');
    if (s) {
        try {
            basketObject.order = JSON.parse(s);
        } catch {
            basketObject.order = {
                extra: null,
                items: [],
                vendorId: {
                    cc: '',
                    slug: '',
                },
            };
        }
    } else {
        basketObject.order = {
            extra: null,
            items: [],
            vendorId: {
                cc: '',
                slug: '',
            },
        };
    }
    return basketObject.order;
};

export const removeSSBasket = () => {
    qlubSessionStorage.remove('qlub.basket');
    basketObject.refId = uuidv4();
    basketObject.order = {
        extra: null,
        items: [],
        vendorId: {
            cc: '',
            slug: '',
        },
    };
};

export const setBasketOrderId = (orderId: string) => {
    basketObject.refId = orderId;
};

export const getBasketOrderId = () => {
    return basketObject.refId;
};
