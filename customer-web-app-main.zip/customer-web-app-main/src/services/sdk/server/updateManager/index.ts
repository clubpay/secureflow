/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import Server, { ISubscribeRequest } from '@/services/sdk/server';

export const UpdateMSG = {
    UpdatePaymentDetails: 'UpdatePaymentDetails',
    UpdateNetworkConnect: 'UpdateNetworkConnect',
};

interface IUpdateEnvelope {
    type: string;
    data: any;
}

export default class UpdateManager {
    public static getInstance() {
        if (!this.instance) {
            this.instance = new UpdateManager();
        }

        return this.instance;
    }

    private static instance: UpdateManager;

    private updateQueue: IUpdateEnvelope[] = [];

    private updateInterval: any = null;

    private updateListeners: { [key: string]: { [key: number]: any } } = {};

    private updateListenerIndex = 0;

    private isReady = false;

    private server: Server;

    public constructor() {
        this.server = Server.getInstance();
        this.server.setConnectFn(this.connectHandler);
        this.server.setUpdateFn(this.parseUpdate);
        setTimeout(() => {
            // init repo
            this.isReady = true;
        }, 100);
    }

    public listen(type: string, fn: any): (() => void) | null {
        if (!type) {
            return null;
        }
        this.updateListenerIndex++;
        const fnIndex = this.updateListenerIndex;
        if (!this.updateListeners.hasOwnProperty(type)) {
            this.updateListeners[type] = {};
        }
        this.updateListeners[type][fnIndex] = fn;
        return () => {
            delete this.updateListeners[type][fnIndex];
        };
    }

    public subscribe(data: ISubscribeRequest) {
        this.server.subscribe(data);
    }

    public unsubscribe() {
        this.server.unsubscribe();
    }

    private connectHandler = () => {
        this.callHandlers(UpdateMSG.UpdateNetworkConnect, {});
    };

    private parseUpdate = (type: string, data: any) => {
        this.updateQueue.push({
            type,
            data,
        });
        this.updateThrottler();
    };

    private updateThrottler() {
        if (!this.isReady) {
            return;
        }
        this.dispatchUpdate();
        if (!this.updateInterval) {
            this.updateInterval = setInterval(() => {
                this.dispatchUpdate();
            }, 5);
        }
    }

    private dispatchUpdate() {
        if (this.updateQueue.length > 0) {
            const update = this.updateQueue.shift();
            if (update) {
                this.processUpdate(update.type, update.data);
            }
        } else {
            clearInterval(this.updateInterval);
            this.updateInterval = null;
        }
    }

    private processUpdate(type: string, data: any) {
        window.console.debug(`%cUpdate ${type}`, 'color: #cc0000', data);
        switch (type) {
            case UpdateMSG.UpdatePaymentDetails:
                this.callHandlers(UpdateMSG.UpdatePaymentDetails, {
                    details: {
                        ...data.details,
                        partiesList: data.details.parties || [],
                    },
                });
                break;
            default:
                console.log('update is not handled');
                break;
        }
    }

    private callHandlers(type: string, data: any) {
        if (!this.updateListeners[type]) {
            return;
        }
        Object.values(this.updateListeners[type]).forEach((fn) => {
            if (fn) {
                fn(data);
            }
        });
    }
}
