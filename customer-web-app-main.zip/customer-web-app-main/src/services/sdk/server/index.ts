/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import { cloneDeep, isEqual, forEachRight } from 'lodash';
import { wsApiUrl } from '@clubpay/customer-common-module/src/repository/axios/constants';
import { getRandomId } from '@clubpay/customer-common-module/src/utility/random';
import { C_ERR, C_ERR_ITEM } from '../const';

export const currentUser: {
    id: string;
} = {
    id: '0',
};

const pingTimeout = 10000;

export const setCurrentUserId = (id: string) => {
    currentUser.id = id;
};

export const getCurrentUserId = () => {
    return currentUser.id;
};

// const C_IDLE_TIME = 300;
const C_TIMEOUT = 20000;
export const C_RETRY = 3;

interface IErrorPair {
    Code: string;
    Items: string;
}

interface IRequestOptions {
    retry?: number;
    retryErrors?: IErrorPair[];
    retryWait?: number;
    timeout?: number;
}

interface IEnvelope {
    hdr: {
        requestID: string;
        cmd: string;
    };
    payload: any;
}

export interface IPing {
    ID: number;
}

export interface ISubscribeRequest {
    country: string;
    restaurantUnique: string;
    diningSessionID: string;
    id: string;
}

export interface IServerRequest {
    cmd: string;
    data: any;
    options?: IRequestOptions;
    reqId: string;
    retry: number;
    timeout: any;
}

interface IMessageListener {
    reject: any;
    request: IServerRequest;
    resolve: any;
    state: number;
}

export default class Server {
    public static getInstance() {
        if (!this.instance) {
            this.instance = new Server();
        }

        return this.instance;
    }

    private static instance: Server;

    private defaultGateway = '';

    private socket: WebSocket | undefined;

    private connected = false;

    private tryCounter = 0;

    private initTimeout: any = null;

    private lastSendTime = 0;

    private lastReceiveTime = 0;

    private online: boolean = navigator.onLine === undefined ? true : navigator.onLine;

    private reqId = 0;

    private messageListeners: { [key: string]: IMessageListener } = {};

    private sentQueue: string[] = [];

    private cancelList: string[] = [];

    private readonly sessionId: number = 0;

    private pingTimeout: any = null;

    private subscribeData: ISubscribeRequest | undefined;

    private onUpdateFn: ((cmd: string, data: any) => void) | undefined;

    private onConnectFn: (() => void) | undefined;

    public constructor() {
        this.reqId = 0;
        this.sessionId = getRandomId();
        this.initWebSocket();
    }

    public getSessionId() {
        return this.sessionId;
    }

    public clearAll() {
        this.closeWire(true);
        this.cancelList = [];
        this.messageListeners = {};
        this.sentQueue = [];
    }

    public setUpdateFn(fn: any) {
        this.onUpdateFn = fn;
    }

    public setConnectFn(fn: any) {
        this.onConnectFn = fn;
    }

    /* Send a request */
    public send(
        cmd: string,
        data: any,
        instant: boolean,
        options?: IRequestOptions,
        reqIdFn?: (rId: string) => void,
    ): Promise<any> {
        if (this.defaultGateway === `wss://`) {
            this.initWebSocket();
        }
        let internalResolve = null;
        let internalReject = null;

        const reqId = String(++this.reqId);
        if (reqIdFn) {
            reqIdFn(reqId);
        }
        // retry on E00 Server error
        if (!options) {
            options = {
                retry: 3,
                retryErrors: [
                    {
                        Code: C_ERR.ErrCodeInternal,
                        Items: C_ERR_ITEM.ErrItemServer,
                    },
                    {
                        Code: C_ERR.ErrCodeInternal,
                        Items: C_ERR_ITEM.ErrItemTimeout,
                    },
                ],
            };
        } else if (options.retryErrors) {
            if (
                !options.retryErrors.find(
                    (o) => o.Code === C_ERR.ErrCodeInternal && o.Items === C_ERR_ITEM.ErrItemServer,
                )
            ) {
                options.retryErrors.push({
                    Code: C_ERR.ErrCodeInternal,
                    Items: C_ERR_ITEM.ErrItemServer,
                });
            }
        }

        const request: IServerRequest = {
            cmd,
            data,
            options,
            reqId,
            retry: 0,
            timeout: null,
        };

        const promise = new Promise((res, rej) => {
            internalResolve = res;
            internalReject = rej;
            if (this.connected) {
                this.sendRequest(request);
            }
        });

        /* Add request to the queue manager */
        this.messageListeners[reqId] = {
            reject: internalReject,
            request,
            resolve: internalResolve,
            state: 0,
        };

        if (cmd !== 'PaymentSubscribe') {
            this.sentQueue.push(reqId);
        }

        return promise;
    }

    public cancelReqId(id: string) {
        if (this.cancelList.indexOf(id) === -1) {
            this.cancelList.push(id);
        }
    }

    public startNetwork() {
        this.initWebSocket();
    }

    public stopNetwork() {
        this.connected = false;
        if (this.socket) {
            this.socket.onclose = null;
            this.socket.onmessage = null;
        }
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            try {
                this.socket.close(3000);
            } catch (e) {
                window.console.log(e);
            }
        }
    }

    public subscribe(data: ISubscribeRequest) {
        if (!isEqual(data, this.subscribeData)) {
            this.subscribeData = data;
            this.subscribeRequest();
        }
    }

    public unsubscribe() {
        this.subscribeData = undefined;
    }

    private cancelRequest(request: IServerRequest) {
        const index = this.cancelList.indexOf(request.reqId);
        if (index > -1) {
            this.cancelList.splice(index, 1);
            delete this.messageListeners[request.reqId];
            window.console.debug(`%c${request.cmd} ${request.reqId} cancelled`, 'color: #cc0000');
            return true;
        }
        return false;
    }

    /* Generate string from request and send to the api */
    private sendRequest(request: IServerRequest) {
        if (this.cancelList.length > 0) {
            if (this.cancelRequest(request)) {
                return;
            }
        }
        window.console.debug(`%c${request.cmd} ${request.reqId}`, 'color: #f9d71c');
        request.timeout = setTimeout(
            () => {
                this.dispatchTimeout(request.reqId);
            },
            request.options ? request.options.timeout || C_TIMEOUT : C_TIMEOUT,
        );
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            const envelope: IEnvelope = {
                hdr: {
                    cmd: request.cmd,
                    requestID: request.reqId,
                },
                payload: request.data,
            };
            this.socket.send(JSON.stringify(envelope));
        }
    }

    private response(dd: string) {
        const d: IEnvelope = JSON.parse(dd);
        const { hdr, payload } = d;
        const { cmd, requestID } = hdr;
        const reqId = hdr.requestID;
        const data = payload;
        if (payload && cmd && (!requestID || requestID === '0')) {
            if (this.onUpdateFn) {
                this.onUpdateFn(cmd, data);
            }
            return;
        }
        if (cmd !== 'Error') {
            window.console.debug(`%c${cmd} ${reqId}`, 'color: #f967a0');
        }
        if (!this.messageListeners[reqId]) {
            return;
        }
        try {
            const res = data;
            if (cmd === 'Error') {
                window.console.error(cmd, reqId, res);
            }
            if (res) {
                window.console.info('%cResponse', 'background-color: #ff4000', res);
            }
            if (res) {
                if (cmd === 'Error') {
                    if (this.checkRetry(reqId, res)) {
                        if (this.messageListeners[reqId].reject) {
                            let isLogout = false;
                            if (
                                this.messageListeners[reqId] &&
                                this.messageListeners[reqId]
                                    .request /* && this.messageListeners[reqId].request.constructor === C_MSG.AuthLogout */
                            ) {
                                isLogout = true;
                            }
                            if (
                                res.Code === C_ERR.ErrCodeUnavailable &&
                                res.Items === C_ERR_ITEM.ErrItemUserID &&
                                !isLogout
                            ) {
                                // if (this.updateManager) {
                                //     this.updateManager.forceLogOut();
                                // }
                            } else {
                                this.messageListeners[reqId].reject(res);
                            }
                        }
                    }
                } else if (this.messageListeners[reqId].resolve) {
                    this.messageListeners[reqId].resolve(res);
                }
                clearTimeout(this.messageListeners[reqId].request.timeout);
                this.cleanQueue(reqId);
            }
        } catch (e) {
            window.console.warn(e, `reqId: ${reqId}`);
            if (this.messageListeners[reqId] && this.messageListeners[reqId].request) {
                const req = JSON.parse(this.messageListeners[reqId].request.data);
                if (req) {
                    window.console.warn(`${this.messageListeners[reqId].request.cmd} payload`);
                }
            }
        }
    }

    private checkRetry(id: string, error: IErrorPair) {
        if (!this.messageListeners[id]) {
            return true;
        }

        const req: IServerRequest = this.messageListeners[id].request;
        if (!req) {
            return true;
        }

        if (!req.options || !req.options.retryErrors || (req.options.retry || C_RETRY) <= req.retry) {
            return true;
        }

        const check = req.options.retryErrors.some((err) => {
            return error.Code === err.Code && error.Items === err.Items;
        });
        if (!check) {
            return true;
        }

        const msg = this.messageListeners[id];
        const reqId = String(++this.reqId);
        const request: IServerRequest = cloneDeep(req);
        request.reqId = reqId;
        request.retry++;
        request.timeout = null;

        if (this.connected) {
            setTimeout(() => {
                this.sendRequest(request);
            }, req.options.retryWait || 0);
        }

        /* Add request to the queue manager */
        this.messageListeners[reqId] = {
            reject: msg.reject,
            request,
            resolve: msg.resolve,
            state: 0,
        };

        this.sentQueue.push(reqId);

        return false;
    }

    private flushSentQueue() {
        const skipIds = this.getSkippableRequestIds();
        this.sentQueue.forEach((reqId) => {
            if (this.messageListeners[reqId]) {
                const msg = this.messageListeners[reqId];
                if (skipIds.length > 0 && skipIds.indexOf(msg.request.reqId) > -1) {
                    if (msg.reject) {
                        msg.reject({
                            code: C_ERR.ErrCodeInternal,
                            items: C_ERR_ITEM.ErrItemSkip,
                        });
                    }
                    this.cleanQueue(reqId);
                } else {
                    this.sendRequest(msg.request);
                }
            }
        });
    }

    private dispatchTimeout(reqId: string) {
        const item = this.messageListeners[reqId];
        if (!item) {
            return;
        }
        window.console.warn('sdk timeout', reqId, item.request.cmd);
        if (
            this.checkRetry(reqId, {
                Code: C_ERR.ErrCodeInternal,
                Items: C_ERR_ITEM.ErrItemTimeout,
            })
        ) {
            if (item.reject) {
                const name = item.request.cmd;
                item.reject({
                    cmd: name,
                    err: 'timeout',
                    reqId,
                });
            }
        }
        this.cleanQueue(reqId);
    }

    private cleanQueue(reqId: string) {
        delete this.messageListeners[reqId];
        const index = this.sentQueue.indexOf(reqId);
        if (index > -1) {
            this.sentQueue.splice(index, 1);
        }
    }

    private initWebSocket() {
        this.defaultGateway = wsApiUrl;
        if (this.socket) {
            try {
                this.socket.close(3000);
            } catch (e) {
                //
            }
        }
        clearTimeout(this.initTimeout);

        this.tryCounter++;

        this.socket = new WebSocket(this.defaultGateway);

        // Connection opened
        this.socket.onopen = () => {
            window.console.log('WebSocket opened', new Date());
            if (this.socket && this.socket.readyState !== WebSocket.OPEN) {
                return;
            }
            this.tryCounter = 0;
            this.connected = true;
            this.lastSendTime = Date.now();
            this.lastReceiveTime = Date.now() + 1;
            this.connected = true;
            if (this.subscribeData) {
                this.subscribeRequest();
            }
            if (this.onConnectFn) {
                this.onConnectFn();
            }
            this.flushSentQueue();
            this.resetPing();
        };

        // Listen for messages
        this.socket.onmessage = (event) => {
            this.lastReceiveTime = Date.now();
            this.response(event.data);
            this.resetPing();
        };

        // Listen for messages
        this.socket.onclose = () => {
            this.closeWire();
        };
    }

    private subscribeRequest() {
        if (!this.subscribeData || !this.connected) {
            return;
        }
        this.send('PaymentSubscribe', this.subscribeData, true);
    }

    private closeWire(force?: boolean) {
        this.connected = false;
        if (this.socket) {
            this.socket.onclose = null;
            this.socket.onmessage = null;
        }
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            try {
                this.socket.close(3000);
            } catch (e) {
                window.console.log(e);
            }
        }
        // this.dispatchEvent(EventWebSocketClose, null);
        // if (!this.online && !force) {
        //     return;
        // }
        // clearTimeout(this.initTimeout);
        if (force) {
            this.initWebSocket();
        } else if (this.tryCounter === 0) {
            this.initTimeout = setTimeout(() => {
                this.initWebSocket();
            }, 1000);
        } else {
            this.initTimeout = setTimeout(() => {
                this.initWebSocket();
            }, 5000 + Math.floor(Math.random() * 3000));
        }
    }

    private resetPing() {
        if (this.pingTimeout) {
            clearTimeout(this.pingTimeout);
            this.pingTimeout = null;
        }
        this.pingTimeout = setTimeout(() => {
            this.checkPing();
        }, pingTimeout);
    }

    private checkPing() {
        const ping: IPing = {
            ID: getRandomId(),
        };
        this.send('Ping', ping, true, {
            timeout: 5000,
            retry: 1,
        }).catch(() => {
            this.closeWire(true);
        });
    }

    private getSkippableRequestIds() {
        const containList: string[] = [];
        const reqIds: string[] = [];
        forEachRight(this.sentQueue, (reqId) => {
            const req = this.messageListeners[reqId];
            if (req && (req.request.cmd === 'Ping' || req.request.cmd === 'PaymentSubscribe')) {
                if (containList.indexOf(req.request.cmd) > -1) {
                    reqIds.push(req.request.reqId);
                } else {
                    containList.push(req.request.cmd);
                }
            }
        });
        return reqIds;
    }
}
