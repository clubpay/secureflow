import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import { EnableEnum, IRestaurant, IRestaurantConfig } from '@clubpay/customer-common-module/src/repository/vendor';

export const getTableTitle = (vendor: IRestaurant | undefined, tableName: string | undefined, id: string) => {
    const getText = () => {
        if (vendor) {
            if (vendor.config?.hideTableName && vendor.config?.hideTableId) {
                return '';
            }
            if (vendor.config?.hideTableName !== true && vendor.config?.hideTableId !== true && tableName) {
                return `${id}${tableName !== '' ? ` (${tableName})` : ''}`;
            }
            if (vendor.config?.hideTableId === true && tableName) {
                return tableName;
            }
            if (!vendor.config.previewBill && vendor.config?.hideTableName !== true && vendor.config?.hideTableId) {
                return '';
            }
            return id;
        }
        return undefined;
    };
    const text = getText();
    if (text?.startsWith('-')) {
        return {
            pager: true,
            text: text?.substring(1) || '',
        };
    }
    return {
        pager: false,
        text: text || '',
    };
};

export const aggregateConfig = (
    vendorConfig: IRestaurantConfig | undefined,
    countryConfig: IConfig | null,
    identifier: keyof IRestaurantConfig | keyof IConfig,
) => {
    if (!vendorConfig || !countryConfig) return;
    if (vendorConfig[identifier as keyof IRestaurantConfig] === EnableEnum.Disable) {
        return undefined;
    }
    if (vendorConfig[identifier as keyof IRestaurantConfig] === EnableEnum.Enable) {
        return vendorConfig;
    }
    if (
        !vendorConfig[identifier as keyof IRestaurantConfig] &&
        countryConfig[identifier as keyof IConfig] === EnableEnum.Enable
    ) {
        return countryConfig;
    }
    return undefined;
};

export const extractLanguageKey = (lang: string, key?: string) => {
    if (!key) return;
    const parsed = JSON.parse(key);
    if (Array.isArray(parsed)) {
        return parsed.find((e: any) => e.locale === lang)?.value;
    }
    return parsed;
};
