import { DateEnum } from '@/components/QSR/QSRDateTimePicker';
import { ScheduledOrderEnum } from '@/components/QSR/QSRScheduledOrder';
import { INameTranslation, IQSROrder, IQSRUrlData, ISessionEditPayload } from '@/repositories/menu/types';
import { IRestaurant, OrderPaymentMethodEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import DateService from '@clubpay/customer-common-module/src/service/date';
// eslint-disable-next-line import/no-duplicates
import { differenceInMinutes, eachDayOfInterval, endOfWeek, format, parseISO, startOfWeek } from 'date-fns';
// eslint-disable-next-line import/no-duplicates
import { ar, de, enUS, es, ja, pt, tr, zhCN, zhHK, ko, ru } from 'date-fns/locale';
import { IURLTopology, QSRRouterModeEnum } from '@clubpay/customer-common-module/src/hook/router';
import MenuAPIManager from '@/repositories/menu';

export const createDateBasedOnDay = (day?: DateEnum, startTime?: string) => {
    if (!day || !startTime) {
        return;
    }
    const currentDate = new Date();

    if (day === DateEnum.Tomorrow) {
        currentDate.setDate(currentDate.getDate() + 1);
    } else if (day === DateEnum.NextDay) {
        currentDate.setDate(currentDate.getDate() + 2);
    }

    const [hours, minutes] = startTime.split(':');
    currentDate.setHours(Number(hours || 0), Number(minutes || 0), 0, 0);

    return currentDate;
};

export const numberToDay = (lang: string, day?: DateEnum | string, short?: boolean) => {
    if (!day) {
        return '';
    }

    if (day === DateEnum.Today) {
        return day;
    }

    const now = new Date();
    const today = now.getDay();
    const daysOfWeekFns = eachDayOfInterval({
        start: startOfWeek(now),
        end: endOfWeek(now),
    });
    const locale = (language: string) => {
        switch (language) {
            case 'ar':
                return ar;
            case 'de':
                return de;
            case 'es':
                return es;
            case 'ja':
                return ja;
            case 'pt':
                return pt;
            case 'tr':
                return tr;
            case 'zh':
                return zhCN;
            case 'hk':
                return zhHK;
            case 'ko':
                return ko;
            case 'ru':
                return ru;
            case 'en':
            default:
                return enUS;
        }
    };

    const daysOfWeek = daysOfWeekFns.map((d) => format(d, 'EEEEEEEE', { locale: locale(lang) }));

    const shortDaysOfWeek = daysOfWeekFns.map((d) => format(d, 'EEE.', { locale: locale(lang) }));
    if (!isNaN(Number(day))) {
        return short ? shortDaysOfWeek[Number(day)] : daysOfWeek[Number(day)];
    }

    if (day === DateEnum.Tomorrow) {
        const dayNum = (today + 1) % 7;
        return short ? shortDaysOfWeek[dayNum] : day;
    }

    if (day === DateEnum.NextDay) {
        const dayNum = (today + 2) % 7;
        return short ? shortDaysOfWeek[dayNum] : daysOfWeek[dayNum];
    }
    return day;
};

export const roundTime = (unix: number, minRound: number) => {
    return Math.ceil(unix / (60 * minRound)) * minRound * 60;
};

export const prepTimeDiffText = (prepTime?: number, acceptTime?: string) => {
    if (!prepTime || !acceptTime) {
        return undefined;
    }

    const now = DateService.getInstance().getNow();
    const acceptDate = parseISO(acceptTime);
    const remainedTime = prepTime - differenceInMinutes(now, acceptDate);
    if (remainedTime > 0) {
        return remainedTime;
    }

    return undefined;
};

export const orderToSchedule = (order: IQSROrder, vendor: IRestaurant | undefined) => {
    if (order.scheduledAt && order.pickupAt) {
        if (!order.pickupAt) {
            return undefined;
        }

        const now = DateService.getInstance().getNow();
        const pickDate = new Date(order.pickupAt);
        const differenceDay = pickDate.getDay() - now.getDay();
        const start = ((pickDate.getHours() || 0) * 60 + (pickDate.getMinutes() || 0)) * 60;
        const end = start + (vendor?.orderConfig?.scheduledOrderOptionGap || 15) * 60;
        let date: DateEnum = DateEnum.Today;
        switch (differenceDay) {
            case 1:
                date = DateEnum.Tomorrow;
                break;
            case 2:
                date = DateEnum.NextDay;
                break;
            default:
        }

        return {
            type: order.pickupAt ? ScheduledOrderEnum.Scheduled : ScheduledOrderEnum.ASAP,
            value: {
                date,
                timePeriod: {
                    start: DateService.getInstance().getTime(start),
                    end: DateService.getInstance().getTime(end),
                },
            },
        };
    }
};

export const moveToPreparationCondition = (url: IURLTopology, successfulPayment: boolean) => {
    if (!successfulPayment) {
        return false;
    }
    if (!url.qsr || !url.qOrderId || url.qsrMA) {
        return false;
    }
    if (url.qsr === QSRRouterModeEnum.Mixed) {
        return url.qsrPayment === OrderPaymentMethodEnum.Default;
    }
    return true;
};

export const editSessionApiCall = (url: IURLTopology, payload: ISessionEditPayload) => {
    MenuAPIManager.getInstance()
        .editSession(url, {
            orderId: payload.orderId,
            reference: payload.reference,
            dsi: payload.dsi,
        })
        .then((res) => {
            console.log(res);
        })
        .catch((err) => {
            console.log(err);
        });
};

const embedPathName = '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/embed';
const normalPathName = '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]';

export const trimPathnameForEmbed = (pathname: string, currentPathname?: string) => {
    if (currentPathname?.startsWith(embedPathName)) {
        return pathname.replace(normalPathName, embedPathName);
    }
    return pathname;
};

export const translator = (name?: string, translations?: INameTranslation, lang?: string, ellipsisLen?: number) => {
    const translation = translations?.[lang as keyof typeof translations] || name || '';
    if (ellipsisLen && translation.length > ellipsisLen) {
        return `${translation.substring(0, ellipsisLen)}...`;
    }
    return translation;
};

export const getUrlStringFromUrlData = (data: IQSRUrlData) => {
    return `${data.tableId}/${data.f1}/${data.f2}/${data.hash}`;
};

export const preparationTimeDiff = (prepTime?: number, acceptTime?: string) => {
    if (!prepTime || !acceptTime) {
        return 0;
    }

    const localDate = new Date();
    const acceptDate = new Date(`${acceptTime}`);
    const seconds = Math.round((localDate.getTime() - acceptDate.getTime()) / 1000);
    if (seconds < prepTime * 60) {
        return prepTime * 60 - seconds;
    }
    return 0;
};

export const checkEmpty = (val: any) => {
    if (!val) {
        return val;
    }

    if (!val?.length) {
        return null;
    }

    return val;
};
