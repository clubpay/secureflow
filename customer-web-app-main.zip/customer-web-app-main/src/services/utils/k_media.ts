import { IMedia } from '@/repositories/menu/types';

export const getMediaFirstItem = (media: undefined | IMedia[], thumb?: boolean) => {
    if (thumb) {
        return media?.[0]?.thumbnail?.url || media?.[0]?.originalFile;
    }
    return media?.[0]?.originalFile;
};

export const getMediaList = (media: undefined | IMedia[]) => {
    return (
        media?.map((m) => {
            return {
                thumb: m?.thumbnail?.url || m?.originalFile,
                original: m?.originalFile,
            };
        }) || []
    );
};

export const getImageString = (image: string | { src: string } | undefined): string | undefined => {
    if (typeof image === 'string') return image;
    if (image && typeof image === 'object' && 'src' in image) return image.src;
    return undefined;
};
