const isCollidingWithContainerEdge = (containerRect: DOMRect, elementRect: DOMRect) => {
    return (
        elementRect.left <= containerRect.left ||
        elementRect.right >= containerRect.right ||
        elementRect.top <= containerRect.top ||
        elementRect.bottom >= containerRect.bottom
    );
};

export const moveToStart = (el: any, ignoreCollisionCheck?: boolean) => {
    if (!el) {
        return;
    }

    const container = el?.parentElement?.parentElement;
    if (!container) {
        return;
    }

    const rtl = getComputedStyle(container).direction === 'rtl'; // Check if the layout is RTL

    const containerRect = container.getBoundingClientRect();
    const tabRect = el.getBoundingClientRect();
    if (!ignoreCollisionCheck && isCollidingWithContainerEdge(containerRect, tabRect)) {
        setTimeout(() => {
            moveToStart(el, true);
        }, 500);
        return;
    }

    let offset = tabRect.left - containerRect.left + container.scrollLeft;
    if (rtl) {
        offset -= containerRect.width - tabRect.width;
    }

    container.scrollTo({
        left: offset + (rtl ? 1 : -1),
        behavior: 'smooth',
    });
};
