import { IAdditiveItem, IBasket, IOrderItem, OrderItemStatusEnum } from '@/repositories/menu/types';
import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor/type';
import { kRoundNumber } from '@/services/utils/k_round';
import { OrderPriceRoundingModeEnum } from '@clubpay/customer-common-module/src/repository/vendor';

interface IOptions {
    currencyPrecision?: number;
    vendor?: IRestaurant;
    isEmbedVendor?: boolean;
}

export const calculateAdditivePrice = (items: IAdditiveItem[] | undefined): number => {
    return (
        items?.reduce((a, b) => {
            return a + (b.price + calculateAdditivePrice(b.additives)) * b.quantity;
        }, 0) || 0
    );
};

export const calculateItemPrice = (orderItem: IOrderItem, { currencyPrecision, vendor }: IOptions) => {
    const amount = (orderItem.price + calculateAdditivePrice(orderItem.additives)) * orderItem.quantity;
    if (currencyPrecision && vendor) {
        return kRoundNumber(
            amount,
            currencyPrecision,
            vendor?.orderConfig?.priceRoundingMode || OrderPriceRoundingModeEnum.Round,
        );
    }
    return amount;
};

export const calculateTotalPrice = (basket: IBasket | undefined, options: IOptions) => {
    const amount =
        basket?.items?.reduce((a, b) => {
            if (b.status === OrderItemStatusEnum.Rejected) {
                return a;
            }
            if (!options.isEmbedVendor && b.timestamp) {
                return a;
            }
            return a + calculateItemPrice(b, {});
        }, 0) ||
        basket?.totalAmount ||
        0;
    return kRoundNumber(
        amount,
        options.currencyPrecision || 0,
        options?.vendor?.orderConfig?.priceRoundingMode || OrderPriceRoundingModeEnum.Round,
    );
};

export const calculateOrderCount = (bask: IBasket | undefined, { isEmbedVendor }: IOptions) => {
    if (!bask) {
        return 0;
    }
    return bask.items.reduce((a, b) => {
        if (!isEmbedVendor && b.timestamp) {
            return a;
        }
        return a + b.quantity;
    }, 0);
};
