export const convertToMinutes = (time12h: string): number => {
    const [time, modifier] = time12h.split(' ');
    const [hoursStr, minutes] = time.split(':');
    let hours = parseInt(hoursStr, 10);

    if (modifier?.toLowerCase() === 'pm' && hours !== 12) {
        hours += 12;
    }
    if (modifier?.toLowerCase() === 'am' && hours === 12) {
        hours = 0;
    }

    return Number(hours) * 60 + Number(minutes);
};

export const getMinutesSinceStartOfDay = () => {
    const now = new Date();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    return hours * 60 + minutes;
};
