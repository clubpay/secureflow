function chunkArray<T>(array: Array<T>, chunkSize: number) {
    const result: Array<Array<T>> = [];
    for (let i = 0; i < array.length; i += chunkSize) {
        result.push(array.slice(i, i + chunkSize));
    }
    return result;
}

export async function kPromiseAll<T, R>(array: Array<T>, batchNum: number, fn: (item: T) => Promise<R>): Promise<R[]> {
    const res: Array<R> = [];
    const chunks = chunkArray(array, batchNum);
    for (let i = 0; i < chunks.length; i++) {
        // eslint-disable-next-line no-await-in-loop
        const batchRes = await Promise.all(chunks[i].map((o) => fn(o)));
        res.push(...batchRes);
    }
    return res;
}
