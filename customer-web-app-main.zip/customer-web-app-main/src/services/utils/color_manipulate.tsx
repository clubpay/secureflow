import { HexColor } from '@/components/Tutorial/Pagination/types';

interface IProps {
    hex: HexColor;
    opacity: number;
}

const reduceOpacity = ({ hex, opacity }: IProps) => {
    const alpha = Math.round(opacity * 255)
        .toString(16)
        .padStart(2, '0');
    return `${hex}${alpha}`;
};

export { reduceOpacity };
