const client = 'vendor_panel';

export const IframeCmdEnum = {
    Bool: 'bool',
    Close: 'close',
    Error: 'error',
    Loaded: 'loaded',
};

interface IMessageListener {
    cmd: string;
    reject: any;
    resolve: any;
    timeout?: any;
}

interface IMessage {
    client: string;
    cmd: string;
    data: any;
    mode: 'req' | 'res';
    reqId: number;
}

interface IResMessage {
    cmd: string;
    data: any;
    reqId: number;
}

interface IReq<T> {
    data: T;
}

interface IRes<T> {
    data: T;
}

class IframeBridge {
    public static getInstance() {
        if (!this.instance) {
            this.instance = new IframeBridge();
        }

        return this.instance;
    }

    private static instance: IframeBridge;

    private fnQueue: any = {};

    private fnIndex = 0;

    private reqId = 0;

    private messageListeners: { [key: number]: IMessageListener } = {};

    constructor() {
        this.init();
        this.api('/init/load', () => {
            return Promise.resolve({
                data: {},
            });
        });
    }

    init() {
        window.addEventListener('message', (e) => {
            if (!e.data) {
                return;
            }
            try {
                const data: IMessage = JSON.parse(e.data);
                if (data.mode === 'res') {
                    this.response(data);
                } else if (data.mode === 'req') {
                    this.callHandlers(data.cmd, data);
                }
            } catch (err) {
                // window.console.warn(e);
            }
        });
    }

    /* API handler */
    public api<P = any, R = any>(path: string, fn: (e: IReq<P>) => Promise<IRes<R>>) {
        if (!path) {
            return null;
        }

        return this.listen(path, (payload) => {
            fn({
                data: payload.data,
            })
                .then((res) => {
                    this.sendResponse({
                        cmd: path,
                        data: res,
                        reqId: payload.reqId,
                    });
                })
                .catch((err) => {
                    this.sendResponse({
                        cmd: IframeCmdEnum.Error,
                        data: err,
                        reqId: payload.reqId,
                    });
                });
        });
    }

    /* Listen to event */
    public listen(subject: string, fn: (e: IMessage) => void): (() => void) | null {
        if (!subject) {
            return null;
        }

        this.fnIndex++;
        const idx = this.fnIndex;
        if (!this.fnQueue.hasOwnProperty(subject)) {
            this.fnQueue[subject] = {};
        }
        this.fnQueue[subject][idx] = fn;
        return () => {
            delete this.fnQueue[subject][idx];
        };
    }

    public loaded() {
        console.log('customer app | load even sent');
        this.send('/init/load', {})
            .then((res) => {
                console.log(res);
            })
            .catch((err) => {
                console.warn(err);
            });
    }

    public submitOrder(order: any) {
        return this.send('/order/submit', { order });
    }

    public handleError(error: any) {
        return this.send('/order/error', { error });
    }

    /* Call queue handler */
    private callHandlers(subject: string, payload: IMessage) {
        if (!this.fnQueue.hasOwnProperty(subject)) {
            return;
        }

        Object.values(this.fnQueue[subject]).forEach((fn: any) => {
            fn?.(payload);
        });
    }

    private sendResponse(data: IResMessage) {
        window.parent.postMessage(
            JSON.stringify({
                client,
                cmd: data.cmd,
                data: data.data,
                mode: 'res',
                reqId: data.reqId,
            }),
            '*',
        );
    }

    // @ts-ignore
    private send(cmd: string, data: any) {
        let internalResolve = null;
        let internalReject = null;

        const reqId = ++this.reqId;

        const promise = new Promise<any>((res, rej) => {
            internalResolve = res;
            internalReject = rej;
        });

        this.messageListeners[reqId] = {
            cmd,
            reject: internalReject,
            resolve: internalResolve,
        };

        window.parent?.postMessage(
            JSON.stringify({
                client,
                cmd,
                data,
                mode: 'req',
                reqId,
            }),
            '*',
        );

        this.messageListeners[reqId].timeout = setTimeout(() => {
            this.dispatchTimeout(reqId);
        }, 10000);

        return promise;
    }

    private response(data: IMessage) {
        if (!this.messageListeners.hasOwnProperty(data.reqId)) {
            return false;
        }

        if (data.cmd === IframeCmdEnum.Error) {
            this.messageListeners[data.reqId].reject(data.data);
        } else {
            this.messageListeners[data.reqId].resolve(data.data);
        }
        if (this.messageListeners[data.reqId].timeout) {
            clearTimeout(this.messageListeners[data.reqId].timeout);
        }
        delete this.messageListeners[data.reqId];
        return true;
    }

    private dispatchTimeout(reqId: number) {
        const item = this.messageListeners[reqId];
        item?.reject?.({
            err: 'timeout',
            reqId,
        });
    }
}

export default IframeBridge;
