import SocketClient, { Socket } from 'socket.io-client';
import AuthManager from '@clubpay/customer-common-module/src/repository/auth';
import { IQSROrder } from '@/repositories/menu/types';

export const SOCKET_URL = process.env.NEXT_PUBLIC_MENU_SOCKET_URL;

export enum SocketEventEnum {
    Connect = 'connect',
    Disconnect = 'disconnect',
    ConnectError = 'connectError',
    Order = 'order',
    Unauthorized = 'unauthorized',
}

enum SocketInternalEventEnum {
    CustomerJoin = 'customerJoin',
    OrderUpdate = 'orderUpdate',
}

interface ISocketIOConnectParam {
    orderId: string;
}

export interface IEventOrder {
    eventName: string;
    details: IQSROrder;
}

export class SocketService {
    private socket: Socket | undefined;

    static instance: SocketService;

    static getInstance = () => {
        if (!SocketService.instance) {
            SocketService.instance = new SocketService();
        }
        return SocketService.instance;
    };

    private init = false;

    private connected = false;

    private events: { [key: string]: { [key: number]: any } } = {};

    private eventIdx: number = 0;

    private authManager = AuthManager.getInstance();

    public on(event: string, fn: any) {
        if (!this.events.hasOwnProperty(event)) {
            this.events[event] = {};
        }
        this.eventIdx++;
        const idx = this.eventIdx;
        this.events[event][idx] = fn;
        return () => {
            delete this.events[event][idx];
        };
    }

    public disconnect() {
        if (this.socket) {
            this.socket.disconnect();
            this.connected = false;
        }
    }

    public destroy() {
        if (this.socket) {
            this.socket.disconnect();
            this.socket = undefined;
            this.connected = false;
        }
    }

    public connect(params: ISocketIOConnectParam): Promise<Socket> {
        this.init = true;
        if (this.connected) {
            this.disconnect();
        }
        return this.socketOpen(params.orderId).then((res) => {
            this.connected = true;
            return res;
        });
    }

    private callEvent(event: string, payload?: any) {
        const events = this.events[event];
        if (events) {
            Object.values(events).forEach((fn) => {
                fn?.(payload);
            });
        }
    }

    private socketOpen(refId: string): Promise<Socket> {
        return new Promise<Socket>((resolve, reject) => {
            this.authManager.menuAuth().then((token) => {
                if (!this.socket) {
                    const socket = SocketClient(SOCKET_URL || '', {
                        auth: {
                            accessToken: token,
                            refId,
                        },
                        transports: ['websocket'],
                        reconnection: true,
                        reconnectionAttempts: 5,
                        reconnectionDelay: 2000,
                    });

                    this.socket = socket;

                    const connectTimeout = setTimeout(() => {
                        this.callEvent(SocketEventEnum.Unauthorized);
                        this.authManager.menuRefresh().then(() => {
                            if (this.connected) {
                                this.disconnect();
                            }
                            this.socketOpen(refId)
                                .then(() => {
                                    resolve(socket);
                                })
                                .catch(() => {
                                    reject();
                                });
                        });
                    }, 5000);

                    socket.on('connect', () => {
                        clearTimeout(connectTimeout);
                        this.callEvent(SocketEventEnum.Connect);
                        console.log('Socket connected with id ', socket.id);
                        socket.emit(SocketInternalEventEnum.CustomerJoin);

                        socket.on(SocketInternalEventEnum.OrderUpdate, this.messageHandler);
                        resolve(socket);
                    });

                    socket.on('connect_error', (err: any) => {
                        console.error('Error in creating socket ', err);
                        this.callEvent(SocketEventEnum.ConnectError, err);
                        reject();
                    });

                    socket.on('disconnect', (err: any) => {
                        console.log('disconnect');
                        this.callEvent(SocketEventEnum.Disconnect, err);
                    });
                } else if (!this.socket.connected) {
                    this.socket.connect();

                    this.socket.on('connect', () => {
                        this.callEvent(SocketEventEnum.Connect);
                        if (this.socket) {
                            this.socket.emit(SocketInternalEventEnum.CustomerJoin);

                            this.socket.on(SocketInternalEventEnum.OrderUpdate, this.messageHandler);
                            resolve(this.socket);
                        } else {
                            reject();
                        }
                    });

                    this.socket.on('connect_error', (err: any) => {
                        this.callEvent(SocketEventEnum.ConnectError, err);
                        console.error('Error in creating socket ', err);
                        reject();
                    });
                } else {
                    resolve(this.socket);
                }
            });
        });
    }

    private messageHandler = (e: any) => {
        this.callEvent(SocketEventEnum.Order, e);
    };
}
