export const footerVariant = 'no-flag';
export const skipForex = 'qlub.payment.skip_forex';
