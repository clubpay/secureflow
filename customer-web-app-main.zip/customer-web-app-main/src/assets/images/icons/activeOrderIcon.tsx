import React from 'react';

interface IProps {
    color: string;
}

const activeOrderIcon = ({ color }: IProps) => {
    return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M5.99557 12.782C4.99857 12.592 4.06057 12.035 3.46857 11.006C2.78057 9.811 2.85057 8.261 3.65557 7.143C4.77857 5.583 6.77957 5.208 8.35157 5.971C8.67557 4.281 10.1826 3 11.9996 3C13.8166 3 15.3236 4.281 15.6466 5.971C17.2156 5.21 19.2106 5.581 20.3346 7.131C21.1436 8.247 21.2156 9.794 20.5356 10.993C19.9446 12.035 19.0036 12.588 18.0036 12.777L17.9966 19C17.9956 20.104 17.1006 20.998 15.9966 20.998L7.98857 21C6.88257 21 5.98657 20.103 5.98857 18.998L5.99557 12.782Z"
                stroke={color || '#7D00D4'}
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M18 16.5H6"
                stroke={color || '#7D00D4'}
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
        </svg>
    );
};

export default activeOrderIcon;
