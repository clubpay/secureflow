import React from 'react';

interface IProps {
    color: string;
}

const OrderDoneIcon = ({ color }: IProps) => {
    return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M19.8 20.7002H4.2C3.8 20.7002 3.4 20.4002 3.3 20.0002L2.5 17.7002H21.5L20.7 20.0002C20.6 20.4002 20.2 20.7002 19.8 20.7002Z"
                stroke={color || '#7D00D4'}
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M3.10044 17.6998V16.6998C2.80044 11.5998 6.90044 7.2998 12.1004 7.2998V7.2998C17.2004 7.2998 21.3004 11.5998 21.1004 16.6998V17.6998"
                stroke={color || '#7D00D4'}
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M12 7.3V7.3C10.9 7.3 10 6.4 10 5.3V5C10 3.9 10.9 3 12 3V3C13.1 3 14 3.9 14 5V5.3C14 6.4 13.1 7.3 12 7.3Z"
                stroke={color || '#7D00D4'}
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
        </svg>
    );
};

export default OrderDoneIcon;
