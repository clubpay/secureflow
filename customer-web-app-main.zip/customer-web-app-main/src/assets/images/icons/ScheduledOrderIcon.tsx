import React from 'react';

interface IProps {
    color: string;
}
const ScheduledOrderIcon = ({ color }: IProps) => {
    return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M21 16V18C21 19.6569 19.6569 21 18 21H17"
                stroke={color || '#7D00D4'}
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M3 9V6C3 4.34315 4.34315 3 6 3H8"
                stroke={color || '#7D00D4'}
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M3 20L4.156 20.578C4.71109 20.8555 5.32318 21 5.94378 21H12.5C13.3284 21 14 20.3284 14 19.5V19.5C14 18.6716 13.3284 18 12.5 18H8.5"
                stroke={color || '#7D00D4'}
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M3 13H5.91335C6.34609 13 6.76716 13.1404 7.11335 13.4L9.35062 15.0779C9.7271 15.3603 9.96252 15.7921 9.99588 16.2615C10.0292 16.731 9.85726 17.1917 9.5245 17.5245V17.5245C8.95325 18.0958 8.04889 18.16 7.4026 17.6753L6 16.6233"
                stroke={color || '#7D00D4'}
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <rect
                x="11"
                y="3.56824"
                width="10"
                height="9"
                rx="2.25"
                stroke={color || '#7D00D4'}
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M14.5 3.56824H17.5V6.06824C17.5 6.34438 17.2761 6.56824 17 6.56824H15C14.7239 6.56824 14.5 6.34438 14.5 6.06824V3.56824Z"
                stroke={color || '#7D00D4'}
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
        </svg>
    );
};

export default ScheduledOrderIcon;
