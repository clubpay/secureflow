import { createSvgIcon } from '@mui/material';

const RestaurantLogoPlaceholderIcon = createSvgIcon(
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40">
        <circle cx="20" cy="20" r="19" fill="#f8f8f8" stroke="#2a2a2a" strokeWidth="1" />

        <path d="M17 12 v16 M15 12 v6 M19 12 v6" stroke="#2a2a2a" strokeWidth="1" strokeLinecap="round" />

        <path
            d="M23 12 c0 0 1 4 1 8 c0 4 -1 8 -1 8"
            stroke="#2a2a2a"
            strokeWidth="1"
            fill="none"
            strokeLinecap="round"
        />
    </svg>,
    'RestaurantLogoPlaceholderIcon',
);

export default RestaurantLogoPlaceholderIcon;
