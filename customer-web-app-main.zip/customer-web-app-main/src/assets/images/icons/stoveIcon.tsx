import React from 'react';

interface IProps {
    color: string;
}

const StoveIcon = ({ color }: IProps) => {
    return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M5 12.1602H3"
                stroke={color || '#7D00D4'}
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M21 12.1602H19"
                stroke={color || '#7D00D4'}
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M6 11H18C18.5523 11 19 11.4029 19 11.9V17.3C19 18.7912 17.6569 20 16 20H8C6.34315 20 5 18.7912 5 17.3V11.9C5 11.4029 5.44772 11 6 11Z"
                stroke={color || '#7D00D4'}
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M15.5 8C14.8333 7.3 14.8333 6.2 15.5 5.5C16.1667 4.8 16.1667 3.7 15.5 3"
                stroke={color || '#7D00D4'}
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M12 8C11.3333 7.3 11.3333 6.2 12 5.5C12.6667 4.8 12.6667 3.7 12 3"
                stroke={color || '#7D00D4'}
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M8.5 8C7.83333 7.3 7.83333 6.2 8.5 5.5C9.16667 4.8 9.16667 3.7 8.5 3"
                stroke={color || '#7D00D4'}
                strokeLinecap="round"
                strokeLinejoin="round"
            />
        </svg>
    );
};

export default StoveIcon;
