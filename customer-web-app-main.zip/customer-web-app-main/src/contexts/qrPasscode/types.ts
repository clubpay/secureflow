export interface IQrPasscodeContext {
    passcode: string;
    setPasscode: (passcode: string) => void;
}
