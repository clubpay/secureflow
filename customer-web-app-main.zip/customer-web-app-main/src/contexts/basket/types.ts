import { IBasket } from '@/repositories/menu/types';

export interface IBasketContext {
    basket: IBasket;
    setBasket: (basket: IBasket) => void;
}
