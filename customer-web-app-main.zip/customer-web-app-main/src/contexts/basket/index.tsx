import { createContext, ReactNode, useContext, useState } from 'react';
import { getSSBasket, setSSBasket } from '@/services/session/basket';
import { IBasket, IOrderVendorId } from '@/repositories/menu/types';
import { IURLTopology } from '@clubpay/customer-common-module/src/hook/router';
import { IBasketContext } from './types';

export const getVendorId = (url: IURLTopology): IOrderVendorId => {
    return {
        cc: url.cc,
        slug: url.slug,
    };
};

const BasketContext = createContext<IBasketContext>({ basket: getSSBasket(), setBasket: setSSBasket });

interface IProps {
    children?: ReactNode;
}

export function BasketContextProvider({ children }: IProps) {
    const [basket, setBasket] = useState<IBasket>(getSSBasket());

    const setBasketHandler = (bsk: IBasket) => {
        setSSBasket(bsk);
        setBasket(bsk);
    };

    return <BasketContext.Provider value={{ basket, setBasket: setBasketHandler }}>{children}</BasketContext.Provider>;
}

export const useBasket = () => useContext(BasketContext);
