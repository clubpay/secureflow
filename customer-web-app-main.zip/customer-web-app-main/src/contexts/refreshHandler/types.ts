export interface IRefreshHandlerContext {
    disable: boolean;
    refreshFunction: any;
    onChangeDisable: (newVal: boolean) => void;
    setPullFunc: (fn: any) => void;
}
