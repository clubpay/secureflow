import { createContext, ReactNode, useContext, useRef, useState } from 'react';
import { IRefreshHandlerContext } from './types';

const RefreshContext = createContext<IRefreshHandlerContext>({
    disable: false,
    onChangeDisable: () => console.log('not implemented'),
    refreshFunction: () => Promise.resolve(),
    setPullFunc: () => console.log('not implemented'),
});

interface Props {
    children?: ReactNode;
}

export function RefreshContextProvider({ children }: Props) {
    const childFunc = useRef(null);
    const [disable, setDisable] = useState<boolean>(false);

    const refreshFunction: any = () => {
        if (childFunc.current) {
            // @ts-ignore
            return childFunc.current();
        }
    };

    const onChangeDisable = (newVal: boolean) => {
        setDisable(newVal);
    };

    const setPullFunc = (fn: any) => {
        childFunc.current = fn;
    };

    return (
        <RefreshContext.Provider value={{ disable, refreshFunction, onChangeDisable, setPullFunc }}>
            {children}
        </RefreshContext.Provider>
    );
}

export const useRefresh = () => useContext(RefreshContext);
