import { createContext, ReactNode, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import IframeBridge from '@/services/iframeBridge';
import { EmbedModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import MenuAPIManager from '@/repositories/menu';
import { useBasket } from '@/contexts/basket';
import { removeSSBasket, setBasketOrderId } from '@/services/session/basket';
import { IOrderTableData } from '@/repositories/menu/types';
import { resetDiningOption } from '@/components/QSR/QSRDiningOptionModal';
import {
    IBridgeContext,
    IBridgeValues,
    IVendorCreateOrderReq,
    IVendorGetOrderReq,
    IVendorGetOrderRes,
    IVendorTokenUpdateReq,
    IVendorTokenUpdateRes,
    IVendorCreateOrderRes,
    HandleSubmitOrderType,
    HandleOrderErrorType,
    HandleBackType,
    HandleVoidFnType,
} from './types';

const embedPathnameList = [
    '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/embed/qsr',
    '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/embed/qsr/social',
    '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/embed/qsr/[menu]',
    '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/embed/qsr/preparation',
    '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/embed/qsr/order_details',
];

const bridge: IBridgeValues = {
    vendorToken: '',
};

const BridgeContext = createContext<IBridgeContext>({
    vendorToken: '',
    handleSubmitOrder: () => console.log('not implemented'),
    handleOrderError: () => console.log('not implemented'),
    handleLoad: () => console.log('not implemented'),
    handleBack: () => console.log('not implemented'),
});

interface IProps {
    children?: ReactNode;
}

export function BridgeContextProvider({ children }: IProps) {
    const iframeBridge = useRef<IframeBridge | null>(null);
    const [vendorToken, setVendorToken] = useState(bridge.vendorToken);
    const { url, pathname, isReady, routerPush, back } = useQlubRouter();
    const { setBasket } = useBasket();

    const backBtnFnRef = useRef<any>(null);
    const hasBackBtnRef = useRef(false);

    const cleanUp = useCallback((opt?: { delay?: number; tableData?: IOrderTableData }) => {
        removeSSBasket();
        setTimeout(() => {
            resetDiningOption();
            setBasket({
                extra: null,
                items: [],
                vendorId: {
                    cc: url.cc,
                    slug: url.slug,
                },
                tableData: opt?.tableData,
            });
        }, opt?.delay || 1);
    }, []);

    const isEmbedded = useMemo(() => {
        if (!isReady) {
            return false;
        }

        return embedPathnameList.includes(pathname);
    }, [isReady, pathname]);

    const isVendor = useMemo(() => {
        if (!isEmbedded) {
            return false;
        }

        return url.embed === EmbedModeEnum.Vendor;
    }, [isEmbedded, url.embed]);

    const isSoftPos = useMemo(() => {
        if (!isEmbedded) {
            return false;
        }

        return url.embed === EmbedModeEnum.SoftPos;
    }, [isEmbedded, url.embed]);

    useEffect(() => {
        if (!isEmbedded) {
            return;
        }

        const vendorInit = () => {
            iframeBridge.current = IframeBridge.getInstance();
            setTimeout(() => {
                iframeBridge.current?.loaded();
            }, 1000);

            return [
                iframeBridge.current?.api<IVendorGetOrderReq, IVendorGetOrderRes>('/order/load', (res) => {
                    cleanUp();
                    bridge.vendorToken = res.data.token || '';
                    setVendorToken(bridge.vendorToken);
                    return routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/embed/qsr/order_details', {
                        ...res.data.url,
                    }).finally(() => {
                        return MenuAPIManager.getInstance()
                            .getOrder(url, res.data.refId, { vendorToken: bridge.vendorToken })
                            .then((data) => {
                                setBasketOrderId(data.refId);
                                setBasket({ ...data.orderData, note: data.customerComment });
                                return {
                                    data: {
                                        success: true,
                                    },
                                };
                            })
                            .catch(() => {
                                return {
                                    data: {
                                        success: false,
                                    },
                                };
                            });
                    });
                }),
                iframeBridge.current?.api<IVendorCreateOrderReq, IVendorCreateOrderRes>('/order/create', (res) => {
                    cleanUp({
                        tableData: res.data.tableData,
                    });
                    bridge.vendorToken = res.data.token || '';
                    setVendorToken(bridge.vendorToken);
                    return routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/embed/qsr', {
                        ...res.data.url,
                    }).finally(() => {
                        return {
                            data: {
                                success: true,
                            },
                        };
                    });
                }),
                iframeBridge.current?.api<IVendorTokenUpdateReq, IVendorTokenUpdateRes>('/token/update', (res) => {
                    bridge.vendorToken = res.data.token || '';
                    setVendorToken(bridge.vendorToken);
                    return Promise.resolve({
                        data: {
                            success: true,
                        },
                    });
                }),
            ];
        };

        const cancellers = isVendor ? vendorInit() : [];

        return () => {
            cancellers?.forEach((c) => {
                c?.();
            });
        };
    }, [isEmbedded, cleanUp, isVendor]);

    const submitOrderHandler: HandleSubmitOrderType = useCallback(
        (params, order) => {
            if (!isEmbedded) {
                return Promise.reject(new Error('invalid order'));
            }

            if (isVendor) {
                if (!iframeBridge.current) {
                    return Promise.reject(new Error('iframe is not initialized'));
                }

                return (iframeBridge.current?.submitOrder(order) || Promise.reject(new Error('invalid order'))).then(
                    (res) => {
                        cleanUp({ delay: 1000 });
                        return res;
                    },
                );
            }

            if (isSoftPos) {
                // call softPos submit api
                // @ts-ignore
                window?.softpos?.processPayment?.(JSON.stringify(params));
                cleanUp({ delay: 1000 });
                return Promise.resolve({});
            }

            return Promise.reject(new Error('invalid embed type'));
        },
        [isEmbedded, cleanUp, isVendor, isSoftPos],
    );

    const orderErrorHandler: HandleOrderErrorType = useCallback(
        (err) => {
            if (!isEmbedded) {
                return Promise.reject(new Error('invalid order'));
            }

            if (isVendor) {
                if (!iframeBridge.current) {
                    return Promise.reject(new Error('iframe is not initialized'));
                }

                return iframeBridge.current?.handleError(err) || Promise.reject(new Error('invalid order'));
            }

            if (isSoftPos) {
                // call softPos submit api
                // @ts-ignore
                window?.softpos?.processPayment?.(JSON.stringify(params));
                return Promise.resolve({});
            }

            return Promise.reject(new Error('invalid embed type'));
        },
        [isEmbedded, cleanUp, isVendor, isSoftPos],
    );

    const appLoadHandler: HandleVoidFnType = useCallback(() => {
        if (!isEmbedded || !isSoftPos) {
            return;
        }

        // @ts-ignore
        window?.softpos?.pageFullyLoaded?.();
    }, [isEmbedded, isSoftPos]);

    const appBackHandler: HandleBackType = useCallback(
        (hasBackBtn, fn) => {
            if (!isEmbedded || !isSoftPos) {
                return;
            }

            hasBackBtnRef.current = hasBackBtn;
            // @ts-ignore
            window?.softpos?.pageHasBackButton?.(hasBackBtn);

            backBtnFnRef.current = fn;
        },
        [isEmbedded, isSoftPos],
    );

    useEffect(() => {
        if (!isEmbedded || !isSoftPos) {
            return;
        }

        if (!window?.softpos) {
            return;
        }

        // @ts-ignore
        window.softpos.handleBack = () => {
            if (backBtnFnRef.current) {
                backBtnFnRef.current?.();
                return;
            }

            back();
        };

        // @ts-ignore
        window.softpos.handleHasBack = () => {
            return hasBackBtnRef.current || false;
        };
    }, [isEmbedded, isSoftPos]);

    return (
        <BridgeContext.Provider
            value={{
                vendorToken,
                handleSubmitOrder: submitOrderHandler,
                handleOrderError: orderErrorHandler,
                handleLoad: appLoadHandler,
                handleBack: appBackHandler,
            }}
        >
            {children}
        </BridgeContext.Provider>
    );
}

export const useBridge = () => useContext(BridgeContext);
