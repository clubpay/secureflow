import { IURLTopology } from '@clubpay/customer-common-module/src/hook/router';
import { IOrderTableData, IQSROrder } from '@/repositories/menu/types';

export type HandleSubmitOrderType = (params: Record<string, any>, order: IQSROrder) => void;

export type HandleOrderErrorType = (err: any) => void;

export type HandleVoidFnType = () => void;

export type HandleBackType = (hasBackBtn: boolean, fn?: any) => void;

export interface IBridgeContext {
    vendorToken: string;
    handleSubmitOrder: HandleSubmitOrderType;
    handleOrderError: HandleOrderErrorType;
    handleBack: HandleBackType;
    handleLoad: HandleVoidFnType;
}

export interface IBridgeValues {
    vendorToken: string;
}

export interface IVendorGetOrderReq {
    refId: string;
    token: string;
    url: IURLTopology;
}

export interface IVendorGetOrderRes {
    success: boolean;
}

export interface IVendorCreateOrderReq {
    token: string;
    url: IURLTopology;
    tableData?: IOrderTableData;
}

export interface IVendorCreateOrderRes {
    success: boolean;
}

export interface IVendorTokenUpdateReq {
    token: string;
}

export interface IVendorTokenUpdateRes {
    success: boolean;
}
