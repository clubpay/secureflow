import { IURLTopology } from '@clubpay/customer-common-module/src/hook/router';

export interface ICreateReq {
    url: IURLTopology;
    dsi: string;
    rate: number;
    body: string;
    isDraft?: boolean;
}

interface IMeta {
    isDraft: boolean;
}

export interface IConfigItem {
    id: string;
    name: string;
    nameTranslations: any; // Specify further if nameTranslations has a specific structure
    type: string;
    service: string;
    meta: any; // Specify further if meta has a specific structure
}

export interface IConfig {
    orderItems?: IConfigItem[];
    behavioralItems?: IConfigItem[];
    redirectionItems?: IConfigItem[];
    formItems?: IConfigItem[];
}

export interface IReview {
    id: string;
    userId: string;
    dsi: string;
    rate: number;
    body: string;
    meta: IMeta;
    createdAt: string;
    config?: IConfig;
}

export interface ICreateRes {
    data: IReview;
}

export interface IGetReq {
    url: IURLTopology;
    dsi: string;
}

export interface IGetRes {
    data: IReview;
}

export interface ISubmitActivityReq {
    url: IURLTopology;
    reviewId: string;
    configId: string;
    meta: any;
}

export interface IActivity {
    id: number;
    reviewId: number;
    vendorKey: string;
    configId: number;
    createdAt: Date;
    updatedAt?: Date;
    type: string;
    meta?: Record<string, any>;
}

export interface ISubmitActivityRes {
    data: IActivity;
}
