import axiosInstance from '@clubpay/customer-common-module/src/repository/axios';
import { IURLTopology } from '@clubpay/customer-common-module/src/hook/router';
import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor';
import { ICreateReq, ICreateRes, IGetReq, IGetRes, IReview, ISubmitActivityReq, ISubmitActivityRes } from './types';
import apiEndpoints from './const';

const parseReview = (review: IReview | undefined, options?: { vendor?: IRestaurant }): IReview | undefined => {
    if (review?.config?.redirectionItems) {
        review.config.redirectionItems = review?.config?.redirectionItems.filter((item) => {
            if (item.type === 'redirection' && item.service === 'google') {
                return Boolean(item.meta.googlePlaceId || options?.vendor?.googlePlaceId);
            }
            return item;
        });
    }
    return review;
};

export default class ReviewAPIManager {
    private static instance: ReviewAPIManager;

    public static getInstance() {
        if (!this.instance) {
            this.instance = new ReviewAPIManager();
        }

        return this.instance;
    }

    public get(payload: IGetReq, options?: { vendor?: IRestaurant }) {
        return axiosInstance
            .Get<IGetRes>(apiEndpoints.get.replace(':table_topology', this.getUrl(payload.url)), {
                'axios-retry': {
                    retries: 3,
                },
                params: {
                    dsi: payload.dsi,
                },
            })
            .then((res) => {
                return parseReview(res.data?.data, options);
            });
    }

    public submit(payload: ICreateReq, options?: { vendor?: IRestaurant }) {
        const { url, ...rest } = payload;
        return axiosInstance
            .Post<ICreateRes, Omit<ICreateReq, 'url'>>(
                apiEndpoints.create.replace(':table_topology', this.getUrl(url)),
                { ...rest },
                {
                    'axios-retry': {
                        retries: 3,
                    },
                },
            )
            .then((res) => {
                return parseReview(res.data?.data, options);
            });
    }

    public submitActivity(payload: ISubmitActivityReq) {
        const { url, ...rest } = payload;
        return axiosInstance
            .Post<ISubmitActivityRes, Omit<ISubmitActivityReq, 'url'>>(
                apiEndpoints.submitActivity.replace(':table_topology', this.getUrl(url)),
                { ...rest },
                {
                    'axios-retry': {
                        retries: 3,
                    },
                },
            )
            .then((res) => {
                return res.data?.data;
            });
    }

    private getUrl(payload: IURLTopology) {
        return `${payload.cc}/${payload.slug}/${payload.id}/${payload.f1 || '_'}/${payload.f2 || '_'}/${
            payload.hash || '_'
        }`;
    }
}
