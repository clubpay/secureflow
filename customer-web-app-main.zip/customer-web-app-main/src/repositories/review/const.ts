export const reviewApiUrlPrefix = '/v2/review';

export const apiEndpoints = {
    get: `${reviewApiUrlPrefix}/:table_topology`,
    create: `${reviewApiUrlPrefix}/:table_topology`,
    submitActivity: `${reviewApiUrlPrefix}/activity/:table_topology`,
};

export default apiEndpoints;
