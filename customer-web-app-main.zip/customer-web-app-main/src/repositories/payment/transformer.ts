import { IPGExchange, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IPaymentGatewayView } from '@clubpay/customer-common-module/src/repository/vendor';

export const updatePgsForForex = (pgs: IPaymentGatewayView[], exchange?: IPGExchange) => {
    return pgs.map((pg) => ({
        ...pg,
        config: {
            ...pg.config,
            hideApplePay:
                pg.config.hideApplePay ||
                (pg.config.forexPgReallocationSupportedPaymentMethods?.includes(PaymentElementEnum.ApplePay) &&
                    exchange?.paymentMethod === PaymentElementEnum.ApplePay &&
                    !exchange?.isRoutingApplied) ||
                (pg.config.forexRetryingPaymentMethods?.includes(PaymentElementEnum.ApplePay) &&
                    (exchange?.paymentMethod !== PaymentElementEnum.ApplePay || exchange?.isRoutingApplied)),
            hideCardPay:
                pg.config.hideCardPay ||
                (pg.config.forexPgReallocationSupportedPaymentMethods?.includes(PaymentElementEnum.CardPay) &&
                    exchange?.paymentMethod === PaymentElementEnum.CardPay &&
                    !exchange?.isRoutingApplied) ||
                (pg.config.forexRetryingPaymentMethods?.includes(PaymentElementEnum.CardPay) &&
                    (exchange?.paymentMethod !== PaymentElementEnum.CardPay || exchange?.isRoutingApplied)),
        },
    }));
};
