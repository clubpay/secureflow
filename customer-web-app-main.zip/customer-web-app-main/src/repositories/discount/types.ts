export interface IGetDiscountTypesReq {
    countryCode: string;
    restaurantUnique: string;
    diningSessionID: string;
}

export interface IGetDiscountTypesRes {
    types: string[];
}

export interface IDiscountEligibilityCheckReq {
    countryCode: string;
    restaurantUnique: string;
    email: string;
    diningSessionID: string;
}

export interface IDiscountEligibilityCheckRes {
    otpID: string;
    emailID: string;
    validated: boolean;
}

export interface IValidateOTPReq {
    countryCode: string;
    restaurantUnique: string;
    diningSessionID: string;
    otpID: string;
    otpCode: string;
}

export interface IValidateOTPRes {
    code: string;
}
