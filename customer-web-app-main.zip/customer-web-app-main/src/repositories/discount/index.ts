import axiosInstance from '@clubpay/customer-common-module/src/repository/axios';
import { apiEndpoints } from './const';
import {
    IDiscountEligibilityCheckReq,
    IDiscountEligibilityCheckRes,
    IGetDiscountTypesReq,
    IGetDiscountTypesRes,
    IValidateOTPReq,
    IValidateOTPRes,
} from './types';

export default class DiscountAPIManager {
    static #instance: DiscountAPIManager;

    readonly #axiosInstance;

    constructor() {
        this.#axiosInstance = axiosInstance;
    }

    static getInstance() {
        if (!this.#instance) {
            this.#instance = new DiscountAPIManager();
        }

        return this.#instance;
    }

    public getAvailableDiscountTypes = (payload: IGetDiscountTypesReq): Promise<IGetDiscountTypesRes> => {
        return this.#axiosInstance
            .Get<IGetDiscountTypesRes>(
                apiEndpoints.getDiscountTypes
                    .replace(':countryCode', payload.countryCode)
                    .replace(':restaurantUnique', payload.restaurantUnique),
                {
                    params: {
                        diningSessionID: payload.diningSessionID,
                    },
                    'axios-retry': {
                        retries: 3,
                    },
                    timeout: 45000,
                },
            )
            .then((response) => {
                return response.data;
            })
            .catch((error) => {
                console.error('Error(discount-api-mananger-types): ', error);
                throw error;
            });
    };

    public checkDiscountEligibilty = (payload: IDiscountEligibilityCheckReq): Promise<IDiscountEligibilityCheckRes> => {
        return this.#axiosInstance
            .Get<IDiscountEligibilityCheckRes>(
                apiEndpoints.checkEligibilty
                    .replace(':countryCode', payload.countryCode)
                    .replace(':restaurantUnique', payload.restaurantUnique),
                {
                    params: {
                        diningSessionID: payload.diningSessionID,
                        email: payload.email,
                    },
                    'axios-retry': {
                        retries: 3,
                    },
                    timeout: 45000,
                },
            )
            .then((response) => {
                return response.data;
            })
            .catch((error) => {
                console.error('Error(discount-api-mananger-eligibility):', error);
                throw error;
            });
    };

    public validateOTP = (payload: IValidateOTPReq): Promise<IValidateOTPRes> => {
        return this.#axiosInstance
            .Post<IValidateOTPRes, IValidateOTPReq>(
                apiEndpoints.validateOTP
                    .replace(':countryCode', payload.countryCode)
                    .replace(':restaurantUnique', payload.restaurantUnique),
                payload,
            )
            .then((response) => {
                return response.data;
            })
            .catch((error) => {
                console.error('Error(discount-api-mananger-validate-otp):', error);
                throw error;
            });
    };
}
