export const apiEndpoints = {
    checkEligibilty: '/discounts/corporate/:countryCode/:restaurantUnique',
    validateOTP: '/discounts/corporate/:countryCode/:restaurantUnique',
    getDiscountTypes: '/discounts/types/:countryCode/:restaurantUnique',
};
