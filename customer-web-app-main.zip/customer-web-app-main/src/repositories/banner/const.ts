export const apiEndpoints = {
    get: `/v1/banner/:table_topology`,
};

export default apiEndpoints;
