import { SliderPositionEnum } from '@clubpay/customer-common-module/src/component/KSlider/enums';

export interface IBannerLocalUrls {
    [key: string]: string;
}

export interface IPaginationPayload {
    limit?: number;
    page?: number;
}

export interface IBanner {
    id?: string;
    name: string;
    docUrl: string;
    docLocalUrls?: IBannerLocalUrls;
    meta: {
        placement?: SliderPositionEnum;
        redirectUrl?: string;
        size?: string;
    };
}

export interface IBannerResponse {
    data: IBanner[];
}
