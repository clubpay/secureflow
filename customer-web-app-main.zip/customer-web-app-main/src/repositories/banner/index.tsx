import apiEndpoints from '@/repositories/banner/const';
import axiosInstance from '@clubpay/customer-common-module/src/repository/axios';
import { changeDomain } from '@clubpay/customer-common-module/src/utility/k_url';
import { cdnDomain, httpApiUrl } from '@clubpay/customer-common-module/src/repository/axios/constants';
import { IBanner, IBannerLocalUrls, IBannerResponse, IPaginationPayload } from '@/repositories/banner/types';
import { IURLTopology } from '@clubpay/customer-common-module/src/hook/router';
import { SingleFlight } from '@/repositories/banner/utility/single_flight';
import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor/type';
import { v4 as uuidv4 } from 'uuid';
import { SliderPositionEnum } from '@/components/Banner';
import { SliderLocationEnum } from '@clubpay/customer-common-module/src/component/KSlider/enums';

const parseBanner = (banner: IBanner, location: SliderLocationEnum): IBanner => {
    const { meta, ...rest } = banner;

    const getDocLocalUrls = () => {
        if (!cdnDomain || !banner.docLocalUrls) {
            return {};
        }

        return {
            docLocalUrls: Object.entries(banner.docLocalUrls).reduce<IBannerLocalUrls>((a, [k, v]) => {
                a[k] = changeDomain(v, cdnDomain) || '';
                return a;
            }, {}),
        };
    };

    return {
        ...rest,
        ...getDocLocalUrls(),
        docUrl: cdnDomain && banner.docUrl ? changeDomain(banner.docUrl, cdnDomain) || '' : banner.docUrl,
        id: uuidv4(),
        meta: {
            ...meta,
            placement:
                location === SliderLocationEnum.LandingPage
                    ? SliderPositionEnum.Middle
                    : meta?.placement ?? SliderPositionEnum.Middle,
            ...(meta?.redirectUrl && !meta?.redirectUrl?.startsWith('http')
                ? {
                      redirectUrl: `${httpApiUrl}${meta.redirectUrl}`,
                  }
                : {}),
        },
    };
};

export default class BannerAPIManager {
    private static instance: BannerAPIManager;

    public static getInstance() {
        if (!this.instance) {
            this.instance = new BannerAPIManager();
        }

        return this.instance;
    }

    // @ts-ignore
    private singleFlight: SingleFlight<IBanner>;

    constructor() {
        if (typeof window === 'undefined') {
            return;
        }

        this.singleFlight = new SingleFlight<IBanner>(
            { many: this.getBannerPr },
            {
                useRequestCache: true,
                useItemCache: true,
            },
        );
    }

    private getBannerPr = async ({
        payload,
        location,
    }: {
        payload: IURLTopology;
        location: SliderLocationEnum;
        pagination?: IPaginationPayload;
        vendor?: IRestaurant;
    }) => {
        return axiosInstance
            .Get<IBannerResponse>(apiEndpoints.get.replace(':table_topology', this.getUrl(payload)), {
                params: { location },
            })
            .then((res) => {
                return {
                    rows:
                        res.data?.data?.map((item) => {
                            return parseBanner(item, location);
                        }) || [],
                };
            });
    };

    public getBanner = (
        payload: IURLTopology,
        location: SliderLocationEnum,
        pagination?: IPaginationPayload,
        vendor?: IRestaurant,
    ) => {
        return this.singleFlight.getMany({
            payload,
            location,
            pagination,
            vendor,
        });
    };

    private getUrl(payload: IURLTopology) {
        return `${payload.cc}/${payload.slug}/${payload.id}/${payload.f1 || '_'}/${payload.f2 || '_'}/${
            payload.hash || '_'
        }`;
    }
}
