import axiosInstance from '@clubpay/customer-common-module/src/repository/axios';
import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor';
import { apiEndpoints } from './const';
import { IGetRes, IResponse } from './types';
import { filterTutorial } from './transformer';

export default class TutorialAPIManager {
    static #instance: TutorialAPIManager;

    public static getInstance() {
        if (!this.#instance) {
            this.#instance = new TutorialAPIManager();
        }

        return this.#instance;
    }

    public getTutorial(vendor?: IRestaurant) {
        return axiosInstance
            .Get<IResponse>(apiEndpoints.get, {
                'axios-retry': {
                    retries: 3,
                },
            })
            .then((res: IGetRes) => {
                const responseData = res.data as IResponse;
                return filterTutorial({ responseData, vendor });
            });
    }
}
