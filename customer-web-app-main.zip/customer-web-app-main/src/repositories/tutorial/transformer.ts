import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor';
import { IResponse } from './types';

interface IProps {
    responseData: IResponse;
    vendor?: IRestaurant;
}

export const filterTutorial = ({ responseData, vendor }: IProps) => {
    const countryCode = vendor?.country?.code || 'en';
    const tutorial = responseData.tutorials.find(
        (tutorialsItem) =>
            tutorialsItem.application === 'customer_app' &&
            tutorialsItem.entity_type === 'country' &&
            tutorialsItem.entity_id === countryCode,
    );
    return tutorial?.content[0] || null;
};
