import { HexColor } from '@/components/Tutorial/Pagination/types';

export interface IResponse {
    lastUpdated: string;
    tutorials: ITutorial[];
    version: string;
}
export interface IGetRes {
    data: IResponse;
}

export interface ITutorial {
    id: string;
    entity_id: string;
    entity_type: string;
    application: string;
    content: IContent[];
    criteria?: any;
    created_at: string;
    updated_at: string;
}

export interface IContent {
    buttons: Button[];
    color: HexColor | undefined;
    slides: Slide[];
    theme?: string;
    title: string;
}

export type Slide = {
    color: HexColor;
    media: string;
    title: string;
    description: string;
};

export type Button = {
    color: HexColor;
    title: string;
};

export type LocalizedText = {
    value: string;
    locale: string;
};
