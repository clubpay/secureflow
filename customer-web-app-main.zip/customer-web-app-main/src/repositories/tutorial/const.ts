import { cdnDomain } from '@clubpay/customer-common-module/src/repository/axios/constants';

const baseUrl = cdnDomain ? `https://${cdnDomain.replace(/^https?:\/\//, '')}` : '';

const urlPostFix =
    process.env.NEXT_PUBLIC_ENV === 'production' ? 'content.json' : `${process.env.NEXT_PUBLIC_ENV}/content.json`;

export const apiEndpoints = {
    get: `${baseUrl}/tutorials/${urlPostFix}`,
};

export default apiEndpoints;
