export enum BillStatusEnum {
    PARTIALLY_PAID = 'partiallyPaid',
    FULLY_PAID = 'fullyPaid',
    UNPAID = 'unpaid',
}

export enum RecordStatusEnum {
    accepted = 'accepted',
    pending = 'pending',
    failed = 'failed',
}

export enum FetchModeEnum {
    Order = 'order',
    Table = 'table',
    PaymentLink = 'payment_link',
}

export enum AdditiveCategoryEnum {
    Tax = 'tax',
    Discount = 'discount',
    Fee = 'fee',
    Sum = 'sum',
    Commision = 'com',
    Unknown = 'unknown',
}

export enum CampaignVoucherStateEnum {
    Hidden = 'hidden',
    Used = 'used',
    Visible = 'visible',
}

export enum GatewayPaymentMethod {
    Unknown = 'unknown',
    Card = 'card',
    ApplePay = 'apple_pay',
    GooglePay = 'google_pay',
    StcPay = 'stc_pay',
    SavedCard = 'saved_card',
    Softpos = 'softpos',
    Pix = 'pix',
}
