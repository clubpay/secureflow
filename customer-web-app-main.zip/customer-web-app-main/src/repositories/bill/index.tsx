import axiosInstance from '@clubpay/customer-common-module/src/repository/axios';
import { AxiosRequestConfig, AxiosResponse } from 'axios';
import { timeUnix } from '@clubpay/customer-common-module/src/utility/k_time';
import { clone, cloneDeep } from 'lodash';
import { apiEndpoints } from './constants';
import {
    parsePaymentDetails,
    parsePaymentReceipt,
    parsePaymentReport,
    parsePaymentStatus,
    transformSetAmountPayload,
} from './transformers';
import {
    IAddPartReq,
    ICalculateCommissionReq,
    ICalculateCommissionRes,
    IDownloadReceiptRequest,
    IEmailReceiptRequestNewReq,
    IEmailReceiptRequestPeq,
    IEmailReceiptRes,
    IGetLayoutConfig,
    IGetPaymentDetailConfig,
    IGetPaymentDetailPayload,
    IGetPaymentReportConfig,
    IGetReceiptPayload,
    ILockPaymentReq,
    IPaymentDetails,
    IPaymentDetailsCache,
    IPaymentDetailsRes,
    IPaymentLockRes,
    IPaymentReceipt,
    IPaymentReceiptRes,
    IPaymentStatus,
    IPaymentStatusReq,
    IPaymentStatusRes,
    IPaymentUnlockRes,
    IRateRequestReq,
    ISetAmountConfig,
    ISetAmountRequestPayload,
    ISetAmountRes,
    ISetAmountStringRequestPayload,
    ISetTipPayload,
    ISetTipRes,
    IToggleOptionalDinerFeeReq,
    IToggleOptionalDinerFeeRes,
    IUnlockPaymentReq,
    IVoucherValidateReq,
} from './types';
import { FetchModeEnum } from './enums';

export default class BillAPIManager {
    private static instance: BillAPIManager;

    private readonly getDetailsDebounce: any;

    private getDetailsDebounceTimeout: any = null;

    private paymentDetailsCache: { [key: string]: IPaymentDetailsCache } = {};

    private paymentStatusCache: { [key: string]: IPaymentStatusRes } = {};

    public static getInstance() {
        if (!this.instance) {
            this.instance = new BillAPIManager();
        }

        return this.instance;
    }

    public constructor() {
        this.getDetailsDebounce = (arg: any) => {
            if (this.getDetailsDebounceTimeout) {
                clearTimeout(this.getDetailsDebounceTimeout);
                this.getDetailsDebounceTimeout = null;
            }
            const cloneArg = cloneDeep(arg);
            return new Promise((resolve, reject) => {
                this.getDetailsDebounceTimeout = setTimeout(() => {
                    this.getDetailsPrivate(cloneArg).then(resolve).catch(reject);
                }, 500);
            });
        };
    }

    // General
    private getDetailsPrivate = ({
        payload,
        config,
    }: {
        payload: IGetPaymentDetailPayload;
        config?: IGetPaymentDetailConfig;
    }): Promise<IPaymentDetails> => {
        const url = `${payload.cc}/${payload.restaurantUnique}/${
            payload.payUrl || `${payload.tableID}/${payload.f1 || '_'}/${payload.f2 || '_'}/${payload.hash || '_'}`
        }`;
        let cacheKey = this.getPaymentDetailsKey(payload, config);
        if (config?.ignoreCache !== true && !payload.forceFresh && this.paymentDetailsCache.hasOwnProperty(cacheKey)) {
            const cache = this.paymentDetailsCache[cacheKey];
            const now = timeUnix();
            if (now - cache.time <= 30) {
                return Promise.resolve(cloneDeep(cache.details));
            }
        }

        return axiosInstance
            .Get<IPaymentDetailsRes>(`${apiEndpoints.details}/${url}`, {
                params: {
                    diningSessionID: payload.diningSessionID,
                    id: payload.id,
                    forceFresh: payload.forceFresh,
                    qsr: config?.qsr || false,
                    ...(payload?.fetchMode || payload.payUrl
                        ? { fetchMode: payload.payUrl ? FetchModeEnum.Order : payload?.fetchMode }
                        : {}),
                    ...(payload?.optionalDinerFee ? { optionalDinerFee: payload?.optionalDinerFee } : {}),
                },
                timeout: 45000,
                'axios-retry': {
                    retries: 3,
                },
            })
            .then((res: AxiosResponse<IPaymentDetailsRes>) => {
                return {
                    ...res.data,
                    jwt: res.headers?.['x-auth-jwt'] || res.data?.JWTToken || payload.jwt,
                };
            })
            .then((res: IPaymentDetailsRes) => {
                return parsePaymentDetails(res, { vendor: config?.vendor });
            })
            .then((res: IPaymentDetails) => {
                if (payload.diningSessionID === '' || payload.diningSessionID !== res.diningSessionID) {
                    const p = clone(payload);
                    p.diningSessionID = res.diningSessionID;
                    cacheKey = this.getPaymentDetailsKey(p, config);
                }
                this.paymentDetailsCache[cacheKey] = {
                    details: cloneDeep(res),
                    time: timeUnix(),
                    force: payload.forceFresh || false,
                };
                return res;
            });
    };

    public getDetails = (
        payload: IGetPaymentDetailPayload,
        config?: IGetPaymentDetailConfig,
    ): Promise<IPaymentDetails> => {
        if (!config?.debounce) {
            return this.getDetailsPrivate({ payload, config });
        }

        return this.getDetailsDebounce({ payload, config });
    };

    public getReceipt = (payload: IGetReceiptPayload, config?: IGetPaymentDetailConfig): Promise<IPaymentReceipt> => {
        return axiosInstance
            .Get<IPaymentReceiptRes>(`${apiEndpoints.receipt}/${payload.dsi}/${payload.pri}`, {
                timeout: 10000,
                'axios-retry': {
                    retries: 3,
                },
            })
            .then((res) => {
                return res.data;
            })
            .then((res) => {
                return parsePaymentReceipt(res, { vendor: config?.vendor });
            });
    };

    public getReceiptReport = (
        payload: IGetReceiptPayload,
        config?: IGetPaymentReportConfig,
    ): Promise<IPaymentDetails> => {
        return axiosInstance
            .Get<IPaymentReceiptRes>(`${apiEndpoints.receiptReport}/${payload.dsi}/${payload.pri}`, {
                timeout: 10000,
                'axios-retry': {
                    retries: 3,
                },
            })
            .then((res) => {
                return res.data;
            })
            .then((res) => {
                return parsePaymentReport(res, { vendor: config?.vendor, dsi: config?.dsi });
            });
    };

    public rate = (payload: IRateRequestReq) => {
        return axiosInstance.Post<any, IRateRequestReq>(
            `${apiEndpoints.rate}/${payload.diningSessionID}/${payload.id}`,
            payload,
        );
    };

    public emailReceipt = (payload: IEmailReceiptRequestPeq) => {
        return axiosInstance.Get<any, IEmailReceiptRequestPeq>(
            `${apiEndpoints.emailReceipt}/${payload.diningSessionID}/${payload.id}`,
            {
                params: {
                    email: payload.email,
                    lang: payload.lang,
                    reference: payload.reference,
                    countryCode: payload.countryCode,
                },
            },
        );
    };

    public emailReceiptV2 = (payload: IEmailReceiptRequestNewReq) => {
        return axiosInstance.Post<IEmailReceiptRes, IEmailReceiptRequestNewReq>(
            `${apiEndpoints.emailReceiptV2}/${payload.diningSessionID}/${payload.id}`,
            payload,
            {
                timeout: 45000,
            },
        );
    };

    public downloadReceipt = (payload: IDownloadReceiptRequest) => {
        return axiosInstance.Post<any, IDownloadReceiptRequest>(
            `${apiEndpoints.downloadReceipt}/${payload.diningSessionID}/${payload.id}`,
            payload,
            {
                responseType: 'blob',
                timeout: 45000,
            },
        );
    };

    public getStatus = (payload: IPaymentStatusReq): Promise<IPaymentStatus> => {
        const key = this.getStatusKey(payload);
        if (this.paymentStatusCache.hasOwnProperty(key) && !payload.force) {
            return Promise.resolve(this.paymentStatusCache[key]);
        }
        return axiosInstance
            .Get<IPaymentStatusRes>(`${apiEndpoints.status}`, {
                params: {
                    diningSessionID: payload.diningSessionID,
                    reference: payload.reference,
                    id: payload.id,
                },
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            })
            .then((res) => {
                return parsePaymentStatus(res.data);
            })
            .then((res) => {
                this.paymentStatusCache[key] = res;
                return res;
            });
    };

    public setAmount = (
        payload: ISetAmountRequestPayload,
        config?: ISetAmountConfig,
        axiosConfig?: AxiosRequestConfig,
    ) => {
        const transformedPayload = transformSetAmountPayload(payload);

        let endpoint = apiEndpoints.setAmountV2;

        if (config?.draft) {
            endpoint = apiEndpoints.draftAmount;
        }

        return axiosInstance
            .Post<ISetAmountRes, ISetAmountStringRequestPayload>(
                endpoint.replace(':diningSessionID', payload.diningSessionID).replace(':id', payload.id),
                transformedPayload,
                axiosConfig,
            )
            .then((res) => {
                return {
                    paymentDetails: parsePaymentDetails(res.data.paymentDetails, { vendor: config?.vendor }),
                    error: res.data.error,
                };
            });
    };

    public addParty = (payload: IAddPartReq, config?: IGetLayoutConfig): Promise<IPaymentDetails> => {
        return axiosInstance
            .Get<IPaymentDetailsRes>(
                `${apiEndpoints.addParty}/${payload.country}/${payload.restaurantUnique}/${payload.diningSessionID}`,
                {
                    params: {
                        id: payload.id,
                    },
                    'axios-retry': {
                        retries: 3,
                    },
                },
            )
            .then((res: any) => {
                return {
                    ...res.data,
                    jwt: payload.jwt,
                };
            })
            .then((res: IPaymentDetailsRes) => {
                return parsePaymentDetails(res, { vendor: config?.vendor });
            });
    };

    public lockPayment = (payload: ILockPaymentReq) => {
        return axiosInstance
            .Post<IPaymentLockRes, ILockPaymentReq>(apiEndpoints.lock, payload, {
                'axios-retry': {
                    retries: 3,
                },
            })
            .then((res) => {
                return res.data;
            });
    };

    public unlockPayment = (payload: IUnlockPaymentReq) => {
        return axiosInstance
            .Post<IPaymentUnlockRes, IUnlockPaymentReq>(apiEndpoints.unlock, payload, {
                'axios-retry': {
                    retries: 3,
                },
            })
            .then((res) => {
                return res.data;
            });
    };

    public calculateCommission = (payload: ICalculateCommissionReq) => {
        return axiosInstance
            .Get<ICalculateCommissionRes>(
                `${apiEndpoints.calculateCommission}/${payload.country}/${payload.restaurantUnique}/${payload.dsi}/${payload.id}`,
                {
                    params: {
                        billAmount: payload.amount,
                    },
                    'axios-retry': {
                        retries: 3,
                    },
                },
            )
            .then((res) => {
                return res.data;
            });
    };

    public validateVoucherCode = (payload: IVoucherValidateReq, config?: IGetLayoutConfig) => {
        return axiosInstance.Post<any, IVoucherValidateReq>(apiEndpoints.voucher.validate, payload).then((res) => {
            return { paymentDetails: parsePaymentDetails(res.data, { vendor: config?.vendor }), error: res.data.error };
        });
    };

    public commissionToggleOptionalDinerFee = (payload: IToggleOptionalDinerFeeReq) => {
        return axiosInstance
            .Post<IToggleOptionalDinerFeeRes, IToggleOptionalDinerFeeReq>(
                apiEndpoints.toggleOptionalDinerFee,
                payload,
                {
                    'axios-retry': {
                        retries: 3,
                    },
                },
            )
            .then((res) => {
                return res.data;
            });
    };

    public setTipAmount = (payload: ISetTipPayload) => {
        return axiosInstance
            .Post<ISetTipRes, ISetTipPayload>(apiEndpoints.tip, payload, {
                'axios-retry': {
                    retries: 3,
                },
            })
            .then((res) => {
                return res.data;
            });
    };

    private getPaymentDetailsKey(payload: IGetPaymentDetailPayload, config?: IGetPaymentDetailConfig) {
        const url = `${payload.cc}/${payload.restaurantUnique}/${payload.tableID}/${payload.f1 || '_'}/${
            payload.f2 || '_'
        }/${payload.hash || '_'}`;
        return `${url}_${payload.diningSessionID}_${payload.id}_${config?.qsr || ''}_${payload.fetchMode || ''}`;
    }

    private getStatusKey(payload: IPaymentStatusReq) {
        return `${payload.id}_${payload.diningSessionID}_${payload.reference}`;
    }
}

export * from './types';
export * from './transformers';
export * from './defaults';
export * from './constants';
