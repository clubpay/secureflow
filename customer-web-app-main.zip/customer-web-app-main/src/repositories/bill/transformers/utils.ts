/* eslint-disable max-lines */
import {
    ColorEnum,
    ILayout,
    IRestaurant,
    SplitModeTypeEnum,
    StyleEnum,
} from '@clubpay/customer-common-module/src/repository/vendor';
import { shouldCommafy } from '@clubpay/customer-common-module/src/utility/k_currency';
import {
    IKeyValue,
    IKeyValueOrder2,
    IPaymentDetails,
    IPaymentPartyView,
    IPromoCode,
    IExplodedItemView,
    IOrderItem,
    IOrderItemView,
    IBill,
    IPaymentParty,
    IPaymentSplit,
    IPaymentStatusRes,
    IPaymentStatus,
    ICampaign,
    IExplodedItem,
    StatusBillNumber,
    IParsePaymentDetailsOptions,
    IParsePaymentDetailsApplyOrderOptions,
} from '../types';
import { AdditiveCategoryEnum, BillStatusEnum, CampaignVoucherStateEnum } from '../enums';
import { getDefaultBillLayout, getDefaultOrderLayout } from '../defaults';

export const sortKeys = (keys: IKeyValueOrder2[], layout: ILayout[]): IKeyValue[] => {
    return layout.reduce<IKeyValue[]>((a, b, idx) => {
        const items = keys.filter((o) => o.key === b.key);
        if (items.length > 0) {
            a.push(
                ...items.map((o) => ({
                    ...o,
                    layout: b,
                    order: idx,
                })),
            );
        }
        return a;
    }, []);
};

export const filterBillLayout = (layout: ILayout[]): ILayout[] => {
    return layout.map((item) => ({
        ...item,
        style: StyleEnum.BodyMedium,
    }));
};

export const filterOrderLayout = (layout: ILayout[]): ILayout[] => {
    return layout.map((item) => {
        if (item.key === 'def_order_topping') {
            return {
                ...item,
                color: ColorEnum.LowEmphasis,
            };
        }

        return item;
    });
};

export const getCampaignData = (sessionId: string, campaign: ICampaign) => {
    const activeCampaign = campaign?.appliedVouchers[0];

    if (!activeCampaign) {
        return;
    }

    if (sessionId === activeCampaign.partyID) {
        return {
            ...activeCampaign,
            isVoucherOwner: true,
        };
    }

    return {
        ...activeCampaign,
        isVoucherOwner: false,
    };
};

export const checkIsPromoDisabled = (vendor: IRestaurant, details: IPaymentDetails, splitByOtherNotPaid: boolean) => {
    if (!vendor?.config?.disableSplitWithPromo) {
        return false;
    }

    // when another party split the bill
    if (
        details.billSplit?.mode &&
        details.billSplit?.mode !== SplitModeTypeEnum.unknown &&
        !(details.campaignVoucher?.code || details.campaignVoucher?.redeemed)
    ) {
        return true;
    }
    // when the current party split the bill
    if (
        details.yourSplitSettings.billSplit.splitMode &&
        details.yourSplitSettings.billSplit.splitMode !== SplitModeTypeEnum.unknown &&
        !(details.campaignVoucher?.code || details.campaignVoucher?.redeemed)
    ) {
        return true;
    }
    // when another party splitted the bill but has not paid yet
    return splitByOtherNotPaid;
};

export const checkPreventOpeningPromoModalInButtonView = (vendor: IRestaurant, details: IPaymentDetails) => {
    if (!vendor?.config?.disableSplitWithPromo) {
        return false;
    }
    if (
        (details.otherSplitSettings.paymentDone && details.campaignVoucher?.redeemed) ||
        ((details.campaignVoucher?.code || details.campaignVoucher?.redeemed) &&
            !details.campaignVoucher.isVoucherOwner)
    ) {
        return true;
    }
    return false;
};

export const getPromoConditions = (
    vendor: IRestaurant | undefined,
    details: IPaymentDetails,
): IPromoCode | undefined => {
    if (!vendor || !vendor.config?.disableSplitWithPromo) {
        return undefined;
    }

    const hasSplit = details.parties?.some(
        (p) => p.billSplit.splitMode && p.billSplit.splitMode !== SplitModeTypeEnum.unknown,
    );
    const splitByOtherNotPaid =
        ((!details.billSplit?.mode || details.billSplit?.mode === SplitModeTypeEnum.unknown) && hasSplit) || false;
    const disableSplitButton =
        (vendor.config.disableSplitWithPromo &&
            (details.campaignVoucher?.redeemed || !!details.campaignVoucher?.code)) ||
        false;
    return {
        isPromoDisabled: checkIsPromoDisabled(vendor, details, splitByOtherNotPaid),
        splitByOtherNotPaid, // toast message texts varies upon this condition
        preventOpenModal: checkPreventOpeningPromoModalInButtonView(vendor, details),
        disableSplitButton,
    };
};

export const getNumberOfPaidItems = (parties: IPaymentPartyView[], index: number, sig: string): number => {
    return parties?.reduce<number>((a, party) => {
        if (party.paymentDone) {
            const tmp = party.billSplit?.items?.find((item) => item.index === index && item.sig === sig);
            if (tmp) {
                a += Number(tmp?.qty);
            }
        }
        return a;
    }, 0);
};

export const decideSplitMode = (
    parties: IPaymentPartyView[],
    sessionId: string,
    orderItems?: IOrderItem[],
): SplitModeTypeEnum => {
    if (parties.length === 0) {
        return SplitModeTypeEnum.empty;
    }
    let paidSplitMode: SplitModeTypeEnum = SplitModeTypeEnum.empty;
    let firstSplitMode: SplitModeTypeEnum = SplitModeTypeEnum.empty;
    parties.forEach((party) => {
        if (!paidSplitMode && party.billSplit?.splitMode && party.paidAt) {
            paidSplitMode = party.billSplit?.splitMode;
        }
        if (!firstSplitMode && party.billSplit?.splitMode && party.id === sessionId) {
            firstSplitMode = party.billSplit?.splitMode;
        }
    });
    // @ts-ignore
    if (paidSplitMode && paidSplitMode !== SplitModeTypeEnum.custom && orderItems?.some((o) => o.updatedAt)) {
        return SplitModeTypeEnum.custom;
    }

    return paidSplitMode || firstSplitMode;
};

export const getYourSplitSettings = (parties: IPaymentPartyView[], sessionId: string): IPaymentPartyView => {
    const party = parties.find((o) => o.id === sessionId);

    if (party) {
        return party;
    }

    return {
        id: sessionId,
        name: '',
        amount: '0',
        amountNumber: 0,
        billSplit: {
            splitMode: SplitModeTypeEnum.unknown,
            items: [],
            share: 0,
            totalShares: 0,
            meta: null,
        },
    };
};

export const getOtherSplitSettings = (parties: IPaymentPartyView[], sessionId: string): IPaymentPartyView => {
    return parties.reduce<IPaymentPartyView>(
        (prevValue, party) => {
            if (!party.paymentDone || party.id === sessionId) {
                return prevValue;
            }
            prevValue.amount += party.amount;
            prevValue.billSplit.totalShares = party.billSplit.totalShares;
            if (party.billSplit.share) {
                prevValue.billSplit.share += party.billSplit.share;
            }
            if (!prevValue.billSplit.items) {
                prevValue.billSplit.items = [];
            }

            party.billSplit.items?.forEach((item) => {
                const idx = prevValue.billSplit.items?.findIndex((o) => o.index === item.index) || -1;
                if (idx > -1 && prevValue.billSplit.items && prevValue.billSplit.items[idx]) {
                    prevValue.billSplit.items[idx].qty += item.qty;
                } else {
                    prevValue.billSplit.items?.push(item);
                }
            });
            prevValue.paymentDone = party.paymentDone;

            return prevValue;
        },
        {
            id: 'other',
            amount: '0',
            amountNumber: 0,
            paymentDone: false,
            paidAt: 0,
            name: '',
            nonQlub: false,
            billSplit: {
                splitMode: SplitModeTypeEnum.unknown,
                items: [],
                share: 0,
                totalShares: 0,
                meta: null,
            },
        },
    );
};

export const checkYourShare = (details: IPaymentDetails, yourSplitSettings: IPaymentPartyView) => {
    if (
        details.billSplit?.mode === SplitModeTypeEnum.byShare &&
        !yourSplitSettings.paymentDone &&
        yourSplitSettings.billSplit.totalShares !== details?.billSplit.totalSharesNumber &&
        yourSplitSettings.billSplit.share &&
        details.billSplit?.shareAmount
    ) {
        const newShare = details.billSplit.shareAmountNumber * yourSplitSettings.billSplit.share;
        details.billNumber.yourShare = newShare;
        details.bill.yourShare = String(newShare);
    }
    return details;
};

export const getRemainingSplitItems = (details: IPaymentDetails) => {
    const allItems = details._orderItems.reduce<{ [key: number]: number }>((a, b, idx) => {
        a[idx] = Number(b.item.qty);
        return a;
    }, {});
    details.otherSplitSettings.billSplit.items?.forEach((item) => {
        const a = allItems[item.index];
        if (a !== undefined) {
            allItems[item.index] -= item._qty;
        }
    });
    return allItems;
};

export const removePaidItemsFromYourSplitSelection = (details: IPaymentDetails) => {
    if (!details?.billSplit || details?.billSplit?.mode !== SplitModeTypeEnum.byItem) {
        return details;
    }

    const unpaidItems = details?.yourSplitSettings?.billSplit.items?.filter((item) => {
        const currentItem = details.explodedItems?.find(
            (eItem) => eItem.sig === item.sig && eItem.index === item.index,
        );

        return currentItem?.paidItemsQty === 0;
    });

    const prevTotalItemCount = Number(details?.yourSplitSettings?.billSplit.items?.length || 0);
    const unpaidItemCount = Number(unpaidItems?.length || 0);

    if (unpaidItemCount !== prevTotalItemCount) {
        details.billSplit.conflict = true;

        const paidItemCount = prevTotalItemCount - unpaidItemCount;

        // use -1 to indicate all items have been paid
        const _paidItemCount = unpaidItemCount === 0 ? -1 : paidItemCount;

        details.billSplit.conflictedItemCount = _paidItemCount;
        details.yourSplitSettings.billSplit.items = unpaidItems;
    }

    return details;
};

export const getCampaignVoucherVisibilityState = (details: IPaymentDetails): CampaignVoucherStateEnum => {
    // if one party split the bill and pay but don't apply the voucher others can't see the voucher box
    if (details.otherSplitSettings.paymentDone && !details.campaignVoucher?.redeemed) {
        return CampaignVoucherStateEnum.Hidden;
    }

    // in case the party splitted the bill and voucher is not applied
    if (details.yourSplitSettings.paymentDone) {
        return CampaignVoucherStateEnum.Hidden;
    }
    // in case bill is fully paid and voucher not applied
    if (details.billNumber.remaining === 0 && !details.campaignVoucher) {
        return CampaignVoucherStateEnum.Hidden;
    }

    // in case another party paid a share and current party chose the share
    if (
        (details.campaignVoucher?.redeemed || details.campaignVoucher?.code) &&
        details.billSplit?.mode &&
        details.billNumber.remaining > 0 &&
        details.otherSplitSettings.paymentDone &&
        details.yourSplitSettings.billSplit.splitMode &&
        details.yourSplitSettings.amount
    ) {
        return CampaignVoucherStateEnum.Used;
    }

    // if voucher is redeemed by other parties or other parties applied the voucher(hasn't redeemed yet)
    if (
        (details.campaignVoucher?.redeemed && !details.campaignVoucher?.isVoucherOwner) ||
        (details.campaignVoucher?.code && !details.campaignVoucher?.isVoucherOwner)
    ) {
        return CampaignVoucherStateEnum.Hidden;
    }

    return CampaignVoucherStateEnum.Visible;
};

export const transformExplodedItems = (
    _orderItems: IOrderItemView[],
    yourSplitSettings: IPaymentPartyView,
    explodedItems?: IExplodedItem[],
    parties?: IPaymentPartyView[],
): IExplodedItemView[] => {
    const itemMap = _orderItems?.reduce<{ [key: string]: IOrderItemView }>((a, b) => {
        a[b.item.sig || ''] = b;
        return a;
    }, {});

    return (
        explodedItems?.map((o) => {
            const hasDecimal = o.qty.includes('.');
            return {
                ...o,
                key: `${o.sig}_${o.index}`,
                item: {
                    ...itemMap[o.sig].item,
                    secondAltValue: o?.adjustedFinalPrice || '',
                    thirdAltValue: o.adjustedFinalNetPrice,
                    isHalfItem: !!hasDecimal,
                },
                selectedItemsQty:
                    (!yourSplitSettings.paymentDone &&
                        yourSplitSettings.billSplit.items?.find((i) => i.index === o.index)?._qty) ||
                    0,
                paidItemsQty: getNumberOfPaidItems(parties || [], o.index, o.sig),
            };
        }) || []
    );
};

export const transformOrderItem = (val?: Record<string, string>) => {
    if (!val) {
        return undefined;
    }

    return Object.entries(val || {}).reduce<Record<string, string>>((a, [k, v]) => {
        a[k.substring(0, 2).toLowerCase()] = v;
        return a;
    }, {});
};

export const getItemsSelectedByYou = (details: IPaymentDetails) => {
    if (!details.billSplit || details.billSplit?.mode !== SplitModeTypeEnum.byItem) {
        return undefined;
    }

    const itemsSelectedByYou = details?.explodedItems?.filter((eItem) => {
        const currentItemIdx = details?.yourSplitSettings?.billSplit?.items?.findIndex(
            (yourItem) => yourItem.sig === eItem.sig && yourItem.index === eItem.index,
        );

        return currentItemIdx !== -1;
    });

    return itemsSelectedByYou;
};

export const getPaidItems = (details: IPaymentDetails) => {
    if (!details?.billSplit || details?.billSplit?.mode !== SplitModeTypeEnum.byItem) {
        return undefined;
    }

    const paidItems = details?.explodedItems?.filter((item) => item.paidItemsQty !== 0);

    return new Map(paidItems?.map((item) => [item.key, item]));
};

export const getCurrencyFormat = (currency: string, currencyPrecision: number) => {
    return {
        cs: currency,
        cc: currency?.toLocaleLowerCase(),
        currencyPrecision,
        currencyCommaSeparator: (shouldCommafy(currency) ? 'enable' : 'disable') as 'enable' | 'disable',
    };
};

export const getBillInNumber = (bill: IBill, yourShare: number) => {
    return {
        billAmount: Number(bill?.billAmount || '0'),
        paid: Number(bill?.paid || '0'),
        payableAmount: Number(bill?.payableAmount || '0'),
        tax: Number(bill?.tax || '0'),
        vat: Number(bill?.vat || '0'),
        qlubDiscount: Number(bill?.qlubDiscount || '0'),
        remaining: Number(bill?.remaining || '0'),
        commission: Number(
            bill?.additives?.reduce(
                (a, b) => a + (b.category === AdditiveCategoryEnum.Commision ? +b.value || 0 : 0),
                0,
            ) || 0,
        ),
        remainingCommission: Number(bill?.remainingCommission || '0'),
        yourShare,
        yourShareCents: Number((yourShare * 100).toFixed(0)),
        yourCommission: Number(bill?.yourCommission || '0'),
        subTotal: Number(bill?.billAmount || '0'),
        total: Number(bill?.payableAmount || '0'),
        voucherAmount: Number(bill?.additives?.find((a) => a.key === 'qlub-voucher')?.value) || 0,
        qlubLoyaltyDiscount: Number(
            bill?.additives?.find((additive) => additive.key.includes('qlub_loyalty_discount'))?.value || '0',
        ),
    };
};

export const transformBillItems = (bill: IBill) => {
    return [
        {
            key: 'def_qlubDiscount',
            value: bill.qlubDiscount,
        },
        {
            key: 'def_paid',
            value: bill.paid,
        },
        {
            key: 'def_remaining',
            value: bill.remaining,
        },
        {
            key: 'def_subTotal',
            value: bill.billAmount,
        },
        {
            key: 'def_tax',
            value: bill.tax,
        },
        {
            key: 'def_vat',
            value: bill.vat,
        },
        {
            key: 'def_total',
            value: bill.payableAmount,
        },
        {
            key: 'def_yourShare',
            value: bill.yourShare,
        },
        {
            key: 'def_billAmount',
            value: bill.billAmount,
        },
        {
            key: 'def_payableAmount',
            value: bill.payableAmount,
        },
        ...(bill.additives?.map((item) => ({
            key: item.key,
            value: item.amount || item.value,
            title: item.title,
        })) || []),
    ];
};

export const transformOrderItems = (orderItems: IOrderItem[] | undefined, options?: IParsePaymentDetailsOptions) => {
    return (
        orderItems?.map((item) => ({
            item: {
                id: item.id,
                key: 'def_order',
                title: item.title,
                titleTrans: transformOrderItem(item.titleTrans),
                value: Number(item.finalPrice || item.subTotal || '0')
                    ? item.finalPrice || item.subTotal
                    : item.unitPrice,
                altValue: Number(item.finalPrice || item.subTotal || '0') ? item.unitPrice : undefined,
                secondAltValue: item.finalUnitPrice,
                qty: item.qty,
                updatedAt: item.updatedAt,
                sig: item.sig,
            },
            items: [
                ...(item.toppings?.map((innerItem) => ({
                    key: 'def_order_topping',
                    title: innerItem.title,
                    titleTrans: transformOrderItem(innerItem.titleTrans),
                    value: innerItem.finalPrice || innerItem.subTotal,
                    altValue: innerItem.unitPrice,
                    qty: innerItem.qty,
                    updatedAt: innerItem.updatedAt,
                })) || []),
                ...(item.additives?.map((innerItem) => ({
                    key: innerItem.key || 'def_additives',
                    title: innerItem.title,
                    value: innerItem.value || innerItem.amount,
                    category: innerItem.category,
                })) || []),
            ],
        })) || []
    );
};

export const transformParties = (parties: IPaymentParty[] | undefined) => {
    return (
        parties?.map((party) => ({
            ...party,
            amountNumber: Number(party.amount),
            billSplit: {
                ...party?.billSplit,
                share: Number(party.billSplit?.share),
                totalShares: Number(party.billSplit?.totalShares),
                items: party.billSplit?.items?.map((item) => ({
                    ...item,
                    _qty: Number(item.qty),
                })),
            },
        })) || []
    );
};

export const transformBill = (bill: IBill) => {
    return {
        ...bill,
        qlubLoyaltyDiscount:
            bill?.additives?.find((additive) => additive.key.includes('qlub_loyalty_discount'))?.value || '0',
        subTotal: bill?.billAmount || '0',
        total: bill?.payableAmount || '0',
        isDinerFeeEnabled: bill?.additives?.some((additive) => additive.category === AdditiveCategoryEnum.Commision),
    };
};

export const transformBillSplit = (
    billSplit: IPaymentSplit,
    parties: IPaymentPartyView[],
    sessionId: string,
    orderItems: IOrderItem[] | undefined,
) => {
    let paidShares = 0;

    if (billSplit?.mode === SplitModeTypeEnum.byShare) {
        parties.forEach((party) => {
            if (party.paymentDone) {
                paidShares += Number(party?.billSplit?.share || 0);
            }
        });
    }

    return {
        ...billSplit,
        totalSharesNumber: Number(billSplit.totalShares),
        shareAmountNumber: Number(billSplit.shareAmount),
        mode: billSplit.mode || decideSplitMode(parties, sessionId, orderItems),
        paidShares,
    };
};

export const getActiveCampaign = (res: IPaymentStatusRes) => res?.campaign?.appliedVouchers?.[0];

export const getTableName = (res: IPaymentStatusRes) => res.bill.tableName.replace('Table', '');

export const getLoyaltyRedemption = (res: IPaymentStatusRes) => res?.loyalty?.redemptions?.[0];

export const checkLoyaltyFullPaymentAvailability = (data: IPaymentStatus) =>
    data?.loyaltyRedemption?.status === 'ok' &&
    ((data.bill.status === BillStatusEnum.FULLY_PAID &&
        Number(data.bill.totalAmount).toFixed(2) === Number(data.amount).toFixed(2)) ||
        (data.bill.status === BillStatusEnum.FULLY_PAID && !data.record?.total) ||
        (data.bill.status === BillStatusEnum.PARTIALLY_PAID && !data.record?.total));

export const getOrderLayout = (cc: string, itemLayout?: ILayout[]) => {
    // TODO: Fix this. There's no county with code 'en', so getDefaultOrderLayout will return the default value when cc isn't specified.
    return itemLayout && itemLayout.length > 0 ? filterOrderLayout(itemLayout) : getDefaultOrderLayout(cc || 'en');
};

export const getBillLayout = (cc: string, billLayout?: ILayout[]) => {
    // TODO: Fix this. There's no county with code 'en', so getDefaultBillLayout will always return the default value when cc isn't specified
    return billLayout && billLayout.length > 0 ? filterBillLayout(billLayout) : getDefaultBillLayout(cc || 'en');
};

export const applyOrderLayout = (_orderItems: IOrderItemView[], options: IParsePaymentDetailsApplyOrderOptions) => {
    const orderLayout = getOrderLayout(options.cc || 'en', options.itemLayout);
    const defOrderLayout = orderLayout.find((o) => o.key === 'def_order');

    return _orderItems.map((o) => {
        return {
            ...o,
            item: {
                ...o.item,
                key: 'def_order',
                layout: defOrderLayout,
                ...(defOrderLayout?.ignoreFinalValue
                    ? {
                          value: o.item.altValue
                              ? (Number(o.item.altValue) * Number(o.item.qty)).toFixed(options.currencyPrecision ?? 2)
                              : o.item.value,
                      }
                    : {}),
            },
            items: sortKeys(o.items, orderLayout),
        };
    });
};

export const getIsPartiallyPaid = (details: IPaymentDetails) => {
    return (
        !!details.billSplit?.mode &&
        details?.billNumber.remaining > 0 &&
        details.billNumber.total > details.billNumber.remaining
    );
};

export const getNumberedStatusBill = (data: IPaymentStatus): StatusBillNumber => ({
    amount: Number(data.amount || '0'),
    remainingAmount: Number(data.bill.remainingAmount || '0'),
    totalAmount: Number(data.bill.totalAmount || '0'),
    voucherAmount: Number((data?.activeCampaign?.redeemed === true && data?.activeCampaign?.amount) || '0'),
});
