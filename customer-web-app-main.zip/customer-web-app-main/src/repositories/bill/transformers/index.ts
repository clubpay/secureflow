import { getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import { extractBillTax, extractLoyaltyPaidAmount } from '@clubpay/loyalty/dist/transformers/bill';
import { clone } from 'lodash';
import {
    IPaymentDetails,
    IPaymentDetailsRes,
    IPaymentPartyView,
    IPaymentStatusRes,
    IPaymentStatus,
    IPaymentReceiptRes,
    IPaymentReceipt,
    ISetAmountRequestPayload,
    ISetAmountStringRequestPayload,
    IParsePaymentDetailsOptions,
} from '../types';
import {
    checkLoyaltyFullPaymentAvailability,
    getActiveCampaign,
    getBillInNumber,
    getCampaignData,
    getCampaignVoucherVisibilityState,
    getCurrencyFormat,
    transformExplodedItems,
    getItemsSelectedByYou,
    getLoyaltyRedemption,
    getOtherSplitSettings,
    getPromoConditions,
    getTableName,
    getYourSplitSettings,
    removePaidItemsFromYourSplitSelection,
    sortKeys,
    transformBill,
    transformBillItems,
    transformBillSplit,
    transformOrderItems,
    transformParties,
    getBillLayout,
    applyOrderLayout,
    getPaidItems,
    getIsPartiallyPaid,
    getNumberedStatusBill,
} from './utils';

const transformKeysForPaymentDetails = (res: IPaymentDetailsRes): IPaymentDetails => {
    const sessionId = getSession();
    const parties: IPaymentPartyView[] = transformParties(res.parties);
    const yourSplitSettings = getYourSplitSettings(parties, sessionId);

    let yourShare = Number(res.bill?.yourShare || '0');

    if (yourSplitSettings.loyalty?.status === 'ok' && yourSplitSettings.amountNumber) {
        yourShare += Number(yourSplitSettings.loyalty?.amount ?? 0);
    }

    const transformable: IPaymentDetails = clone(res) as unknown as IPaymentDetails;

    transformable._orderItems = transformOrderItems(res.orderItems);
    transformable._billItems = transformBillItems(res.bill);
    transformable.currencyFormat = getCurrencyFormat(res.currency, res.currencyPrecision);
    transformable.bill = transformBill(res.bill);
    transformable.billNumber = getBillInNumber(res.bill, yourShare);
    transformable.billSplit = transformBillSplit(res.billSplit, parties, sessionId, res.orderItems);
    transformable.billLoyalty = {
        tax: extractBillTax(res.bill),
        paid: extractLoyaltyPaidAmount(parties as any),
    };

    transformable.parties = parties;
    transformable.yourSplitSettings = yourSplitSettings;
    transformable.otherSplitSettings = getOtherSplitSettings(parties, sessionId);
    transformable.campaignVoucherVisibilityState = getCampaignVoucherVisibilityState(transformable);
    transformable.explodedItems = transformExplodedItems(
        transformable._orderItems,
        yourSplitSettings,
        res.explodedItems,
        parties,
    );

    transformable.itemsSelectedByYou = getItemsSelectedByYou(transformable);
    transformable.paidItems = getPaidItems(transformable);
    transformable.isPartiallyPaid = getIsPartiallyPaid(transformable);
    transformable.campaignVoucher = getCampaignData(sessionId, res.campaign);

    return removePaidItemsFromYourSplitSelection(transformable);
};

export const parsePaymentDetails = (res: IPaymentDetailsRes, options: IParsePaymentDetailsOptions): IPaymentDetails => {
    const countryCode = options?.vendor?.country?.code || 'en';

    const transformable = transformKeysForPaymentDetails(res);

    const billLayout = getBillLayout(countryCode, options?.vendor?.posVendor?.billLayout);
    transformable._billItems = sortKeys(transformable._billItems, billLayout);

    transformable._orderItems = applyOrderLayout(transformable._orderItems, {
        cc: countryCode,
        itemLayout: options?.vendor?.posVendor?.itemLayout,
        currencyPrecision: res.currencyPrecision,
    });

    if (options?.vendor?.posVendor?.billLayout || options?.vendor?.posVendor?.itemLayout) {
        transformable._layoutInit = true;
    }

    transformable.promoConditions = getPromoConditions(options?.vendor, transformable);

    return transformable;
};

const transformKeysForPaymentReceipt = (res: IPaymentReceiptRes): IPaymentReceipt => {
    const transformable: IPaymentReceipt = clone(res) as unknown as IPaymentReceipt;

    transformable.bill = transformBill(res.bill);
    transformable.currencyFormat = getCurrencyFormat(res.currency, res.currencyPrecision);
    transformable.billNumber = getBillInNumber(res.bill, Number(res.bill?.yourShare || '0'));
    transformable._billItems = transformBillItems(res.bill);
    transformable._orderItems = transformOrderItems(res.orderItems);

    return transformable;
};

export const parsePaymentReceipt = (res: IPaymentReceiptRes, options: IParsePaymentDetailsOptions): IPaymentReceipt => {
    const countryCode = options?.vendor?.country?.code || 'en';
    const transformable = transformKeysForPaymentReceipt(res);

    const billLayout = getBillLayout(countryCode, options?.vendor?.posVendor?.billLayout);
    transformable._billItems = sortKeys(transformable._billItems, billLayout);

    transformable.timestamp = res.timestamp * 1000;
    transformable._orderItems = applyOrderLayout(transformable._orderItems, {
        cc: countryCode,
        itemLayout: options?.vendor?.posVendor?.itemLayout,
        currencyPrecision: res.currencyPrecision,
    });

    return transformable;
};

export const parsePaymentReport = (res: IPaymentReceiptRes, options: IParsePaymentDetailsOptions): IPaymentDetails => {
    const countryCode = options?.vendor?.country?.code || 'en';
    const transformable = transformKeysForPaymentReceipt(res);

    const billLayout = getBillLayout(countryCode, options?.vendor?.posVendor?.billLayout);
    transformable._billItems = sortKeys(transformable._billItems, billLayout);

    transformable.timestamp = res.timestamp * 1000;
    transformable._orderItems = applyOrderLayout(transformable._orderItems, {
        cc: countryCode,
        itemLayout: options?.vendor?.posVendor?.itemLayout,
        currencyPrecision: res.currencyPrecision,
    });

    const remaining = Number(res?.bill.remaining);
    const total = Number(res?.bill?.total);

    return {
        ...transformable,
        billLoyalty: { paid: 0, tax: 0 },
        restaurantUnique: options?.vendor?.unique || '',
        diningSessionID: options?.dsi || '',
        isPartiallyPaid: !!res.splitDetails?.mode && remaining > 0 && total > remaining,
        yourSplitSettings: {
            amount: res.bill.yourShare,
            amountNumber: Number(res.bill.yourShare),
            billSplit: {
                splitMode: res.splitDetails.mode,
                share: Number(res.splitDetails.shares.share),
                totalShares: Number(res.splitDetails.shares.total),
            },
            name: '',
            id: '',
        },
        otherSplitSettings: {
            amount: res.bill.yourShare,
            amountNumber: Number(res.bill.yourShare),
            billSplit: {
                splitMode: res.splitDetails.mode,
                share: Number(res.splitDetails.shares.share),
                totalShares: Number(res.splitDetails.shares.total),
            },
            name: '',
            id: '',
        },
    };
};

export const parsePaymentStatus = (res: IPaymentStatusRes): IPaymentStatus => {
    const transformable: IPaymentStatus = clone(res);

    transformable.activeCampaign = getActiveCampaign(res);
    transformable.tableName = getTableName(res);
    transformable.loyaltyRedemption = getLoyaltyRedemption(res);
    transformable.hasLoyaltyFullPayment = checkLoyaltyFullPaymentAvailability(transformable);
    transformable.billNumber = getNumberedStatusBill(transformable);

    return transformable;
};

export const transformSetAmountPayload = (payload: ISetAmountRequestPayload): ISetAmountStringRequestPayload => {
    const transformable: ISetAmountStringRequestPayload = {
        amount: payload.amount,
        diningSessionID: payload.diningSessionID,
        id: payload.id,
        name: payload.name,
        phoneNumber: payload.phoneNumber ?? '',
        split: {
            mode: payload.splitMode,
            itemsToPay: [],
            shareToPay: {},
            meta: payload.meta ?? {},
        },
        checkExplodedItems: true,
    };

    if (payload.share !== undefined) {
        transformable.split.shareToPay.share = String(payload.share);
    }

    if (payload.totalShares !== undefined) {
        transformable.split.shareToPay.total = String(payload.totalShares);
    }

    if (payload.items !== undefined) {
        transformable.split.itemsToPay = payload.items.map((item) => ({
            id: item.id,
            index: item.index,
            qty: String(item.qty),
            sig: item.sig,
        }));
    }

    return transformable;
};
