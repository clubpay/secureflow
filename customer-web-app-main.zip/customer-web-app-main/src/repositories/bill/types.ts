import { ILayout, IRestaurant, SplitModeTypeEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { IKeyValueOrder } from '@qlub-dev/qlub-kit/dist/types/InvoiceItemTypes';
import { IAppliedDiscount, ILoyalty } from '@clubpay/loyalty/dist/types';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import {
    AdditiveCategoryEnum,
    BillStatusEnum,
    CampaignVoucherStateEnum,
    FetchModeEnum,
    GatewayPaymentMethod,
    RecordStatusEnum,
} from './enums';

export interface IGetPaymentDetailPayload {
    restaurantUnique: string;
    tableID: string;
    id: string;
    diningSessionID: string;
    forceFresh: boolean;
    cc: string;
    f1?: string;
    f2?: string;
    hash?: string;
    jwt?: string;
    fetchMode?: FetchModeEnum;
    optionalDinerFee?: 'enable' | 'disable';
    payUrl?: string;
}

export interface IGetReceiptPayload {
    dsi: string;
    pri: string;
}

export interface IGetLayoutConfig {
    cc: string;
    vendor?: IRestaurant;
}

export interface ISetAmountConfig extends IGetLayoutConfig {
    draft?: boolean;
}

export interface IGetPaymentDetailConfig extends IGetLayoutConfig {
    ignoreCache?: boolean;
    qsr?: boolean;
    debounce?: boolean;
}

export interface IGetPaymentReportConfig extends IGetLayoutConfig {
    ignoreCache?: boolean;
    qsr?: boolean;
    debounce?: boolean;
    dsi?: string;
}

export interface IKeyValue {
    key: string;
    value: any;
    layout?: ILayout;
    order?: number;
    title?: string;
    titleTrans?: Record<string, string>;
    id?: string;
    sig?: string;
}

export interface IKeyValueOrder2 extends IKeyValueOrder {
    sig?: string;
    category?: AdditiveCategoryEnum;
}

export interface IAdditiveView {
    key: string;
    amount: string;
    value: string;
    valueType: string;
    category: AdditiveCategoryEnum;
    title: string;
}

export interface IToppingView {
    qty: string;
    title: string;
    titleTrans?: Record<string, string>;
    unitPrice: string;
    updatedAt: number;
    subTotal?: string;
    finalPrice?: string;
}

export interface IOrderItem {
    id: string;
    qty: string;
    title: string;
    titleTrans?: Record<string, string>;
    unitPrice: string;
    updatedAt: number;
    subTotal?: string;
    finalPrice?: string;
    finalUnitPrice?: string;
    toppings?: Array<IToppingView>;
    additives?: Array<IAdditiveView>;
    sig: string;
}

export interface ISetAmountRequestPayload {
    amount?: string;
    diningSessionID: string;
    id: string;
    name: string;
    splitMode?: string;
    share?: number;
    totalShares?: number;
    items?: IItemToPay[];
    phoneNumber?: string;
    meta?: any;
}

export interface ISetAmountStringRequestPayload {
    amount?: string;
    diningSessionID: string;
    id: string;
    name: string;
    split: {
        mode?: string;
        meta: any;
        itemsToPay: IItemToPay[];
        shareToPay: {
            share?: string;
            total?: string;
        };
    };
    phoneNumber?: string;
    checkExplodedItems?: boolean;
}

export interface IPaidItem {
    id?: string;
    index: number;
    qty: number;
    sig: string;
}

export interface IItemToPay {
    id?: string;
    index: number;
    qty: string;
    sig: string;
}

export interface IItemToPayView extends IItemToPay {
    _qty: number;
}

export interface IPartySplit {
    items?: Array<IItemToPay>;
    meta?: any;
    splitMode: SplitModeTypeEnum;
    share: string;
    totalShares: string;
}

export interface IParty {
    amount: string;
    id: string;
    name: string;
    paymentDone?: boolean;
    paidAt?: number;
    nonQlub?: boolean;
    loyalty?: ILoyalty;
}

export interface IPaymentParty extends IParty {
    billSplit: IPartySplit;
}

export interface IPaymentPartyView extends IParty {
    amountNumber: number;
    billSplit: IPartySplitView;
}

export interface IPartySplitView {
    items?: Array<IItemToPayView>;
    meta?: any;
    splitMode: SplitModeTypeEnum;
    share: number;
    totalShares: number;
}

export interface IBill {
    id: string;
    qlubDiscount: string;
    qlubLoyaltyDiscount: string;
    paid: string;
    remaining: string;
    remainingCommission: string;
    subTotal: string;
    tax: string;
    total: string;
    vat: string;
    yourShare: string;
    yourCommission: string;
    additives?: Array<IAdditiveView>;
    billAmount?: string;
    payableAmount?: string;
    isDinerFeeEnabled?: boolean;
    revenueBuckets: string;
    covers: number;
    updatedAt: string;
    optionalDinerFee: string;
    yourOptionalDinerFee: string;
}

export interface IPaymentDetailsBillNumber {
    qlubDiscount: number;
    paid: number;
    remaining: number;
    subTotal: number;
    tax: number;
    total: number;
    vat: number;
    commission: number;
    yourShare: number;
    yourShareCents: number;
    yourCommission: number;
    remainingCommission: number;
    billAmount: number;
    payableAmount: number;
    voucherAmount: number;
    qlubLoyaltyDiscount: number;
}

export interface IOrderItemView {
    item: IKeyValueOrder2;
    items: IKeyValueOrder2[];
}

export interface IPaymentSplit {
    availableModes: Array<SplitModeTypeEnum>;
    mode: SplitModeTypeEnum;
    totalShares: string;
    shareAmount: string;
}

export interface IShareToPay {
    indices: number[];
    total: string;
    share: string;
}

export interface ISplitDetails {
    items: IReceiptExplodedItem[];
    shares: IShareToPay;
    mode: SplitModeTypeEnum;
}

export interface IVoucher extends IVoucherRes {
    partyID: string;
    isVoucherOwner?: boolean;
}

export interface IExplodedItem {
    index: number;
    price: string;
    adjustedFinalPrice?: string;
    adjustedFinalNetPrice?: string;
    adjustedUnitNetPrice?: string;
    qty: string;
    sig: string;
}

export interface IReceiptExplodedItem {
    id: string;
    index: number;
    qty: number;
    sig: string;
}

export interface IKnetMetaData {
    knet_payment_id: string;
    knet_result: string;
    knet_transaction_id: string;
}

export interface ICampaign {
    appliedVouchers: IVoucherRes[];
}

export interface IPaymentDetailsRes {
    bill: IBill;
    billSplit: IPaymentSplit;
    currency: string;
    currencyPrecision: number;
    orderItems?: IOrderItem[];
    parties?: IPaymentParty[];
    restaurantUnique: string;
    tableID: string;
    diningSessionID: string;
    tableName: string;
    jwt?: string;
    JWTToken?: string;
    campaign: ICampaign;
    explodedItems?: IExplodedItem[];
    knetMetaData?: IKnetMetaData;
    transactionTime?: string;
}

export interface IPaymentReceiptRes {
    id: string;
    paymentRecordID: number;
    tableID: string;
    tableName: string;
    orderID: string;
    currency: string;
    currencyPrecision: number;
    timestamp: number;
    timezone: string;
    yourTip: string;
    yourTotal: string;
    orderItems: IOrderItem[];
    bill: IBill;
    card: ICard;
    loyalty?: ILoyalty;
    exchangeDetails: IExchangeData;
    splitDetails: ISplitDetails;
}

export interface IPaymentReceipt extends IPaymentReceiptRes {
    currencyFormat: CurrencyFormat;
    billNumber: IPaymentDetailsBillNumber;
    _billItems: IKeyValue[];
    _orderItems: IOrderItemView[];
}

export interface IPaymentSplitView extends IPaymentSplit {
    conflictedItemCount?: number;
    totalSharesNumber: number;
    shareAmountNumber: number;
    paidShares: number;
    conflict?: boolean;
}

export interface IPromoCode {
    isPromoDisabled: boolean;
    splitByOtherNotPaid: boolean;
    preventOpenModal: boolean;
    disableSplitButton: boolean;
}

export interface ILoyaltyPayment {
    tax: number;
    paid: number;
}

export interface IExplodedItemView extends IExplodedItem {
    key: string;
    item?: IKeyValueOrder2 | IKeyValue;
    selectedItemsQty?: number;
    paidItemsQty?: number;
}

export interface IStaff {
    id: string;
    name: string;
}

interface IKnetMedataData {
    knet_payment_id: string;
    knet_result: string;
    knet_transaction_id: string;
}

interface ICard {
    brand?: string;
    last4?: string;
}

export interface IPaymentDetails {
    _billItems: IKeyValue[];
    _orderItems: IOrderItemView[];
    _layoutInit?: boolean;
    bill: IBill;
    billNumber: IPaymentDetailsBillNumber;
    billSplit?: IPaymentSplitView;
    billLoyalty: ILoyaltyPayment;
    restaurantUnique: string;
    tableID: string;
    parties?: IPaymentPartyView[];
    currency: string;
    diningSessionID: string;
    currencyPrecision: number;
    tableName?: string;
    yourSplitSettings: IPaymentPartyView;
    otherSplitSettings: IPaymentPartyView;
    jwt?: string;
    tablePreferredName?: string;
    campaignVoucher?: IVoucher;
    campaignVoucherVisibilityState?: CampaignVoucherStateEnum;
    promoConditions?: IPromoCode;
    explodedItems?: IExplodedItemView[];
    staff?: IStaff;
    knetMetaData?: IKnetMedataData;
    transactionTime?: Date | string;
    itemsSelectedByYou?: IExplodedItemView[];
    card?: ICard;
    currencyFormat: CurrencyFormat;
    paidItems?: Map<string, IExplodedItemView>;
    isPartiallyPaid: boolean;
}

export interface ISetAmountRes {
    paymentDetails: IPaymentDetailsRes;
    error?: { items: string };
}

export interface IRateRequestReq {
    diningSessionID: string;
    id: string;
    rate: number;
    reference: string;
}

export interface IEmailReceiptRequestPeq {
    diningSessionID: string;
    email: string;
    id: string;
    reference: string;
    lang: string;
    countryCode: string;
}

export interface IEmailReceiptRequestNewReq {
    countryCode: string;
    diningSessionID: string;
    email?: string;
    phone?: string;
    id: string;
    lang: string;
    reference: string;
    timezone: string;
}

export interface IDownloadReceiptRequest {
    countryCode: string;
    diningSessionID: string;
    id: string;
    lang: string;
    reference: string;
    timezone: string;
}

export interface IEmailReceiptRes {
    status?: string;
    meta: { como: string };
    message: string;
    knetMetaData?: IKnetMedataData;
    transactionDateTime?: Date | string;
}

export interface IPaymentStatusReq {
    diningSessionID: string;
    reference: string;
    id: string;
    force?: boolean;
}

interface IExchangeData {
    paid_amount: string;
    currency: string;
}

export interface IPaymentRecord {
    id: string;
    billAmount: string;
    tipAmount: string;
    total: string;
    createdAt: number;
    updatedAt: number;
    gatewayVendor: string;
    gatewayPaymentMethod?: GatewayPaymentMethod;
    status: RecordStatusEnum;
    accepted: boolean;
    reference: string;
    customerCommission: string;
    knetMetaData?: IKnetMedataData;
    exchangeData?: IExchangeData;
    transactionDateTime?: string;
    issuerCountry?: string;
    threeDS?: boolean;
    cardBrand?: string;
}

export interface IPaymentStatusRes {
    amount: string;
    currency: string;
    bill: {
        currency: string;
        orderID: string;
        remainingAmount: string;
        status: BillStatusEnum;
        tableID: string;
        tableName: string;
        totalAmount: string;
    };
    loyalty?: {
        redemptions?: ILoyalty[];
        earnings?: ILoyalty[];
        discounts?: IAppliedDiscount[];
    };
    campaign: {
        appliedVouchers?: IVoucherRes[];
    };
    record?: IPaymentRecord;
    verified: boolean;
    gatewayVendor?: string;
}

export interface IPaymentStatus extends IPaymentStatusRes {
    activeCampaign?: IVoucher;
    tableName?: string;
    loyaltyRedemption?: ILoyalty;
    hasLoyaltyFullPayment?: boolean;
    billNumber?: StatusBillNumber;
}

export interface IUpdatePaymentDetails {
    details?: IPaymentDetailsRes;
    yourTotal: string;
}

export interface IAddPartReq {
    country: string;
    restaurantUnique: string;
    diningSessionID: string;
    id: string;
    jwt?: string;
}

export interface IPaymentDetailsCache {
    time: number;
    details: IPaymentDetails;
    force: boolean;
}

export interface ILockPaymentReq {
    diningSessionID: string;
    id: string;
    gatewayID: string;
}

export interface IPaymentLockRes {
    sessions: Array<{
        reference: string;
        status: string;
        timestamp: number;
        tipAmount: string;
        billAmount: string;
        gatewayVendor: string;
    }>;
    state: 'acquired' | 'failedPartial' | 'failedFull' | 'duplicatePaidItems' | 'orderClosed';
}

export interface IUnlockPaymentReq {
    diningSessionID: string;
    id: string;
    gatewayID: string;
}

export interface IPaymentUnlockRes {
    result: boolean;
}

export interface IVoucherValidateReq {
    code: string | null;
    diningSessionID: string;
    id: string;
}

export interface IPreferredCurrency {
    code: string;
    forex: number;
    tempCalculatedAmountWithoutTip: number; // this will be removed with exact implementation
}

export interface ICalculateCommissionReq {
    country: string;
    restaurantUnique: string;
    dsi: string;
    id: string;
    amount: number;
}

export interface ICalculateCommissionRes {
    customerCommission: string;
}

export interface IToggleOptionalDinerFeeReq {
    id: string;
    diningSessionID: string;
    useOptionalDinerFee: boolean;
}

export interface IToggleOptionalDinerFeeRes {
    optionalDinerFee: string;
}

interface IDraftSplit {
    mode: SplitModeTypeEnum;
    itemsToPay?: IItemToPay[];
    shareToPay: {
        indices: string[];
        total: string;
        share: string;
        ''?: any;
    };
}

export interface ISetDraftAmountPayload {
    id: string; // party id (aka session id)
    name: string;
    phoneNumber: string;
    diningSessionID: string;
    amount?: string;
    split: IDraftSplit;
    checkExplodedItems: boolean;
}

export interface ISetTipPayload {
    id: string;
    diningSessionID: string;
    amount: string;
}

export interface ISetTipRes {
    success: boolean;
}

export enum CampaignDiscountTypeEnum {
    VENTURE = 'VENTURE_VOUCHER',
    CORPORATE = 'CORPORATE_VOUCHER',
    NONE = '',
}

export interface IVoucherRes {
    code: string;
    discountType: CampaignDiscountTypeEnum;
    partyID: string;
    redeemed: boolean;
    amount: string;
}

export interface StatusBillNumber {
    amount: number;
    remainingAmount: number;
    totalAmount: number;
    voucherAmount?: number;
}

export interface IParsePaymentDetailsOptions {
    vendor?: IRestaurant;
    dsi?: string;
}

export interface IParsePaymentDetailsApplyOrderOptions {
    cc: string;
    itemLayout?: ILayout[];
    currencyPrecision?: number;
}
