import {
    ColorEnum,
    ConditionEnum,
    IconEnum,
    ILayout,
    StyleEnum,
} from '@clubpay/customer-common-module/src/repository/vendor';

export const getDefaultBillLayout = (cc: string): ILayout[] => {
    switch (cc) {
        default:
        case 'ae':
            return [
                {
                    key: 'def_subTotal',
                    format: `{csf}{0}`,
                    style: StyleEnum.BodyMedium,
                    vcond: ConditionEnum.GTD,
                },
                {
                    key: 'def_qlubDiscount',
                    format: `{csf}{0}`,
                    color: ColorEnum.Green,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Discount,
                    vcond: ConditionEnum.GT,
                },
                {
                    key: 'def_total',
                    format: `{csf}{0}`,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Dollar,
                },
            ];
        case 'sa':
            return [
                {
                    key: 'def_subTotal',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    vcond: ConditionEnum.GTD,
                },
                {
                    key: 'def_qlubDiscount',
                    format: `{csf} {0}`,
                    color: ColorEnum.Green,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Discount,
                    vcond: ConditionEnum.GT,
                },
                {
                    key: 'def_total',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Rial,
                },
            ];
        case 'in':
            return [
                {
                    key: 'def_subTotal',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    vcond: ConditionEnum.GTD,
                },
                {
                    key: 'def_vat',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Bill,
                    vcond: ConditionEnum.GT,
                },
                {
                    key: 'def_qlubDiscount',
                    format: `{csf} {0}`,
                    color: ColorEnum.Green,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Discount,
                    vcond: ConditionEnum.GT,
                },
                {
                    key: 'def_total',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Dollar,
                },
            ];
        case 'sg':
        case 'br':
        case 'tr':
            return [
                {
                    key: 'def_qlubDiscount',
                    format: `{csf} {0}`,
                    color: ColorEnum.Green,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Discount,
                    vcond: ConditionEnum.GT,
                },
                {
                    key: 'def_total',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Dollar,
                },
            ];
        case 'jp':
            return [
                {
                    key: 'def_subTotal',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Bill,
                },
                {
                    key: 'def_vat',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Bill,
                },
                {
                    key: 'def_qlubDiscount',
                    format: `{csf} {0}`,
                    color: ColorEnum.Green,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Discount,
                    vcond: ConditionEnum.GT,
                },
                {
                    key: 'def_total',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Yen,
                },
            ];
        case 'au':
            return [
                {
                    key: 'sum_inclusive',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Bill,
                },
                {
                    key: 'tax_exclusive',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                },
                {
                    key: 'tax_inclusive',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    vcond: ConditionEnum.GT,
                },
                {
                    key: 'discount_inclusive',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    vcond: ConditionEnum.NE,
                },
                {
                    key: 'fee_inclusive',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    vcond: ConditionEnum.NE,
                },
                {
                    key: 'discount_exclusive',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    vcond: ConditionEnum.NE,
                },
                {
                    key: 'def_qlubDiscount',
                    format: `{csf} {0}`,
                    color: ColorEnum.Green,
                    style: StyleEnum.BodyMedium,
                    icon: IconEnum.Discount,
                    vcond: ConditionEnum.GT,
                },
                {
                    key: 'def_total',
                    format: `{csf} {0}`,
                    style: StyleEnum.TitleMedium,
                    icon: IconEnum.Dollar,
                },
                {
                    key: 'def_vat',
                    format: `{csf} {0}`,
                    style: StyleEnum.BodyMedium,
                    locales: [
                        {
                            locale: 'en',
                            value: 'GST',
                        },
                    ],
                },
            ];
    }
};

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export const getDefaultOrderLayout = (cc: string): ILayout[] => {
    switch (cc) {
        default:
        case 'ae':
        case 'sa':
            return [
                {
                    key: 'def_order',
                    format: `{csf}{0}`,
                    style: StyleEnum.BodyMedium,
                    color: ColorEnum.HighEmphasis,
                    hideAltValue: true,
                },
                {
                    key: 'def_order_topping',
                    format: `{csf}{0}`,
                    style: StyleEnum.BodyMedium,
                    color: ColorEnum.LowEmphasis,
                    hideAltValue: true,
                },
            ];
        case 'in':
        case 'sg':
        case 'br':
        case 'tr':
            return [
                {
                    key: 'def_order',
                    format: `{csf}{0}`,
                    style: StyleEnum.BodyMedium,
                    color: ColorEnum.HighEmphasis,
                    hideAltValue: true,
                },
                {
                    key: 'def_order_topping',
                    format: `{cs}{0}`,
                    style: StyleEnum.BodyMedium,
                    color: ColorEnum.LowEmphasis,
                    hideAltValue: true,
                },
            ];
        case 'jp':
            return [
                {
                    key: 'def_order',
                    format: `{csf}{0}`,
                    style: StyleEnum.BodyMedium,
                    color: ColorEnum.HighEmphasis,
                    hideAltValue: true,
                },
                {
                    key: 'def_order_topping',
                    format: `{cs}{0}`,
                    style: StyleEnum.BodyMedium,
                    color: ColorEnum.LowEmphasis,
                    hideAltValue: true,
                },
                {
                    key: 'def_additives',
                    format: `{cs} {0}`,
                    style: StyleEnum.BodySmall,
                    color: ColorEnum.MediumEmphasis,
                    vcond: ConditionEnum.GT,
                    hideAltValue: true,
                },
            ];
        case 'au':
            return [
                {
                    key: 'def_order',
                    format: `{csf}{0}`,
                    style: StyleEnum.BodyMedium,
                    color: ColorEnum.HighEmphasis,
                    hideAltValue: true,
                },
                {
                    key: 'def_order_topping',
                    format: `{cs}{0}`,
                    style: StyleEnum.BodyMedium,
                    color: ColorEnum.LowEmphasis,
                    hideAltValue: true,
                },
                {
                    key: 'def_additives',
                    format: `{cs} {0}`,
                    style: StyleEnum.BodySmall,
                    color: ColorEnum.MediumEmphasis,
                    vcond: ConditionEnum.NE,
                    hideAltValue: true,
                },
                {
                    key: 'fee_inclusive',
                    format: `{cs} {0}`,
                    style: StyleEnum.BodySmall,
                    color: ColorEnum.MediumEmphasis,
                    vcond: ConditionEnum.NE,
                    hideAltValue: true,
                },
                {
                    key: 'discount_inclusive',
                    format: `{cs} {0}`,
                    style: StyleEnum.BodySmall,
                    color: ColorEnum.MediumEmphasis,
                    vcond: ConditionEnum.NE,
                    hideAltValue: true,
                },
                {
                    key: 'tax_inclusive',
                    format: `{cs} {0}`,
                    style: StyleEnum.BodySmall,
                    color: ColorEnum.MediumEmphasis,
                    vcond: ConditionEnum.NE,
                    hideAltValue: true,
                },
                {
                    key: 'tax_exclusive',
                    format: `{cs} {0}`,
                    style: StyleEnum.BodySmall,
                    color: ColorEnum.MediumEmphasis,
                    vcond: ConditionEnum.NE,
                    hideAltValue: true,
                },
                {
                    key: 'fee_exclusive',
                    format: `{cs} {0}`,
                    style: StyleEnum.BodySmall,
                    color: ColorEnum.MediumEmphasis,
                    vcond: ConditionEnum.NE,
                    hideAltValue: true,
                },
                {
                    key: 'discount_exclusive',
                    format: `{cs} {0}`,
                    style: StyleEnum.BodySmall,
                    color: ColorEnum.MediumEmphasis,
                    vcond: ConditionEnum.NE,
                    hideAltValue: true,
                },
            ];
    }
};
