/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import { createTheme, Theme } from '@mui/material/styles';

// Create a theme instance.
const theme = (mainTheme: Theme) =>
    createTheme({
        ...mainTheme,
        direction: 'ltr',
        typography: {
            fontFamily: "'roboto'",
        },
    });

export default theme;
