import { QlubPalette, Typography } from '@qlub-dev/qlub-kit/dist/theme/types';

declare module '@mui/material/Button' {
    interface ButtonPropsVariantOverrides {
        containedLight: true;
        containedDestructive: true;
        textElevated: true;
    }
}
declare module '@mui/material/styles' {
    interface Theme {
        qlub: { palette: QlubPalette; typography: Typography };
    }
    interface ThemeOptions {
        qlub: { palette: QlubPalette; typography: Typography };
    }
}
export {};
