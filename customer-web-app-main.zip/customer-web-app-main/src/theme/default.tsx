/*
    Creation Time: 2021 - Dec - 18
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import { createTheme, Theme } from '@mui/material/styles';

// Create a theme instance.
const theme = (mainTheme: Theme) =>
    createTheme({
        ...mainTheme,
        direction: 'ltr',
    });

export default theme;
