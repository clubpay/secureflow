import { FC, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Paper, Skeleton } from '@mui/material';
import { KImage } from '@qlub-dev/qlub-kit';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { BackgroundModeEnum, EnableEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { KeyboardArrowLeftRounded, MenuRounded } from '@mui/icons-material';
import Menu from '@/layout/QlubLayout/component/Menu';
import classNames from 'classnames';
import Footer from '@clubpay/customer-common-module/src/component/Footer';
import Loading from '@qlub-dev/qlub-kit/dist/components/Loading';
import PullToRefresh from 'react-simple-pull-to-refresh';
import LoginButton from 'layout/QlubLayout/component/LoginButton';
import CircleButton from '@/layout/QlubLayout/component/CirlceButton';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { profileEventsCenter } from '@clubpay/customer-common-module/src/hook/eventsCenter';
import { useLayout } from '@clubpay/customer-common-module/src/context/layout';
import { isUserProfileEnable } from '@clubpay/customer-common-module/src/repository/config';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getLayoutVendorDetails, isNodeSpaceWorthy } from '@/layout/QlubLayout/utils';
import WorkingHoursBanner from '@/layout/QlubLayout/component/WorkingHoursBanner';
import { StackElements } from '@qlub-dev/qlub-kit/dist/components/StackElements';
import LanguageDrawer from '@clubpay/customer-common-module/src/component/LanguageSwitcher/Drawer';
import LanguageSwitcher from '@clubpay/customer-common-module/src/component/LanguageSwitcher';
import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';

import styles from './index.module.scss';

interface IProps {
    title?: React.ReactNode;
    variant: 'static' | 'small' | 'scrollable' | 'compact' | 'none';
    logoSize?: 'small' | 'large';
    hideVendorTitle?: boolean;
    hideVendorLogo?: boolean;
    hideFooter?: boolean;
    hideMenu?: boolean;
    hideAuth?: boolean;
    forceTitle?: boolean;
    fixedFooter?: boolean;
    pullable?: boolean;
    withBack?: boolean;
    borderBottom?: boolean;
    titleFullWidth?: boolean;
    startComponent?: React.ReactNode | (() => React.ReactNode);
    endComponent?: React.ReactNode | (() => React.ReactNode);
    hideHeaderIfEmpty?: boolean;
    openingHoursBanner?: boolean;
}

const QlubLayout: FC<IProps> = ({
    title,
    variant,
    logoSize,
    withBack: plainWithBack,
    hideFooter,
    hideMenu,
    hideAuth,
    fixedFooter,
    hideVendorTitle,
    hideVendorLogo,
    forceTitle,
    borderBottom,
    titleFullWidth,
    pullable,
    startComponent,
    endComponent,
    hideHeaderIfEmpty,
    openingHoursBanner,
    children,
}) => {
    const { t } = useTranslation('common');
    const { vendor } = useVendor();
    const { lang, pathname } = useQlubRouter();
    const { config: countryConfig } = useConfigContext();
    const { isAuthorizedUser, setDrawerConstants, login, setWithSSOLogin, forceEnableLogin } = useAuth();
    const { pull, barRef, scrolled: layoutScroll, enableScroll, back, backIsVisible } = useLayout();
    const isInvoicePage = pathname === '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice';
    const isLandingPage = pathname === '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]';

    const showHeaderLanguageSwitcher = useMemo(
        () => countryConfig?.languageSwitcherUIv2 === EnableEnum.Enable && (isLandingPage || isInvoicePage),

        [countryConfig?.languageSwitcherUIv2, pathname],
    );

    const landingFooterDisclaimerText = useMemo(() => {
        if (!isLandingPage) {
            return '';
        }

        const disclaimerText =
            getLocaleText(vendor?.config?.landingFooterDisclaimerText || '', lang || '', 'en') ||
            getLocaleText(countryConfig?.landingFooterDisclaimerText || '', lang || '', 'en');

        return disclaimerText;
    }, [vendor?.config?.landingFooterDisclaimerText, countryConfig?.landingFooterDisclaimerText, lang, pathname]);

    const [logoScrollableLoaded, setLogoScrollableLoaded] = useState(false);
    const [logoCompactLoaded, setCompactLoaded] = useState(false);
    const [hideHeader, setHideHeader] = useState(false);

    const {
        userProfile: { tapOnLoginEvent, isUserProfileEnabledEvent },
    } = profileEventsCenter();

    useEffect(() => {
        const fn = () => {
            if (vendor?.config.enableSSOLogin) {
                return vendor?.config.enableSSOLogin === EnableEnum.Enable;
            }
            return countryConfig?.enableSSOLogin === EnableEnum.Enable;
        };
        setWithSSOLogin(fn());
    }, [countryConfig, vendor]);

    const isLoginEnabled = useMemo(() => {
        return (
            forceEnableLogin || isUserProfileEnable(countryConfig, vendor?.config?.enableUserProfile, vendor?.brand?.id)
        );
    }, [vendor, countryConfig, forceEnableLogin]);

    useEffect(() => {
        if (isLoginEnabled) {
            isUserProfileEnabledEvent(isAuthorizedUser);
        }
    }, [isLoginEnabled]);

    const menuRef = useRef<any | null>(null);

    const layoutVendorDetails = useMemo(() => {
        return getLayoutVendorDetails(vendor, {});
    }, [vendor]);

    const menuClickHandler = useCallback(() => {
        menuRef.current?.openDrawer(true);
    }, []);

    const scrolled = variant === 'scrollable' && layoutScroll;
    const withBack = backIsVisible ?? plainWithBack;

    useEffect(() => {
        enableScroll(variant === 'scrollable');
    }, [variant]);

    const loginHandler = useCallback(() => {
        tapOnLoginEvent();
        setDrawerConstants({
            text: {
                phone: {
                    title: '',
                    description: '',
                    buttonText: t('Continue'),
                },
                otp: {
                    title: '',
                    description: '',
                    buttonText: t('Continue'),
                },
                done: {
                    title: '',
                    description: '',
                    buttonText: '',
                },
            },
            numInputs: 5,
        });

        login?.({ guest: false, isFullPage: true });
    }, [lang]);

    const logoScrollableLoadHandler = useCallback(() => {
        setLogoScrollableLoaded(true);
    }, []);

    const logoCompactLoadHandler = useCallback(() => {
        setCompactLoaded(true);
    }, []);

    const headerRefHandler = (ref: any) => {
        if (!hideHeaderIfEmpty) {
            return;
        }

        setHideHeader(!isNodeSpaceWorthy(ref));
    };

    const [headerStart, headerEnd] = useMemo(() => {
        const showDetails = scrolled || variant === 'compact';
        const renderLogo = Boolean(showDetails && !hideVendorLogo && !withBack && layoutVendorDetails?.logoUrl);
        const renderTitle = Boolean(!hideVendorTitle && showDetails && !forceTitle);
        return [
            <>
                {typeof startComponent === 'function' ? startComponent() : startComponent}
                {withBack && showDetails && (
                    <CircleButton className={styles.backIcon} onClick={back}>
                        <KeyboardArrowLeftRounded />
                    </CircleButton>
                )}
                <div className={styles.headerVendor}>
                    {renderLogo && (
                        <>
                            {!logoCompactLoaded && <Skeleton variant="circular" width={36} height={36} />}
                            <KImage
                                src={layoutVendorDetails?.logoUrl}
                                className={classNames(styles.vendorLogo, {
                                    [styles.imgLoaded]: logoCompactLoaded,
                                    [styles.imgNotLoaded]: !logoCompactLoaded,
                                })}
                                alt={layoutVendorDetails?.title || ''}
                                maxSize={32}
                                onLoad={logoCompactLoadHandler}
                            />
                        </>
                    )}
                    {renderTitle && (
                        <div className={styles.vendorTitle}>
                            {layoutVendorDetails?.title ? (
                                layoutVendorDetails?.title
                            ) : (
                                <Skeleton className={styles.skeleton} variant="text" width={210} height={30} />
                            )}
                        </div>
                    )}
                </div>
                {(!showDetails || forceTitle) && (
                    <div
                        className={classNames(styles.pageTitle, {
                            [styles.ellipsis]: titleFullWidth,
                        })}
                    >
                        {title}
                    </div>
                )}
            </>,
            <>
                {typeof endComponent === 'function' ? endComponent() : endComponent}
                {showDetails && !hideMenu && isLoginEnabled && (
                    <CircleButton className={styles.hamburgerIcon} onClick={menuClickHandler}>
                        <MenuRounded />
                    </CircleButton>
                )}
            </>,
        ];
    }, [
        layoutVendorDetails,
        withBack,
        menuClickHandler,
        startComponent,
        endComponent,
        scrolled,
        back,
        logoCompactLoaded,
        variant,
        isLoginEnabled,
    ]);

    const content = useMemo(() => {
        if (variant === 'none') {
            return <>{children}</>;
        }
        return (
            <>
                <LanguageDrawer />
                <div className={styles.header}>
                    {variant !== 'compact' && (
                        <div className={styles.top}>
                            <div className={styles.start}>
                                <StackElements alignItems="center" justifyContent="center" spacing={2}>
                                    {withBack && !scrolled && (
                                        <CircleButton className={styles.backIcon} onClick={back}>
                                            <KeyboardArrowLeftRounded />
                                        </CircleButton>
                                    )}
                                    {showHeaderLanguageSwitcher && <LanguageSwitcher />}
                                </StackElements>
                            </div>
                            <div className={styles.center}>
                                {layoutVendorDetails?.logoUrl && (
                                    <div className={styles.logo} style={layoutVendorDetails?.iconBgStyle}>
                                        {layoutVendorDetails?.iconBgStyle && <div className="logo-blur" />}
                                        {!logoScrollableLoaded && (
                                            <Skeleton variant="rectangular" className={styles.skeleton} />
                                        )}
                                        <KImage
                                            src={layoutVendorDetails?.logoUrl}
                                            alt="vendor-logo"
                                            onLoad={logoScrollableLoadHandler}
                                            className={logoScrollableLoaded ? styles.imgLoaded : styles.imgNotLoaded}
                                        />
                                    </div>
                                )}
                            </div>
                            <div className={styles.end}>
                                <div className={styles.wrapper}>
                                    {!hideAuth && isLoginEnabled && <LoginButton onLogin={loginHandler} />}
                                    {!hideMenu && isLoginEnabled && (
                                        <CircleButton onClick={menuClickHandler}>
                                            <MenuRounded />
                                        </CircleButton>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                    <div
                        className={classNames(styles.bottom, {
                            [styles.backdrop]: layoutVendorDetails?.bgUrl && variant === 'static',
                        })}
                        ref={headerRefHandler}
                    >
                        {!hideVendorTitle && variant !== 'compact' && (
                            <div className={styles.title}>
                                {layoutVendorDetails?.title ? (
                                    layoutVendorDetails?.title
                                ) : (
                                    <Skeleton className={styles.skeleton} variant="text" width={210} height={30} />
                                )}
                            </div>
                        )}
                        {variant !== 'static' && variant !== 'small' && (
                            <div
                                className={classNames(styles.bar, { [styles.stick]: scrolled })}
                                ref={!scrolled ? barRef : undefined}
                            >
                                <div
                                    className={classNames(styles.start, {
                                        [styles.flexAuto]: titleFullWidth,
                                    })}
                                >
                                    {headerStart}
                                </div>
                                <div className={styles.end}>{headerEnd}</div>
                            </div>
                        )}
                        {variant === 'scrollable' && scrolled && <div className={styles.bar} ref={barRef} />}
                    </div>
                </div>
                {openingHoursBanner && <WorkingHoursBanner />}
                <Paper
                    elevation={0}
                    className={classNames(styles.paper, {
                        [styles.backdrop]: layoutVendorDetails?.bgUrl && variant === 'static',
                        [styles.applePayBottomSpace]: isInvoicePage,
                    })}
                >
                    <div className={styles.content}>{children}</div>
                    {!hideFooter && <Footer fixed={fixedFooter} opaque />}
                </Paper>
                <Menu loginEnable={isLoginEnabled} variant={variant} onLogin={loginHandler} ref={menuRef} />
            </>
        );
    }, [
        children,
        headerStart,
        headerEnd,
        menuClickHandler,
        barRef,
        scrolled,
        back,
        loginHandler,
        logoScrollableLoaded,
        isLoginEnabled,
        withBack,
    ]);

    const pullableContent = useMemo(() => {
        if (!pullable) {
            return content;
        }

        return (
            <PullToRefresh
                onRefresh={pull}
                className={styles.pullable}
                refreshingContent={
                    <div className={styles.loading}>
                        <Loading />
                    </div>
                }
                isPullable
                pullingContent=""
            >
                {content}
            </PullToRefresh>
        );
    }, [content, pullable]);

    return (
        <div
            className={classNames(styles.container, {
                [styles.variantStrict]: variant === 'static',
                [styles.variantSmall]: variant === 'small',
                [styles.variantScrollable]: variant === 'scrollable',
                [styles.variantCompact]: variant === 'compact',
                [styles.variantNone]: variant === 'none',
                [styles.withBorderBottom]: borderBottom,
                [styles.withLogo]: layoutVendorDetails?.logoUrl,
                [styles.withBg]: layoutVendorDetails?.bgUrl,
                [styles.withFooter]: !hideFooter,
                [styles.smallLogo]: layoutVendorDetails?.logoUrl && logoSize === 'small',
                [styles.hideHeader]: hideHeader,
                [styles.bgModeNoRepeat]: layoutVendorDetails?.bgMode === BackgroundModeEnum.NoRepeat,
                [styles.bgModeRepeat]: layoutVendorDetails?.bgMode === BackgroundModeEnum.Repeat,
                [styles.bgModeFixed]: layoutVendorDetails?.bgMode === BackgroundModeEnum.Fixed,
                [styles.bgModeFitWidth]: layoutVendorDetails?.bgMode === BackgroundModeEnum.FitWidth,
                [styles.hasDisclaimerFooterText]: !!landingFooterDisclaimerText,
            })}
            style={layoutVendorDetails?.bgUrl ? { backgroundImage: `url(${layoutVendorDetails.bgUrl})` } : undefined}
        >
            {pullableContent}
        </div>
    );
};

export default QlubLayout;
