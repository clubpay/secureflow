import { useMemo } from 'react';
import { Button } from '@qlub-dev/qlub-kit';
import Link from 'next/link';
import Avatar from '@mui/material/Avatar';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { profileEventsCenter } from '@clubpay/customer-common-module/src/hook/eventsCenter';
import UserIcon from '@clubpay/customer-common-module/src/component/Icons/UserIcon';
import { IProfile } from '@clubpay/customer-common-module/src/repository/auth/type';
import CircleButton from '@/layout/QlubLayout/component/CirlceButton';
import classNames from 'classnames';

import styles from './index.module.scss';

function getInitials(profile: IProfile | undefined): string {
    if (!profile) {
        return 'NA';
    }

    const str = profile.name || profile.email || profile.phone || '';
    return (
        str
            .split(' ')
            .reduce<string[]>((a, c) => {
                if (!c && a.length > 1) {
                    return a;
                }
                a.push(c.substring(0, 1).toUpperCase());
                return a;
            }, [])
            .join('') || 'NA'
    );
}

interface IProps {
    size?: 'small' | 'normal' | 'large';
    onLogin?: () => void;
}

function LoginButton({ size, onLogin }: IProps) {
    const { t } = useTranslation('common');
    const { getRouterParam, lang } = useQlubRouter();
    const { isAuthorizedUser, profile } = useAuth();
    const {
        userProfile: { tapOnProfileEvent },
    } = profileEventsCenter();

    const initials = useMemo(() => getInitials(profile), [profile]);

    const avatarComponent = useMemo(() => {
        if (isAuthorizedUser) {
            return (
                <Link href={getRouterParam('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/profile')}>
                    {initials === '+' ? (
                        <CircleButton size={size} onClick={() => tapOnProfileEvent()}>
                            <UserIcon />
                        </CircleButton>
                    ) : (
                        <Avatar
                            onClick={() => tapOnProfileEvent()}
                            className={classNames(styles.avatar, {
                                [styles.small]: size === 'small',
                                [styles.large]: size === 'large',
                            })}
                            src="/broken-image.jpg"
                        >
                            {initials}
                        </Avatar>
                    )}
                </Link>
            );
        }

        return (
            <Button
                className={classNames(styles.login, {
                    [styles.small]: size === 'small',
                    [styles.large]: size === 'large',
                })}
                onClick={onLogin}
            >
                <div className={styles.inner}>
                    <div className={styles.icon}>
                        <UserIcon />
                    </div>
                    <div className={styles.label}>{t('Login')}</div>
                </div>
            </Button>
        );
    }, [isAuthorizedUser, profile, initials, size, onLogin, tapOnProfileEvent, getRouterParam, lang]);

    return avatarComponent;
}

export default LoginButton;
