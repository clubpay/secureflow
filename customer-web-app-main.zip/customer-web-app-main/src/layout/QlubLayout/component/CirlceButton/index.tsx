import { FC } from 'react';
import { IconButton } from '@mui/material';
import { IconButtonProps } from '@mui/material/IconButton/IconButton';
import classNames from 'classnames';

import styles from './index.module.scss';

interface IProps extends Omit<IconButtonProps, 'size'> {
    size?: 'small' | 'normal' | 'large';
}

const CircleButton: FC<IProps> = ({ children, size, className, ...props }) => {
    return (
        <IconButton
            className={classNames(styles.button, className, {
                [styles.small]: size === 'small',
                [styles.large]: size === 'large',
            })}
            {...props}
        >
            {children}
        </IconButton>
    );
};

export default CircleButton;
