import { useMemo } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { convertToMinutes, getMinutesSinceStartOfDay } from '@/services/utils/k_date';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';

import styles from './index.module.scss';

const WorkingHoursBanner = () => {
    const { t } = useTranslation('common');
    const { vendor } = useVendor();

    const show = useMemo(() => {
        if (
            !vendor ||
            !vendor.config?.operationalHoursMessageEnable ||
            !vendor.config?.openingHour ||
            !vendor.config?.closingHour
        ) {
            return false;
        }

        const openingTimeMinutes = convertToMinutes(vendor?.config?.openingHour);
        const closingTimeMinutes = convertToMinutes(vendor?.config?.closingHour);

        const currentMinutes = getMinutesSinceStartOfDay();

        return !(openingTimeMinutes <= currentMinutes && currentMinutes <= closingTimeMinutes);
    }, [vendor]);

    if (!show) {
        return null;
    }

    return <div className={styles.banner}>{t('This restaurant is closed, ordering is currently unavailable')}</div>;
};

export default WorkingHoursBanner;
