import { useMemo, useState, forwardRef, useImperativeHandle, useCallback, useEffect } from 'react';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Box from '@mui/material/Box';
import { PermIdentityRounded, CloseRounded, ChevronRightRounded } from '@mui/icons-material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { Button } from '@qlub-dev/qlub-kit';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import Link from 'next/link';
import CircleButton from '@/layout/QlubLayout/component/CirlceButton';
import { IMenuItem } from '@clubpay/customer-common-module/src/context/layout/types';
import { useLayout } from '@clubpay/customer-common-module/src/context/layout';
import classNames from 'classnames';

import styles from './index.module.scss';

interface IProps {
    variant: string;
    loginEnable: boolean;
    onLogin: () => void;
}

const Menu = forwardRef<any, IProps>(({ loginEnable, onLogin }, ref) => {
    const { t } = useTranslation('common');
    const { isAuthorizedUser, profile } = useAuth();
    const { routerPush } = useQlubRouter();
    const { menuItems, widgets, setSwitchAccountOpenFn, setCloseDrawerFn } = useLayout();
    const [open, setOpen] = useState(false);

    const closeHandler = useCallback(() => {
        setOpen(false);
    }, []);

    useEffect(() => {
        setCloseDrawerFn(closeHandler);
    }, [closeHandler]);

    const openHandler = useCallback((o: boolean) => {
        setOpen(o);
    }, []);

    useImperativeHandle(
        ref,
        () => {
            return {
                openDrawer: openHandler,
            };
        },
        [openHandler],
    );

    const profileHandler = () => {
        openHandler(false);
        routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/profile');
    };

    const menuList = useMemo(() => {
        const menuItem = (item: IMenuItem) => {
            return (
                <ListItem disablePadding className={styles.menuItem}>
                    <ListItemButton onClick={item.onClick}>
                        {item.icon && <ListItemIcon>{item.icon}</ListItemIcon>}
                        <ListItemText primary={item.title} className={styles.menuItemTitle} />
                        <div className={styles.menuEndIcon}>
                            <ChevronRightRounded />
                        </div>
                    </ListItemButton>
                </ListItem>
            );
        };
        return (
            <List>
                {menuItems.map((item) => {
                    if (item.type === 'divider') {
                        return <Divider />;
                    }

                    if (item.type === 'gap') {
                        return <Box sx={{ flex: '1 1' }} />;
                    }

                    if (item.href) {
                        return (
                            <Link
                                href={item.href}
                                onClick={() => {
                                    setOpen(false);
                                }}
                            >
                                {menuItem(item)}
                            </Link>
                        );
                    }
                    return menuItem(item);
                })}
            </List>
        );
    }, [menuItems]);

    return (
        <Drawer
            anchor="top"
            transitionDuration={100}
            PaperProps={{
                elevation: 0,
                sx: {
                    height: 'calc((var(--vh, 1vh) * 100))',
                    maxWidth: '100vw',
                    margin: 'auto',
                    background: 'white',
                    overflow: 'hidden',
                },
            }}
            className={styles.menu}
            open={open}
            onClose={() => {
                setOpen(false);
            }}
        >
            <div className={styles.content}>
                <div className={styles.header}>
                    <div className={styles.bar}>
                        <CircleButton
                            className={styles.close}
                            onClick={() => {
                                setOpen(false);
                            }}
                            id="menuCloseBtn"
                        >
                            <CloseRounded />
                        </CircleButton>
                    </div>
                    <div className={styles.widgets}>
                        {loginEnable && !isAuthorizedUser && (
                            <div className={styles.loginWidget}>
                                <div className={styles.label}>{t('Welcome back!')}</div>
                                <div className={styles.subLabel}>{t(`Let's get you logged in to your account`)}</div>
                                <div className={styles.button}>
                                    <Button variant="contained" fullWidth onClick={onLogin}>
                                        {t('Log in')}
                                    </Button>
                                </div>
                            </div>
                        )}
                        {loginEnable && isAuthorizedUser && (
                            <div className={styles.infoWidget} onClick={profileHandler}>
                                <div className={styles.icon}>
                                    <PermIdentityRounded />
                                </div>
                                <div className={styles.details}>
                                    <div className={styles.label}>{t('User profile')}</div>
                                    <div className={styles.id}>{profile?.phone || profile?.email || 'na'}</div>
                                </div>
                            </div>
                        )}
                        {widgets}
                    </div>
                </div>
                <div className={styles.list}>{menuList}</div>
                {loginEnable && isAuthorizedUser && (
                    <div className={classNames(styles.list, styles.logoutBtn)}>
                        <Button
                            fullWidth
                            size="large"
                            type="submit"
                            variant="containedDestructive"
                            onClick={setSwitchAccountOpenFn}
                        >
                            {t('Log out')}
                        </Button>
                    </div>
                )}
                <div className={styles.footer} />
            </div>
        </Drawer>
    );
});

export default Menu;
