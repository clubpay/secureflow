import { CSSProperties } from 'react';
import { BackgroundModeEnum, IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor';
import { cdnDomain } from '@clubpay/customer-common-module/src/repository/axios/constants';
import { changeDomain } from '@clubpay/customer-common-module/src/utility/k_url';

export interface ILayoutVendorDetailsOptions {
    logoSize?: 'small' | 'large';
    logoBlurBackground?: boolean;
    bgColor?: string;
}

export interface ILayoutVendorDetails {
    title: string;
    logoUrl: string;
    iconBgStyle: CSSProperties | undefined;
    bgUrl?: string;
    bgMode?: BackgroundModeEnum;
}

export const getLayoutVendorDetails = (
    vendor: IRestaurant | undefined,
    { logoSize, logoBlurBackground, bgColor }: ILayoutVendorDetailsOptions,
): ILayoutVendorDetails | undefined => {
    if (!vendor) {
        return undefined;
    }

    const logoUrl = logoSize === 'small' ? vendor.logoSmallUrl || vendor.logoBigUrl : vendor.logoBigUrl;

    const getIconStyle = () => {
        if (logoBlurBackground) {
            return { backgroundImage: `url(${logoUrl})`, backgroundPosition: 'center', backgroundSize: 'cover' };
        }

        if (bgColor) {
            return { backgroundImage: bgColor };
        }

        return undefined;
    };

    return {
        title: vendor.title || '',
        logoUrl,
        iconBgStyle: getIconStyle(),
        bgUrl:
            cdnDomain && vendor.config.customerBackground
                ? changeDomain(vendor.config.customerBackground, cdnDomain)
                : vendor.config.customerBackground || vendor.backgroundUrl,
        bgMode: vendor?.config?.customerBackgroundMode,
    };
};

export function isNodeSpaceWorthy(node: Node | null, depth = 0): boolean {
    if (!node || depth > 10) {
        return false;
    }

    if (node.nodeType === Node.TEXT_NODE && node.textContent?.trim()) {
        return true;
    }

    const element = node as HTMLElement;
    const tagName = element.tagName.toUpperCase();

    if (
        ['IMG', 'SVG', 'VIDEO', 'IFRAME'].includes(tagName) &&
        ((element.hasAttribute('src') && element.getAttribute('src') !== '') || element.hasChildNodes())
    ) {
        return true;
    }

    const { childNodes } = element;

    if (childNodes.length !== 0) {
        for (let i = 0; i < childNodes.length; i++) {
            if (isNodeSpaceWorthy(childNodes[i], depth + 1)) {
                return true;
            }
        }
    }

    return false;
}
