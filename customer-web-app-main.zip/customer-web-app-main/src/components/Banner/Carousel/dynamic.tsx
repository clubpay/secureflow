import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { IBanner } from '@/repositories/banner/types';
import useEventsCenter from '@/hooks/eventsCenter';
import BannerAPIManager from '@/repositories/banner';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { ISliderItem } from '@clubpay/customer-common-module/src/component/KSlider/interface';
import KSlider from '@clubpay/customer-common-module/src/component/KSlider';
import { detectRTLFromLang } from '@clubpay/customer-common-module/src/utility/k_lang';
import { SliderLocationEnum } from '@clubpay/customer-common-module/src/component/KSlider/enums';
import { getAuth } from '@clubpay/customer-common-module/src/service/session/auth';
import { updateQueryStringParameter } from '@clubpay/customer-common-module/src/utility/k_url';

export interface IProps {
    position?: string;
    location: SliderLocationEnum;
    styleOverrides?: {
        commonContainer?: string;
        singleSlide?: string;
        multiSlide?: string;
    };
}

const CarouselBanner = ({ position, location, styleOverrides }: IProps) => {
    const [banners, setBanners] = useState<IBanner[]>([]);

    const { url, urlStr, lang, query } = useQlubRouter();
    const { carouselBanner } = useEventsCenter();

    useEffect(() => {
        BannerAPIManager.getInstance()
            .getBanner(url, location || SliderLocationEnum.ConfirmationPage)
            .then((res) => {
                setBanners(res?.rows || []);
            });
    }, [urlStr, location]);

    const transformRedirectUrl = useCallback(
        ({ redirectURL, queryParams }: { redirectURL: string | undefined; queryParams: any }) => {
            if (!redirectURL) {
                return;
            }

            let link = redirectURL;
            if (queryParams?.sid) {
                link = updateQueryStringParameter(link, 'partyId', queryParams?.sid);
            }
            if (queryParams?.dsi) {
                link = updateQueryStringParameter(link, 'dsi', queryParams?.dsi);
            }
            const auth = getAuth();
            if (auth.JWTToken) {
                link = updateQueryStringParameter(link, 'jwt', auth.JWTToken);
            }

            return link;
        },
        [],
    );

    const list = useMemo<ISliderItem[]>(() => {
        if (!banners?.length) {
            return [];
        }

        return banners.reduce<ISliderItem[]>((acc, banner) => {
            if (position && banner.meta?.placement && banner.meta?.placement !== position) {
                return acc;
            }

            acc.push({
                name: banner.name,
                src: banner.docLocalUrls?.[lang] || banner.docUrl,
                url: transformRedirectUrl({ redirectURL: banner.meta?.redirectUrl, queryParams: query }),
                position: banner.meta?.placement,
            });
            return acc;
        }, []);
    }, [banners, position, query, lang]);

    if (list.length === 0) {
        return null;
    }

    return (
        <KSlider
            list={list}
            rtl={detectRTLFromLang(lang)}
            centerPadding="17px"
            location={location}
            styleOverrides={styleOverrides}
            events={{
                showSlider: carouselBanner?.showCarouselBannerEvent,
                tapOnSlider: carouselBanner?.tapOnSliderEvent,
                redirectFromSlider: carouselBanner?.redirectFromSliderEvent,
            }}
        />
    );
};

export default CarouselBanner;
