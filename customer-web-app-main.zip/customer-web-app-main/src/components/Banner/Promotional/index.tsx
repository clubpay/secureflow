import React, { useEffect, useState } from 'react';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { Box, Skeleton } from '@mui/material';
import useEventsCenter from '@/hooks/eventsCenter';
import { SliderPositionEnum } from '@/components/Banner';

interface IBannerSize {
    [key: string]: string;
}

const bannerSize: IBannerSize = {
    small: '62px',
    medium: '105px',
    large: '120px',
};

interface IProps {
    position: SliderPositionEnum;
}

const PromotionalBanner = ({ position }: IProps) => {
    const { vendor } = useVendor();
    const [isShow, setIsShow] = useState(false);
    const {
        promotionalBanner: { displayEvent, clickEvent, redirectEvent },
    } = useEventsCenter();

    const promotionalBannerSize = bannerSize[vendor?.config?.promotionalBannerSize || 'medium'];

    useEffect(() => {
        if (isShow) {
            displayEvent();
        }
    }, [isShow]);

    if (position !== vendor?.config?.promotionalBannerPlacement) {
        return null;
    }

    const handleBannerClick = () => {
        clickEvent();

        let bannerUrl = vendor?.config?.promotionalBannerRedirectLink || '';

        if (bannerUrl) {
            redirectEvent();
        }

        setTimeout(() => {
            if (!bannerUrl) {
                return;
            }

            if (!bannerUrl.match(/^https?:\/\//i)) {
                bannerUrl = `https://${bannerUrl}`;
            }

            window.location.href = bannerUrl;
        }, 150);
    };

    const handleBannerLoad = () => {
        setIsShow(true);
    };

    if (!vendor?.config?.promotionalBannerImageLink) {
        return null;
    }

    return (
        <Box
            sx={{
                margin: '32px 24px',
                borderRadius: '8px',
                height: promotionalBannerSize,
            }}
        >
            {!isShow && (
                <Skeleton
                    animation="wave"
                    variant="rectangular"
                    sx={{
                        height: '100%',
                        borderRadius: '8px',
                    }}
                />
            )}

            <Box
                component="img"
                src={vendor?.config?.promotionalBannerImageLink || ''}
                alt="venture-banner"
                sx={{
                    borderRadius: '8px',
                    height: '100%',
                    width: '100%',
                    opacity: isShow ? 1 : 0,
                }}
                onLoad={handleBannerLoad}
                onClick={handleBannerClick}
            />
        </Box>
    );
};

export default PromotionalBanner;
