import { FC } from 'react';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { SliderLocationEnum } from '@clubpay/customer-common-module/src/component/KSlider/enums';
import dynamic from 'next/dynamic';

export enum SliderPositionEnum {
    Top = 'top',
    Middle = 'middle',
    Bottom = 'bottom',
}

interface IProps {
    position: SliderPositionEnum;
    location: SliderLocationEnum;
    carouselStyleOverrides?: {
        commonContainer?: string;
        singleSlide?: string;
        multiSlide?: string;
    };
    success?: boolean;
}

const PromotionalBanner = dynamic(() => import('./Promotional'), { ssr: false });
const CarouselBanner = dynamic(() => import('./Carousel'), { ssr: false });

const Banners: FC<IProps> = ({ success, position, location, carouselStyleOverrides }) => {
    const { vendor } = useVendor();

    if (!success) {
        return null;
    }

    if (vendor?.config.enablePromotionalBanner) {
        return <PromotionalBanner position={position} />;
    }

    return <CarouselBanner position={position} location={location} styleOverrides={carouselStyleOverrides} />;
};

export default Banners;
