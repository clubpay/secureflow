/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import dynamic from 'next/dynamic';
import type { IPDFProps } from '@/components/Menu/PDF/pdf';

const PDFWidget = dynamic<IPDFProps>(() => import('@/components/Menu/PDF/pdf'), {
    loading: () => <></>,
    ssr: false,
});

export default PDFWidget;
