/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useState, useMemo, useEffect, Dispatch } from 'react';
import { Button, CustomerContainer } from '@qlub-dev/qlub-kit';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { ErrorBoundary } from '@sentry/nextjs';
import { isIOS } from '@clubpay/customer-common-module/src/utility/k_user_agent';
import { WindowPdfJs } from '@/components/Menu/PDF/windowPdfJs';
import Loading from '@qlub-dev/qlub-kit/dist/components/Loading';

import styles from './index.module.scss';

export interface IPDFProps {
    url: string;
    priority: string[] | string;
    setNewLoading?: Dispatch<React.SetStateAction<boolean>>;
    setLoading?: Dispatch<React.SetStateAction<boolean>>;
    isCalledFromDrawer?: boolean;
}

enum RenderOptionEnum {
    PDFJS = 1,
    EMBED = 2,
    GDOC = 3,
    LINK = 4,
}

const embedProps: any = {
    type: 'application/pdf',
    frameBorder: '0',
    scrolling: 'auto',
    height: '100%',
    width: '100%',
};

const iframeProps: any = {
    frameBorder: '0',
    scrolling: 'auto',
    height: '100%',
    width: '100%',
};

const convertTextToEnum = (items?: string[] | string): RenderOptionEnum[] | null => {
    const fn = (item: string) => {
        switch (item.toLowerCase()) {
            case 'pdfjs':
                return RenderOptionEnum.PDFJS;
            case 'embed':
                return RenderOptionEnum.EMBED;
            case 'gdoc':
                return RenderOptionEnum.GDOC;
            case 'link':
            default:
                return RenderOptionEnum.LINK;
        }
    };
    if (typeof items === 'string') {
        return [fn(items as string)];
    }
    if (!items || items.length === 0) {
        return null;
    }
    return items?.map((item) => {
        return fn(item);
    });
};

const getDefaultPriorityList = (): RenderOptionEnum[] => {
    if (isIOS()) {
        return [RenderOptionEnum.PDFJS, RenderOptionEnum.GDOC, RenderOptionEnum.EMBED, RenderOptionEnum.LINK];
    }
    return [RenderOptionEnum.PDFJS, RenderOptionEnum.EMBED, RenderOptionEnum.GDOC, RenderOptionEnum.LINK];
};

export default function PDF({ url, priority, setNewLoading, isCalledFromDrawer }: IPDFProps) {
    const { t } = useTranslation('common');
    const [error, setError] = useState<Error | null>(null);
    const [option, setOption] = useState<RenderOptionEnum>(
        (convertTextToEnum(priority) || getDefaultPriorityList())?.[0] || RenderOptionEnum.PDFJS,
    );
    const [height, setHeight] = useState<number>(1080);
    const [innerLoading, setInnerLoading] = useState<boolean>(true);

    useEffect(() => {
        const windowResizeHandler = () => {
            setHeight(window.innerHeight - 128);
        };
        windowResizeHandler();
        window.addEventListener('resize', windowResizeHandler);

        setNewLoading?.(true);

        return () => {
            window.addEventListener('resize', windowResizeHandler);
        };
    }, []);

    const priorityList: RenderOptionEnum[] = useMemo(
        () => convertTextToEnum(priority) || getDefaultPriorityList(),
        [priority],
    );

    const documentLoadErrorHandler = (err: Error) => {
        setError(err);
        setInnerLoading(false);
        setNewLoading?.(false);

        const index = priorityList.indexOf(option);

        if (index === -1) {
            setOption(RenderOptionEnum.LINK);
        } else if (priorityList.length > index + 1) {
            setOption(priorityList[index + 1]);
        } else {
            setOption(RenderOptionEnum.LINK);
        }
    };

    const render = useMemo(() => {
        switch (option) {
            case RenderOptionEnum.PDFJS:
                return (
                    <WindowPdfJs
                        url={url}
                        onDone={() => {
                            setInnerLoading(false);
                            setNewLoading?.(false);
                        }}
                        onFail={() => {
                            setInnerLoading(false);
                            setNewLoading?.(false);
                        }}
                    />
                );
            case RenderOptionEnum.EMBED:
                // eslint-disable-next-line react/no-unknown-property
                return <embed {...embedProps} src={url} onError={documentLoadErrorHandler} height={`${height}px`} />;
            case RenderOptionEnum.GDOC:
                return (
                    <iframe
                        {...iframeProps}
                        title="menu"
                        src={`https://docs.google.com/gview?embedded=true&url=${url}`}
                        onError={documentLoadErrorHandler}
                        height={`${height}px`}
                    />
                );
            default:
            case RenderOptionEnum.LINK:
                return (
                    <a href={url} target="_blank" rel="noopener noreferrer">
                        <Button variant="contained" color="primary">
                            {t('Open External Link')}
                        </Button>
                    </a>
                );
        }
        return null;
    }, [url, option, error, priorityList]);

    return (
        <CustomerContainer className={styles.pdfViewer}>
            {innerLoading && isCalledFromDrawer && (
                <div className={styles.innerLoading}>
                    <Loading color="outlined" />
                </div>
            )}
            <ErrorBoundary
                fallback={<>{t('Something went wrong. Please contact the company representative')}</>}
                onError={documentLoadErrorHandler}
            >
                {render}
            </ErrorBoundary>
        </CustomerContainer>
    );
}
