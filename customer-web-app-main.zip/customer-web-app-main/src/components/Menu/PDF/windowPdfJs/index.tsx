import React, { useCallback, useRef, useState } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import AutoSizer, { Size } from 'react-virtualized-auto-sizer';
import { ListChildComponentProps, VariableSizeList } from 'react-window';
import { OnDocumentLoadSuccess, OnError } from 'react-pdf/dist/cjs/shared/types';
import { DocumentCallback } from 'react-pdf/src/shared/types';
import { debounce } from 'lodash';
import Loading from '@qlub-dev/qlub-kit/dist/components/Loading';

import styles from './index.module.scss';

pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

const options: any = {
    cMapUrl: 'cmaps/',
};

interface IPageSize {
    [key: string]: {
        width: number;
        height: number;
    };
}

interface IRange {
    from: number;
    to: number;
}

interface IProps {
    url: string;
    onFail?: (e: any) => void;
    onDone?: () => void;
}

export const WindowPdfJs = ({ url, onFail, onDone }: IProps) => {
    const [size, setSize] = useState(0);
    const [width, setWidth] = useState(0);
    const [pageSizeMap, setPageSizeMap] = useState<IPageSize | undefined>(undefined);
    const pdf = useRef<DocumentCallback | undefined>(undefined);
    const rangeRef = useRef<IRange>({ from: 0, to: 0 });
    const listRef = useRef<VariableSizeList | null>(null);

    const successHandler =
        ({ width: w }: Size): OnDocumentLoadSuccess =>
        (document) => {
            onDone?.();
            setWidth(w);
            pdf.current = document;
            setSize(document.numPages);
            Promise.all(
                Array.from({ length: document.numPages }).map((d, i) => {
                    return document.getPage(i + 1);
                }),
            ).then((arr) => {
                const psm: IPageSize = {};
                arr.forEach((page, index) => {
                    psm[index] = {
                        width: page.view[2],
                        height: page.view[3],
                    };
                });
                setPageSizeMap(psm);
            });
        };

    const failedHandler: OnError = (e) => {
        onFail?.(e);
    };

    const getHeight = (index: number) => {
        const pageSize = pageSizeMap?.[index];
        if (!pageSize) {
            return 0;
        }
        return (pageSize.height / pageSize.width) * width;
    };

    const Row = ({ index, style }: ListChildComponentProps<any>) => {
        if (rangeRef.current.from <= index && index <= rangeRef.current.to) {
            return (
                <div style={style} key={`page_${index + 1}`}>
                    <Page
                        renderMode="canvas"
                        pageNumber={index + 1}
                        renderAnnotationLayer={false}
                        renderTextLayer={false}
                        renderForms={false}
                        width={width}
                        height={getHeight(index)}
                    />
                </div>
            );
        }
        return (
            <div style={style} className={styles.loading} key={`page_${index + 1}`}>
                <Loading color="outlined" />
            </div>
        );
    };

    const updateRangeHandler = useCallback(
        debounce(
            (r: IRange) => {
                rangeRef.current = r;
                listRef.current?.forceUpdate();
            },
            256,
            { leading: true },
        ),
        [],
    );

    return (
        <div className={styles.container}>
            <AutoSizer>
                {(pageSize: Size) => {
                    return (
                        <>
                            <Document
                                renderMode="canvas"
                                file={url}
                                onLoadSuccess={successHandler(pageSize)}
                                onLoadError={failedHandler}
                                onSourceError={failedHandler}
                                loading={<></>}
                                options={options}
                            >
                                {pageSizeMap && (
                                    <VariableSizeList
                                        ref={(ref) => {
                                            listRef.current = ref;
                                        }}
                                        height={Math.min(pageSize.height, 600)}
                                        width={pageSize.width}
                                        itemSize={getHeight}
                                        itemCount={size}
                                        overscanCount={0}
                                        onItemsRendered={({ overscanStartIndex, overscanStopIndex }) => {
                                            updateRangeHandler({ from: overscanStartIndex, to: overscanStopIndex });
                                        }}
                                    >
                                        {Row}
                                    </VariableSizeList>
                                )}
                            </Document>
                        </>
                    );
                }}
            </AutoSizer>
        </div>
    );
};
