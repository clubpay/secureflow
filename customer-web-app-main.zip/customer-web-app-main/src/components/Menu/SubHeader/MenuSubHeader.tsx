import { FC } from 'react';
import { Divider, SubHeader } from '@qlub-dev/qlub-kit';
import { IconButton } from '@mui/material';
import { KeyboardArrowLeftRounded, KeyboardArrowRightRounded } from '@mui/icons-material';
import { Theme } from '@mui/material/styles/createTheme';
import MultiLocale, { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IURLTopology, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import {
    IQrDetailsResponse,
    IRestaurant,
    IRestaurantConfig,
    MenuPageDescriptionModeEnum,
} from '@clubpay/customer-common-module/src/repository/vendor';
import { ISelectedMenuLink } from '@/views/Menu/Menu/types';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';

import styles from './index.module.scss';

interface IMenuSubHeaderProps {
    vendor: IRestaurant;
    url: IURLTopology;
    qrDetails?: IQrDetailsResponse;
    theme: Theme;
    countryConfig: IConfig;
    isForDrawerContent?: boolean;
    toggleDrawerHandler?: (open: boolean, menu?: ISelectedMenuLink) => void;
}

export type AvailableApi = 'vendor' | 'country';

const MenuSubHeader: FC<IMenuSubHeaderProps> = ({
    vendor,
    qrDetails,
    theme,
    isForDrawerContent,
    countryConfig,
    toggleDrawerHandler,
}) => {
    const { t } = useTranslation('common');
    const { url, lang } = useQlubRouter();
    const { routerPush } = useQlubRouter();

    /**
     * Gets the title for the subheader.
     *
     * @returns {React.ReactElement} The rendered title component.
     */
    const getTitle = () => {
        const availableApi: AvailableApi = vendor.config.menuPageMode ? 'vendor' : 'country';

        if (availableApi === 'country') {
            return t('Menu');
        }

        if (!vendor.config.menuPageTitle) {
            return t('Menu');
        }

        return <MultiLocale value={getLocaleText(vendor.config.menuPageTitle, lang, '') || t('Menu')} lang={lang} />;
    };

    /**
     * Retrieves the description based on the available description mode.
     *
     * @returns {string|null} The description or null if no description is available.
     */
    const getDescription = () => {
        const setDescription = (api?: IRestaurantConfig | IConfig) => {
            switch (api?.menuPageDescriptionMode) {
                case MenuPageDescriptionModeEnum.Custom: {
                    if (!api.menuPageDescription) {
                        return null;
                    }

                    const availableApi: AvailableApi = vendor.config.menuPageMode ? 'vendor' : 'country';

                    if (availableApi === 'vendor' && api.menuPageDescriptionMode) {
                        return <MultiLocale value={getLocaleText(api.menuPageDescription, lang, '')} lang={lang} />;
                    }

                    if (availableApi === 'country' && api.menuPageDescriptionMode) {
                        return <MultiLocale value={getLocaleText(api.menuPageDescription, lang, '')} lang={lang} />;
                    }

                    return null;
                }

                case MenuPageDescriptionModeEnum.RestaurantName:
                    return vendor.name;
                case MenuPageDescriptionModeEnum.PreferredTableName:
                    return t('Table: {{name}}', {
                        name: qrDetails?.table?.preferredName || qrDetails?.table?.id || '',
                    });
                case MenuPageDescriptionModeEnum.TableId:
                    return t('Table: {{name}}', { name: qrDetails?.table?.id || '' });
                case MenuPageDescriptionModeEnum.TableName:
                    return t('Table: {{name}}', { name: qrDetails?.table?.tableName || qrDetails?.table?.id || '' });
                case MenuPageDescriptionModeEnum.NoDescription:
                default:
                    return null;
            }
        };

        if (vendor.config.menuPageMode) {
            return setDescription(vendor.config);
        }

        if (countryConfig.menuPageMode) {
            return setDescription(countryConfig);
        }

        return null;
    };

    /**
     * Gets the initial icon for the subheader.
     *
     * @returns {React.ReactElement|null} The rendered initial icon component, or null if not applicable.
     */
    const getInitialIcon = () => {
        if (vendor.config.onlyMenuVendor && !isForDrawerContent) {
            return null;
        }

        const arrowIcon = theme.direction === 'ltr' ? <KeyboardArrowLeftRounded /> : <KeyboardArrowRightRounded />;

        const handleOnClick = () => {
            if (vendor.config.onlyMenuVendor || isForDrawerContent) {
                toggleDrawerHandler?.(false);
            } else if (url.id === '_') {
                routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/loyalty/venues');
            } else {
                routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]');
            }
        };

        return (
            <IconButton
                data-qa-id="menu-back"
                sx={{
                    height: '24px',
                    width: '24px',
                    color: theme.qlub.palette.onSurfaceColors.highEmphasis,
                    marginRight: '16px',
                }}
                onClick={handleOnClick}
            >
                {arrowIcon}
            </IconButton>
        );
    };

    /**
     * Gets the styles for the subheader container.
     *
     * @returns {Object} The styles object.
     */
    const getSx = () => {
        return isForDrawerContent
            ? { marginTop: '16px', padding: ' 0px 16px 6px 16px' }
            : { padding: ' 8px 16px 6px 16px' };
    };

    /**
     * Sets the render props for a component.
     *
     * @returns {Object} The render props object with title, subTitle, initialIcon, CTA, sx and qaIds properties.
     */
    const callRenderProps = () => {
        return {
            title: getTitle(),
            subTitle: getDescription(),
            initialIcon: getInitialIcon(),
            CTA: <></>,
            sx: getSx(),
            qaIds: {
                titleId: 'menu-page-title',
                subTitleId: 'menu-page-description',
            },
        };
    };

    return (
        <div className={styles.subHeader}>
            <SubHeader {...callRenderProps()} />
            <Divider type="fullWidth" />
        </div>
    );
};

export default MenuSubHeader;
