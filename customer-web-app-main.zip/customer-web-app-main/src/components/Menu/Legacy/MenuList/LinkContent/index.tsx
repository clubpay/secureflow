import { ReactNode } from 'react';
import { KeyboardArrowLeftRounded, KeyboardArrowRightRounded } from '@mui/icons-material';
import { useTheme } from '@mui/material';
import classNames from 'classnames';
import { KImage } from '@qlub-dev/qlub-kit';

import styles from '../index.module.scss';

export interface ILinkContentProps {
    vendorTitle: string;
    title: ReactNode;
    image?: string;
    description?: ReactNode;
    advancedView?: boolean;
}

const LinkContent = ({ vendorTitle, image, title, description, advancedView }: ILinkContentProps) => {
    const theme = useTheme();
    return (
        <div className={styles.linkContainer}>
            {image && <KImage src={image} alt={vendorTitle} />}
            <div
                className={classNames(image ? styles.linkContentImg : styles.linkContent, {
                    [styles.noDescription]: !description,
                })}
            >
                <h1 className={description || advancedView ? styles.titleDescription : styles.title}>
                    {title}
                    {theme.direction === 'ltr' ? <KeyboardArrowRightRounded /> : <KeyboardArrowLeftRounded />}
                </h1>
                {description}
            </div>
        </div>
    );
};

export default LinkContent;
