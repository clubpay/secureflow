import React, { Dispatch, FC, SetStateAction, useEffect, useMemo, useState } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { Button } from '@qlub-dev/qlub-kit';
import MenuList from '@/components/Menu/MenuList';
import PDFWidget from '@/components/Menu/PDF';
import { Drawer } from '@mui/material';
import { IQrDetailsResponse, IRestaurant, MenuModeEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import classNames from 'classnames';
import { ThemeModeEnum } from '@clubpay/customer-common-module/src/context/config';
import { IMenuLinks, ISelectedMenuLink } from '@/views/Menu/Menu/types';
import MenuTabs from '@/components/Menu/Tabs/Tabs';
import MenuSubHeader from '@/components/Menu/SubHeader/MenuSubHeader';
import {
    convertMultiLocaleStringToObject,
    getLocaleText,
} from '@clubpay/customer-common-module/src/component/MultiLocale';
import useMenuEventsCenter from '@/hooks/menuEventsCenter';

import styles from './index.module.scss';

interface IMenuContentProps {
    vendor: IRestaurant;
    lang: string;
    theme: any;
    qrDetails?: IQrDetailsResponse;
    countryConfig: IConfig;
    setLoading: Dispatch<SetStateAction<boolean>>;
    loading: boolean;
}

const MenuContent: FC<IMenuContentProps> = ({ vendor, lang, theme, qrDetails, countryConfig, setLoading, loading }) => {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const { routerPush, theme: qlubTheme, url } = useQlubRouter();
    const {
        menu: { viewBillwithPayBillCTAEvent, viewBillwithoutPayBillCTAEvent, viewBillClickPayBillCTAEvent },
    } = useMenuEventsCenter();
    const [selectedMenu, setSelectedMenu] = useState<ISelectedMenuLink | undefined>(undefined);
    const [drawerOpen, setDrawerOpen] = useState(false);
    const [, setMultiLink] = useState(false);

    const menuLink = useMemo(() => {
        const { menuMode, languageBasedMenu } = vendor?.config || {};
        const pdfMenu = menuMode === MenuModeEnum.PdfMenuIOSRedirect || menuMode === MenuModeEnum.PDFMenu;
        if (!pdfMenu) {
            return vendor?.externalMenuUrl;
        }
        const localesObject = convertMultiLocaleStringToObject(languageBasedMenu || '', lang);
        const availableLocalesArray = Object.values(localesObject).filter(Boolean);
        const link = getLocaleText(languageBasedMenu || '', lang, 'en');
        return link || vendor?.externalMenuUrl || availableLocalesArray[0];
    }, [vendor?.config?.languageBasedMenu, lang, vendor?.externalMenuUrl, vendor?.config?.menuMode]);

    const toggleDrawerHandler = (open: boolean, menu?: ISelectedMenuLink) => {
        if (open) {
            setSelectedMenu(menu);
            setTimeout(() => {
                setDrawerOpen(open);
            }, 100);
        } else {
            setDrawerOpen(open);
            setTimeout(() => {
                setSelectedMenu(undefined);
            }, 100);
        }
    };

    const iframeLoadHandler = () => {
        console.log('iframe loaded');
    };

    const getMenuLinks = (): IMenuLinks | null => {
        try {
            if (vendor?.config?.menuLinks) {
                return JSON.parse(vendor.config.menuLinks) as IMenuLinks;
            }
        } catch (err) {
            console.log('Error parsing JSON at get menu links:', err, vendor?.config);
        }
        return null;
    };

    const menuContent = useMemo(() => {
        if (!vendor) {
            return null;
        }

        const getMultiMenu = (ml: IMenuLinks | null) => {
            return <MenuList menuLinks={ml} toggleDrawer={toggleDrawerHandler} vendorTitle={vendor.title} />;
        };

        const getExternalMenu = () => {
            return (
                <div className={styles.iframe}>
                    <iframe
                        title="External Menu"
                        src={vendor.config.externalMenuUrl}
                        onError={(err: any) => {
                            enqueueSnackbar(err.message, { variant: 'error' });
                        }}
                        onLoad={iframeLoadHandler}
                    />
                </div>
            );
        };

        const getPDFMenu = () => {
            return (
                <div className={styles.pdfWrapper}>
                    <PDFWidget url={menuLink} priority={vendor.config?.pdfPriority || []} isCalledFromDrawer />
                </div>
            );
        };

        const getMultiMenuTab = () => {
            const menuLinks = getMenuLinks();

            if (!(menuLinks?.links && menuLinks?.links?.length > 0 && menuLinks?.links.some((link) => link?.status))) {
                setMultiLink(false);
                return null;
            }

            setMultiLink(true);

            return <MenuTabs menuLinks={menuLinks} vendor={vendor} />;
        };

        const getDefault = () => {
            const menuLinks = getMenuLinks();

            if (menuLinks?.links && menuLinks?.links.length > 0 && menuLinks?.links.some((link) => link?.status)) {
                setMultiLink(true);

                return getMultiMenu(menuLinks);
            }

            setMultiLink(false);

            if (vendor.config?.externalMenuUrl) {
                return getExternalMenu();
            }

            if (menuLink) {
                return getPDFMenu();
            }

            return null;
        };

        setMultiLink(false);

        switch (vendor.config?.menuMode) {
            default:
                return getDefault();
            case MenuModeEnum.ExternalUrl:
            case MenuModeEnum.ExternalUrlSameTab:
                return getExternalMenu();
            case MenuModeEnum.PdfMenuIOSRedirect:
            case MenuModeEnum.PDFMenu:
                return getPDFMenu();
            case MenuModeEnum.MultiMenuTab:
                return getMultiMenuTab();
            case MenuModeEnum.MultiMenu:
                const menuLinks = getMenuLinks();

                if (menuLinks?.links && menuLinks?.links.length > 0 && menuLinks?.links.some((link) => link.status)) {
                    setMultiLink(true);
                    return getMultiMenu(menuLinks);
                }
        }

        return getDefault();
    }, [lang, vendor, theme?.direction]);

    useEffect(() => {
        if (menuContent && !loading && !vendor?.config?.onlyMenuVendor) {
            if (vendor?.config?.enableMenuCTAButton !== false) {
                viewBillwithPayBillCTAEvent();
            } else {
                viewBillwithoutPayBillCTAEvent();
            }
        }
    }, [vendor, menuContent, loading]);

    const renderCTA = () => {
        if (
            !menuContent ||
            loading ||
            vendor?.config?.onlyMenuVendor ||
            drawerOpen ||
            !vendor?.config?.enableMenuCTAButton ||
            !url.id ||
            url.id === '_'
        ) {
            return null;
        }

        const ctaButtonText =
            getLocaleText(vendor?.config?.menuCTAButtonText || '', lang, '') || t('Pay when you are ready');

        const handleOnClick = () => {
            viewBillClickPayBillCTAEvent();
            routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice', {
                source: 'landingPage',
            });
        };

        return (
            <Button
                data-qa-id="menu-pay-bill"
                variant="outlined"
                className={styles.payButton}
                sx={{
                    width: 'calc(100% - 48px)',
                    position: 'fixed',
                    bottom: 96,
                    left: '50%',
                    transform: 'translateX(-50%)',
                    height: '48px',
                    color: theme?.qlub?.palette?.onSurfaceColors?.highEmphasis,
                    boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
                    ':hover': {
                        backgroundColor: qlubTheme === ThemeModeEnum.Black ? '#fff' : '#F9F6FD',
                    },
                }}
                disableRipple
                onClick={handleOnClick}
            >
                {ctaButtonText}
            </Button>
        );
    };

    const drawerMenuContent = useMemo(() => {
        if (!selectedMenu) {
            return null;
        }

        return (
            <Drawer
                anchor="bottom"
                open={drawerOpen}
                onClose={() => toggleDrawerHandler(false)}
                BackdropProps={{ sx: { background: '#00000099' } }}
                PaperProps={{
                    elevation: 0,
                    sx: {
                        height: '100vh',
                        background: 'white',
                        position: 'relative',
                        maxWidth: '552px',
                        width: '100%',
                    },
                }}
                sx={{ display: 'flex', justifyContent: 'center' }}
            >
                <MenuSubHeader
                    vendor={vendor}
                    qrDetails={qrDetails}
                    url={url}
                    theme={theme}
                    countryConfig={countryConfig}
                    isForDrawerContent
                    toggleDrawerHandler={toggleDrawerHandler}
                />
                <div className={styles.drawer}>
                    {selectedMenu && (
                        <PDFWidget
                            url={selectedMenu?.languageBasedMenuLink}
                            priority={selectedMenu?.pdfPriority}
                            isCalledFromDrawer
                        />
                    )}
                </div>
            </Drawer>
        );
    }, [selectedMenu, lang, drawerOpen, countryConfig]);

    useEffect(() => {
        setTimeout(() => {
            setLoading(false);
        }, 150);
    }, [menuContent]);

    return (
        <>
            <div
                className={classNames({
                    [styles.onlyMenuContent]: vendor?.config?.onlyMenuVendor,
                    [styles.menuContent]: !vendor?.config?.onlyMenuVendor,
                })}
            >
                <>
                    {menuContent}
                    {renderCTA()}
                </>
                {drawerMenuContent}
            </div>
        </>
    );
};

export default MenuContent;
