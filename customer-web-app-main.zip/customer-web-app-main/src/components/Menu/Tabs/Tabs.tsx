import * as React from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import MultiLocale from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useMemo } from 'react';
import { Grid } from '@mui/material';
import PDFWidget from '@/components/Menu/PDF';
import { IMenuLinks } from '@/views/Menu/Menu/types';

interface TabPanelProps {
    children?: React.ReactNode;
    index: number;
    value: number;
}

function TabPanel(props: TabPanelProps) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 3 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

function a11yProps(index: number) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

export default function MenuTabs({ menuLinks, vendor }: { menuLinks: IMenuLinks; vendor: any }) {
    const [value, setValue] = React.useState(0);
    const { lang } = useQlubRouter();

    const currentLinks = menuLinks.links;

    const handleChange = (event: React.SyntheticEvent, newValue: number) => {
        setValue(newValue);
    };

    const renderTabs = useMemo(() => {
        return currentLinks?.map((link, index) => {
            if (!link.status) {
                return null;
            }

            const menuLink =
                link?.linkWithLocale?.find((item) => item.locale === lang)?.value ||
                link?.linkWithLocale?.find((item) => item.locale === 'en')?.value ||
                link?.link ||
                '';

            return (
                <Tab
                    sx={{
                        textTransform: 'none',
                    }}
                    key={menuLink}
                    label={<MultiLocale value={link.title} lang={lang} />}
                    {...a11yProps(index)}
                />
            );
        });
    }, [currentLinks, lang]);

    const renderTabPanels = useMemo(() => {
        return currentLinks?.map((link, index) => {
            if (!link.status) {
                return null;
            }
            const menuLink =
                link?.linkWithLocale?.find((item) => item.locale === lang)?.value ||
                link?.linkWithLocale?.find((item) => item.locale === 'en')?.value ||
                link?.link ||
                '';

            return (
                <TabPanel key={menuLink} value={value} index={index}>
                    <Grid container item xs={12}>
                        <PDFWidget url={menuLink} priority={vendor.config.pdfPriority || []} isCalledFromDrawer />
                    </Grid>
                </TabPanel>
            );
        });
    }, [currentLinks, value]);

    return (
        <Box sx={{ width: '100%' }}>
            <Box
                sx={{
                    borderBottom: 1,
                    borderColor: 'divider',
                    position: 'sticky',
                }}
            >
                <Tabs value={value} onChange={handleChange} variant="scrollable" scrollButtons="auto">
                    {renderTabs}
                </Tabs>
            </Box>
            {renderTabPanels}
        </Box>
    );
}
