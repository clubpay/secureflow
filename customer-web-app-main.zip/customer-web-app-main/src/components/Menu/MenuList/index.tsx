import React, { useMemo } from 'react';
import { ISelectedMenuLink, IMenuLinks, MenuColor } from '@/views/Menu/Menu/types';
import { isIOS } from '@clubpay/customer-common-module/src/utility/k_user_agent';
import { useTheme } from '@mui/material';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import MultiLocale, { validateMultiLocale } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { Button, CustomerContainer, Divider, QlubKitTheme } from '@qlub-dev/qlub-kit';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import LinkContent, { ILinkContentProps } from './LinkContent';

import styles from './index.module.scss';

// TODO Burak: change with design system colors
const colorOptions = {
    green: {
        backgroundColor: '#BAEAD6',
    },
    pink: {
        backgroundColor: '#FCEDEC',
    },
    purple: {
        backgroundColor: '#EFE0FA',
    },
    orange: {
        backgroundColor: '#FEDBA2',
    },
    blue: {
        backgroundColor: '#BBE1FF',
    },
    default: {
        backgroundColor: QlubKitTheme.qlub.palette.destructive.main,
    },
};

interface IMenuLinkProps extends ILinkContentProps {
    onClick: any;
    onLinkClick: any;
    color: MenuColor;
    iOS: boolean;
    link: string;
    redirect?: boolean;
    newTab?: boolean;
    advancedView?: boolean;
}

const MenuLink = ({
    image,
    link,
    title,
    vendorTitle,
    description,
    color,
    redirect,
    iOS,
    newTab,
    onClick,
    onLinkClick,
    advancedView,
}: IMenuLinkProps) => {
    return (
        <div
            onClick={onClick}
            className={styles.link}
            style={image ? { background: 'transparent' } : colorOptions[color] || colorOptions.default}
        >
            {redirect || iOS ? (
                <a href={link} target={newTab ? '_blank' : '_self'} rel="noopener noreferrer" data-testid="LinkButton">
                    <LinkContent
                        vendorTitle={vendorTitle}
                        title={title}
                        image={image}
                        description={description}
                        advancedView={advancedView}
                    />
                </a>
            ) : (
                <Button type="button" variant="text" data-testid="LinkButton" onClick={onLinkClick}>
                    <LinkContent
                        vendorTitle={vendorTitle}
                        title={title}
                        image={image}
                        description={description}
                        advancedView={advancedView}
                    />
                </Button>
            )}
        </div>
    );
};

interface IProps {
    menuLinks: IMenuLinks | null;
    vendorTitle: string;
    toggleDrawer: (open: boolean, link: ISelectedMenuLink) => void;
}

export default function MenuList({ menuLinks, vendorTitle, toggleDrawer }: IProps) {
    const { lang } = useQlubRouter();
    const theme = useTheme();

    const iOS = useMemo(() => isIOS(), []);

    const menuItemClickHandler = () => {
        onPushEvent(`tapOnMenulinks`, {
            vendor: vendorTitle,
            diningSessionId: '',
        });
    };

    const menuLinksContent = useMemo(() => {
        return menuLinks?.links?.map((link) => {
            if (!link) {
                return null;
            }

            const menuLink =
                link?.linkWithLocale?.find((item) => item.locale === lang)?.value ||
                link?.linkWithLocale?.find((item) => item.locale === 'en')?.value ||
                link?.link ||
                '';

            return (
                link.status &&
                link.title.find((item) => item.locale === lang)?.value !== '' && (
                    <>
                        <MenuLink
                            onClick={() => {
                                menuItemClickHandler();
                            }}
                            onLinkClick={() => {
                                toggleDrawer(true, {
                                    link,
                                    languageBasedMenuLink: menuLink,
                                    pdfPriority: menuLinks?.pdfPriority || [],
                                });
                            }}
                            color={link.color}
                            iOS={iOS}
                            redirect={link.redirect}
                            link={menuLink}
                            newTab={link.newTab}
                            vendorTitle={vendorTitle}
                            title={<MultiLocale value={link.title} lang={lang} />}
                            image={menuLinks.advanced ? link.image : undefined}
                            advancedView={menuLinks.advanced}
                            description={
                                validateMultiLocale(link.description) && (
                                    <MultiLocale value={link.description} lang={lang} Component="p" />
                                )
                            }
                        />
                        {menuLinks.advanced && <Divider />}
                    </>
                )
            );
        });
    }, [iOS, menuLinks, lang, theme.direction]);

    return (
        <CustomerContainer
            centered
            sx={{
                height: '100%',
                width: '100%',
                display: 'flex',
                flexDirection: 'column',
                padding: '0px',
            }}
            direction="column"
            gap="sm"
            padding="xs"
            className={styles.mainContainer}
        >
            <div className={styles.links}>{menuLinksContent}</div>
        </CustomerContainer>
    );
}
