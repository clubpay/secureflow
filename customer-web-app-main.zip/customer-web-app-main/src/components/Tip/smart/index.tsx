import { forwardRef, useCallback, useEffect, useImperativeHandle, useMemo, useState } from 'react';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import {
    SmartTipModalEventConditionEnum,
    SmartTipModalTriggerPointConditionEnum,
} from '@clubpay/customer-common-module/src/repository/vendor';
import useTipStore from '@/store/tip';
import { Collapse } from '@mui/material';
import { IPaymentDetails } from '@/repositories/bill';
import { calculateSmartTip, findMatchingStepSizes } from './calculations';
import OneLiner from './components/one-liner';
import BottomSheet from './components/bottom-sheet';
import useGetFirstNonZeroTip from './hooks/min-tip';
import {
    checkModalAvailabilityBasedOnEventCondition,
    getSmartTipModalShown,
    setSmartTipModalOrigin,
    setSmartTipModalShown,
} from './utils';
import useSmartTipGAEvents from './hooks/smart-tip-ga';
import useFetchStepSizeRanges from './hooks/fetch-step-size-ranges';

interface IProps {
    details: IPaymentDetails;
    onChange: (value: number) => void;
}

export interface ISmartTipModalHandler {
    toggleDrawer: (open: boolean, origin?: SmartTipModalTriggerPointConditionEnum) => boolean;
}

const SmartTip = forwardRef<ISmartTipModalHandler, IProps>(({ details, onChange }, ref) => {
    const [isPayingSmartTip, setIsPayingSmartTip] = useState<boolean | undefined>(undefined);
    const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

    const normalTip = useTipStore((state) => state.normalTip);
    const isDirty = useTipStore((state) => state.isDirty);
    const nonModalDefaultTipOption = useTipStore((state) => state.nonModalDefaultTipOption);
    const isSmartTipOneLinerVisible = useTipStore((state) => state.isSmartTipOneLinerVisible);

    const updateNormalTipVisibility = useTipStore((state) => state.updateNormalTipVisibility);
    const updateSmartTipOneLinerVisibility = useTipStore((state) => state.updateSmartTipOneLinerVisibility);

    const { vendor } = useVendor();
    const { config: countryConfig } = useConfigContext();

    const firstNonZeroTip = useGetFirstNonZeroTip({
        billAmount: details.billNumber.total,
        yourShareAmount: details.billNumber.yourShare,
        remainingAmount: details.billNumber.remaining,
        hasUserPaid: details.yourSplitSettings.paymentDone || false,
        payableAmount: details.billNumber.payableAmount,
    });

    const { stepSizeRanges, isError: hasStepSizeFetchingFailed, isLoading } = useFetchStepSizeRanges();

    const triggerPoint = vendor?.config?.smartTipModalTriggerCondition ?? countryConfig?.smartTipModalTriggerCondition;

    const triggerEvent =
        vendor?.config?.smartTipModalEventCondition ??
        countryConfig?.smartTipModalEventCondition ??
        SmartTipModalEventConditionEnum.Interaction;

    const hasModalAlreadyBeenShown = getSmartTipModalShown();

    const smartTip = useMemo(() => {
        if (hasStepSizeFetchingFailed || !stepSizeRanges || isLoading) {
            return 0;
        }

        const stepSizes = findMatchingStepSizes(details.billNumber.yourShare, stepSizeRanges);

        return calculateSmartTip(details.billNumber.yourShare, firstNonZeroTip, stepSizes);
    }, [details, firstNonZeroTip, stepSizeRanges, hasStepSizeFetchingFailed, isDirty, isLoading, normalTip]);

    const gaEvents = useSmartTipGAEvents({
        smartTip,
        eventTrigger: triggerEvent,
        preRoundingBill: details.billNumber.yourShare,
    });

    useEffect(() => {
        onChange(isPayingSmartTip ? smartTip : 0);
    }, [isPayingSmartTip, smartTip]);

    const toggleDrawer = useCallback(
        (open: boolean, origin?: SmartTipModalTriggerPointConditionEnum): boolean => {
            if (open) {
                if (hasModalAlreadyBeenShown) {
                    return false;
                }

                if (isPayingSmartTip || smartTip <= 0) {
                    return false;
                }

                if (origin && origin !== triggerPoint) {
                    return false;
                }

                // smart tip modal should not be shown if user is proceeding with default tip
                if (
                    nonModalDefaultTipOption !== undefined &&
                    nonModalDefaultTipOption > 0 &&
                    nonModalDefaultTipOption === normalTip?.amount
                ) {
                    return false;
                }

                if (!checkModalAvailabilityBasedOnEventCondition(triggerEvent, isDirty, normalTip?.finalValue)) {
                    return false;
                }
            }

            setTimeout(() => {
                setIsModalOpen(open);

                if (open) {
                    setSmartTipModalShown();
                    setSmartTipModalOrigin(origin);
                    gaEvents.modalDisplayed();
                }
            }, 800);

            return open;
        },
        [
            isPayingSmartTip,
            smartTip,
            normalTip,
            isDirty,
            isModalOpen,
            triggerEvent,
            triggerPoint,
            nonModalDefaultTipOption,
        ],
    );

    useImperativeHandle(
        ref,
        () => ({
            toggleDrawer,
        }),
        [toggleDrawer],
    );

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const toggleSwitch = (event: React.ChangeEvent<HTMLInputElement>) => {
        setIsPayingSmartTip((prev) => !prev);

        if (event.target.checked) {
            gaEvents.toggleOn();
        } else {
            gaEvents.toggleOff();
        }
    };

    const modalConfirmHandler = () => {
        setIsPayingSmartTip(true);
        toggleDrawer(false);

        updateNormalTipVisibility(false);
        updateSmartTipOneLinerVisibility(true);

        gaEvents.modalConfirmed();
    };

    const modalDismissHandler = () => {
        setIsPayingSmartTip(false);
        toggleDrawer(false);

        updateNormalTipVisibility(false);
        updateSmartTipOneLinerVisibility(true);

        gaEvents.modalDismissed();
    };

    const modalManualCloseHandler = () => {
        gaEvents.modalClosedWithCloseBtn();
    };

    const showOneLiner = isSmartTipOneLinerVisible && smartTip > 0;

    return (
        <>
            <Collapse in={showOneLiner}>
                <div>
                    <OneLiner isPayingSmartTip={!!isPayingSmartTip} toggleSwitch={toggleSwitch} smartTip={smartTip} />
                </div>
            </Collapse>
            <BottomSheet
                isOpen={isModalOpen}
                toggleDrawer={toggleDrawer}
                smartTip={smartTip}
                yourShareAmount={details.billNumber.yourShare}
                confirmHandler={modalConfirmHandler}
                dismissHandler={modalDismissHandler}
                manualCloseHandler={modalManualCloseHandler}
            />
        </>
    );
});

export default SmartTip;
