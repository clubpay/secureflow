import useEventsCenter from '@/hooks/eventsCenter';
import useTipStore from '@/store/tip';
import { SmartTipModalEventConditionEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { getSmartTipModalOrigin } from '../utils';

interface IProps {
    smartTip: number;
    eventTrigger: SmartTipModalEventConditionEnum;
    preRoundingBill: number;
}
const useSmartTipGAEvents = ({ smartTip, eventTrigger, preRoundingBill }: IProps) => {
    const { smartTip: gaEvents } = useEventsCenter();
    const mostCommonTipOption = useTipStore((state) => state.mostCommonTipOption);

    const origin = getSmartTipModalOrigin();

    const gaData = {
        isMostCommonTipEnabled: !!mostCommonTipOption,
        eventTrigger,
        preRoundingBill,
        smartTip,
        postRoundingBill: preRoundingBill + smartTip,
        triggerAction: origin,
    };

    const modalDisplayed = () =>
        gaEvents.tipRoundingModalDisplayed(
            gaData.isMostCommonTipEnabled,
            gaData.eventTrigger,
            gaData.preRoundingBill,
            gaData.smartTip,
            gaData.postRoundingBill,
            gaData.triggerAction,
        );

    const modalConfirmed = () =>
        gaEvents.tipRoundingSelectedOnModal(
            gaData.isMostCommonTipEnabled,
            gaData.eventTrigger,
            gaData.preRoundingBill,
            gaData.smartTip,
            gaData.postRoundingBill,
            gaData.triggerAction,
        );

    const modalDismissed = () =>
        gaEvents.tipRoundingNotSelectedOnModal(
            gaData.isMostCommonTipEnabled,
            gaData.eventTrigger,
            gaData.preRoundingBill,
            gaData.smartTip,
            gaData.postRoundingBill,
            gaData.triggerAction,
        );

    const modalClosedWithCloseBtn = () =>
        gaEvents.tipRoundingModalManuallyClosed(
            gaData.isMostCommonTipEnabled,
            gaData.eventTrigger,
            gaData.preRoundingBill,
            gaData.smartTip,
            gaData.postRoundingBill,
            gaData.triggerAction,
        );

    const toggleOn = () =>
        gaEvents.tipRoundingToggleOn(
            gaData.isMostCommonTipEnabled,
            gaData.eventTrigger,
            gaData.preRoundingBill,
            gaData.smartTip,
            gaData.postRoundingBill,
        );

    const toggleOff = () =>
        gaEvents.tipRoundingToggleOff(
            gaData.isMostCommonTipEnabled,
            gaData.eventTrigger,
            gaData.preRoundingBill,
            gaData.smartTip,
            gaData.postRoundingBill,
        );

    return {
        modalDisplayed,
        modalConfirmed,
        modalDismissed,
        modalClosedWithCloseBtn,
        toggleOn,
        toggleOff,
    };
};

export default useSmartTipGAEvents;
