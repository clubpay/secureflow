import { useTipOptions } from '@/components/Tip/normal/hooks/get-tip-options';
import { removeItemsFromArr } from '@/lib/utils';
import useTipCalculator from '@/components/Tip/normal/hooks/calculate-tip';

interface IProps {
    billAmount: number;
    yourShareAmount: number;
    remainingAmount: number;
    hasUserPaid: boolean;
    payableAmount: number;
}

const useGetFirstNonZeroTip = ({
    billAmount,
    yourShareAmount,
    remainingAmount,
    hasUserPaid,
    payableAmount,
}: IProps) => {
    const tipOptions = useTipOptions({
        isTipModal: false,
    });

    const { calculateTip } = useTipCalculator({
        billAmount,
        yourShareAmount,
        remainingAmount,
        hasUserPaid,
        payableAmount,
    });

    let filteredOptions = removeItemsFromArr(tipOptions, 0);
    filteredOptions = removeItemsFromArr(tipOptions, -1);

    filteredOptions.sort((a, b) => a - b);

    const firstNonZeroTipOption = filteredOptions[0];

    const firstNonZeroTipVal = calculateTip(firstNonZeroTipOption);

    return firstNonZeroTipVal;
};

export default useGetFirstNonZeroTip;
