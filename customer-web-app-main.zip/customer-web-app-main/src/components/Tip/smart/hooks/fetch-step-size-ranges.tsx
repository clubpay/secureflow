import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { ISmartTipStepSizeRange } from '@clubpay/customer-common-module/src/repository/vendor';
import { useEffect, useState } from 'react';

const useFetchStepSizeRanges = () => {
    const [stepSizeRanges, setStepSizes] = useState<ISmartTipStepSizeRange[]>();
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [isError, setIsError] = useState<boolean>(false);

    const { vendor } = useVendor();
    const { config: countryConfig } = useConfigContext();

    const stepSizesJSONURL = vendor?.config?.smartTipStepSizesJSONURL ?? countryConfig?.smartTipStepSizesJSONURL;

    useEffect(() => {
        if (!stepSizesJSONURL) {
            console.error('No step sizes JSON URL found');
            setIsError(true);
            return;
        }

        setIsLoading(true);

        fetch(stepSizesJSONURL)
            .then((res) => {
                if (!res.ok) {
                    throw new Error(`HTTP error! Status: ${res.status}`);
                }
                return res.json();
            })
            .then((data: ISmartTipStepSizeRange[]) => {
                setStepSizes(data);
            })
            .catch((error) => {
                console.error('Failed to fetch step sizes: ', error);
                setIsError(true);
            })
            .finally(() => setIsLoading(false));
    }, [stepSizesJSONURL]);

    return { stepSizeRanges, isLoading, isError };
};

export default useFetchStepSizeRanges;
