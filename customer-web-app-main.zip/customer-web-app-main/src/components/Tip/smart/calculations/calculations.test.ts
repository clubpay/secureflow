import { calculateSmartTip, ceilToStepSize, findMatchingStepSizes, sortStepSizesInDesc } from '.';
import stepSizeRanges from './test-data';

describe('smart-tip-calculations', () => {
    describe('ceilToStepSize', () => {
        test('ceilToStepSize should return the correct value when billValue % stepSize === 0', () => {
            expect(ceilToStepSize(10, 5)).toBe(10);
        });

        test('ceilToStepSize should return the correct value when stepSize > billValue', () => {
            expect(ceilToStepSize(12, 20)).toBe(20);
        });

        test('ceilToStepSize should return the correct value when stepSize = billValue', () => {
            expect(ceilToStepSize(13, 13)).toBe(13);
        });

        test('ceilToStepSize should return the correct value when stepSize < billValue', () => {
            expect(ceilToStepSize(125, 50)).toBe(150);
        });
    });

    describe('sort tip sizes', () => {
        test('should sort step sizes in desc order', () => {
            expect(sortStepSizesInDesc([10, 2, 50, 34])).toEqual([50, 34, 10, 2]);
        });
    });

    describe('find matching step sizes', () => {
        test('find step sizes in range of the provided bill value when bill value is in between margins', () => {
            expect(findMatchingStepSizes(405, stepSizeRanges.SORTED)).toEqual([50, 100]);
        });
        test('find step sizes in range of the provided bill value when bill value is equal to one of the max limits', () => {
            expect(findMatchingStepSizes(500, stepSizeRanges.SORTED)).toEqual([50, 100]);
        });
        test('find step sizes in range of the provided bill value when bill value is equal to one of the min limits', () => {
            expect(findMatchingStepSizes(300, stepSizeRanges.SORTED)).toEqual([20, 25]);
        });
        test('return an empty array when bill value is out of the provided limits', () => {
            expect(findMatchingStepSizes(999999, stepSizeRanges.SORTED)).toEqual([]);
        });
        test('find step sizes in range when only a single range is provided ', () => {
            expect(findMatchingStepSizes(150, stepSizeRanges.SINGLE_RANGE)).toEqual([25, 50]);
        });
        test('should return and empty array bill value is below provided range', () => {
            expect(findMatchingStepSizes(50, stepSizeRanges.SINGLE_RANGE)).toEqual([]);
        });
        test('should return and empty array when an no ranges are provided', () => {
            expect(findMatchingStepSizes(50, stepSizeRanges.EMPTY)).toEqual([]);
        });
        test('should return matching range when top range has an infinite max value', () => {
            expect(findMatchingStepSizes(100000, stepSizeRanges.INFINITE_MAX_RANGE)).toEqual([5000]);
        });
        test('find step sizes in range of the provided bill value when provided bill values are unordered', () => {
            expect(findMatchingStepSizes(405, stepSizeRanges.UNORDERED)).toEqual([50, 100]);
        });
    });

    describe('calculateSmartTip', () => {
        test('smart tip should RETURN SMART TIP FOR SECONDARY STEP SIZE when  (bill value with primary step size) > (bill value + 1st tip option with a value) > (bill value with secondary step size)', () => {
            expect(calculateSmartTip(101, 11, [20, 10])).toBe(9);
        });

        test('calculateSmartTip should RETURN 0 when  (bill value with primary step size) > (bill value with secondary step size) > (bill value + 1st tip option with a value)', () => {
            expect(calculateSmartTip(101, 5, [20, 10])).toBe(0);
        });

        test('calculateSmartTip should RETURN SMART TIP FOR PRIMARY STEP SIZE when  (bill value + 1st tip option with a value) > (bill value with primary step size) > (bill value with secondary step size)', () => {
            expect(calculateSmartTip(101, 25, [20, 10])).toBe(19);
        });

        test('calculateSmartTip should return correct value when step sizes are unordered', () => {
            expect(calculateSmartTip(101, 11, [10, 20])).toBe(9);
        });

        test('calculateSmartTip should return the optimal step size when step size count > 2', () => {
            expect(calculateSmartTip(101, 50, [20, 10, 5, 25, 100])).toBe(24);
        });
    });
});
