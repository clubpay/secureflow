import { ISmartTipStepSizeRange } from '@clubpay/customer-common-module/src/repository/vendor';

const ceilToStepSize = (billValue: number, stepSize: number): number => {
    if (billValue % stepSize === 0) {
        return billValue;
    }

    return billValue + (stepSize - (billValue % stepSize));
};

const sortStepSizesInDesc = (stepSizes: number[]): number[] => {
    return [...stepSizes].sort((a, b) => b - a);
};

const findMatchingStepSizes = (billValue: number, stepSizeRanges: ISmartTipStepSizeRange[]): number[] => {
    // sort in descending order of minBill
    const sortedStepSizeRanges = stepSizeRanges.slice().sort((a, b) => b.minBill - a.minBill);

    // -1 is used to denote INFINITY
    const matchingRange = sortedStepSizeRanges.find(
        (range) => billValue > range.minBill && (billValue <= range.maxBill || range.maxBill === -1),
    );

    return matchingRange ? matchingRange.stepSizes : [];
};

const calculateSmartTip = (billValue: number, tip: number, stepSizes: number[]): number => {
    // sort step sizes in descending order as a safety measure
    stepSizes = sortStepSizesInDesc(stepSizes);

    const ceiledBillValues = stepSizes.map((stepSize) => ceilToStepSize(billValue, stepSize));

    const billWithFirstNonZeroTip = billValue + tip;

    // find the first bill value that is less than the bill value with the first non-zero tip
    const billWithSmartTip = ceiledBillValues.find((ceiledBillValue) => ceiledBillValue < billWithFirstNonZeroTip);

    // if there is no bill value that is less than the bill value with the first non-zero tip, return 0 otherwise return the smart tip
    return billWithSmartTip ? billWithSmartTip - billValue : 0;
};

export { ceilToStepSize, sortStepSizesInDesc, calculateSmartTip, findMatchingStepSizes };
