const stepSizeRanges = {
    SORTED: [
        {
            minBill: 0,
            maxBill: 100,
            stepSizes: [5, 10],
        },
        {
            minBill: 100,
            maxBill: 300,
            stepSizes: [20, 25],
        },
        {
            minBill: 300,
            maxBill: 500,
            stepSizes: [50, 100],
        },
        {
            minBill: 500,
            maxBill: 1000,
            stepSizes: [200, 500],
        },
        {
            minBill: 1000,
            maxBill: 10000,
            stepSizes: [5000, 10000],
        },
    ],
    SINGLE_RANGE: [
        {
            minBill: 100,
            maxBill: 200,
            stepSizes: [25, 50],
        },
    ],
    EMPTY: [],
    INFINITE_MAX_RANGE: [
        {
            minBill: 0,
            maxBill: 100,
            stepSizes: [5, 10],
        },
        {
            minBill: 100,
            maxBill: 200,
            stepSizes: [20, 25],
        },
        {
            minBill: 300,
            maxBill: 500,
            stepSizes: [50, 100],
        },
        {
            minBill: 500,
            maxBill: 1000,
            stepSizes: [200, 500],
        },
        {
            minBill: 1000,
            maxBill: -1,
            stepSizes: [5000],
        },
    ],
    UNORDERED: [
        {
            minBill: 100,
            maxBill: 200,
            stepSizes: [20, 25],
        },
        {
            minBill: 300,
            maxBill: 500,
            stepSizes: [50, 100],
        },
        {
            minBill: 1000,
            maxBill: -1,
            stepSizes: [5000],
        },
        {
            minBill: 500,
            maxBill: 1000,
            stepSizes: [200, 500],
        },
        {
            minBill: 0,
            maxBill: 100,
            stepSizes: [5, 10],
        },
    ],
};

export default stepSizeRanges;
