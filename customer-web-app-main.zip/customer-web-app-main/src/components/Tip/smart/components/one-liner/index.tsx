import { FC } from 'react';
import DonateMoneyIcon from '@/assets/images/icons/donate-money';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import Switch from '@qlub-dev/qlub-kit/dist/components/Switch';
import { InfoIcon } from '@/assets/images/icons/info';
import { Price } from '@qlub-dev/qlub-kit';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import Tooltip from '@mui/material/Tooltip';

import styles from './index.module.scss';

interface IProps {
    isPayingSmartTip: boolean;
    toggleSwitch: (event: React.ChangeEvent<HTMLInputElement>) => void;
    smartTip: number;
}

const OneLiner: FC<IProps> = ({ isPayingSmartTip, toggleSwitch, smartTip }) => {
    const { t } = useTranslation();
    const { currencyFormat } = useVendor();

    return (
        <div className={styles.container}>
            <div className={styles.toggle__left}>
                <DonateMoneyIcon className={styles.donateMoneyIcon} />
                <div className={styles.msg}>
                    <TypographyT typo="title_sm">
                        {interpolateT(t('Round-up <amount> for tip'), {
                            amount: <Price value={smartTip.toString()} currencyFormat={currencyFormat} />,
                        })}
                    </TypographyT>
                    <Tooltip
                        title={interpolateT(t('smart_tip_tooltip_text small gesture with big impact'), {
                            tip: <Price value={smartTip.toString()} currencyFormat={currencyFormat} />,
                        })}
                    >
                        <div className={styles.infoIcon}>
                            <InfoIcon />
                        </div>
                    </Tooltip>
                </div>
            </div>
            <Switch checked={isPayingSmartTip} handleChange={toggleSwitch} />
        </div>
    );
};

export default OneLiner;
