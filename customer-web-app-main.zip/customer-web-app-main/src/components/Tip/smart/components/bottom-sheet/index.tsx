import { FC } from 'react';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import Divider from '@qlub-dev/qlub-kit/dist/components/Divider';
import Price from '@qlub-dev/qlub-kit/dist/components/Format';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import Button from '@qlub-dev/qlub-kit/dist/components/Button';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { SmartTipModalTriggerPointConditionEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import DonateMoneyIcon from '@/assets/images/icons/donate-money';
import Drawer from './drawer';

import styles from './index.module.scss';

interface IProps {
    isOpen: boolean;
    smartTip: number;
    yourShareAmount: number;
    toggleDrawer: (open: boolean, origin?: SmartTipModalTriggerPointConditionEnum) => boolean;
    confirmHandler: () => void;
    dismissHandler: () => void;
    manualCloseHandler: () => void;
}

const BottomSheet: FC<IProps> = ({
    isOpen,
    smartTip,
    yourShareAmount,
    toggleDrawer,
    confirmHandler,
    dismissHandler,
    manualCloseHandler,
}) => {
    const { currencyFormat } = useVendor();
    const { t } = useTranslation();

    const tip = smartTip.toString();
    const totalWithSmartTip = (yourShareAmount + smartTip).toString();

    return (
        <Drawer isOpen={isOpen} toggleDrawer={toggleDrawer} manualCloseHandler={manualCloseHandler}>
            <div className={styles.container}>
                <div className={styles.body}>
                    <div className={styles.icon}>
                        <DonateMoneyIcon />
                    </div>
                    <div className={styles.description}>
                        <TypographyT typo="title_md">
                            {interpolateT(t('Round up the bill to <total> by tipping <tip>?'), {
                                total: <Price value={totalWithSmartTip} currencyFormat={currencyFormat} />,
                                tip: <Price value={tip} currencyFormat={currencyFormat} />,
                            })}
                        </TypographyT>
                        <TypographyT typo="caption_overline">
                            {interpolateT(t('<tip> will go to your waiter'), {
                                tip: <Price value={tip} currencyFormat={currencyFormat} />,
                            })}
                        </TypographyT>
                    </div>
                </div>
                <Divider type="fullWidth" />
                <div className={styles.billSummary}>
                    <div className={styles.youPay}>
                        <TypographyT typo="title_md">{t('You pay')}</TypographyT>
                        <Price value={totalWithSmartTip} currencyFormat={currencyFormat} bold />
                    </div>
                    <TypographyT
                        typo="caption_overline"
                        sx={{
                            color: 'var(--onSurfaceColors-disabled)',
                        }}
                    >
                        {t('Includes tip, taxes and charges')}
                    </TypographyT>
                </div>
                <div className={styles.btns}>
                    <Button variant="containedLight" fullWidth onClick={dismissHandler}>
                        {t('Later')}
                    </Button>
                    <Button variant="contained" fullWidth onClick={confirmHandler}>
                        {t('Round up')}
                    </Button>
                </div>
            </div>
        </Drawer>
    );
};

export default BottomSheet;
