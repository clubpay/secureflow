import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { SmartTipModalTriggerPointConditionEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { SwipeableCustomerDrawer } from '@qlub-dev/qlub-kit/dist/components/Drawer';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import { FC } from 'react';

interface IProps {
    children: React.ReactNode;
    isOpen: boolean;
    toggleDrawer: (open: boolean, origin?: SmartTipModalTriggerPointConditionEnum) => boolean;
    manualCloseHandler: () => void;
}

const Drawer: FC<IProps> = ({ children, isOpen, toggleDrawer, manualCloseHandler }) => {
    const { t } = useTranslation();

    return (
        <SwipeableCustomerDrawer
            headerTitle={<TypographyT>{t('Show Your Appreciation')}</TypographyT>}
            open={isOpen}
            onClose={() => toggleDrawer(false)}
            onManualClose={() => manualCloseHandler()}
            onOpen={() => toggleDrawer(true)}
            disablePortal
            disableSwipeToOpen
            slotProps={{
                backdrop: {
                    sx: {
                        background: '#00000099',
                    },
                },
            }}
            PaperProps={{
                sx: {
                    maxWidth: '552px',
                    margin: '0 auto',
                    background: '#fff',
                    borderRadius: '2rem 2rem 0 0',
                },
            }}
        >
            {children}
        </SwipeableCustomerDrawer>
    );
};

export default Drawer;
