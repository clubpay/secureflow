import {
    SmartTipModalEventConditionEnum,
    SmartTipModalTriggerPointConditionEnum,
} from '@clubpay/customer-common-module/src/repository/vendor';
import { qlubSessionStorage } from '@clubpay/customer-common-module/src/service/storage/sessionStorage';

const modalShownKey = 'qlub.tip.smart_tip__modal_shown';
const modalOriginKey = 'qlub.tip.smart_tip__modal_origin';

export const getSmartTipModalShown = () => {
    const shown = qlubSessionStorage.get(modalShownKey) === 'true';
    return shown || false;
};

export const setSmartTipModalShown = () => {
    qlubSessionStorage.set(modalShownKey, true);
};

export const getSmartTipModalOrigin = (): SmartTipModalTriggerPointConditionEnum | undefined => {
    const origin = qlubSessionStorage.get(modalOriginKey);
    return origin;
};

export const setSmartTipModalOrigin = (origin?: SmartTipModalTriggerPointConditionEnum) => {
    qlubSessionStorage.set(modalOriginKey, origin);
};

export const checkModalAvailabilityBasedOnEventCondition = (
    modalTriggerEvent: SmartTipModalEventConditionEnum,
    isDirty: boolean,
    tip?: number,
): boolean => {
    const isNormalTipZero = tip === undefined || tip <= 0;

    if (modalTriggerEvent === SmartTipModalEventConditionEnum.ZeroAmount) {
        if (isNormalTipZero) return true;
    } else if (modalTriggerEvent === SmartTipModalEventConditionEnum.Interaction) {
        if (!isDirty) return true;
    } else if (modalTriggerEvent === SmartTipModalEventConditionEnum.Both) {
        if (isNormalTipZero || !isDirty) return true;
    }

    return false;
};
