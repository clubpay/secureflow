import { TipModeEnum } from './enums';

export const PERCENTAGE_BASED_TIP_MODES = [
    TipModeEnum.Percentage,
    TipModeEnum.PercentageWithHint,
    TipModeEnum.PercentWithRoundUp,
    TipModeEnum.PercentWithHintAndRoundUp,
];

export const ROUNDING_ENABLED_TIP_MODES = [TipModeEnum.PercentWithRoundUp, TipModeEnum.PercentWithHintAndRoundUp];
