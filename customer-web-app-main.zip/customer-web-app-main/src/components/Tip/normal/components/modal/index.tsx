import { FC, useEffect, useMemo, useState } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import {
    IRestaurant,
    TipGamificationModeEnum,
    TipLabelType,
} from '@clubpay/customer-common-module/src/repository/vendor';
import { Button, Divider, SplitPriceLabel, SwipeableCustomerDrawer, TotalPrice, Typography } from '@qlub-dev/qlub-kit';
import TipInputs from '@/components/Tip/normal/components/inputs';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import useEventsCenter from '@/hooks/eventsCenter';
import { qlubSessionStorage } from '@clubpay/customer-common-module/src/service/storage/sessionStorage';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { IStaff } from '@/repositories/bill';
import { shouldNewPaymentModuleAcitvate } from '@/components/Bill/PaymentGateway/utils';
import { usePGGroupStore } from '@/store/pgGroup';
import { PaymentButtonForClient } from '@clubpay/payment-kit';
import { useGetInclusiveChargesMessage } from '@/hooks/getInclusiveChargesMessage';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { filterEmptyArrays } from '@/lib/utils';
import { IModalTrigger, ITip, TipToggleFunc } from '../../types';
import { TipToggleOriginEnum } from '../../enums';
import { useDefaultText } from '../../hooks/useDefaultText';

import styles from './index.module.scss';

const tipModal: { shown?: boolean } = {
    shown: undefined,
};

export const getTipModalShown = () => {
    tipModal.shown = qlubSessionStorage.get('qlub.tip.modal_shown') === 'true';
    return tipModal.shown || false;
};

export const setTipModalShown = (shown: boolean) => {
    tipModal.shown = shown;
    qlubSessionStorage.set('qlub.tip.modal_shown', shown ? 'true' : 'false');
};

interface IProps {
    open: boolean;
    billAmount: number;
    yourShareAmount: number;
    remainingAmount: number;
    currencyPrecision: number;
    currencySymbol: string;
    vendor: IRestaurant;
    lang: string;
    hasUserPaid: boolean;
    payableAmount: number;
    myTotal: number;
    disabled: boolean;
    hideFooter?: boolean;
    paymentHeight: number;
    tip: ITip;
    staff?: IStaff;
    onTipConfirm: (reshowTipBoxes: boolean) => void;
    modalTrigger: IModalTrigger;
    onOpenChange: TipToggleFunc;
    onChangeTip: (val: ITip, dirt?: boolean) => void;
    currencyFormat: CurrencyFormat;
}

const TipModal: FC<IProps> = ({
    open,
    billAmount,
    currencySymbol,
    yourShareAmount,
    remainingAmount,
    vendor,
    lang,
    hasUserPaid,
    payableAmount,
    currencyPrecision,
    myTotal,
    disabled,
    tip,
    staff,
    modalTrigger,
    onOpenChange,
    onChangeTip,
    onTipConfirm,
    paymentHeight,
    hideFooter,
    currencyFormat,
}) => {
    const { t } = useTranslation('common');
    const { config: countryConfig } = useConfigContext();
    const [clonedTip, setCloneTip] = useState<ITip>({
        amount: 0,
        finalValue: 0,
    });
    const [reservedTip, setReservedTip] = useState<ITip>({
        amount: 0,
        finalValue: 0,
    });
    const defaultTexts = useDefaultText({
        staff,
        isTipModal: true,
    });

    const { inclusiveChargesMessage } = useGetInclusiveChargesMessage({
        tip: clonedTip?.finalValue,
    });

    const isNewPaymentModule = shouldNewPaymentModuleAcitvate(
        vendor.country.config?.enableNewPaymentModule,
        vendor.config?.enableNewPaymentModule,
    );

    const { closeSnackbar } = snackBar();
    const { state } = usePGGroupStore((store) => store);

    const {
        tip: {
            tipModalConfirmEvents,
            tipModalCloseEvent,
            tipModalDisplayEvent,
            tipModalNotNowEnableEvent,
            tipModalActivePaymentEvent,
        },
    } = useEventsCenter();

    const hideNotNow = vendor.config.tipModalHideNotNow || countryConfig?.tipModalHideNotNow;

    useEffect(() => {
        closeSnackbar();
        tipModalDisplayEvent();
        if (hideFooter) {
            tipModalActivePaymentEvent();
        }
    }, []);

    useEffect(() => {
        if (!hideNotNow) {
            tipModalNotNowEnableEvent();
        }
    }, [hideNotNow]);

    useEffect(() => {
        setCloneTip(tip);
    }, [tip]);

    const changeTipHandler = (newState: ITip, dirty?: boolean) => {
        if (hideFooter) {
            onChangeTip(newState, dirty);
        } else {
            setCloneTip(newState);
        }
    };

    const modalTotal = sumAmounts(currencyPrecision, myTotal, clonedTip.finalValue ?? clonedTip.amount);

    const footerData = {
        priceData: [
            {
                label: 'yourShare' as SplitPriceLabel,
                value: (hideFooter ? myTotal : modalTotal) || yourShareAmount,
                text: t('You pay'),
                qaTextId: 'tip-modal-you-pay',
            },
        ],
        footer: inclusiveChargesMessage,
        firstButton: '',
        secondButton: '',
    };

    useEffect(() => {
        if (open) {
            setTipModalShown(true);
            setReservedTip(tip);
        }
    }, [open]);

    const confirmHandler = () => {
        onOpenChange(false, TipToggleOriginEnum.TipModal);
        onChangeTip(clonedTip);
        tipModalConfirmEvents(clonedTip);
        onTipConfirm(clonedTip?.finalValue !== 0 && clonedTip?.status !== 'notNow');
    };

    const closeModalHandler = () => {
        onOpenChange(false, TipToggleOriginEnum.TipModal);
        tipModalCloseEvent();
        setTimeout(() => {
            window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
        }, 100);
        if (hideFooter) {
            onChangeTip(reservedTip);
        }
        onTipConfirm(tip?.finalValue !== 0 && tip?.status !== 'notNow');
    };

    const minHeight = useMemo(() => {
        const hasGamification = () => {
            if (
                vendor?.config?.tipGamificationMode &&
                vendor?.config?.tipGamificationMode !== TipGamificationModeEnum.Default
            ) {
                return vendor?.config?.tipGamificationMode === TipGamificationModeEnum.GamificationOn;
            }
            return countryConfig?.tipGamificationMode === TipGamificationModeEnum.GamificationOn;
        };
        const hasCustomTip = () => {
            const options = filterEmptyArrays(vendor?.config?.tipOptions) || countryConfig?.tipOptions || [];
            return options?.indexOf(-1);
        };
        let min = 351;
        if (hasGamification()) {
            min += 94;
        }
        if (hasCustomTip()) {
            min += 56;
        }
        return `${min}px`;
    }, [vendor?.config?.tipGamificationMode, countryConfig?.tipGamificationMode]);

    return (
        <SwipeableCustomerDrawer
            headerTitle={defaultTexts.title}
            open={open}
            onClose={closeModalHandler}
            onOpen={() => {
                onOpenChange(true, TipToggleOriginEnum.TipModal);
            }}
            disablePortal
            disableSwipeToOpen
            PaperProps={{
                sx: {
                    maxWidth: '552px',
                    minHeight,
                    margin: '0 auto',
                    background: '#fff',
                    borderRadius: '30px 30px 0 0',
                },
            }}
            qaIds={{
                closeBtnId: 'tip-modal-close',
                titleId: 'tip-modal-title',
            }}
        >
            <Typography data-qa-id="tip-modal-description" typo="caption_overline" className={styles.caption}>
                {defaultTexts.caption}
            </Typography>
            <TipInputs
                billAmount={Number(billAmount)}
                remainingAmount={Number(remainingAmount)}
                yourShareAmount={Number(yourShareAmount)}
                currencyPrecision={currencyPrecision}
                currencySymbol={vendor?.country?.currencySymbol || ''}
                vendor={vendor}
                lang={lang || 'en'}
                hasUserPaid={hasUserPaid}
                payableAmount={payableAmount}
                modal
                disabled={disabled}
                disableTooltip
                tip={hideFooter ? tip : clonedTip}
                hideNotNow={hideNotNow}
                onChangeTip={changeTipHandler}
                modalTrigger={modalTrigger}
                currencyFormat={currencyFormat}
                tipLabelType={(vendor?.config?.tipLabelType || countryConfig?.tipLabelType) as TipLabelType}
            />
            <Divider type="fullWidth" sx={{ marginBottom: '4px' }} />
            <TotalPrice
                priceData={footerData.priceData}
                footerText={footerData.footer}
                qaFooterTextId="tip-modal-including"
                currencyFormat={{
                    ...currencyFormat,
                    currencyPrecision: currencyPrecision || currencyFormat?.currencyPrecision,
                    cs: currencySymbol || currencyFormat?.cs,
                }}
            />
            {hideFooter !== true ? (
                <div className={styles.footer}>
                    <Button
                        data-qa-id="tip-modal-add-tip"
                        variant="contained"
                        size="large"
                        fullWidth
                        disabled={disabled}
                        onClick={confirmHandler}
                    >
                        {!clonedTip.amount ? t('Pay with no tip') : t('Add tip')}
                    </Button>
                </div>
            ) : isNewPaymentModule ? (
                <div style={{ paddingTop: '25px' }}>
                    <PaymentButtonForClient
                        onClick={() => {
                            state?.paymentHandler?.();
                            onOpenChange(false, TipToggleOriginEnum.TipModal);
                        }}
                        name={state.currentlySelectedPGData.name}
                    >
                        {t('Pay')}
                    </PaymentButtonForClient>
                </div>
            ) : (
                <div className={styles.paymentPlaceholder} style={{ height: `${paymentHeight}px` }} />
            )}
        </SwipeableCustomerDrawer>
    );
};
export default TipModal;
