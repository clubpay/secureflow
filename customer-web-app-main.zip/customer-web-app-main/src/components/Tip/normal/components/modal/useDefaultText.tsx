import { IStaff } from '@/repositories/bill';
import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';

interface ITipHeader {
    title: string;
    caption: string;
    isCustomTipMessage: boolean;
}

interface IProps {
    staff?: IStaff;
}

export const useDefaultText = ({ staff }: IProps): ITipHeader => {
    const { lang } = useQlubRouter();
    const { t } = useTranslation('common');

    const { vendor } = useVendor();
    const { config: countryConfig } = useConfigContext();

    const showWaiterName = vendor?.config?.showWaiterName;

    const getCustomText = (header?: string, description?: string) => ({
        header: getLocaleText(header || '', lang, 'en'),
        description: getLocaleText(description || '', lang, 'en'),
    });

    const { header: restaurantHeader, description: restaurantDescription } = getCustomText(
        vendor?.config?.tipCustomHeader,
        vendor?.config?.tipCustomDescription,
    );

    const { header: countryHeader, description: countryDescription } = getCustomText(
        countryConfig?.tipCustomHeader,
        countryConfig?.tipCustomDescription,
    );

    const defaultTipTitle = t('Your tip matters');

    const defaultDescription =
        showWaiterName && staff !== null
            ? t(`All proceeds go directly to {{value}}`, {
                  value: staff?.name,
              })
            : t('All proceeds go directly to our staff!');

    return {
        title: restaurantHeader || countryHeader || defaultTipTitle,
        caption:
            !restaurantHeader && !countryHeader
                ? restaurantDescription || countryDescription || defaultDescription
                : restaurantHeader
                ? restaurantDescription || defaultDescription
                : countryDescription || defaultDescription,
        isCustomTipMessage: !!restaurantHeader || !!countryHeader || !!restaurantDescription || !!countryDescription,
    };
};
