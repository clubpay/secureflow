import React, { FC } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import { tipCalculateValue } from '@/components/Tip/normal/utils/tip';
import TipBoxV2 from '@qlub-dev/qlub-kit/dist/components/TipV2/TipBox';
import { Price, TipBox, TipV2 } from '@qlub-dev/qlub-kit';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { IRestaurant, TipLabelType } from '@clubpay/customer-common-module/src/repository/vendor';
import { useTipDescriptions } from '@/hooks/useTipDescriptions';
import { TipModeEnum } from '@/components/Tip/normal/enums';
import { ITip } from '../../../types';

interface IProps {
    vendor: IRestaurant | undefined;
    currencyPrecision: number;
    currencySymbol: string;
    tip: ITip;
    blackTheme: boolean;
    newVersion: boolean;
    showZeroValue?: boolean;
    onClick: () => void;
    currencyFormat: CurrencyFormat;
    option: number;
    hasMostCommon: boolean;
    mostCommonTip: number | undefined;
    tipMode: TipModeEnum;
    amount: number;
    convertAmount: (option: number) => number | JSX.Element;
    newRoundUpConfigs?: any | false;
    onTipSelect: (val: number) => () => void;
    shouldStretchBoxes: boolean;
    index: number;
    tipLabelType?: TipLabelType;
    isTipLabelType?: boolean;
    lang: string;
}

const NotNow: FC<IProps> = ({
    newVersion,
    tip,
    onClick,
    blackTheme,
    showZeroValue,
    currencySymbol,
    currencyPrecision,
    currencyFormat,
    isTipLabelType,
    option,
    onTipSelect,
    tipMode,
    amount,
    convertAmount,
    hasMostCommon,
    mostCommonTip,
    newRoundUpConfigs,
    vendor,
    tipLabelType,
    index,
    shouldStretchBoxes,
    lang,
}) => {
    const { t } = useTranslation('common');
    const [descriptions] = useTipDescriptions();

    if (newVersion) {
        if (isTipLabelType) {
            return (
                <TipV2
                    option={option}
                    tipSelectHandler={onTipSelect}
                    currencyFormat={currencyFormat}
                    tipMode={tipMode}
                    tip={tip.amount}
                    amount={amount}
                    convertAmount={convertAmount}
                    mostCommon={hasMostCommon ? (mostCommonTip === option ? t('Common') : '') : undefined}
                    tipCalculateValue={tipCalculateValue}
                    enableTipRounding={vendor?.config.enableTipRounding}
                    calculatedAmount={tipCalculateValue(
                        tipMode,
                        option,
                        amount,
                        vendor?.config.enableTipRounding,
                        newRoundUpConfigs,
                    ).toFixed(currencyPrecision)}
                    cancelIcon={!(isTipLabelType && tip.amount === 0)}
                    blackThemeStyle={blackTheme}
                    shouldStretchBoxes={shouldStretchBoxes}
                    tipLabelType={tipLabelType}
                    isTipLabelType={isTipLabelType}
                    index={index}
                    descriptions={descriptions}
                    lang={lang}
                />
            );
        }
        return (
            <TipBoxV2
                selected={tip.status === 'notNow'}
                onClick={onClick}
                blackThemeStyle={blackTheme}
                sx={{
                    minWidth: '62px',
                    width: '100%',
                }}
                shouldStretchBoxes={shouldStretchBoxes}
            >
                {showZeroValue ? (
                    <TypographyT typo="tip_single_line_percentage">
                        <Price
                            value="0"
                            currencyFormat={{
                                ...currencyFormat,
                                currencyPrecision: currencyPrecision || currencyFormat?.currencyPrecision,
                                cs: currencySymbol || currencyFormat?.cs,
                            }}
                            typo="tip_single_line_multi_line_top_currency_value"
                            currencyUnitTypo="tip_single_line_multi_line_top_currency_unit"
                        />
                    </TypographyT>
                ) : (
                    t('Not Now')
                )}
            </TipBoxV2>
        );
    }

    return (
        <TipBox type="text" selected={tip.status === 'notNow'} onClick={onClick} blackThemeStyle={blackTheme}>
            {showZeroValue ? (
                <Price
                    value="0"
                    currencyFormat={{
                        ...currencyFormat,
                        currencyPrecision: currencyPrecision || currencyFormat?.currencyPrecision,
                        cs: currencySymbol || currencyFormat?.cs,
                    }}
                />
            ) : (
                t('Not now')
            )}
        </TipBox>
    );
};

export default NotNow;
