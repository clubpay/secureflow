import React, { FC, useState } from 'react';
import { CustomTip, Typography } from '@qlub-dev/qlub-kit';
import Format from '@qlub-dev/qlub-kit/dist/components/Format';
import { ClickAwayListener } from '@mui/material';
import { extractFloatNumbers, faToEn, isValidNumber } from '@clubpay/customer-common-module/src/utility/localize';
import useEventsCenter from '@/hooks/eventsCenter';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { TipModeEnum } from '@/components/Tip/normal/enums';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IModalTrigger, ITip } from '../../../types';

import styles from './index.module.scss';

interface IProps {
    tip: ITip;
    mode: TipModeEnum;
    currencySymbol: string;
    currencyPrecision: number;
    blackTheme: boolean;
    modal: boolean | undefined;
    modalTrigger: IModalTrigger;
    onChangeTip: (data: ITip) => void;
    onFocus?: () => void;
    onBlur?: () => void;
}

const TipCustom: FC<IProps> = ({
    tip,
    mode,
    currencySymbol,
    currencyPrecision,
    blackTheme,
    modal,
    onChangeTip,
    onFocus,
    onBlur,
}: IProps) => {
    const { t } = useTranslation('common');
    const [enable, setEnable] = useState(false);
    const [focused, setFocused] = useState(false);
    const [controlledTipValue, setControlledTipValue] = useState('0');

    const { currencyFormat } = useVendor();
    const {
        tip: { tipBoxCustomTipEvents },
    } = useEventsCenter();

    const tipSelectHandler = () => () => {
        onFocus?.();
        setEnable(true);
        setFocused(true);
        onChangeTip({
            amount: -1,
            status: 'custom',
            finalValue: 0,
        });

        setControlledTipValue('0');
    };

    const blurHandler = () => {
        onBlur?.();
        setFocused(false);
        if (tip.amount === -1 && tip.finalValue === 0) {
            onChangeTip({
                amount: 0,
                finalValue: 0,
            });
            setControlledTipValue('0');
        }
    };

    const tipValueChangeHandler = (e: any) => {
        const inputValue: string = e.target.value;
        const enVal = faToEn(inputValue);
        const decimalWithPrecisionZero = currencyPrecision === 0 && /[.,]/.test(enVal);

        // limit key inputs
        const isValidInput = new RegExp(`^\\d*[,.]?\\d{0,${currencyPrecision}}$`).test(enVal);
        if (!decimalWithPrecisionZero && isValidInput && enVal.length < 11) {
            // remove non decimal point leading zeros
            const normalizedValue = enVal.replace(/^0+(?!\.)/, '');
            if (normalizedValue === '' || !isValidNumber(normalizedValue, true)) {
                setControlledTipValue('0');
                onChangeTip({
                    ...tip,
                    finalValue: 0,
                });
            } else {
                const finalNumericValue = parseFloat(
                    Math.max(0, parseFloat(extractFloatNumbers(normalizedValue, true))).toFixed(currencyPrecision || 2),
                );
                const finalStringValue = extractFloatNumbers(enVal, true);

                setControlledTipValue(finalStringValue);
                onChangeTip({
                    ...tip,
                    finalValue: finalNumericValue,
                });
            }
        }
    };

    const clickAwayHandler = () => {
        if (tip.status === 'custom' && enable && !modal) {
            tipBoxCustomTipEvents(tip);
        }

        setEnable(false);
    };

    return (
        <ClickAwayListener onClickAway={clickAwayHandler}>
            <div style={{ display: 'inline-flex' }}>
                <CustomTip
                    option={-1}
                    tipSelectHandler={tipSelectHandler}
                    tipMode={mode}
                    tip={tip.amount}
                    InputNode={
                        !enable && tip.finalValue !== 0 && tip.amount === -1 ? (
                            <Typography typo="body_sm" className={styles.selectedStyle} sx={{ pl: 1 }}>
                                {`${t('Custom tip')}: `}
                                <Format
                                    currencyFormat={currencyFormat}
                                    value={String(tip.finalValue)}
                                    sx={{ pl: '4px' }}
                                />
                            </Typography>
                        ) : (
                            <div className={styles.customTip}>
                                <Typography typo="caption_overline">{currencySymbol}</Typography>
                                <input
                                    className={styles.tipInput}
                                    value={controlledTipValue}
                                    ref={(inputRef) => inputRef && focused && inputRef.focus()}
                                    onChange={tipValueChangeHandler}
                                    onFocus={tipSelectHandler}
                                    onBlur={blurHandler}
                                    inputMode="decimal"
                                    placeholder="0"
                                    min="0"
                                />
                            </div>
                        )
                    }
                    title={t('Pay custom tip')}
                    blackThemeStyle={blackTheme}
                    selected={!enable && tip.finalValue !== 0 && tip.amount === -1}
                />
            </div>
        </ClickAwayListener>
    );
};

export default TipCustom;
