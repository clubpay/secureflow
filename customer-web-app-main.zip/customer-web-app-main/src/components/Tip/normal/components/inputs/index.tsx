import React, { FC, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Trivia } from '@qlub-dev/qlub-kit';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import {
    IRestaurant,
    TipLabelType,
    TipTooltipModeEnum,
    TipUIv2Enum,
} from '@clubpay/customer-common-module/src/repository/vendor';
import { convertMultiLocaleStringToObject } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { Box } from '@mui/material';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import classNames from 'classnames';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import useEventsCenter from '@/hooks/eventsCenter';
import { qlubLocalStorage } from '@clubpay/customer-common-module/src/service/storage/localStorage';
import { IsTipRoudUpConfigAvailable } from '@/components/Tip/normal/utils/rounding-calculations';
import { IStaff } from '@/repositories/bill';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { useTipBoxLabelLengthCheck } from '@qlub-dev/qlub-kit/dist/hooks';
import { useTipDescriptions } from '@/hooks/useTipDescriptions';
import NotNow from './not-now';
import TipItem from './item';
import TipCustom from './custom';
import Hint from './hint';
import useTipMode from '../../hooks/get-tip-mode';
import { IModalTrigger, ITip } from '../../types';
import { useTipOptions } from '../../hooks/get-tip-options';

import styles from './index.module.scss';
import useTipCalulator from '../../hooks/calculate-tip';

const qlubTooltipKey = 'qlub.tip.tooltip';

interface IProps {
    billAmount: number;
    yourShareAmount: number;
    remainingAmount: number;
    currencyPrecision: number;
    currencySymbol: string;
    vendor?: IRestaurant;
    lang: string;
    hasUserPaid: boolean;
    payableAmount: number;
    modal?: boolean;
    disabled: boolean;
    disableTooltip?: boolean;
    hideNotNow?: boolean;
    tip: ITip;
    modalTrigger: IModalTrigger;
    onChangeTip: (newState: ITip, dirty?: boolean) => void;
    onCustomFocus?: () => void;
    onCustomBlur?: () => void;
    staff?: IStaff;
    currencyFormat: CurrencyFormat;
    showHiddenTipBoxes?: boolean;
    tipLabelType?: TipLabelType;
}

const TipInputs: FC<IProps> = ({
    billAmount,
    currencySymbol,
    yourShareAmount,
    remainingAmount,
    vendor,
    lang,
    hasUserPaid,
    payableAmount,
    currencyPrecision,
    modal,
    disabled,
    disableTooltip,
    hideNotNow,
    tip,
    modalTrigger,
    onChangeTip,
    onCustomFocus,
    onCustomBlur,
    staff,
    currencyFormat,
    showHiddenTipBoxes,
    tipLabelType,
}) => {
    const [customTipIndex, setCustomTipIndex] = useState<number | undefined>();
    const [firstDelay, setFirstDelay] = useState(false);
    const [shouldStretchTipBoxes, setShouldStretchTipBoxes] = useState<boolean>(false);

    const isFirstTime = qlubLocalStorage.get(qlubTooltipKey);
    const [showTooltip, setShowTooltip] = useState(isFirstTime);

    const { config } = useConfigContext();
    const { t } = useTranslation('common');
    const { theme } = useQlubRouter();
    const { mode: tipMode } = useTipMode({ billAmount });

    const tipOptions = useTipOptions({ isTipModal: !!modal });

    const { calculateTip } = useTipCalulator({
        billAmount,
        yourShareAmount,
        remainingAmount,
        hasUserPaid,
        payableAmount,
    });

    const sortedTipOptions = tipOptions.filter((num) => num >= 0).sort((a, b) => a - b);
    const [descriptions] = useTipDescriptions();

    const isLengthyDescription = useTipBoxLabelLengthCheck({
        lang: lang || '',
        tipLabelType: tipLabelType || '',
        descriptions,
    });

    const [newVersion, showZeroValue] = useMemo(() => {
        const newVersionFn = () => {
            if (vendor?.config?.tipUIv2 === TipUIv2Enum.Enable) {
                return true;
            }

            if (vendor?.config?.tipUIv2 === TipUIv2Enum.Disable) {
                return false;
            }

            return config?.tipUIv2 === TipUIv2Enum.Enable;
        };

        const showZeroValueFn = () => {
            return vendor?.config?.tipShowZeroValue || config?.tipShowZeroValue;
        };

        return [newVersionFn(), showZeroValueFn()];
    }, [vendor?.config, config]);

    const isTipLabelType =
        newVersion &&
        (tipLabelType === 'satisfaction' ||
            tipLabelType === 'service' ||
            tipLabelType === 'stars' ||
            tipLabelType === 'ticks');
    const {
        tip: {
            tipBoxNotNowEnableEvent,
            tipBoxTipRemoveEvent,
            tipBoxTipSelectedEvent,
            tipBoxNoTipSelectedEvent,
            tipModalScrollEvent,
            tipBoxScrollEvent,
        },
    } = useEventsCenter();

    const newRoundUpConfigs = useMemo(() => {
        if (!vendor || !config) {
            return;
        }
        return IsTipRoudUpConfigAvailable(vendor, config);
    }, [vendor?.config.tipRoundingCRV, config?.tipRoundingCRV, vendor?.config.tipRoundingMTC, config?.tipRoundingMTC]);

    const amount = useMemo(() => {
        if (yourShareAmount > 0) {
            return yourShareAmount;
        }
        if (remainingAmount === 0 || (remainingAmount > 0 && hasUserPaid)) {
            return payableAmount;
        }
        if (remainingAmount > 0) {
            return remainingAmount;
        }
        return billAmount;
    }, [yourShareAmount, remainingAmount, billAmount]);

    const scrollTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const onScroll = (e: any) => {
        const element = e.currentTarget;
        const pushScrollEvent = (scrollPercentage: number) => {
            if (modal) {
                tipModalScrollEvent({
                    scroll_rate: `${scrollPercentage.toFixed()}%`,
                });
            } else {
                tipBoxScrollEvent({
                    scroll_rate: `${scrollPercentage.toFixed()}%`,
                });
            }
        };
        if (scrollTimeoutRef.current) {
            clearTimeout(scrollTimeoutRef.current);
        }
        if (element) {
            const scrollPercentage = (element.scrollLeft / (element.scrollWidth - element.clientWidth)) * 100;
            scrollTimeoutRef.current = setTimeout(() => {
                pushScrollEvent(scrollPercentage);
            }, 500);
        }
    };

    useEffect(() => {
        if (billAmount > 0 && !firstDelay) {
            setTimeout(() => {
                setFirstDelay(true);
            }, 2000);
        }
    }, [billAmount]);

    useEffect(() => {
        if (!config) {
            return;
        }

        let defaultAmount;

        if (!showHiddenTipBoxes) {
            if (modal) {
                defaultAmount = vendor?.config?.tipDefaultForTipModal ?? config.tipDefaultForTipModal;
            } else {
                defaultAmount = vendor?.config?.tipDefault ?? config.tipDefault;
            }
        }

        if (!modal && tipOptions.includes(0)) {
            tipBoxNotNowEnableEvent();
        }

        setCustomTipIndex(tipOptions.indexOf(-1));

        if (defaultAmount === 0 && tipOptions.includes(0)) {
            onChangeTip({
                amount: 0,
                status: 'notNow',
                finalValue: 0,
            });
        }

        if (defaultAmount) {
            onChangeTip({
                amount: defaultAmount,
                status: 'selected',
                finalValue: calculateTip(defaultAmount),
            });
        }
    }, [config, newRoundUpConfigs]);

    useEffect(() => {
        if (tip.amount > 0) {
            onChangeTip({
                amount: tip.amount,
                status: 'selected',
                finalValue: calculateTip(tip.amount),
            });
        }
    }, [amount]);

    useEffect(() => {
        if (!modal || !vendor?.config?.tipDefaultForTipModal) {
            return;
        }

        onChangeTip({
            amount: vendor?.config?.tipDefaultForTipModal,
            status: 'selected',
            finalValue: calculateTip(vendor?.config?.tipDefaultForTipModal),
        });
    }, [modal, vendor?.config?.tipDefaultForTipModal, vendor?.config?.tipMode]);

    const getVendorKey = (ven: IRestaurant) => {
        return `${qlubTooltipKey}_${ven.country.currencyCode}_${ven.unique}`;
    };

    useEffect(() => {
        if (!vendor) {
            return;
        }

        switch (vendor.config?.tipTooltip || '') {
            case TipTooltipModeEnum.Hide:
                setShowTooltip(false);
                break;
            case TipTooltipModeEnum.Show:
                if (isFirstTime) {
                    // diactivate for now
                    // setShowTooltip(true);
                }
                break;
            default:
                setShowTooltip(false);
                break;
        }
    }, [vendor]);

    useEffect(() => {
        let tipOptionCount = tipOptions.length;
        const doesContainCustomTip = tipOptions.indexOf(-1) !== -1;

        // custom tip does not appear as a tip box, hence it should be ignored when calculating tip box count
        if (doesContainCustomTip) {
            tipOptionCount -= 1;
        }

        setShouldStretchTipBoxes(tipOptionCount <= 4);
    }, [tipOptions]);

    const actionClickHandler = () => {
        setShowTooltip(false);
        qlubLocalStorage.set(qlubTooltipKey, 'true');
        if (vendor) {
            qlubLocalStorage.set(getVendorKey(vendor), 'true');
        }
    };

    const clearTip = useCallback(
        (tipValue: number) => {
            if (tip.status === 'selected' && tip.amount === tipValue) {
                if (!modal) {
                    tipBoxTipRemoveEvent(tipValue);
                }

                onChangeTip(
                    {
                        amount: 0,
                        status: undefined,
                        finalValue: 0,
                    },
                    true,
                );
            }
        },
        [tip.amount, tip.status, modal],
    );

    const tipSelectHandler = (val: number) => () => {
        if (val === -1 || disabled) {
            return;
        }

        if (tip.status === 'selected' && tip.amount === val) {
            clearTip(val);
            return;
        }

        if (val > 0) {
            tipBoxTipSelectedEvent(val);
        }

        onChangeTip(
            {
                amount: val,
                status: 'selected',
                finalValue: calculateTip(val),
            },
            true,
        );
    };

    const tipMessage = useMemo(() => {
        const defaultText = t('Tipping is the best way to appreciate people’s hard work');
        return (
            convertMultiLocaleStringToObject(
                vendor?.config?.tipReminderContent || config?.tipReminderContent || '',
                defaultText,
            )[lang] || defaultText
        );
    }, [vendor?.config?.tipReminderContent, config?.tipReminderContent, lang, t]);

    const [hasMostCommon, mostCommonTip] = useMemo(() => {
        return [
            tipOptions.some(
                (option) =>
                    vendor?.config?.mostCommonTip === option ||
                    (!vendor?.config?.mostCommonTip && config?.mostCommonTip === option),
            ),
            vendor?.config?.mostCommonTip ?? config?.mostCommonTip,
        ];
    }, [tipOptions]);

    useEffect(() => {
        if (modal || !firstDelay) {
            return;
        }

        const tipEl = document.querySelector(`#tip_${tip.amount}`);
        if (tipEl) {
            tipEl.scrollIntoView({
                behavior: 'smooth',
                inline: 'nearest',
                block: 'nearest',
            });
        }
    }, [tip, modal]);

    const convertAmount = (option: number) => {
        if (option >= 1000 && vendor?.posVendor?.config?.tipNumberAbbreviation) {
            return (
                <>
                    {Math.ceil(option / 1000)}
                    <span className={styles.unit}>{t('K')}</span>
                </>
            );
        }
        return option;
    };

    const notNowClickHandler = () => {
        if (!modal) {
            tipBoxNoTipSelectedEvent();
        }
        onChangeTip(
            {
                amount: 0,
                status: 'notNow',
                finalValue: 0,
            },
            true,
        );
    };

    const tipCustomChangeHandler = (val: ITip) => {
        if (disabled) {
            return;
        }

        onChangeTip(val, true);
    };

    const blackTheme = theme === 'black';

    const getNotNow = (option: number, index: number, key: string) => {
        if (modal && hideNotNow) {
            return;
        }

        return (
            <div key={key} className={classNames(styles.tipItem, styles.notNowContainer)}>
                <NotNow
                    tip={tip}
                    newVersion={newVersion}
                    currencyPrecision={currencyPrecision}
                    currencySymbol={currencySymbol}
                    blackTheme={blackTheme}
                    showZeroValue={showZeroValue}
                    onClick={notNowClickHandler}
                    currencyFormat={currencyFormat}
                    isTipLabelType={isTipLabelType}
                    option={option}
                    onTipSelect={tipSelectHandler}
                    tipMode={tipMode}
                    amount={amount}
                    convertAmount={convertAmount}
                    hasMostCommon={hasMostCommon}
                    mostCommonTip={mostCommonTip}
                    newRoundUpConfigs={newRoundUpConfigs}
                    vendor={vendor}
                    tipLabelType={tipLabelType}
                    index={index}
                    shouldStretchBoxes={shouldStretchTipBoxes}
                    lang={lang}
                />
            </div>
        );
    };

    return (
        <div className={styles.tipInputs}>
            {disabled && <div className={styles.disabledOverlay} />}
            {disableTooltip !== true && showTooltip && (
                <Box sx={{ pb: '1rem' }}>
                    <Trivia
                        textOverrides={{
                            flex: '1 1',
                        }}
                        message={tipMessage}
                        onClickClose={actionClickHandler}
                    />
                </Box>
            )}
            <div
                className={classNames({
                    [styles.TipHintContainer]: isTipLabelType,
                })}
            >
                <Hint
                    modal={modal}
                    selectedTip={tip}
                    selectedTipIndex={tip ? sortedTipOptions.indexOf(tip.amount) : undefined}
                    currencyPrecision={currencyPrecision}
                    staff={staff}
                    isTipLabelType={isTipLabelType}
                    isIncludeZero={tipOptions.includes(0)}
                />
            </div>
            <div
                className={classNames(
                    styles.tipContainer,
                    { [styles.newVersion]: newVersion },
                    { [styles.hasTipLabelType]: !hasMostCommon && isTipLabelType },
                    { [styles.hasMostCommon]: !isTipLabelType && newVersion && hasMostCommon },
                    { [styles.hasTipLabelTypeTipContainer]: isTipLabelType },
                    { [styles.hasMostCommonAndTipLabelType]: isTipLabelType && hasMostCommon },
                    {
                        [styles.hasMostCommonAndTipLabelTypeAndLengthyText]:
                            isTipLabelType && hasMostCommon && isLengthyDescription,
                    },
                    {
                        [styles.hasMostCommonAndTipLabelTypeIcon]:
                            isTipLabelType && hasMostCommon && (tipLabelType === 'stars' || tipLabelType === 'ticks'),
                    },
                )}
                onScroll={onScroll}
            >
                <div
                    className={classNames(styles.tipScrollable, {
                        [styles.tipV2Scroll]: newVersion && shouldStretchTipBoxes,
                        [styles.tipScrollableWithoutTipUIV2]: !newVersion,
                    })}
                >
                    {(newVersion && isTipLabelType ? sortedTipOptions : tipOptions).map((option, index) => {
                        if (option === -1) {
                            return null;
                        }

                        if (option === 0) {
                            return getNotNow(option, index, `${option}-${index}`);
                        }

                        return (
                            <div
                                key={`${option}-${index}`}
                                id={`tip${modal ? '_modal' : ''}_${option}`}
                                className={styles.tipItem}
                            >
                                <TipItem
                                    vendor={vendor}
                                    option={option}
                                    onTipSelect={tipSelectHandler}
                                    currencySymbol={currencySymbol}
                                    currencyPrecision={currencyPrecision}
                                    tipMode={tipMode}
                                    tip={tip}
                                    amount={amount}
                                    convertAmount={convertAmount}
                                    blackTheme={blackTheme}
                                    hasMostCommon={hasMostCommon}
                                    mostCommonTip={mostCommonTip}
                                    newVersion={newVersion}
                                    newRoundUpConfigs={newRoundUpConfigs}
                                    shouldStretchBoxes={shouldStretchTipBoxes}
                                    currencyFormat={currencyFormat}
                                    index={index}
                                    tipLabelType={tipLabelType}
                                    isTipLabelType={isTipLabelType}
                                    isIncludeZero={tipOptions.includes(0)}
                                    lang={lang}
                                />
                            </div>
                        );
                    })}
                </div>
            </div>
            {customTipIndex !== -1 && (
                <div className={styles.tipCustom}>
                    <TipCustom
                        tip={tip}
                        mode={tipMode}
                        currencySymbol={currencySymbol}
                        currencyPrecision={currencyPrecision}
                        blackTheme={blackTheme}
                        onChangeTip={tipCustomChangeHandler}
                        modal={modal}
                        modalTrigger={modalTrigger}
                        onFocus={onCustomFocus}
                        onBlur={onCustomBlur}
                    />
                </div>
            )}
        </div>
    );
};

export default TipInputs;
