import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Box, IconButton, useTheme } from '@mui/material';
import { Typography } from '@qlub-dev/qlub-kit';
import Format from '@qlub-dev/qlub-kit/dist/components/Format';
import { FC, useMemo } from 'react';
import Heart from '@/assets/images/tip/hearthand.png';
import Sad from '@/assets/images/tip/sad.png';
import Smiling from '@/assets/images/tip/smiling.png';
import HeartEyes from '@/assets/images/tip/hearteyes.png';
import Blessed from '@/assets/images/tip/blessed.png';
import Sunglasses from '@/assets/images/tip/sunglasses.png';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { TipGamificationModeEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import classNames from 'classnames';
import { InfoIcon, InfoIconFilled } from '@/assets/images/icons/info';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import useEventsCenter from '@/hooks/eventsCenter';
import { IStaff } from '@/repositories/bill';
import { StackElements } from '@qlub-dev/qlub-kit/dist/components/StackElements';
import { IsTipRoundingFeatureEnable } from '@/components/Tip/normal/utils/rounding-calculations';
import { useDefaultText } from '@/components/Tip/normal/hooks/tip-hint-msg';
import { ITip } from '../../../types';

import styles from './index.module.scss';

interface ITipTexts {
    title: string;
    caption: string;
    modalText?: string;
    icon?: any;
}

interface IProps {
    selectedTip: ITip;
    selectedTipIndex?: number;
    modal?: boolean;
    currencyPrecision: number;
    staff?: IStaff;
    isTipLabelType?: boolean;
    isIncludeZero?: boolean;
}

const Hint: FC<IProps> = ({
    selectedTip,
    selectedTipIndex,
    currencyPrecision,
    modal,
    staff,
    isTipLabelType,
    isIncludeZero = false,
}) => {
    const { t } = useTranslation('common');
    const theme = useTheme();
    const { vendor, currencyFormat } = useVendor();
    const { config } = useConfigContext();
    const {
        tip: { tipRoundUpSetEvent },
    } = useEventsCenter();

    const titleAndCaption = useDefaultText({
        staff,
        selectedTipStatus: selectedTip.status,
        isSelectedTip: selectedTip.status === 'selected' && selectedTipIndex !== undefined,
    });

    const { triggerAlternateSnackBar } = snackBar();

    const hideTipAmountTipBox = vendor?.config.hideTipAmountTipBox || config?.hideTipAmountTipBox;

    const showInfoIconForTipRounding = useMemo(() => {
        if (!vendor || !config) {
            return false;
        }
        const isRoundingEnable = IsTipRoundingFeatureEnable(vendor, config);
        if (isRoundingEnable) {
            tipRoundUpSetEvent();
        }
        return isRoundingEnable;
    }, [vendor, config]);

    const showGamification = useMemo(() => {
        if (
            vendor?.config?.tipGamificationMode &&
            vendor?.config?.tipGamificationMode !== TipGamificationModeEnum.Default
        ) {
            return vendor?.config?.tipGamificationMode;
        }
        return config?.tipGamificationMode;
    }, [vendor?.config?.tipGamificationMode, config?.tipGamificationMode]);

    const tipTexts = useMemo<ITipTexts>(() => {
        switch (selectedTip.status) {
            case 'notNow':
                return {
                    ...titleAndCaption,
                    icon: Sad.src,
                    modalText: t('Make someone smile!'),
                };
            case 'selected':
                if (selectedTipIndex === undefined) {
                    return {
                        ...titleAndCaption,
                        icon: Sunglasses.src,
                        modalText: t('Kindness always wins!'),
                    };
                }

                return {
                    ...titleAndCaption,
                    ...[
                        ...(isIncludeZero
                            ? [
                                  {
                                      icon: Sad.src,
                                      modalText: t('Make someone smile!'),
                                  },
                              ]
                            : []),
                        {
                            icon: Blessed.src,
                            modalText: t('You are great!'),
                        },
                        {
                            icon: Smiling.src,
                            modalText: t('Very generous!'),
                        },
                        {
                            icon: HeartEyes.src,
                            modalText: t('Thank you so much!'),
                        },
                    ][Math.min(selectedTipIndex, isIncludeZero ? 3 : 2)],
                };
            case 'custom':
                return {
                    ...titleAndCaption,
                    icon: Sunglasses.src,
                    modalText: t('Custom'),
                };
            default:
                return {
                    ...titleAndCaption,
                    icon: isTipLabelType && isIncludeZero ? Sad.src : Heart.src,
                    modalText: isTipLabelType && isIncludeZero ? t('Make someone smile!') : t('Kindness always wins!'),
                };
        }
    }, [selectedTip.status, selectedTipIndex, selectedTip.amount, vendor?.config?.tipDefault, t]);

    const onInfoButtonClicked = () => {
        triggerAlternateSnackBar(
            <span
                style={{
                    display: 'flow',
                }}
                className={styles.toast}
            >
                {t(
                    'Tips are rounded up to the nearest whole amount for simplicity You can modify with the custom option',
                )}
            </span>,

            <InfoIconFilled />,
            'whiteWithBlackText',
        );
    };

    return (
        <>
            {!modal ? (
                <StackElements direction="column" spacing={1}>
                    <Typography typo="title_md" sx={{ pt: 2 }}>
                        {tipTexts.title}
                    </Typography>
                    <Typography
                        sx={{
                            ...theme.qlub.typography.caption_overline,
                            color: theme.qlub.palette.onSurfaceColors.mediumEmphasis,
                        }}
                    >
                        {tipTexts.caption}
                    </Typography>
                </StackElements>
            ) : (
                showGamification === 'gamificationOn' && (
                    <div className={styles.InModalEmojies}>
                        <Typography typo="body_md">{tipTexts.modalText}</Typography>
                        <img data-qa-id="tip-modal-emoji" src={tipTexts.icon} alt="..." />
                    </div>
                )
            )}
            <StackElements alignItems="flex-end" justifyContent="space-between">
                {!(hideTipAmountTipBox && !modal) && (
                    <Box sx={{ pt: 2 }} className={styles.tipAmount}>
                        {!modal && showGamification === 'gamificationOn' && !isTipLabelType && (
                            <img src={tipTexts.icon} alt="..." />
                        )}
                        <Typography data-qa-id="tip-amount-modal" typo="body_sm" className={styles.text}>
                            <span
                                className={classNames({
                                    [styles.tipAmountText]: isTipLabelType,
                                })}
                            >{`${t('Tip amount')}: `}</span>
                            <Format
                                bold
                                currencyFormat={{
                                    ...currencyFormat,
                                    currencyPrecision: currencyPrecision || currencyFormat.currencyPrecision,
                                }}
                                value={selectedTip.finalValue?.toFixed(currencyPrecision)}
                            />
                            {showInfoIconForTipRounding && (
                                <IconButton onClick={onInfoButtonClicked}>
                                    <InfoIcon />
                                </IconButton>
                            )}
                        </Typography>
                    </Box>
                )}
            </StackElements>
        </>
    );
};

export default Hint;
