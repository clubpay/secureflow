import React, { FC } from 'react';
import { tipCalculateValue } from '@/components/Tip/normal/utils/tip';
import { Tip, TipV2 } from '@qlub-dev/qlub-kit';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IRestaurant, TipLabelType } from '@clubpay/customer-common-module/src/repository/vendor';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { useTipDescriptions } from '@/hooks/useTipDescriptions';
import { TipModeEnum } from '@/components/Tip/normal/enums';
import { ITip } from '../../../types';

interface IProps {
    vendor: IRestaurant | undefined;
    option: number;
    currencyPrecision: number;
    currencySymbol: string;
    hasMostCommon: boolean;
    mostCommonTip: number | undefined;
    tipMode: TipModeEnum;
    tip: ITip;
    amount: number;
    convertAmount: (option: number) => number | JSX.Element;
    blackTheme: boolean;
    newRoundUpConfigs?: any | false;
    newVersion: boolean;
    onTipSelect: (val: number) => () => void;
    shouldStretchBoxes: boolean;
    currencyFormat: CurrencyFormat;
    index: number;
    tipLabelType?: TipLabelType;
    isTipLabelType?: boolean;
    isIncludeZero?: boolean;
    lang: string;
}

const TipItem: FC<IProps> = ({
    vendor,
    option,
    currencyPrecision,
    currencySymbol,
    hasMostCommon,
    mostCommonTip,
    tipMode,
    tip,
    amount,
    convertAmount,
    blackTheme,
    newRoundUpConfigs,
    newVersion,
    onTipSelect,
    shouldStretchBoxes,
    currencyFormat,
    index,
    tipLabelType,
    isTipLabelType,
    isIncludeZero = false,
    lang,
}) => {
    const { t } = useTranslation('common');
    const [descriptions] = useTipDescriptions();

    if (newVersion) {
        return (
            <TipV2
                option={option}
                tipSelectHandler={onTipSelect}
                currencyFormat={{
                    ...currencyFormat,
                    currencyPrecision: currencyPrecision || currencyFormat?.currencyPrecision,
                    cs: currencySymbol || currencyFormat?.cs,
                }}
                tipMode={tipMode}
                tip={tip.amount}
                amount={amount}
                convertAmount={convertAmount}
                mostCommon={hasMostCommon ? (mostCommonTip === option ? t('Most Common') : '') : undefined}
                // TODO: don't pass the tipCalculateValue function as a prop. Calculated value is being passed already
                tipCalculateValue={tipCalculateValue}
                enableTipRounding={vendor?.config.enableTipRounding}
                calculatedAmount={tipCalculateValue(
                    tipMode,
                    option,
                    amount,
                    vendor?.config.enableTipRounding,
                    newRoundUpConfigs,
                ).toFixed(currencyPrecision)}
                cancelIcon={!(isTipLabelType && tip.amount === 0)}
                blackThemeStyle={blackTheme}
                shouldStretchBoxes={shouldStretchBoxes}
                tipLabelType={tipLabelType}
                isTipLabelType={isTipLabelType}
                index={index}
                descriptions={descriptions}
                isIncludeZero={isIncludeZero}
                lang={lang}
            />
        );
    }

    return (
        <Tip
            option={option}
            tipSelectHandler={onTipSelect}
            tipMode={tipMode}
            tip={tip.amount}
            amount={amount}
            cancelIcon
            convertAmount={convertAmount}
            mostCommon={hasMostCommon ? (mostCommonTip === option ? t('Most common') : ' ') : undefined}
            tipCalculateValue={tipCalculateValue}
            enableTipRounding={vendor?.config.enableTipRounding}
            calculatedAmount={tipCalculateValue(
                tipMode,
                option,
                amount,
                vendor?.config.enableTipRounding,
                newRoundUpConfigs,
            ).toFixed(currencyPrecision)}
            blackThemeStyle={blackTheme}
            currencyFormat={{
                ...currencyFormat,
                currencyPrecision: currencyPrecision || currencyFormat?.currencyPrecision,
                cs: currencySymbol || currencyFormat?.cs,
            }}
        />
    );
};

export default TipItem;
