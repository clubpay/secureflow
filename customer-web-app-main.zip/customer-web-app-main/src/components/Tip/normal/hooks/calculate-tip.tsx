import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useCallback, useMemo } from 'react';
import { PERCENTAGE_BASED_TIP_MODES } from '../constants';
import useTipMode from './get-tip-mode';
import useRoundUpConfigs from './rounding-configs';
import { calculateTipWithRoudUpFeature } from '../utils/rounding-calculations';

interface IProps {
    billAmount: number;
    yourShareAmount: number;
    remainingAmount: number;
    hasUserPaid: boolean;
    payableAmount: number;
}

const useTipCalulator = ({ billAmount, yourShareAmount, remainingAmount, hasUserPaid, payableAmount }: IProps) => {
    const { vendor } = useVendor();

    const { mode } = useTipMode({
        billAmount,
    });

    const newRoundUpConfigs = useRoundUpConfigs({
        billAmount,
    }); // only rounds up

    const isLegacyRoundingEnabled = vendor?.config?.enableTipRounding; // can round up and down based on the decimal value

    const finalAmount = useMemo(() => {
        if (yourShareAmount > 0) {
            return yourShareAmount;
        }

        if (remainingAmount === 0 || (remainingAmount > 0 && hasUserPaid)) {
            return payableAmount;
        }

        if (remainingAmount > 0) {
            return remainingAmount;
        }

        return billAmount;
    }, [yourShareAmount, remainingAmount, billAmount, payableAmount, hasUserPaid]);

    const calculateTip = useCallback(
        (val: number): number => {
            const totalFloat = parseFloat(((val * finalAmount) / 100).toFixed(2));

            if (newRoundUpConfigs && newRoundUpConfigs?.tipRoundingCRV > 0 && newRoundUpConfigs?.tipRoundingMTC > 0) {
                return calculateTipWithRoudUpFeature(
                    totalFloat,
                    newRoundUpConfigs.tipRoundingCRV,
                    newRoundUpConfigs.tipRoundingMTC,
                );
            }

            if (PERCENTAGE_BASED_TIP_MODES.includes(mode)) {
                if (isLegacyRoundingEnabled) {
                    const decimalPart = totalFloat - Math.floor(totalFloat);

                    if (decimalPart >= 0.5) {
                        return Math.ceil(totalFloat);
                    }

                    return Math.floor(totalFloat);
                }

                return (val * finalAmount) / 100;
            }

            return val || 0;
        },
        [finalAmount, newRoundUpConfigs, isLegacyRoundingEnabled],
    );

    return {
        calculateTip,
    };
};

export default useTipCalulator;
