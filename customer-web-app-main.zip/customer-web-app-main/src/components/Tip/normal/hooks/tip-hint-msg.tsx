import { IStaff } from '@/repositories/bill';
import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';

interface ITipHeader {
    title: string;
    caption: string;
}

interface IProps {
    staff?: IStaff;
    selectedTipStatus?: 'notNow' | 'custom' | 'selected';
    isSelectedTip?: boolean;
}

export const useDefaultText = ({ staff, selectedTipStatus, isSelectedTip = false }: IProps): ITipHeader => {
    const { lang } = useQlubRouter();
    const { t } = useTranslation('common');

    const { vendor } = useVendor();
    const { config } = useConfigContext();

    const getCustomText = (header?: string, description?: string) => ({
        header: getLocaleText(header || '', lang, 'en'),
        description: getLocaleText(description || '', lang, 'en'),
    });

    const { header: restaurantTitle, description: restaurantCaption } = getCustomText(
        vendor?.config?.tipCustomHeader,
        vendor?.config.tipCustomDescription,
    );

    const { header: countryTitle, description: countryCaption } = getCustomText(
        config?.tipCustomHeader,
        config?.tipCustomDescription,
    );

    const thankYouCaption =
        vendor?.config?.tipDefault && vendor.config.tipDefault > 0 ? t('Your tip matters!') : t('Thanks for the tip!');

    const staffCaption =
        vendor?.config?.showWaiterName && staff !== null
            ? t(`Do you want to include a tip for {{value}}?`, {
                  value: staff?.name,
              })
            : t('Do you want to include a tip?');

    const defaultTipTitle = isSelectedTip || selectedTipStatus === 'custom' ? thankYouCaption : staffCaption;

    const defaultCaption = t('All proceeds go directly to our staff!');

    return {
        title: restaurantTitle || countryTitle || defaultTipTitle,
        caption:
            !restaurantTitle && !countryTitle
                ? restaurantCaption || countryCaption || defaultCaption
                : restaurantTitle
                ? restaurantCaption || defaultCaption
                : countryCaption || defaultCaption,
    };
};
