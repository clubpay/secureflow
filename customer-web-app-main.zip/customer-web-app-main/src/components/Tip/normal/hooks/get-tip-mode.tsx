import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { TipModeEnum } from '../enums';

interface IProps {
    billAmount: number;
}

const useTipMode = ({ billAmount }: IProps) => {
    const { vendor } = useVendor();
    const { config: country } = useConfigContext();

    let configuredTipMode: TipModeEnum;

    if (vendor?.config.tipMode === TipModeEnum.Default) {
        configuredTipMode = TipModeEnum.PercentageWithHint;
    } else {
        configuredTipMode = vendor?.config.tipMode || country?.tipMode || TipModeEnum.Percentage;
    }

    // percentage tip can only be calculated for non-zero bill amounts
    const tipMode = billAmount <= 0 ? TipModeEnum.Fixed : configuredTipMode || TipModeEnum.Percentage;

    return { mode: tipMode };
};

export default useTipMode;
