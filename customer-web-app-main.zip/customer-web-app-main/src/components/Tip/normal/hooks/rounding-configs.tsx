import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import useTipMode from './get-tip-mode';
import { ROUNDING_ENABLED_TIP_MODES } from '../constants';

interface IProps {
    billAmount: number;
}

const useRoundUpConfigs = ({ billAmount }: IProps) => {
    const { vendor } = useVendor();
    const { config: country } = useConfigContext();

    const { mode } = useTipMode({
        billAmount,
    });

    // CRV = configurable rounding value
    // MTC = max tip cap
    const vendorLvlTipRoundingCRV = vendor?.config?.tipRoundingCRV;
    const vendorLvlTipRoundingMTC = vendor?.config?.tipRoundingMTC;
    const countryLvlTipRoundingCRV = country?.tipRoundingCRV;
    const countryLvlTipRoundingMTC = country?.tipRoundingMTC;

    // both configs(CRV and MTC) must be available in the same level (vendor or country)
    if (
        (!(vendorLvlTipRoundingCRV && vendorLvlTipRoundingMTC) &&
            !(countryLvlTipRoundingCRV && countryLvlTipRoundingMTC)) ||
        !ROUNDING_ENABLED_TIP_MODES.includes(mode)
    ) {
        return false;
    }

    if (vendorLvlTipRoundingCRV && vendorLvlTipRoundingMTC) {
        return {
            tipRoundingCRV: vendorLvlTipRoundingCRV,
            tipRoundingMTC: vendorLvlTipRoundingMTC,
        };
    }

    if (countryLvlTipRoundingCRV && countryLvlTipRoundingMTC) {
        return {
            tipRoundingCRV: countryLvlTipRoundingCRV,
            tipRoundingMTC: countryLvlTipRoundingMTC,
        };
    }
};

export default useRoundUpConfigs;
