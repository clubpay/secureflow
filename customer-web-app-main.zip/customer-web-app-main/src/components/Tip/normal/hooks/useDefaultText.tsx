import { useMemo } from 'react';
import { IStaff } from '@/repositories/bill';
import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';

interface ITipHeader {
    title: string;
    caption: string;
    isCustomTipMessage: boolean;
}

interface IProps {
    staff?: IStaff;
    isTipModal?: boolean;
}

export const useDefaultText = ({ staff, isTipModal = false }: IProps): ITipHeader => {
    const { lang } = useQlubRouter();
    const { t } = useTranslation('common');
    const { config: countryConfig } = useConfigContext();
    const { vendor } = useVendor();

    return useMemo<ITipHeader>(() => {
        const getCustomText = (header?: string, description?: string) => ({
            header: getLocaleText(header || '', lang, 'en'),
            description: getLocaleText(description || '', lang, 'en'),
        });

        const { header: restaurantHeader, description: restaurantDescription } = getCustomText(
            vendor?.config?.tipCustomHeader,
            vendor?.config?.tipCustomDescription,
        );

        const { header: countryHeader, description: countryDescription } = getCustomText(
            countryConfig?.tipCustomHeader,
            countryConfig?.tipCustomDescription,
        );

        const defaultText = isTipModal
            ? {
                  defaultDescription:
                      vendor?.config?.showWaiterName && staff !== null
                          ? t(`All proceeds go directly to {{value}}`, {
                                value: staff?.name,
                            })
                          : t('All proceeds go directly to our staff!'),
                  defaultTipTitle: t('Your tip matters'),
              }
            : {
                  defaultDescription: t('All proceeds go directly to our staff!'),
                  defaultTipTitle:
                      vendor?.config?.showWaiterName && staff !== null
                          ? t(`Do you want to include a tip for {{value}}?`, {
                                value: staff?.name,
                            })
                          : t('Do you want to include a tip?'),
              };

        const restaurantAndCountryHeadersNotAvailable =
            !restaurantHeader && !countryHeader
                ? restaurantDescription || countryDescription || defaultText?.defaultDescription
                : '';

        const restaurantOrCountryHeadersAvailable = restaurantHeader
            ? restaurantDescription || defaultText?.defaultDescription
            : countryDescription || defaultText?.defaultDescription;

        return {
            title: restaurantHeader || countryHeader || defaultText?.defaultTipTitle,
            caption: restaurantAndCountryHeadersNotAvailable || restaurantOrCountryHeadersAvailable,
            isCustomTipMessage:
                !!restaurantHeader || !!countryHeader || !!restaurantDescription || !!countryDescription,
        };
    }, [
        vendor?.config?.tipCustomHeader,
        vendor?.config?.tipCustomDescription,
        countryConfig?.tipCustomHeader,
        countryConfig?.tipCustomDescription,
        isTipModal,
        lang,
        staff,
        t,
    ]);
};
