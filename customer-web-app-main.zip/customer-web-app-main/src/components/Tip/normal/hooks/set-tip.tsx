import BillAPIManager from '@/repositories/bill';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getDiningSession, getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import _debounce from 'lodash/debounce';
import { useCallback } from 'react';

interface IProps {
    currencyPrecision?: number;
}

const useSetTip = ({ currencyPrecision }: IProps) => {
    const { url } = useQlubRouter();

    const setTipHandler = useCallback(
        (tip: number, isDirty: boolean) => {
            if (!isDirty && tip === 0) {
                return;
            }

            BillAPIManager.getInstance()
                .setTipAmount({
                    id: getSession(),
                    diningSessionID: getDiningSession(url)?.id || '',
                    amount: tip.toFixed(currencyPrecision || 2),
                })
                .catch((err) => {
                    console.warn('Error setting tip amount', err);
                });
        },
        [url],
    );

    const setDebouncedTipHandler = useCallback(_debounce(setTipHandler, 1000), [setTipHandler]);

    const set = useCallback((tip: number, isDirty: boolean, debounce?: boolean) => {
        return debounce ? setDebouncedTipHandler(tip, isDirty) : setTipHandler(tip, isDirty);
    }, []);

    return { set };
};

export default useSetTip;
