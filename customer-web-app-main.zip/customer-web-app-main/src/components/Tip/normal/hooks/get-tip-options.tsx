import { filterEmptyArrays } from '@/lib/utils';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import useTipStore from '@/store/tip';
import { sortTipOptions } from '../utils/tip';

interface IProps {
    isTipModal: boolean;
}

export const useTipOptions = ({ isTipModal }: IProps) => {
    const { vendor } = useVendor();
    const { config: countryConfig } = useConfigContext();

    const updateMostCommonTipOption = useTipStore((state) => state.updateMostCommonTipOption);
    const updateNonModalDefaultTipOption = useTipStore((state) => state.updateNonModalDefaultTipOption);

    const filteredVendorLvlOptions = filterEmptyArrays(vendor?.config?.tipOptions);
    const filteredCountryLvlOptions = filterEmptyArrays(countryConfig?.tipOptions);

    const prioritizedOptions = filteredVendorLvlOptions || filteredCountryLvlOptions || [];

    const mostCommonOption =
        vendor?.config?.mostCommonTip && vendor?.config?.mostCommonTip > 0
            ? vendor?.config?.mostCommonTip
            : countryConfig?.mostCommonTip;

    updateMostCommonTipOption(mostCommonOption);

    const tipModalDefaultOption = vendor?.config?.tipDefaultForTipModal ?? countryConfig?.tipDefaultForTipModal;
    const nonModalDefaultOption = vendor?.config?.tipDefault ?? countryConfig?.tipDefault;

    updateNonModalDefaultTipOption(nonModalDefaultOption);

    const finalOptions: { modal: number[]; nonModal: number[] } = {
        modal: [],
        nonModal: [],
    };

    finalOptions.modal = sortTipOptions(prioritizedOptions, {
        mostCommon: mostCommonOption,
        defaultAmount: tipModalDefaultOption,
    });

    finalOptions.nonModal = sortTipOptions(prioritizedOptions, {
        mostCommon: mostCommonOption,
        defaultAmount: nonModalDefaultOption,
    });

    return isTipModal ? finalOptions.modal : finalOptions.nonModal;
};
