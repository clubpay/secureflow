import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor';
import { getTipMode } from './tip';
import { TipModeEnum } from '../enums';

// sample test data
export const testData = [
    [15.12, 0.5, 0.5],
    [50, 0.5, 0.5],
    [3.99, 0.01, 0.05],
    [19.99, 1, 5],
    [47.3, 0.35, 1],
    [0.85, 5, 5],
    [78.2, 1, 10],
    [22, 0, 1],
    [99.91, 0.01, 0.09],
    [-20.5, 1, 0.05],
    [10.1, 1, 0.5],
    [55.999, 0.01, 0.1],
    [7.123, 0.2, 0.5],
];

export const calculateTipWithRoudUpFeature = (
    tipAmount: number,
    configurableRoundingValue: number,
    maxTipCap: number,
) => {
    if (tipAmount <= 0 || configurableRoundingValue <= 0 || maxTipCap <= 0) {
        return 0;
    }
    const val = tipAmount / configurableRoundingValue;
    const roundedTarget = Math.ceil(val) * configurableRoundingValue || 0;

    const tipBeforeCap = roundedTarget - tipAmount;
    const finalRoundUpAmount = Math.min(tipBeforeCap, maxTipCap);
    const finalTipAmountAfterRoundUp = finalRoundUpAmount + tipAmount;

    return finalTipAmountAfterRoundUp;
};

/**
 * @deprecated This function is deprecated. Use useRoundUpConfigs hook instead.
 */
export const IsTipRoudUpConfigAvailable = (vendor: IRestaurant, country: IConfig) => {
    if (vendor.config.tipRoundingCRV && vendor.config.tipRoundingMTC) {
        return {
            tipRoundingCRV: vendor.config.tipRoundingCRV,
            tipRoundingMTC: vendor.config.tipRoundingMTC,
        };
    }
    if (country.tipRoundingCRV && country.tipRoundingMTC) {
        return {
            tipRoundingCRV: country.tipRoundingCRV,
            tipRoundingMTC: country.tipRoundingMTC,
        };
    }
    return false;
};

/**
 * @deprecated This function is deprecated. Use useRoundUpConfigs hook instead.
 */
export const IsTipRoundingFeatureEnable = (vendor: IRestaurant | undefined, country: IConfig | undefined | null) => {
    if (!vendor || !country) {
        return false;
    }
    const tipMode = getTipMode(vendor, country);
    const isConfigAvailable = IsTipRoudUpConfigAvailable(vendor, country);
    const isNewRoundingActive =
        isConfigAvailable &&
        (tipMode === TipModeEnum.PercentWithRoundUp || tipMode === TipModeEnum.PercentWithHintAndRoundUp);
    return isNewRoundingActive;
};

export const calcAdditionalTipRoundingAmount = (RoundedValue: number, tipOption: number, totalAmount: number) => {
    const totalFloat = parseFloat(((tipOption * totalAmount) / 100).toFixed(3));
    const additionalValue = (RoundedValue - totalFloat).toFixed(3);
    return additionalValue;
};
