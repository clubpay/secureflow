import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import { IRestaurant, IRestaurantConfig } from '@clubpay/customer-common-module/src/repository/vendor';
import { addOrBringToStartOfArray } from '@/lib/utils';
import { calculateTipWithRoudUpFeature } from './rounding-calculations';
import { PERCENTAGE_BASED_TIP_MODES } from '../constants';
import { TipModeEnum } from '../enums';

/**
 * @deprecated This utility function is deprecated and may be removed in future versions. Use useTipCalculator hook instead
 */
export const tipCalculateValue = (
    mode: TipModeEnum,
    val: number,
    totalAmount: number,
    legacyRounding?: boolean, // can round up and down based on the decimal value
    newRounding?: any | false, // only rounds up
): number => {
    const totalFloat = parseFloat(((val * totalAmount) / 100).toFixed(2));

    if (
        newRounding?.tipRoundingCRV > 0 &&
        newRounding?.tipRoundingMTC > 0 &&
        (mode === TipModeEnum.PercentWithRoundUp || mode === TipModeEnum.PercentWithHintAndRoundUp)
    ) {
        return calculateTipWithRoudUpFeature(totalFloat, newRounding.tipRoundingCRV, newRounding.tipRoundingMTC);
    }

    if (PERCENTAGE_BASED_TIP_MODES.includes(mode)) {
        if (legacyRounding) {
            const decimalPart = totalFloat - Math.floor(totalFloat);
            if (decimalPart >= 0.5) {
                return Math.ceil(totalFloat);
            }

            return Math.floor(totalFloat);
        }

        return (val * totalAmount) / 100;
    }

    return val || 0;
};

export const getTipMode = (vendor: IRestaurant | undefined, country: IConfig | undefined | null): TipModeEnum => {
    if (vendor?.config.tipMode === TipModeEnum.Default) {
        return TipModeEnum.PercentageWithHint;
    }

    return vendor?.config.tipMode || country?.tipMode || TipModeEnum.Percentage;
};

export const checkField = (f: any, vendor: IRestaurantConfig | undefined, country: IConfig | null, value: number) => {
    if (vendor?.[f as keyof IRestaurantConfig]) {
        return vendor?.[f as keyof IRestaurantConfig] === value;
    }

    if (country?.[f as keyof IConfig]) {
        return country?.[f as keyof IConfig] === value;
    }

    return 'not-set';
};

export const sortTipOptions = (
    options: Array<number>,
    option?: {
        mostCommon?: number;
        defaultAmount?: number;
    },
) => {
    let tipOptions = [...options];

    if (option?.defaultAmount) {
        tipOptions = addOrBringToStartOfArray(tipOptions, option.defaultAmount);
    }

    if (option?.mostCommon) {
        tipOptions = addOrBringToStartOfArray(tipOptions, option.mostCommon);
    }

    const zeroTipIdx = tipOptions?.indexOf(0);

    if (zeroTipIdx > -1) {
        tipOptions?.splice(zeroTipIdx, 1);
        tipOptions?.unshift(0);
    }

    return tipOptions;
};
