export enum TipToggleOriginEnum {
    Payment = 'payment',
    Split = 'split',
    TipModal = 'tipModal',
}

export enum TipModeEnum {
    Default = 'default',
    Fixed = 'fixed',
    Percentage = 'percentage',
    PercentageWithHint = 'percentageWithHint',
    FixedWithHint = 'fixedWithHint',
    PercentWithRoundUp = 'percentWithRoundUp',
    PercentWithHintAndRoundUp = 'percentWithHintAndRoundUp',
}
