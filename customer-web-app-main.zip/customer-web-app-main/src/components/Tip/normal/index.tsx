import React, { FC, useCallback, useEffect, useMemo, useState } from 'react';
import {
    EnableEnum,
    IRestaurant,
    TipBoxPresentationEnum,
    TipLabelType,
    TipModalEventConditionEnum,
    TipModalTriggerPointConditionEnum,
} from '@clubpay/customer-common-module/src/repository/vendor';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import { Divider } from '@qlub-dev/qlub-kit';
import TipInputs from '@/components/Tip/normal/components/inputs';
import useElemObserver from '@/hooks/elemObserver';
import useEventsCenter from '@/hooks/eventsCenter';
import { IPaymentDetails } from '@/repositories/bill';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import useTipStore from '@/store/tip';
import TipModal, { getTipModalShown } from './components/modal';
import useSetTip from './hooks/set-tip';
import { ITip, TipToggleFunc } from './types';
import { TipToggleOriginEnum } from './enums';

interface IProps {
    vendor: IRestaurant;
    config: IConfig | undefined;
    details: IPaymentDetails;
    myTotal: number;
    lang: string | null;
    paymentOnTipModal: boolean;
    paymentHeight: number;
    disabled: boolean;
    setTipModalOpenFunc: (fn: TipToggleFunc) => void;
    onChange: (val: number, option?: number) => void;
    onTipModalOpen: (open: boolean) => void;
    currencyFormat: CurrencyFormat;
}

const NormalTip: FC<IProps> = ({
    config,
    vendor,
    details,
    myTotal,
    lang,
    disabled,
    paymentOnTipModal,
    paymentHeight,
    setTipModalOpenFunc,
    onChange,
    onTipModalOpen,
    currencyFormat,
}) => {
    const [tip, setTip] = useState<ITip>({
        amount: 0,
        finalValue: 0,
    });
    const [tipModalOpen, setTipModalOpen] = useState(false);
    const [dirty, setDirty] = useState(false);
    const [shouldShowHiddenTipBoxes, setShouldShowHiddenTipBoxes] = useState<boolean>(false);

    const isVisible = useTipStore((state) => state.isNormalTipVisible);

    const updateTip = useTipStore((state) => state.updateNormalTip);
    const updateDirtiness = useTipStore((state) => state.updateDirtiness);

    const {
        tip: { defaultEvents, tipBoxDisplayEvent, modalTrigger },
    } = useEventsCenter();

    const { show: inViewPort } = useElemObserver({
        selector: '#tipElement',
        threshold: 0.75,
        hysteresis: 0,
        checkInside: true,
    });

    const { set: setRemoteTip } = useSetTip({
        currencyPrecision: details.currencyPrecision,
    });

    useEffect(() => {
        if (inViewPort) {
            tipBoxDisplayEvent();
        }
    }, [inViewPort]);

    useEffect(() => {
        const tipValue = tip.finalValue || 0;

        onChange(tipValue, tip.amount);
        setRemoteTip(tipValue || 0, dirty, true);
    }, [tip]);

    useEffect(() => {
        defaultEvents(tipModalOpen);
    }, []);

    const enableTip = config && config.showTip && vendor.config?.tipHide !== true;

    /* if return true tip modal should be opened and before payment hook will be ignored
     * if return false it continues as it is */
    const tipModalOpenHandler = useCallback<TipToggleFunc>(
        (open, origin, timeout) => {
            const isSmartTipEnabled = (vendor?.config?.smartTip ?? config?.smartTip) === EnableEnum.Enable;

            if (!enableTip || tipModalOpen === open || isSmartTipEnabled) {
                return false;
            }

            const tipValue = tip.finalValue || tip.amount;
            const checkEventCondition = () => {
                switch (modalTrigger.event) {
                    case TipModalEventConditionEnum.Interaction:
                        return dirty || tipValue > 0;
                    default:
                    case TipModalEventConditionEnum.ZeroAmount:
                        return tipValue > 0;
                }
            };
            if (open) {
                /* eslint default-case: 'off' */
                switch (origin) {
                    case TipToggleOriginEnum.Payment:
                        if (
                            modalTrigger.point !== TipModalTriggerPointConditionEnum.TapOnPay ||
                            getTipModalShown() ||
                            checkEventCondition()
                        ) {
                            return false;
                        }
                        break;
                    case TipToggleOriginEnum.Split:
                        if (
                            modalTrigger.point !== TipModalTriggerPointConditionEnum.ConfirmPaymentType ||
                            getTipModalShown() ||
                            checkEventCondition()
                        ) {
                            return false;
                        }
                        break;
                }
            }
            if (timeout) {
                setTimeout(() => {
                    setTipModalOpen(open);
                }, timeout);
            } else {
                setTipModalOpen(open);
            }

            return true;
        },
        [vendor, config, modalTrigger, tip, tipModalOpen, enableTip],
    );

    useEffect(() => {
        setTipModalOpenFunc(tipModalOpenHandler);
    }, [tipModalOpenHandler]);

    useEffect(() => {
        onTipModalOpen(tipModalOpen);
    }, [tipModalOpen]);

    const showTipBox = useMemo(() => {
        if (isVisible === false) {
            return false;
        }

        if (shouldShowHiddenTipBoxes) {
            return true;
        }

        if (vendor?.config?.tipBoxPresentation === TipBoxPresentationEnum.Show) {
            return true;
        }

        if (vendor?.config?.tipBoxPresentation === TipBoxPresentationEnum.Hide) {
            return false;
        }

        return config?.tipBoxPresentation !== TipBoxPresentationEnum.Hide;
    }, [vendor, config, shouldShowHiddenTipBoxes, isVisible]);

    if (!enableTip) {
        return null;
    }

    const setDirtiness = (dirt?: boolean) => {
        if (!dirty && dirt) {
            setDirty(true);
            updateDirtiness(true);
        }
    };

    const changeTipHandler = (val: ITip, dirt?: boolean) => {
        setTip(val);
        setDirtiness(dirt);
        updateTip(val);
    };

    const onTipConfirm = (reshowTipBoxes: boolean) => {
        setShouldShowHiddenTipBoxes(reshowTipBoxes);
    };

    return (
        <>
            {showTipBox && (
                <div id="tipElement">
                    <Divider type="fullWidth" />
                    <TipInputs
                        billAmount={details.billNumber.total}
                        remainingAmount={details.billNumber.remaining}
                        yourShareAmount={details.billNumber.yourShare}
                        currencyPrecision={details.currencyPrecision}
                        currencySymbol={vendor.country.currencySymbol}
                        vendor={vendor}
                        lang={lang || 'en'}
                        hasUserPaid={details.yourSplitSettings.paymentDone || false}
                        payableAmount={details.billNumber.payableAmount}
                        disabled={disabled}
                        hideNotNow
                        tip={tip}
                        onChangeTip={changeTipHandler}
                        modalTrigger={modalTrigger}
                        staff={details.staff}
                        currencyFormat={currencyFormat}
                        showHiddenTipBoxes={shouldShowHiddenTipBoxes}
                        tipLabelType={(vendor?.config?.tipLabelType || config?.tipLabelType) as TipLabelType}
                    />
                </div>
            )}
            {tipModalOpen && (
                <TipModal
                    open={tipModalOpen}
                    onOpenChange={tipModalOpenHandler}
                    billAmount={details.billNumber.total}
                    remainingAmount={details.billNumber.remaining}
                    yourShareAmount={details.billNumber.yourShare}
                    currencyPrecision={details.currencyPrecision}
                    currencySymbol={vendor.country.currencySymbol}
                    vendor={vendor}
                    lang={lang || 'en'}
                    hasUserPaid={details.yourSplitSettings.paymentDone || false}
                    payableAmount={details.billNumber.payableAmount}
                    myTotal={myTotal}
                    disabled={disabled}
                    tip={tip}
                    onTipConfirm={onTipConfirm}
                    hideFooter={paymentOnTipModal}
                    paymentHeight={paymentHeight}
                    onChangeTip={changeTipHandler}
                    modalTrigger={modalTrigger}
                    staff={details.staff}
                    currencyFormat={currencyFormat}
                />
            )}
        </>
    );
};

export default NormalTip;
