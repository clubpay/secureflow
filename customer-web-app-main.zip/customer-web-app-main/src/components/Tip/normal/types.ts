import {
    TipModalEventConditionEnum,
    TipModalTriggerPointConditionEnum,
} from '@clubpay/customer-common-module/src/repository/vendor/type';
import { TipToggleOriginEnum } from './enums';

export interface ITip {
    amount: number;
    status?: 'notNow' | 'custom' | 'selected';
    finalValue?: number;
    roundedValue?: number;
}

export interface IModalTrigger {
    point: TipModalTriggerPointConditionEnum | undefined;
    event: TipModalEventConditionEnum | undefined;
}

export type TipToggleFunc = (open: boolean, origin: TipToggleOriginEnum, timeout?: number) => boolean;
