/*
    Creation Time: 2021 - Dec - 14
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React from 'react';
import { Paper, Skeleton, Grid } from '@mui/material';

import { CustomerContainer, CustomerGrid } from '@qlub-dev/qlub-kit';
import styles from './index.module.scss';

export default function InvoiceSkeleton() {
    return (
        <div className="mainContainer">
            <CustomerContainer maxWidth="sm">
                <div className={styles.container}>
                    <Paper elevation={0}>
                        <div className={styles.inner}>
                            <CustomerGrid spacing={2}>
                                <Grid item xs={12}>
                                    <Grid container justifyContent="space-between" alignItems="center">
                                        <Grid item xs={4}>
                                            <Grid item xs={12}>
                                                <Skeleton variant="text" />
                                            </Grid>
                                            <Grid item xs={12}>
                                                <Skeleton variant="text" />
                                            </Grid>
                                        </Grid>
                                        <Grid item xs={4}>
                                            <Skeleton variant="text" />
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item xs={8}>
                                    <Skeleton variant="text" />
                                </Grid>
                                <Grid item xs={2}>
                                    <Skeleton variant="text" />
                                </Grid>
                                <Grid item xs={2}>
                                    <Skeleton variant="text" />
                                </Grid>
                                <Grid item xs={8}>
                                    <Skeleton variant="text" />
                                </Grid>
                                <Grid item xs={2}>
                                    <Skeleton variant="text" />
                                </Grid>
                                <Grid item xs={2}>
                                    <Skeleton variant="text" />
                                </Grid>
                                <Grid item xs={8}>
                                    <Skeleton variant="text" />
                                </Grid>
                                <Grid item xs={2}>
                                    <Skeleton variant="text" />
                                </Grid>
                                <Grid item xs={2}>
                                    <Skeleton variant="text" />
                                </Grid>
                                <Grid item xs={8}>
                                    <Skeleton variant="text" />
                                </Grid>
                                <Grid item xs={2}>
                                    <Skeleton variant="text" />
                                </Grid>
                                <Grid item xs={2}>
                                    <Skeleton variant="text" />
                                </Grid>
                                <Grid item xs={8}>
                                    <Skeleton variant="text" />
                                </Grid>
                                <Grid item xs={2}>
                                    <Skeleton variant="text" />
                                </Grid>
                                <Grid item xs={2}>
                                    <Skeleton variant="text" />
                                </Grid>
                            </CustomerGrid>
                        </div>
                    </Paper>
                    <Paper elevation={0}>
                        <div className={styles.newInner}>
                            <Skeleton className={styles.borderRadius} variant="rectangular" width="45%" height={48} />
                            <Skeleton className={styles.borderRadius} variant="rectangular" width="45%" height={48} />
                        </div>
                    </Paper>
                    <Paper elevation={0}>
                        <div className={styles.innerCard}>
                            <CustomerGrid spacing={3}>
                                <Grid item xs={12}>
                                    <Skeleton
                                        className={styles.borderRadius}
                                        variant="rectangular"
                                        width="100%"
                                        height={33}
                                    />
                                </Grid>
                                {/* <Grid item xs={6} /> */}
                                <Grid item xs={3}>
                                    <Skeleton
                                        className={styles.borderRadius}
                                        variant="rectangular"
                                        height={72}
                                        width="100%"
                                    />
                                </Grid>
                                <Grid item xs={3}>
                                    <Skeleton
                                        className={styles.borderRadius}
                                        variant="rectangular"
                                        height={72}
                                        width="100%"
                                    />
                                </Grid>
                                <Grid item xs={3}>
                                    <Skeleton
                                        className={styles.borderRadius}
                                        variant="rectangular"
                                        height={72}
                                        width="100%"
                                    />
                                </Grid>
                                <Grid item xs={3}>
                                    <Skeleton
                                        className={styles.borderRadius}
                                        variant="rectangular"
                                        height={72}
                                        width="100%"
                                    />
                                </Grid>
                                <Grid item xs={4}>
                                    <Skeleton variant="text" />
                                </Grid>
                                {/* <Grid item xs={8} /> */}
                                <Grid item xs={12}>
                                    <div className={styles.card}>
                                        <Skeleton
                                            className={styles.borderRadius}
                                            variant="rectangular"
                                            height={128}
                                            width="100%"
                                        />
                                    </div>
                                </Grid>
                                <Grid item xs={12}>
                                    <Skeleton
                                        className={styles.borderRadius}
                                        variant="rectangular"
                                        width="100%"
                                        height={48}
                                    />
                                </Grid>
                            </CustomerGrid>
                        </div>
                    </Paper>
                </div>
            </CustomerContainer>
        </div>
    );
}
