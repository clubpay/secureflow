import { useMemo } from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import { ExpandMoreRounded } from '@mui/icons-material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { fromUnixTime, format } from 'date-fns';

import styles from './index.module.scss';

interface IProps {
    accordionHeader: string;
    transactionTimestamp: number;
    paymentSolution: string;
    hideDate: boolean;
    lang: string;
}

const TransactionDateFormats = {
    Ja: 'yyyy年M月d日 H:mm',
    Tr: 'h:mm, d/M/yyyy',
    Others: 'h:mmaaa, d/M/yyyy',
};

export default function PaymentDetails({ accordionHeader, transactionTimestamp, hideDate, lang }: IProps) {
    const { t } = useTranslation('common');

    const formatTransactionTimestamp = useMemo(() => {
        switch (lang) {
            default:
                return format(fromUnixTime(transactionTimestamp), TransactionDateFormats.Others);
            case 'tr':
                return format(fromUnixTime(transactionTimestamp), TransactionDateFormats.Tr);
            case 'ja':
                return format(fromUnixTime(transactionTimestamp), TransactionDateFormats.Ja);
        }
    }, [lang, transactionTimestamp]);

    return (
        <div>
            <Accordion
                sx={{ backgroundColor: 'unset', boxShadow: 'unset' }}
                defaultExpanded={!hideDate}
                expanded={!hideDate ? undefined : false}
            >
                <AccordionSummary
                    expandIcon={<ExpandMoreRounded />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                    sx={{
                        padding: '5px 16px',
                        minHeight: '64px !important',
                        '&$expanded': {
                            margin: '12px 0 !important',
                        },
                    }}
                >
                    <Typography sx={{ fontSize: '16px', fontWeight: 700, color: '#000000' }}>
                        {accordionHeader}
                    </Typography>
                </AccordionSummary>
                <AccordionDetails
                    sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'space-between',
                        padding: '0',
                    }}
                >
                    {!hideDate && (
                        <div className={styles.textWrapper}>
                            <Typography className={styles.accordionDetail}>{t('Transaction date')}</Typography>
                            <Typography className={styles.accordionDetail}>{formatTransactionTimestamp}</Typography>
                        </div>
                    )}
                    {/* <div className={styles.textWrapper}>
                        <Typography className={styles.accordionDetail}>{t('Payment solution')}</Typography>
                        <Typography className={styles.accordionDetail}>{t(paymentSolution)}</Typography>
                    </div> */}
                </AccordionDetails>
            </Accordion>
        </div>
    );
}
