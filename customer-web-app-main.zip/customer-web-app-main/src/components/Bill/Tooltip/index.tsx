import React, { useEffect, useState } from 'react';
import MuiTooltip from '@mui/material/Tooltip';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import Fade from '@mui/material/Fade';

type Props = {
    toolTipText: string;
    children: React.ReactElement;
};

const Tooltip = (props: Props) => {
    const { toolTipText = '', children } = props;
    const [open, setOpen] = useState<boolean>(false);

    const handleViewLog = () => {
        console.log('View log');
    };

    /*
     * This is the function that handles the click away event on the tooltip
     * It closes the tooltip
     */
    const handleTooltipClose = () => {
        setOpen(false);
    };

    /**
     * This is the function that handles the click event on the tooltip
     * It changes the state of the tooltip to open or close
     */
    const handleTooltipClick = () => {
        setOpen(() => !open);
    };

    /**
     * This is the function that handles the scroll event on the tooltip and sends first log
     * It closes the tooltip
     */

    useEffect(() => {
        handleViewLog();
        window.addEventListener('scroll', handleTooltipClose);
        return () => {
            window.removeEventListener('scroll', handleTooltipClose);
        };
    }, []);

    return (
        <>
            <ClickAwayListener onClickAway={handleTooltipClose}>
                <MuiTooltip
                    PopperProps={{
                        disablePortal: true,
                    }}
                    componentsProps={{
                        tooltip: {
                            sx: {
                                border: '1px solid #EBECF2',
                                marginTop: '0 !important',
                                backgroundColor: '#fff',
                                color: '#616475',
                                borderColor: '#EBECF2',
                                padding: '16px 24px',
                                borderRadius: '8px',
                                boxShadow:
                                    '0px 2px 4px 0px rgba(97, 100, 117, 0.12), 0px 1px 10px 0px rgba(97, 100, 117, 0.04), 0px 4px 5px 0px rgba(97, 100, 117, 0.06)',
                                '& .MuiTooltip-arrow::before': {
                                    border: '1px solid #EBECF2',
                                    backgroundColor: '#fff',
                                },
                            },
                        },
                    }}
                    onClose={handleTooltipClose}
                    open={open}
                    disableFocusListener
                    disableHoverListener
                    disableTouchListener
                    title={toolTipText}
                    onClick={handleTooltipClick}
                    TransitionComponent={Fade}
                    TransitionProps={{ timeout: 600 }}
                >
                    <div>{children}</div>
                </MuiTooltip>
            </ClickAwayListener>
        </>
    );
};

export default Tooltip;
