import { Card } from '@qlub-dev/qlub-kit';
import { Accordion, AccordionDetails } from '@mui/material';
import React, { ReactNode } from 'react';
import styles from './index.module.scss';

interface IAccordionProps {
    label: string;
    expanded: boolean;
    selected?: boolean;
    onClick: (event?: any) => void;
    children?: JSX.Element | ReactNode;
    showAccordion?: boolean;
    className?: string;
    accordionIcon?: React.ReactNode;
}

export const CustomerAccordion = ({
    label,
    expanded,
    onClick,
    children,
    accordionIcon,
    showAccordion,
    className,
    selected,
}: IAccordionProps): JSX.Element => {
    if (!showAccordion) {
        return <>{children}</>;
    }
    return (
        <Accordion className={className} expanded={expanded}>
            <Card label={label} onClick={onClick} selected={selected || expanded} customIcon={accordionIcon} />

            <AccordionDetails className={styles.accordionDetails}>{children}</AccordionDetails>
        </Accordion>
    );
};
export const PGSelectorAnchor = ({ label, expanded, onClick, accordionIcon }: IAccordionProps) => {
    return (
        <Accordion className={styles.accordion} data-name="creditCardButton" expanded={expanded}>
            <Card
                buttonOverrides={{
                    '&:focus-visible': {
                        borderRadius: '8px',
                        border: '1px solid var(--iris)!important',
                    },
                    '&:focus:not(.focus-visible)': {
                        outline: 'none',
                    },
                }}
                label={label}
                onClick={onClick}
                selected={expanded}
                customIcon={accordionIcon}
            />
        </Accordion>
    );
};

export default CustomerAccordion;
