import { useMemo } from 'react';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import VentureBanner from './ventureBanner';

const ConditionalVentureBanner = () => {
    const { vendor } = useVendor();
    const { config } = useConfigContext();
    const { lang } = useQlubRouter();

    const title = useMemo(() => {
        if (vendor?.config.voucherTitle) {
            return getLocaleText(vendor.config.voucherTitle, lang, config?.defaultLang || '');
        }
        return '';
    }, [vendor?.config.voucherTitle, lang, config?.defaultLang]);

    const description = useMemo(() => {
        if (vendor?.config.voucherDescription) {
            return getLocaleText(vendor.config.voucherDescription, lang, config?.defaultLang || '');
        }
        return '';
    }, [vendor?.config.voucherDescription, lang, config?.defaultLang]);

    return (
        <>
            {vendor &&
                vendor.config &&
                (vendor.config.voucherTitle || vendor.config.voucherDescription) &&
                (title || description) && <VentureBanner title={title} description={description} />}
        </>
    );
};

export default ConditionalVentureBanner;
