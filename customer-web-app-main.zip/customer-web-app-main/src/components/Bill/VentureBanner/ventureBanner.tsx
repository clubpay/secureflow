import { Box } from '@mui/material';
import { useEffect } from 'react';
import { KImage, Typography } from '@qlub-dev/qlub-kit';
import promotion from '@/assets/images/venture/promotion.svg';
import general from '@/assets/images/venture/general.svg';
import survey from '@/assets/images/venture/survey.svg';
import promotionDark from '@/assets/images/venture/promotion-dark.svg';
import generalDark from '@/assets/images/venture/general-dark.svg';
import surveyDark from '@/assets/images/venture/survey-dark.svg';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import useEventsCenter from '@/hooks/eventsCenter';
import useVenturestyle from './ventureBanner.style';

const ventureImages = {
    promotion,
    general,
    survey,
    generalDark,
    promotionDark,
    surveyDark,
    default: promotion,
};

interface VentureProps {
    title: string;
    description: string;
}

const VentureBanner = ({ title, description }: VentureProps) => {
    const { vendor } = useVendor();

    const {
        ventureBanner: { viewEvent, clickEvent },
    } = useEventsCenter();

    useEffect(() => {
        viewEvent();
    }, []);

    const { container, dec } = useVenturestyle(vendor?.config?.voucherStyle, !!(title && description));

    const getVentureImage = () => {
        return ventureImages[vendor?.config?.voucherType || 'default'];
    };

    const onBannerClicked = () => {
        clickEvent();
    };

    return (
        <Box sx={container} onClick={onBannerClicked}>
            <a href={vendor?.config?.voucherUrl}>
                <div>
                    <Typography typo="body_md" sx={{ pb: '4px' }}>
                        {title}
                    </Typography>
                    <Typography typo="body_sm" sx={dec}>
                        {description}
                    </Typography>
                </div>
                <KImage src={getVentureImage().src} alt="venture-img" />
            </a>
        </Box>
    );
};

export default VentureBanner;
