const useVenturestyle = (voucherStyle: string | undefined, singleItem: boolean) => {
    const container = {
        borderRadius: '8px',
        boxShadow:
            '0px 6px 10px rgba(97, 100, 117, 0.06), 0px 1px 18px rgba(97, 100, 117, 0.04), 0px 3px 5px rgba(97, 100, 117, 0.12);',
        margin: '0rem 1.5rem 2rem 1.5rem',

        display: 'flex',
        '>a': {
            display: 'flex',
            width: '100%',
            padding: '1rem',
        },
        '>a>div': {
            flex: '1 1',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: singleItem ? 'flex-start' : 'center',
        },
    };
    const dec = {
        fontWeight: '400 !important',
        fontSize: voucherStyle === 'medium' ? '1rem' : '0.875rem',
    };
    return {
        container,
        dec,
    };
};

export default useVenturestyle;
