/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import dynamic from 'next/dynamic';
import { IQrIProps } from '@/components/Bill/QR/qr';

const QRWidget = dynamic<IQrIProps>(() => import('@/components/Bill/QR/qr'), {
    loading: () => <>Loading</>,
    ssr: false,
});

export default QRWidget;
