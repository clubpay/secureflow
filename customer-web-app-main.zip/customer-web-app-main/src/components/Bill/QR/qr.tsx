/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import * as React from 'react';
import jsQR from 'jsqr';
import { Point } from 'jsqr/dist/locator';

import styles from './index.module.scss';

export interface IQrIProps {
    verbose?: boolean;
}

export default class QR extends React.Component<IQrIProps, any> {
    private qrCanvasRef: HTMLCanvasElement | undefined = undefined;

    private qrStart = false;

    constructor(props: IQrIProps) {
        super(props);

        this.state = {
            error: null,
        };
    }

    public componentDidMount() {
        if (!process.browser) {
            return;
        }

        this.initQRCode();
    }

    public componentWillUnmount() {
        this.stopQR();
    }

    private qrCanvasRefHandler = (ref: any) => {
        this.qrCanvasRef = ref;
    };

    private initQRCode() {
        if (!this.qrCanvasRef) {
            return;
        }

        this.qrStart = true;
        const video = document.createElement('video');
        const canvas = this.qrCanvasRef.getContext('2d');
        let tracks: any[] = [];

        function drawLine(begin: Point, end: Point, color: string) {
            if (!canvas) {
                return;
            }
            canvas.beginPath();
            canvas.moveTo(begin.x, begin.y);
            canvas.lineTo(end.x, end.y);
            canvas.lineWidth = 4;
            canvas.strokeStyle = color;
            canvas.stroke();
        }

        const tick = () => {
            if (!this.qrStart) {
                video.remove();
                tracks.forEach((track) => {
                    track.stop();
                });
                return;
            }

            if (this.qrCanvasRef && canvas && video.readyState === video.HAVE_ENOUGH_DATA) {
                this.qrCanvasRef.hidden = false;

                this.qrCanvasRef.height = video.videoHeight;
                this.qrCanvasRef.width = video.videoWidth;
                canvas.drawImage(video, 0, 0, this.qrCanvasRef.width, this.qrCanvasRef.height);
                const imageData = canvas.getImageData(0, 0, this.qrCanvasRef.width, this.qrCanvasRef.height);
                const code = jsQR(imageData.data, imageData.width, imageData.height, {
                    inversionAttempts: 'dontInvert',
                });
                // TODO: get the colors from qlub-kit
                if (code && code.data !== '') {
                    drawLine(code.location.topLeftCorner, code.location.topRightCorner, '#07ec19');
                    drawLine(code.location.topRightCorner, code.location.bottomRightCorner, '#07ec19');
                    drawLine(code.location.bottomRightCorner, code.location.bottomLeftCorner, '#07ec19');
                    drawLine(code.location.bottomLeftCorner, code.location.topLeftCorner, '#07ec19');
                }
            }
            requestAnimationFrame(tick);
        };

        // Use facingMode: environment to attempt to get the front camera on phones

        navigator.mediaDevices
            .getUserMedia({ video: { facingMode: 'environment' } })
            .then((stream) => {
                video.srcObject = stream;
                video.setAttribute('playsinline', 'true'); // required to tell iOS safari we don't want fullscreen
                video.play();
                tracks = stream.getTracks();
                requestAnimationFrame(tick);
            })
            .catch((err) => {
                console.log(err);
                this.setState({ error: true });
            });
    }

    private stopQR() {
        this.qrStart = false;
    }

    public render() {
        return (
            <div>
                {this.state.error && <div>You need to approve the camera usage permission to scan.</div>}
                <div className={styles.canvas}>
                    <canvas ref={this.qrCanvasRefHandler} height="320" width="320" />
                </div>
            </div>
        );
    }
}
