import { FC, useEffect, useState } from 'react';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Box, CircularProgress, IconButton, useTheme } from '@mui/material';
import { CardButton, Typography } from '@qlub-dev/qlub-kit';
import { getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import Format from '@qlub-dev/qlub-kit/dist/components/Format';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import ArrowBackIosNewRoundedIcon from '@mui/icons-material/ArrowBackIosNewRounded';
import useEventsCenter from '@/hooks/eventsCenter';
import BillAPIManager, { CampaignDiscountTypeEnum, IPaymentDetails } from '@/repositories/bill';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import DiscountFilledIcon from '@clubpay/customer-common-module/src/component/Icons/DiscountFilledIcon';
import DiscountIcon from '@clubpay/customer-common-module/src/component/Icons/DiscountIcon';
import { checkActiveCampaign } from '@clubpay/customer-common-module/src/utility/vendor';
import { CampaignVoucherStateEnum } from '@/repositories/bill/enums';
import VoucherModal from './VoucherModal';

import styles from './index.module.scss';

export enum VoucherViewEnum {
    Button = 'button',
    Card = 'Card',
}

interface IProps {
    diningSessionID: string;
    details: IPaymentDetails | undefined;
    onVoucherApply?: (data: IPaymentDetails) => void;
    config: IConfig | undefined | null;
    view?: VoucherViewEnum;
}

const VentureVoucher: FC<IProps> = ({ diningSessionID, details, config, view, onVoucherApply }) => {
    const { t } = useTranslation('common');
    const [open, setOpen] = useState<boolean>(false);
    const [loading, setLoading] = useState<boolean>(false);
    const [applied, setApplied] = useState<boolean>(!!details?.campaignVoucher?.code);

    const hasCorporateDiscountBeenApplied =
        details?.campaignVoucher?.discountType === CampaignDiscountTypeEnum.CORPORATE &&
        details?.campaignVoucher?.isVoucherOwner;

    const { vendor, currencyFormat } = useVendor();
    const { lang } = useQlubRouter();
    const theme = useTheme();
    const {
        voucherCampaign: { promoCodeEnabledEvent, tapOnPromoCodeTabEvent, editPromoCodeEvent, deletePromoCodeEvent },
    } = useEventsCenter();

    const hasActiveCampaign = checkActiveCampaign(config, vendor?.config?.voucherHasActiveCampaign, vendor?.brand.id);
    const { triggerAlternateSnackBar } = snackBar();

    useEffect(() => {
        if (details?.campaignVoucher?.code) {
            setApplied(true);
        }
    }, [details?.campaignVoucher?.code]);

    useEffect(() => {
        if (hasActiveCampaign) {
            promoCodeEnabledEvent();
        }
    }, [hasActiveCampaign]);

    if (!hasActiveCampaign) {
        return null;
    }

    if (!details) {
        return null;
    }

    if (
        hasCorporateDiscountBeenApplied ||
        (details.campaignVoucher?.redeemed === true &&
            details.campaignVoucher?.discountType === CampaignDiscountTypeEnum.CORPORATE)
    ) {
        return null;
    }

    const isPromoDisabled = details?.promoConditions?.isPromoDisabled;

    const getPromoButtonColor = () => {
        if (isPromoDisabled) {
            return theme.qlub.palette.onSurfaceColors.disabled;
        }
        if (details?.campaignVoucher?.redeemed || details?.campaignVoucher?.code) {
            return theme.qlub.palette.success.main;
        }
        return theme.qlub.palette.onSurfaceColors.mediumEmphasis;
    };

    const clickHandler = () => {
        if (details.promoConditions?.preventOpenModal) {
            return;
        }

        if (isPromoDisabled) {
            triggerAlternateSnackBar(
                <span
                    style={{
                        display: 'flow',
                    }}
                >
                    <strong>{`${t('Remember')}, `}</strong>
                    {details.promoConditions?.splitByOtherNotPaid
                        ? t('the promo code cannot be applied while another party is making a partial payment')
                        : t('the promo code cannot be applied if you are making a partial payment')}
                </span>,

                <DiscountFilledIcon color={theme.qlub.palette.iris.main} />,
            );
            return;
        }

        if (!details.yourSplitSettings.paymentDone || details.billNumber.remaining !== 0) {
            if (details.campaignVoucher?.code) {
                editPromoCodeEvent();
            } else {
                tapOnPromoCodeTabEvent();
            }
            setOpen(true);
        }
    };

    const callVoucherApi = (code: string | null) => {
        const sid = getSession();
        setLoading(true);
        return BillAPIManager.getInstance()
            .validateVoucherCode(
                {
                    code,
                    diningSessionID,
                    id: sid,
                },
                {
                    cc: vendor?.country.code || 'en',
                    vendor,
                },
            )
            .then((res) => {
                if (res?.paymentDetails) {
                    onVoucherApply?.(res.paymentDetails);
                    if (res.paymentDetails.campaignVoucher) {
                        if (vendor?.config?.disableSplitWithPromo) {
                            triggerAlternateSnackBar(
                                <span
                                    style={{
                                        display: 'flow',
                                    }}
                                >
                                    <strong>{`${t('Promotion applied.')} `}</strong>
                                    {t("Please note, bills with promo codes can't be split.")}
                                </span>,
                                <DiscountFilledIcon color={theme.qlub.palette.iris.main} />,
                            );
                        }
                        setApplied(true);
                    } else {
                        setApplied(false);
                    }
                }
                return res?.paymentDetails;
            })
            .finally(() => {
                setLoading(false);
            });
    };

    const toggleDrawerHandler = (state: boolean) => () => {
        setOpen(state);
    };

    const RenderModal = () => {
        return (
            <VoucherModal
                finalCode={details.campaignVoucher?.code}
                callVoucherApi={callVoucherApi}
                onToggleDrawer={toggleDrawerHandler}
                open={open}
            />
        );
    };

    if (view === VoucherViewEnum.Button) {
        return (
            <>
                <div onClick={clickHandler} className={styles.iconButtonContainer}>
                    <IconButton
                        data-qa-id="billing-new-voucher-button"
                        className={styles.iconButton}
                        sx={{ mr: 2 }}
                        disabled={
                            isPromoDisabled ||
                            details.campaignVoucherVisibilityState === CampaignVoucherStateEnum.Hidden
                        }
                    >
                        <DiscountIcon color={getPromoButtonColor()} />
                    </IconButton>
                </div>
                {RenderModal()}
            </>
        );
    }

    if (details.campaignVoucherVisibilityState === CampaignVoucherStateEnum.Hidden) {
        return null;
    }

    if (details.campaignVoucherVisibilityState === CampaignVoucherStateEnum.Used) {
        return (
            <Box sx={{ pt: 2 }}>
                <CardButton
                    greenStyle
                    cardContent={
                        <>
                            <Typography typo="body_sm">
                                <Format
                                    currencyFormat={currencyFormat}
                                    value={String(details.billNumber.voucherAmount)}
                                />
                                {` ${t('is saved with a promo code')}`}
                            </Typography>
                        </>
                    }
                />
            </Box>
        );
    }

    const removeVoucherHandler = (e: React.MouseEvent<HTMLElement>) => {
        e.stopPropagation();
        callVoucherApi(null).then((res: any) => {
            if (res) {
                deletePromoCodeEvent();
                setApplied(false);
            }
        });
    };

    const getIcon = () => {
        if (applied && !details.yourSplitSettings.paymentDone) {
            if (loading) return <CircularProgress size={24} />;
            return (
                <IconButton data-qa-id="promo-remove" onClick={removeVoucherHandler}>
                    <CloseRoundedIcon />
                </IconButton>
            );
        }
        if (!applied && lang === 'ar') {
            return <ArrowBackIosNewRoundedIcon />;
        }
        return null;
    };

    return (
        <Box sx={{ pt: 2 }}>
            <div data-qa-id="billing-add-promo" onClick={clickHandler}>
                <CardButton
                    greenStyle={applied}
                    cardContent={
                        applied ? (
                            <>
                                <Typography typo="body_sm">{t('Promotion applied')}</Typography>
                                <Typography typo="body_sm">
                                    {interpolateT(t('You saved <price> on this order!'), {
                                        price: (
                                            <Format
                                                currencyFormat={currencyFormat}
                                                value={String(details.billNumber.voucherAmount)}
                                            />
                                        ),
                                    })}
                                </Typography>
                            </>
                        ) : (
                            <Typography typo="body_sm">{t('Add Promotion Code')}</Typography>
                        )
                    }
                    actionButton={getIcon()}
                    disabled={isPromoDisabled}
                />
            </div>
            {RenderModal()}
        </Box>
    );
};

export default VentureVoucher;
