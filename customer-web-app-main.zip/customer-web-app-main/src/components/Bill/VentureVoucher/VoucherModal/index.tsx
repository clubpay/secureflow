import { FC, useEffect, useState } from 'react';
import * as Yup from 'yup';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Box, TextField } from '@mui/material';
import { Button, CustomerGrid, SwipeableCustomerDrawer } from '@qlub-dev/qlub-kit';
import { useFormik } from 'formik';
import useEventsCenter from '@/hooks/eventsCenter';

interface IVoucherForm {
    code: string;
}

interface IProps {
    onToggleDrawer: (state: boolean) => any;
    open: boolean;
    finalCode: string | undefined;
    callVoucherApi: (code: string) => Promise<any>;
}

const VoucherModal: FC<IProps> = ({ onToggleDrawer, callVoucherApi, finalCode, open }) => {
    const { t } = useTranslation('common');
    const {
        voucherCampaign: { applyPromoCodeEvent },
    } = useEventsCenter();
    const [loading, setLoading] = useState<boolean>(false);
    const validationSchema = Yup.object({
        code: Yup.string(),
    });
    const formSubmitHandler = async (values: IVoucherForm) => {
        setLoading(true);
        callVoucherApi(values.code)
            .then((res) => {
                if (res) {
                    applyPromoCodeEvent();
                    // eslint-disable-next-line @typescript-eslint/no-use-before-define
                    formik.values.code = '';
                    onToggleDrawer(false)();
                }
            })
            .catch((err) => {
                const errObject = err?.response?.data;
                if (errObject) {
                    // eslint-disable-next-line @typescript-eslint/no-use-before-define
                    formik.setFieldError('code', getError(errObject));
                }
            })
            .finally(() => {
                setLoading(false);
            });
    };
    const formik = useFormik({
        initialValues: {
            code: '',
        },
        validationSchema,
        onSubmit: formSubmitHandler,
    });

    const getError = (errObject: any) => {
        // eslint-disable-next-line default-case
        switch (errObject.code) {
            case 400:
                // eslint-disable-next-line default-case
                switch (errObject.items) {
                    case 'CAMPAIGN_TYPE_NOT_VALID':
                        return t('CAMPAIGN_TYPE_NOT_VALID');
                    case 'VALIDATION_FAILED':
                        return t('VALIDATION_FAILED');
                    case 'DISCOUNT_TYPE_NOT_VALID':
                        return t('DISCOUNT_TYPE_NOT_VALID');
                    case 'TIME_RANGE_NOT_VALID':
                        return t('TIME_RANGE_NOT_VALID');
                    case 'INSUFFICIENT_CODE_PLACEHOLDERS':
                        return t('INSUFFICIENT_CODE_PLACEHOLDERS');
                    case 'DISCOUNT_ALREADY_USED':
                        return t('DISCOUNT_ALREADY_USED');
                    case 'DISCOUNT_CODE_NOT_VALID':
                        return t('DISCOUNT_CODE_NOT_VALID');
                    case 'VOUCHER_NOT_VALID':
                        return t('VOUCHER_NOT_VALID');
                    case 'VOUCHER_EXCEEDS_REMAINING_AMOUNT':
                        return t('VOUCHER_EXCEEDS_REMAINING_AMOUNT');
                    case 'CAMPAIGN_NOT_FOUND':
                        return t('CAMPAIGN_NOT_FOUND');
                    case 'SERVICE_FAILURE':
                        return t('SERVICE_FAILURE');
                    case 'VOUCHER_NOT_VALID_IN_BILL_RANGE':
                        return t('VOUCHER_NOT_VALID_IN_BILL_RANGE');
                }
                break;
            case 404:
                // eslint-disable-next-line default-case
                switch (errObject.items) {
                    case 'CAMPAIGN_NOT_FOUND':
                        return t('CAMPAIGN_NOT_FOUND');
                    case 'DINING_SESSION_NOT_FOUND':
                        return t('DINING_SESSION_NOT_FOUND');
                    case 'DISCOUNT_NOT_FOUND':
                        return t('DISCOUNT_NOT_FOUND');
                }
                break;
            case 500:
                if (errObject.items === 'SERVICE_FAILURE') {
                    return t('SERVICE_FAILURE');
                }
                break;
        }
    };

    useEffect(() => {
        if (open) {
            formik.setFieldValue('code', finalCode || '');
        }
    }, [open, finalCode]);

    const modalCloseHandler = () => {
        formik.setFieldError('code', undefined);
        onToggleDrawer(false)();
    };

    return (
        <SwipeableCustomerDrawer
            headerTitle={t('Add Promotion Code')}
            caption={t('Promo code reduces bill amount, tips not included')}
            hasRadius
            hasOverflow
            anchor="bottom"
            open={open}
            onClose={modalCloseHandler}
            onOpen={onToggleDrawer(true)}
            BackdropProps={{
                sx: {
                    background: '#00000099',
                },
            }}
            PaperProps={{ elevation: 0, sx: { background: 'transparent' } }}
            sx={{
                '& p:first-child': {
                    pt: 0,
                    pb: 2,
                    px: 0,
                },
                'div[title="drawer content"] ': {
                    '&>div:first-child': {
                        pb: 1,
                    },
                },
            }}
            contentStyle={{}}
            qaIds={{
                closeBtnId: 'promo-close',
                titleId: 'promo-modal-title',
                captionId: 'promo-modal-info',
            }}
        >
            <div>
                <form onSubmit={formik.handleSubmit}>
                    <Box sx={{ pt: 1 }}>
                        <CustomerGrid container>
                            <TextField
                                autoFocus
                                color="primary"
                                id="voucher-code"
                                fullWidth
                                name="code"
                                type="text"
                                label={t('Code')}
                                autoComplete="off"
                                value={formik.values.code}
                                error={!!formik.errors.code}
                                helperText={formik.errors.code || ' '}
                                onChange={formik.handleChange}
                            />
                        </CustomerGrid>
                    </Box>
                    <Box sx={{ py: 3 }}>
                        <Button
                            data-qa-id="promo-apply"
                            disabled={!formik.values.code}
                            variant="contained"
                            size="large"
                            fullWidth
                            type="submit"
                            loading={loading}
                        >
                            {t('Apply')}
                        </Button>
                    </Box>
                </form>
            </div>
        </SwipeableCustomerDrawer>
    );
};
export default VoucherModal;
