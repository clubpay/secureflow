import React from 'react';
// import { Google } from '@/components/Common/SVG';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';

import { CustomerContainer, Typography } from '@qlub-dev/qlub-kit';
import styles from './index.module.scss';

interface IProps {
    placeId?: string;
    opsMode: string;
    pgName: string;
}

export default function GoogleReviewWidget({ placeId, opsMode, pgName }: IProps) {
    const { t } = useTranslation('common');
    const clickReviewHandler = () => {
        onPushEvent('add_google_review', {
            opsMode,
            pg_name: pgName,
            diningSessionId: '',
        });
    };

    return (
        <CustomerContainer padding="xs" centered className={styles.googleWrapper}>
            <a
                className={styles.button}
                href={`https://search.google.com/local/writereview?placeid=${placeId}`}
                target="_blank"
                rel="noreferrer"
                onClick={clickReviewHandler}
            >
                <div className={styles.googleSvg} />
                <Typography typo="title_sm" className={styles.googleText}>
                    {t('review this place')}
                </Typography>
            </a>
        </CustomerContainer>
    );
}
