import React, { useEffect, useState } from 'react';
import Tooltip from '@mui/material/Tooltip';
import ClickAwayListener from '@mui/material/ClickAwayListener';
import Fade from '@mui/material/Fade';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor';
import MultiLocale, { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

interface IDinerFeeTooltipProps {
    vendor: IRestaurant | undefined;
    children: React.ReactElement;
    countryConfig: IConfig | undefined | null;
}

const DinerFeeTooltip = ({ vendor, children, countryConfig }: IDinerFeeTooltipProps) => {
    const { t } = useTranslation('common');
    const { lang } = useQlubRouter();
    const [open, setOpen] = useState<boolean>(false);

    /**
     * This is the function that handles the scroll event on the tooltip and sends first log
     * It closes the tooltip
     */

    const handleViewLog = () => {
        console.log('View log');
    };

    const handleTooltipClick = () => {
        setOpen(() => !open);
    };

    const handleTooltipClose = () => {
        setOpen(false);
    };

    /*
     * This is the function that handles the click away event on the tooltip
     * It closes the tooltip
     */

    useEffect(() => {
        handleViewLog();
        window.addEventListener('scroll', handleTooltipClose);
        return () => {
            window.removeEventListener('scroll', handleTooltipClose);
        };
    }, []);

    /**
     * This is the function that handles the click event on the tooltip
     * It changes the state of the tooltip to open or close
     */

    const getTitle = () => {
        if (vendor?.config.showDinerFeeTooltip === 'show') {
            const title = getLocaleText(vendor?.config.dinerFeeTooltipText as string, lang, '');

            return <MultiLocale value={title} lang={lang} />;
        }

        if (countryConfig?.showDinerFeeTooltip === 'show') {
            const title = getLocaleText(countryConfig?.dinerFeeTooltipText as string, lang, '');

            return <MultiLocale value={title} lang={lang} />;
        }
    };

    return (
        <>
            <ClickAwayListener onClickAway={handleTooltipClose}>
                <Tooltip
                    PopperProps={{
                        disablePortal: true,
                    }}
                    componentsProps={{
                        tooltip: {
                            sx: {
                                border: '1px solid #EBECF2',
                                marginTop: '0 !important',
                                backgroundColor: '#fff',
                                color: '#616475',
                                borderColor: '#EBECF2',
                                padding: '16px 24px',
                                borderRadius: '8px',
                                boxShadow:
                                    '0px 2px 4px 0px rgba(97, 100, 117, 0.12), 0px 1px 10px 0px rgba(97, 100, 117, 0.04), 0px 4px 5px 0px rgba(97, 100, 117, 0.06)',
                                margin: '0 auto',
                                maxWidth: 'calc(100% - 40px)',

                                '& .MuiTooltip-arrow::before': {
                                    border: '1px solid #EBECF2',
                                    backgroundColor: '#fff',
                                },
                            },
                        },
                    }}
                    onClose={handleTooltipClose}
                    open={open}
                    disableFocusListener
                    disableHoverListener
                    disableTouchListener
                    title={
                        <div
                            style={{
                                overflow: 'hidden',
                                display: '-webkit-box',
                                WebkitLineClamp: 8,
                                WebkitBoxOrient: 'vertical',
                            }}
                        >
                            {getTitle()?.props.value
                                ? getTitle()
                                : t(
                                      "The fee is for the provision of fast checkout service using Qlub, which also allows you to split the bill in seconds and to get you receipt sent to your inbox, this way you don't need to waste time waiting for the paper bill and the card machine",
                                  )}
                        </div>
                    }
                    onClick={handleTooltipClick}
                    TransitionComponent={Fade}
                    TransitionProps={{ timeout: 600 }}
                >
                    <div>{children}</div>
                </Tooltip>
            </ClickAwayListener>
        </>
    );
};

export default DinerFeeTooltip;
