import React, { useEffect, useState } from 'react';
import {
    FacebookLogo,
    InstagramLogo,
    TripAdvisorLogo,
    TwitterLogo,
    TiktokLogo,
    WebsiteLogo,
} from '@clubpay/customer-common-module/src/component/SVG';
import { IconButton } from '@mui/material';
import { parseJSON } from '@clubpay/customer-common-module/src/utility/k_json';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import Typography from '@qlub-dev/qlub-kit/dist/components/Typography';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { KeyboardArrowLeftRounded, KeyboardArrowRightRounded } from '@mui/icons-material';
import MultiLocale, {
    ILocaleValue,
    validateMultiLocale,
} from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';

import styles from './index.module.scss';

const socialIcons: { [key: string]: JSX.Element } = {
    facebook: <FacebookLogo />,
    instagram: <InstagramLogo />,
    twitter: <TwitterLogo />,
    website: <WebsiteLogo />,
    tripadvisor: <TripAdvisorLogo />,
    tiktok: <TiktokLogo />,
};

interface SocialLink {
    key: string;
    value: string;
    icon: JSX.Element;
}

const SocialMedia = () => {
    const [socialLinks, setSocialLinks] = useState<SocialLink[]>([]);
    const [socialHeader, setSocialHeader] = useState<ILocaleValue[] | null>(null);

    const { t } = useTranslation('common');
    const { url, lang } = useQlubRouter();
    const { vendor } = useVendor();

    const data = vendor?.config?.socialMedia;
    const header = vendor?.config.socialMediaHeader;

    const transformIconsToSocialLinks = (links: SocialLink[]): SocialLink[] => {
        return links.reduce((acc: SocialLink[], sLink) => {
            if (socialIcons?.hasOwnProperty(sLink.key)) {
                const icon = socialIcons[sLink.key];
                acc.push({
                    ...sLink,
                    icon,
                });
            }
            return acc;
        }, [] as SocialLink[]);
    };

    useEffect(() => {
        if (typeof data !== 'string') {
            return;
        }
        setSocialLinks(transformIconsToSocialLinks(parseJSON(data)));
    }, [data]);

    useEffect(() => {
        setSocialHeader(parseJSON(header));
    }, [header]);

    const onSelectSocialMedia = (type: string) => {
        onPushEvent('click_on_social_media', {
            restaurant_name: url.slug,
            type,
        });
    };

    if (!data || socialLinks.length === 0) {
        return null;
    }

    if (socialLinks.length === 1) {
        return (
            <>
                <a href={socialLinks[0]?.value || ''} target="_blank" rel="noreferrer">
                    <div className={styles.container} onClick={() => onSelectSocialMedia(socialLinks[0]?.key)}>
                        <IconButton className={styles.socialMediaIconWrapper}>{socialLinks[0]?.icon}</IconButton>
                        <div className={styles.info}>
                            <Typography typo="body_md" className={styles.title}>
                                {socialLinks[0]?.key}
                            </Typography>
                            <Typography typo="body_sm" className={styles.subTitle}>
                                {socialHeader && validateMultiLocale(socialHeader) ? (
                                    <MultiLocale value={socialHeader} lang={lang} />
                                ) : (
                                    t('Follow us on social media')
                                )}
                            </Typography>
                        </div>
                        {lang === 'ar' ? <KeyboardArrowLeftRounded /> : <KeyboardArrowRightRounded />}
                    </div>
                </a>
            </>
        );
    }

    return (
        <>
            <div className={styles.mutipleContainer}>
                <Typography typo="title_md" className={styles.title}>
                    {socialHeader && validateMultiLocale(socialHeader) ? (
                        <MultiLocale value={socialHeader} lang={lang} />
                    ) : (
                        t('Follow us on social media')
                    )}
                </Typography>
                <div className={styles.socialMediaIcons}>
                    {socialLinks.map((sLink) =>
                        sLink?.value ? (
                            <a key={sLink.key} target="_blank" href={sLink?.value} rel="noreferrer">
                                <IconButton
                                    className={styles.socialMediaIconWrapper}
                                    onClick={() => onSelectSocialMedia(sLink?.key)}
                                >
                                    {sLink.icon}
                                </IconButton>
                            </a>
                        ) : null,
                    )}
                </div>
            </div>
        </>
    );
};

export default React.memo(SocialMedia);
