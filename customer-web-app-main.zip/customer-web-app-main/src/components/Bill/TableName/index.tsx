import { getTableTitle } from '@/services/utils/config';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import {
    BillPageDescriptionModeEnum,
    IQrDetailsResponse,
    IRestaurant,
} from '@clubpay/customer-common-module/src/repository/vendor';
import { IPaymentDetails } from '@/repositories/bill';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

interface ITableNameProps {
    config?: IConfig | null;
    vendor?: IRestaurant;
    tableInfo?: IQrDetailsResponse;
}

const NewTableName = ({ vendor, config, tableInfo }: ITableNameProps) => {
    const { t } = useTranslation('common');
    switch (vendor?.config.billPageDescriptionMode || config?.billPageDescriptionMode) {
        case BillPageDescriptionModeEnum.PreferredTableName:
            return t('Table: {{name}}', { name: tableInfo?.table.preferredName || tableInfo?.table.id || '' });
        case BillPageDescriptionModeEnum.TableId:
            return t('Table: {{name}}', { name: tableInfo?.table.id || '' });
        case BillPageDescriptionModeEnum.TableName:
            return t('Table: {{name}}', { name: tableInfo?.table.tableName || tableInfo?.table.id || '' });
        default:
            return null;
    }
};

interface IProps {
    config?: IConfig | null;
    vendor?: IRestaurant;
    details?: IPaymentDetails;
    placeholder?: any;
    tableInfo?: IQrDetailsResponse;
}

export const TableName = ({ config, vendor, details, tableInfo, placeholder }: IProps) => {
    const { t } = useTranslation('common');
    if (vendor?.config.billPageDescriptionMode || config?.billPageDescriptionMode) {
        return <NewTableName config={config} vendor={vendor} tableInfo={tableInfo} />;
    }

    const { pager, text } = getTableTitle(
        vendor,
        tableInfo?.table.tableName || details?.tableName || '',
        tableInfo?.table.id || details?.tableID || placeholder || '',
    );

    if (text) {
        if (text === '0' && vendor?.orderConfig?.pagerEnable) {
            if (!vendor?.orderConfig?.enablePagerAssignMessage) {
                return null;
            }

            return <>{t('Pager will be assigned after the submit')}</>;
        }

        return <>{`${pager ? t('Pager') : t('Table')} ${text}`}</>;
    }

    return placeholder || null;
};

export default TableName;
