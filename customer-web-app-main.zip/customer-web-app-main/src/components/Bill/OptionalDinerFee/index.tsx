import React, { Dispatch, SetStateAction, useMemo } from 'react';
import { EnableEnum, IRestaurant, ODFTypeEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { IPaymentDetails } from '@/repositories/bill';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import dynamic from 'next/dynamic';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import useODFAvailabilityCheck from '../../../hooks/odf-availability';

const ODFCheckBox = dynamic(() => import('./ODFCheckBox'));
const ODFBanner = dynamic(() => import('./ODFBanner'));

interface IProps {
    currencyFormat: CurrencyFormat;
    vendor: IRestaurant | undefined;
    config: IConfig | undefined;
    details: IPaymentDetails;
    checked: boolean;
    setChecked: Dispatch<SetStateAction<boolean>>;
}

const OptionalDinerFee = ({ vendor, details, checked, setChecked, config, currencyFormat }: IProps) => {
    const { lang } = useQlubRouter();
    const { t } = useTranslation('common');

    const [tooltipText, label] = useMemo(() => {
        return [
            getLocaleText(vendor?.config.commissionOptionalDinerFeeTooltip || '', lang, ''),
            getLocaleText(vendor?.config.commissionOptionalDinerFeeLabel || '', lang, '') || t('Fast checkout fees'),
        ];
    }, [vendor, lang]);

    const uiType = useMemo(() => {
        if (vendor?.config?.commissionOptionalDinerFee === EnableEnum.Enable) {
            return vendor?.config?.commissionOptionalDinerFeeUiType;
        }
        return config?.commissionOptionalDinerFeeUiType;
    }, [
        vendor?.config?.commissionOptionalDinerFee,
        vendor?.config?.commissionOptionalDinerFeeUiType,
        config?.commissionOptionalDinerFeeUiType,
    ]);

    const isODFAvailable = useODFAvailabilityCheck({ odf: details?.bill?.optionalDinerFee });

    if (!isODFAvailable) {
        return null;
    }

    if (uiType === ODFTypeEnum.CheckBox) {
        return (
            <ODFCheckBox
                currencyFormat={currencyFormat}
                details={details}
                checked={checked}
                setChecked={setChecked}
                tooltipText={tooltipText}
                label={label}
            />
        );
    }

    return (
        <ODFBanner
            currencyFormat={currencyFormat}
            details={details}
            checked={checked}
            setChecked={setChecked}
            tooltipText={tooltipText}
            label={label}
        />
    );
};

export default OptionalDinerFee;
