import React, { Dispatch, SetStateAction } from 'react';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { Checkbox } from '@mui/material';
import { IPaymentDetails } from '@/repositories/bill';
import { Divider, Price } from '@qlub-dev/qlub-kit';
import Box from '@mui/material/Box';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import Tooltip from '@/components/Bill/Tooltip';
import { StackElements } from '@qlub-dev/qlub-kit/dist/components/StackElements';
import styles from './index.module.scss';

interface IProps {
    currencyFormat: CurrencyFormat;
    details: IPaymentDetails;
    checked: boolean;
    setChecked: Dispatch<SetStateAction<boolean>>;
    tooltipText: string;
    label: string;
}

const ODFCheckBox = ({ currencyFormat, details, checked, setChecked, label, tooltipText }: IProps) => {
    return (
        <>
            <div className={styles.container}>
                <div className={styles.checkbox}>
                    <Checkbox checked={checked} onChange={(e) => setChecked(e.target.checked)} />
                </div>
                <div className={styles.label}>{label}</div>
                <StackElements direction="row" alignItems="center" justifyContent="center" spacing={2}>
                    <Price
                        value={details?.bill?.yourOptionalDinerFee || '0'}
                        currencyFormat={{
                            ...currencyFormat,
                            currencyPrecision: details?.currencyPrecision || currencyFormat?.currencyPrecision,
                        }}
                    />
                    {!!tooltipText && (
                        <Tooltip toolTipText={tooltipText}>
                            <div className={styles.tooltip}>
                                <InfoOutlinedIcon className={styles.icon} />
                            </div>
                        </Tooltip>
                    )}
                </StackElements>
            </div>
            <Box>
                <Divider type="fullWidth" />
            </Box>
        </>
    );
};

export default ODFCheckBox;
