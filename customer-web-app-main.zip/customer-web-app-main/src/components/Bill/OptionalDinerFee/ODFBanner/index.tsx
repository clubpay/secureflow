import React, { Dispatch, SetStateAction } from 'react';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { IconButton } from '@mui/material';
import { IPaymentDetails } from '@/repositories/bill';
import { Divider, Price } from '@qlub-dev/qlub-kit';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import CloseRounded from '@mui/icons-material/CloseRounded';
import Tooltip from '@/components/Bill/Tooltip';

import styles from './index.module.scss';

interface IProps {
    currencyFormat: CurrencyFormat;
    details: IPaymentDetails;
    checked: boolean;
    setChecked: Dispatch<SetStateAction<boolean>>;
    tooltipText: string;
    label: string;
}

const ODFBanner = ({ currencyFormat, details, setChecked, checked, tooltipText, label }: IProps) => {
    if (!checked) {
        return null;
    }

    return (
        <>
            <div className={styles.container}>
                <div className={styles.info}>
                    <div className={styles.label}>{label}:</div>
                    <div className={styles.fee}>
                        <Price
                            typo="tip_single_line_multi_line_top_currency_value"
                            value={details?.bill?.yourOptionalDinerFee || '0'}
                            currencyFormat={{
                                ...currencyFormat,
                                currencyPrecision: details?.currencyPrecision || currencyFormat?.currencyPrecision,
                            }}
                        />
                        {!!tooltipText && (
                            <Tooltip toolTipText={tooltipText}>
                                <div className={styles.tooltip}>
                                    <InfoOutlinedIcon className={styles.icon} />
                                </div>
                            </Tooltip>
                        )}
                    </div>
                </div>
                <IconButton
                    className={styles.close}
                    onClick={() => {
                        setChecked(false);
                    }}
                >
                    <CloseRounded />
                </IconButton>
            </div>
            <div>
                <Divider type="fullWidth" />
            </div>
        </>
    );
};

export default ODFBanner;
