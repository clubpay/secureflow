import { qlubSessionStorage } from '@clubpay/customer-common-module/src/service/storage/sessionStorage';
import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import { CheckEnum, ODFTypeEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';

const okfKey = 'qlub.odf';

export function setODF(val: boolean) {
    qlubSessionStorage.set(okfKey, val ? 'true' : 'false');
}

export function getODF() {
    const v = qlubSessionStorage.get(okfKey);
    if (v) {
        return v === 'true';
    }
    return null;
}

export function getODFDefault({ vendor, config }: { vendor: IRestaurant | undefined; config: IConfig | undefined }) {
    const uiType = vendor?.config?.commissionOptionalDinerFeeUiType || config?.commissionOptionalDinerFeeUiType;
    if (uiType === ODFTypeEnum.CheckBox) {
        return (
            getODF() ??
            (vendor?.config?.commissionOptionalDinerFeeDefault || config?.commissionOptionalDinerFeeDefault) ===
                CheckEnum.Check ??
            true
        );
    }
    return getODF() ?? true;
}
