/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useMemo, useState } from 'react';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import Link from 'next/link';
import { AppBar, IconButton, Toolbar, useTheme, Drawer, Divider, List, ListItem, ListItemText } from '@mui/material';
import { ChevronLeftRounded, ChevronRightRounded, ArrowBackRounded, ArrowForwardRounded } from '@mui/icons-material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { getAvailableLang } from '@clubpay/customer-common-module/src/utility/k_lang';

import styles from './index.module.scss';

const backBtnFilter = [
    '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice/success',
    '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice/pending',
    '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice/fail',
];

export default function Navigator() {
    const { t } = useTranslation('common');
    const { url, urlStr, lang, pathname, routerPush } = useQlubRouter();
    const [open, setOpen] = useState(false);
    const theme = useTheme();

    const drawerCloseHandler = () => {
        setOpen(false);
    };

    const moveBackHandler = () => {
        routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]');
    };

    const modifyLink = (link: any) => {
        if (url.cc) {
            return {
                pathname: link.pathname,
                query: link.query,
            };
        }
        return link;
    };

    const menuItems = useMemo(
        () => [
            {
                name: t('Home'),
                link: url.slug
                    ? {
                          pathname: '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]',
                          query: {
                              ...url,
                          },
                      }
                    : { pathname: '/' },
            },
            {
                name: t('Menu'),
                link: url.slug
                    ? {
                          pathname: '/qr/[cc]/[slug]/[id]/menu',
                          query: {
                              cc: url.cc,
                              slug: url.slug,
                              id: url.id || '_',
                              ...getAvailableLang(lang),
                          },
                      }
                    : { pathname: '/' },
            },
            {
                name: t('Info'),
                link: url.slug
                    ? {
                          pathname: '/qr/[cc]/[slug]/[id]/info',
                          query: {
                              cc: url.cc,
                              slug: url.slug,
                              id: url.id || '_',
                              ...getAvailableLang(lang),
                          },
                      }
                    : { pathname: '/' },
            },
            {
                name: '',
                link: '',
                divider: true,
            },
            {
                name: t('About'),
                link: {
                    pathname: '/about',
                },
            },
            {
                name: t('Privacy and Policy'),
                link: {
                    pathname: '/privacy',
                },
            },
            {
                name: t('Terms and Conditions'),
                link: {
                    pathname: '/terms',
                },
            },
        ],
        [urlStr, lang],
    );

    return (
        <div className={styles.navigator}>
            {backBtnFilter.indexOf(pathname) > -1 && (
                <AppBar position="absolute" color="transparent" elevation={0}>
                    <Toolbar>
                        <IconButton color="inherit" aria-label="open drawer" onClick={moveBackHandler} edge="start">
                            {theme.direction === 'ltr' ? (
                                <ArrowBackRounded fontSize="large" />
                            ) : (
                                <ArrowForwardRounded fontSize="large" />
                            )}
                        </IconButton>
                    </Toolbar>
                </AppBar>
            )}
            <Drawer
                variant="persistent"
                anchor="left"
                open={open}
                classes={{
                    paper: styles.drawerPaper,
                }}
            >
                <div className={styles.header}>
                    <div className={styles.text}>{t('Qlub_')}</div>
                    <IconButton onClick={drawerCloseHandler}>
                        {theme.direction === 'ltr' ? <ChevronLeftRounded /> : <ChevronRightRounded />}
                    </IconButton>
                </div>
                <Divider />
                <List>
                    {menuItems.map((item, index) => {
                        if (item.divider) {
                            return <Divider key={`d_${index}`} />;
                        }
                        return (
                            <ListItem button key={`${item.name}_${index}`} onClick={drawerCloseHandler}>
                                <Link href={modifyLink(item.link)} passHref>
                                    <ListItemText primary={item.name} className={styles.listItem} />
                                </Link>
                            </ListItem>
                        );
                    })}
                </List>
            </Drawer>
        </div>
    );
}
