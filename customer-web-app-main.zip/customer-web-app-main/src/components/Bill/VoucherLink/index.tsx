import React from 'react';
import { Typography } from '@mui/material';
import MultiLocale from '@clubpay/customer-common-module/src/component/MultiLocale';

import styles from './index.module.scss';

interface IProps {
    url: string;
    title: string;
}

export default function VoucherLink({ url, title }: IProps) {
    return (
        <a className={styles.voucherWrapper} href={url} rel="noreferrer">
            <div className={styles.svgWrapper}>
                <svg width={12} height={12} fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        fillRule="evenodd"
                        clipRule="evenodd"
                        d="M6.599.5a1.2 1.2 0 0 0-.848.351L.35 6.247a1.2 1.2 0 0 0 0 1.698l4.207 4.204a1.2 1.2 0 0 0 1.696 0l5.395-5.397A1.2 1.2 0 0 0 12 5.903V1.7A1.2 1.2 0 0 0 10.8.5H6.6ZM8.7 4.701a.899.899 0 1 0-.9-.9c0 .498.402.9.9.9Z"
                        fill="#616475"
                    />
                </svg>
            </div>
            <Typography className={styles.voucherText}>
                <MultiLocale value={title} />
            </Typography>
        </a>
    );
}
