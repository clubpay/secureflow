import { useMemo } from 'react';
import { PriceItem, SplitPriceLabel } from '@qlub-dev/qlub-kit';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useForexStore } from '@clubpay/payment-kit';

interface IProps {
    currencyPrecision: number;
    total: number;
    tip: number | string;
}

export const useYouPayFinalAmount = ({ tip, total, currencyPrecision }: IProps) => {
    const { vendor } = useVendor();
    const { t } = useTranslation('common');
    const forex = useForexStore();

    const priceData = useMemo(() => {
        const array: PriceItem[] = [
            {
                label: SplitPriceLabel.yourShare,
                text: t('You pay'),
                value: forex.isApplied ? forex.total : total,
                qaTextId: 'billing-you-pay',
            },
        ];

        const newTip = forex.isApplied
            ? sumAmounts(currencyPrecision, forex.tip || 0)
            : sumAmounts(currencyPrecision, tip);

        if (newTip > 0 && vendor?.config.showTipValueDetails) {
            array.unshift({
                label: SplitPriceLabel.tip,
                text: t('Tip amount'),
                value: newTip,
            });
        }

        return array;
    }, [tip, total, currencyPrecision, forex, t, vendor?.config.showTipValueDetails]);

    return {
        priceData,
    };
};
