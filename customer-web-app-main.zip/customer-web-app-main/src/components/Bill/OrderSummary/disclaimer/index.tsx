import React, { ReactNode } from 'react';
import { Trivia } from '@qlub-dev/qlub-kit';
import { StackElements } from '@qlub-dev/qlub-kit/dist/components/StackElements';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import classNames from 'classnames';
import { ThemeModeEnum } from '@clubpay/customer-common-module/src/context/config';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';

import styles from './index.module.scss';

interface IProps {
    title: string;
    description: string | ReactNode;
}

const Disclaimer = ({ title, description }: IProps) => {
    const { theme } = useQlubRouter();

    return (
        <div className={styles.container}>
            <Trivia
                disableIcon
                triviaOverrides={{
                    borderRadius: '1rem',
                }}
                message={
                    <>
                        <StackElements direction="row" alignItems="center" spacing={1}>
                            <InfoOutlinedIcon fontSize="small" /> <span className={styles.title}>{title}</span>
                        </StackElements>
                        <div
                            className={classNames(styles.description, {
                                [styles.blackMode]: theme === ThemeModeEnum.Black,
                            })}
                        >
                            {description}
                        </div>
                    </>
                }
            />
        </div>
    );
};

export default Disclaimer;
