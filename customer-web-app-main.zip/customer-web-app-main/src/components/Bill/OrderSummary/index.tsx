import { FC, useMemo, useState } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Button, CustomerGrid, Divider, SwipeableCustomerDrawer, TotalPrice, Typography } from '@qlub-dev/qlub-kit';
import { Box } from '@mui/material';
import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor';
import { InvoiceBill, InvoiceOrder } from '@/components/Bill/InvoiceItem';
import { IPaymentDetails } from '@/repositories/bill';
import { DiscountLineItem } from '@clubpay/loyalty/dist/drivers/customer/Subscription/LineItem';
import { SubscriptionCompletionPrompt } from '@clubpay/loyalty/dist/drivers/customer/Subscription/CompletionPrompt';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ChangeCurrency from '@/components/Bill/ChangeCurrency';
import { useGetInclusiveChargesMessage } from '@/hooks/getInclusiveChargesMessage';
import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { ForexCurrencyChangeV2, setForex, useForexStore } from '@clubpay/payment-kit';
import InvoiceDisclaimer from './disclaimer';
import { useYouPayFinalAmount } from './hook';

import styles from './index.module.scss';

interface IProps {
    loading: boolean;
    currencyPrecision: number;
    total: number;
    tip: number | string;
    yourShareAmount: string;
    details: IPaymentDetails;
    lang: string | null;
    vendor: IRestaurant;
    scrollToElement: () => void;
    id: string;
    hasSplitPayment?: boolean;
    currencyFormat: CurrencyFormat;
}

const OrderSummary: FC<IProps> = ({
    loading,
    currencyPrecision,
    scrollToElement,
    id,
    lang,
    vendor,
    details,
    total,
    tip,
    currencyFormat,
}) => {
    const { t } = useTranslation('common');
    const { inclusiveChargesMessage } = useGetInclusiveChargesMessage({
        tip: Number(tip),
    });

    const [open, setOpen] = useState(false);
    const [showChangeCurrency, setShowChangeCurrency] = useState(false);

    const forex = useForexStore();

    const forexUI = vendor.config.forexUI ?? 'v2';

    const toggleChangeCurrency = () => setShowChangeCurrency(!showChangeCurrency);

    const changeCurrencyHandler = (currency: string | null) => {
        if (currency === forex?.currencyCode) setForex({ isApplied: true });
        else if (forex.isInterrupted) setForex({ isApplied: false });
    };

    const toggleDrawerHandler = (state: boolean) => () => {
        setOpen(state);
    };

    const onPayBill = () => {
        scrollToElement();
        setOpen(false);
    };

    const { priceData } = useYouPayFinalAmount({
        tip,
        total,
        currencyPrecision,
    });

    const { disclaimerHeading, disclaimerDescription, direction } = useMemo(() => {
        const getDisclaimerText = (key: 'invoiceDisclaimerHeading' | 'invoiceDisclaimerDescription', langVal: string) =>
            getLocaleText(vendor?.config[key] || '', langVal, '');

        const langHeading = getDisclaimerText('invoiceDisclaimerHeading', lang || '');
        const langDescription = getDisclaimerText('invoiceDisclaimerDescription', lang || '');
        const enHeading = getDisclaimerText('invoiceDisclaimerHeading', 'en');
        const enDescription = getDisclaimerText('invoiceDisclaimerDescription', 'en');

        if (langHeading && langDescription) {
            return {
                disclaimerHeading: langHeading,
                disclaimerDescription: langDescription,
                direction: lang === 'ar' ? 'rtl' : 'ltr',
            };
        }

        if (enHeading && enDescription) {
            return { disclaimerHeading: enHeading, disclaimerDescription: enDescription, direction: 'ltr' };
        }

        return { disclaimerHeading: null, disclaimerDescription: null, direction: 'ltr' };
    }, [vendor?.config, lang]);

    return (
        <div className={styles.container}>
            {disclaimerHeading && disclaimerDescription && (
                <div dir={direction} className={styles.disclaimer}>
                    <InvoiceDisclaimer title={disclaimerHeading} description={disclaimerDescription} />
                    <Divider type="fullWidth" />
                </div>
            )}

            {forexUI === 'v1' && (
                <ChangeCurrency
                    open={showChangeCurrency}
                    vendorCurrency={vendor?.country.currencySymbol}
                    total={total}
                    currencyPrecision={currencyPrecision || 0}
                    onChange={changeCurrencyHandler}
                    onClose={toggleChangeCurrency}
                    onOpen={toggleChangeCurrency}
                />
            )}
            {forex.isInterrupted && forexUI === 'v2' && <ForexCurrencyChangeV2 />}

            <DiscountLineItem style={{ marginBottom: 8 }} />

            <TotalPrice
                Button={
                    vendor?.config.showOrderDetails && (
                        <Button
                            onClick={toggleDrawerHandler(true)}
                            size="small"
                            sx={{
                                fontSize: '12px',
                                padding: '0px .5rem',
                                minHeight: 'fit-content',
                                '&:focus': {
                                    border: 'solid 1px transparent',
                                },
                                '&:active': {
                                    border: 'solid 1px transparent',
                                },
                            }}
                        >
                            {t('Order details')}
                        </Button>
                    )
                }
                priceData={priceData}
                currencyFormat={{
                    ...currencyFormat,
                    cs: forex?.isApplied ? forex.currencyCode! : currencyFormat.cs,
                }}
                loading={loading}
            />
            {forex?.isApplied && forexUI === 'v1' && (
                <div className={styles.forexContainer}>
                    <Typography typo="caption_overline" sx={{ color: '#9b9eab' }}>
                        FX: 1 {vendor?.country.currencySymbol}: {forex.exchangeRate} {forex.currencyCode}
                    </Typography>
                    <Typography typo="caption_overline" sx={{ color: '#1a1c23' }}>
                        <span className={styles.currency}> {vendor?.country.currencySymbol} </span>
                        {total.toFixed(currencyPrecision)}
                    </Typography>
                </div>
            )}

            <div className={styles.currencyChangeContainer}>
                {!vendor.config?.hideSurchargeSubtitle && (
                    <Typography typo="caption_overline" className={styles.caption}>
                        {inclusiveChargesMessage}
                    </Typography>
                )}

                {forex.isInterrupted && forexUI === 'v1' && (
                    <Typography onClick={toggleChangeCurrency} typo="caption_overline" className={styles.changeButton}>
                        {t('Change currency')}
                        <ChevronRightIcon />
                    </Typography>
                )}
            </div>

            <SubscriptionCompletionPrompt />

            <SwipeableCustomerDrawer
                headerTitle={t('Order details')}
                hasRadius={false}
                hasOverflow
                anchor="bottom"
                open={open}
                onClose={toggleDrawerHandler(false)}
                onOpen={toggleDrawerHandler(true)}
                BackdropProps={{ sx: { background: '#00000099' } }}
                PaperProps={{ elevation: 0, sx: { background: 'transparent' } }}
                contentStyle={{
                    padding: 0,
                    '&>p': {
                        padding: '0 1.5rem',
                    },
                }}
            >
                <div className={styles.content}>
                    <div className={styles.inner}>
                        <Typography typo="title_md" sx={{ pb: '.5rem', pt: '1rem', px: '1.5rem' }}>
                            {t('Table {{id}}', { id })}
                        </Typography>
                        <div className={styles.orderTable}>
                            <InvoiceOrder orderItems={details?._orderItems} lang={lang} newOrderIds={[]} />
                        </div>
                        <Divider type="fullWidth" />
                        <div className={styles.orderTable}>
                            <InvoiceBill
                                billItems={details?._billItems}
                                lang={lang}
                                qlubDiscount={details?.billNumber?.qlubDiscount}
                            />
                        </div>
                    </div>
                    <Box className={styles.footer}>
                        <Divider type="fullWidth" />
                        <CustomerGrid sx={{ py: '1rem' }}>
                            <Button variant="contained" onClick={onPayBill} fullWidth>
                                {t(`Pay the Bill `)}
                            </Button>
                        </CustomerGrid>
                    </Box>
                </div>
            </SwipeableCustomerDrawer>
        </div>
    );
};
export default OrderSummary;
