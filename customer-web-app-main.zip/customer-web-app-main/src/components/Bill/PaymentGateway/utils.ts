/*
    Creation Time: 2022 - April - 23
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2023
*/

import { IPaymentGatewayView } from '@clubpay/customer-common-module/src/repository/vendor';
import { elemOrders, IPGRegister, IPGSelect } from '@clubpay/customer-common-module/src/repository/common/payment/type';

export const getDefaultSelected = (
    paymentGateways: IPaymentGatewayView[],
    pgSelectors: IPGRegister[],
): IPGSelect | undefined => {
    if (pgSelectors.length === 1) {
        return {
            pgId: pgSelectors[0].pgId,
            elem: pgSelectors[0].elem,
            bySystem: true,
        };
    }
    const pgDefault =
        paymentGateways.find((o) => o.config.pgDefaultSelected) ||
        paymentGateways.find((o) => o.config.pgDefaultSelectedElem);

    if (pgDefault && pgDefault.config.pgDefaultSelectedElem && pgDefault.config.pgDefaultSelectedElem.length > 0) {
        const selectors = pgSelectors.filter((o) => o.pgId === pgDefault.id).map((o) => o.elem);
        const elem =
            pgDefault.config.pgDefaultSelectedElem.find((o: any) => selectors.includes(o)) ||
            elemOrders.find((el) => selectors.includes(el));

        if (selectors.length > 0 && elem) {
            return {
                pgId: pgDefault.id,
                elem,
                bySystem: true,
            };
        }
    } else {
        const elem = pgSelectors[0];
        return {
            pgId: elem.pgId,
            elem: elem.elem,
            bySystem: true,
        };
    }
    return undefined;
};

export const getPriority = (paymentGateways: IPaymentGatewayView[]) => {
    return paymentGateways.some((o) => o.config?.priority)
        ? Math.min(...paymentGateways.filter((o) => o.config?.priority).map((o) => o.config.priority || 0))
        : 0;
};

export const shouldNewPaymentModuleAcitvate = (
    countryFlag: boolean,
    restuarantFlag?: boolean,
    oldModuleOverride?: boolean,
) => {
    if (oldModuleOverride) return false;
    return countryFlag || restuarantFlag;
};
