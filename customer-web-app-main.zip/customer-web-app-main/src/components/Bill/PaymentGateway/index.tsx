import React, { MutableRefObject, RefObject, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Grid } from '@mui/material';
import {
    IPaymentGatewayView,
    IRestaurant,
    SmartTipModalTriggerPointConditionEnum,
} from '@clubpay/customer-common-module/src/repository/vendor';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { TotalPrice, Button } from '@qlub-dev/qlub-kit';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IURLTopology, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import PaymentTerms from '@clubpay/customer-common-module/src/component/PaymentTerms';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useSubscriptionStore } from '@clubpay/loyalty/dist/store/subscription';
import { Transaction } from '@sentry/types';
import * as Sentry from '@sentry/nextjs';
import { getDefaultJwt, getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import useSentryTrace from '@clubpay/customer-common-module/src/hook/sentry/useSentryTrace';
import { HandleSentryCloseEnum } from '@clubpay/customer-common-module/src/hook/sentry/enums';
import { IHandleSentryClose } from '@clubpay/customer-common-module/src/hook/sentry/types';
import { getPriority, shouldNewPaymentModuleAcitvate } from '@/components/Bill/PaymentGateway/utils';
import { usePgSelector } from '@/components/Bill/PaymentGateway/hook';
import { qlubSessionStorage } from '@clubpay/customer-common-module/src/service/storage/sessionStorage';
import Typography from '@qlub-dev/qlub-kit/dist/components/Typography';
import Payment from '@clubpay/customer-payment-module/src/component';
import { PaymentPortal, getPaymentKitProps, ConsumerTypes, useForexStore } from '@clubpay/payment-kit';
import {
    IElementPayHandler,
    IGatewayPayHandler,
    IPayBeforePaymentHandler,
    IPGExchange,
    IPGPropsAll,
    PaymentElementEnum,
    PaymentTypeName,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import '@clubpay/customer-payment-module/src/component/PayMaf/maflib';
import '@clubpay/customer-payment-module/src/component/PayMafV2/maflib';
import '@clubpay/customer-payment-module/src/component/PayMashreq/mashreqlib';
import '@clubpay/customer-payment-module/src/component/PayTuna/tunalib';
import { updatePgsForForex } from '@/repositories/payment/transformer';
import classNames from 'classnames';
import { TipToggleFunc } from '@/components/Tip/normal/types';
import { usePGGroupStore } from '@/store/pgGroup';
import { ISmartTipModalHandler } from '@/components/Tip/smart';
import { TipToggleOriginEnum } from '@/components/Tip/normal/enums';
import { useYouPayFinalAmount } from '../OrderSummary/hook';

import styles from './index.module.scss';

interface IProps {
    diningSessionID: string;
    url: IURLTopology;
    amount: number;
    vendor: IRestaurant;
    tableName: string;
    lang: string | null;
    paymentGateways: IPaymentGatewayView[];
    currencyPrecision: number;
    tip: number;
    updateTimestamp: number;
    remainingAmount: number;
    total: number;
    paymentOnTopLayer: boolean;
    exchange?: IPGExchange;
    hasSplitPayment: boolean;
    onBeforePayment: (payload: IPayBeforePaymentHandler) => Promise<boolean>;
    onUnlockPayment: (gatewayId: string) => Promise<boolean>;
    onDone: (payload: IGatewayPayHandler) => void;
    onPending: (payload: IGatewayPayHandler) => void;
    onFail: (payload: IGatewayPayHandler) => void;
    onTipModalOpenRef?: MutableRefObject<TipToggleFunc | undefined>;
    smartTipModalHandlerRef?: RefObject<ISmartTipModalHandler>;
    onLoading: (loading: boolean) => void;
    onHeightChange?: (height: number) => void;
    onExchangeChange?: (payload: IPGExchange) => void;
}

export default function PaymentGateway({
    diningSessionID,
    url,
    amount,
    vendor,
    tableName,
    paymentGateways,
    currencyPrecision,
    tip,
    updateTimestamp,
    remainingAmount,
    total: totalReceived,
    exchange,
    hasSplitPayment,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onPending,
    onFail,
    onTipModalOpenRef,
    smartTipModalHandlerRef,
    paymentOnTopLayer,
    onHeightChange,
    onLoading,
    onExchangeChange,
}: IProps) {
    const { t } = useTranslation('common');
    const { lang, isQSR } = useQlubRouter();
    const { fetchTrace, finishTrace } = useSentryTrace();
    const [enableCardPayment, setEnableCardPayment] = useState(true);
    const [priority, setPriority] = useState(getPriority(paymentGateways));
    const [indicator, setIndicator] = useState(false);
    const [emptyPgErrorSent, setEmptyPgErrorSent] = useState<boolean>(false);
    const [loadFailSentry, setLoadFailSentry] = useState<boolean>(false);
    const buttonRef = useRef<HTMLDivElement | null>(null);
    const contentRef = useRef<HTMLDivElement | null>(null);
    const [lock, setLock] = useState(false);
    const lockTimeoutRef = useRef<any>();
    const lastHeight = useRef(0);

    const { setPaymentHandler, setCurrentActivePGData, state } = usePGGroupStore((store) => store);

    const forex = useForexStore();
    const optedForSubscription = useSubscriptionStore((store) => store.optedForSubscription);

    const { priceData } = useYouPayFinalAmount({
        tip,
        total: totalReceived,
        currencyPrecision,
    });

    const isNewPaymentModule = shouldNewPaymentModuleAcitvate(
        vendor.country.config?.enableNewPaymentModule,
        vendor.config?.enableNewPaymentModule,
    );

    const observer = useMemo(() => {
        return new ResizeObserver((entries) => {
            const height = Math.max(entries[0]?.contentRect?.height, 72);
            if (height !== lastHeight.current) {
                onHeightChange?.(height);
                lastHeight.current = height;
            }
        });
    }, []);

    useMemo(() => {
        return () => {
            observer.disconnect();
        };
    }, []);

    const filteredPaymentGateways = useMemo(() => {
        const updatedList = priority ? paymentGateways.filter((o) => o.config?.priority === priority) : paymentGateways;

        /** hide payment methods if it's used for with forex reallocation and retrying
         * currently only implemented for applepay and card pay only
         */
        const updatedListWithForexLogic = updatePgsForForex(updatedList, exchange);

        return updatedListWithForexLogic;
    }, [paymentGateways, priority, exchange]);

    const { pgUnregisterHandler, pgRegisterHandler, selectedPG, selected, pgSelectors, disabledElems, prev, next } =
        usePgSelector({
            hasPgGroup: vendor.paymentGatewayList.hasPgGroup,
            buttonRef,
            contentRef,
            filteredPaymentGateways,
            exchange,
        });

    const overlayClickHandler = () => {
        setEnableCardPayment(true);
    };

    const handleNoPgSentry = useCallback(() => {
        Sentry.withScope((scope) => {
            scope.setLevel('info');
            Sentry.captureMessage('No payment gateway is set');
        });

        setEmptyPgErrorSent(true);
    }, []);

    useEffect(() => {
        if (!emptyPgErrorSent && paymentGateways.length === 0) {
            handleNoPgSentry();
        }

        setPriority(getPriority(paymentGateways));
    }, [paymentGateways, pgSelectors]);

    const indicatorHandler = useCallback(() => {
        if (priority) {
            setIndicator(true);
        }
    }, [paymentGateways, priority]);

    const handleLoadFailSentry = useCallback(
        (pg: IPaymentGatewayView) => {
            Sentry.withScope((scope) => {
                scope.setLevel('info');
                scope.setExtra('pg', pg);
                Sentry.captureMessage('Payment gateway load failed');
            });

            setLoadFailSentry(true);
        },
        [paymentGateways],
    );

    const loadHandler = useCallback(
        (success) => {
            setIndicator(false);
            if (priority && !success) {
                const pg = paymentGateways.find((o) => o.config.priority === priority);

                if (pg && pg.type) {
                    onPushEvent('payment_load_failed', {
                        vendor: PaymentTypeName[pg.type],
                        opsMode: vendor.opsMode,
                        restaurant_name: url.slug,
                        pg_name: pg.name,
                        diningSessionId: diningSessionID,
                    });

                    if (!loadFailSentry) {
                        handleLoadFailSentry(pg);
                    }
                }
                if (priority < paymentGateways.length) {
                    setPriority((o) => o + 1);
                }
            }
        },
        [paymentGateways, priority],
    );

    const total = exchange?.total || sumAmounts(currencyPrecision, amount, tip);
    const disable = total <= 0;

    const beforePaymentHandler = useCallback(
        (gatewayId: string) =>
            (payload: IPayBeforePaymentHandler): Promise<boolean> => {
                if (
                    smartTipModalHandlerRef?.current &&
                    smartTipModalHandlerRef.current?.toggleDrawer(true, SmartTipModalTriggerPointConditionEnum.TapOnPay)
                ) {
                    return Promise.resolve(false);
                }

                if (onTipModalOpenRef?.current && onTipModalOpenRef.current(true, TipToggleOriginEnum.Payment)) {
                    return Promise.resolve(false);
                }

                /** return here when only checking the tip */
                if (payload.checkTipOnly) {
                    onTipModalOpenRef?.current?.(false, TipToggleOriginEnum.Payment);
                    return Promise.resolve(true);
                }

                onTipModalOpenRef?.current?.(false, TipToggleOriginEnum.Payment);

                const pg = paymentGateways.find((o) => o.id === gatewayId);
                setLock(true);
                lockTimeoutRef.current = setTimeout(() => {
                    setLock(false);
                    lockTimeoutRef.current = null;
                }, 20000);
                return onBeforePayment({
                    tip: payload.tip,
                    method: pg?.name || '',
                    paymentElement: payload.paymentElement,
                    gatewayId,
                    meta: payload?.meta,
                }).then((res) => {
                    if (!res) {
                        if (lockTimeoutRef.current) {
                            clearTimeout(lockTimeoutRef.current);
                        }
                        setLock(false);
                    }
                    return res;
                });
            },
        [tip, onBeforePayment, updateTimestamp, lang, paymentGateways],
    );

    const unlockPaymentHandler = useCallback(
        (gatewayId: string) => () => {
            if (lockTimeoutRef.current) {
                clearTimeout(lockTimeoutRef.current);
            }
            setLock(false);
            return onUnlockPayment(gatewayId);
        },
        [tip, onUnlockPayment],
    );

    const doneHandler = useCallback(
        (gatewayId: string) => (payload: IElementPayHandler) => {
            const pg = paymentGateways.find((o) => o.id === gatewayId);
            return onDone({
                amount: sumAmounts(currencyPrecision, amount, tip),
                method: pg?.name || '',
                gatewayId,
                traceId: payload.traceId || '',
                tableName,
                ...payload,
            });
        },
        [onDone, tip, amount, paymentGateways, tableName],
    );

    const pendingHandler = useCallback(
        (gatewayId: string) => (payload: IElementPayHandler) => {
            const pg = paymentGateways.find((o) => o.id === gatewayId);
            return onPending({
                amount: sumAmounts(currencyPrecision, amount, tip),
                paymentElement: payload.paymentElement,
                method: pg?.name || '',
                refId: payload.refId,
                gatewayId,
                traceId: payload.traceId || '',
                tableName,
            });
        },
        [onPending, tip, amount, paymentGateways, tableName],
    );

    const failHandler = useCallback(
        (gatewayId: string) => (payload: IElementPayHandler) => {
            const pg = paymentGateways.find((o) => o.id === gatewayId);
            return onFail({
                ...payload,
                amount: sumAmounts(currencyPrecision, amount, tip),
                paymentElement: payload.paymentElement,
                method: pg?.name || '',
                refId: payload.refId,
                gatewayId,
                traceId: payload.traceId || '',
                tableName,
            });
        },
        [onFail, tip, amount, paymentGateways, tableName],
    );

    const traceStartHandler = (gatewayId: string, paymentTraceId?: string) => {
        const pg = paymentGateways.find((o) => o.id === gatewayId);

        return fetchTrace({
            gatewayId,
            name: pg?.name || '',
            amount,
            tip,
            diningSessionID,
            paymentGateway: pg?.name || '',
            countryCode: url.cc,
            participantID: getSession(),
            restaurantUniqueID: url.slug,
            opsMode: vendor.opsMode || 'default-ops-mode',
            paymentTraceId: paymentTraceId || '',
        });
    };

    const traceFinishHandler = (transaction: Transaction) => {
        finishTrace(transaction);
    };

    const traceCloseHandler = (payload: IHandleSentryClose) => {
        try {
            const { error, errorString, location, traceRef, traceStart } = payload;

            traceRef.current?.span.setData(HandleSentryCloseEnum.description, error);
            if (errorString) {
                traceRef.current?.span.setData(HandleSentryCloseEnum.errorString, errorString);
            }
            traceRef.current?.span.setTag(HandleSentryCloseEnum.errorLocation, location);
            traceStart?.transaction.setTag(HandleSentryCloseEnum.errorLocation, location);
            traceRef.current?.finishSpan();
            traceFinishHandler(traceStart?.transaction as any);
        } catch (e) {
            console.log(e);
        }
    };

    const prePaymentHandler = (fn: VoidFunction, payload?: any) => {
        setPaymentHandler(fn);
        if (payload) setCurrentActivePGData(payload);
        /** check tip modal */
        if (!onTipModalOpenRef?.current?.(true, TipToggleOriginEnum.Payment)) {
            fn();
        }
    };

    const isPgElemVisible = (gatewayId: string) => (elem: PaymentElementEnum) => {
        const disabledEl = disabledElems.find((o) => o.pgId === gatewayId);

        return Boolean(selected?.pgId === gatewayId && selected?.elem === elem && disabledEl?.elem !== elem);
    };

    const paybtnRef = useRef<HTMLDivElement>();

    const { currencyFormat } = useVendor();

    const getPaymentGatewaysContent = useMemo(() => {
        const pgRender = (pg: IPaymentGatewayView) => {
            const { id, name, type, config, disabled } = pg;
            const sessionId = getSession();
            const jwt = getDefaultJwt();
            const props: IPGPropsAll = {
                diningSessionID,
                sessionId,
                jwt,
                url,
                amount,
                tip,
                lang,
                disable,
                name,
                currencyPrecision,
                vendor,
                exchange,
                hasSplitPayment,
                onDone: doneHandler(id),
                onPending: pendingHandler(id),
                onFail: failHandler(id),
                enableButton: enableCardPayment,
                onOverlayClick: overlayClickHandler,
                onIndicator: indicatorHandler,
                onLoad: loadHandler,
                config: config as any,
                gatewayId: id,
                onBeforePayment: beforePaymentHandler(id),
                onUnlockPayment: unlockPaymentHandler(id),
                onPgRegister: pgRegisterHandler,
                onPgUnregister: pgUnregisterHandler,
                isPgElemVisible: isPgElemVisible(id),
                updateTimestamp,
                remainingAmount,
                onTraceStart: traceStartHandler,
                onTraceClose: traceCloseHandler,
                onLoading,
                onExchangeChange,
            };

            if (disabled) {
                return null;
            }

            return (
                <Grid item xs={12}>
                    <Payment type={type} {...props} />
                </Grid>
            );
        };
        if (!isNewPaymentModule)
            return (
                <>
                    <Grid item marginTop={1} xs={12} display="flex" gap={2} flexDirection="column">
                        <div ref={contentRef}>
                            {filteredPaymentGateways.map((pg) => {
                                return pgRender(pg);
                            })}
                        </div>
                    </Grid>
                </>
            );

        return (
            <div>
                <PaymentPortal
                    ref={paybtnRef}
                    slots={{
                        paymentDrawer: {
                            youPay: (
                                <TotalPrice
                                    priceData={priceData}
                                    footerText={t('Inclusive of all taxes and charges', { useLocale: true })}
                                    currencyFormat={currencyFormat}
                                />
                            ),
                        },
                    }}
                    {...getPaymentKitProps(vendor.paymentGateways, {
                        amount,
                        vendor,
                        hasSplitPayment,
                        enableCardPayment,
                        events: {
                            onBeforePayment: (id: string, payload: any) => beforePaymentHandler(id)(payload),
                            onPaymentSuccess: (id: string, payload: any) => doneHandler(id)(payload),
                            onPaymentFailure: (id: string, payload: any) => failHandler(id)(payload),
                            onPaymentPending: (id: string, payload?: any) => pendingHandler(id)(payload),
                            onOverlayClick: overlayClickHandler,
                            onPrePayment: prePaymentHandler,
                            onPaymentMethodSelect: (data: any) => {
                                setPaymentHandler(data.fn);
                                setCurrentActivePGData(data);
                            },
                            onTraceStart: traceStartHandler,
                            onTraceClose: traceCloseHandler,
                        },
                        diningSessionID,
                        currencyPrecision,
                        tip,
                        lang,
                        remainingAmount,
                        consumer: ConsumerTypes.CUSTOMER_APP,
                        billPaidStatus: state.billPaidStatus,
                        isSubscriptionPayment: optedForSubscription,
                    })}
                />
            </div>
        );
    }, [
        paymentGateways,
        disable,
        tip,
        amount,
        diningSessionID,
        enableCardPayment,
        priority,
        lang,
        selected,
        filteredPaymentGateways,
        updateTimestamp,
        exchange,
        hasSplitPayment,
        tableName,
        forex,
    ]);

    const refCardHandler = (ref: HTMLDivElement) => {
        if (!ref) {
            return;
        }

        const paymentEl = ref.querySelector('[data-area="submit"]');
        if (!paymentEl) {
            return;
        }

        observer.unobserve(paymentEl);
        if (selectedPG?.placement === 'bottom') {
            observer.observe(paymentEl);
        }
    };

    const refPaymentHandler = (ref: HTMLDivElement) => {
        buttonRef.current = ref;
        if (!ref) {
            return;
        }

        const paymentEl = ref.querySelector('[data-area="submit"]');
        if (!paymentEl) {
            return;
        }

        observer.unobserve(paymentEl);
        if (selectedPG?.placement !== 'bottom') {
            observer.observe(paymentEl);
        }
    };

    const renderPaymentGatewayContent = () => {
        if (isNewPaymentModule) return getPaymentGatewaysContent;

        return (
            <Grid
                container
                spacing={1}
                className={classNames(styles.paymentButton, styles.paymentCard, {
                    [styles.paymentOnTopLayer]: paymentOnTopLayer && selectedPG?.placement === 'bottom',
                })}
                ref={refCardHandler}
            >
                {getPaymentGatewaysContent}
            </Grid>
        );
    };

    return (
        <div className={styles.gatewayWrapper}>
            <Typography typo="title_md" sx={{ pt: 2, pb: 2 }}>
                {t('Payment method')}
            </Typography>

            {isQSR && remainingAmount === 0 && selectedPG?.elem === PaymentElementEnum.PixPay && (
                <div className={styles.invoiceAnchor}>
                    <Button
                        fullWidth
                        color="primary"
                        variant="contained"
                        onClick={() => {
                            doneHandler(selectedPG?.pgId || '')({
                                paymentElement: PaymentElementEnum.PixPay,
                                refId: qlubSessionStorage.get('qlub.pix.refId'),
                            });
                        }}
                    >
                        {t('Check your order status')}
                    </Button>
                </div>
            )}
            {indicator && <div className={styles.indicator}>{t('We are trying to setup the payment gateway')}</div>}

            {prev}
            {selectedPG?.placement === 'bottom' && <div className={styles.gap} />}

            {renderPaymentGatewayContent()}

            {next}
            {selectedPG?.buttonElement && <div className={styles.gap} />}
            <div
                className={classNames(styles.paymentButton, {
                    [styles.paymentOnTopLayer]: paymentOnTopLayer && selectedPG?.placement !== 'bottom',
                })}
                ref={refPaymentHandler}
            >
                {selectedPG?.buttonElement && (
                    <div>
                        <PaymentTerms />
                        <div className={styles.submit} data-area="submit">
                            {selectedPG?.buttonElement}
                        </div>
                    </div>
                )}
            </div>

            {lock && !isNewPaymentModule && <div className={styles.lockOverlay} />}
        </div>
    );
}
