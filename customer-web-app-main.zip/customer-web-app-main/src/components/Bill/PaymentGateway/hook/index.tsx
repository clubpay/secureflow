/*
    Creation Time: 2022 - April - 23
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2023
*/

import { CreditCard } from '@mui/icons-material';
import { getDefaultSelected } from '@/components/Bill/PaymentGateway/utils';
import React, { useMemo, useState } from 'react';
import { omit, orderBy } from 'lodash';
import { PGSelectorAnchor } from 'components/Bill/CustomerAccordion';
import { IPaymentGatewayView } from '@clubpay/customer-common-module/src/repository/vendor';
import {
    IPGDisable,
    IPGExchange,
    IPGRegister,
    IPGSelect,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';

const elementsMustBeUnique = [PaymentElementEnum.GooglePay, PaymentElementEnum.ApplePay];
export const usePgSelector = ({
    hasPgGroup,
    buttonRef,
    contentRef,
    filteredPaymentGateways,
    exchange,
}: {
    hasPgGroup: boolean;
    buttonRef: any;
    contentRef: any;
    filteredPaymentGateways: IPaymentGatewayView[];
    exchange?: IPGExchange;
}) => {
    const [pgSelectors, setPgSelectors] = useState<IPGRegister[]>([]);
    const [selected, setSelected] = useState<IPGSelect | undefined>(undefined);
    const [disabledElems, setDisabledElems] = useState<IPGDisable[]>([]);

    const [prevList, nextList] = useMemo<[IPGRegister[], IPGRegister[]]>(() => {
        if (!selected) {
            return [pgSelectors, []];
        }
        const selectedIdx = pgSelectors.findIndex((o) => o.pgId === selected.pgId && o.elem === selected.elem);
        if (selectedIdx > -1) {
            const selectedPg = pgSelectors[selectedIdx];
            if (selectedPg.placement === 'top') {
                return [[], pgSelectors];
            }
            if (selectedPg.placement === 'bottom') {
                return [pgSelectors, []];
            }
            return [pgSelectors.slice(0, selectedIdx + 1), pgSelectors.slice(selectedIdx + 1, pgSelectors.length + 1)];
        }
        return [pgSelectors, []];
    }, [pgSelectors, selected]);

    const sortList = (list: IPGRegister[]): IPGRegister[] => {
        return orderBy(
            list.map((item) => {
                const pg = filteredPaymentGateways.find((o) => o.id === item.pgId);

                const elemOrder = pg?.config.pgElemOrder?.indexOf(item.elem) || 0;

                return {
                    ...item,
                    order: elemOrder === -1 ? 1000000 : elemOrder,
                };
            }),
            ['order'],
            ['asc'],
        ).map((o) => omit(o, 'order'));
    };

    const pgRegisterHandler = ({ pgId, elem, name, icon, placement, buttonElement }: IPGRegister) => {
        if (!hasPgGroup) {
            return;
        }

        const oldList = (list: IPGRegister[]) => {
            const idx = list.findIndex((o) => o.pgId === pgId && o.elem === elem);

            if (idx === -1) {
                const li: IPGRegister[] = [
                    {
                        pgId,
                        elem,
                        name,
                        icon: icon || <CreditCard />,
                        placement,
                        buttonElement,
                    },
                    ...list,
                ];

                setDisabledElems((old: IPGDisable[]) => {
                    const elemIsUnique = elementsMustBeUnique.includes(elem);
                    const anyOtherEnabled = li.find((pg) => pg.elem === elem && pg.pgId !== pgId);
                    if (elemIsUnique && anyOtherEnabled) {
                        return [...old, anyOtherEnabled];
                    }
                    return old;
                });

                if (exchange?.paymentMethod === elem) {
                    setSelected({ pgId, elem });
                } else if (!selected || selected.bySystem) {
                    setSelected(getDefaultSelected(filteredPaymentGateways, li));
                }
                return sortList(li);
            }
            list[idx].name = name;
            list[idx].buttonElement = buttonElement;
            return sortList(list);
        };

        setPgSelectors(oldList);
    };

    const pgUnregisterHandler = ({ pgId, elem, force }: IPGDisable) => {
        // if disabled elements has not this element, return
        const isElemDisabled = disabledElems.find((d) => d.elem === elem);

        if (!isElemDisabled && !force) {
            return;
        }

        setPgSelectors((prev) => {
            const index = prev.findIndex((pg) => pg.pgId === pgId && pg.elem === elem);
            if (index === -1) {
                return prev;
            }
            const newList = [...prev];
            newList.splice(index, 1);

            const elemIsUnique = elementsMustBeUnique.includes(elem);
            const isDisabled = disabledElems.find((d) => d.pgId === pgId && d.elem === elem);

            if (elemIsUnique && !isDisabled) {
                const firstElem = newList.find((pg) => pg.elem === elem);
                if (firstElem) {
                    setDisabledElems((old: IPGDisable[]) => {
                        const newOld = old.filter((o) => o.elem !== elem);
                        const idx = newOld.findIndex((o) => o.pgId === firstElem.pgId && o.elem === firstElem.elem);
                        if (idx > -1) {
                            newOld.splice(idx, 1);
                        }
                        return [...newOld, { pgId, elem }];
                    });
                    setSelected({
                        pgId: firstElem.pgId,
                        elem: firstElem.elem,
                    });
                } else {
                    setDisabledElems((old: IPGDisable[]) => [...old, { pgId, elem }]);
                    setSelected(getDefaultSelected(filteredPaymentGateways, newList));
                }
            } else {
                const r = newList.find((pg) => disabledElems.find((o) => o.pgId === pg.pgId && o.elem === pg.elem));
                if (r) {
                    setSelected({
                        pgId: r.pgId,
                        elem: r.elem,
                    });
                } else {
                    setSelected(getDefaultSelected(filteredPaymentGateways, newList));
                }
                setDisabledElems((old: IPGDisable[]) => old.filter((d) => d.elem !== elem || d.pgId !== pgId));
            }

            return sortList(newList);
        });
    };

    const selectedPG = useMemo(() => {
        if (!selected) {
            return undefined;
        }
        return pgSelectors.find((o) => o.pgId === selected.pgId && o.elem === selected.elem);
    }, [pgSelectors, selected]);

    const selectPGHandler = (s: IPGRegister) => () => {
        setSelected({ ...s });

        if (['bottom', 'top'].includes(s.placement || '') && s.buttonElement) {
            buttonRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
        } else {
            contentRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
        }
    };

    const pgSelectorRender = (list?: IPGRegister[]) => {
        if (prevList.length + nextList.length <= 1) {
            return null;
        }
        return list?.map((pg: IPGRegister) => {
            if (disabledElems.find((o) => o.pgId === pg.pgId && o.elem === pg.elem)) {
                return null;
            }
            return (
                <PGSelectorAnchor
                    key={`${pg.pgId}_${pg.elem}`}
                    onClick={selectPGHandler(pg)}
                    label={pg.name || pg.elem}
                    expanded={selected?.pgId === pg.pgId && selected?.elem === pg.elem}
                    accordionIcon={pg.icon || <CreditCard />}
                />
            );
        });
    };

    const prev = useMemo(() => pgSelectorRender(prevList), [prevList, selected]);
    const next = useMemo(() => pgSelectorRender(nextList), [nextList, selected]);

    return {
        pgSelectors,
        pgRegisterHandler,
        pgUnregisterHandler,
        selectedPG,
        selected,
        setSelected,
        disabledElems,
        pgSelectorRender,
        prev,
        next,
    };
};
