import React, { useEffect, useState } from 'react';
import { FormControlLabel, Radio, RadioGroup, Stack } from '@mui/material';
import { Button, SwipeableCustomerDrawer, Typography } from '@qlub-dev/qlub-kit';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

import { useForexStore } from '@clubpay/payment-kit';
import styles from './index.module.scss';

interface IProps {
    open: boolean;
    vendorCurrency: string;
    total: number;
    currencyPrecision: number;
    onChange: (currencyCode: string | null) => void;
    onClose: () => void;
    onOpen: () => void;
}

const ChangeCurrency = ({ open, vendorCurrency, total, currencyPrecision, onChange, onClose, onOpen }: IProps) => {
    const { t } = useTranslation('common');

    const forex = useForexStore();

    const initialCurrency = forex?.isApplied ? forex.currencyCode : vendorCurrency;

    const [selectedCurrency, setSelectedCurrency] = useState(initialCurrency);

    const confirmHandler = () => {
        onChange(selectedCurrency);
        onClose();
    };

    useEffect(() => {
        if (open) setSelectedCurrency(initialCurrency);
    }, [open]);

    return (
        <SwipeableCustomerDrawer
            anchor="bottom"
            open={open}
            headerTitle={t('Exchange currency')}
            onClose={onClose}
            onOpen={onOpen}
        >
            <Typography typo="caption_overline" sx={{ color: '#616475' }}>
                {t('Select to pay with one of the below options')}
            </Typography>

            <div className={styles.detailsContainer}>
                <Typography typo="title_md">{t('Pay in')}</Typography>
                <RadioGroup
                    value={selectedCurrency}
                    className={styles.radioContainer}
                    onChange={(_, value: string) => setSelectedCurrency(value)}
                    row
                >
                    <FormControlLabel
                        value={forex?.currencyCode}
                        control={<Radio />}
                        label={`${forex?.currencyCode}: ${forex?.total?.toFixed(currencyPrecision)}`}
                    />
                    <FormControlLabel
                        value={vendorCurrency}
                        control={<Radio />}
                        label={`${vendorCurrency}: ${total?.toFixed(currencyPrecision)}`}
                    />
                </RadioGroup>
                <Typography typo="caption_overline" sx={{ color: '#9B9EAB' }}>
                    {t('Exchange rate')} 1 {vendorCurrency} = {forex?.exchangeRate} {forex?.currencyCode}
                </Typography>
            </div>

            <Stack spacing={2} className={styles.buttonContainer}>
                <Button variant="contained" onClick={confirmHandler}>
                    {t('Confirm')}
                </Button>
                <Button variant="containedLight" onClick={onClose}>
                    {t('Cancel')}
                </Button>
            </Stack>
        </SwipeableCustomerDrawer>
    );
};

export default ChangeCurrency;
