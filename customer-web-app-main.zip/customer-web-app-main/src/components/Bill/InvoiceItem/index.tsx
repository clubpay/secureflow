import React, { Fragment } from 'react';
import { useBillItemTranslation, useOrderItemTranslation } from '@/components/Bill/InvoiceItem/hooks/translations_hook';
import { getIdFromOrder } from '@/views/Bill/Invoice/utils';
import { InvoiceItem } from '@qlub-dev/qlub-kit';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import { IKeyValue, IOrderItemView } from '@/repositories/bill';
import { IKeyValueOrder } from '@qlub-dev/qlub-kit/dist/types/InvoiceItemTypes';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import InvoiveItemWithCondition from './HOC';
import { checkVisibilityCondition } from './utils';

export interface IInvoiceBillProps {
    billItems: IKeyValue[];
    lang: string | null;
    qlubDiscount: number;
    countryConfig?: IConfig | undefined;
    currencyFormat?: CurrencyFormat;
    className?: string;
}

export function InvoiceBill({ billItems, qlubDiscount, lang, currencyFormat, className }: IInvoiceBillProps) {
    const { currencyFormat: _currencyFormat } = useVendor();

    return (
        <div className={className}>
            {billItems.map((item, i) => {
                if (!checkVisibilityCondition(item, String(qlubDiscount))) {
                    return null;
                }
                return (
                    // in case we want to add any kind of conditions or conditional props
                    // on invoiceItem level we can use this HOC
                    <InvoiveItemWithCondition
                        key={`${item.key}_${item.value}_${i}`}
                        val={item}
                        lang={lang}
                        useBillItemTranslation={useBillItemTranslation}
                        useOrderItemTranslation={useOrderItemTranslation}
                        currencyFormat={currencyFormat ?? _currencyFormat}
                    />
                );
            })}
        </div>
    );
}

interface IInvoiceOrderProps {
    orderItems: IOrderItemView[];
    lang: string | null;
    currencyFormat?: CurrencyFormat;
    newOrderIds: string[];
    onOrderClick?: (item: IKeyValueOrder) => void;
    onToppingClick?: (item: IKeyValueOrder, topping: IKeyValueOrder) => void;
    className?: string;
}

export function InvoiceOrder({
    orderItems,
    lang,
    newOrderIds,
    onOrderClick,
    onToppingClick,
    currencyFormat,
    className,
}: IInvoiceOrderProps) {
    const { currencyFormat: _currencyFormat } = useVendor();

    const clickHandler = (item: IKeyValueOrder) => (topping: IKeyValueOrder) => {
        if (onToppingClick) {
            onToppingClick(item, topping);
        }
    };

    return (
        <div className={className}>
            {orderItems.map((item, i) => {
                if (!checkVisibilityCondition(item.item)) {
                    return null;
                }

                const orderId = getIdFromOrder(item.item, undefined, true);
                const isNew = newOrderIds.indexOf(orderId) > -1;

                return (
                    <Fragment key={`${orderId}_${i}`}>
                        <InvoiceItem
                            val={item.item}
                            lang={lang}
                            type="order"
                            isNew={isNew}
                            onClick={onOrderClick as any}
                            useBillItemTranslation={useBillItemTranslation}
                            useOrderItemTranslation={useOrderItemTranslation}
                            currencyFormat={currencyFormat ?? _currencyFormat}
                        />
                        {item.items.map((innerItem, j) => {
                            if (!checkVisibilityCondition(innerItem)) {
                                return null;
                            }

                            return (
                                <InvoiceItem
                                    key={`${orderId}_${i}_${j}`}
                                    val={innerItem}
                                    lang={lang}
                                    type="topping"
                                    onClick={clickHandler(item.item) as any}
                                    useBillItemTranslation={useBillItemTranslation}
                                    useOrderItemTranslation={useOrderItemTranslation}
                                    currencyFormat={currencyFormat ?? _currencyFormat}
                                />
                            );
                        })}
                    </Fragment>
                );
            })}
        </div>
    );
}
