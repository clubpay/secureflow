import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { IInvoiceItemProps } from '@qlub-dev/qlub-kit/dist/components/InvoiceItem';
import { ComponentType } from 'react';
import { InvoiceItem } from '@qlub-dev/qlub-kit';
import DinerFeeTooltip from '../../DinerFeeTooltip';

const InvoiceWithConditions = (WrappedInvoiceItem: ComponentType<IInvoiceItemProps>) => {
    return (props: IInvoiceItemProps) => {
        const { vendor } = useVendor();
        const { config: countryConfig } = useConfigContext();
        const visibilityOption = vendor?.config.showDinerFeeTooltip || countryConfig?.showDinerFeeTooltip;

        if (!props.type && props.val.key === 'com_exclusive_fixed' && visibilityOption === 'show') {
            return (
                <DinerFeeTooltip vendor={vendor} countryConfig={countryConfig}>
                    <WrappedInvoiceItem {...props} isShowDinerFeeTooltip={visibilityOption} />
                </DinerFeeTooltip>
            );
        }

        return <WrappedInvoiceItem {...props} />;
    };
};

export default InvoiceWithConditions(InvoiceItem);
