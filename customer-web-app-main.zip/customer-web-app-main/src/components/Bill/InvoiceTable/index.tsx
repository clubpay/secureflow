import { Box, IconButton, Paper } from '@mui/material';
import React from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { InvoiceBill, InvoiceOrder } from '@/components/Bill/InvoiceItem';
import { Button, CustomerContainer, Divider, SubHeader } from '@qlub-dev/qlub-kit';
import Link from 'next/link';
import { QSRRouterModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import TableName from '@/components/Bill/TableName';
import MultiLocale, { validateMultiLocale } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { IPaymentDetails } from '@/repositories/bill';
import getMenuLink, { linkHardRefreshHandler } from '@clubpay/customer-common-module/src/utility/menuLink';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import MenuIcon from '@clubpay/customer-common-module/src/component/Icons/MenuIcon';
import { checkActiveCampaign } from '@clubpay/customer-common-module/src/utility/vendor';
import VentureVoucher, { VoucherViewEnum } from '@/components/Bill/VentureVoucher';
import QSRScheduledOrderInfo from '@/components/QSR/QSRScheduleOrderInfo';
import { OrderModeEnum, OrderPaymentMethodEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import QSRStepper from '@/components/QSR/QSRStepper';
import { StepperStatusEnum } from '@/repositories/menu/types';
import { IKeyValueOrder } from '@qlub-dev/qlub-kit/dist/types/InvoiceItemTypes';

import styles from './index.module.scss';

interface IProps {
    diningSessionID: string;
    id: string;
    details: IPaymentDetails | undefined;
    loading: boolean;
    lang: string | null;
    onRefresh: () => void;
    newOrderIds: string[];
    onOrderItemClick?: (item: IKeyValueOrder) => void;
    onOrderItemToppingClick?: (item: IKeyValueOrder, topping: IKeyValueOrder) => void;
    onVoucherApply?: (data: IPaymentDetails) => void;
}

function InvoiceTable({
    details,
    lang,
    newOrderIds,
    diningSessionID,
    onOrderItemClick,
    onOrderItemToppingClick,
    onVoucherApply,
}: IProps) {
    const { t } = useTranslation('common');
    const { url, isQSR: hasQSRMode, query } = useQlubRouter();
    const { vendor, setTableName, tableInfo } = useVendor();
    const { config } = useConfigContext();
    const hasActiveCampaign = checkActiveCampaign(config, vendor?.config?.voucherHasActiveCampaign, vendor?.brand.id);

    const isQSR = hasQSRMode && !url.qsrMA && url.qsr !== QSRRouterModeEnum.Mixed;

    const { pickupAt } = query as unknown as { pickupAt?: string };

    const rowClickHandler = (item: IKeyValueOrder) => () => {
        onOrderItemClick?.(item);
    };

    const rowToppingClickHandler = (item: IKeyValueOrder, topping: IKeyValueOrder) => () => {
        onOrderItemToppingClick?.(item, topping);
    };

    const tableNameRefHandler = (ref: any) => {
        if (ref?.innerText) {
            setTableName(ref?.innerText || '');
        }
    };

    const menuCTA = (menuLink: any) => {
        return (
            <Button data-qa-id="billing-view-menu" variant="text" sx={{ px: 0 }} disableRipple>
                <Link href={menuLink} onClick={linkHardRefreshHandler(menuLink)} passHref>
                    <span>
                        {vendor?.config?.viewMenuText && lang && validateMultiLocale(vendor?.config?.viewMenuText) ? (
                            <MultiLocale value={vendor?.config?.viewMenuText} lang={lang} />
                        ) : vendor?.orderMode === OrderModeEnum.Mixed ? (
                            t('Order now')
                        ) : (
                            t('View menu')
                        )}
                    </span>
                </Link>
            </Button>
        );
    };

    const endHeaderActions = () => {
        const menuLink = getMenuLink(url, lang, 'billPage');
        if (!isQSR && hasActiveCampaign) {
            return (
                <div className={styles.btnContainer}>
                    <VentureVoucher
                        config={config}
                        diningSessionID={diningSessionID}
                        details={details}
                        onVoucherApply={onVoucherApply}
                        view={VoucherViewEnum.Button}
                    />
                    {vendor?.orderMode === OrderModeEnum.Mixed
                        ? menuCTA(menuLink)
                        : !vendor?.config?.hideViewMenuButton && (
                              <Link href={menuLink} onClick={linkHardRefreshHandler(menuLink)} passHref>
                                  <IconButton data-qa-id="billing-new-menu-button" className={styles.iconButton}>
                                      <MenuIcon />
                                  </IconButton>
                              </Link>
                          )}
                </div>
            );
        }
        if (
            (!vendor?.config.hideViewMenuButton || vendor?.orderMode === OrderModeEnum.Mixed) &&
            !(vendor?.orderMode === OrderModeEnum.Mixed && url.qsrPayment === OrderPaymentMethodEnum.Default)
        ) {
            return menuCTA(menuLink);
        }
        return null;
    };

    return (
        <Paper elevation={0}>
            <CustomerContainer centered direction="column" padding="0" className={styles.invoice}>
                {!isQSR && (
                    <>
                        <SubHeader
                            subTitle={isQSR ? '' : vendor?.title || ''}
                            title={
                                <span data-qa-id="billing-table-num" ref={tableNameRefHandler}>
                                    <TableName
                                        config={config || undefined}
                                        vendor={vendor}
                                        details={details}
                                        placeholder={t('Your bill')}
                                        tableInfo={tableInfo}
                                    />
                                </span>
                            }
                            CTA={endHeaderActions()}
                            sx={
                                isQSR
                                    ? {}
                                    : {
                                          pb: '.5rem',
                                      }
                            }
                            qaIds={{
                                subTitleId: 'billing-rest-name',
                            }}
                        />
                        <Box sx={{ mt: 1 }}>
                            <Divider type="fullWidth" />
                        </Box>
                    </>
                )}

                {isQSR && (
                    <QSRStepper
                        config={config}
                        vendor={vendor}
                        tableInfo={tableInfo}
                        status={StepperStatusEnum.CHECKOUT}
                    />
                )}
                {vendor?.orderConfig?.scheduledOrderEnable && (
                    <div className={styles.sheduledOrderInfo}>
                        <QSRScheduledOrderInfo pickupAt={pickupAt} />
                    </div>
                )}

                {details && (
                    <>
                        {!vendor?.posVendor?.config?.disableItemView && (
                            <>
                                <div className={styles.orderTable}>
                                    <InvoiceOrder
                                        orderItems={details._orderItems}
                                        lang={lang}
                                        newOrderIds={newOrderIds}
                                        onOrderClick={rowClickHandler}
                                        onToppingClick={rowToppingClickHandler}
                                    />
                                </div>
                                {details._orderItems.length > 0 && (
                                    <Box>
                                        <Divider type="fullWidth" />
                                    </Box>
                                )}
                            </>
                        )}
                        <div className={styles.orderTable}>
                            <InvoiceBill
                                lang={lang}
                                countryConfig={config || undefined}
                                billItems={details?._billItems}
                                qlubDiscount={details?.billNumber?.qlubDiscount}
                            />
                        </div>
                    </>
                )}
            </CustomerContainer>
        </Paper>
    );
}

export default InvoiceTable;
