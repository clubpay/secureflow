import React, { FC } from 'react';
import { useBillItemTranslation, useOrderItemTranslation } from '@/components/Bill/InvoiceItem/hooks/translations_hook';
import { IExplodedItemView, IPaymentDetails } from '@/repositories/bill';
import { InvoiceItem, SelectionIndicator } from '@qlub-dev/qlub-kit';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';

import styles from './index.module.scss';

interface IItemListProps {
    currencyFormat: CurrencyFormat;
    details: IPaymentDetails;
    selectedItems: IExplodedItemView[];
    onChangeItems: (item: IExplodedItemView, qty: number) => void;
}

const ItemList: FC<IItemListProps> = ({ details, currencyFormat, selectedItems, onChangeItems }) => {
    const { lang } = useQlubRouter();

    const indicatorValueHandler = (item: IExplodedItemView, qty: number) => () => {
        onChangeItems(item, qty);
    };

    return (
        <div className={styles.orderTable}>
            {details.explodedItems?.map((eItem, orderIndex) => {
                if (!eItem.item) return;
                const isSelected = selectedItems.find((s) => s.key === eItem.key);
                const paidItems = eItem.paidItemsQty ? eItem.paidItemsQty + 1 : 0;

                return (
                    <InvoiceItem
                        val={eItem.item}
                        currencyFormat={{
                            ...currencyFormat,
                            currencyPrecision: details?.currencyPrecision || currencyFormat?.currencyPrecision,
                        }}
                        lang={lang}
                        type="split"
                        selected={paidItems > 0}
                        useBillItemTranslation={useBillItemTranslation}
                        useOrderItemTranslation={useOrderItemTranslation}
                        Extra={
                            <SelectionIndicator
                                value={isSelected ? 1 : 0}
                                onValueChange={indicatorValueHandler(eItem, isSelected ? 0 : 1)}
                                max={1}
                                min={0}
                                tick
                                paid={paidItems > 0}
                                addId={`add-item-${orderIndex + 1}`}
                                removeId={`remove-item-${orderIndex + 1}`}
                                splitByItemV2Selector
                            />
                        }
                        key={eItem.key}
                        showExplodedItemNetPrice
                    />
                );
            })}
        </div>
    );
};

export default ItemList;
