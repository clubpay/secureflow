import { FC, useEffect, useMemo, useState } from 'react';
import { EnableEnum, SplitModeTypeEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import ItemList from '@/components/Split/modes/by-item/item-list';
import SplitButtons from '@/components/Split/modes/components/btns/confirm';
import { clone } from 'lodash';
import { CustomerContainer, TotalPrice, PriceItem, Divider, SplitPriceLabel, Trivia } from '@qlub-dev/qlub-kit';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { IExplodedItemView, IPaymentDetails } from '@/repositories/bill';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { useTheme } from '@mui/material';
import { ISplitOptions } from '@/views/Bill/Invoice/types';
import useSplitConflictAlertMsg from '../../hooks/split-conflict-alert';
import { calculateSplitByItemNetSubtotal, calculateSplitByItemTotal, convertExplodedItemToPaidItem } from '../../utils';
import useGetPaymentProcessingFeeLabel from '../../hooks/payment-processing-fee-txt';

import styles from './index.module.scss';

interface IProps {
    countryConfig?: IConfig;
    details: IPaymentDetails;
    inclusiveChargesMessage: string;
    onRemoveSplit: () => Promise<any> | undefined;
    onSelect: (amount: number, options?: ISplitOptions, draft?: boolean) => Promise<any> | undefined;
    ga: Record<string, unknown>;
    currencyFormat: CurrencyFormat;
    draftAPILoading: boolean;
}

const SplitByItem: FC<IProps> = ({
    onRemoveSplit,
    details,
    countryConfig,
    onSelect,
    inclusiveChargesMessage,
    ga,
    currencyFormat,
    draftAPILoading,
}) => {
    const { t } = useTranslation('common');
    const theme = useTheme();

    const [removeSplitLoading, setRemoveSplitLoading] = useState(false);
    const [selectedItems, setSelectedItems] = useState<IExplodedItemView[]>([]);
    const [loading, setLoading] = useState(false);

    const conflictedItemCount = Number(details?.billSplit?.conflictedItemCount || 0);
    const { conflictAlertMsg } = useSplitConflictAlertMsg(conflictedItemCount);
    const paymentProcessingFeeText = useGetPaymentProcessingFeeLabel({
        odf: details?.bill?.optionalDinerFee,
        billItems: details?._billItems,
    });

    // TODO: move this to transformer - causes loading to show twice
    // useEffect(() => {
    //     setSelectedItems((prevSelection) => {
    //         return filterSelectedItems(prevSelection, details?.paidItems, details?.itemsSelectedByYou);
    //     });
    // }, [details?.paidItems?.keys.length, details?.itemsSelectedByYou?.length]);

    const paymentProcessingFee = details?.billNumber?.yourCommission;

    const billItems = useMemo(() => {
        const netSubTotal = calculateSplitByItemNetSubtotal(selectedItems);
        const myShare = calculateSplitByItemTotal(selectedItems);

        return {
            netSubTotal,
            myShare,
        };
    }, [details?.billNumber?.yourCommission, selectedItems]);

    const changeItemsHandler = (item: IExplodedItemView, qty: number) => {
        onPushEvent('modify_item', {
            ...ga,
            splitMode: SplitModeTypeEnum.byItem,
        });

        setSelectedItems((prevSelectedItems) => {
            const selectedItemsClone = clone(prevSelectedItems);

            const idx = selectedItemsClone.findIndex((o) => o.key === item.key);

            if (qty === 0) {
                if (idx > -1) {
                    selectedItemsClone.splice(idx, 1);
                }
            } else if (idx === -1) {
                selectedItemsClone.push(item);
            }

            return selectedItemsClone;
        });
    };

    useEffect(() => {
        onSelect(
            billItems.myShare,
            {
                items: selectedItems?.map((item) => convertExplodedItemToPaidItem(item)),
            },
            true,
        );
    }, [selectedItems, billItems.myShare]);

    const priceData: PriceItem[] = useMemo(
        () => [
            {
                label: SplitPriceLabel.netSubTotal,
                value: billItems.netSubTotal > 0 ? billItems.netSubTotal : 0,
                text: t('Subtotal'),
                qaTextId: 'in-split-your-net-subtotal',
            },
            {
                label: SplitPriceLabel.paymentProcessingFee,
                value: paymentProcessingFee,
                text: paymentProcessingFeeText,
                qaTextId: 'in-split-payment-processing-fee',
            },
            {
                label: SplitPriceLabel.qlubDiscount,
                value: details.billNumber.qlubDiscount,
                text: t('Qlub Discount'),
            },
            {
                label: SplitPriceLabel.yourShare,
                value: billItems.myShare,
                text: t('Your share'),
                qaTextId: 'in-split-your-share',
            },
            {
                label: SplitPriceLabel.leftToPay,
                value: details.billNumber.remaining,
                text: t('Left To Pay'),
                qaTextId: 'in-split-left-to-pay',
            },
        ],
        [details, billItems, t, paymentProcessingFeeText],
    );

    const payHandler = () => {
        setLoading(true);
        onSelect(billItems.myShare, {
            items: selectedItems?.map((item) => convertExplodedItemToPaidItem(item)),
        })?.then(() => {
            setLoading(false);
        });
    };

    const removeSplitHandler = () => {
        setRemoveSplitLoading(true);
        onRemoveSplit()?.finally(() => {
            setSelectedItems([]);
            setRemoveSplitLoading(false);
        });
    };

    return (
        <>
            <CustomerContainer className={styles.mainContainer}>
                <ItemList
                    selectedItems={selectedItems}
                    details={details}
                    onChangeItems={changeItemsHandler}
                    currencyFormat={currencyFormat}
                />
            </CustomerContainer>
            <div className={styles.footer}>
                <Divider type="fullWidth" />
                <CustomerContainer padding="1rem 1.5rem">
                    {!!conflictedItemCount && countryConfig?.splitByItemV2Ui === EnableEnum.Enable && (
                        <>
                            <div className={styles.conflictItemAlertBox}>
                                <Trivia
                                    message={conflictAlertMsg}
                                    triviaOverrides={{
                                        backgroundColor: theme.qlub.palette.caution.transparent,
                                    }}
                                    iconOverrides={{
                                        color: theme.qlub.palette.caution.main,
                                    }}
                                    textOverrides={{
                                        color: theme.qlub.palette.black.main,
                                    }}
                                />
                            </div>
                            <div className={styles.conflictItemAlertBoxDivider}>
                                <Divider />
                            </div>
                        </>
                    )}
                    <TotalPrice
                        priceData={priceData}
                        footerText={inclusiveChargesMessage}
                        qaFooterTextId="in-split-info"
                        currencyFormat={{
                            ...currencyFormat,
                            currencyPrecision: details?.currencyPrecision || currencyFormat?.currencyPrecision,
                        }}
                        loading={draftAPILoading}
                    />
                    <SplitButtons
                        onPay={payHandler}
                        onRemoveSplit={removeSplitHandler}
                        myShare={billItems.myShare}
                        loading={loading}
                        removeSplitLoading={removeSplitLoading}
                    />
                </CustomerContainer>
            </div>
        </>
    );
};

export default SplitByItem;
