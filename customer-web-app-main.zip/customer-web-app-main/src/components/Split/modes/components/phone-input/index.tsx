import PhoneInputV2, { ChangeHandlerParams } from '@clubpay/customer-common-module/src/component/PhoneInputV2';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Typography from '@qlub-dev/qlub-kit/dist/components/Typography';
import classNames from 'classnames';
import { FC, useState } from 'react';
import { SplitUIVersion } from '@clubpay/customer-common-module/src/repository/vendor/type';

import styles from './phone.module.scss';

interface ISplitPhoneProps {
    isSplitSelectClicked: boolean;
    onPhoneChange: (formattedNumber?: string) => void;
    onValidation: (isValid: boolean) => void;
    splitUIVersion?: SplitUIVersion;
}

const SplitPhoneInput: FC<ISplitPhoneProps> = ({
    isSplitSelectClicked,
    splitUIVersion,
    onPhoneChange,
    onValidation,
}) => {
    const [phoneNumber, setPhoneNumber] = useState<string>('');

    const { t } = useTranslation();
    const { lang } = useQlubRouter();
    const { vendor } = useVendor();

    return (
        <div
            className={classNames({
                [styles.container]: splitUIVersion === SplitUIVersion.V2,
            })}
        >
            <Typography typo="caption_overline" sx={{ margin: '24px 0 8px 0px' }}>
                {t('Mobile number*')}
            </Typography>
            <PhoneInputV2
                placeholder={t('Enter mobile no')}
                lang={lang}
                defaultCountry={vendor?.country?.code ?? 'ar'}
                value={phoneNumber}
                onChange={(data: ChangeHandlerParams) => {
                    setPhoneNumber(data?.phone);
                    onPhoneChange(data?.inputValue);
                }}
                errorText={t('Please enter a valid mobile number')}
                validation={{
                    enable: true,
                    callbackFn: onValidation,
                    debounceWait: 1000,
                }}
                countrySearchLabel={t('Search for countries')}
                hideErrorText={!isSplitSelectClicked}
            />
        </div>
    );
};

export default SplitPhoneInput;
