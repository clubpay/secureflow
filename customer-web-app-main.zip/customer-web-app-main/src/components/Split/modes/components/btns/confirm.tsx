import { FC } from 'react';
import { Button, CustomerContainer } from '@qlub-dev/qlub-kit';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

interface IProps {
    myShare: number;
    onRemoveSplit: () => void;
    onPay: (myShare: number) => void;
    disabled?: boolean;
    loading?: boolean;
    removeSplitLoading?: boolean;
}

const SplitButtons: FC<IProps> = ({ myShare, disabled, loading, onPay, onRemoveSplit, removeSplitLoading }) => {
    const { t } = useTranslation('common');
    return (
        <CustomerContainer centered gap="sm" padding="1rem 0 0rem 0">
            <Button
                fullWidth
                size="large"
                type="submit"
                variant="containedDestructive"
                onClick={onRemoveSplit}
                disabled={loading || removeSplitLoading}
                id="remove-split"
                loading={removeSplitLoading}
            >
                {t('Remove split')}
            </Button>
            <Button
                disabled={myShare === 0 || disabled || loading || removeSplitLoading}
                variant="contained"
                size="large"
                type="submit"
                id="split-bill"
                fullWidth
                onClick={() => onPay(myShare)}
                loading={loading}
            >
                {t('Confirm')}
            </Button>
        </CustomerContainer>
    );
};

export default SplitButtons;
