import { FC } from 'react';
import Button from '@qlub-dev/qlub-kit/dist/components/Button';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

interface IProps {
    isDrawerOpen: boolean;
    toggleDrawer: (open: boolean) => void;
    closeSnackbar: () => void;
}

const ActionBtn: FC<IProps> = ({ isDrawerOpen, toggleDrawer: onDrawerOpen, closeSnackbar }) => {
    const { t } = useTranslation('common');

    return (
        <Button
            onClick={() => {
                if (!isDrawerOpen) {
                    onDrawerOpen(true);

                    setTimeout(() => {
                        closeSnackbar();
                    }, 200);
                } else {
                    closeSnackbar();
                }
            }}
            size="small"
            variant="text"
            color="inherit"
            sx={{
                backgroundColor: 'transparent !important',
                border: 'none !important',
                py: 0,
            }}
        >
            {t('Review')}
        </Button>
    );
};

export default ActionBtn;
