import React, { FC } from 'react';
import { Button, Divider, LabelButton } from '@qlub-dev/qlub-kit';
import { SplitUIVersion } from '@clubpay/customer-common-module/src/repository/vendor';

import styles from './index.module.scss';

interface ISplitSelectQAProps {
    readonly qaTitleId?: string;
}

export interface ISplitSelectProps extends ISplitSelectQAProps {
    title: string;
    buttonTitle: string;
    active: boolean;
    onClick: () => void;
    divider?: boolean;
    mode: string;
    version: SplitUIVersion;
}

const SplitSelect: FC<ISplitSelectProps> = ({
    title,
    buttonTitle,
    onClick,
    active,
    divider,
    mode,
    version,
    qaTitleId,
}) => {
    return (
        <>
            {version === SplitUIVersion.V2 ? (
                <div className={styles.v2}>
                    <LabelButton
                        text={title}
                        disabled={!active}
                        onClick={onClick}
                        qaIds={{
                            btnId: qaTitleId,
                        }}
                    />
                </div>
            ) : (
                <>
                    <div className={styles.selectItem}>
                        <h3 data-qa-id={qaTitleId}>{title}</h3>
                        <Button id={`select-${mode}`} onClick={onClick} variant="containedLight" disabled={!active}>
                            {buttonTitle}
                        </Button>
                    </div>
                    {divider && <Divider type="fullWidth" />}
                </>
            )}
        </>
    );
};

export default SplitSelect;
