import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { SplitModeTypeEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';
import { SwipeableCustomerDrawer } from '@qlub-dev/qlub-kit/dist/components/Drawer';
import { FC, useMemo } from 'react';

import styles from './index.module.scss';

interface IDrawerProps {
    isOpen: boolean;
    splitMode?: SplitModeTypeEnum;
    hasSelectedSplitMode?: boolean;
    onOpenChange: (open?: boolean) => () => void;
}

const Drawer: FC<IDrawerProps> = ({ isOpen, onOpenChange, splitMode, hasSelectedSplitMode, children }) => {
    const { t } = useTranslation();

    const headerTitle = useMemo(() => {
        switch (splitMode) {
            case SplitModeTypeEnum.custom:
                return t('Pay a custom amount');
            case SplitModeTypeEnum.byItem:
                return t('Pay for your items');
            case SplitModeTypeEnum.byShare:
                return t('Divide the bill equally');
            default:
                return null;
        }
    }, [splitMode]);

    return (
        <SwipeableCustomerDrawer
            headerTitle={headerTitle}
            removeHeader={!hasSelectedSplitMode}
            anchor="bottom"
            hasOverflow={splitMode === SplitModeTypeEnum.byItem}
            hasRadius={!hasSelectedSplitMode}
            open={isOpen}
            onClose={onOpenChange(false)}
            onOpen={onOpenChange(true)}
            BackdropProps={{ sx: { background: '#00000099' } }}
            PaperProps={{
                elevation: 0,
                sx: {
                    background: 'transparent',
                    borderTopLeftRadius: '32px',
                    borderTopRightRadius: '32px',
                },
            }}
            sx={{
                '>div': {
                    '>div': {
                        padding: hasSelectedSplitMode ? 0 : '12px 1.5rem',
                    },
                },
            }}
            contentStyle={{
                padding: splitMode === SplitModeTypeEnum.byItem && hasSelectedSplitMode ? 0 : 0,
            }}
            qaIds={{
                closeBtnId: 'split-type-close-modal',
                titleId: 'split-title',
            }}
        >
            <div className={hasSelectedSplitMode ? styles.container : ''}>{children}</div>
        </SwipeableCustomerDrawer>
    );
};

export default Drawer;
