import React, { FC, ReactElement, useEffect, useMemo } from 'react';
import { SplitModeTypeEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Paper } from '@mui/material';
import {
    Button,
    CardButton,
    CustomerContainer,
    Divider,
    PriceItem,
    SplitPriceLabel,
    TotalPrice,
    Typography,
} from '@qlub-dev/qlub-kit';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import useElemObserver from '@/hooks/elemObserver';
import Format, { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { CampaignDiscountTypeEnum, IPaymentDetails } from '@/repositories/bill';
import { usePGGroupStore } from '@/store/pgGroup';
import { useGetInclusiveChargesMessage } from '@/hooks/getInclusiveChargesMessage';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import useDiscountStore from '@/store/discounts';

import styles from './index.module.scss';

interface IProps {
    currencyFormat: CurrencyFormat;
    details: IPaymentDetails;
    isSplit: boolean;
    onSplit: () => void;
    onPayFullBill: (preventFullPayment?: boolean) => void;
    ga: Record<string, unknown>;
    onScrollToElement: (element: 'invoice' | 'payment' | 'split') => void;
    loyalty?: ReactElement;
}

interface ISplitItem {
    priceData: PriceItem[];
    footer: any;
    firstButton: any;
    secondButton: any;
    preventFullPayment?: boolean;
}

const SplitAnchor: FC<IProps> = ({
    details,
    isSplit,
    onSplit,
    onPayFullBill,
    ga,
    onScrollToElement,
    currencyFormat,
    loyalty,
}) => {
    const { t } = useTranslation('common');
    const { show: showBill } = useElemObserver({ selector: '#invoiceElement', threshold: 0.25, hysteresis: 0.25 });
    const { setBillPaidStatus } = usePGGroupStore((state) => state);
    const { inclusiveChargesMessage } = useGetInclusiveChargesMessage({});
    const { vendor } = useVendor();

    const hasCorporateDiscountBeenApplied = useDiscountStore((state) => state.hasDiscountBeenApplied);

    const paid = useMemo(() => {
        if (details.billNumber.remaining === 0) {
            return 'paid';
        }
        if (details.billNumber.payableAmount === details.billNumber.remaining) {
            return 'notPaid';
        }
        return 'partial';
    }, [details.billNumber.remaining, details.billNumber.payableAmount]);

    const getDataOf = (filters: SplitPriceLabel[]) => {
        let filteredList = filters;
        if (!details.billNumber.qlubDiscount) {
            filteredList = filters.filter((d) => d !== 'qlubDiscount');
        }
        const list: PriceItem[] = [
            {
                label: SplitPriceLabel.billAmount,
                text: t('Total'),
                value: details.billNumber.billAmount,
            },
            {
                label: SplitPriceLabel.qlubDiscount,
                text: t('Promotion code'),
                value: details.billNumber.voucherAmount,
            },
            {
                label: SplitPriceLabel.payableAmount,
                text: t('Payable amount'),
                value: details.billNumber.payableAmount,
                qaTextId: 'billing-payable-amount',
            },
            {
                label: SplitPriceLabel.leftToPay,
                value: details.billNumber.remaining,
                text: t('Left to pay'),
            },
            {
                label: SplitPriceLabel.youPaid,
                value: details.yourSplitSettings.amountNumber,
                text: t('You paid'),
            },
            {
                label: SplitPriceLabel.fullyPaid,
                text: t('Bill is fully paid'),
            },
            {
                label: SplitPriceLabel.yourShare,
                value: details.billNumber.yourShare,
                text: t('Your Share'),
            },
            {
                label: SplitPriceLabel.changeableAmount,
                value: details.billNumber.yourShare,
                text: showBill ? t('Your share') : t('Payable amount'),
                qaTextId: showBill ? 'billing-your-share' : 'billing-payable-amount',
            },
        ];
        return list.filter((item) => filteredList.some((l) => l === item.label));
    };

    const splitData = useMemo<ISplitItem>(() => {
        const peopleShare =
            details.billSplit?.totalShares ||
            details.otherSplitSettings.billSplit.totalShares ||
            details.yourSplitSettings.billSplit.totalShares;
        if (paid === 'paid') {
            return {
                priceData: !details.yourSplitSettings.paymentDone
                    ? getDataOf([SplitPriceLabel.fullyPaid])
                    : getDataOf([SplitPriceLabel.youPaid, SplitPriceLabel.fullyPaid]),
                footer: t('Reward the staff with a tip'),
                firstButton: t('Edit the split'),
                secondButton: t('Pay the rest'),
            };
        }
        if (paid === 'notPaid') {
            if (isSplit) {
                // locked custom because of campaign voucher
                if (
                    details.campaignVoucher?.code &&
                    !details.campaignVoucher.redeemed &&
                    (!details.yourSplitSettings.billSplit.splitMode ||
                        details.yourSplitSettings.billSplit.splitMode === SplitModeTypeEnum.unknown)
                ) {
                    return {
                        priceData: getDataOf([
                            SplitPriceLabel.billAmount,
                            SplitPriceLabel.qlubDiscount,
                            SplitPriceLabel.payableAmount,
                        ]),
                        footer: inclusiveChargesMessage,
                        firstButton: vendor?.config.disableSplitWithPromo ? t('Split bill') : t('Custom amount'),
                        secondButton: t('Pay fully', { useLocale: true }),
                    };
                }
                // no payment splitted

                return {
                    priceData: getDataOf([
                        SplitPriceLabel.qlubDiscount,
                        SplitPriceLabel.payableAmount,
                        SplitPriceLabel.yourShare,
                    ]),
                    footer:
                        details.billSplit?.mode === SplitModeTypeEnum.byItem
                            ? t('You are paying for your items')
                            : details.billSplit?.mode === SplitModeTypeEnum.byShare
                            ? t('You are paying for your share')
                            : t('You are paying for your share'),
                    firstButton: t('Edit split'),
                    secondButton: t('Pay your share'),
                    preventFullPayment: true,
                };
            }
            // no payment not splitted
            return {
                priceData: details.campaignVoucher?.code
                    ? getDataOf([
                          SplitPriceLabel.billAmount,
                          SplitPriceLabel.qlubDiscount,
                          SplitPriceLabel.changeableAmount,
                      ])
                    : getDataOf([SplitPriceLabel.changeableAmount]),
                footer: inclusiveChargesMessage,
                firstButton: t('Split bill'),
                secondButton: t('Pay fully', { useLocale: true }),
            };
        }
        if (isSplit) {
            // partial paid splitted
            if (details.yourSplitSettings.paymentDone) {
                return {
                    priceData: getDataOf([SplitPriceLabel.leftToPay, SplitPriceLabel.youPaid]),
                    footer: t('You paid for your share, Reward the staff with a tip'),
                    firstButton: '',
                    secondButton: '',
                };
            }
            // splitted and user chose his/her share
            if (
                details.yourSplitSettings.billSplit.splitMode &&
                (details.yourSplitSettings.billSplit.share > 0 ||
                    (details.yourSplitSettings.billSplit.items &&
                        details.yourSplitSettings.billSplit.items.length > 0) ||
                    Number(details.yourSplitSettings.amount) > 0)
            ) {
                return {
                    priceData: details.campaignVoucher?.isVoucherOwner
                        ? getDataOf([
                              SplitPriceLabel.leftToPay,
                              SplitPriceLabel.qlubDiscount,
                              SplitPriceLabel.yourShare,
                          ])
                        : getDataOf([SplitPriceLabel.leftToPay, SplitPriceLabel.yourShare]),
                    footer:
                        details.billSplit?.mode === SplitModeTypeEnum.byItem
                            ? t('You can split the bill and pay for your item')
                            : details.billSplit?.mode === SplitModeTypeEnum.byShare
                            ? t('The bill has been split by {{peopleShare}} people equally', { peopleShare })
                            : t('You can pay custom amount for the bill'),
                    firstButton: t('Edit split'),
                    secondButton: t('Pay your share'),
                    preventFullPayment: true,
                };
            }
            // splitted user hasn't chosen the share
            return {
                priceData:
                    details.campaignVoucher?.redeemed || details.campaignVoucher?.code
                        ? getDataOf([SplitPriceLabel.leftToPay])
                        : getDataOf([
                              SplitPriceLabel.payableAmount,
                              SplitPriceLabel.qlubDiscount,
                              SplitPriceLabel.leftToPay,
                          ]),
                footer:
                    details.billSplit?.mode === SplitModeTypeEnum.byItem
                        ? t('You can split the bill and pay for your item')
                        : details.billSplit?.mode === 'byShare'
                        ? t('The bill has been split by {{peopleShare}} people equally', { peopleShare })
                        : t('You can pay custom amount for the bill'),
                firstButton:
                    details.billSplit?.mode === SplitModeTypeEnum.byItem
                        ? t('Pay item')
                        : details.billSplit?.mode === SplitModeTypeEnum.byShare
                        ? t('Pay share')
                        : t('Pay custom'),
                secondButton: t('Pay the rest'),
            };
        }
        if (!isSplit) {
            // partial paid not splitted
            return {
                priceData: getDataOf([SplitPriceLabel.leftToPay]),
                footer: inclusiveChargesMessage,
                firstButton: t('Split the bill'),
                secondButton: t('Pay the rest'),
            };
        }
        return {
            // prevent to crush return
            priceData: getDataOf([SplitPriceLabel.payableAmount]),
            footer: inclusiveChargesMessage,
            firstButton: t('Split the bill'),
            secondButton: t('Pay full bill'),
        };
    }, [details, showBill, isSplit, t]);

    const onSplitHandler = () => {
        onSplit();
        if (details.yourSplitSettings.billSplit.splitMode) {
            onPushEvent('edit_split', {
                ...ga,
                splitMode: details.yourSplitSettings.billSplit.splitMode,
            });
        } else {
            onPushEvent('add_split', {
                ...ga,
                splitMode: details.billSplit?.mode,
            });
        }
    };

    const onViewBill = () => {
        onScrollToElement('invoice');
        onPushEvent('pay_the_rest', {
            ...ga,
            splitMode: details.billSplit?.mode,
        });
    };

    const renderVoucher = () => {
        if (
            hasCorporateDiscountBeenApplied ||
            (details.campaignVoucher?.redeemed === true &&
                details.campaignVoucher?.discountType === CampaignDiscountTypeEnum.CORPORATE)
        ) {
            return null;
        }

        return (
            <CardButton
                greenStyle
                cardContent={
                    <>
                        <Typography typo="body_sm">
                            <Format currencyFormat={currencyFormat} value={String(details.billNumber.voucherAmount)} />
                            {` ${t('is saved with a promo code')}`}
                        </Typography>
                    </>
                }
            />
        );
    };

    useEffect(() => {
        setBillPaidStatus(`${paid}-${details.yourSplitSettings.paymentDone}`);
    }, [paid]);

    return (
        <Paper elevation={0} className={styles.stickyAnchor}>
            <div className={styles.fullWidth}>
                <div className={styles.dividerContainer}>
                    <Divider type="fullWidth" />
                </div>

                {loyalty}

                <div className={styles.splitAction}>
                    <TotalPrice
                        priceData={splitData.priceData}
                        footerText={splitData.footer}
                        currencyFormat={currencyFormat}
                    />
                    {/** *** show it when voucher is applied and
           1) bill is fully paid or
           2) this party paid it's share and return to bill or
           3) another party paid a share and current party hasn't choose the share yet
           */}
                    {(details.campaignVoucher?.redeemed || details.campaignVoucher?.code) &&
                        (details.billNumber.remaining === 0 ||
                            details.yourSplitSettings.paymentDone ||
                            (isSplit &&
                                details.billNumber.remaining > 0 &&
                                details.otherSplitSettings.paymentDone &&
                                !details.yourSplitSettings.billSplit.splitMode)) &&
                        renderVoucher()}

                    {details?.billNumber.remaining !== 0 && !details.yourSplitSettings.paymentDone && (
                        <CustomerContainer className={styles.splitContainer} sx={{ display: 'flex' }}>
                            <Button
                                data-qa-id="billing-split-bill"
                                onClick={onSplitHandler}
                                variant="containedLight"
                                color="primary"
                                type="submit"
                                fullWidth
                                disabled={
                                    details.yourSplitSettings.paymentDone ||
                                    (vendor?.config.disableSplitWithPromo &&
                                        (details.campaignVoucher?.redeemed || !!details.campaignVoucher?.code))
                                }
                            >
                                {splitData.firstButton || t('Split the bill')}
                            </Button>
                            {!(
                                details.yourSplitSettings.billSplit.splitMode &&
                                (details.yourSplitSettings.billSplit.share > 0 ||
                                    (details.yourSplitSettings.billSplit.items &&
                                        details.yourSplitSettings.billSplit.items.length > 0) ||
                                    (details.yourSplitSettings.amountNumber > 0 &&
                                        details.yourSplitSettings.amountNumber === details.billNumber.remaining)) &&
                                details.otherSplitSettings.paymentDone
                            ) && (
                                <Button
                                    variant={showBill ? 'outlined' : 'contained'}
                                    size="large"
                                    type="submit"
                                    id="pay-full-bill"
                                    fullWidth
                                    disabled={details.yourSplitSettings.paymentDone}
                                    onClick={(e) => {
                                        if (showBill) {
                                            return onViewBill();
                                        }
                                        e.currentTarget.blur();
                                        onPayFullBill(splitData.preventFullPayment);
                                    }}
                                    sx={{
                                        transition: 'all .5s ease',
                                    }}
                                >
                                    {showBill ? t('View bill') : splitData.secondButton || t('Pay full bill')}
                                </Button>
                            )}
                        </CustomerContainer>
                    )}
                </div>
            </div>
        </Paper>
    );
};

export default SplitAnchor;
