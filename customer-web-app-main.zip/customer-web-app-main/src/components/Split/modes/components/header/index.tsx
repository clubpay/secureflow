import { IconButton } from '@mui/material';
import { ClearRounded } from '@mui/icons-material';
import classNames from 'classnames';
import { FC } from 'react';
import { CustomerContainer, Typography } from '@qlub-dev/qlub-kit';

import styles from './index.module.scss';

interface ISplitHeaderProps {
    title: string;
    subTitle: string;
    onClose: () => void;
    margin?: 'normal' | 'over';
}

const SplitHeader: FC<ISplitHeaderProps> = ({ title, subTitle, onClose, margin }) => {
    return (
        <CustomerContainer
            gap="xs"
            className={classNames(styles.header, {
                [styles.marginOver]: margin === 'over',
            })}
        >
            <div className={styles.title}>
                <Typography data-qa-id="split-modal-title" variant="h2" typo="title_lg">
                    {title}
                </Typography>
                <IconButton data-qa-id="split-close-modal" size="small" onClick={onClose} sx={{ py: 1, px: 0 }}>
                    <ClearRounded className={styles.clear} />
                </IconButton>
            </div>
            <p data-qa-id="split-modal-description" className={styles.subtitle}>
                {subTitle}
            </p>
        </CustomerContainer>
    );
};

export default SplitHeader;
