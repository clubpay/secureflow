import { useEffect, useState, useCallback, FC } from 'react';
import Format from '@qlub-dev/qlub-kit/dist/components/Format';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import styles from './index.module.scss';

interface IProps {
    centerContentData?: { mainText?: any; subText?: string };
    chartRef: React.RefObject<HTMLDivElement>;
}

const CenterContent: FC<IProps> = ({ centerContentData, chartRef }) => {
    const [fontSize, setFontSize] = useState<string>('1.2em');
    const [subTextFontSize, setSubTextFontSize] = useState<string>('0.6em');
    const { currencyFormat } = useVendor();

    const updateFontSize = useCallback(() => {
        if (chartRef.current) {
            const { width } = chartRef.current.getBoundingClientRect();
            const newFontSize = `${Math.max((0.035 * width) / 10, 1.4375)}em`; // Minimum font size of 1.4375em
            const newSubTextFontSize = `${Math.max((0.017 * width) / 10, 0.75)}em`; // Minimum font size of 0.75em
            setFontSize(newFontSize);
            setSubTextFontSize(newSubTextFontSize);
        }
    }, [chartRef]);

    useEffect(() => {
        if (!chartRef.current) return;

        const observer = new ResizeObserver(updateFontSize);
        observer.observe(chartRef.current);

        return () => {
            observer.disconnect();
        };
    }, [chartRef, updateFontSize]);

    return (
        centerContentData?.mainText && (
            <div
                className={styles.centerText}
                style={{ '--main-font-size': fontSize, '--sub-font-size': subTextFontSize } as React.CSSProperties}
            >
                <div className={styles.mainText}>
                    <Format
                        bold={centerContentData.mainText?.bold}
                        value={centerContentData.mainText?.value}
                        currencyFormat={currencyFormat}
                    />
                </div>
                {centerContentData?.subText && (
                    <div>
                        <div className={styles.subText}>{centerContentData.subText}</div>
                    </div>
                )}
            </div>
        )
    );
};

export { CenterContent };
