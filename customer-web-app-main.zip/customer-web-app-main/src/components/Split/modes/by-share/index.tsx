import { FC, useEffect, useMemo, useState } from 'react';
import { Alert, Divider } from '@mui/material';
import { IRestaurant, SplitModeTypeEnum, VersionEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import SplitButtons from '@/components/Split/modes/components/btns/confirm';
import { CustomerContainer, SelectionIndicator, TotalPrice, PriceItem, SplitPriceLabel } from '@qlub-dev/qlub-kit';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { InfoRounded } from '@mui/icons-material';
import { IPaymentDetails } from '@/repositories/bill';
import { SplitRatioChart } from '@qlub-dev/qlub-kit/dist/components/Charts/SplitRatioChart';
import { StackElements } from '@qlub-dev/qlub-kit/dist/components/StackElements';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { ISplitOptions } from '@/views/Bill/Invoice/types';
import { CenterContent } from './content';
import useGetPaymentProcessingFeeLabel from '../../hooks/payment-processing-fee-txt';
import { calculateSplitByShareAmountV1, calculateSplitByShareAmountV2 } from '../../utils';

import styles from './index.module.scss';

interface IProps {
    vendor: IRestaurant | undefined;
    details: IPaymentDetails;
    inclusiveChargesMessage: string;
    closeDrawer: () => void;
    onRemoveSplit: () => Promise<any> | undefined;
    onShareCountChange: (amount: number, options?: ISplitOptions, draft?: boolean) => Promise<any> | undefined;
    ga: Record<string, unknown>;
    currencyFormat: CurrencyFormat;
    draftAPILoading: boolean;
}

const SplitByShare: FC<IProps> = ({
    onRemoveSplit,
    details,
    vendor,
    onShareCountChange,
    inclusiveChargesMessage,
    ga,
    currencyFormat,
    draftAPILoading,
}) => {
    const [loading, setLoading] = useState(false);
    const [removeSplitLoading, setRemoveSplitLoading] = useState(false);
    const [yourShares, setYourShares] = useState(1);
    const [totalShares, setTotalShares] = useState(1);

    const { t } = useTranslation('common');

    const paymentProcessingFeeText = useGetPaymentProcessingFeeLabel({
        odf: details?.bill?.optionalDinerFee,
        billItems: details?._billItems,
    });

    useEffect(() => {
        if (details.billSplit?.mode === SplitModeTypeEnum.byShare && details.otherSplitSettings.paymentDone) {
            setTotalShares(
                Number(details.billSplit?.totalShares) || details.yourSplitSettings.billSplit.totalShares || 2,
            );
            if (details.yourSplitSettings.billSplit.share) {
                setYourShares(details.yourSplitSettings.billSplit.share);
            }
        } else {
            setYourShares(details.yourSplitSettings.billSplit.share || 1);
            setTotalShares(
                Number(details.billSplit?.totalShares) || details.yourSplitSettings.billSplit.totalShares || 2,
            );
        }
    }, []);

    const splitByShareAlgorithm =
        vendor?.config?.splitByShareAlgorithm ?? vendor?.country?.config?.splitByShareAlgorithm;

    const totalAmount = useMemo(() => {
        if (splitByShareAlgorithm === VersionEnum.V2) {
            return calculateSplitByShareAmountV2(details, yourShares, totalShares);
        }

        return calculateSplitByShareAmountV1(details, yourShares, totalShares);
    }, [yourShares, totalShares, splitByShareAlgorithm]);

    useEffect(() => {
        onShareCountChange?.(totalAmount, { yourShares, totalShares }, true);
    }, [yourShares, totalShares, totalAmount]);

    const priceData: PriceItem[] = useMemo(
        () => [
            {
                label: SplitPriceLabel.netSubTotal,
                value: totalAmount - details?.billNumber?.yourCommission,
                text: t('Subtotal'),
                qaTextId: 'in-split-left-to-pay',
            },
            {
                label: SplitPriceLabel.qlubDiscount,
                value: details.billNumber.qlubDiscount,
                text: t('Qlub Discount'),
                qaTextId: 'in-split-qlub-discount',
            },
            {
                label: SplitPriceLabel.paymentProcessingFee,
                value: details?.billNumber?.yourCommission,
                text: paymentProcessingFeeText,
                qaTextId: 'in-split-left-to-pay',
            },
            {
                label: SplitPriceLabel.yourShare,
                value: totalAmount,
                text: t('Your share'),
                qaTextId: 'in-split-your-share',
            },
            {
                label: SplitPriceLabel.leftToPay,
                value: details.billNumber.remaining,
                text: t('Left To Pay'),
                qaTextId: 'in-split-left-to-pay',
            },
        ],
        [details, totalAmount, paymentProcessingFeeText, t],
    );

    const centerContentData: { mainText: any; subText: string } = useMemo(() => {
        return {
            mainText: {
                bold: true,
                value: String(details.billNumber.remaining),
                currencyPrecision: details.currencyPrecision,
                params: {
                    cs: `${vendor?.country.currencySymbol}`,
                },
            },
            subText: t('Total bill amount'),
        };
    }, [details.billNumber.remaining, details.currencyPrecision, vendor?.country.currencySymbol, t]);

    const totalSharesChangeHandler = (num: number) => {
        onPushEvent('modify_Participant', {
            ...ga,
            splitMode: SplitModeTypeEnum.byShare,
        });
        setTotalShares(num);
    };

    const yourSharesChangeHandler = (num: number) => {
        onPushEvent('modify_share', {
            ...ga,
            splitMode: SplitModeTypeEnum.byShare,
        });
        setYourShares(num);
    };

    const payHandler = () => {
        setLoading(true);
        onShareCountChange(totalAmount, { yourShares, totalShares })?.finally(() => {
            setLoading(false);
        });
    };

    const removeSplitHandler = () => {
        setRemoveSplitLoading(true);
        onRemoveSplit()?.finally(() => {
            setRemoveSplitLoading(false);
        });
    };

    const { share } = details.otherSplitSettings.billSplit;

    return (
        <>
            <CustomerContainer className={styles.mainContainer} padding="0 1.5rem">
                <div className={styles.drawerContent}>
                    <SplitRatioChart
                        totalPeople={totalShares}
                        maxScale={12}
                        payingFor={yourShares}
                        centerContentData={centerContentData}
                        CenterContent={CenterContent}
                        strokeWidth={5}
                    />

                    <div className={styles.shareItem}>
                        <StackElements spacing={5} direction="row" alignItems="center" justifyContent="center">
                            <StackElements spacing={9} direction="column" alignItems="flex-end" justifyContent="center">
                                <span className={styles.leftText}>{t('Total people')}</span>
                                <span className={styles.leftText}>{t('Total people')}</span>
                            </StackElements>

                            <StackElements spacing={4} direction="column" alignItems="center" justifyContent="center">
                                <div>
                                    <SelectionIndicator
                                        disabled={
                                            details.billSplit?.mode === SplitModeTypeEnum.byShare &&
                                            details.otherSplitSettings.paymentDone
                                        }
                                        min={2}
                                        value={totalShares}
                                        onValueChange={totalSharesChangeHandler}
                                        splitByShareV2UI
                                    />
                                </div>

                                <div>
                                    <SelectionIndicator
                                        max={
                                            details.otherSplitSettings.billSplit.share
                                                ? totalShares - details.otherSplitSettings.billSplit.share
                                                : totalShares
                                        }
                                        min={1}
                                        value={yourShares}
                                        onValueChange={yourSharesChangeHandler}
                                        splitByShareV2UI
                                    />
                                </div>
                            </StackElements>

                            <StackElements
                                spacing={9}
                                direction="column"
                                alignItems="flex-start"
                                justifyContent="center"
                            >
                                <span className={styles.leftText}>{t('at your table')}</span>
                                <span className={styles.leftText}>{t('you pay for')}</span>
                            </StackElements>
                        </StackElements>
                    </div>
                    {share > 0 && (
                        <span className={styles.shareItemAlert}>
                            <Alert color="info" variant="filled" iconMapping={{ success: <InfoRounded /> }}>
                                {share === 1
                                    ? `${share} ${t('share has been already paid for this bill')}`
                                    : `${share} ${t('shares have been already paid for this bill')}`}
                            </Alert>
                        </span>
                    )}
                </div>
            </CustomerContainer>
            <div className={styles.footer}>
                <Divider />
                <CustomerContainer padding="1rem 1.5rem">
                    <TotalPrice
                        priceData={priceData}
                        footerText={inclusiveChargesMessage}
                        qaFooterTextId="in-split-info"
                        currencyFormat={{
                            ...currencyFormat,
                            currencyPrecision: details?.currencyPrecision || currencyFormat?.currencyPrecision,
                        }}
                        loading={draftAPILoading}
                    />
                    <SplitButtons
                        onPay={payHandler}
                        onRemoveSplit={removeSplitHandler}
                        myShare={totalAmount}
                        disabled={yourShares === 0 || totalShares < 2}
                        loading={loading}
                        removeSplitLoading={removeSplitLoading}
                    />
                </CustomerContainer>
            </div>
        </>
    );
};
export default SplitByShare;
