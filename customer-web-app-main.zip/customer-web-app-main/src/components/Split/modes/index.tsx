import React, { FC, MutableRefObject, ReactElement, RefObject, useCallback, useEffect, useState } from 'react';
import {
    EnableEnum,
    SmartTipModalTriggerPointConditionEnum,
    SplitModeTypeEnum,
    SplitUIVersion,
} from '@clubpay/customer-common-module/src/repository/vendor';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import SplitByShare from '@/components/Split/modes/by-share';
import SplitByCustom from '@/components/Split/modes/by-custom';
import SplitAnchor from '@/components/Split/modes/components/split-anchor';
import SplitSelect from '@/components/Split/modes/components/btns/mode';
import SplitHeader from '@/components/Split/modes/components/header';
import { SplitRealTimeFeeCalcModeEnum } from '@clubpay/customer-common-module/src/repository/config';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { IPaymentDetails } from '@/repositories/bill';
import { useTheme } from '@mui/material';
import DiscountFilledIcon from '@clubpay/customer-common-module/src/component/Icons/DiscountFilledIcon';
import { checkActiveCampaign } from '@clubpay/customer-common-module/src/utility/vendor';
import { useGetInclusiveChargesMessage } from '@/hooks/getInclusiveChargesMessage';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { ISplitOptions } from '@/views/Bill/Invoice/types';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { TipToggleOriginEnum } from '@/components/Tip/normal/enums';
import { TipToggleFunc } from '@/components/Tip/normal/types';
import { ISmartTipModalHandler } from '@/components/Tip/smart';
import { cloneDeep } from 'lodash';
import useSetAmount from '../hooks/set-amount';
import useSplitConflictAlertMsg from '../hooks/split-conflict-alert';
import SplitPhoneInput from './components/phone-input';
import SplitByItem from './by-item';
import { calculateSplitByItemTotal } from '../utils';
import Drawer from './components/drawer';
import ActionBtn from './components/btns/action';
import useGetAvailableSplitModes from '../hooks/get-split-modes';

import styles from './index.module.scss';

interface IProps {
    details: IPaymentDetails;
    onSplitChange: (enable: boolean) => void;
    onSetAmount: (data: IPaymentDetails) => void;
    ga: Record<string, unknown>;
    billUpdateTriggered: number;
    onScrollToElement: (element: 'invoice' | 'payment' | 'split') => void;
    onTipModalOpenRef?: MutableRefObject<TipToggleFunc | undefined>;
    smartTipModalHandlerRef?: RefObject<ISmartTipModalHandler>;
    currencyFormat: CurrencyFormat;
    loyalty?: ReactElement;
}

const SplitMode: FC<IProps> = ({
    billUpdateTriggered,
    details: invoiceDetails,
    onSetAmount,
    ga,
    onScrollToElement,
    onTipModalOpenRef,
    smartTipModalHandlerRef,
    currencyFormat,
    loyalty,
}) => {
    const [drawerOpen, setDrawerOpen] = useState(false);
    const [splitMode, setSplitMode] = useState<SplitModeTypeEnum | undefined>();
    const [details, setDetails] = useState<IPaymentDetails>(cloneDeep(invoiceDetails));
    const [hasSelectedSplitMode, setHasSelectedSplitMode] = useState(!!invoiceDetails.billSplit?.mode);
    const [isSplit, setIsSplit] = useState(!!invoiceDetails.billSplit?.mode);
    const [formattedPhoneNumber, setFormattedPhoneNumber] = useState<string>('');
    const [isValidPhoneNumber, setIsValidPhoneNumber] = useState<boolean | undefined>(undefined);
    const [isSplitSelectClicked, setIsSplitSelectClicked] = useState<boolean>(false);

    const { t } = useTranslation('common');
    const theme = useTheme();
    const { triggerSnackBar: enqueueSnackbar, triggerAlternateSnackBar, closeSnackbar } = snackBar();
    const { vendor } = useVendor();
    const { config } = useConfigContext();

    const { callSetAmount, draftAPILoading } = useSetAmount({ details });
    const hasActiveCampaign = checkActiveCampaign(config, vendor?.config?.voucherHasActiveCampaign, vendor?.brand.id);
    const { inclusiveChargesMessage } = useGetInclusiveChargesMessage({});
    const { conflictAlertMsg } = useSplitConflictAlertMsg(details.billSplit?.conflictedItemCount || 0);
    const { splitModes } = useGetAvailableSplitModes({ availableModes: invoiceDetails?.billSplit?.availableModes });

    const splitUIVersion = vendor?.config?.splitUIVersion ?? config?.splitUIVersion ?? SplitUIVersion.V1;
    const isPhoneInputEnabled = vendor?.config?.enablePhoneNumberInSplit;
    const isPartiallyPaid = details?.isPartiallyPaid;

    useEffect(() => {
        if (
            invoiceDetails.billSplit?.conflict &&
            invoiceDetails?.billSplit?.conflictedItemCount &&
            invoiceDetails.billSplit?.mode === SplitModeTypeEnum.byItem
        ) {
            const selectedItems = invoiceDetails.itemsSelectedByYou || [];
            const isSplitByItemV2UiEnabled = config?.splitByItemV2Ui === EnableEnum.Enable;

            callSetAmount(SplitModeTypeEnum.byItem, calculateSplitByItemTotal(selectedItems), {
                options: {
                    items: selectedItems,
                },
                mobileNo: formattedPhoneNumber,
            }).then((response) => {
                const alertOptions: { variant: 'warning'; action?: JSX.Element } = isSplitByItemV2UiEnabled
                    ? {
                          variant: 'warning',
                          action: (
                              <ActionBtn
                                  isDrawerOpen={drawerOpen}
                                  toggleDrawer={(isOpen) => setDrawerOpen(isOpen)}
                                  closeSnackbar={closeSnackbar}
                              />
                          ),
                      }
                    : { variant: 'warning' };

                if (isSplitByItemV2UiEnabled) {
                    enqueueSnackbar(conflictAlertMsg, alertOptions);
                } else {
                    enqueueSnackbar(
                        t('The item you selected to pay has been modified due to changes in order details'),
                        alertOptions,
                    );
                }

                onSetAmount(response.paymentDetails);
            });
        }
    }, [invoiceDetails.billSplit?.conflict]);

    useEffect(() => {
        if (billUpdateTriggered > 0) {
            callSetAmount(isPartiallyPaid ? SplitModeTypeEnum.custom : SplitModeTypeEnum.unknown, 0, {
                options: {
                    items: [],
                    yourShares: 0,
                    totalShares: 0,
                },
            }).then((response) => {
                onSetAmount(response.paymentDetails);
            });
        }
    }, [billUpdateTriggered]);

    useEffect(() => {
        setSplitMode(invoiceDetails.billSplit?.mode);
        setHasSelectedSplitMode(invoiceDetails.billSplit?.mode !== SplitModeTypeEnum.empty);
        setIsSplit(invoiceDetails.billSplit?.mode !== SplitModeTypeEnum.empty);
    }, [invoiceDetails.billSplit?.mode]);

    const dispatchGA = useCallback((mode: SplitModeTypeEnum, amount: number, options?: ISplitOptions) => {
        const splitDetails: any = {};
        if (mode === SplitModeTypeEnum.byItem) {
            splitDetails.split_item = options?.items;
        } else if (mode === SplitModeTypeEnum.byShare) {
            splitDetails.split_equally = {
                participants: options?.totalShares,
                share: options?.yourShares,
            };
        } else {
            splitDetails.split_custom = amount;
        }

        onPushEvent('confirm_split', {
            ...ga,
            splitMode,
            splitDetails,
        });
    }, []);

    const dispatchThirdPartyTriggers = useCallback(() => {
        setTimeout(() => {
            onTipModalOpenRef?.current?.(true, TipToggleOriginEnum.Split, 1000);

            smartTipModalHandlerRef?.current?.toggleDrawer(
                true,
                SmartTipModalTriggerPointConditionEnum.ConfirmPaymentType,
            );
        }, 300);
    }, []);

    if (!details) {
        return null;
    }

    const toggleDrawerHandler = (open?: boolean) => () => {
        if (open === undefined) {
            setDrawerOpen((o) => !o);
            return;
        }

        if (open === false) {
            onPushEvent('close_modal', {
                ...ga,
                splitMode: invoiceDetails.yourSplitSettings.billSplit.splitMode || invoiceDetails.billSplit?.mode,
            });
        }

        setDrawerOpen(open);

        if (!invoiceDetails.billSplit?.mode || (isPhoneInputEnabled && isPartiallyPaid)) {
            setHasSelectedSplitMode(false);
        }
    };

    const selectModeHandler = (mode: SplitModeTypeEnum) => {
        setIsSplitSelectClicked(true);

        if (isPhoneInputEnabled && !isValidPhoneNumber) {
            return;
        }

        setDrawerOpen(false);

        setTimeout(() => {
            onPushEvent('select_split', {
                ...ga,
                splitMode: mode,
            });
            setHasSelectedSplitMode(true);
            setSplitMode(mode);
        }, 300);

        setTimeout(() => {
            setDrawerOpen(true);
        }, 500);
    };

    const removeSplitHandler = () => {
        setIsSplitSelectClicked(false);
        setFormattedPhoneNumber('');
        setIsValidPhoneNumber(false);

        return callSetAmount(
            isPartiallyPaid ? invoiceDetails.billSplit?.mode || SplitModeTypeEnum.unknown : SplitModeTypeEnum.unknown,
            undefined,
            {
                options: {
                    totalShares: 0,
                    yourShares: 0,
                    items: [],
                },
            },
        )
            .then(() => {
                if (!isPartiallyPaid) {
                    setHasSelectedSplitMode(false);
                    setSplitMode(undefined);
                    setIsSplit(false);
                }
                onPushEvent('remove_split', {
                    ...ga,
                    splitMode: invoiceDetails.yourSplitSettings.billSplit.splitMode,
                });
            })
            .finally(() => {
                setDrawerOpen(false);
            });
    };

    const splitHandler =
        (mode: SplitModeTypeEnum) =>
        (amount: number, options?: ISplitOptions, draft?: boolean): Promise<any> | undefined => {
            return callSetAmount(mode, amount, {
                options,
                mobileNo: formattedPhoneNumber,
                draft,
            }).then((response) => {
                setDetails(cloneDeep(response.paymentDetails));
                if (draft) {
                    return;
                }

                setDrawerOpen(false);
                setIsSplit(true);

                onSetAmount(response.paymentDetails);
                dispatchThirdPartyTriggers();

                if (response.error?.items === 'ILLEGAL_SPLIT_MODE') {
                    enqueueSnackbar(t('Your bill has been already split by another party, Please try to split again'), {
                        variant: 'error',
                    });
                } else if (
                    response.error?.items === 'PAYMENT_AMOUNT_IS_TOO_LARGE' &&
                    response.paymentDetails?.billNumber?.remaining === 0
                ) {
                    enqueueSnackbar(t('Your bill is fully paid by another party'), { variant: 'error' });
                }

                if (hasActiveCampaign && vendor?.config.disableSplitWithPromo) {
                    triggerAlternateSnackBar(
                        <span
                            style={{
                                display: 'flow',
                            }}
                        >
                            <strong>{`${t('Remember')}, `}</strong>
                            {t('a promo code cannot be applied if the bill is split')}
                        </span>,
                        <DiscountFilledIcon color={theme.qlub.palette.iris.main} />,
                    );
                }

                setTimeout(() => {
                    onScrollToElement('split');
                }, 200);

                dispatchGA(mode, amount, options);
            });
        };

    const payFullBillHandler = (preventFullPayment?: boolean) => {
        if (!invoiceDetails) {
            return;
        }

        onScrollToElement('payment');

        if (preventFullPayment) {
            return;
        }

        callSetAmount(
            isPartiallyPaid ? SplitModeTypeEnum.custom : SplitModeTypeEnum.unknown,
            Number(invoiceDetails.billNumber.remaining.toFixed(invoiceDetails.currencyPrecision || 0)),
            { mobileNo: isPhoneInputEnabled ? formattedPhoneNumber : undefined },
        ).then((response) => {
            setIsSplit(isPartiallyPaid);

            onSetAmount(response.paymentDetails);
            dispatchThirdPartyTriggers();
        });
    };

    const getContent = () => {
        if (!hasSelectedSplitMode) {
            return (
                <div className={styles.drawer}>
                    <SplitHeader
                        title={t('Split the bill')}
                        subTitle={t('You can pay for your share by selecting one of the options shown below')}
                        onClose={toggleDrawerHandler(false)}
                        margin="over"
                    />
                    {isPhoneInputEnabled && (
                        <SplitPhoneInput
                            isSplitSelectClicked={isSplitSelectClicked}
                            onPhoneChange={(formattedNumber?: string) => {
                                setFormattedPhoneNumber(formattedNumber || '');
                            }}
                            onValidation={(isValid: boolean) => {
                                setIsValidPhoneNumber(isValid);
                            }}
                            splitUIVersion={splitUIVersion}
                        />
                    )}
                    <div>
                        {splitModes.map((item, idx) => (
                            <SplitSelect
                                key={item.mode}
                                mode={item.mode}
                                title={item.title}
                                qaTitleId={item.qaTitleId}
                                buttonTitle={t('select')}
                                active={!!item.active}
                                onClick={() => selectModeHandler(item.mode)}
                                divider={splitModes.length - 1 !== idx}
                                version={splitUIVersion}
                            />
                        ))}
                    </div>
                </div>
            );
        }

        switch (splitMode) {
            case SplitModeTypeEnum.byItem:
                return (
                    <SplitByItem
                        onRemoveSplit={removeSplitHandler}
                        details={details}
                        inclusiveChargesMessage={inclusiveChargesMessage}
                        onSelect={splitHandler(SplitModeTypeEnum.byItem)}
                        ga={ga}
                        currencyFormat={currencyFormat}
                        draftAPILoading={draftAPILoading}
                    />
                );
            case SplitModeTypeEnum.byShare:
                return (
                    <SplitByShare
                        onRemoveSplit={removeSplitHandler}
                        closeDrawer={toggleDrawerHandler(false)}
                        details={details}
                        vendor={vendor}
                        inclusiveChargesMessage={inclusiveChargesMessage}
                        onShareCountChange={splitHandler(SplitModeTypeEnum.byShare)}
                        ga={ga}
                        currencyFormat={currencyFormat}
                        draftAPILoading={draftAPILoading}
                    />
                );
            case SplitModeTypeEnum.custom:
                return (
                    <SplitByCustom
                        onRemoveSplit={removeSplitHandler}
                        isSplit={isSplit}
                        details={details}
                        vendor={vendor}
                        inclusiveChargesMessage={inclusiveChargesMessage}
                        remoteCommissionCalc={
                            (vendor?.config?.splitRealTimeFeeCalculation || config?.splitRealTimeFeeCalculation) ===
                            SplitRealTimeFeeCalcModeEnum.Enabled
                        }
                        closeDrawer={toggleDrawerHandler(false)}
                        onShareChange={splitHandler(SplitModeTypeEnum.custom)}
                        currencyFormat={currencyFormat}
                    />
                );
            default:
                return null;
        }
    };

    return (
        <>
            <SplitAnchor
                details={invoiceDetails}
                isSplit={isSplit}
                onSplit={toggleDrawerHandler(true)}
                onPayFullBill={payFullBillHandler}
                onScrollToElement={onScrollToElement}
                ga={ga}
                currencyFormat={currencyFormat}
                loyalty={loyalty}
            />
            <Drawer
                splitMode={splitMode}
                hasSelectedSplitMode={hasSelectedSplitMode}
                isOpen={drawerOpen}
                onOpenChange={toggleDrawerHandler}
            >
                {getContent()}
            </Drawer>
        </>
    );
};

export default SplitMode;
