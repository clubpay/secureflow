import React, { FC, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Form, Formik, FormikConfig } from 'formik';
import * as Yup from 'yup';
import { clone, debounce } from 'lodash';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { faToEn, isValidNumber } from '@clubpay/customer-common-module/src/utility/localize';
import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor';
import { InputAdornment, TextField } from '@mui/material';
import SplitButtons from '@/components/Split/modes/components/btns/confirm';
import { TotalPrice, CustomerGrid, CustomerContainer, PriceItem, Divider, SplitPriceLabel } from '@qlub-dev/qlub-kit';
import BillAPIManager, { IPaymentDetails } from '@/repositories/bill';
import { getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { ISplitOptions } from '@/views/Bill/Invoice/types';
import { trimMaxAmount } from '../../utils';
import useGetPaymentProcessingFeeLabel from '../../hooks/payment-processing-fee-txt';

import styles from './index.module.scss';

interface IProps {
    vendor: IRestaurant | undefined;
    details: IPaymentDetails;
    inclusiveChargesMessage: string;
    lang?: string | null;
    closeDrawer: () => void;
    onRemoveSplit: () => Promise<any> | undefined;
    onShareChange: (amount: number, options?: ISplitOptions, draft?: boolean) => Promise<any> | undefined;
    defaultName?: string;
    isSplit: boolean;
    remoteCommissionCalc?: boolean;
    currencyFormat: CurrencyFormat;
}

const SplitByCustom: FC<IProps> = ({
    onRemoveSplit,
    onShareChange,
    details,
    vendor,
    isSplit,
    remoteCommissionCalc,
    inclusiveChargesMessage,
    currencyFormat,
}) => {
    const { t } = useTranslation('common');

    const [initialValues, setInitialValues] = useState<any>({
        amount: '0',
    });
    const [loading, setLoading] = useState(false);
    const [remoteLoading, setRemoteLoading] = useState(false);
    const [commission, setCommission] = useState(0);
    const [removeSplitLoading, setRemoveSplitLoading] = useState(false);
    const [myShare, setMyShare] = useState(
        isSplit
            ? remoteCommissionCalc
                ? sumAmounts(
                      details.currencyPrecision,
                      details.billNumber.yourShare,
                      -details.billNumber.yourCommission,
                  )
                : details.billNumber.yourShare
            : 0,
    );

    const { currencyPrecision } = details;

    const defaultAmount = details.billNumber.total;

    const maxAmount = Number(
        (remoteCommissionCalc
            ? details.billNumber.remaining - details.billNumber.remainingCommission
            : details.billNumber.remaining
        ).toFixed(currencyPrecision),
    );

    const currencySymbol = vendor?.country.currencySymbol || '';

    const ref: any = useRef();
    const [focused, setFocused] = useState(false);
    const amountRef = useRef(defaultAmount);
    const unfilteredAmountRef = useRef<any>(defaultAmount);

    const paymentProcessingFeeText = useGetPaymentProcessingFeeLabel({
        odf: details?.bill?.optionalDinerFee,
        billItems: details?._billItems,
    });

    useEffect(() => {
        if (!focused) {
            const d = {
                amount: isSplit ? details.bill.yourShare : '',
            };
            setInitialValues(clone(d));
        }
    }, [defaultAmount]);

    const priceData: PriceItem[] = useMemo(
        () => [
            {
                label: SplitPriceLabel.qlubDiscount,
                value: details.billNumber.qlubDiscount,
                text: t('Qlub Discount'),
            },
            ...(!remoteCommissionCalc && myShare
                ? [
                      {
                          label: SplitPriceLabel.leftToPay,
                          value: details.billNumber.remaining,
                          text: t('Left To Pay'),
                          qaTextId: 'in-split-left-to-pay',
                      },
                  ]
                : []),
            {
                label: SplitPriceLabel.yourShare,
                value: myShare,
                text: t('Your share'),
                qaTextId: 'in-split-your-share',
            },
            ...(remoteCommissionCalc && commission && myShare
                ? [
                      {
                          label: SplitPriceLabel.subTotal,
                          value: commission,
                          text: paymentProcessingFeeText,
                      },
                      {
                          label: SplitPriceLabel.payableAmount,
                          value: myShare + commission,
                          text: t('You pay'),
                      },
                  ]
                : []),
        ],
        [details, myShare, t, commission, details.billNumber.qlubDiscount, details.billNumber.remaining],
    );

    const splitFormSchema = useMemo(
        () =>
            Yup.object().shape({
                name: Yup.string(),
                amount: Yup.number().max(maxAmount),
            }),
        [maxAmount],
    );

    type SplitFormSchema = Yup.InferType<typeof splitFormSchema>;

    const formSubmitHandler: FormikConfig<SplitFormSchema>['onSubmit'] = (values) => {
        const amount = (values.amount as any) === '' ? 0 : parseFloat(faToEn(values.amount as any));
        if (ref.current) {
            const dec = 10 ** (currencyPrecision || 2);
            ref.current.setFieldValue('amount', Math.round(amount * dec) / dec);
        }
    };

    const inputChangeHandler = (e: any, setFieldValue: any) => {
        const val = e.target.value;
        unfilteredAmountRef.current = val;
        let trimmedVal: string | number = val === '' ? '0' : trimMaxAmount(val, maxAmount);
        amountRef.current = parseFloat(trimmedVal);
        const dec = 10 ** (currencyPrecision || 2);
        trimmedVal = Math.round(Number(trimmedVal) * dec) / dec;
        setFieldValue('amount', trimmedVal);
        setMyShare(Number(trimmedVal));
    };

    const debounceMyShareChange = useCallback(
        debounce((amount) => {
            BillAPIManager.getInstance()
                .calculateCommission({
                    country: vendor?.country.code || '',
                    restaurantUnique: vendor?.unique || '',
                    dsi: details.diningSessionID,
                    id: getSession(),
                    amount,
                })
                .then((res) => {
                    setCommission(Number(res.customerCommission));
                })
                .finally(() => {
                    setRemoteLoading(false);
                });
        }, 500),
        [details],
    );

    useEffect(() => {
        if (!remoteCommissionCalc) {
            return;
        }
        if (!myShare) {
            setCommission(0);
            return;
        }
        setRemoteLoading(true);
        debounceMyShareChange(myShare);
    }, [myShare]);

    const payHandler = () => {
        setLoading(true);
        onShareChange(remoteCommissionCalc ? myShare + commission : myShare)?.then(() => {
            setLoading(false);
        });
    };

    const removeSplitHandler = () => {
        setRemoveSplitLoading(true);
        onRemoveSplit()?.finally(() => {
            setRemoveSplitLoading(false);
        });
    };

    return (
        <>
            <div className={styles.mainContainer}>
                <div className={styles.drawerContent}>
                    <Formik
                        innerRef={ref}
                        initialValues={initialValues}
                        onSubmit={formSubmitHandler}
                        validationSchema={splitFormSchema}
                        validateOnMount={false}
                        validateOnBlur={false}
                        enableReinitialize
                    >
                        {({ handleBlur, errors, setFieldValue }): JSX.Element => {
                            const unfilteredNumber = faToEn(unfilteredAmountRef.current);

                            return (
                                <Form>
                                    <CustomerGrid container>
                                        <TextField
                                            color="primary"
                                            className={styles.amount}
                                            required
                                            id="fullWidth"
                                            fullWidth
                                            onChange={(e) => inputChangeHandler(e, setFieldValue)}
                                            onBlur={(e) => {
                                                setFocused(false);
                                                handleBlur(e);
                                            }}
                                            onFocus={() => {
                                                setFocused(true);
                                            }}
                                            placeholder="00.00"
                                            name="amount"
                                            autoCorrect="off"
                                            type="text"
                                            autoComplete="off"
                                            InputProps={{
                                                startAdornment: (
                                                    <InputAdornment position="start" className={styles.prefix}>
                                                        {currencySymbol}
                                                    </InputAdornment>
                                                ),
                                                inputProps: {
                                                    max: maxAmount,
                                                    inputMode: 'decimal',
                                                },
                                            }}
                                            value={
                                                focused &&
                                                currencyPrecision > 0 &&
                                                unfilteredNumber !== '00' &&
                                                isValidNumber(unfilteredNumber) &&
                                                unfilteredNumber.split('.')[1]?.length - 1 < currencyPrecision &&
                                                (unfilteredNumber as any) <= maxAmount
                                                    ? undefined
                                                    : myShare
                                            }
                                            error={!!errors.amount}
                                            helperText={errors.amount}
                                        />
                                    </CustomerGrid>
                                </Form>
                            );
                        }}
                    </Formik>
                </div>
            </div>
            <div className={styles.footer}>
                <Divider type="fullWidth" />
                <CustomerContainer padding="1rem 1.5rem">
                    <TotalPrice
                        priceData={priceData}
                        currencyFormat={{
                            ...currencyFormat,
                            currencyPrecision: details.currencyPrecision || currencyFormat?.currencyPrecision,
                        }}
                        footerText={
                            remoteCommissionCalc && !myShare
                                ? t('Additional fees may be applied')
                                : inclusiveChargesMessage
                        }
                        loading={remoteLoading}
                        qaFooterTextId="in-split-info"
                    />
                    <SplitButtons
                        onPay={payHandler}
                        onRemoveSplit={removeSplitHandler}
                        myShare={myShare}
                        loading={loading}
                        removeSplitLoading={removeSplitLoading}
                    />
                </CustomerContainer>
            </div>
        </>
    );
};
export default SplitByCustom;
