import { SplitModeTypeEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';

export interface ISplitOptionQA {
    qaTitleId?: string;
}

export interface ISplitOption extends ISplitOptionQA {
    title: string;
    buttonTitle: string;
    mode: SplitModeTypeEnum;
    active?: boolean;
}
