import { IExplodedItemView, IItemToPay, IPaymentDetails } from '@/repositories/bill/types';
import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor/type';
import { extractFloatNumbers } from '@clubpay/customer-common-module/src/utility/localize';
import { ceil } from 'lodash';

export const isSplitActive = (vendor: IRestaurant | undefined, isQSR: boolean) => {
    if (!vendor || (isQSR && !vendor?.orderConfig?.splitEnable)) {
        return false;
    }

    return true;
};

export const convertExplodedItemToPaidItem = (eItem: IExplodedItemView): IItemToPay => {
    return {
        id: eItem.item?.id || '',
        index: eItem.index,
        qty: eItem.qty,
        sig: eItem?.sig || '',
    };
};

export const trimMaxAmount = (val: any, maxAmount: number) => {
    let a = extractFloatNumbers(val);
    // remove twice dots
    if (a.indexOf('.') !== a.lastIndexOf('.')) {
        a = a.substring(0, a.lastIndexOf('.'));
    }
    return String(Math.min(isNaN(a as any) ? 0 : parseFloat(a), maxAmount));
};

export const calculateSplitByItemTotal = (selectedItems: IExplodedItemView[]) => {
    return selectedItems.reduce<number>((acc, cur) => {
        return acc + Number(cur.adjustedFinalPrice);
    }, 0);
};

export const filterSelectedItems = (
    prevSelection: IExplodedItemView[],
    paidItems?: Map<string, IExplodedItemView>,
    confirmedSelectedItems?: IExplodedItemView[],
) => {
    if (!paidItems && confirmedSelectedItems?.length === 0) return prevSelection;

    // Find items selected by you + prev selection. Reduce to a map to remove duplicates.
    const allSelectedItemsMap = [...prevSelection, ...(confirmedSelectedItems || [])].reduce(
        (acc, item) => {
            acc.map.set(item.key, item);
            return acc;
        },
        { map: new Map() },
    );

    const allSelectedItems = Array.from(allSelectedItemsMap.map.values());

    // remove paid items
    const remainingItems = allSelectedItems.filter((item) => {
        return !paidItems?.has(item.key);
    });

    return [...remainingItems];
};

export const calculateSplitByItemPaymentProcessingFee = (selectedItems: IExplodedItemView[]) => {
    return selectedItems?.reduce(
        (acc, cur) => acc + (Number(cur.adjustedFinalPrice) - Number(cur.adjustedFinalNetPrice)),
        0,
    );
};

export const calculateSplitByItemNetSubtotal = (selectedItems: IExplodedItemView[]) => {
    return selectedItems?.reduce((acc, cur) => acc + Number(cur.adjustedFinalNetPrice), 0);
};

export const calculateSplitByShareAmountV1 = (details: IPaymentDetails, yourShares: number, totalShares: number) => {
    const newAmount = ceil(details.billNumber.total * (yourShares / totalShares), details.currencyPrecision);
    return +Math.min(details.billNumber.remaining, newAmount).toFixed(details.currencyPrecision || 0);
};

export const calculateSplitByShareAmountV2 = (details: IPaymentDetails, yourShares: number, totalShares: number) => {
    const sharePrice = ceil(
        details.billNumber.remaining / (totalShares - (details?.billSplit?.paidShares || 0)),
        details.currencyPrecision,
    );

    const amount = ceil(sharePrice * yourShares, details.currencyPrecision);

    return +Math.min(details.billNumber.remaining, amount).toFixed(details.currencyPrecision || 0);
};
