import React, { FC, ReactElement } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Paper } from '@mui/material';
import { Button, Divider, PriceItem, SplitPriceLabel, TotalPrice } from '@qlub-dev/qlub-kit';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import useElemObserver from '@/hooks/elemObserver';
import { IPaymentDetails } from '@/repositories/bill';
import { useGetInclusiveChargesMessage } from '@/hooks/getInclusiveChargesMessage';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';

import styles from './index.module.scss';

interface ISplitItem {
    priceData: PriceItem[];
    footer: any;
    firstButton: any;
    secondButton: any;
}

interface IProps {
    details: IPaymentDetails;
    ga: Record<string, unknown>;
    onScrollToElement: (element: 'invoice' | 'payment' | 'split') => void;
    currencyFormat: CurrencyFormat;
    loyalty?: ReactElement;
}

const NoSplitAnchor: FC<IProps> = ({ details, ga, onScrollToElement, currencyFormat, loyalty }) => {
    const { t } = useTranslation('common');
    const { show: showBill } = useElemObserver({ selector: '#invoiceElement', threshold: 0.25, hysteresis: 0.25 });
    const { inclusiveChargesMessage } = useGetInclusiveChargesMessage({});

    const splitData: ISplitItem = {
        priceData: [
            {
                label: SplitPriceLabel.yourShare,
                value: details.billNumber.yourShare,
                text: t('Payable amount'),
                qaTextId: 'billing-payable-amount',
            },
        ],
        footer: inclusiveChargesMessage,
        firstButton: '',
        secondButton: '',
    };

    const showBillHandler = () => {
        if (showBill) {
            onScrollToElement('invoice');
            onPushEvent('pay_the_rest', {
                ...ga,
                splitMode: details.billSplit?.mode,
            });
        } else {
            onScrollToElement('payment');
        }
    };

    return (
        <Paper elevation={0} className={styles.anchor}>
            <div className={styles.fullWidth}>
                <div className={styles.container}>
                    <Divider type="fullWidth" />
                </div>

                {loyalty}

                <div className={styles.actions}>
                    <TotalPrice
                        priceData={splitData.priceData}
                        footerText={splitData.footer}
                        currencyFormat={{
                            ...currencyFormat,
                            currencyPrecision: details?.currencyPrecision || currencyFormat?.currencyPrecision,
                        }}
                    />
                    <Button
                        variant={showBill ? 'outlined' : 'contained'}
                        size="large"
                        type="submit"
                        id="pay-full-bill"
                        fullWidth
                        disabled={details.yourSplitSettings.paymentDone}
                        onClick={showBillHandler}
                        sx={{
                            transition: 'all .5s ease',
                        }}
                    >
                        {showBill ? t('View bill') : t('Pay full bill')}
                    </Button>
                </div>
            </div>
        </Paper>
    );
};

export default NoSplitAnchor;
