import useODFAvailabilityCheck from '@/hooks/odf-availability';
import { useBillItemTranslation } from '@/components/Bill/InvoiceItem/hooks/translations_hook';
import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IKeyValue } from '@qlub-dev/qlub-kit/dist/types/InvoiceItemTypes';

interface IProps {
    odf: string;
    billItems?: IKeyValue[];
}

const useGetPaymentProcessingFeeLabel = ({ odf, billItems }: IProps) => {
    const { vendor } = useVendor();
    const { lang } = useQlubRouter();
    const { t } = useTranslation();
    const { getTrans } = useBillItemTranslation(lang);

    const isODFAvaialble = useODFAvailabilityCheck({ odf });

    if (isODFAvaialble) {
        return getLocaleText(vendor?.config.commissionOptionalDinerFeeLabel || '', lang, '') || t('Fast checkout fees');
    }

    // TODO: clean this
    const qdf = billItems?.find((item) => item?.key?.startsWith('com_exclusive'));
    const qdfVal = Number(qdf?.value);

    if (qdf && qdfVal) {
        return getTrans(qdf.key, qdf.title, qdf.layout?.locales, qdf.layout?.useTitle);
    }

    return t('Payment processing fee');
};

export default useGetPaymentProcessingFeeLabel;
