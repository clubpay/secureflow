import { useCallback, useRef, useState } from 'react';
import debounce from 'lodash/debounce';
import BillAPIManager, { IPaymentDetails } from '@/repositories/bill';
import { SplitModeTypeEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';
import { getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { ISplitOptions } from '@/views/Bill/Invoice/types';

class SupersededCallError extends Error {
    constructor() {
        super('Superseded by newer call');
        this.name = 'SupersededCallError';
    }
}

type SetAmountType = (
    mode: SplitModeTypeEnum,
    amount?: number,
    options?: IOptions,
) => Promise<{
    paymentDetails: IPaymentDetails;
    error: any;
}>;

interface IOptions {
    options?: ISplitOptions;
    mobileNo?: string;
    draft?: boolean;
}

interface IProps {
    details: IPaymentDetails;
}

const useSetAmount = ({ details }: IProps) => {
    const [isDraftLoading, setIsDraftLoading] = useState(false);
    const { vendor } = useVendor();

    // to avoid stale closures
    const detailsRef = useRef(details);
    detailsRef.current = details;

    // track the latest API call
    const latestCallIdRef = useRef(0);

    const setAmount: SetAmountType = useCallback(
        (mode, amount, options) => {
            const currentDetails = detailsRef.current;

            if (
                !currentDetails ||
                currentDetails.billNumber.remaining === 0 ||
                currentDetails.yourSplitSettings.paymentDone
            ) {
                return Promise.reject(new Error('wrong inputs'));
            }

            const phoneNumber = options?.mobileNo?.trim() ?? '';

            if (options?.draft) {
                setIsDraftLoading(true);
            }

            // generate a unique ID for current call
            const callId = ++latestCallIdRef.current;

            return BillAPIManager.getInstance()
                .setAmount(
                    {
                        amount: amount
                            ? Math.min(currentDetails.billNumber.remaining, amount).toFixed(
                                  currentDetails.currencyPrecision || 0,
                              )
                            : undefined,
                        diningSessionID: currentDetails.diningSessionID,
                        name: '',
                        phoneNumber,
                        id: getSession(),
                        splitMode: mode,
                        items: options?.options?.items,
                        share: options?.options?.yourShares || 0,
                        totalShares: options?.options?.totalShares || 0,
                    },
                    {
                        cc: vendor?.country.code || 'en',
                        vendor,
                        draft: options?.draft,
                    },
                )
                .then((response) => {
                    if (callId === latestCallIdRef.current) {
                        return response;
                    }
                    // Cancel this response since a newer call has been made
                    throw new SupersededCallError();
                })
                .finally(() => {
                    if (options?.draft && callId === latestCallIdRef.current) {
                        setIsDraftLoading(false);
                    }
                });
        },
        [vendor],
    );

    const debouncedSetAmountRef = useRef<any>(null);

    if (!debouncedSetAmountRef.current) {
        debouncedSetAmountRef.current = debounce((args, resolve, reject) => {
            const { mode, amount, options } = args;

            setAmount(mode, amount, options)
                .then(resolve)
                .catch((error) => {
                    // Silently ignore superseded calls
                    if (error instanceof SupersededCallError) {
                        // Resolve with the last known valid data
                        resolve({
                            paymentDetails: detailsRef.current,
                            error: null,
                        });
                    } else {
                        // return other errors
                        reject(error);
                    }
                });
        }, 300);
    }

    const callSetAmount: SetAmountType = useCallback(
        (mode, amount, options) => {
            // for non-draft calls, cancel any pending debounced calls and call immediately
            if (!options?.draft) {
                debouncedSetAmountRef.current.cancel();

                return setAmount(mode, amount, options).catch((error) => {
                    // ignore superseded calls silently
                    if (error instanceof SupersededCallError) {
                        return {
                            paymentDetails: detailsRef.current,
                            error: null,
                        };
                    }
                    throw error;
                });
            }

            // debounce draft calls
            return new Promise((resolve, reject) => {
                // cancel any pending debounced calls before making a new one
                debouncedSetAmountRef.current.cancel();

                // make a new debounced call
                debouncedSetAmountRef.current({ mode, amount, options }, resolve, reject);
            });
        },
        [setAmount],
    );

    return {
        callSetAmount,
        draftAPILoading: isDraftLoading,
    };
};

export default useSetAmount;
