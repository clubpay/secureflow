import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

const useSplitConflictAlertMsg = (conflictedItemCount: number) => {
    const { t } = useTranslation();

    let msg = '';

    switch (conflictedItemCount) {
        case 1:
            msg = t('1 item you selected has been paid by someone else');
            break;
        case -1:
            msg = t('All of the items you selected have been paid by someone else');
            break;
        default:
            msg = t('{{conflictCount}} items you selected have been paid by someone else', {
                conflictCount: conflictedItemCount,
            });
    }

    return {
        conflictAlertMsg: msg,
    };
};

export default useSplitConflictAlertMsg;
