import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { SplitModeTypeEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';
import { useMemo } from 'react';
import { ISplitOption } from '../types';

interface IProps {
    availableModes?: SplitModeTypeEnum[];
}

const useGetAvailableSplitModes = ({ availableModes }: IProps) => {
    const { vendor } = useVendor();
    const { config } = useConfigContext();
    const { t } = useTranslation('common');

    const splitOptions = useMemo<SplitModeTypeEnum[]>(() => {
        if (vendor?.config?.splitOptions && vendor.config.splitOptions.length > 0) {
            return vendor.config.splitOptions;
        }

        if (config?.splitOptions && config?.splitOptions.length > 0) {
            return config?.splitOptions;
        }

        return [SplitModeTypeEnum.byItem, SplitModeTypeEnum.byShare, SplitModeTypeEnum.custom];
    }, [config, vendor]);

    const btnTitle = t('select');

    const list: ISplitOption[] = [
        {
            title: t('Pay for your items'),
            buttonTitle: btnTitle,
            mode: SplitModeTypeEnum.byItem,
            active: false,
            qaTitleId: 'split-modal-by-item',
        },
        {
            title: t('Divide the bill equally'),
            buttonTitle: btnTitle,
            mode: SplitModeTypeEnum.byShare,
            active: false,
            qaTitleId: 'split-modal-by-share',
        },
        {
            title: t('Pay a custom amount'),
            buttonTitle: btnTitle,
            mode: SplitModeTypeEnum.custom,
            active: false,
            qaTitleId: 'split-modal-custom',
        },
    ];

    const filteredSplitOptions = useMemo(
        () =>
            splitOptions.reduce<ISplitOption[]>((a, b) => {
                const splitMode = list.find((o) => o.mode === b);

                if (splitMode) {
                    splitMode.active = availableModes?.some((mode: string) => mode === splitMode.mode);

                    if (splitMode.active) {
                        a.push(splitMode);
                    }
                }

                return a;
            }, []),
        [availableModes, t, list, splitOptions],
    );

    return {
        splitModes: filteredSplitOptions,
    };
};

export default useGetAvailableSplitModes;
