import React, { FC, MutableRefObject, ReactElement, RefObject, useMemo } from 'react';
import { SplitModeEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import NoSplitAnchor from '@/components/Split/no-split-anchor';
import SplitMode from '@/components/Split/modes';
import { getDiningSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import { IURLTopology } from '@clubpay/customer-common-module/src/hook/router';
import { IPaymentDetails } from '@/repositories/bill';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { isSplitActive } from './utils';
import { TipToggleFunc } from '../Tip/normal/types';
import { ISmartTipModalHandler } from '../Tip/smart';

interface IProps {
    details: IPaymentDetails;
    isQSR: boolean;
    url: IURLTopology;
    billUpdateTriggered: number;
    onScrollToElement: (element: 'invoice' | 'payment' | 'split') => void;
    onSplitChangeHandler: (enable: boolean) => void;
    onSetAmount: (data: IPaymentDetails) => void;
    onTipModalOpenRef?: MutableRefObject<TipToggleFunc | undefined>;
    smartTipModalHandlerRef?: RefObject<ISmartTipModalHandler>;
    currencyFormat: CurrencyFormat;
    loyalty?: ReactElement;
}

const SplitSection: FC<IProps> = ({
    details,
    isQSR,
    url,
    billUpdateTriggered,
    onScrollToElement,
    onSplitChangeHandler,
    onSetAmount,
    onTipModalOpenRef,
    smartTipModalHandlerRef,
    currencyFormat,
    loyalty,
}) => {
    const { vendor } = useVendor();
    const { config } = useConfigContext();

    const ga = useMemo(() => {
        const discount = vendor?.discount || 0;
        const billAmount = details?.bill?.total || 0;

        return {
            table_param: `${url.id}/${url.f1}/${url.f2}`,
            country_code: url.cc,
            has_active_discount: discount ? 'yes' : 'no',
            bill_amount: billAmount,
            restaurant_name: vendor?.title,
            opsMode: vendor?.opsMode,
            splitType: vendor?.config.splitMode || config?.splitMode,
            diningSessionId: getDiningSession(url)?.id,
            pg_name: vendor?.availablePGs,
        };
    }, [vendor, details]);

    if (!vendor || !isSplitActive(vendor, isQSR)) {
        return null;
    }

    switch (vendor.config.splitMode || config?.splitMode) {
        case SplitModeEnum.Disabled:
            return (
                <NoSplitAnchor
                    onScrollToElement={onScrollToElement}
                    ga={ga}
                    details={details}
                    currencyFormat={currencyFormat}
                    loyalty={loyalty}
                />
            );
        default:
        case SplitModeEnum.Legacy || SplitModeEnum.New:
            return (
                <SplitMode
                    key="new-split"
                    onScrollToElement={onScrollToElement}
                    details={details}
                    ga={ga}
                    onSplitChange={onSplitChangeHandler}
                    onSetAmount={onSetAmount}
                    billUpdateTriggered={billUpdateTriggered}
                    onTipModalOpenRef={onTipModalOpenRef}
                    smartTipModalHandlerRef={smartTipModalHandlerRef}
                    currencyFormat={currencyFormat}
                    loyalty={loyalty}
                />
            );
    }
};

export default SplitSection;
