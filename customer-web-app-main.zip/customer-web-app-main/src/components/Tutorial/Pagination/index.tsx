import { useMemo, CSSProperties } from 'react';
import { StackElements } from '@qlub-dev/qlub-kit/dist/components/StackElements';
import { Button } from '@qlub-dev/qlub-kit';
import classNames from 'classnames';
import { useTheme } from '@mui/material';
import { QlubTheme } from '@qlub-dev/qlub-kit/dist/theme/types';
import { reduceOpacity } from '@/services/utils/color_manipulate';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { qlubLocalStorage } from '@clubpay/customer-common-module/src/service/storage/localStorage';
import { HexColor, IPaginationLine } from './types';

import styles from './index.module.scss';

const Pagination: React.FC<IPaginationLine> = ({
    totalPages,
    currentPage,
    lineGap = 8,
    lineWidth = 24,
    lineHeight = 4,
    minScale,
    maxScale,
    themeColor,
    onPageChange,
    svgOverrides,
    buttonParams,
    handelTutorialDrawer,
}) => {
    const theme = useTheme<QlubTheme>();
    const { t } = useTranslation('common');

    const { adjustedLineWidth, adjustedGap } = useMemo(() => {
        const gap = totalPages > 10 ? 4 : totalPages > 6 ? 6 : lineGap;
        const width = totalPages > 10 ? 16 : totalPages > 6 ? 20 : lineWidth;
        return { adjustedLineWidth: width, adjustedGap: gap };
    }, [totalPages, lineGap, lineWidth]);

    const totalWidth = totalPages * adjustedLineWidth + (totalPages - 1) * adjustedGap;
    const selectedLinePosition = currentPage * (adjustedLineWidth + adjustedGap);
    const backButtonColor = reduceOpacity({ hex: buttonParams.backButtonColor as HexColor, opacity: 0.2 });
    const buttonConfigs = useMemo(() => {
        return [
            {
                type: 'back',
                text: buttonParams.backButtonText,
                textColor: theme.qlub.palette.iris.main,
                color: backButtonColor,
                disabled: currentPage === 0,
                isDone: false,
            },
            {
                type: 'next',
                text: buttonParams.nextButtonText,
                textColor: theme.palette.common.white,
                color: buttonParams.nextButtonColor,
                disabled: currentPage === totalPages - 1,
                isDone: currentPage === totalPages - 1,
            },
        ] as const;
    }, [buttonParams, currentPage, totalPages]);

    const handlePageChange = (page: number) => {
        if (page >= 0 && page < totalPages) {
            onPageChange?.(page);
        }
    };

    return (
        <StackElements
            alignItems="center"
            justifyContent="center"
            direction="column"
            spacing={6}
            className={classNames(styles.container, {
                [styles.containerMinScale]: minScale,
                [styles.containerMaxScale]: maxScale,
            })}
            style={
                {
                    '--min-scale': minScale ? `${minScale}rem` : 'auto',
                    '--max-scale': maxScale ? `${maxScale}rem` : 'auto',
                } as CSSProperties
            }
        >
            <svg
                width="100%"
                height={lineHeight}
                viewBox={`0 0 ${totalWidth} ${lineHeight}`}
                className={classNames(styles.svg, {
                    svgOverrides,
                })}
                role="img"
                aria-label={`Page ${currentPage + 1} of ${totalPages}`}
            >
                {Array.from({ length: totalPages }, (_, index) => (
                    <rect
                        key={index}
                        className={styles.segment}
                        x={index * (adjustedLineWidth + adjustedGap)}
                        y={0}
                        width={adjustedLineWidth}
                        height={lineHeight}
                        rx={lineHeight / 2}
                        onClick={() => {
                            handlePageChange(index);
                        }}
                    />
                ))}

                <rect
                    fill={themeColor}
                    className={styles.highlightedMoving}
                    x={selectedLinePosition}
                    y={0}
                    width={adjustedLineWidth}
                    height={lineHeight}
                    rx={lineHeight / 2}
                />
            </svg>

            <StackElements className={styles.fullWidth} spacing={5} alignItems="center" justifyContent="center">
                {buttonConfigs.map(({ type, text, color, disabled, textColor, isDone }) => {
                    if (text) {
                        return (
                            <Button
                                key={type}
                                variant="contained"
                                fullWidth
                                onClick={() => {
                                    if (isDone) {
                                        qlubLocalStorage.set('tutorialCompleted', true);
                                        handelTutorialDrawer?.(false);
                                    } else if (type === 'next') {
                                        handlePageChange(currentPage + 1);
                                    } else if (type === 'back') {
                                        handlePageChange(currentPage - 1);
                                    }
                                }}
                                disabled={isDone ? false : disabled}
                                className={classNames(styles.navigationButton, {
                                    [styles.disabledButton]: isDone ? false : disabled,
                                })}
                                style={
                                    {
                                        '--button-color': color,
                                        '--text-color': textColor,
                                    } as React.CSSProperties
                                }
                                aria-label={type === 'back' ? 'Previous page' : 'Next page'}
                            >
                                {isDone ? t('Done') : text}
                            </Button>
                        );
                    }
                    return null;
                })}
            </StackElements>
        </StackElements>
    );
};

export default Pagination;
