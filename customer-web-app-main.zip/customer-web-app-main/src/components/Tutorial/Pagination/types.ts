import { CSSProperties } from 'react';

export type HexColor = `#${string}`;

export type IButtonPrams = {
    nextButtonText: string;
    nextButtonColor?: HexColor;
    backButtonText: string;
    backButtonColor?: HexColor;
};

export type IPaginationLine = {
    totalPages: number;
    currentPage: number;
    lineGap?: number;
    lineWidth?: number;
    lineHeight?: number;
    minScale?: number;
    maxScale?: number;
    themeColor?: HexColor;
    onPageChange?: (page: number) => void;
    containerOverrides?: CSSProperties;
    svgOverrides?: CSSProperties;
    controlsOverrides?: CSSProperties;
    buttonParams: IButtonPrams;
    handelTutorialDrawer?: (status: boolean) => void;
};
