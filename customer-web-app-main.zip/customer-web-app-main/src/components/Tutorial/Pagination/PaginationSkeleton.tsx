import { useMemo, CSSProperties } from 'react';
import { StackElements } from '@qlub-dev/qlub-kit/dist/components/StackElements';
import classNames from 'classnames';
import { Skeleton } from '@mui/material';
import styles from './index.module.scss';

interface IPaginationSkeleton {
    isRtl?: boolean;
    currentPage: number;
}

const PaginationSkeleton = ({ isRtl = false, currentPage }: IPaginationSkeleton) => {
    const totalPages = 4;
    const lineGap = 8;
    const lineWidth = 24;
    const lineHeight = 4;

    const { adjustedLineWidth, adjustedGap } = useMemo(() => {
        const gap = totalPages > 10 ? 4 : totalPages > 6 ? 6 : lineGap;
        const width = totalPages > 10 ? 16 : totalPages > 6 ? 20 : lineWidth;
        return { adjustedLineWidth: width, adjustedGap: gap };
    }, []);

    const totalWidth = totalPages * adjustedLineWidth + (totalPages - 1) * adjustedGap;

    return (
        <StackElements
            alignItems="center"
            justifyContent="center"
            direction="column"
            spacing={10}
            className={styles.container}
            style={
                {
                    '--min-scale': 'auto',
                    '--max-scale': 'auto',
                } as CSSProperties
            }
        >
            <svg
                width="100%"
                height={lineHeight}
                viewBox={`0 0 ${totalWidth} ${lineHeight}`}
                className={classNames(styles.svg, {
                    [styles.rtlSvg]: isRtl,
                })}
                role="img"
                aria-label={`Page ${currentPage + 1} of ${totalPages}`}
            >
                {Array.from({ length: totalPages }, (_, index) => (
                    <rect
                        key={index}
                        className={styles.segment}
                        x={index * (adjustedLineWidth + adjustedGap)}
                        y={0}
                        width={adjustedLineWidth}
                        height={lineHeight}
                        rx={lineHeight / 2}
                    />
                ))}
            </svg>

            <StackElements className={styles.fullWidth} spacing={5} alignItems="center" justifyContent="center">
                {Array.from({
                    length: 2,
                }).map(() => {
                    return <Skeleton width="100%" height={70} sx={{ borderRadius: '1rem' }} />;
                })}
            </StackElements>
        </StackElements>
    );
};

export default PaginationSkeleton;
