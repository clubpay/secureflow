import React from 'react';
import { StackElements } from '@qlub-dev/qlub-kit/dist/components/StackElements';
import { Skeleton } from '@mui/material';
import PaginationSkeleton from '../Pagination/PaginationSkeleton';

import styles from './index.module.scss';

const SliderSkeleton = () => {
    const currentPage = 1;
    const isRtl = false;

    return (
        <div className={styles.container}>
            <StackElements direction="column" spacing={0} alignItems="center" justifyContent="center">
                <Skeleton width="100%" height={400} sx={{ borderRadius: '34px' }} />
                <Skeleton width="20%" height={20} />
                <Skeleton width="70%" height={20} />
            </StackElements>

            <PaginationSkeleton isRtl={isRtl} currentPage={currentPage} />
        </div>
    );
};

export default SliderSkeleton;
