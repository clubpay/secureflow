import React, { CSSProperties, useEffect } from 'react';
import { Typography } from '@qlub-dev/qlub-kit';
import { StackElements } from '@qlub-dev/qlub-kit/dist/components/StackElements';
import { useMediaQuery } from '@mui/material';
import classNames from 'classnames';
import useEventsCenter from '@/hooks/eventsCenter';
import Pagination from '../Pagination';
import type { IButtonPrams, HexColor } from '../Pagination/types';

import styles from './index.module.scss';

interface IProps {
    rtl: boolean;
    lang: string;
    imageUrls?: string[];
    titlesAndDescriptions?: { title: string; description: string }[];
    isButtonsAvailable?: boolean;
    currentPage: number;
    handlePageChange: (page: number) => void;
    themeColor?: HexColor;
    totalPages: number;
    buttonParams: IButtonPrams;
    handelTutorialDrawer?: (status: boolean) => void;
}

const Index = ({
    rtl,
    imageUrls,
    titlesAndDescriptions,
    isButtonsAvailable = false,
    currentPage,
    handlePageChange,
    themeColor,
    totalPages,
    buttonParams,
    handelTutorialDrawer,
}: IProps) => {
    const isDesktop = useMediaQuery('(min-width: 429px)');

    const {
        cAppTutorial: { tutorialDisplayed },
    } = useEventsCenter();

    useEffect(() => {
        tutorialDisplayed();
    }, []);

    return (
        <div className={styles.container}>
            <div
                className={classNames(styles.contentContainer, {
                    [styles.contentContainerIsDesktop]: isDesktop,
                })}
            >
                {imageUrls?.length && (
                    <div className={styles.imageSliderContainer}>
                        <div
                            className={styles.imageSlider}
                            style={
                                {
                                    '--rtl-transform': rtl
                                        ? `translateX(${currentPage * 100}%)`
                                        : `translateX(-${currentPage * 100}%)`,
                                } as CSSProperties
                            }
                        >
                            {imageUrls.map((item, i: number) => (
                                <img key={i} src={item} alt={`Slide ${i + 1}`} className={styles.image} />
                            ))}
                        </div>
                    </div>
                )}

                {titlesAndDescriptions?.length && (
                    <div className={styles.descriptionSliderContainer}>
                        <div
                            className={styles.descriptionSlider}
                            style={
                                {
                                    '--rtl-transform': rtl
                                        ? `translateX(${currentPage * 100}%)`
                                        : `translateX(-${currentPage * 100}%)`,
                                } as CSSProperties
                            }
                        >
                            {titlesAndDescriptions?.map((item, i: number) => (
                                <>
                                    <StackElements
                                        key={i}
                                        direction="column"
                                        alignItems="center"
                                        justifyContent="center"
                                        spacing={2}
                                        style={{
                                            minWidth: '100%',
                                        }}
                                    >
                                        <h1 className={styles.title}>{item.title}</h1>
                                        <Typography typo="body_sm" className={styles.description}>
                                            {item.description}
                                        </Typography>
                                    </StackElements>
                                </>
                            ))}
                        </div>
                    </div>
                )}
            </div>

            {isButtonsAvailable && (
                <Pagination
                    lineGap={8}
                    lineWidth={60}
                    lineHeight={5}
                    themeColor={themeColor}
                    totalPages={totalPages}
                    currentPage={currentPage}
                    onPageChange={handlePageChange}
                    buttonParams={buttonParams}
                    handelTutorialDrawer={handelTutorialDrawer}
                />
            )}
        </div>
    );
};

export default Index;
