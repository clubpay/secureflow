import TutorialAPIManager from '@/repositories/tutorial';
import { IContent } from '@/repositories/tutorial/types';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useEffect, useState } from 'react';

const useCheckTutorialAvailability = () => {
    const [tutorial, setTutorial] = useState<IContent | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [isError, setIsError] = useState<boolean>(false);
    const { vendor } = useVendor();

    useEffect(() => {
        setIsLoading(true);

        TutorialAPIManager.getInstance()
            .getTutorial(vendor)
            .then((res) => {
                setTutorial(res);
            })
            .catch((error) => {
                console.error('Tutorial(fetch-types): ', error);
                setIsError(true);
            })
            .finally(() => {
                setIsLoading(false);
            });
    }, []);

    return { tutorial, isLoading, isError };
};

export default useCheckTutorialAvailability;
