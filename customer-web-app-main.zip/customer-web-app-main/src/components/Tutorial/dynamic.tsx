import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { detectRTLFromLang } from '@clubpay/customer-common-module/src/utility/k_lang';
import { SwipeableCustomerDrawer } from '@qlub-dev/qlub-kit';
import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useState } from 'react';
import { Slide } from '@/repositories/tutorial/types';
import useEventsCenter from '@/hooks/eventsCenter';
import { useTheme } from '@mui/material';
import useCheckTutorialAvailability from './useCheckTutorialAvailability';
import Slider from './Slider';
import type { HexColor } from './Pagination/types';

export interface IProps {
    open: boolean;
    handleTutorialDrawer: (value: boolean) => void;
}

const Tutorial = ({ open, handleTutorialDrawer }: IProps) => {
    const [currentPage, setCurrentPage] = useState(0);
    const [tutorialCompleted, setTutorialCompleted] = useState(false);
    const theme = useTheme();
    const { lang } = useQlubRouter();
    const rtl = detectRTLFromLang(lang);
    const { tutorial, isError } = useCheckTutorialAvailability();

    const {
        cAppTutorial: { tutorialSkipped, tutorialComplete },
    } = useEventsCenter();

    const isButtonsAvailable = !!(tutorial?.buttons[0]?.title || tutorial?.buttons[1]?.title);

    const themeColor = (theme.qlub.palette.iris.main as HexColor) || tutorial?.color;
    const totalPages = tutorial?.slides?.length;
    const imageUrls = tutorial?.slides?.map((item: Slide) => getLocaleText(item.media, lang, 'en'));
    const titlesAndDescriptions = tutorial?.slides?.map((item: Slide) => ({
        title: getLocaleText(item.title, lang, 'en'),
        description: getLocaleText(item.description, lang, 'en'),
    }));
    const buttonParams = {
        nextButtonText: getLocaleText(tutorial?.buttons[0]?.title || '', lang, 'en') || 'Next',
        nextButtonColor: (theme.qlub.palette.iris.main as HexColor) || tutorial?.buttons[0]?.color,
        backButtonText: getLocaleText(tutorial?.buttons[1]?.title || '', lang, 'en') || 'Prev',
        backButtonColor: (theme.qlub.palette.iris.main as HexColor) || tutorial?.buttons[1]?.color,
    };

    const handlePageChange = (page: number) => {
        setCurrentPage(page);
        if (totalPages && page && page === totalPages - 1) {
            tutorialComplete();
            setTutorialCompleted(true);
        }
    };

    if (
        !tutorial ||
        !totalPages ||
        (!imageUrls?.length && !titlesAndDescriptions?.length && !isButtonsAvailable) ||
        isError
    ) {
        return <></>;
    }

    return (
        <SwipeableCustomerDrawer
            anchor="bottom"
            open={open}
            headerTitle={getLocaleText(tutorial.title, lang, 'en')}
            onOpen={() => handleTutorialDrawer(true)}
            onClose={() => {
                if (!tutorialCompleted) {
                    tutorialSkipped();
                }
                handleTutorialDrawer(false);
            }}
            mobileWidth
        >
            <Slider
                themeColor={themeColor}
                totalPages={totalPages}
                buttonParams={buttonParams}
                lang={lang}
                rtl={rtl}
                imageUrls={imageUrls}
                titlesAndDescriptions={titlesAndDescriptions}
                isButtonsAvailable={isButtonsAvailable}
                currentPage={currentPage}
                handlePageChange={handlePageChange}
                handelTutorialDrawer={handleTutorialDrawer}
            />
        </SwipeableCustomerDrawer>
    );
};

export default Tutorial;
