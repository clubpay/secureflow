import dynamic from 'next/dynamic';
import type { IProps } from '@/components/Tutorial/dynamic';

const Tutorial = dynamic<IProps>(() => import('@/components/Tutorial/dynamic'));

export default Tutorial;
