import { FC, useCallback, useMemo, useState } from 'react';
import TextField from '@mui/material/TextField';
import { Typography } from '@qlub-dev/qlub-kit';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Collapse from '@mui/material/Collapse';
import { emailTermsAndConditionsType, EnableEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import Link from 'next/link';
import { getAvailableLang } from '@clubpay/customer-common-module/src/utility/k_lang';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import { Form, Formik, FormikConfig } from 'formik';
import * as Yup from 'yup';
import BillAPIManager from '@/repositories/bill';
import { getDiningSession, getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import useEventsCenter from '@/hooks/eventsCenter';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import Button from '@qlub-dev/qlub-kit/dist/components/Button';
import Divider from '@qlub-dev/qlub-kit/dist/components/Divider';
import { saveAs } from 'file-saver';
import Consent from '../Consent';

import styles from './index.module.scss';

interface IProps {
    shouldShowEmailLabel?: boolean;
    email?: string;
    buttonDivider?: boolean;
    submitLabel?: any;
    downloadLabel?: any;
    qsr?: boolean;
    onSubmitting?: (val: boolean) => void;
    onDone?: () => void;
}

const FormContent: FC<IProps> = ({
    shouldShowEmailLabel,
    email,
    buttonDivider,
    submitLabel,
    downloadLabel,
    qsr,
    onSubmitting,
    onDone,
}) => {
    const { t } = useTranslation('common');
    const { triggerSnackBar } = snackBar();
    const { url, query, lang } = useQlubRouter();
    const { config: countryConfig } = useConfigContext();
    const { vendor } = useVendor();

    const events = useEventsCenter();
    const qsrEvents = useQsrEventsCenter();

    // Track the number of successful mailing attempts.
    // Using a count (rather than a boolean) lets us trigger the consent API call for each new successful mailing,
    // and it resets to 0 whenever sending fails.
    const [successfulMailingCount, setSuccessfulMailingCount] = useState<number>(0);

    const [downloading, setDownloading] = useState(false);

    const blurHandler = useCallback(
        (e: any) => {
            if (!qsr || !e?.target?.value) {
                return;
            }

            qsrEvents.qsr.qsrEnterGetReceiptInfo();
        },
        [qsr],
    );

    const [showTerms, showDownload] = useMemo(() => {
        const showTermsFn = () => {
            switch (vendor?.config.emailTermsAndConditionsV4) {
                case 'show' as emailTermsAndConditionsType:
                    return true;
                case 'hide' as emailTermsAndConditionsType:
                    return false;
                default:
                    return countryConfig?.emailTermsAndConditionsV4;
            }
        };
        const showDownloadFn = () => {
            if (countryConfig?.downloadReceiptEnable === EnableEnum.Enable) {
                return true;
            }

            return vendor?.config.downloadReceiptEnable === EnableEnum.Enable;
        };
        return [showTermsFn(), showDownloadFn()];
    }, [vendor, countryConfig]);

    const schema = useMemo(
        () =>
            Yup.object().shape({
                email: Yup.string().required(t('Email is required!')).email(t('Email is not valid!')),
            }),
        [t, lang],
    );

    const initialValues = useMemo(() => {
        return {
            email: email || '',
        };
    }, [email]);

    const formSubmitHandler: FormikConfig<{ email: string }>['onSubmit'] = useCallback(
        (values: { email: string }, { setSubmitting }) => {
            setSubmitting(true);
            onSubmitting?.(true);

            BillAPIManager.getInstance()
                .emailReceiptV2({
                    email: values.email,
                    id: getSession(query?.sid),
                    diningSessionID: query?.dsi || getDiningSession(url)?.id || '',
                    lang,
                    reference: query?.ref,
                    countryCode: url.cc,
                    timezone: vendor?.timezone?.timezone || '',
                })
                .then(() => {
                    const pgName = `${query?.method}_${query?.paymentElement}`.toLowerCase();
                    events.email.receipt(pgName);

                    triggerSnackBar(t('Your payment receipt has been sent to your email'), {
                        variant: 'success',
                        persist: false,
                    });

                    setSuccessfulMailingCount((prev) => prev + 1);

                    onDone?.();

                    if (qsr) {
                        qsrEvents.qsr.qsrRequestTheReceipt();
                    }
                })
                .catch((err) => {
                    setSuccessfulMailingCount(0);

                    if (err?.status === 429) {
                        triggerSnackBar(t('You cannot get more receipts'), { variant: 'error' });
                    } else {
                        triggerSnackBar(t('Failed to download receipt'), { variant: 'error', persist: !email });
                    }
                })
                .finally(() => {
                    setSubmitting(false);
                    onSubmitting?.(false);
                });
        },
        [url.cc, vendor, lang, qsr],
    );

    const downloadHandler = useCallback(() => {
        setDownloading(true);

        BillAPIManager.getInstance()
            .downloadReceipt({
                id: getSession(query?.sid),
                diningSessionID: query?.dsi || getDiningSession(url)?.id || '',
                lang,
                reference: query?.ref,
                countryCode: url.cc,
                timezone: vendor?.timezone?.timezone || '',
            })
            .then((res) => {
                triggerSnackBar(t('Your payment receipt is being downloaded'), {
                    variant: 'success',
                });
                saveAs(res.data, 'receipt.pdf');
                onDone?.();
                if (qsr) {
                    qsrEvents.qsr.qsrDownloadTheReceipt();
                }
            })
            .catch((err) => {
                if (err?.status === 429) {
                    triggerSnackBar(t('You cannot get more receipts'), { variant: 'error' });
                } else {
                    triggerSnackBar(t('Failed to download receipt'), { variant: 'error' });
                }
            })
            .finally(() => {
                setDownloading(false);
            });
    }, [url.cc, vendor, lang]);

    return (
        <Formik
            initialValues={initialValues}
            enableReinitialize
            validationSchema={schema}
            onSubmit={formSubmitHandler}
            validateOnMount={false}
            validateOnBlur={false}
            validateOnChange
        >
            {({ values, handleChange, errors, isSubmitting }) => {
                return (
                    <Form className={styles.form}>
                        {shouldShowEmailLabel && (
                            <TypographyT typo="title_sm" className={styles.label}>
                                {t('Email')}
                            </TypographyT>
                        )}
                        <div>
                            <TextField
                                fullWidth
                                placeholder={t('Your Email Address')}
                                onChange={(e) => handleChange(e)}
                                value={values.email}
                                name="email"
                                onBlur={blurHandler}
                                helperText={
                                    <Collapse in={!!errors?.email} timeout={500}>
                                        <Typography typo="caption_overline" className={styles.errorMessage}>
                                            {errors?.email}
                                        </Typography>
                                    </Collapse>
                                }
                                error={!!errors?.email}
                                className={styles.emailInput}
                            />
                            <Consent emailSent={successfulMailingCount} email={values.email} />
                            {showTerms && (
                                <Typography typo="caption_overline" className={styles.termsLink}>
                                    {t('By confirming my email, I accept Qlub’s')}
                                    <Typography typo="caption_overline" secondColor>
                                        <Link
                                            href={{
                                                pathname: '/qr/[cc]/terms',
                                                query: {
                                                    cc: url.cc || vendor?.country.code,
                                                    ...getAvailableLang(lang),
                                                },
                                            }}
                                        >
                                            {t('privacy policy and terms and conditions')}
                                        </Link>
                                    </Typography>
                                </Typography>
                            )}
                        </div>
                        <Button
                            type="submit"
                            variant="contained"
                            color="primary"
                            fullWidth
                            disabled={isSubmitting || !!errors?.email || values.email === '' || downloading}
                            loading={isSubmitting}
                        >
                            {submitLabel || (showDownload ? t('Send via Email') : t('Submit'))}
                        </Button>
                        {showDownload && buttonDivider && <Divider />}
                        {showDownload && (
                            <Button
                                type="button"
                                variant="containedLight"
                                color="primary"
                                fullWidth
                                onClick={downloadHandler}
                                disabled={downloading || isSubmitting}
                                loading={downloading}
                            >
                                {downloadLabel || t('Download the PDF')}
                            </Button>
                        )}
                    </Form>
                );
            }}
        </Formik>
    );
};

export default FormContent;
