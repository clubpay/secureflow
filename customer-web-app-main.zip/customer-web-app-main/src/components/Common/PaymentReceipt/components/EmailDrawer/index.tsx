import React, { useCallback, useState } from 'react';
import { SwipeableCustomerDrawer } from '@qlub-dev/qlub-kit/dist/components/Drawer';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import Button from '@qlub-dev/qlub-kit/dist/components/Button';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import FormContent from '../FormContent';

import styles from './index.module.scss';

interface IProps {
    email?: string;
    buttonDivider?: boolean;
    qsr?: boolean;
    onSubmitted?: () => void;
}

const EmailDrawer = ({ email, buttonDivider, qsr, onSubmitted }: IProps) => {
    const { t } = useTranslation('common');
    const qsrEvents = useQsrEventsCenter();

    const [open, setOpen] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const openHandler = useCallback(() => {
        setOpen(true);
        if (qsr) {
            qsrEvents.qsr.qsrSelectGetReceipt();
        }
    }, [qsr]);

    const toggleDrawer = useCallback(
        (v: boolean) => () => {
            setOpen(v);
        },
        [],
    );

    return (
        <>
            <Button
                data-qa-id="confimation-get-receipt"
                variant="contained"
                color="primary"
                fullWidth
                disabled={isSubmitting}
                loading={isSubmitting}
                onClick={openHandler}
            >
                {t('Get the Receipt')}
            </Button>
            <SwipeableCustomerDrawer
                headerTitle={<TypographyT className={styles.headerTitle}>{t('Get the Receipt')}</TypographyT>}
                open={open}
                onClose={toggleDrawer(false)}
                onOpen={toggleDrawer(true)}
                disablePortal
                disableSwipeToOpen
                slotProps={{
                    backdrop: {
                        sx: {
                            background: '#00000099',
                        },
                    },
                }}
                PaperProps={{
                    sx: {
                        maxWidth: '552px',
                        margin: '0 auto',
                        background: '#fff',
                        borderRadius: '2rem 2rem 0 0',
                    },
                }}
            >
                <FormContent
                    shouldShowEmailLabel
                    email={email}
                    buttonDivider={buttonDivider}
                    qsr={qsr}
                    onSubmitting={(val) => {
                        setIsSubmitting(val);
                    }}
                    onDone={() => {
                        setOpen(false);
                        onSubmitted?.();
                    }}
                />
            </SwipeableCustomerDrawer>
        </>
    );
};

export default EmailDrawer;
