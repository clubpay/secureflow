import { FC, useEffect, useMemo, useState } from 'react';
import { ConsentType } from '@clubpay/customer-common-module/src/component/Consent/types';
import UserConsent from '@clubpay/customer-common-module/src/component/Consent/UserConsent';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { CheckEnum, VisibilityEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { qlubLocalStorage } from '@clubpay/customer-common-module/src/service/storage/localStorage';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import AuthManager from '@clubpay/customer-common-module/src/repository/auth';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { ConsentKey } from '@clubpay/customer-common-module/src/repository/auth/enums';

const key = 'qlub.email.consent';

interface IProps {
    emailSent: number;
    email: string;
}

const Consent: FC<IProps> = ({ emailSent, email }) => {
    const { t } = useTranslation('common');
    const { config: countryConfig } = useConfigContext();
    const { vendor } = useVendor();
    const { lang } = useQlubRouter();

    const consentDefault =
        (vendor?.config?.communicationConsentDefault ?? countryConfig?.communicationConsentDefault) === CheckEnum.Check;
    const [hasEmailConsent, setHasEmailConsent] = useState(consentDefault);

    const [hasConsentFromPriorVisit, setHasConsentFromPriorVisit] = useState(qlubLocalStorage.get(key) === 'true');

    const authMgr = AuthManager.getInstance();

    useEffect(() => {
        if (hasConsentFromPriorVisit) {
            return;
        }

        authMgr
            .getConsent({
                consentKey: ConsentKey.Communication,
            })
            .then((res) => {
                if (res?.emails?.length && res.emails?.length > 0) {
                    setHasConsentFromPriorVisit(true);
                }
            })
            .catch((err) => {
                console.error('(Email-consent): Failed to get email consent ', err);
            });
    }, []);

    useEffect(() => {
        qlubLocalStorage.set(key, hasConsentFromPriorVisit || hasEmailConsent);

        if (emailSent === 0 || !email || !hasEmailConsent) {
            return;
        }

        authMgr
            .setConsent({
                email,
                consentKey: ConsentKey.Communication,
            })
            .catch((err) => {
                console.error('(Email-consent): Failed to save email consent ', err);
            });
    }, [emailSent]);

    const handleEmailConsent = (e: Event) => {
        e.preventDefault();
        e.stopPropagation();

        setHasEmailConsent((prev) => !prev);
    };

    const showEmailConsent =
        (vendor?.config?.communicationConsentVisibility ?? countryConfig?.communicationConsentVisibility) ===
            VisibilityEnum.Show && !hasConsentFromPriorVisit;

    const consentMsg = useMemo(() => {
        const countryLvlConsentMsg = getLocaleText(countryConfig?.communicationConsentMessage || '', lang, 'en');
        const vendorLvlConsentMsg = getLocaleText(vendor?.config?.communicationConsentMessage || '', lang, 'en');

        return vendorLvlConsentMsg || countryLvlConsentMsg || t('I consent to receiving marketing communications');
    }, [vendor?.config?.communicationConsentMessage, countryConfig?.communicationConsentMessage, lang]);

    if (!showEmailConsent) {
        return <></>;
    }

    return (
        <UserConsent
            consentBoxProps={{
                hasConsented: hasEmailConsent,
                handleClick: handleEmailConsent,
            }}
            messageFactoryProps={{
                type: ConsentType.PlainText,
                messageProps: {
                    text: consentMsg,
                },
            }}
        />
    );
};

export default Consent;
