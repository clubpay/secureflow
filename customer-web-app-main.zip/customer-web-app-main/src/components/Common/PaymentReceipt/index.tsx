import React, { useCallback, useMemo, useState } from 'react';
import Typography from '@qlub-dev/qlub-kit/dist/components/Typography';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import classNames from 'classnames';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { EnableEnum, VersionEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';
import Divider from '@qlub-dev/qlub-kit/dist/components/Divider';
import { AutoOpenEnum } from '@/components/Review/Main';
import Review from '@/components/Review';
import FormContent from './components/FormContent';
import EmailDrawer from './components/EmailDrawer';

import styles from './index.module.scss';

export interface IProps {
    email?: string;
    forceDrawer?: boolean;
    qsr?: boolean;
}

const PaymentReceipt = ({ email, forceDrawer, qsr }: IProps) => {
    const { t } = useTranslation('common');
    const { vendor } = useVendor();
    const { config: countryConfig } = useConfigContext();

    const [openReview, setOpenReview] = useState(false);

    const [showDrawer, showReviewDrawerConfig] = useMemo(() => {
        return [
            forceDrawer ||
                (vendor?.config?.emailReceiptVersion || countryConfig?.emailReceiptVersion) === VersionEnum.V2,
            (vendor?.config?.reviewFlowAfterReceiptEmail || countryConfig?.reviewFlowAfterReceiptEmail) ===
                EnableEnum.Enable,
        ];
    }, [vendor, countryConfig, forceDrawer]);

    const postEmailSubmitHandler = useCallback(() => {
        setOpenReview(true);
    }, []);

    return (
        <div
            className={classNames(styles.container, {
                [styles.qsr]: qsr,
            })}
        >
            {showDrawer ? (
                <EmailDrawer email={email} buttonDivider qsr={qsr} onSubmitted={postEmailSubmitHandler} />
            ) : (
                <>
                    <Typography className={styles.nonDrawerFormTitle}>{t('Get receipt via Email')}</Typography>
                    <FormContent
                        submitLabel={t('Get the Receipt')}
                        email={email}
                        qsr={qsr}
                        onDone={postEmailSubmitHandler}
                    />
                    <Divider />
                </>
            )}
            {showReviewDrawerConfig && openReview && <Review paymentGateway="" show autoOpen={AutoOpenEnum.NoReview} />}
        </div>
    );
};

export default PaymentReceipt;
