import { useMemo } from 'react';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useLoyaltyPageTitles } from '@clubpay/loyalty/dist/utils/page-titles';

interface IProps {
    def?: string;
}

const PageTitle = ({ def }: IProps) => {
    const { pathname, lang } = useQlubRouter();
    const { t } = useTranslation('common');

    const loyaltyPageTitles = useLoyaltyPageTitles();

    const title = useMemo(() => {
        switch (pathname) {
            case '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr':
            case '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/embed/qsr':
                return t('Select a menu');
            case '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/social':
                return t('Select a restaurant');
            case '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/profile':
                return t('Account Details');
            case '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/loyalty/venues':
                return loyaltyPageTitles.loyalty_restaurants;
            case '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/loyalty/transactions':
                return loyaltyPageTitles.loyalty_transactions;
            case '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/subscription':
                return loyaltyPageTitles.manage_subscription;
            case '/receipts':
                return t('Payment receipts');
            case '/receipts/[id]':
                return t('Payment details');
            default:
                return def;
        }
    }, [pathname, lang, loyaltyPageTitles]);

    return <>{title}</>;
};

export default PageTitle;
