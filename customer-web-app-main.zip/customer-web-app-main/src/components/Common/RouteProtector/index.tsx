import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import { ComponentType, useEffect } from 'react';

import styles from './index.module.scss';

const withAuth = <P extends object>(WrappedComponent: ComponentType<P>) => {
    const ProtectedComponent = (props: P) => {
        const { isAuthorizedUser } = useAuth();
        const { t } = useTranslation('common');
        const { back: routeBack } = useQlubRouter();

        useEffect(() => {
            if (isAuthorizedUser === false) {
                routeBack();
            }
        }, [isAuthorizedUser, routeBack]);

        if (isAuthorizedUser === false) {
            return (
                <div className={styles.unauthorized_container}>
                    <TypographyT typo="body_sm">{t('Unauthorized')}</TypographyT>
                </div>
            );
        }

        return <WrappedComponent {...props} />;
    };

    Object.assign(ProtectedComponent, WrappedComponent);

    return ProtectedComponent;
};

export default withAuth;
