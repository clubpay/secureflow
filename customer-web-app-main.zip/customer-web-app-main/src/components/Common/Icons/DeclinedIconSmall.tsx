const DeclinedIconSmall = () => {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
            <g clipPath="url(#clip0_264_18591)">
                <path
                    d="M8.46445 4.51407L4.51405 8.46447C2.56143 10.4171 2.56143 13.5829 4.51405 15.5355L8.46445 19.4859C10.4171 21.4386 13.5829 21.4386 15.5355 19.4859L19.4859 15.5355C21.4385 13.5829 21.4385 10.4171 19.4859 8.46447L15.5355 4.51407C13.5829 2.56145 10.4171 2.56144 8.46445 4.51407Z"
                    fill="#FF4949"
                />
                <ellipse
                    cx="12"
                    cy="12"
                    rx="5.5"
                    ry="5.5"
                    transform="rotate(180 12 12)"
                    fill="url(#paint0_angular_264_18591)"
                    fillOpacity="0.1"
                />
                <g clipPath="url(#clip1_264_18591)">
                    <path
                        d="M10.4004 10.3984L13.6004 13.5984"
                        stroke="white"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                    />
                    <path
                        d="M13.6004 10.3984L10.4004 13.5984"
                        stroke="white"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                    />
                </g>
            </g>
            <defs>
                <radialGradient
                    id="paint0_angular_264_18591"
                    cx="0"
                    cy="0"
                    r="1"
                    gradientUnits="userSpaceOnUse"
                    gradientTransform="translate(12 12) rotate(90) scale(5.5 5.5)"
                >
                    <stop stopColor="white" />
                    <stop offset="0.510417" stopColor="white" stopOpacity="0.2" />
                </radialGradient>
                <clipPath id="clip0_264_18591">
                    <rect width="24" height="24" fill="white" />
                </clipPath>
                <clipPath id="clip1_264_18591">
                    <rect width="9.6" height="9.6" fill="white" transform="translate(7.2002 7.19922)" />
                </clipPath>
            </defs>
        </svg>
    );
};

export default DeclinedIconSmall;
