const PendingIcon = () => {
    return (
        <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M16.9289 9.52813L9.0281 17.4289C5.12286 21.3342 5.12286 27.6658 9.0281 31.5711L16.9289 39.4719C20.8341 43.3771 27.1658 43.3771 31.071 39.4719L38.9718 31.5711C42.8771 27.6658 42.8771 21.3342 38.9718 17.4289L31.071 9.52813C27.1658 5.62289 20.8341 5.62289 16.9289 9.52813Z"
                fill="#F26123"
            />
            <ellipse
                cx="24"
                cy="24.5"
                rx="11"
                ry="11"
                transform="rotate(180 24 24.5)"
                fill="url(#paint0_angular_13505_11375)"
                fillOpacity="0.1"
            />
            <path
                d="M24 24.7641V22.1001"
                stroke="white"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <circle cx="24.0006" cy="26.9" r="0.9" fill="white" />
            <path
                d="M28.5238 29.0232C27.3654 30.1808 25.7678 30.9 24.0006 30.9C20.4662 30.9 17.6006 28.0344 17.6006 24.5C17.6006 24.0136 17.6598 23.5416 17.7622 23.0864"
                stroke="white"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M16 24.4999L17.6 22.8999L19.2 24.4999"
                stroke="white"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M32.0008 24.5L30.4008 26.1L28.8008 24.5"
                stroke="white"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M19.4746 19.9745C20.633 18.8169 22.233 18.1001 24.0002 18.1001C27.5346 18.1001 30.4002 20.9657 30.4002 24.5001C30.4002 24.9865 30.341 25.4585 30.2386 25.9137"
                stroke="white"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <defs>
                <radialGradient
                    id="paint0_angular_13505_11375"
                    cx="0"
                    cy="0"
                    r="1"
                    gradientUnits="userSpaceOnUse"
                    gradientTransform="translate(24 24.5) rotate(90) scale(11 11)"
                >
                    <stop stopColor="white" />
                    <stop offset="0.510417" stopColor="white" stopOpacity="0.2" />
                </radialGradient>
            </defs>
        </svg>
    );
};

export default PendingIcon;
