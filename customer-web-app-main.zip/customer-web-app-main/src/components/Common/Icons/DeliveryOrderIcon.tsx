const DeliveryOrderIcon = () => {
    return (
        <svg width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M21 16.5V18.5C21 20.1569 19.6569 21.5 18 21.5H17"
                stroke="#1A1C23"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M3 9.5V6.5C3 4.84315 4.34315 3.5 6 3.5H8"
                stroke="#1A1C23"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M3 20.5L4.156 21.078C4.71109 21.3555 5.32318 21.5 5.94378 21.5H12.5C13.3284 21.5 14 20.8284 14 20V20C14 19.1716 13.3284 18.5 12.5 18.5H8.5"
                stroke="#1A1C23"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M3 13.5H5.91335C6.34609 13.5 6.76716 13.6404 7.11335 13.9L9.35062 15.5779C9.7271 15.8603 9.96252 16.2921 9.99588 16.7615C10.0292 17.231 9.85726 17.6917 9.5245 18.0245V18.0245C8.95325 18.5958 8.04889 18.66 7.4026 18.1753L6 17.1233"
                stroke="#1A1C23"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <rect
                x="11"
                y="4.06836"
                width="10"
                height="9"
                rx="2.25"
                stroke="#1A1C23"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M14.5 4.06836H17.5V6.56836C17.5 6.8445 17.2761 7.06836 17 7.06836H15C14.7239 7.06836 14.5 6.8445 14.5 6.56836V4.06836Z"
                stroke="#1A1C23"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
        </svg>
    );
};

export default DeliveryOrderIcon;
