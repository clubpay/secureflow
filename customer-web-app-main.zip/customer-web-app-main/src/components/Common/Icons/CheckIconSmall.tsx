const CheckIconSmall = () => {
    return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g clipPath="url(#clip0_229_18195)">
                <path
                    d="M8.13637 3.85387L3.83139 8.15884C1.70351 10.2867 1.70351 13.7367 3.83139 15.8646L8.13637 20.1696C10.2642 22.2975 13.7142 22.2975 15.8421 20.1696L20.1471 15.8646C22.275 13.7367 22.275 10.2867 20.1471 8.15885L15.8421 3.85387C13.7142 1.72599 10.2642 1.72598 8.13637 3.85387Z"
                    fill="#009821"
                />
                <path
                    d="M16.5 9L10.879 15L8 12"
                    stroke="white"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                />
            </g>
            <defs>
                <clipPath id="clip0_229_18195">
                    <rect width="24" height="24" fill="white" />
                </clipPath>
            </defs>
        </svg>
    );
};

export default CheckIconSmall;
