const DeliveryIcon = () => {
    return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M2.848 20.875H21.152C21.62 20.875 22 20.495 22 20.027V18.848C22 18.38 21.62 18 21.152 18H2.848C2.38 18 2 18.38 2 18.848V20.027C2 20.495 2.38 20.875 2.848 20.875Z"
                stroke="#1A1C23"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M14.0156 18V12C14.0156 11.448 14.4636 11 15.0156 11H19.9996C20.5516 11 20.9996 11.448 20.9996 12V18"
                stroke="#1A1C23"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path d="M17 15H18" stroke="#1A1C23" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            <path
                d="M8.5857 5.97338C9.39526 6.78294 9.39526 8.09549 8.5857 8.90504C7.77615 9.7146 6.46359 9.7146 5.65404 8.90504C4.84449 8.09548 4.84449 6.78293 5.65404 5.97338C6.4636 5.16382 7.77615 5.16382 8.5857 5.97338"
                stroke="#1A1C23"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M3.18359 18.0002L3.84259 14.0382C4.00259 13.0732 4.83759 12.3662 5.81559 12.3662H8.44459C9.41459 12.3662 10.2446 13.0622 10.4136 14.0172L11.1206 18.0002"
                stroke="#1A1C23"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
        </svg>
    );
};

export default DeliveryIcon;
