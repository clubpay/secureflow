const PendingIconSmall = () => {
    return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g clipPath="url(#clip0_229_18212)">
                <path
                    d="M7.90593 3.60579L3.60506 7.90666C1.4792 10.0325 1.4792 13.4792 3.60506 15.6051L7.90593 19.9059C10.0318 22.0318 13.4785 22.0318 15.6043 19.9059L19.9052 15.6051C22.0311 13.4792 22.0311 10.0325 19.9052 7.90666L15.6043 3.60579C13.4785 1.47994 10.0318 1.47994 7.90593 3.60579Z"
                    fill="#F26123"
                />
                <g clipPath="url(#clip1_229_18212)">
                    <path d="M11.75 11.915V10.25" stroke="white" strokeLinecap="round" strokeLinejoin="round" />
                    <ellipse cx="11.75" cy="13.25" rx="0.5625" ry="0.5625" fill="white" />
                    <path
                        d="M14.577 14.5757C13.853 15.2992 12.8545 15.7487 11.75 15.7487C9.541 15.7487 7.75 13.9577 7.75 11.7487C7.75 11.4447 7.787 11.1497 7.851 10.8652"
                        stroke="white"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                    />
                    <path
                        d="M6.75 11.75L7.75 10.75L8.75 11.75"
                        stroke="white"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                    />
                    <path
                        d="M16.75 11.75L15.75 12.75L14.75 11.75"
                        stroke="white"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                    />
                    <path
                        d="M8.92139 8.9215C9.64539 8.198 10.6454 7.75 11.7499 7.75C13.9589 7.75 15.7499 9.541 15.7499 11.75C15.7499 12.054 15.7129 12.349 15.6489 12.6335"
                        stroke="white"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                    />
                </g>
            </g>
            <defs>
                <clipPath id="clip0_229_18212">
                    <rect width="24" height="24" fill="white" />
                </clipPath>
                <clipPath id="clip1_229_18212">
                    <rect width="12" height="12" fill="white" transform="translate(6 6)" />
                </clipPath>
            </defs>
        </svg>
    );
};

export default PendingIconSmall;
