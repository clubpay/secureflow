const DeclinedIcon = () => {
    return (
        <svg width="48" height="49" viewBox="0 0 48 49" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M16.9289 9.52813L9.0281 17.4289C5.12286 21.3342 5.12286 27.6658 9.0281 31.5711L16.9289 39.4719C20.8341 43.3771 27.1658 43.3771 31.071 39.4719L38.9718 31.5711C42.8771 27.6658 42.8771 21.3342 38.9718 17.4289L31.071 9.52813C27.1658 5.62289 20.8341 5.62289 16.9289 9.52813Z"
                fill="#FF4949"
            />
            <ellipse
                cx="24"
                cy="24.5"
                rx="11"
                ry="11"
                transform="rotate(180 24 24.5)"
                fill="url(#paint0_angular_13505_11877)"
                fillOpacity="0.1"
            />
            <path
                d="M20.8008 21.2998L27.2008 27.6998"
                stroke="white"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d="M27.2008 21.2998L20.8008 27.6998"
                stroke="white"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <defs>
                <radialGradient
                    id="paint0_angular_13505_11877"
                    cx="0"
                    cy="0"
                    r="1"
                    gradientUnits="userSpaceOnUse"
                    gradientTransform="translate(24 24.5) rotate(90) scale(11 11)"
                >
                    <stop stopColor="white" />
                    <stop offset="0.510417" stopColor="white" stopOpacity="0.2" />
                </radialGradient>
            </defs>
        </svg>
    );
};

export default DeclinedIcon;
