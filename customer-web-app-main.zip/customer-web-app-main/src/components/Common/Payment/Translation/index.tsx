import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

export const PaymentLocals = () => {
    const { t } = useTranslation('common');

    return [t('Retry payment'), t('Phone number')];
};
