import { FC, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Typography from '@qlub-dev/qlub-kit/dist/components/Typography';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { Button, Divider } from '@qlub-dev/qlub-kit';
import TextField from '@mui/material/TextField';
import ReviewAPIManager from '@/repositories/review';
import ReviewRate from '@/components/Review/Rate';
import ReviewThankYou from '@/components/Review/ThankYou';
import { IReview } from '@/repositories/review/types';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { SwipeableDrawer } from '@mui/material';
import ReviewSecondary, { SubmitFnType } from '@/components/Review/Secondary';
import { googleRedirect, hasAutoRedirectionOnStar, reviewRedirect } from '@/components/Review/Secondary/utils';
import { RedirectionTypeEnum } from '@/components/Review/Secondary/Redirection/types';

import styles from './index.module.scss';

enum ReviewStepEnum {
    Pre = 'pre',
    Star = 'star',
    Detail = 'detail',
    ThankYou = 'thankYou',
}

interface IHandle {
    rate: number;
    body?: string;
    draft?: boolean;
}

export enum AutoOpenEnum {
    Always = 'always',
    NoReview = 'noReview',
    Disabled = 'disabled',
}

interface IProps {
    dividerPosition?: 'top' | 'bottom';
    autoOpen?: AutoOpenEnum;
    defaultDsi?: string;
}

const Review: FC<IProps> = ({ dividerPosition, autoOpen, defaultDsi }) => {
    const { t } = useTranslation('common');
    const { url, query } = useQlubRouter();
    const { vendor } = useVendor();

    const [loading, setLoading] = useState(false);
    const [firstLoad, setFirstLoad] = useState(false);
    const [step, setStep] = useState<ReviewStepEnum>(ReviewStepEnum.Pre);

    const [drawerOpen, setDrawerOpen] = useState(false);

    const initialRateRef = useRef(0);
    const [rate, setRate] = useState(0);
    const [body, setBody] = useState('');
    const [hasNoReview, setHasNoReview] = useState(false);
    const [review, setReview] = useState<IReview | undefined>(undefined);
    const [secondaryDone, setSecondaryDone] = useState(false);
    const [finalStep, setFinalStep] = useState(false);
    const submitFnRef = useRef<SubmitFnType>(undefined);
    const [hasSubmitBtn, setHasSubmitBtn] = useState(false);

    const [isSubmitting, setIsSubmitting] = useState(false);

    const withAutoOpen = [AutoOpenEnum.Always, AutoOpenEnum.NoReview].includes(autoOpen || AutoOpenEnum.Disabled);

    const dsi = query.dsi || defaultDsi;

    const toggleDrawerHandler = (open: boolean) => () => {
        if (!open) {
            setStep(ReviewStepEnum.Star);
        }

        setDrawerOpen(open);
    };

    useEffect(() => {
        if (!url || !url.cc || !url.slug) {
            return;
        }

        ReviewAPIManager.getInstance()
            .get(
                {
                    url,
                    dsi,
                },
                { vendor },
            )
            .then((res) => {
                initialRateRef.current = res?.rate || 0;
                setRate(res?.rate || 0);
                setBody(res?.body || '');
                if (res) {
                    setHasNoReview(res.rate === 0 && res.body.trim() === '');
                } else {
                    setHasNoReview(true);
                }
            })
            .catch((err: any) => {
                if (err?.data?.statusCode === 400 && err?.data?.message === 'REVIEW_NOT_FOUND') {
                    setHasNoReview(true);
                }
            })
            .finally(() => {
                setFirstLoad(true);
                if (!withAutoOpen) {
                    setTimeout(() => {
                        setStep(ReviewStepEnum.Star);
                    }, 100);
                }
            });
    }, [dsi, vendor, withAutoOpen]);

    useEffect(() => {
        if (!firstLoad || autoOpen === AutoOpenEnum.Disabled) {
            return;
        }

        // eslint-disable-next-line default-case
        switch (autoOpen) {
            case AutoOpenEnum.NoReview:
                if (hasNoReview) {
                    setDrawerOpen(true);
                    setStep(ReviewStepEnum.Detail);
                }
                break;
            case AutoOpenEnum.Always:
                setDrawerOpen(true);
                setStep(ReviewStepEnum.Detail);
                break;
        }
    }, [autoOpen, hasNoReview, firstLoad]);

    const callReviewAPI = useCallback(
        (props: IHandle) => {
            setLoading(true);
            return ReviewAPIManager.getInstance()
                .submit(
                    {
                        url,
                        dsi,
                        rate: props.rate,
                        body: props.body || '',
                        isDraft: props.draft || false,
                    },
                    { vendor },
                )
                .then((res) => {
                    const [option, redirectionConfig] = hasAutoRedirectionOnStar(res);
                    if (option && redirectionConfig) {
                        return ReviewAPIManager.getInstance()
                            .submitActivity({
                                url,
                                reviewId: res?.id || '',
                                configId: option.id,
                                meta: {},
                            })
                            .then(() => {
                                if (redirectionConfig?.redirection === 'sameTab') {
                                    setStep(ReviewStepEnum.ThankYou);
                                }

                                switch (option.service) {
                                    case RedirectionTypeEnum.Google:
                                        googleRedirect(redirectionConfig, vendor);
                                        break;
                                    case RedirectionTypeEnum.TripAdvisor:
                                        reviewRedirect(redirectionConfig.tripAdvisorUrl, redirectionConfig);
                                        break;
                                    case RedirectionTypeEnum.Foursquare:
                                        reviewRedirect(redirectionConfig.foursquareUrl, redirectionConfig);
                                        break;
                                    default:
                                        console.warn('service is not supported');
                                        break;
                                }

                                return res;
                            });
                    }

                    setReview(res);
                    return res;
                })
                .finally(() => {
                    setLoading(false);
                });
        },
        [vendor],
    );

    const submitReview = useCallback(() => {
        return callReviewAPI({
            rate,
            body,
        });
    }, [rate, body]);

    const submitHandler = useCallback(() => {
        setIsSubmitting(true);
        Promise.all([...(finalStep ? [submitReview()] : []), ...(submitFnRef.current ? [submitFnRef.current()] : [])])
            ?.then(() => {
                if (!submitFnRef.current) {
                    setSecondaryDone(true);
                }
            })
            .finally(() => {
                setIsSubmitting(false);
            });
    }, [finalStep, submitReview]);

    useEffect(() => {
        switch (step) {
            case ReviewStepEnum.Star:
                if (!rate || initialRateRef.current === rate) {
                    break;
                }

                callReviewAPI({
                    rate,
                    draft: true,
                }).then(() => {
                    initialRateRef.current = rate;
                    setStep(ReviewStepEnum.Detail);
                    setDrawerOpen(true);
                });
                break;
            case ReviewStepEnum.Detail:
                if (withAutoOpen && rate > 0 && initialRateRef.current !== rate) {
                    callReviewAPI({
                        rate,
                        draft: true,
                    }).then(() => {
                        initialRateRef.current = rate;
                    });
                }

                if (!secondaryDone) {
                    break;
                }

                setTimeout(
                    () => {
                        setDrawerOpen(false);
                    },
                    withAutoOpen ? 3000 : 1,
                );
                setStep(ReviewStepEnum.ThankYou);
                break;
            default:
                break;
        }
    }, [step, rate, secondaryDone, withAutoOpen]);

    const rateChangeHandler = (embed?: boolean) => (event: React.SyntheticEvent, value: number | null) => {
        if (review && review.config && embed && (rate === value || !value)) {
            setStep(ReviewStepEnum.Detail);
            toggleDrawerHandler(true)();
            return;
        }

        setRate(value || 0);
    };

    const content = useMemo(() => {
        switch (step) {
            default:
            case ReviewStepEnum.Star:
                return null;
            case ReviewStepEnum.Detail:
                return (
                    <>
                        <div className={styles.header}>
                            {hasSubmitBtn ? t('Tell us more, so we improve!') : t('How’s your overall experience?')}
                        </div>
                        <div className={styles.content}>
                            <Typography typo="body_sm" className={styles.caption}>
                                {interpolateT(t('Rate & review <title>'), {
                                    title: <Typography className={styles.title}>{vendor?.title}</Typography>,
                                })}
                            </Typography>
                            <ReviewRate topPadding value={rate} onChange={rateChangeHandler()} />
                            {review?.config && (
                                <ReviewSecondary
                                    review={review}
                                    bottomMargin={finalStep && hasSubmitBtn}
                                    onDone={() => {
                                        setSecondaryDone(true);
                                    }}
                                    onFinal={(final) => {
                                        setFinalStep(final);
                                    }}
                                    onSubmitting={(val) => {
                                        setIsSubmitting(val);
                                    }}
                                    setSubmitFn={(fn) => {
                                        submitFnRef.current = fn;
                                        setHasSubmitBtn(Boolean(fn));
                                    }}
                                />
                            )}
                            {finalStep && hasSubmitBtn && <Divider type="fullWidth" />}
                            {finalStep && (
                                <div className={styles.body}>
                                    <Typography typo="title_md" sx={{ pt: 2 }}>
                                        {t('Tell us more, so we improve!')}
                                    </Typography>
                                    <TextField
                                        fullWidth
                                        className={styles.input}
                                        placeholder={t('Add review')}
                                        onChange={(e) => {
                                            setBody(e.target.value || '');
                                        }}
                                        value={body}
                                        name="review"
                                        type="text"
                                        sx={{ mt: 2 }}
                                        multiline
                                        rows={2}
                                    />
                                </div>
                            )}
                        </div>
                        {(finalStep || hasSubmitBtn) && (
                            <div className={styles.submit}>
                                <Button
                                    type="submit"
                                    variant="contained"
                                    color="primary"
                                    sx={{ mt: 3 }}
                                    fullWidth
                                    disabled={isSubmitting || !rate}
                                    loading={isSubmitting}
                                    onClick={submitHandler}
                                >
                                    {t('Submit')}
                                </Button>
                            </div>
                        )}
                    </>
                );
            case ReviewStepEnum.ThankYou:
                return <ReviewThankYou />;
        }
    }, [step, rate, body, isSubmitting, review, finalStep, hasSubmitBtn]);

    return (
        <>
            {!withAutoOpen && (
                <>
                    {dividerPosition === 'top' && (
                        <div>
                            <Divider type="fullWidth" />
                        </div>
                    )}
                    {step === ReviewStepEnum.ThankYou ? (
                        <ReviewThankYou dividerPosition={dividerPosition} />
                    ) : (
                        <div className={styles.container}>
                            <Typography typo="body_sm" className={styles.embedCaption}>
                                {t('How’s your overall experience?')}
                            </Typography>
                            <ReviewRate
                                topPadding
                                value={rate}
                                onChange={rateChangeHandler(true)}
                                disabled={loading}
                                dividerPosition={dividerPosition}
                            />
                        </div>
                    )}
                </>
            )}
            <SwipeableDrawer
                anchor="bottom"
                open={drawerOpen}
                onClose={toggleDrawerHandler(false)}
                onOpen={toggleDrawerHandler(true)}
                BackdropProps={{ sx: { background: '#00000099' } }}
                PaperProps={{
                    sx: {
                        maxWidth: '552px',
                        minHeight: '200px',
                        margin: '0 auto',
                        background: '#fff',
                        borderRadius: '30px 30px 0 0',
                    },
                }}
            >
                <div className={styles.container}>{content}</div>
            </SwipeableDrawer>
        </>
    );
};

export default Review;
