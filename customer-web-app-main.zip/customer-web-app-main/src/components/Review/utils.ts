import { aggregateConfig } from '@/services/utils/config';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import { EnableEnum, IRestaurantConfig } from '@clubpay/customer-common-module/src/repository/vendor';

export const getVentureReviewConfigs = (vendorConfig: IRestaurantConfig | undefined, countryConfig: IConfig | null) => {
    if (!vendorConfig || !countryConfig) return;

    const base: IRestaurantConfig | IConfig | undefined = aggregateConfig(vendorConfig, countryConfig, 'reviewEnabled');
    if (!base) return;
    return {
        reviewMode: base.reviewMode,
        defaultRate: base.defaultRate,
        goodRatingThreshold: base.goodRatingThreshold || 3,
        showGoogleReviewRedirectionFlow: base.showGoogleReviewRedirectionFlow,
        enableGoogleReviewAutoRedirect: base.enableGoogleReviewAutoRedirect,
    };
};

export const useIsReviewEnabled = () => {
    const { config: countryConfig } = useConfigContext();
    const { vendor } = useVendor();

    if (vendor?.config?.reviewEnabled === EnableEnum.Enable) {
        return true;
    }

    if (vendor?.config?.reviewEnabled === EnableEnum.Disable) {
        return false;
    }

    return countryConfig?.reviewEnabled === EnableEnum.Enable;
};
