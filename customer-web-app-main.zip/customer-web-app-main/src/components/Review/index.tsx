import React from 'react';
import dynamic from 'next/dynamic';
import { Box, CircularProgress } from '@mui/material';
import { useIsReviewEnabled } from '@/components/Review/utils';
import GoogleReview from '@/components/Review/GoogleReview';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { AutoOpenEnum } from '@/components/Review/Main';
import type { IProps } from './dynamic';

const Review = dynamic<IProps>(() => import('./dynamic'), {
    loading: () => (
        <Box
            sx={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
            }}
        >
            <CircularProgress size={24} />
        </Box>
    ),
    ssr: false,
});

interface IWrapperProps extends IProps {
    paymentGateway: string;
    dividerPosition?: 'top' | 'bottom';
    autoOpen?: AutoOpenEnum;
}

const ReviewWrapper = ({ show, paymentGateway, dividerPosition, autoOpen }: IWrapperProps) => {
    const { vendor } = useVendor();

    const reviewEnabled = useIsReviewEnabled();

    if (reviewEnabled || autoOpen) {
        return <Review show={show} dividerPosition={dividerPosition} autoOpen={autoOpen} />;
    }

    if ((vendor?.googlePlaceId?.length || 0) > 2) {
        return <GoogleReview vendorGateway={paymentGateway} dividerPosition={dividerPosition} />;
    }

    return null;
};

export default ReviewWrapper;
