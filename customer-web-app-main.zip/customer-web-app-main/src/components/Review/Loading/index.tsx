import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { EnableEnum } from '@clubpay/customer-common-module/src/repository/vendor';

const useReviewLoading = () => {
    const { vendor } = useVendor();
    const url = `https://search.google.com/local/writereview?placeid=${vendor?.googlePlaceId}`;

    const handleRedirectFlow = (showGoogleReviewRedirectionFlow?: EnableEnum) => {
        if (
            !showGoogleReviewRedirectionFlow ||
            (showGoogleReviewRedirectionFlow && showGoogleReviewRedirectionFlow === EnableEnum.Disable)
        ) {
            window.open(url, '_blank');
            return;
        }

        window.location.href = url;
    };

    const redirectToGoogle = () => {
        window.open(url, '_blank');
    };

    return {
        handleRedirectFlow,
        redirectToGoogle,
    };
};
export default useReviewLoading;
