import { useEffect } from 'react';
import classNames from 'classnames';
import Typography from '@qlub-dev/qlub-kit/dist/components/Typography';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Rating from '@mui/material/Rating';
import StarIcon from '@/components/Review/icons/StarIcon';
import { Divider } from '@qlub-dev/qlub-kit';

import styles from './index.module.scss';

interface IProps {
    value: number | null | undefined;
    onChange: (event: React.SyntheticEvent, value: number | null) => void;
    topPadding?: boolean;
    disabled?: boolean;
    dividerPosition?: 'top' | 'bottom';
}

const ReviewRate = ({ value, onChange, topPadding, disabled, dividerPosition }: IProps) => {
    const { t } = useTranslation('common');

    useEffect(() => {
        setTimeout(() => {
            const components = document.querySelectorAll(`#embed_rating label`);
            if (!components) {
                return;
            }

            components.forEach((label, index) => {
                if (index === components.length - 1) {
                    return;
                }

                label.setAttribute('data-index', String(index + 1));
            });
        }, 1);
    }, []);

    return (
        <div className={styles.container}>
            <div
                className={classNames(styles.rate, {
                    [styles.embedContainer]: topPadding,
                })}
            >
                <Rating
                    icon={<StarIcon />}
                    emptyIcon={<StarIcon color="#EBECF2" />}
                    size="large"
                    disabled={disabled}
                    className={styles.star}
                    value={value}
                    onChange={onChange}
                    IconContainerComponent={({ value: val, ...props }) => {
                        return (
                            <span {...props} className={styles.starItem}>
                                {props.children}
                                <span className={styles.starLabel}>{val}</span>
                            </span>
                        );
                    }}
                />
            </div>
            <div className={styles.labels}>
                <Typography typo="caption_overline">{t('Not Satisfied')} </Typography>
                <Typography typo="caption_overline">{t('Very Satisfied')} </Typography>
            </div>
            {dividerPosition !== 'top' && <Divider type="fullWidth" />}
        </div>
    );
};

export default ReviewRate;
