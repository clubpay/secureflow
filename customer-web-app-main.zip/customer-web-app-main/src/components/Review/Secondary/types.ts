import { BehavioralTypeEnum } from '@/components/Review/Secondary/Behavioral/types';
import { FormTypeEnum } from '@/components/Review/Secondary/Form/types';
import { OrderTypeEnum } from '@/components/Review/Secondary/Order/types';
import { RedirectionTypeEnum } from '@/components/Review/Secondary/Redirection/types';

export enum RenderItemTypeEnum {
    Order = 'order',
    Behavioral = 'behavioral',
    Redirection = 'redirection',
    Form = 'form',
}

export type RenderItemServiceEnum = BehavioralTypeEnum | FormTypeEnum | OrderTypeEnum | RedirectionTypeEnum;

export interface IRenderOption {
    id: string;
    type: RenderItemTypeEnum;
    name: string;
    nameTranslations: any;
    service: RenderItemServiceEnum;
    meta: any;
    priority: number;
    done?: boolean;
}
