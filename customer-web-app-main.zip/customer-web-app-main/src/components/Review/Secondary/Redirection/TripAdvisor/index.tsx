import { useCallback, useEffect } from 'react';
import { Button } from '@qlub-dev/qlub-kit';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { IRenderOption } from '@/components/Review/Secondary/types';
import MultiLocale from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { ICommonProps } from '@/components/Review/Secondary';
import { IRedirectionConfig } from '@/components/Review/Secondary/Redirection';
import { reviewRedirect } from '@/components/Review/Secondary/utils';
import ReviewAPIManager from '@/repositories/review';
import { IReview } from '@/repositories/review/types';

import styles from './index.module.scss';

interface IProps extends ICommonProps {
    review: IReview;
    option: IRenderOption;
}

const TripAdvisor = ({ review, option, onDone }: IProps) => {
    const { t } = useTranslation('common');
    const { url, lang } = useQlubRouter();
    const { vendor } = useVendor();

    const config: IRedirectionConfig = option.meta;

    const redirect = useCallback(() => {
        ReviewAPIManager.getInstance()
            .submitActivity({
                url,
                reviewId: review?.id || '',
                configId: option.id,
                meta: {},
            })
            .then(() => {
                onDone(option.id);
                reviewRedirect(config.tripAdvisorUrl, config);
            });
    }, [config, vendor]);

    useEffect(() => {
        if (config.autoRedirection !== 'enable') {
            return;
        }

        redirect();
    }, [redirect]);

    const handleClick = useCallback(() => {
        redirect();
    }, [redirect]);

    return (
        <Button
            variant="outlined"
            color="primary"
            fullWidth
            onClick={handleClick}
            className={styles.button}
            disabled={config.autoRedirection === 'enable'}
            sx={{
                textDecoration: 'none',
            }}
        >
            <div className={styles.icon} />
            {option.name ? <MultiLocale value={option.name} lang={lang} /> : t('Review This Place')}
        </Button>
    );
};

export default TripAdvisor;
