export enum RedirectionTypeEnum {
    Google = 'google',
    TripAdvisor = 'trip_advisor',
    Foursquare = 'foursquare',
}
