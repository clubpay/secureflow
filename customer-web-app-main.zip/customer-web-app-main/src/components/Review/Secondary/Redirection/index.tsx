import { useMemo } from 'react';
import { IRenderOption } from '@/components/Review/Secondary/types';
import { RedirectionTypeEnum } from '@/components/Review/Secondary/Redirection/types';
import Google from '@/components/Review/Secondary/Redirection/Google';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IReview } from '@/repositories/review/types';
import { ICommonProps } from '@/components/Review/Secondary';
import TripAdvisor from '@/components/Review/Secondary/Redirection/TripAdvisor';
import Foursquare from '@/components/Review/Secondary/Redirection/Foursquare';

import styles from './index.module.scss';

export interface IRedirectionConfig {
    googlePlaceId?: string;
    foursquareUrl?: string;
    tripAdvisorUrl?: string;

    redirection?: 'sameTab' | 'newTab';
    autoRedirection?: 'enable' | 'disable' | 'star';
}

interface IProps extends ICommonProps {
    review: IReview;
    option: IRenderOption;
}

const Redirection = ({ review, option, onDone }: IProps) => {
    const { t } = useTranslation('common');

    const content = useMemo(() => {
        switch (option.service) {
            case RedirectionTypeEnum.Google:
                return <Google review={review} option={option} onDone={onDone} />;
            case RedirectionTypeEnum.TripAdvisor:
                return <TripAdvisor review={review} option={option} onDone={onDone} />;
            case RedirectionTypeEnum.Foursquare:
                return <Foursquare review={review} option={option} onDone={onDone} />;
            default:
                return t(`it's not supported`);
        }
    }, [option]);

    return <div className={styles.content}>{content}</div>;
};

export default Redirection;
