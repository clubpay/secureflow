import { IReview } from '@/repositories/review/types';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { transformConfigToRenderItems } from '@/components/Review/Secondary/utils';
import { IRenderOption, RenderItemTypeEnum } from '@/components/Review/Secondary/types';
import Order from '@/components/Review/Secondary/Order';
import Behavioral from '@/components/Review/Secondary/Behavioral';
import Redirection from '@/components/Review/Secondary/Redirection';
import Form from '@/components/Review/Secondary/Form';
import classNames from 'classnames';

import styles from './index.module.scss';

export type SubmitFnType = undefined | (() => Promise<PromiseSettledResult<Awaited<any>>[]>);

export interface ICommonProps {
    onDone: (id: string) => void;
    setSubmitFn?: (id: string, fn: any) => void;
    removeSubmitFn?: (id: string) => void;
    onSubmitting?: (id: string, submitting: boolean) => void;
}

interface IProps {
    review: IReview;
    onDone: () => void;
    onFinal: (final: boolean) => void;
    onSubmitting: (submitting: boolean) => void;
    setSubmitFn: (fn: SubmitFnType) => void;
    bottomMargin?: boolean;
}

const ReviewSecondary = ({ review, onDone, onFinal, onSubmitting, setSubmitFn, bottomMargin }: IProps) => {
    const [priority, setPriority] = useState(0);
    const [doneMap, setDoneMap] = useState<Record<string, boolean>>({});
    const [submitFnMap, setSubmitFnMap] = useState<Record<string, any>>({});
    const [submittingMap, setSubmittingMap] = useState<Record<string, boolean>>({});

    const items = useMemo<Record<string, IRenderOption[]>>(() => {
        if (!review.config) {
            return {};
        }

        return transformConfigToRenderItems(review.config);
    }, [review]);

    const list = useMemo(() => {
        const li = items[String(priority)];
        if (!li?.length) {
            return [];
        }

        return li.map((o) => ({
            ...o,
            done: doneMap[o.id] || false,
        }));
    }, [items, priority, doneMap]);

    useEffect(() => {
        if (list.length === 0 || !list.every((o) => o.done)) {
            return;
        }

        if (priority === Object.keys(items).length - 1) {
            onDone();
            return;
        }

        if (list[0]?.priority === undefined) {
            return;
        }

        setPriority(list[0].priority + 1);
    }, [list, priority]);

    useEffect(() => {
        onFinal(Object.keys(items).length - 1 <= priority);
    }, [items, priority]);

    const doneHandler = useCallback(
        (id: string) => {
            const item = list.find((o) => o.id === id);
            if (!item) {
                return;
            }

            setDoneMap((o) => ({
                ...o,
                [id]: true,
            }));
        },
        [list, items],
    );

    const setSubmitFnHandler = useCallback(
        (id: string, fn: any) => {
            setSubmitFnMap((o) => ({
                ...o,
                [id]: fn,
            }));
        },
        [items],
    );

    const removeSubmitFnHandler = useCallback(
        (id: string) => {
            setSubmitFnMap((o) => {
                delete o[id];
                return o;
            });
        },
        [items],
    );

    const submittingHandler = useCallback(
        (id: string, submitting: boolean) => {
            setSubmittingMap((o) => ({
                ...o,
                [id]: submitting,
            }));
        },
        [items],
    );

    const submitting = useMemo(() => {
        if (!Object.keys(items).length) {
            return false;
        }

        const values = Object.values(submittingMap);
        if (!values.length) {
            return false;
        }

        return values.includes(true);
    }, [items, submittingMap]);

    useEffect(() => {
        onSubmitting(submitting);
    }, [submitting]);

    const submitHandler = useCallback(() => {
        const entries = Object.entries(submitFnMap);
        if (!entries.length) {
            return Promise.allSettled([]);
        }

        return Promise.allSettled(
            entries.map(([id, fn]) => {
                return fn();
            }),
        );
    }, [items, submitFnMap]);

    useEffect(() => {
        return () => {
            setSubmitFn(undefined);
        };
    }, []);

    useEffect(() => {
        if (!Object.keys(items).length || !Object.keys(submitFnMap).length) {
            setSubmitFn(undefined);
            return;
        }

        setSubmitFn(submitHandler);
    }, [items, submitFnMap, submitHandler]);

    const content = useMemo(() => {
        return list.map((item) => {
            const props = {
                review,
                option: item,
                onDone: doneHandler,
                setSubmitFn: setSubmitFnHandler,
                removeSubmitFn: removeSubmitFnHandler,
                onSubmitting: submittingHandler,
            };
            switch (item.type) {
                case RenderItemTypeEnum.Order:
                    return (
                        <div className={styles.item} key={item.id}>
                            <Order {...props} />
                        </div>
                    );
                case RenderItemTypeEnum.Behavioral:
                    return (
                        <div className={styles.item} key={item.id}>
                            <Behavioral {...props} />
                        </div>
                    );
                case RenderItemTypeEnum.Redirection:
                    return (
                        <div className={styles.item} key={item.id}>
                            <Redirection {...props} />
                        </div>
                    );
                case RenderItemTypeEnum.Form:
                    return (
                        <div className={styles.item} key={item.id}>
                            <Form {...props} />
                        </div>
                    );
                default:
                    return null;
            }
        });
    }, [list, doneHandler, setSubmitFnHandler, removeSubmitFnHandler]);

    return <div className={classNames(styles.container, { [styles.bottomMargin]: bottomMargin })}>{content}</div>;
};

export default ReviewSecondary;
