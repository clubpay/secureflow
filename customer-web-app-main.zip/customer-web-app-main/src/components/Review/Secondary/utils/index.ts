import { IConfig, IConfigItem } from '@/repositories/review/types';
import { groupBy } from 'lodash';
import { IRenderOption, RenderItemServiceEnum, RenderItemTypeEnum } from '@/components/Review/Secondary/types';
import { parseJSON } from '@clubpay/customer-common-module/src/utility/k_json';
import { IRedirectionConfig } from '@/components/Review/Secondary/Redirection';
import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor/type';

export const transformConfigToRenderItems = (config: IConfig): Record<string, IRenderOption[]> => {
    const items: IRenderOption[] = [];
    const getCommonItem = (item: IConfigItem): Omit<IRenderOption, 'type'> => {
        return {
            id: item.id,
            name: item.name,
            nameTranslations: item.nameTranslations,
            service: item.service as RenderItemServiceEnum,
            meta: item.meta,
            priority: Number(item.meta?.priority || 0) || 0,
        };
    };
    config.orderItems?.forEach((item) => {
        items.push({
            type: RenderItemTypeEnum.Order,
            ...getCommonItem(item),
        });
    });
    config.behavioralItems?.forEach((item) => {
        items.push({
            type: RenderItemTypeEnum.Behavioral,
            ...getCommonItem(item),
        });
    });
    config.formItems?.forEach((item) => {
        items.push({
            type: RenderItemTypeEnum.Form,
            ...getCommonItem(item),
        });
    });
    config.redirectionItems?.forEach((item) => {
        items.push({
            type: RenderItemTypeEnum.Redirection,
            ...getCommonItem(item),
        });
    });
    const list = groupBy(items, (o) => o.priority);
    return Object.keys(list)
        .map((o) => Number(o))
        .sort()
        .reduce<Record<string, IRenderOption[]>>((acc, curr, idx) => {
            acc[idx] = list[curr].map((item) => ({
                ...item,
                priority: idx,
            }));
            return acc;
        }, {});
};

export const convertMapType = (data: string): any | { [key: string]: string } => {
    const parsedObj = parseJSON(data);
    if (parsedObj && Array.isArray(parsedObj)) {
        return parsedObj.reduce((acc, curr) => {
            acc[curr.key] = curr.value;
            return acc;
        }, {});
    }
    return data;
};

export const getGoogleReviewLink = (placeId: string) => {
    return `https://search.google.com/local/writereview?placeid=${placeId}`;
};

export const reviewRedirect = (url: string | undefined, config: IRedirectionConfig) => {
    if (!url) {
        return;
    }

    setTimeout(() => {
        if (config.redirection === 'sameTab') {
            window.location.href = url;
            return;
        }

        window.open(url, '_blank');
    }, 100);
};

export const googleRedirect = (config: IRedirectionConfig, vendor: IRestaurant | undefined) => {
    const url = getGoogleReviewLink(config.googlePlaceId || vendor?.googlePlaceId || '');
    reviewRedirect(url, config);
};

export const hasAutoRedirectionOnStar = (res: any): [IConfigItem | undefined, IRedirectionConfig | undefined] => {
    const item = res.config?.redirectionItems?.find(
        (o: any) => (o.meta as IRedirectionConfig).autoRedirection === 'star',
    );
    return [item, item?.meta];
};
