import { IRenderOption } from '@/components/Review/Secondary/types';
import { ICommonProps } from '@/components/Review/Secondary';

interface IProps extends ICommonProps {
    option: IRenderOption;
}

const Waiter = ({ option }: IProps) => {
    return <>{option}</>;
};

export default Waiter;
