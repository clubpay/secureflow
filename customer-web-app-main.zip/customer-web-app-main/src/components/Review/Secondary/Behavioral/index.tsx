import { useMemo } from 'react';
import { IRenderOption } from '@/components/Review/Secondary/types';
import { BehavioralTypeEnum } from '@/components/Review/Secondary/Behavioral/types';
import Waiter from '@/components/Review/Secondary/Behavioral/Waiter';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IReview } from '@/repositories/review/types';
import { ICommonProps } from '@/components/Review/Secondary';

interface IProps extends ICommonProps {
    review: IReview;
    option: IRenderOption;
}

const Behavioral = ({ option, onDone }: IProps) => {
    const { t } = useTranslation('common');

    const content = useMemo(() => {
        switch (option.service) {
            case BehavioralTypeEnum.Waiter:
                return <Waiter option={option} onDone={onDone} />;
            default:
                return t(`it's not supported`);
        }
    }, [option]);

    return <>{content}</>;
};

export default Behavioral;
