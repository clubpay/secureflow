export enum BehavioralTypeEnum {
    Waiter = 'waiter',
}
