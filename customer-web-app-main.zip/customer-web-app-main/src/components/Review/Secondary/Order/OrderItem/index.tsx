import { IRenderOption } from '@/components/Review/Secondary/types';
import { IPaymentDetails } from '@/repositories/bill';
import React, { useState } from 'react';
import { Button, InvoiceItem } from '@qlub-dev/qlub-kit';
import { useBillItemTranslation, useOrderItemTranslation } from '@/components/Bill/InvoiceItem/hooks/translations_hook';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import StarIcon from '@/components/Review/icons/StarIcon';
import Rating from '@mui/material/Rating';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { ICommonProps } from '@/components/Review/Secondary';

import styles from './index.module.scss';

interface IProps extends ICommonProps {
    option: IRenderOption;
    details: IPaymentDetails | undefined;
}

const OrderItem = ({ details }: IProps) => {
    const { t } = useTranslation('common');
    const { lang } = useQlubRouter();
    const { currencyFormat } = useVendor();
    const [rateMap, setRateMap] = useState<Record<number, number>>({});

    return (
        <div className={styles.container}>
            <div className={styles.items}>
                {details?._orderItems?.map((order, orderIndex) => {
                    const value = rateMap[orderIndex] || 0;

                    const changeHandler = (e: React.SyntheticEvent, val: number | null) => {
                        setRateMap((o) => ({
                            ...o,
                            [orderIndex]: val || 0,
                        }));
                    };

                    return (
                        <div key={`${orderIndex}`} className={styles.item}>
                            <div className={styles.label}>
                                <InvoiceItem
                                    val={order.item}
                                    currencyFormat={{
                                        ...currencyFormat,
                                        currencyPrecision:
                                            details?.currencyPrecision || currencyFormat?.currencyPrecision,
                                    }}
                                    lang={lang}
                                    type="split"
                                    selected={false}
                                    useBillItemTranslation={useBillItemTranslation}
                                    useOrderItemTranslation={useOrderItemTranslation}
                                />
                            </div>
                            <div className={styles.rate}>
                                <Rating
                                    icon={<StarIcon />}
                                    emptyIcon={<StarIcon color="#EBECF2" />}
                                    size="small"
                                    value={value}
                                    onChange={changeHandler}
                                />
                            </div>
                        </div>
                    );
                })}
            </div>
            <div className={styles.footer}>
                <Button type="submit" variant="contained" color="primary" sx={{ mt: 3 }} fullWidth>
                    {t('Submit')}
                </Button>
            </div>
        </div>
    );
};

export default OrderItem;
