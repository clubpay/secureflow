import { useEffect, useMemo, useState } from 'react';
import { IRenderOption } from '@/components/Review/Secondary/types';
import { OrderTypeEnum } from '@/components/Review/Secondary/Order/types';
import OrderItem from '@/components/Review/Secondary/Order/OrderItem';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { getDiningSession, getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import BillAPIManager, { IPaymentDetails } from '@/repositories/bill';
import { QSRRouterModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { IReview } from '@/repositories/review/types';
import { ICommonProps } from '@/components/Review/Secondary';
import { FetchModeEnum } from '@/repositories/bill/enums';

interface IProps extends ICommonProps {
    review: IReview;
    option: IRenderOption;
}

const Order = ({ option, onDone }: IProps) => {
    const { t } = useTranslation('common');
    const { url, isQSR } = useQlubRouter();
    const { vendor } = useVendor();

    const [details, setDetails] = useState<IPaymentDetails | undefined>(undefined);

    useEffect(() => {
        if (!url || !vendor) {
            return;
        }

        const diningSessionPayload = getDiningSession(url);
        BillAPIManager.getInstance()
            .getDetails(
                {
                    id: getSession(),
                    diningSessionID: diningSessionPayload?.id || '0',
                    cc: url.cc,
                    restaurantUnique: url.slug,
                    tableID: url.id,
                    f1: url.f1,
                    f2: url.f2,
                    hash: url.hash,
                    forceFresh: false,
                    jwt: diningSessionPayload?.jwt || undefined,
                    fetchMode: url.fetchMode as FetchModeEnum,
                    payUrl: url.qPayUrl,
                },
                {
                    cc: url.cc,
                    vendor,
                    qsr: isQSR && url.qsr !== QSRRouterModeEnum.Mixed,
                },
            )
            .then((res) => {
                setDetails(res);
            });
    }, [url, vendor]);

    const content = useMemo(() => {
        switch (option.service) {
            case OrderTypeEnum.OrderItem:
                return <OrderItem option={option} details={details} onDone={onDone} />;
            default:
                return t(`it's not supported`);
        }
    }, [option, details]);

    return <>{content}</>;
};

export default Order;
