export enum FormTypeEnum {
    UserInfo = 'user_info',
}
