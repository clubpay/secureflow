import { useMemo } from 'react';
import { IRenderOption } from '@/components/Review/Secondary/types';
import { FormTypeEnum } from '@/components/Review/Secondary/Form/types';
import UserInfo from '@/components/Review/Secondary/Form/UserInfo';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IReview } from '@/repositories/review/types';
import { ICommonProps } from '@/components/Review/Secondary';

interface IProps extends ICommonProps {
    review: IReview;
    option: IRenderOption;
}

const Form = ({ review, option, onDone, setSubmitFn, removeSubmitFn, onSubmitting }: IProps) => {
    const { t } = useTranslation('common');

    const content = useMemo(() => {
        switch (option.service) {
            case FormTypeEnum.UserInfo:
                return (
                    <UserInfo
                        review={review}
                        option={option}
                        onDone={onDone}
                        setSubmitFn={setSubmitFn}
                        removeSubmitFn={removeSubmitFn}
                        onSubmitting={onSubmitting}
                    />
                );
            default:
                return t(`it's not supported`);
        }
    }, [option]);

    return <>{content}</>;
};

export default Form;
