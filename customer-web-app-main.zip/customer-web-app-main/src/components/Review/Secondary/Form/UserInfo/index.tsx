import { IRenderOption } from '@/components/Review/Secondary/types';
import React, { useCallback, useEffect, useMemo } from 'react';
// @ts-ignore
import { ObjectSchemaConstructor } from 'yup';
import * as Yup from 'yup';
import MultiLocale from '@clubpay/customer-common-module/src/component/MultiLocale';
import { FastField, FieldProps, FormikProvider, useFormik } from 'formik';
import { Grid, TextField } from '@mui/material';
import PhoneInputV2 from '@clubpay/customer-common-module/src/component/PhoneInputV2';
import { FormikHelpers } from 'formik/dist/types';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { convertMapType } from '@/components/Review/Secondary/utils';
import { IReview } from '@/repositories/review/types';
import ReviewAPIManager from '@/repositories/review';
import { ICommonProps } from '@/components/Review/Secondary';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';

import styles from './index.module.scss';

export enum UserInfoKeyEnum {
    Name = 'name',
    Phone = 'phone',
    Address = 'address',
    Email = 'email',
}

interface IUserInfoConfig {
    userInfoTitle: string;
    userInfoFields: UserInfoKeyEnum[];
    userInfoRequiredFields: string[];
    userInfoExtraFields: { [key: string]: string };
}

interface IProps extends ICommonProps {
    review: IReview;
    option: IRenderOption;
    initData?: any;
}

const UserInfo = ({ review, option, initData, onDone, setSubmitFn, removeSubmitFn, onSubmitting }: IProps) => {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const { url, lang } = useQlubRouter();

    const [config, extraFieldMap, extraFieldKeys] = useMemo(() => {
        const cnf: IUserInfoConfig = {
            userInfoTitle: option.meta.userInfoTitle,
            userInfoFields: option.meta.userInfoFields,
            userInfoRequiredFields: option.meta.userInfoRequiredFields,
            userInfoExtraFields: convertMapType(option.meta.userInfoExtraFields),
        };
        const dd = Object.keys(cnf.userInfoExtraFields || {}).reduce<string[]>((acc, key) => {
            if (!key) {
                return acc;
            }
            acc.push(key);
            return acc;
        }, []);
        return [cnf, cnf.userInfoExtraFields || {}, dd.sort()];
    }, [option]);

    const validationSchema = useMemo(() => {
        const fields =
            config.userInfoFields?.reduce<ObjectSchemaConstructor>((acc, curr) => {
                switch (curr) {
                    default:
                    case UserInfoKeyEnum.Name:
                    case UserInfoKeyEnum.Phone:
                    case UserInfoKeyEnum.Address:
                        acc[curr] = Yup.string();
                        break;
                    case UserInfoKeyEnum.Email:
                        acc[curr] = Yup.string().email();
                        break;
                }
                if (config.userInfoRequiredFields?.includes(curr)) {
                    if (curr === UserInfoKeyEnum.Phone) {
                        acc[curr] = acc[curr].min(9, t('invalid phone number'));
                    }
                    acc[curr] = acc[curr].required();
                }
                return acc;
            }, {}) || {};
        if (extraFieldKeys.length === 0) {
            return Yup.object(fields);
        }

        return Yup.object(
            extraFieldKeys.reduce<ObjectSchemaConstructor>((acc, key) => {
                acc[key] = Yup.string();
                return acc;
            }, fields),
        );
    }, [config, extraFieldKeys]);

    const initialValues = useMemo(() => {
        const fields =
            config.userInfoFields?.reduce<{ [key: string]: string }>((acc, curr) => {
                acc[curr] = initData?.[curr] || '';
                return acc;
            }, {}) || {};
        if (extraFieldKeys.length === 0) {
            return fields;
        }

        return extraFieldKeys.reduce<{ [key: string]: string }>((acc, key) => {
            acc[key] = initData?.[key] || '';
            return acc;
        }, fields);
    }, [initData, extraFieldKeys]);

    const submitHandler = useCallback(
        (values: any, formikHelpers: FormikHelpers<any>) => {
            formikHelpers.validateForm().then(() => {
                onSubmitting?.(option.id, true);
                formikHelpers.setSubmitting(true);
                ReviewAPIManager.getInstance()
                    .submitActivity({
                        url,
                        reviewId: review.id,
                        configId: option.id,
                        meta: {
                            ...values,
                        },
                    })
                    .then(() => {
                        onDone(option.id);
                    })
                    .catch((err) => {
                        enqueueSnackbar(err?.message || t('Something went wrong'), { variant: 'error' });
                    })
                    .finally(() => {
                        formikHelpers.setSubmitting(false);
                        onSubmitting?.(option.id, false);
                    });
            });
        },
        [review, option],
    );

    const formik = useFormik({
        initialValues,
        validationSchema,
        onSubmit: submitHandler,
    });

    const getLabel = (fieldName: string) => {
        switch (fieldName) {
            case UserInfoKeyEnum.Name:
                return t('Name');
            case UserInfoKeyEnum.Email:
                return t('Email');
            case UserInfoKeyEnum.Phone:
                return t('Phone');
            case UserInfoKeyEnum.Address:
                return t('Address');
            default:
                if (extraFieldMap.hasOwnProperty(fieldName)) {
                    return <MultiLocale value={extraFieldMap[fieldName]} lang={lang} />;
                }
                return '';
        }
    };

    const fieldRenderer = (fieldName: string, { field, meta, form }: FieldProps) => {
        const disabled = false;
        switch (fieldName) {
            default:
            case UserInfoKeyEnum.Name:
            case UserInfoKeyEnum.Email:
            case UserInfoKeyEnum.Address:
                return (
                    <TextField
                        {...field}
                        fullWidth
                        disabled={disabled}
                        type="text"
                        label={getLabel(fieldName)}
                        variant="outlined"
                        dir={fieldName === UserInfoKeyEnum.Email ? 'ltr' : undefined}
                        multiline={fieldName === UserInfoKeyEnum.Address}
                        minRows={fieldName === UserInfoKeyEnum.Address ? 3 : undefined}
                        error={!!meta.error && meta.touched}
                        helperText={meta.touched && meta.error}
                    />
                );
            case UserInfoKeyEnum.Phone:
                return (
                    <PhoneInputV2
                        placeholder={getLabel(fieldName)}
                        lang={lang}
                        defaultCountry={url?.cc || ''}
                        value={field.value}
                        onChange={(data) => {
                            form.setFieldValue(UserInfoKeyEnum.Phone, data.phone);
                        }}
                        validation={{
                            enable: true,
                        }}
                        errorText={t('Please enter a valid phone number!')}
                        countrySearchLabel={t('Search for countries')}
                    />
                );
        }
    };

    const getContent = () => {
        return [...(config.userInfoFields || []), ...extraFieldKeys]?.map((fieldName) => {
            return (
                <Grid key={fieldName} item xs={12}>
                    <FastField name={fieldName}>{(props: FieldProps) => fieldRenderer(fieldName, props)}</FastField>
                </Grid>
            );
        });
    };

    useEffect(() => {
        if (!setSubmitFn) {
            return () => {
                //
            };
        }

        setSubmitFn(option.id, formik.submitForm);
        return () => {
            removeSubmitFn?.(option.id);
        };
    }, [option]);

    if (!config.userInfoFields?.length && extraFieldKeys.length === 0) {
        return null;
    }

    return (
        <div className={styles.container}>
            <FormikProvider value={formik}>
                <form key={lang}>
                    <div className={styles.title}>
                        <MultiLocale value={config?.userInfoTitle || ''} lang={lang} />
                    </div>
                    <div className={styles.form}>
                        <Grid container spacing={2}>
                            {getContent()}
                        </Grid>
                    </div>
                </form>
            </FormikProvider>
        </div>
    );
};

export default UserInfo;
