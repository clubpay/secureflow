import { Divider, Typography } from '@qlub-dev/qlub-kit';
import GoogleReviewWidget from '@/components/Bill/GoogleReviewWidget';
import React from 'react';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';

import styles from './index.module.scss';

export interface IProps {
    vendorGateway: string;
    dividerPosition?: 'top' | 'bottom';
}

const GoogleReview = ({ vendorGateway, dividerPosition }: IProps) => {
    const { vendor } = useVendor();
    const { t } = useTranslation('common');
    const { query } = useQlubRouter();

    return (
        <>
            {dividerPosition === 'top' && <Divider />}
            <div className={styles.feedback}>
                <Typography typo="title_md" className={styles.feedbackQuestion}>
                    {t('How was your dining experience?')}
                </Typography>
                <div className={styles.review}>
                    {vendor && vendor.googlePlaceId && (
                        <GoogleReviewWidget
                            placeId={vendor.googlePlaceId}
                            opsMode={vendor.opsMode || ''}
                            pgName={`${vendorGateway}_${query.paymentElement}`.toLowerCase()}
                        />
                    )}
                </div>
            </div>
            {dividerPosition !== 'top' && <Divider />}
        </>
    );
};

export default GoogleReview;
