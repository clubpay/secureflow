import Review, { AutoOpenEnum } from '@/components/Review/Main';

export interface IProps {
    show: boolean | undefined;
    dividerPosition?: 'top' | 'bottom';
    autoOpen?: AutoOpenEnum;
    defaultDsi?: string;
}

const ReviewWrapper = ({ show, dividerPosition, autoOpen, defaultDsi }: IProps) => {
    if (!show) {
        return null;
    }

    return <Review dividerPosition={dividerPosition} autoOpen={autoOpen} defaultDsi={defaultDsi} />;
};

export default ReviewWrapper;
