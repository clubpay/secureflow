import HeartIcon from '@/assets/images/icons/heart';
import Typography from '@qlub-dev/qlub-kit/dist/components/Typography';
import { Divider } from '@qlub-dev/qlub-kit';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

import styles from './index.module.scss';

interface IProps {
    dividerPosition?: 'top' | 'bottom';
}

const ReviewThankYou = ({ dividerPosition }: IProps) => {
    const { t } = useTranslation('common');

    return (
        <>
            {dividerPosition === 'top' && <Divider type="fullWidth" />}
            <div className={styles.container}>
                <span>
                    <HeartIcon />
                </span>
                <Typography typo="body_sm">
                    <strong>{`${t('Awesome')}, `}</strong>
                    {t('Thanks for your feedback!')}
                </Typography>
            </div>
            {dividerPosition !== 'top' && <Divider type="fullWidth" />}
        </>
    );
};

export default ReviewThankYou;
