import React from 'react';
import { IconButton, SwipeableDrawer } from '@mui/material';
import { CloseRounded } from '@mui/icons-material';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Button, Divider, Typography } from '@qlub-dev/qlub-kit';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import { ScheduledOrderEnum, IScheduledTime } from '../QSRScheduledOrder';

import styles from './index.module.scss';

interface QSRAsapConfirmProps {
    open: boolean;
    setOpen: (open: boolean) => void;
    setSchedule: (value: IScheduledTime) => void;
}

const QSRAsapConfirm = ({ open, setOpen, setSchedule }: QSRAsapConfirmProps) => {
    const { t } = useTranslation('common');
    const {
        qsr: { qsrScheduledCancelled },
    } = useQsrEventsCenter();
    const closeHandler = () => {
        setOpen(false);
    };
    const onChangeToAsapClick = () => {
        setSchedule({ type: ScheduledOrderEnum.ASAP });
        qsrScheduledCancelled();
        closeHandler();
    };
    return (
        <SwipeableDrawer
            anchor="bottom"
            open={open}
            onClose={closeHandler}
            onOpen={() => {
                setOpen(true);
            }}
            BackdropProps={{ sx: { background: '#00000099' } }}
            PaperProps={{
                sx: {
                    maxWidth: '552px',
                    minHeight: '200px',
                    margin: '0 auto',
                    background: '#fff',
                    borderRadius: '30px 30px 0 0',
                },
            }}
        >
            <div className={styles.container}>
                <div className={styles.content}>
                    <div className={styles.header}>
                        <div className={styles.title}>
                            <Typography typo="headline_sm" className={styles.titleText}>
                                {t('Change to ASAP pickup')}
                            </Typography>
                            <IconButton sx={{ padding: '0px' }} onClick={closeHandler}>
                                <CloseRounded />
                            </IconButton>
                        </div>
                        <Typography typo="caption_overline" className={styles.subTitleText}>
                            {interpolateT(t('Are you sure you want to change from <scheduled> method to <asap> ?'), {
                                scheduled: <span className={styles.innerText}>{t('scheduled pickup')}</span>,
                                asap: <span className={styles.innerText}>{t('ASAP pickup')}</span>,
                            })}
                        </Typography>
                    </div>
                    <Divider />
                    <div className={styles.buttonGroup}>
                        <Button variant="contained" onClick={onChangeToAsapClick}>
                            {t('Yes, Change to ASAP pickup')}
                        </Button>
                        <Button variant="containedLight" onClick={closeHandler}>
                            {t('Cancel')}
                        </Button>
                    </div>
                </div>
            </div>
        </SwipeableDrawer>
    );
};

export default QSRAsapConfirm;
