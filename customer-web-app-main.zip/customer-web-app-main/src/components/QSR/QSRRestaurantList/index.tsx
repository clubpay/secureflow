import React, { useCallback, useEffect, useMemo, useState } from 'react';
import Fuse, { IFuseOptions } from 'fuse.js';
import { orderBy } from 'lodash';
import {
    EmbedModeEnum,
    getQsrRouteParamFromMode,
    IQlubParams,
    useQlubRouter,
} from '@clubpay/customer-common-module/src/hook/router';
import { ThemeModeEnum } from '@clubpay/customer-common-module/src/context/config';
import { OrderModeEnum, IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor';
import { useBasket } from '@/contexts/basket';
import QSRConfirmationDrawer from '@/components/QSR/QSRConfirmationDrawer';
import { resetDiningOption } from '@/components/QSR/QSRDiningOptionModal';
import QSRRestaurantItem from '@/components/QSR/QSRRestaurantItem';
import QSRRestaurantSimpleItem from '@/components/QSR/QSRSimpleRestaurantItem';
import QSRSocialLandingFilterArea from '@/components/QSR/QSRSocialLandingFilterArea';
import { ISocialMenu } from '@/repositories/menu/types';
import { removeSSBasket, getSSBasket } from '@/services/session/basket';
import { trimPathnameForEmbed } from '@/services/utils/k_qsr';
import { calculateOrderCount } from '@/services/utils/k_order';
import Skeleton from './Skeleton';

import styles from './index.module.scss';

enum SortEnum {
    ASC = 'asc',
    DESC = 'desc',
}

interface IFilterOptions {
    searchTerm?: string;
    sort?: SortEnum;
}

const filterAndSort = (
    list: ISocialMenu[],
    fuse: Fuse<ISocialMenu> | undefined,
    options: IFilterOptions,
): ISocialMenu[] => {
    const getSearch = () => {
        if (!fuse || !options.searchTerm) {
            return list;
        }
        return fuse.search(options.searchTerm).map((o) => o.item);
    };
    return orderBy(
        getSearch(),
        [
            (o) => {
                return o.name?.toLowerCase() || '';
            },
        ],
        options.sort === SortEnum.ASC ? ['asc'] : ['desc'],
    );
};

interface IProps {
    list: ISocialMenu[];
    loading: boolean;
    vendor: IRestaurant | undefined;
}

const QSRRestaurantList = ({ list, loading, vendor }: IProps) => {
    const { url, routerPush, pathname } = useQlubRouter();
    const [filteredList, setFilteredList] = useState<ISocialMenu[]>([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedVendor, setSelectedVendor] = useState<ISocialMenu | undefined>();
    const [basketRestaurantName, setBasketRestaurantName] = useState<string | undefined>();
    const [basketItemCount, setBasketItemCount] = useState<number | undefined>();
    const [sort, setSort] = useState<SortEnum>(SortEnum.ASC);
    const { basket, setBasket } = useBasket();
    const [drawerOpen, setDrawerOpen] = useState(false);

    const embedVendor = url.embed === EmbedModeEnum.Vendor;

    const basketOrderCount = useMemo(
        () =>
            calculateOrderCount(basket, {
                vendor,
                isEmbedVendor: embedVendor,
            }),
        [basket, vendor, embedVendor],
    );

    const fuse = useMemo(() => {
        if (!list.length) {
            return;
        }
        const fuseOptions: IFuseOptions<ISocialMenu> = {
            isCaseSensitive: false,
            keys: ['name'],
        };
        return new Fuse(list, fuseOptions);
    }, [list]);

    useEffect(() => {
        setFilteredList(filterAndSort(list, fuse, { sort, searchTerm }));
    }, [fuse, searchTerm, sort]);

    const handleSearch = useCallback((term: string) => {
        setSearchTerm(term);
    }, []);

    const handleSortToggle = useCallback(() => {
        setSort((o) => (o === SortEnum.ASC ? SortEnum.DESC : SortEnum.ASC));
    }, []);

    const redirect = (item: ISocialMenu, force?: boolean) => {
        if (
            !force &&
            basketOrderCount !== 0 &&
            basket.vendorId.cc &&
            basket.vendorId.slug &&
            (basket.vendorId.cc !== item.cc || basket.vendorId.slug !== item.slug)
        ) {
            setSelectedVendor(item);
            setBasketRestaurantName(
                list.find((o) => o.cc === basket.vendorId.cc && o.slug === basket.vendorId.slug)?.name,
            );
            setBasketItemCount(basketOrderCount);
            setDrawerOpen(true);
            return;
        }
        const routeParams: IQlubParams = {
            cc: item.params.cc,
            slug: item.params.slug,
            id: item.params.id,
            f1: item.params.f1,
            f2: item.params.f2,
            hash: item.params.hash,
        };
        if (item.config.themeMode) {
            routeParams.theme = item.config.themeMode as ThemeModeEnum;
        }
        const qsrParam = getQsrRouteParamFromMode(item.orderMode);
        if (qsrParam) {
            routeParams.qsr = qsrParam;
        }

        return routerPush(
            item.orderMode === OrderModeEnum.QSR
                ? trimPathnameForEmbed('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr', pathname)
                : '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]',
            routeParams,
        );
    };

    const handleContinue = () => {
        if (!selectedVendor) {
            return;
        }
        resetDiningOption();
        removeSSBasket();
        setBasket(getSSBasket());
        redirect(selectedVendor, true);
    };

    const getContent = () => {
        if (loading) {
            return <Skeleton childrenNumber={3} />;
        }

        const isSimpleView = vendor?.config?.socialDiningView === 'v2';

        return (
            <>
                <div className={styles.scroll}>
                    {filteredList?.map((item, index) =>
                        isSimpleView ? (
                            <QSRRestaurantSimpleItem
                                key={item.id || index}
                                item={item}
                                onClick={(val) => {
                                    redirect(val);
                                }}
                            />
                        ) : (
                            <QSRRestaurantItem
                                key={item.id || index}
                                index={index}
                                item={item}
                                onClick={(val) => {
                                    redirect(val);
                                }}
                            />
                        ),
                    )}
                </div>
            </>
        );
    };

    return (
        <div className={styles.container} style={{ position: 'relative' }}>
            <QSRSocialLandingFilterArea onSearch={handleSearch} onSortToggle={handleSortToggle} />
            {getContent()}
            <QSRConfirmationDrawer
                onClose={() => setDrawerOpen(false)}
                open={drawerOpen}
                name={basketRestaurantName}
                count={basketItemCount}
                onContinue={handleContinue}
            />
        </div>
    );
};

export default QSRRestaurantList;
