import { Skeleton } from '@mui/material';

import styles from '../index.module.scss';

interface ISkeletonComponentSingleProps {
    childrenNumber?: number;
}

const SkeletonComponentSingle = ({ childrenNumber }: ISkeletonComponentSingleProps) => {
    return (
        <div className={styles.skeleton}>
            {Array.from({
                length: childrenNumber || 0,
            }).map((value, index) => (
                <div key={index} className={styles.skeletonItem}>
                    <Skeleton variant="rounded" height={232} />
                    <div className={styles.skeletonLogoBg}>
                        <Skeleton variant="rectangular" className={styles.logo} width={64} height={64} />
                    </div>
                </div>
            ))}
        </div>
    );
};

export default SkeletonComponentSingle;
