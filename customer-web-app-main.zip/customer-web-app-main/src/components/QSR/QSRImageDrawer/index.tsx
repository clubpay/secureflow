import { useCallback, useRef } from 'react';
import { Drawer } from '@mui/material';
import QuickPinchZoom, { make3dTransformValue } from 'react-quick-pinch-zoom';
import { KImage } from '@qlub-dev/qlub-kit';
import CloseButton from '@/components/QSR/QSRCloseButton';

import styles from './index.module.scss';

interface QSRImageDrawerProps {
    open: boolean;
    onClose: () => void;
    selectedImage?: { thumb: string | undefined; original: string | undefined };
}

const QSRImageDrawer = ({ open, onClose, selectedImage }: QSRImageDrawerProps) => {
    const imgRef: any = useRef(null);
    const updateHandler = useCallback(({ x, y, scale }) => {
        if (imgRef) {
            imgRef?.current?.style.setProperty('transform', make3dTransformValue({ x, y, scale }));
        }
    }, []);

    return (
        <Drawer
            anchor="top"
            open={open}
            onClose={onClose}
            transitionDuration={100}
            BackdropProps={{ sx: { background: '#00000099' } }}
            PaperProps={{
                elevation: 0,
                sx: {
                    height: 'calc((var(--vh, 1vh) * 100))',
                    maxWidth: '552px',
                    margin: 'auto',
                    background: 'white',
                    overflow: 'hidden',
                    backgroundColor: '#000000cc',
                },
            }}
        >
            <div className={styles.main}>
                <CloseButton onClose={onClose} variant="light" />
                <QuickPinchZoom onUpdate={updateHandler} zoomOutFactor={10} animationDuration={0} inertiaFriction={0}>
                    <KImage
                        innerRef={imgRef}
                        src={selectedImage?.original || selectedImage?.thumb}
                        alt="Product Image"
                        className={styles.productImage}
                        maxSize={400}
                    />
                </QuickPinchZoom>
            </div>
        </Drawer>
    );
};

export default QSRImageDrawer;
