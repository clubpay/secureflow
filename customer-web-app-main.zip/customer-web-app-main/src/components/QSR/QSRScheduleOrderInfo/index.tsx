import { Typography } from '@qlub-dev/qlub-kit';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useTheme } from '@mui/material';
import { format } from 'date-fns';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useMemo } from 'react';
import DateService from '@clubpay/customer-common-module/src/service/date';
import { DateEnum } from '@/components/QSR/QSRDateTimePicker';
import { IScheduledTime, ScheduledOrderEnum } from '@/components/QSR/QSRScheduledOrder';
import DeliveryOrderIcon from '@/components/Common/Icons/DeliveryOrderIcon';
import QSRDay from '@/components/QSR/QSRDay';

import styles from './index.module.scss';

interface IProps {
    pickupAt: Date | string | null | undefined;
}

const QSRScheduledOrderInfo = ({ pickupAt }: IProps) => {
    const { t } = useTranslation('common');
    const { lang } = useQlubRouter();
    const { vendor } = useVendor();
    const theme = useTheme();

    const scheduledOrder: IScheduledTime | undefined = useMemo(() => {
        if (!pickupAt) {
            return undefined;
        }

        const now = new Date();
        const pickDate = new Date(pickupAt || '');
        const differenceDay = pickDate.getDay() - now.getDay();
        const start = ((pickDate.getHours() || 0) * 60 + (pickDate.getMinutes() || 0)) * 60;
        const end = start + (vendor?.orderConfig?.scheduledOrderOptionGap || 15) * 60;
        let date: DateEnum = DateEnum.Today;
        switch (differenceDay) {
            case 1:
                date = DateEnum.Tomorrow;
                break;
            case 2:
                date = DateEnum.NextDay;
                break;
            default:
        }

        return {
            type: pickupAt ? ScheduledOrderEnum.Scheduled : ScheduledOrderEnum.ASAP,
            value: {
                date,
                timePeriod: {
                    start: DateService.getInstance().getTime(start),
                    end: DateService.getInstance().getTime(end),
                },
            },
        };
    }, [pickupAt]);

    const currentDay = useMemo(() => {
        return format(new Date(), lang === 'ja' ? 'yyyy/MM/dd' : 'dd/MM/yyyy');
    }, [lang]);

    return (
        <div className={styles.container}>
            <DeliveryOrderIcon />
            <div className={styles.content}>
                <Typography typo="caption_overline" sx={{ color: theme.qlub.palette.onSurfaceColors.mediumEmphasis }}>
                    {t('Pick-up at {{name}}', {
                        name: vendor?.name || '',
                    })}
                </Typography>
                <Typography typo="title_md" sx={{ color: theme.qlub.palette.onSurfaceColors.highEmphasis }}>
                    {scheduledOrder?.type === ScheduledOrderEnum.Scheduled
                        ? t('You scheduled your order')
                        : t('Pickup your order ASAP')}
                </Typography>
                <Typography typo="caption_overline" sx={{ color: theme.qlub.palette.onSurfaceColors.highEmphasis }}>
                    {scheduledOrder?.type === ScheduledOrderEnum.Scheduled
                        ? interpolateT(
                              t('Pickup your order <date>, {{start}} to {{end}}', {
                                  start: scheduledOrder.value?.timePeriod?.start || '',
                                  end: scheduledOrder.value?.timePeriod?.end || '',
                              }),
                              {
                                  date: <QSRDay lang={lang} day={scheduledOrder.value?.date} />,
                              },
                          )
                        : interpolateT(t('Today, <day>'), {
                              day: currentDay,
                          })}
                </Typography>
            </div>
        </div>
    );
};

export default QSRScheduledOrderInfo;
