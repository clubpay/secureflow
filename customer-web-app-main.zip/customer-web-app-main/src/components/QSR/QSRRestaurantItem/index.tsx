import React from 'react';
import { Typography, Box } from '@mui/material';
import { ISocialMenu } from '@/repositories/menu/types';
import classNames from 'classnames';
import { useQsrColors } from '@/hooks/qsrColors';

import styles from './index.module.scss';

interface IProps {
    index: number;
    item: ISocialMenu;
    onClick: (item: ISocialMenu, e: any) => void;
}

const QSRRestaurantItem = ({ index, item, onClick }: IProps) => {
    const { getByIndex } = useQsrColors();
    return (
        <Box
            className={styles.card}
            onClick={(e) => {
                onClick(item, e);
            }}
            sx={{}}
        >
            <div
                className={classNames(styles.media, { [styles.withBg]: item.backgroundUrl })}
                style={{
                    backgroundColor: getByIndex(index),
                    ...(item.backgroundUrl ? { backgroundImage: `url(${item.backgroundUrl})` } : {}),
                }}
            >
                {item.logoSmallUrl && (
                    <div className={styles.logo}>
                        <img src={item.logoSmallUrl} alt={item.name} />
                    </div>
                )}
            </div>
            <div className={styles.content}>
                <Typography className={styles.title}>{item.name}</Typography>
                {/* <Typography className={styles.subtitle}>American, Burger, Fast Food</Typography> */}
            </div>
        </Box>
    );
};

export default QSRRestaurantItem;
