import { Price } from '@qlub-dev/qlub-kit';
import { IProps as IFormatPrice, ZeroTypeEnum } from '@qlub-dev/qlub-kit/dist/components/Format';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { OrderPricePresentationEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { IProduct } from '@/repositories/menu/types';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

import styles from './index.module.scss';

interface IProps extends IFormatPrice {
    product?: IProduct;
    hasAdditives?: boolean;
    hasDiscount?: boolean;
    discountDisplayLeft?: boolean;
    hideFree?: boolean;
}

export const QSRPrice = ({ product, hasAdditives, hasDiscount, discountDisplayLeft, hideFree, ...rest }: IProps) => {
    const { vendor } = useVendor();
    const { t } = useTranslation('common');

    if (vendor?.orderConfig?.pricePresentation === OrderPricePresentationEnum.HidePrice) {
        return null;
    }

    const price = Number(rest.value);
    const charges = product?.charges ?? 0;
    const discountedPrice = charges < 0 ? (-charges + price).toString() : undefined;

    if (price === 0) {
        if (product?.hasAdditives || hasAdditives) {
            return t('Price on selection');
        }
        if (vendor?.orderConfig?.zeroPriceMode === ZeroTypeEnum.Free) {
            if (hideFree) return null;
            return t('Free');
        }
    }

    return (
        <div className={styles.container}>
            {hasDiscount && discountDisplayLeft && discountedPrice && (
                <Price {...rest} value={discountedPrice} strikeThrough />
            )}
            <Price {...rest} />
            {hasDiscount && !discountDisplayLeft && discountedPrice && (
                <Price {...rest} value={discountedPrice} strikeThrough />
            )}
        </div>
    );
};

export default QSRPrice;
