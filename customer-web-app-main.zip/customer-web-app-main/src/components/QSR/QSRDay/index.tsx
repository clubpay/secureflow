import { DateEnum } from '@/components/QSR/QSRDateTimePicker';
import { useMemo } from 'react';
import { numberToDay } from '@/services/utils/k_qsr';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

interface IProps {
    lang: string;
    day?: DateEnum | string;
    short?: boolean;
}

const QSRDay = ({ lang, day, short }: IProps) => {
    const { t } = useTranslation('common');

    const text = useMemo(() => {
        return numberToDay(lang, day, short);
    }, [lang, day, short]);

    if (text === DateEnum.Tomorrow) {
        return t('Tomorrow');
    }

    if (text === DateEnum.Today) {
        return t('Today');
    }
    return text;
};

export default QSRDay;
