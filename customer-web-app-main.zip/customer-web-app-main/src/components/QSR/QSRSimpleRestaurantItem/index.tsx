import React from 'react';
import { Typography } from '@mui/material';
import { ISocialMenu } from '@/repositories/menu/types';

import styles from './index.module.scss';

interface IProps {
    item: ISocialMenu;
    onClick: (item: ISocialMenu, e: any) => void;
}

const QSRSimpleRestaurantItem = ({ item, onClick }: IProps) => {
    return (
        <div
            className={styles.card}
            onClick={(e) => {
                onClick(item, e);
            }}
        >
            <div className={styles.horizontalLayout}>
                <div className={styles.logo}>{item.logoSmallUrl && <img src={item.logoSmallUrl} alt="" />}</div>
                <Typography className={styles.title}>{item.name}</Typography>
            </div>
        </div>
    );
};

export default QSRSimpleRestaurantItem;
