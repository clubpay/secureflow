import React, { useCallback, useMemo } from 'react';
import classNames from 'classnames';
import { AddButton, AddButtonV2, SelectionIndicator, SelectionIndicatorV2 } from '@qlub-dev/qlub-kit';
import { IBasket, IOrderItem, IProduct, UIVariantEnum } from '@/repositories/menu/types';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import { IndicatorType } from '@qlub-dev/qlub-kit/dist/components/SelectionIndicator';
import QSRPrice from '@/components/QSR/QSRPrice';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';

import styles from './index.module.scss';

interface IProps {
    loading?: boolean;
    basket: IBasket;
    product: IProduct;
    isList: boolean;
    menuId: string;
    currencySymbol: string;
    currencyPrecision: number;
    withIndicator?: boolean;
    disabled?: boolean;
    skipClickEvent?: boolean;
    isEmbedVendor?: boolean;
    currencyFormat: CurrencyFormat;
    ui: UIVariantEnum;
    onChange: (type: 'add' | 'change', num: number, selection?: IOrderItem, product?: IProduct) => void;
}

const QSRIndicator: React.FC<IProps> = ({
    loading,
    basket,
    product,
    isList,
    menuId,
    currencySymbol,
    currencyPrecision,
    withIndicator,
    disabled,
    skipClickEvent,
    isEmbedVendor,
    currencyFormat,
    ui,
    onChange,
}) => {
    const selectedItems = useMemo<Array<IOrderItem | undefined>>(() => {
        const list = basket.items.filter((o) => o.id === product.id && (!o.timestamp || isEmbedVendor));
        if (list.length > 0) {
            return list;
        }
        return [undefined];
    }, [basket, product, isEmbedVendor]);

    const totalQuantity = useMemo(() => {
        return selectedItems.reduce((sum, item) => sum + (item?.quantity || 0), 0);
    }, [selectedItems]);

    const {
        qsr: { qsrProductAddChartEvent, qsrProductRemoveChartEvent },
    } = useQsrEventsCenter();

    const addButtonClickHandler = useCallback(() => {
        if (skipClickEvent) {
            return;
        }

        qsrProductAddChartEvent({
            pageName: 'qsrActiveMenu',
            productName: product.name,
            quantity: 1,
        });
        onChange(
            'add',
            1,
            {
                id: product.id,
                menuId,
                price: product.price,
                quantity: 1,
            },
            product,
        );
    }, [skipClickEvent, onChange, product, menuId]);

    const indicatorChangeHandler = useCallback(
        (selected: IOrderItem | undefined) => (num: number, type: IndicatorType, e?: any) => {
            e?.stopPropagation();
            let trimVal: number;
            if ((selected?.quantity || 0) < num) {
                qsrProductAddChartEvent({
                    pageName: 'qsrActiveMenu',
                    productName: product.name,
                    quantity: num,
                });
                trimVal = num < (product.min || 0) ? product.min || 0 : num;
            } else {
                qsrProductRemoveChartEvent({
                    pageName: 'qsrActiveMenu',
                    productName: product.name,
                    quantity: num,
                });
                trimVal = num < (product.min || 0) ? 0 : num;
            }

            onChange(
                'change',
                trimVal,
                selected
                    ? { ...selected, quantity: trimVal }
                    : {
                          id: product.id,
                          price: product.price,
                          menuId,
                          quantity: trimVal,
                      },
            );
        },
        [onChange, product, menuId],
    );

    const content = useMemo(() => {
        if (ui === UIVariantEnum.V2) {
            if (disabled) {
                return null;
            }

            if (withIndicator) {
                return (
                    <div className={styles.indicator}>
                        <SelectionIndicatorV2
                            value={selectedItems[0]?.quantity || 0}
                            onValueChange={indicatorChangeHandler(selectedItems[0])}
                            min={0}
                            max={product.max || 100}
                            disabled={loading || product.disabled || disabled}
                            elevated
                        />
                    </div>
                );
            }

            return (
                <AddButtonV2
                    disabled={loading || product.disabled || disabled}
                    onClick={addButtonClickHandler}
                    elevated
                    quantity={totalQuantity}
                />
            );
        }

        if (!withIndicator) {
            return (
                <>
                    <AddButton disabled={loading || product.disabled || disabled} onClick={addButtonClickHandler} />
                    <QSRPrice
                        product={product}
                        value={product.displayPrice}
                        currencyFormat={{
                            ...currencyFormat,
                            currencyPrecision: currencyPrecision || currencyFormat.currencyPrecision,
                            cs: currencySymbol || currencyFormat.cs,
                        }}
                        sx={{ paddingLeft: '5px' }}
                        hasDiscount
                    />
                </>
            );
        }
        return selectedItems.map((selected, index) => (
            <div
                className={classNames(styles.itemFooter, {
                    [styles.grid]: !isList,
                })}
                key={index}
            >
                <div className={styles.indicator}>
                    <SelectionIndicator
                        disabled={loading || product.disabled || disabled}
                        min={0}
                        max={product.max || 100}
                        value={selected?.quantity || 0}
                        onValueChange={indicatorChangeHandler(selected)}
                    />
                </div>
                <QSRPrice
                    product={product}
                    value={product.displayPrice}
                    currencyFormat={{
                        ...currencyFormat,
                        currencyPrecision: currencyPrecision || currencyFormat.currencyPrecision,
                        cs: currencySymbol || currencyFormat.cs,
                    }}
                    sx={{ paddingLeft: '5px' }}
                    hasDiscount
                />
            </div>
        ));
    }, [
        ui,
        withIndicator,
        selectedItems,
        isList,
        loading,
        disabled,
        product,
        addButtonClickHandler,
        indicatorChangeHandler,
        totalQuantity,
    ]);

    return (
        <div
            className={classNames(styles.footer, {
                [styles.notSelected]: selectedItems.length === 0,
                [styles.v2]: ui === UIVariantEnum.V2,
            })}
        >
            {content}
        </div>
    );
};

export default QSRIndicator;
