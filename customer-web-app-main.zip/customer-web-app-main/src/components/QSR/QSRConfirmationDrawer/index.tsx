import { IconButton, Drawer, Stack } from '@mui/material';
import { CloseRounded, Warning } from '@mui/icons-material';
import { Button, Typography } from '@qlub-dev/qlub-kit';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

import styles from './index.module.scss';

interface IProps {
    open: boolean;
    name: string | undefined;
    count: number | undefined;
    onClose: () => void;
    onContinue: () => void;
}

const QSRConfirmationDrawer = ({ open, name, count, onClose, onContinue }: IProps) => {
    const { t } = useTranslation('common');
    const handleCancel = () => {
        onClose();
    };

    const handleContinue = () => {
        onClose();
        onContinue();
    };
    return (
        <Drawer
            anchor="bottom"
            open={open}
            onClose={onClose}
            BackdropProps={{ sx: { background: '#00000099' } }}
            PaperProps={{
                elevation: 0,
                sx: {
                    maxWidth: '552px',
                    margin: 'auto',
                    background: 'white',
                    borderRadius: '30px 30px 0px 0px',
                },
            }}
        >
            <>
                <div className={styles.main}>
                    <Stack direction="row" spacing={2}>
                        <IconButton className={styles.warningIcon}>
                            <Warning fontSize="small" />
                        </IconButton>
                        <IconButton onClick={() => onClose()} className={styles.closeIcon}>
                            <CloseRounded fontSize="small" />
                        </IconButton>
                    </Stack>
                    <div className={styles.content}>
                        <Typography className={styles.title}>
                            {count === 1
                                ? t('You have 1 item in your basket from another restaurant!')
                                : t(`You have {{cnt}} items in your basket from another restaurant!`, { cnt: count })}
                        </Typography>
                        <Typography className={styles.subtitle}>
                            {t(
                                'By continuing selecting items, your existing items at {{name}} will be removed Do you want to continue?',
                                { name },
                            )}
                        </Typography>
                    </div>
                    <Stack direction="row" spacing={2} justifyContent="space-between">
                        <Button variant="containedLight" onClick={handleCancel} sx={{ width: '50%' }}>
                            {t('Cancel')}
                        </Button>
                        <Button variant="contained" onClick={handleContinue} sx={{ width: '50%' }}>
                            {t('Continue')}
                        </Button>
                    </Stack>
                </div>
            </>
        </Drawer>
    );
};

export default QSRConfirmationDrawer;
