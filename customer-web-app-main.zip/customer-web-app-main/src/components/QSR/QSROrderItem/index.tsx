import React, { useEffect, useMemo, useState } from 'react';
import { Box, Skeleton, useTheme } from '@mui/material';
import { Divider, FoodItem, TipIcon } from '@qlub-dev/qlub-kit';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getDateAndTimeMin } from '@clubpay/customer-common-module/src/utility/k_time';
import { getCurrencyPrecision } from '@clubpay/customer-common-module/src/utility/k_currency';
import { OrderPaymentMethodEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import MenuAPIManager from '@/repositories/menu';
import { IProduct, IQSROrder, OrderItemStatusEnum } from '@/repositories/menu/types';
import CheckIcon from '@/components/Common/Icons/CheckIcon';
import PendingIcon from '@/components/Common/Icons/PendingIcon';
import DeclinedIcon from '@/components/Common/Icons/DeclinedIcon';
import QSRModifierDisplay from '@/components/QSR/QSRModifierDisplay';
import QSRPrice from '@/components/QSR/QSRPrice';
import { translator } from '@/services/utils/k_qsr';
import { calculateItemPrice } from '@/services/utils/k_order';

import styles from './index.module.scss';

interface IProps {
    order: IQSROrder;
}

const QSROrderItem = ({ order }: IProps) => {
    const { vendor, currencyFormat } = useVendor();
    const menuApi = MenuAPIManager.getInstance();
    const { t } = useTranslation('common');
    const { url, lang } = useQlubRouter();
    const theme = useTheme();
    const [orderDetailsLoading, setOrderDetailsLoading] = useState(false);
    const [productMap, setProductMap] = useState<{
        [key: string]: IProduct;
    }>({});

    useEffect(() => {
        setOrderDetailsLoading(true);
        menuApi
            .getManyProduct(
                url,
                order.orderData.items.map((o) => ({ productId: o.id, menuId: o.menuId })),
                vendor,
            )
            .then((res) => {
                setProductMap(res);
            })
            .finally(() => {
                setOrderDetailsLoading(false);
            });
    }, [order.orderData.items]);

    const { label, icon, upperText } = useMemo(() => {
        switch (order.batchStatus) {
            default:
            case OrderItemStatusEnum.New:
                return { label: t('Order pending!'), icon: <PendingIcon />, upperText: t('Waiting for accept') };
            case OrderItemStatusEnum.Approved:
                return {
                    label: t('Order approved!'),
                    icon: <CheckIcon />,
                };
            case OrderItemStatusEnum.PickUp:
                return {
                    label: t('Ready for Pick Up!'),
                    icon: <CheckIcon />,
                };
            case OrderItemStatusEnum.Completed:
                return { label: t('Order completed!'), icon: <CheckIcon /> };
            case OrderItemStatusEnum.Rejected:
                return { label: t('Order declined!'), icon: <DeclinedIcon /> };
        }
    }, [order, lang]);

    const currencyPrecision = useMemo(() => getCurrencyPrecision(vendor?.country?.currencyCode), [vendor]);

    const tip =
        vendor?.orderConfig?.paymentMethod !== OrderPaymentMethodEnum.PayLater &&
        order?.paymentResponse?.tip &&
        order.paymentResponse.tip !== 0
            ? order.paymentResponse.tip.toString()
            : null;

    if (!vendor || vendor?.orderConfig?.orderHistoryDisable || !order) {
        return null;
    }

    return (
        <div className={styles.accordion}>
            <div className={styles.accordionSum}>
                {icon}
                <div className={styles.summary}>
                    {upperText && (
                        <TypographyT
                            typo="caption_overline"
                            sx={{ color: theme.qlub.palette.onSurfaceColors.mediumEmphasis }}
                        >
                            {upperText}
                        </TypographyT>
                    )}
                    <TypographyT typo="title_md" sx={{ color: theme.qlub.palette.onSurfaceColors.highEmphasis }}>
                        {label}
                    </TypographyT>
                    {order.date && (
                        <TypographyT
                            typo="caption_overline"
                            sx={{ color: theme.qlub.palette.onSurfaceColors.highEmphasis }}
                        >
                            {getDateAndTimeMin(order.date)}
                        </TypographyT>
                    )}
                </div>
            </div>
            <div className={styles.details}>
                <Divider />
                <div className={styles.orderItems}>
                    {order.orderData.items.map((item, i) => {
                        if (!productMap[item.id]) {
                            if (orderDetailsLoading) {
                                return <Skeleton key={i} sx={{ marginX: '16px' }} />;
                            }
                            return null;
                        }

                        const product = { ...productMap[item.id], menuId: item.menuId };

                        return (
                            <Box key={i} className={styles.item}>
                                <FoodItem
                                    key={i}
                                    quantity={item.quantity}
                                    numberCircleColor={theme.qlub.palette.dim.main}
                                    multiplier
                                    name={translator(product.name, product.nameTranslations, lang)}
                                    classes={{
                                        foodCardOverrides: {
                                            paddingBottom: '0 !important',
                                        },
                                    }}
                                    attributes={<QSRModifierDisplay item={item} product={product} lang={lang} />}
                                    price={
                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                            <QSRPrice
                                                value={(item
                                                    ? calculateItemPrice(item, { currencyPrecision, vendor })
                                                    : product.price
                                                ).toFixed(currencyPrecision)}
                                                currencyFormat={{
                                                    ...currencyFormat,
                                                    currencyPrecision:
                                                        currencyPrecision || currencyFormat.currencyPrecision,
                                                }}
                                            />
                                        </div>
                                    }
                                    note={order.orderData.version === 'v2' ? item.note : undefined}
                                />
                            </Box>
                        );
                    })}
                </div>
                {tip && (
                    <div className={styles.tip}>
                        <div className={styles.start}>
                            <div className={styles.icon}>
                                <TipIcon />
                            </div>
                            <TypographyT>{t('Tip Amount')}</TypographyT>
                        </div>
                        <QSRPrice
                            className={styles.price}
                            value={tip}
                            currencyFormat={{
                                ...currencyFormat,
                                currencyPrecision: currencyPrecision || currencyFormat.currencyPrecision,
                            }}
                        />
                    </div>
                )}
                {Boolean(order.note || order.customerComment) && !vendor?.orderConfig?.enableProductBasedComment && (
                    <div className={styles.customerComment}>
                        <TypographyT typo="title_sm" sx={{ color: theme.qlub.palette.onSurfaceColors.mediumEmphasis }}>
                            {t('Note:')}
                        </TypographyT>
                        <TypographyT
                            typo="caption_overline"
                            sx={{ color: theme.qlub.palette.onSurfaceColors.mediumEmphasis }}
                        >
                            {order.note || order.customerComment}
                        </TypographyT>
                    </div>
                )}
            </div>
        </div>
    );
};

export default QSROrderItem;
