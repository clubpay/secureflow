import React, { useState, useCallback } from 'react';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import MultiLocale, { validateMultiLocale } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { Trivia } from '@qlub-dev/qlub-kit';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';

const QSRVendorInfo = () => {
    const { lang } = useQlubRouter();
    const { vendor } = useVendor();
    const [showInfo, setShowInfo] = useState(true);

    const infoClickHandler = useCallback(() => {
        setShowInfo(false);
        onPushEvent('tapOnInformingBox', {
            vendor: vendor?.title,
        });
    }, []);

    if (
        !showInfo ||
        vendor?.orderConfig?.menuInfoDisable ||
        !vendor?.orderConfig?.menuInfoText ||
        !validateMultiLocale(vendor?.orderConfig?.menuInfoText || '')
    ) {
        return null;
    }

    return (
        <Trivia
            message={<MultiLocale value={vendor?.orderConfig?.menuInfoText || ''} lang={lang} Component="p" />}
            onClickClose={() => infoClickHandler()}
            triviaOverrides={{ marginY: '8px', backgroundColor: '#fff' }}
        />
    );
};

export default QSRVendorInfo;
