import React, { memo, useMemo } from 'react';
import classNames from 'classnames';
import { IRestaurant, IQrDetailsResponse } from '@clubpay/customer-common-module/src/repository/vendor';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import { OrderModeEnum, OrderPaymentMethodEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { ThemeModeEnum } from '@clubpay/customer-common-module/src/context/config';
import {
    Typography,
    StepperCheckoutIcon,
    StepperMyOrderIcon,
    StepperPreparingIcon,
    StepperVerifyingIcon,
} from '@qlub-dev/qlub-kit';
import { StepperStatusEnum } from '@/repositories/menu/types';
import QSRTableName from '@/components/QSR/QSRTableName';

import styles from './index.module.scss';

interface IStepData {
    title: string;
    icon: any;
    steps: number;
    done: number;
}

interface IProps {
    config: IConfig | null | undefined;
    vendor: IRestaurant | undefined;
    status: StepperStatusEnum;
    tableInfo: IQrDetailsResponse | undefined;
    isPaid?: boolean;
}

const QSRStepper = ({ config, vendor, tableInfo, status, isPaid }: IProps) => {
    const { t } = useTranslation('common');
    const { theme } = useQlubRouter();

    const isBlackMode = theme === ThemeModeEnum.Black;

    const stepData = useMemo<IStepData>(() => {
        const isVerifyingStepEnabled = vendor?.orderConfig?.enablePosVerifyingStatus ? 1 : 0;
        const stepCount =
            (vendor?.orderMode === OrderModeEnum.QSR &&
            vendor?.orderConfig?.paymentMethod !== OrderPaymentMethodEnum.NoPayment
                ? 3
                : 2) + isVerifyingStepEnabled;

        switch (status) {
            case StepperStatusEnum.BASKET:
                return {
                    title: t('My Order'),
                    icon: <StepperMyOrderIcon disabled={false} />,
                    steps: stepCount,
                    done: 0,
                };
            case StepperStatusEnum.CHECKOUT:
                return {
                    title: t('Checkout'),
                    icon: <StepperCheckoutIcon />,
                    steps: stepCount,
                    done:
                        stepCount === 3 && vendor?.orderConfig?.paymentMethod === OrderPaymentMethodEnum.PayLater
                            ? 2 + isVerifyingStepEnabled
                            : 1,
                };
            case StepperStatusEnum.VERIFYING:
                return {
                    title: t('Verifying'),
                    icon: <StepperVerifyingIcon />,
                    steps: stepCount,
                    done: (() => {
                        if (stepCount === 3 + isVerifyingStepEnabled) {
                            if (isPaid) {
                                return vendor?.orderConfig?.paymentMethod === OrderPaymentMethodEnum.PayLater
                                    ? 2 + isVerifyingStepEnabled
                                    : 1 + isVerifyingStepEnabled;
                            }
                        }
                        return isVerifyingStepEnabled;
                    })(),
                };
            case StepperStatusEnum.PREPARING:
                return {
                    title: t('Preparing'),
                    icon: <StepperPreparingIcon />,
                    steps: stepCount,
                    done: (() => {
                        if (stepCount === 3 + isVerifyingStepEnabled) {
                            if (isPaid) {
                                return vendor?.orderConfig?.paymentMethod === OrderPaymentMethodEnum.PayLater
                                    ? 3 + isVerifyingStepEnabled
                                    : 2 + isVerifyingStepEnabled;
                            }
                        }
                        return 1 + isVerifyingStepEnabled;
                    })(),
                };
            default:
                return {
                    title: t('Preparing'),
                    icon: <StepperPreparingIcon />,
                    steps: stepCount,
                    done: 1,
                };
        }
    }, [status, vendor, t]);

    const renderStep = useMemo(() => {
        return (
            <div
                className={classNames(styles.container, {
                    [styles.isBlackMode]: isBlackMode,
                })}
            >
                <div className={styles.statusData}>
                    <div className={styles.statusInfo}>
                        {stepData.icon}
                        <Typography>{stepData.title}</Typography>
                    </div>
                    <div className={styles.tableInfo}>
                        <Typography>
                            <QSRTableName vendor={vendor} config={config} tableInfo={tableInfo} />
                        </Typography>
                    </div>
                </div>
                <div className={styles.steps}>
                    {Array.from({ length: stepData.steps || 0 }).map((_, index) => {
                        return (
                            <div
                                key={index}
                                className={classNames(styles.step, {
                                    [styles.done]: stepData.done > index,
                                    [styles.selected]: stepData.done === index,
                                })}
                            />
                        );
                    })}
                </div>
            </div>
        );
    }, [stepData, isBlackMode]);

    if (
        (status === StepperStatusEnum.ENJOY || status === StepperStatusEnum.ERROR) &&
        !(
            vendor?.orderConfig?.paymentMethod === OrderPaymentMethodEnum.PayLater &&
            !isPaid &&
            vendor?.orderMode === OrderModeEnum.QSR
        )
    ) {
        return <div className={styles.placeholder} />;
    }

    return renderStep;
};

export default memo(QSRStepper);
