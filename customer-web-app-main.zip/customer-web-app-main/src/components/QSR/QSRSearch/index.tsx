import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import scrollIntoView from 'scroll-into-view';
import { debounce } from 'lodash';
import Fuse, { IFuseOptions } from 'fuse.js';
import { Drawer } from '@mui/material';
import { SearchRounded, KeyboardArrowLeftRounded } from '@mui/icons-material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { EmbedModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import MenuAPIManager from '@/repositories/menu';
import { ICategory, ICategoryProduct, IMenu, UIVariantEnum } from '@/repositories/menu/types';
import { kPromiseAll } from '@/services/utils/k_promise';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import CircleButton from '@/layout/QlubLayout/component/CirlceButton';
import QSRMenu from '@/components/QSR/QSRMenu';
import QSRProductList, { QSRSelectFunc } from '@/components/QSR/QSRProductList';
import { DiningOptionButton } from '../QSRDiningOptionModal';
import Skeleton from './Skeleton';

import styles from './index.module.scss';

export interface ISearchCategoryProduct extends ICategoryProduct {
    _cat: ICategory;
    _tName?: string;
    _tSubtitle?: string;
}

interface IProps {
    menu: IMenu | undefined;
    menus: IMenu[];
    currencyPrecision: number;
    isQSR?: boolean;
    ui: UIVariantEnum;
    onSelect: QSRSelectFunc;
    onOpen: (open: boolean) => void;
}

const QSRSearch = ({ menu: initialMenu, menus, currencyPrecision, isQSR, ui, onSelect, onOpen }: IProps) => {
    const { t } = useTranslation('common');
    const { url } = useQlubRouter();
    const wrapperRef = useRef<HTMLDivElement>(null);
    const [products, setProducts] = useState<ISearchCategoryProduct[]>([]);
    const [items, setItems] = useState<ISearchCategoryProduct[] | null>([]);
    const [term, setTerm] = useState('');
    const [drawerOpen, setDrawerOpen] = useState<boolean>(false);
    const [preventAutoFocus, setPreventAutoFocus] = useState(false);
    const [selectedMenu, setSelectedMenu] = useState<IMenu | undefined>(initialMenu);
    const [loading, setLoading] = useState(false);
    const inputRef = useRef<HTMLInputElement | null>(null);
    const [categories] = useState<ICategory[]>([]);

    const embedVendor = url.embed === EmbedModeEnum.Vendor;
    useEffect(() => {
        onOpen?.(drawerOpen);
    }, [drawerOpen]);

    const menuApi = MenuAPIManager.getInstance();
    const {
        qsr: { qsrSearchTyped },
    } = useQsrEventsCenter();

    const inputRefHandler = (ref: HTMLInputElement) => {
        inputRef.current = ref;
        if (!ref || preventAutoFocus) {
            return;
        }

        ref.focus();
        setPreventAutoFocus(true);
    };

    const fuse = useMemo(() => {
        if (products.length === 0) {
            return null;
        }

        const fuseOptions: IFuseOptions<ISearchCategoryProduct> = {
            isCaseSensitive: false,
            // includeScore: false,
            shouldSort: true,
            // includeMatches: false,
            // findAllMatches: false,
            minMatchCharLength: 2,
            // location: 0,
            // threshold: 0.6,
            // distance: 100,
            // useExtendedSearch: false,
            // ignoreLocation: false,
            // ignoreFieldNorm: false,
            // fieldNormWeight: 1,
            keys: ['name', 'subTitle', '_tName', '_tSubtitle'],
        };

        return new Fuse(products, fuseOptions);
    }, [products]);

    const debounceTextChange = useCallback(
        debounce((text) => {
            qsrSearchTyped(text);
            setTerm(text);
        }, 300),
        [],
    );

    const searchHandler = useCallback((ids: ISearchCategoryProduct[] | null) => {
        if (ids?.length && wrapperRef.current) {
            scrollIntoView(wrapperRef.current, {
                align: {
                    top: 0,
                },
                cancellable: true,
                time: 200,
            });
        }
    }, []);

    useEffect(() => {
        if (!fuse || !term) {
            setItems(null);
            searchHandler(null);
            return;
        }

        const res = fuse.search(term).map((o) => o.item);
        setItems(res);
        searchHandler(res);
        setTimeout(() => {
            document.body.scrollTop = 0;
        }, 10);
    }, [term, fuse, selectedMenu]);

    const getProducts = (menu: IMenu | undefined) => {
        if (!menu) {
            return Promise.resolve();
        }

        setLoading(true);

        return kPromiseAll(menu.categories, 5, (cat) => {
            return menuApi.getCategory(url, cat.id, menu.id, {
                pagination: {
                    limit: cat.size || 100,
                },
            });
        })
            .then((list) => {
                setProducts(
                    list.reduce<ISearchCategoryProduct[]>((a, item, idx) => {
                        item.rows.forEach((product) => {
                            a.push({
                                ...product,
                                _cat: menu.categories[idx],
                                _tName: product.nameTranslations
                                    ? Object.values(product.nameTranslations).join(' ')
                                    : undefined,
                                _tSubtitle: product.subTitleTranslations
                                    ? Object.values(product.subTitleTranslations).join(' ')
                                    : undefined,
                            });
                        });
                        return a;
                    }, []),
                );
                return list;
            })
            .finally(() => {
                setLoading(false);
            });
    };

    const changeHandler = async (e: any) => {
        const text = e.target.value;
        if (!text) {
            setItems(null);
            searchHandler(null);
        }

        if (products.length === 0) {
            await getProducts(selectedMenu);
        }
        debounceTextChange(text);
    };

    const focusHandler = () => {
        if (!items || items.length === 0) {
            return;
        }

        searchHandler(items);
    };

    const closeHandler = () => {
        setTerm('');
        setDrawerOpen(false);
        setPreventAutoFocus(false);
    };

    const menuTabChangeHandler = async (selectedMenuId: string) => {
        const m = menus?.find((o) => o.id === selectedMenuId);
        setSelectedMenu(m);

        await getProducts(m);
    };

    return (
        <>
            <div className={styles.searchAnchor}>
                <div
                    className={styles.input}
                    onClick={() => {
                        setDrawerOpen(true);
                    }}
                >
                    <div className={styles.action}>
                        <SearchRounded fontSize="medium" />
                    </div>
                    <input placeholder={t('Search')} readOnly />
                </div>
                <DiningOptionButton />
            </div>
            <Drawer
                anchor="top"
                open={drawerOpen}
                onClose={closeHandler}
                BackdropProps={{ sx: { background: '#00000099' } }}
                PaperProps={{
                    sx: {
                        minHeight: '100vh',
                        background: '#fff',
                    },
                }}
            >
                <div className={styles.searchContent} ref={wrapperRef}>
                    <div className={styles.header}>
                        <CircleButton className={styles.backIcon} onClick={closeHandler}>
                            <KeyboardArrowLeftRounded />
                        </CircleButton>
                        <div className={styles.input}>
                            <div className={styles.action}>
                                <SearchRounded fontSize="medium" />
                            </div>
                            <input
                                ref={inputRefHandler}
                                defaultValue={term}
                                placeholder={t('Type to search')}
                                onChange={changeHandler}
                                onFocus={focusHandler}
                            />
                        </div>
                    </div>
                    <QSRMenu
                        menus={menus}
                        selectedId={selectedMenu?.id || ''}
                        onSearchDrawer
                        onChange={menuTabChangeHandler}
                    />
                    {loading ? (
                        <Skeleton childrenNumber={5} />
                    ) : (
                        <QSRProductList
                            key={`${selectedMenu?.id}`}
                            menuId={selectedMenu?.id || ''}
                            categories={categories}
                            isList
                            isQSR={isQSR}
                            menu={selectedMenu}
                            currencyPrecision={currencyPrecision}
                            searchProducts={items}
                            noMinHeight
                            isEmbedVendor={embedVendor}
                            isSingleMenu={menus?.length === 1}
                            ui={ui}
                            onSelect={onSelect}
                        />
                    )}
                </div>
            </Drawer>
        </>
    );
};

export default QSRSearch;
