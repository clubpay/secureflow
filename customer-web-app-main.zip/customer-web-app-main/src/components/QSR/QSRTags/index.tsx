import { Typography } from '@qlub-dev/qlub-kit';
import { ITags, UIVariantEnum } from '@/repositories/menu/types';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { translator } from '@/services/utils/k_qsr';
import classNames from 'classnames';

import styles from './index.module.scss';

interface IProps {
    tags?: ITags[];
    ui: UIVariantEnum;
}

const getColorCode = (colorName: string) => {
    switch (colorName?.toLowerCase()) {
        default:
            return '#e0e0e0';
        case 'purple':
            return '#ba68c8';
        case 'blue':
            return '#2196f3';
        case 'green':
            return '#81c784';
        case 'red':
            return '#f44336';
        case 'orange':
            return '#ffb74d';
        case 'pink':
            return '#f06292';
    }
};

const QSRTags = ({ tags, ui }: IProps) => {
    const { lang } = useQlubRouter();

    if (!tags?.length) {
        return null;
    }

    return (
        <div
            className={classNames(styles.tags, {
                [styles.v2]: ui === UIVariantEnum.V2,
            })}
        >
            {tags.map((tag) => {
                return (
                    <Typography
                        key={tag.id}
                        typo="body_sm"
                        className={styles.item}
                        sx={{
                            backgroundColor: getColorCode(tag?.color || ''),
                            color:
                                tag?.color && ['pink', 'purple', 'blue', 'red'].includes(tag.color)
                                    ? 'var(--white)'
                                    : 'var(--onSurfaceColors-highEmphasis)',
                        }}
                    >
                        {translator(tag.name, tag.nameTranslations, lang, 20)}
                    </Typography>
                );
            })}
        </div>
    );
};

export default QSRTags;
