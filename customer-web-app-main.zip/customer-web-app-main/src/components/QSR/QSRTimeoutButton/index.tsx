import { FC, useEffect, useState } from 'react';
import { Button } from '@qlub-dev/qlub-kit';
import { IButtonProps } from '@qlub-dev/qlub-kit/dist/components/Button';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { qlubSessionStorage } from '@clubpay/customer-common-module/src/service/storage/sessionStorage';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { timeUnix } from '@clubpay/customer-common-module/src/utility/k_time';
import { startTimeKey } from '../QSRPreparationFooter';

import styles from './index.module.scss';

function removeStorageStartTime() {
    qlubSessionStorage.remove(startTimeKey);
}

function formatTime(seconds: number): string {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    // Format the output into MM:SS
    return `${minutes < 10 ? `0${minutes}` : `${minutes}`}:${
        remainingSeconds < 10 ? `0${remainingSeconds}` : `${remainingSeconds}`
    }`;
}

function getTimeDiff(t1: number, t2: number) {
    return t1 - Math.floor(timeUnix() - t2);
}

interface IProps extends IButtonProps {
    timeout: number;
    persist?: boolean;
    startTime: number;
    onPay: () => void;
}

const QSRTimeoutButton: FC<IProps> = ({ timeout, children, startTime, onPay }: IProps) => {
    const { routerReplace, query, pathname } = useQlubRouter();
    const { t } = useTranslation('common');
    const [timer, setTimer] = useState(getTimeDiff(timeout, startTime));
    const { payTimeoutDone } = query as unknown as { payTimeoutDone?: string };

    const stopped = timer < 0 || payTimeoutDone === 'true';

    useEffect(() => {
        if (stopped) {
            if (payTimeoutDone !== 'true') {
                routerReplace(pathname, { ...query, payTimeoutDone: 'true' });
            }
            return;
        }

        const interval = setInterval(() => {
            setTimer(getTimeDiff(timeout, startTime));
        }, 1000);

        return () => {
            clearInterval(interval);
            removeStorageStartTime();
        };
    }, [stopped]);

    return (
        <>
            <div className={styles.hint}>
                {stopped
                    ? t('Now you can pay the bill')
                    : t('Pay the bill after {{time}}', { time: formatTime(timer) })}
            </div>
            <Button variant="containedLight" disabled={!stopped} className={styles.button} onClick={onPay}>
                {children}
            </Button>
        </>
    );
};

export default QSRTimeoutButton;
