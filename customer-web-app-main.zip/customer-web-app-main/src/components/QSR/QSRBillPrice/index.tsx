import { useEffect, useMemo, useState } from 'react';
import { Skeleton, useTheme } from '@mui/material';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import BillAPIManager from '@/repositories/bill';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import { IQSROrder } from '@/repositories/menu/types';
import { IPaymentStatusRes } from '@/repositories/bill/types';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import Format from '@qlub-dev/qlub-kit/dist/components/Format';
import { getCurrencyPrecision } from '@clubpay/customer-common-module/src/utility/k_currency';
import { ThemeModeEnum } from '@clubpay/customer-common-module/src/context/config';

import styles from './index.module.scss';

interface IProps {
    loading: boolean;
    order: IQSROrder | undefined;
    showPayment: boolean;
}

const QSRBillPrice = ({ loading, order, showPayment }: IProps) => {
    const { t } = useTranslation('common');
    const apiManager = BillAPIManager.getInstance();
    const { query, theme } = useQlubRouter();
    const { vendor, currencyFormat } = useVendor();
    const palette = useTheme();
    const { dsi, ref, sid } = query as {
        dsi: string;
        ref: string;
        sid?: string;
    };
    const [paymentStatus, setPaymentStatus] = useState<IPaymentStatusRes | undefined>(undefined);

    useEffect(() => {
        setPaymentStatus(undefined);
        if (!order || !ref) {
            return;
        }

        apiManager
            .getStatus({
                id: getSession(sid),
                reference: ref,
                diningSessionID: dsi || '',
            })
            .then((res) => {
                setPaymentStatus(res);
            })
            .catch((err: any) => {
                setPaymentStatus(undefined);
                console.log(err, 'err');
            });
    }, [order, ref]);

    const content = useMemo(() => {
        if (loading && !order) {
            return <Skeleton width="90%" />;
        }

        const amount = Number(paymentStatus?.record?.total || order?.total || 0);

        if (showPayment || order?.paymentStatus !== 'success' || amount < 0.01) {
            return (
                <TypographyT typo="title_md" className={styles.unpaidBill}>
                    {t("You haven't paid the bill yet!")}
                </TypographyT>
            );
        }

        return (
            <TypographyT typo="body_sm" className={styles.paidBill}>
                {interpolateT(t('You have fully paid your bill of <price>'), {
                    price: (
                        <Format
                            currencyFormat={{
                                ...currencyFormat,
                                cs: paymentStatus?.currency || currencyFormat.cs,
                                cc: paymentStatus?.currency || currencyFormat.cc,
                                currencyPrecision: getCurrencyPrecision(paymentStatus?.currency || currencyFormat.cc),
                            }}
                            value={
                                paymentStatus?.amount ||
                                order?.total?.toFixed(getCurrencyPrecision(vendor?.country?.currencyCode)) ||
                                ''
                            }
                            sx={{
                                fontFamily: 'inherit',
                                fontWeight: '500',
                                fontSize: '1rem',
                                letterSpacing: '0.0015em',
                                color:
                                    theme === ThemeModeEnum.Black
                                        ? palette.qlub.palette.black.main
                                        : palette.qlub.palette.iris.main,
                            }}
                        />
                    ),
                })}
            </TypographyT>
        );
    }, [loading, order, order, paymentStatus]);

    return <div>{content}</div>;
};

export default QSRBillPrice;
