import { useMemo } from 'react';
import { trimPathnameForEmbed } from '@/services/utils/k_qsr';
import {
    IRestaurant,
    OrderPricePresentationEnum,
    VisibilityEnum,
} from '@clubpay/customer-common-module/src/repository/vendor';
import QSRPrice from '@/components/QSR/QSRPrice';
import { calculateTotalPrice } from '@/services/utils/k_order';
import QSRActiveOrder from '@/components/QSR/QSRActiveOrder';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IBasket } from '@/repositories/menu/types';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import classNames from 'classnames';

import styles from './index.module.scss';

interface IProps {
    basket: IBasket;
    basketOrderCount: number;
    currencyPrecision: number;
    vendor: IRestaurant | undefined;
    isSim: boolean;
    isQSR: boolean;
    isEmbedVendor?: boolean;
    currencyFormat: CurrencyFormat;
    searchOpen: boolean;
}

const QSRReviewOrderButton = ({
    basket,
    basketOrderCount,
    currencyPrecision,
    vendor,
    isSim,
    isQSR,
    isEmbedVendor,
    currencyFormat,
    searchOpen,
}: IProps) => {
    const { t } = useTranslation('common');
    const { routerPush, lang, pathname } = useQlubRouter();
    const {
        qsr: { qsrViewPayEvent },
    } = useQsrEventsCenter();

    const content = useMemo(() => {
        if (isSim || !isQSR || !vendor) {
            return null;
        }

        if (basketOrderCount > 0) {
            return (
                <div
                    className={classNames(styles.button, { [styles.moveToFront]: searchOpen })}
                    onClick={() => {
                        qsrViewPayEvent();
                        routerPush(
                            trimPathnameForEmbed('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr/order_details', pathname),
                        );
                    }}
                >
                    <span className={styles.circle}>{basketOrderCount}</span>
                    {vendor?.orderConfig?.pricePresentation === OrderPricePresentationEnum.HidePrice
                        ? t('Submit')
                        : t('Review Order')}
                    {vendor?.orderConfig?.ctaPricePresentation !== OrderPricePresentationEnum.HidePrice && (
                        <QSRPrice
                            value={calculateTotalPrice(basket, { currencyPrecision, vendor, isEmbedVendor }).toFixed(
                                currencyPrecision,
                            )}
                            currencyFormat={{
                                ...currencyFormat,
                                currencyPrecision: currencyPrecision || currencyFormat.currencyPrecision,
                            }}
                            bold
                            sx={{ paddingLeft: '5px' }}
                            hideFree
                        />
                    )}
                </div>
            );
        }

        if (vendor?.orderConfig?.customerActiveOrderVisibility === VisibilityEnum.Show) {
            return <QSRActiveOrder />;
        }

        return null;
    }, [basketOrderCount, isSim, isQSR, vendor, currencyPrecision, pathname, lang, isEmbedVendor, searchOpen]);

    return <>{content}</>;
};

export default QSRReviewOrderButton;
