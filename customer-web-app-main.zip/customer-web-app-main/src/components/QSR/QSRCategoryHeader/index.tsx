import { ICategory } from '@/repositories/menu/types';
import { getMediaFirstItem } from '@/services/utils/k_media';
import { CategoryCard } from '@qlub-dev/qlub-kit';
import { checkEmpty, translator } from '@/services/utils/k_qsr';

interface IQSRCategoryHeader {
    category?: ICategory;
    lang?: string;
    isList?: boolean;
}

const QSRCategoryHeader = ({ category, lang, isList }: IQSRCategoryHeader) => {
    if (!category) {
        return null;
    }

    const media = checkEmpty(category?.meta?._media) || category?.media || [];

    return (
        <CategoryCard
            description={translator(category.description, category.descriptionTranslations, lang)}
            image={getMediaFirstItem(media)}
            classes={{
                categoryCardOverrides: !isList
                    ? {
                          flexBasis: '100%',
                          flexGrow: '1',
                          flexShrink: '1',
                          boxSizing: 'border-box',
                          padding: '16px 24px 0px',
                      }
                    : {
                          padding: '16px 24px 0px',
                          backgroundColor: 'var(--white)',
                      },
            }}
        />
    );
};
export default QSRCategoryHeader;
