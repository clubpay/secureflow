import React, { FC } from 'react';
import { translator } from '@/services/utils/k_qsr';
import QSRValidationHint, { QSRValidationHintTypeEnum } from '@/components/QSR/QSRValidationHint';
import { Divider, Typography } from '@qlub-dev/qlub-kit';
import { IModifierGroup, IProduct } from '@/repositories/menu/types';
import { IModifierProduct } from '@/components/QSR/QSRItemSelector';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

import styles from './index.module.scss';

interface IProps {
    modifier: IModifierGroup<IProduct>;
    product: IProduct;
    parentProducts?: IModifierProduct[];
    lang: string;
    divider: boolean;
    parentSelected?: boolean;
    defaultExpanded?: boolean;
}

const QSRModifierWrapper: FC<IProps> = ({
    modifier,
    product,
    divider,
    parentProducts,
    lang,
    parentSelected,
    defaultExpanded: de,
    children,
}) => {
    const anchorContent = (
        <div className={styles.header}>
            <div className={styles.title}>
                {translator(modifier.name, modifier.nameTranslations, lang)}
                <QSRValidationHint item={modifier} type={QSRValidationHintTypeEnum.ModifierGroup} />
            </div>
            <Typography className={styles.desc} typo="caption_overline">
                {translator(modifier.description, modifier.descriptionTranslations, lang)}
            </Typography>
        </div>
    );

    const withAccordion = (parentProducts?.length || 0) > 0;
    const defaultExpanded = Boolean(parentSelected || modifier.selectedItems || de);

    const content = withAccordion ? (
        <Accordion
            key={defaultExpanded ? 'selected' : 'notSelected'}
            defaultExpanded={defaultExpanded}
            elevation={0}
            sx={{
                m: '0 !important',
                p: '0 !important',
                background: 'none !important',
                '&:before': { display: 'none' },
                '& .MuiAccordionSummary-root': { m: 0, p: 0, minHeight: 'unset !important' },
                '& .MuiAccordionDetails-root': { m: 0, p: 0 },
                '& .MuiAccordionActions-root': { m: 0, p: 0 },
                '& .MuiAccordionSummary-content': { m: 0, p: 0 },
                '& .MuiAccordionSummary-expandIconWrapper, & .MuiAccordionSummary-expandIconWrapper.Mui-expanded': {
                    m: (theme) => (theme.direction === 'ltr' ? '0 24px 0 0 !important' : '0 0 0 24px !important'),
                },
            }}
        >
            <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                sx={{
                    p: '0 !important',
                    m: '0 !important',
                    '&.Mui-expanded': { minHeight: 'unset !important' },
                    '& .Mui-expanded': { m: '0 !important' },
                }}
            >
                {anchorContent}
            </AccordionSummary>
            <AccordionDetails sx={{ padding: '0 !important' }}>{children}</AccordionDetails>
        </Accordion>
    ) : (
        <>
            {anchorContent}
            {children}
        </>
    );

    return (
        <div>
            <div
                className={styles.container}
                data-mg-id={modifier.id}
                data-invalid={product.selected?.qty && product?.invalidMgIds?.includes(modifier.id) ? 'true' : 'false'}
            >
                {content}
            </div>
            {divider && <Divider type="fullWidth" />}
        </div>
    );
};

export default QSRModifierWrapper;
