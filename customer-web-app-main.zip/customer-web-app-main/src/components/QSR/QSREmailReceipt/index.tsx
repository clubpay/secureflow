import React from 'react';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import PaymentReceipt from '@/components/Common/PaymentReceipt';

interface IProps {
    email?: string;
}

const QSREmailReceipt = ({ email }: IProps) => {
    const { query } = useQlubRouter();

    if (!query.ref) {
        return null;
    }

    return <PaymentReceipt forceDrawer email={email} qsr />;
};
export default QSREmailReceipt;
