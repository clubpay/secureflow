import { NewLoading } from '@qlub-dev/qlub-kit';
import { IRestaurant, OrderPricePresentationEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import QSRPrice from '@/components/QSR/QSRPrice';
import { IBasket } from '@/repositories/menu/types';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';

import styles from './index.module.scss';

interface IProps {
    basket: IBasket;
    basketOrderCount: number;
    amount: number;
    vendor: IRestaurant | undefined;
    currencyPrecision: number;
    prepaid: boolean;
    embedVendor: boolean;
    loading: boolean;
    onConfirm: () => void;
    currencyFormat: CurrencyFormat;
}

const QSRConfirmOrderButton = ({
    basket,
    basketOrderCount,
    amount,
    vendor,
    currencyPrecision,
    prepaid,
    embedVendor,
    loading,
    onConfirm,
    currencyFormat,
}: IProps) => {
    const { t } = useTranslation('common');

    if (!basket || basketOrderCount === 0) {
        return null;
    }

    return (
        <div className={styles.button} onClick={onConfirm}>
            {loading ? (
                <NewLoading />
            ) : (
                <>
                    <span className={styles.circle}>{basketOrderCount}</span>
                    {embedVendor ? t('Confirm') : prepaid ? t('Proceed to Payment') : t('Confirm Order')}
                    {vendor?.orderConfig?.ctaPricePresentation !== OrderPricePresentationEnum.HidePrice && (
                        <QSRPrice
                            value={amount.toFixed(currencyPrecision)}
                            currencyFormat={{
                                ...currencyFormat,
                                currencyPrecision: currencyPrecision || currencyFormat?.currencyPrecision,
                            }}
                            bold
                            sx={{ paddingLeft: '5px' }}
                            hideFree
                        />
                    )}
                </>
            )}
        </div>
    );
};

export default QSRConfirmOrderButton;
