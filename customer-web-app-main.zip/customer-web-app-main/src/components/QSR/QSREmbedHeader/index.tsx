import QSRTableName from '@/components/QSR/QSRTableName';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useBasket } from '@/contexts/basket';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { EmbedModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';

import styles from './index.module.scss';

const QSREmbedHeader = () => {
    const { t } = useTranslation('common');
    const { url } = useQlubRouter();
    const { config } = useConfigContext();
    const { vendor, tableInfo } = useVendor();
    const { basket } = useBasket();

    const embedVendor = url.embed === EmbedModeEnum.Vendor;

    if (!embedVendor) {
        return null;
    }

    return (
        <div className={styles.container}>
            <div className={styles.tableName}>
                <QSRTableName config={config} vendor={vendor} tableInfo={tableInfo} />
            </div>
            {!!basket.tableData?.paxCount && (
                <div className={styles.tableInfo}>{t('Guests: {{count}}', { count: basket.tableData?.paxCount })}</div>
            )}
        </div>
    );
};

export default QSREmbedHeader;
