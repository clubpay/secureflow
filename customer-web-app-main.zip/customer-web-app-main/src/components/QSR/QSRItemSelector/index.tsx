import React from 'react';
import { CheckButton, SelectionIndicator } from '@qlub-dev/qlub-kit';
import { IModifierGroup, IProduct } from '@/repositories/menu/types';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';

export interface IModifierProduct {
    product: IProduct;
    mgId?: string;
    disabledParent?: boolean;
}

export type ItemIndicatorChangeFunc = (modifierProducts: IModifierProduct[], qty: number, single?: boolean) => void;

interface IProps {
    parentProducts: IModifierProduct[];
    product: IProduct;
    modifier?: IModifierGroup<IProduct>;
    onChange?: ItemIndicatorChangeFunc;
}

const QSRItemSelector = ({ parentProducts, product, modifier, onChange }: IProps) => {
    const checkbox = product.max === 1 || (modifier?.min === 1 && modifier?.max === 1) || modifier?.multiMax === 1;
    const single = modifier?.max === 1;
    const val = product.selected?.qty || 0;
    const {
        qsr: { qsrModifierSelectEvent, qsrProductRemoveChartEvent, qsrProductAddChartEvent },
    } = useQsrEventsCenter();

    const checkboxChange = () => {
        if (val === 0) {
            qsrProductAddChartEvent({
                pageName: 'qsrActiveMenu',
                productName: product.name,
                quantity: 1,
            });
        } else {
            qsrProductRemoveChartEvent({
                pageName: 'qsrActiveMenu',
                productName: product.name,
                quantity: 0,
            });
        }
        qsrModifierSelectEvent(product.min > 0 || (modifier?.min || 0) > 0);
        onChange?.(parentProducts, val ? 0 : 1, single);
    };

    const indicatorChange = (num: number, e?: any) => {
        e?.preventDefault?.();
        e?.preventDefault?.();
        const trimVal = !num || (num < val && num < (product.min || 0)) ? 0 : Math.max(product.min || 0, num);

        if (trimVal < num) {
            qsrProductAddChartEvent({
                pageName: 'qsrActiveMenu',
                productName: product.name,
                quantity: trimVal,
            });
        } else {
            qsrProductRemoveChartEvent({
                pageName: 'qsrActiveMenu',
                productName: product.name,
                quantity: trimVal,
            });
        }
        qsrModifierSelectEvent((product.min || 0) > 0 || (modifier?.min || 0) > 0);
        onChange?.(parentProducts, trimVal);
    };

    const getMax = (v: number) => {
        const multiMax = (modifier?.multiMax || 10000) - (modifier?.maxSelectedQty || 0);
        const max = (modifier?.max || 10000) - (modifier?.selectedItems || 0);
        return v + Math.min(product.max || 10000, multiMax, max);
    };
    const maxValue = getMax(val);

    const disabled = product.disabled || parentProducts?.[parentProducts?.length - 1]?.disabledParent || maxValue === 0;

    if (checkbox) {
        return <CheckButton onClick={() => checkboxChange()} disabled={disabled} selected={val === 1} />;
    }

    return (
        <SelectionIndicator
            disabled={disabled}
            value={val}
            min={product.min}
            max={maxValue}
            onValueChange={(num, z, e) => indicatorChange(num, e)}
        />
    );
};

export default QSRItemSelector;
