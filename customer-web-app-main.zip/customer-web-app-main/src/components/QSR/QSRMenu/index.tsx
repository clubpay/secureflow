import React, { SyntheticEvent, useRef } from 'react';
import { Tab, Tabs } from '@mui/material';
import { IMenu, MenuTypeEnum } from '@/repositories/menu/types';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { translator, trimPathnameForEmbed } from '@/services/utils/k_qsr';
import { moveToStart } from '@/services/utils/k_menu';
import MenuSkeleton from './skeleton';

import styles from './index.module.scss';

interface IProps {
    selectedId: string;
    menus: IMenu[];
    loading?: boolean;
    onChange: (id: string) => void;
    onSearchDrawer?: boolean;
}

const QSRMenu = ({ selectedId, menus, loading = false, onChange, onSearchDrawer }: IProps) => {
    const { lang } = useQlubRouter();
    const { routerPush, pathname } = useQlubRouter();
    const tabRefs = useRef<Record<string, any>>({}); // References for individual tabs

    const tabChangeHandler = (e: SyntheticEvent, menuId: string) => {
        if (!onSearchDrawer) {
            routerPush(trimPathnameForEmbed('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr/[menu]', pathname), {
                menu: menuId,
            });
        }

        setTimeout(() => {
            onChange(menuId);
            moveToStart(tabRefs.current[menuId]);
        }, 100);
    };

    const tabsContent = () => {
        return (
            <div className={styles.tabs}>
                <Tabs
                    variant="scrollable"
                    scrollButtons={false}
                    value={selectedId}
                    onChange={tabChangeHandler}
                    sx={{ minHeight: '38px', height: '38px' }}
                    TabIndicatorProps={{
                        sx: (theme) => ({
                            background: theme.qlub.palette.iris.main,
                            height: '2px',
                        }),
                    }}
                >
                    {loading ? (
                        <MenuSkeleton />
                    ) : (
                        menus
                            .filter((item) => item.type !== MenuTypeEnum.UPSELL)
                            .map((item) => {
                                return (
                                    <Tab
                                        key={item.id}
                                        value={item.id}
                                        disableRipple
                                        label={translator(item.name, item.nameTranslations, lang)}
                                        sx={(theme) => ({
                                            '&.Mui-selected': {
                                                color: `${theme.qlub.palette.iris.main} `,
                                            },
                                            padding: '8px 16px',
                                            ...theme.qlub.typography.button,
                                            color: theme.qlub?.palette.onSurfaceColors.disabled,
                                            fontSize: '14px',
                                            textTransform: 'none',
                                            fontFamily: 'inherit',
                                            minHeight: '38px',
                                            height: '38px',
                                        })}
                                        ref={(el) => {
                                            tabRefs.current[item.id] = el;
                                        }}
                                    />
                                );
                            })
                    )}
                </Tabs>
            </div>
        );
    };

    return <div className={styles.container}>{tabsContent()}</div>;
};

export default QSRMenu;
