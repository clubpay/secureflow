import React, { FC, ReactNode, useCallback, useEffect, useMemo, useState } from 'react';
import { CardMedia } from '@mui/material';
import classNames from 'classnames';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { IBaseUpsell, IProduct, UIVariantEnum } from '@/repositories/menu/types';
import MenuAPIManager from '@/repositories/menu';
import { translator } from '@/services/utils/k_qsr';
import { getMediaFirstItem } from '@/services/utils/k_media';
import QSRUpsellName from '@/components/QSR/QSRUpsellName';
import QSRProductItem from '@/components/QSR/QSRProductItem';
import QSRPrice from '@/components/QSR/QSRPrice';
import { getCurrencyPrecision } from '@clubpay/customer-common-module/src/utility/k_currency';
import { CheckButton, Divider } from '@qlub-dev/qlub-kit';
import { SkeletonBlock, SkeletonList } from './Skeleton';

import styles from './index.module.scss';

export type UpsellUpdateChangeFunc = (product: IProduct, qty: number) => void;

export enum VariantEnum {
    Product = 'Product',
    Category = 'Category',
    Menu = 'Menu',
}

interface IProps {
    upsell: IBaseUpsell;
    variant?: VariantEnum;
    divider?: boolean;
    ui: UIVariantEnum;
    indicator?: (product: IProduct) => ReactNode;
    gridView?: boolean;
    onChange?: UpsellUpdateChangeFunc;
}

const QSRUpsell: FC<IProps> = ({ variant, upsell, divider, ui, indicator, gridView, onChange }) => {
    const menuApi = MenuAPIManager.getInstance();
    const { lang, url, isQSR } = useQlubRouter();
    const { vendor, currencyFormat } = useVendor();
    const [loading, setLoading] = useState<boolean>(true);
    const [products, setProducts] = useState<IProduct[]>([]);
    const [selectedProduct, setSelectedProduct] = useState<Record<string, boolean>>({});

    const currencyPrecision = useMemo(() => getCurrencyPrecision(vendor?.country?.currencyCode), [vendor]);

    useEffect(() => {
        if (!upsell?.id) {
            return;
        }

        setLoading(true);
        menuApi
            .getCategory(url, upsell.id, 'upsell', {
                pagination: { limit: 15 },
                vendor,
            })
            .then((res) => {
                setProducts(res.rows || []);
            })
            .finally(() => {
                setLoading(false);
            });
    }, [upsell.id]);

    const clickHandler = useCallback(
        (product: IProduct) => () => {
            const has = selectedProduct[product.id] || false;
            setSelectedProduct({
                ...selectedProduct,
                [product.id]: !has,
            });
            onChange?.(product, has ? 0 : 1);
        },
        [selectedProduct],
    );

    const content = useMemo(() => {
        if (variant === VariantEnum.Product) {
            return (
                <div className={styles.upsellProduct}>
                    <div className={styles.categoryName}>{upsell.id && <QSRUpsellName id={upsell.id} />}</div>
                    {products.map((prod) => {
                        const product = { ...prod, max: 1, menuId: 'upsell' };
                        return (
                            <QSRProductItem
                                key={prod.id}
                                product={product}
                                lang={lang}
                                vendor={vendor}
                                parentProducts={[]}
                                qsr={isQSR}
                                currencyPrecision={currencyPrecision}
                                Indicator={
                                    isQSR ? (
                                        <CheckButton
                                            onClick={clickHandler(product)}
                                            selected={selectedProduct[product.id] || false}
                                        />
                                    ) : undefined
                                }
                                currencyFormat={currencyFormat}
                            />
                        );
                    })}
                </div>
            );
        }

        return (
            <>
                {variant === VariantEnum.Category && (
                    <div className={styles.header}>{upsell.id && <QSRUpsellName id={upsell.id} />}</div>
                )}
                <div className={styles.upsellList}>
                    {products.map((prod) => {
                        const product = { ...prod, menuId: 'upsell' };
                        return (
                            <div key={product.id} className={styles.item}>
                                <div className={styles.info}>
                                    <div className={styles.name}>
                                        {translator(product?.name, product?.nameTranslations, lang)}
                                    </div>
                                    <div
                                        className={classNames(styles.indicator, {
                                            [styles.v2]: ui === UIVariantEnum.V2,
                                        })}
                                    >
                                        {ui === UIVariantEnum.V2 && (
                                            <QSRPrice
                                                product={product}
                                                value={product.displayPrice}
                                                currencyFormat={{
                                                    ...currencyFormat,
                                                    currencyPrecision:
                                                        currencyPrecision || currencyFormat.currencyPrecision,
                                                }}
                                                bold
                                                hasDiscount
                                            />
                                        )}
                                        {indicator?.(product)}
                                    </div>
                                </div>
                                <div className={styles.image}>
                                    {product?.media && (
                                        <CardMedia
                                            component="img"
                                            src={getMediaFirstItem(product?.media, true)}
                                            className={styles.media}
                                        />
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </>
        );
    }, [products, lang, selectedProduct, indicator]);

    const loadingContent = useMemo(() => {
        if (variant === VariantEnum.Product) {
            return <SkeletonList />;
        }

        return <SkeletonBlock />;
    }, [variant]);

    return (
        <>
            {divider && <Divider type="fullWidth" />}
            <div
                className={classNames(styles.container, {
                    [styles.menuVariant]: variant === VariantEnum.Menu,
                    [styles.categoryVariant]: variant === VariantEnum.Category,
                    [styles.gridView]: gridView,
                })}
            >
                {loading ? loadingContent : content}
            </div>
            {divider && <Divider type="fullWidth" />}
        </>
    );
};

export default QSRUpsell;
