import { Box, Skeleton } from '@mui/material';

import styles from '../index.module.scss';

export const SkeletonBlock = () => {
    return (
        <div className={styles.skeleton}>
            <Box className={styles.title}>
                <Skeleton variant="rounded" height={24} width={120} />
            </Box>
            <div className={styles.content}>
                {Array.from({
                    length: 3 || 0,
                }).map((value, index) => (
                    <Box key={index}>
                        <Skeleton variant="rounded" height={112} width={210} />
                    </Box>
                ))}
            </div>
        </div>
    );
};

export const SkeletonList = () => {
    return (
        <div className={styles.skeleton}>
            <Box className={styles.title}>
                <Skeleton variant="rounded" height={24} width={100} />
            </Box>
            {Array.from({
                length: 3 || 0,
            }).map((value, index) => (
                <Box key={index} className={styles.row}>
                    <Skeleton variant="rounded" height={37} />
                </Box>
            ))}
        </div>
    );
};
