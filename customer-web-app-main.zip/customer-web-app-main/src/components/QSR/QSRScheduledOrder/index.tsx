import React, { Dispatch, SetStateAction, useEffect, useMemo, useState } from 'react';
import { Drawer, IconButton, ToggleButton, ToggleButtonGroup, useTheme } from '@mui/material';
import { CloseRounded, KeyboardArrowRightRounded } from '@mui/icons-material';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { Button, Divider, Typography } from '@qlub-dev/qlub-kit';
import DeliveryIcon from '@/components/Common/Icons/DeliveryIcon';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import QSRDateTimePicker, { DateEnum, IDateTime } from '@/components/QSR/QSRDateTimePicker';
import QSRAsapConfirm from '@/components/QSR/QSRAsapConfirm';
import { format } from 'date-fns';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import classNames from 'classnames';

import styles from './index.module.scss';
import QSRDay from '../QSRDay';

export enum ScheduledOrderEnum {
    ASAP = 'asap',
    Scheduled = 'scheduled',
}

export interface IScheduledTime {
    type: ScheduledOrderEnum;
    value?: IDateTime;
}

interface IProps {
    value: IScheduledTime;
    setValue: Dispatch<SetStateAction<IScheduledTime>>;
    isPickupOnly: boolean;
}

const QSRScheduledOrder = ({ value, setValue, isPickupOnly }: IProps) => {
    const { t } = useTranslation('common');
    const { lang } = useQlubRouter();
    const { vendor } = useVendor();
    const theme = useTheme();
    const [scheduleOpen, setScheduleOpen] = useState(false);
    const [asapConfirmOpen, setAsapConfirmOpen] = useState(false);
    const [selectedDate, setSelectedDate] = useState<IDateTime | undefined>(undefined);
    const {
        qsr: { qsrAsapTypeSelected, qsrScheduleTypeSelected, qsrOrderScheduled, qsrSwitchedAsap },
    } = useQsrEventsCenter();

    const scheduleCloseHandler = () => {
        setScheduleOpen(false);
    };

    const asapConfirmClickHandler = () => {
        if (scheduleOpen) {
            qsrSwitchedAsap({
                actionLocation: 'modal',
            });
            setScheduleOpen(false);
        } else {
            qsrSwitchedAsap({
                actionLocation: 'button',
            });
        }
        setAsapConfirmOpen(true);
    };

    const onClickHandlerSchedule = (val: ScheduledOrderEnum) => {
        if (val === ScheduledOrderEnum.Scheduled) {
            qsrScheduleTypeSelected();
            setScheduleOpen(true);
        } else if (value.type === ScheduledOrderEnum.Scheduled) {
            asapConfirmClickHandler();
        }
    };

    const dateTimeValidation = (val: IDateTime | undefined) => {
        return !(val && val.date && val.timePeriod);
    };

    const setScheduleClickHandler = () => {
        setValue({
            type: ScheduledOrderEnum.Scheduled,
            value: selectedDate,
        });
        if (selectedDate?.date && selectedDate?.timePeriod) {
            qsrOrderScheduled(
                selectedDate?.date,
                `start: ${selectedDate?.timePeriod?.start} end: ${selectedDate?.timePeriod?.end}`,
            );
        }
        scheduleCloseHandler();
    };

    const pickupMethodFooter = useMemo(() => {
        const numberDate = (dayOfWeek?: boolean) => {
            const now = new Date();
            if (value.value?.date === DateEnum.Tomorrow) {
                now.setDate(now.getDate() + 1);
            } else if (value.value?.date === DateEnum.NextDay) {
                now.setDate(now.getDate() + 2);
            }
            if (dayOfWeek) {
                return String(now.getDay());
            }
            return format(now, lang === 'ja' ? 'yyyy/MM/dd' : 'dd/MM/yyyy');
        };
        if (value.type === ScheduledOrderEnum.Scheduled && !dateTimeValidation(value.value)) {
            return interpolateT(
                t(
                    'Your scheduled your pickup for <date> (<dateWeek> <day>), between {{start}} to {{end}} at {{name}}',
                    {
                        start: value.value?.timePeriod?.start || '',
                        end: value.value?.timePeriod?.end || '',
                        name: vendor?.name || '',
                    },
                ),
                {
                    date: <QSRDay lang={lang} day={value.value?.date} />,
                    day: numberDate(),
                    dateWeek: <QSRDay lang={lang} day={numberDate(true)} />,
                },
            );
        }
        return t('Your order will be ready as soon as possible and you can pick it up at {{name}}', {
            name: vendor?.name || '',
        });
    }, [value, lang, t]);

    useEffect(() => {
        if (value.type === ScheduledOrderEnum.ASAP) {
            qsrAsapTypeSelected();
            setSelectedDate(undefined);
        }
    }, [value.type]);

    const scheduledOrderText = useMemo(() => {
        if (value.type === ScheduledOrderEnum.Scheduled && !dateTimeValidation(value.value)) {
            return interpolateT(t('Scheduled pickup <dateInfo>'), {
                dateInfo: (
                    <Typography typo="caption_overline">
                        {interpolateT(
                            t('<date>, {{start}} to {{end}}', {
                                start: value.value?.timePeriod?.start || '',
                                end: value.value?.timePeriod?.end || '',
                            }),
                            {
                                date: <QSRDay lang={lang} day={value.value?.date} short />,
                            },
                        )}
                    </Typography>
                ),
            });
        }
        return t('Schedule pick up');
    }, [lang, value, t]);

    const orderTimeModes = useMemo(() => {
        const modes = [
            {
                mode: ScheduledOrderEnum.ASAP,
                title: t('ASAP'),
            },
            {
                mode: ScheduledOrderEnum.Scheduled,
                title: scheduledOrderText,
            },
        ];
        return isPickupOnly ? modes.filter((mode) => mode.mode === ScheduledOrderEnum.Scheduled) : modes;
    }, [t, scheduledOrderText, lang, isPickupOnly]);

    const changeToAsapButton = useMemo(() => {
        return (
            <div className={styles.asapButton} onClick={asapConfirmClickHandler}>
                <div className={styles.group}>
                    <DeliveryIcon />
                    <div className={styles.texts}>
                        <Typography
                            typo="caption_overline"
                            sx={{ color: theme.qlub.palette.onSurfaceColors.mediumEmphasis }}
                        >
                            {t('Change to')}
                        </Typography>
                        <Typography typo="title_md" sx={{ color: theme.qlub.palette.onSurfaceColors.highEmphasis }}>
                            {t('Pickup as soon as possible')}
                        </Typography>
                    </div>
                </div>
                <IconButton sx={{ padding: '0px' }} className={styles.iconButton}>
                    <KeyboardArrowRightRounded sx={{ color: theme.qlub.palette.onSurfaceColors.highEmphasis }} />
                </IconButton>
            </div>
        );
    }, [lang, scheduleOpen, value, isPickupOnly]);

    return (
        <>
            <div className={styles.orderDetails} data-testid="qsr-scheduler" id="qsr-scheduler">
                <Typography
                    typo="title_md"
                    sx={{ color: theme.qlub.palette.onSurfaceColors.highEmphasis }}
                    className={styles.title}
                >
                    {!isPickupOnly ? t('Select a pickup method') : t('Select your pickup time')}
                </Typography>
                <ToggleButtonGroup className={styles.buttons} fullWidth color="primary" value={value.type} exclusive>
                    {orderTimeModes.map((item) => {
                        return (
                            <ToggleButton
                                key={item.mode}
                                className={classNames(styles.toggleButton, {
                                    [styles.pickupOnly]: isPickupOnly,
                                })}
                                onClick={() => onClickHandlerSchedule(item.mode)}
                                value={item.mode}
                            >
                                <Typography typo="button">{item.title}</Typography>
                            </ToggleButton>
                        );
                    })}
                </ToggleButtonGroup>
                <Typography
                    typo="caption_overline"
                    sx={{ color: theme.qlub.palette.onSurfaceColors.mediumEmphasis }}
                    className={styles.footerText}
                >
                    {pickupMethodFooter}
                </Typography>
            </div>
            <Drawer
                anchor="bottom"
                open={scheduleOpen}
                onClose={scheduleCloseHandler}
                BackdropProps={{ sx: { background: '#00000099' } }}
                PaperProps={{
                    sx: {
                        maxWidth: '552px',
                        minHeight: '200px',
                        margin: '0 auto',
                        background: '#fff',
                        borderRadius: '30px 30px 0 0',
                    },
                }}
            >
                <div className={styles.container}>
                    <div className={styles.content}>
                        <div className={styles.header}>
                            <div className={styles.title}>
                                <Typography typo="headline_sm" className={styles.titleText}>
                                    {!dateTimeValidation(value.value)
                                        ? t('Edit Schedule order details')
                                        : t('Schedule order details')}
                                </Typography>
                                <IconButton sx={{ padding: '0px' }} onClick={scheduleCloseHandler}>
                                    <CloseRounded />
                                </IconButton>
                            </div>
                            <Typography typo="caption_overline" className={styles.subTitleText}>
                                {t(
                                    "Enter the date and time that works for you and pickup your food at {{name}}'s restaurant, {{address}}",
                                    {
                                        address: vendor?.address1 || vendor?.address2 || '',
                                        name: vendor?.name || '',
                                    },
                                )}
                            </Typography>
                        </div>
                        <QSRDateTimePicker value={selectedDate} setValue={setSelectedDate} />
                        {!isPickupOnly && !dateTimeValidation(value.value) && changeToAsapButton}
                        {!dateTimeValidation(value.value) && <Divider />}
                        <Button
                            sx={{ margin: '24px' }}
                            variant="contained"
                            onClick={setScheduleClickHandler}
                            disabled={dateTimeValidation(selectedDate)}
                        >
                            {t('Confirm')}
                        </Button>
                    </div>
                </div>
            </Drawer>
            <QSRAsapConfirm open={asapConfirmOpen} setOpen={setAsapConfirmOpen} setSchedule={setValue} />
        </>
    );
};

export default QSRScheduledOrder;
