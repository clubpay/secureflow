import React, { useState, useEffect } from 'react';
import QSRRestaurantList from '@/components/QSR/QSRRestaurantList';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import MenuAPIManager from '@/repositories/menu';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { ISocialMenu } from '@/repositories/menu/types';
import { qlubSessionStorage } from '@clubpay/customer-common-module/src/service/storage/sessionStorage';
import { parseJSON } from '@clubpay/customer-common-module/src/utility/k_json';

import styles from './index.module.scss';

const key = 'qlub.social.params';

export const setSocialMenuParams = (params: any) => {
    qlubSessionStorage.set(key, JSON.stringify(params));
};

export const getSocialMenuParams = (): any | null => {
    const val = qlubSessionStorage.get(key);
    if (!val) {
        return null;
    }

    return parseJSON(val);
};

const QSRSocialVendorList: React.FC = () => {
    const menuApi = MenuAPIManager.getInstance();
    const { url, urlStr, query } = useQlubRouter();
    const { vendor } = useVendor();
    const [loading, setLoading] = useState(false);
    const [list, setList] = useState<ISocialMenu[]>([]);

    useEffect(() => {
        if (!vendor || loading) {
            return;
        }

        setLoading(true);
        menuApi
            .getSocialMenu(url, { page: 0, limit: 100 }, vendor)
            .then((res) => {
                setList(res.rows || []);
                setSocialMenuParams(query);
            })
            .catch((err) => console.log(err))
            .finally(() => {
                setLoading(false);
            });
    }, [urlStr, vendor]);

    return (
        <div className={styles.container}>
            <QSRRestaurantList list={list} loading={loading} vendor={vendor} />
        </div>
    );
};

export default QSRSocialVendorList;
