import React from 'react';
import WhatshotIcon from '@mui/icons-material/Whatshot';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { UIVariantEnum } from '@/repositories/menu/types';
import classNames from 'classnames';

import styles from './index.module.scss';

interface IProps {
    calories?: { min: number; max: number };
    ui: UIVariantEnum;
}

const QSRCalories = ({ calories, ui }: IProps) => {
    const { t } = useTranslation('common');

    if (!calories?.min && !calories?.max) {
        return null;
    }

    const getContent = () => {
        if (calories.max > 0 && calories.min > 0) {
            return t('{{min}} - {{max}} Cal', {
                min: calories.min,
                max: calories.max,
            });
        }

        if (calories.min > 0) {
            return t('{{min}} Cal', {
                min: calories.min,
            });
        }

        if (calories.max > 0) {
            return t('{{max}} Cal', {
                max: calories.max,
            });
        }

        return null;
    };

    return (
        <div
            className={classNames(styles.calories, {
                [styles.v2]: ui === UIVariantEnum.V2,
            })}
        >
            <WhatshotIcon fontSize="small" />
            <span className={styles.label}>{getContent()}</span>
        </div>
    );
};

export default QSRCalories;
