import React, { useEffect, useMemo, useState } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Button, Typography } from '@qlub-dev/qlub-kit';
import CancelRoundedIcon from '@mui/icons-material/CancelRounded';
import Picker from 'react-mobile-picker';
import { useTheme } from '@mui/material';
import { useBasket } from '@/contexts/basket';
import { IMenu } from '@/repositories/menu/types';
import MenuAPIManager from '@/repositories/menu';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import DateService, { IAvailability, ITime } from '@clubpay/customer-common-module/src/service/date';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { roundTime } from '@/services/utils/k_qsr';
import { uniq } from 'lodash';

import styles from './index.module.scss';
import QSRDay from '../QSRDay';

const endOfDayUnix = 24 * 60 * 60;

export enum DateEnum {
    Today = 'today',
    Tomorrow = 'tomorrow',
    NextDay = 'nextDay',
}

export interface IDateTime {
    date?: DateEnum;
    timePeriod?: ITime;
}

interface IProps {
    setValue: React.Dispatch<React.SetStateAction<IDateTime | undefined>>;
    value?: IDateTime;
}

const QSRDateTimePicker = ({ value, setValue }: IProps) => {
    const menuApi = MenuAPIManager.getInstance();
    const { vendor } = useVendor();
    const { url, lang } = useQlubRouter();
    const { t } = useTranslation('common');
    const theme = useTheme();
    const [menus, setMenus] = useState<IMenu[]>([]);

    const { basket } = useBasket();

    const dateClickHandler = (newDate: DateEnum) => {
        setValue({
            date: newDate,
        });
    };

    const timeSelectHandler = (val: { range: string }) => {
        setValue((o) => ({
            ...o,
            timePeriod: JSON.parse(val.range),
        }));
    };

    useEffect(() => {
        menuApi
            .getMenu(url, { page: 0, limit: 100 }, vendor)
            .then((res) => {
                setMenus(res.rows);
            })
            .catch((err) => console.log(err));
        if (!value) {
            setValue({
                date: DateEnum.Today,
            });
        }
    }, []);

    const availableTimeRange = useMemo(() => {
        if (!menus) {
            return;
        }

        const days = [DateEnum.Today, DateEnum.Tomorrow, DateEnum.NextDay];
        const basketMenuIds = uniq(basket.items.map((o) => o.menuId));
        const selectedMenusAvailabilities = menus.reduce<IAvailability[][]>((a, curr) => {
            if (basketMenuIds.includes(curr.id)) {
                a.push(curr.availabilities || []);
            }
            return a;
        }, []);

        const now = new Date();
        const startDelay =
            (Math.max(
                vendor?.orderConfig?.scheduledOrderOffsetTime || 0,
                vendor?.orderConfig?.scheduledOrderPreparationTime || 0,
            ) || 30) * 60;
        const dateGap = (vendor?.orderConfig?.scheduledOrderOptionGap || 15) * 60;
        const unixNow = (now.getHours() * 60 + now.getMinutes()) * 60;

        const setAvailableTimes = (day: number) => {
            let start = now.getDay() === day ? unixNow || 0 : 0;
            let end = endOfDayUnix;
            const unixRanges = DateService.getInstance().getOverlap(selectedMenusAvailabilities, day) || [];
            const availableTimes: ITime[] = [];
            if (unixRanges.length === 0) {
                unixRanges[0] = {
                    start: DateService.getInstance().getUnixTime(vendor?.config?.openingHour) || 0,
                    end: DateService.getInstance().getUnixTime(vendor?.config?.closingHour) || endOfDayUnix,
                };
            }

            unixRanges.forEach((timeRange) => {
                start = roundTime((timeRange.start > start ? timeRange.start : start) + startDelay, 5);
                end = timeRange.end < end ? timeRange.end : end;
                while (start < end - dateGap) {
                    availableTimes.push({
                        start: DateService.getInstance().getTime(start),
                        end: DateService.getInstance().getTime(start + dateGap),
                    });
                    start += dateGap;
                }
            });
            return availableTimes;
        };

        return days
            .map((day, index) => {
                const timeRange = setAvailableTimes(now.getDay() + index);
                if (timeRange.length === 0) {
                    return null;
                }
                if (index < (vendor?.orderConfig?.scheduledOrderFutureDays || 1)) {
                    return {
                        label: <QSRDay lang={lang} day={day} />,
                        day,
                        timeRange,
                    };
                }
                return null;
            })
            .filter((o) => o);
    }, [menus, basket, lang, t]);

    useEffect(() => {
        if (((availableTimeRange && availableTimeRange?.length) || 0) >= 1) {
            if (value) {
                setValue(value);
            } else if (availableTimeRange) {
                setValue({ date: availableTimeRange[0]?.day });
            }
        }
    }, [availableTimeRange]);

    return (
        <div className={styles.container}>
            {(availableTimeRange?.length || 0) === 0 ? (
                <div className={styles.date}>
                    <Typography typo="title_md" className={styles.title}>
                        {t('Currently there is no available Schedule Time ')}
                    </Typography>
                </div>
            ) : (
                <>
                    <div className={styles.date}>
                        <Typography typo="title_md" className={styles.title}>
                            {t('Select date')}
                        </Typography>
                        <div className={styles.toggleDate}>
                            {availableTimeRange?.map((date, index) => {
                                if (!date || date.timeRange.length === 0) {
                                    return null;
                                }

                                return (
                                    <Button
                                        key={index}
                                        icon={value?.date === date?.day ? 'left' : undefined}
                                        startIcon={
                                            value?.date === date?.day && <CancelRoundedIcon sx={{ fontSize: '20px' }} />
                                        }
                                        sx={{ padding: '8px 16px' }}
                                        variant={value?.date === date?.day ? 'contained' : 'outlined'}
                                        onClick={() => dateClickHandler(date.day)}
                                        disabled={availableTimeRange.length === 1}
                                    >
                                        <Typography typo="button">{date.label}</Typography>
                                    </Button>
                                );
                            })}
                        </div>
                    </div>
                    <div className={styles.time}>
                        <Typography typo="title_md" className={styles.title}>
                            {t('Select date')}
                        </Typography>
                        <div className={styles.timeSelection}>
                            <Picker
                                value={{
                                    range: JSON.stringify(value?.timePeriod || { start: '', end: '' }),
                                }}
                                onChange={timeSelectHandler}
                                wheelMode="natural"
                                height={106}
                                itemHeight={40}
                                key={value?.date}
                                className={styles.picker}
                            >
                                <Picker.Column name="range" className={styles.column}>
                                    {availableTimeRange
                                        ?.find((day) => day?.day === value?.date)
                                        ?.timeRange.map((option, index) => {
                                            if (!option) {
                                                return null;
                                            }
                                            return (
                                                <Picker.Item
                                                    key={index}
                                                    value={JSON.stringify(option)}
                                                    className={styles.item}
                                                >
                                                    {(selected) => (
                                                        <Typography
                                                            typo={selected.selected ? 'title_md' : 'body_md'}
                                                            sx={{
                                                                color: selected.selected
                                                                    ? theme.qlub.palette.onSurfaceColors.highEmphasis
                                                                    : theme.qlub.palette.onSurfaceColors.mediumEmphasis,
                                                                textAlign: 'center',
                                                            }}
                                                        >
                                                            {t('Between {{start}} to {{end}}', {
                                                                start: option.start,
                                                                end: option.end,
                                                            })}
                                                        </Typography>
                                                    )}
                                                </Picker.Item>
                                            );
                                        })}
                                </Picker.Column>
                            </Picker>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
};

export default QSRDateTimePicker;
