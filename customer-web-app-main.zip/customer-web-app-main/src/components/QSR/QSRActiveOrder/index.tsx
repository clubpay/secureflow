import React, { useCallback, useEffect, useRef, useState } from 'react';
import MenuAPIManager from '@/repositories/menu';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IQSROrder, OrderHistoryStatusEnum } from '@/repositories/menu/types';
import QSRActiveOrderItem from '@/components/QSR/QSRActiveOrderItem';
import { debounce } from 'lodash';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';

import styles from './index.module.scss';

const QSRActiveOrder = () => {
    const menuApi = MenuAPIManager.getInstance();
    const [loading, setLoading] = useState(false);
    const [list, setList] = useState<IQSROrder[]>([]);
    const [currentIdx, setCurrentIdx] = useState(0);
    const mostVisibleItem = useRef<{ el: any; refId: string } | null>(null);
    const { vendor } = useVendor();

    const { url } = useQlubRouter();

    const getOrder = () => {
        if (loading) {
            return;
        }

        setLoading(true);
        menuApi
            .getOrderHistory(url, { limit: 12, skip: 0, status: OrderHistoryStatusEnum.Active }, vendor)
            .then((res) => {
                setList(res || []);
            })
            .finally(() => {
                setLoading(false);
            });
    };

    useEffect(() => {
        getOrder();
    }, []);

    const changeHandler = useCallback(
        debounce((e: any) => {
            mostVisibleItem.current = e;
        }, 300),
        [list],
    );
    const settleHandler = useCallback(
        debounce(() => {
            if (!mostVisibleItem.current?.el || list.length <= 1) {
                return;
            }

            mostVisibleItem.current?.el.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        }, 310),
        [list],
    );

    return (
        <div className={styles.main}>
            <div
                className={styles.container}
                onTouchCancel={settleHandler}
                onTouchEnd={settleHandler}
                onScroll={settleHandler}
            >
                {list.map((order) => (
                    <QSRActiveOrderItem
                        key={order.refId}
                        onView={(e) => {
                            setCurrentIdx(list.findIndex((o) => o.refId === e.refId));
                            changeHandler(e);
                        }}
                        order={order}
                    />
                ))}
            </div>
            {list.length > 1 && (
                <div className={styles.progress}>
                    {list.map((order, index) => {
                        return <span key={index} className={index === currentIdx ? styles.selected : styles.bar} />;
                    })}
                </div>
            )}
        </div>
    );
};
export default QSRActiveOrder;
