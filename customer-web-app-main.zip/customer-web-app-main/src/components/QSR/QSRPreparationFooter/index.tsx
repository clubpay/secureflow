import React, { useEffect, useState } from 'react';
import { IQSROrder, OrderPaymentStatusEnum, OrderStatusEnum } from '@/repositories/menu/types';
import { Button } from '@qlub-dev/qlub-kit';
import QSREmailReceipt from '@/components/QSR/QSREmailReceipt';
import { qlubSessionStorage } from '@clubpay/customer-common-module/src/service/storage/sessionStorage';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import QSRTimeoutButton from '@/components/QSR/QSRTimeoutButton';
import { timeUnix } from '@clubpay/customer-common-module/src/utility/k_time';

import styles from './index.module.scss';

export const startTimeKey = 'qlub.button.startTimeKey';

interface IProps {
    order?: IQSROrder;
    payLater: boolean;
    showPrices: boolean;
    onPay: () => void;
    obModify: (modify?: boolean) => void;
}

function setStorageStartTime(val: number) {
    qlubSessionStorage.set(startTimeKey, String(val));
}

function getStorageStartTime() {
    const v = qlubSessionStorage.get(startTimeKey);
    if (v) {
        return Number(v);
    }
    return null;
}

const QSRPreparationFooter = ({ order, payLater, showPrices, onPay, obModify }: IProps) => {
    const { t } = useTranslation('common');
    const { vendor } = useVendor();
    const [startTime, setStartTime] = useState(0);

    useEffect(() => {
        if (!vendor?.orderConfig?.payTimeout) {
            return;
        }

        const v = getStorageStartTime();
        if (!v) {
            const now = timeUnix();
            setStorageStartTime(now);
            setStartTime(now);
            return;
        }
        setStartTime(v);
    }, [vendor?.orderConfig?.payTimeout || 0]);

    const addItem =
        vendor?.orderConfig?.multiOrder &&
        (order?.orderStatus || OrderStatusEnum.PENDING) === OrderStatusEnum.PENDING &&
        payLater;
    const {
        qsr: { qsrNewOrderSelected, qsrAddToOrderSelected },
    } = useQsrEventsCenter();

    const payButton = () => {
        if (vendor?.orderConfig?.payTimeout) {
            return (
                <QSRTimeoutButton
                    fullWidth
                    onPay={onPay}
                    timeout={vendor?.orderConfig?.payTimeout}
                    startTime={startTime}
                >
                    {t('Pay bill now')}
                </QSRTimeoutButton>
            );
        }

        return (
            <Button variant="containedLight" fullWidth className={styles.button} onClick={onPay}>
                {t('Pay bill now')}
            </Button>
        );
    };

    return (
        <div className={styles.buttonGroup}>
            {showPrices &&
                (order?.paymentStatus !== OrderPaymentStatusEnum.Success && payLater
                    ? payButton()
                    : order?.paymentStatus === OrderPaymentStatusEnum.Success && (
                          <QSREmailReceipt email={order?.userInfo?.email} />
                      ))}
            {!vendor?.orderConfig?.hideNewOrderButton && (
                <Button
                    variant="contained"
                    fullWidth
                    onClick={() => {
                        if (addItem) {
                            qsrAddToOrderSelected('qsrPreparation');
                        } else {
                            qsrNewOrderSelected('qsrPreparation');
                        }
                        obModify(addItem);
                    }}
                >
                    {addItem ? t('Add more items') : t('New order')}
                </Button>
            )}
        </div>
    );
};

export default QSRPreparationFooter;
