import React from 'react';
import { Skeleton } from '@mui/material';

import styles from './index.module.scss';

const SkeletonComponent = () => {
    return (
        <div className={styles.skeleton}>
            <Skeleton height={35} />
            <Skeleton height={35} />
        </div>
    );
};

export default SkeletonComponent;
