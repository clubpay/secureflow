import Lottie from 'lottie-react';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { KImage, Typography } from '@qlub-dev/qlub-kit';
import hourglassAnimation from '@/assets/animations/hourglass.json';

import styles from './index.module.scss';

const QSRPosStatus = () => {
    const { vendor } = useVendor();
    const { t } = useTranslation('common');

    return (
        <div className={styles.container}>
            <div className={styles.verifyStatusBanner}>
                {vendor?.logoBigUrl && <KImage src={vendor?.logoBigUrl} alt="venture-img" />}

                <div>
                    <Typography className={styles.subtitle}>{t('Thank you for your order!')}</Typography>
                    <Typography className={styles.title}>{t('Verifying your order now...')}</Typography>
                </div>
            </div>
            <div className={styles.lottie}>
                <Lottie animationData={hourglassAnimation} loop />
            </div>
        </div>
    );
};

export default QSRPosStatus;
