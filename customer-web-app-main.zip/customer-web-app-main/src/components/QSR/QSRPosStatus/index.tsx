import dynamic from 'next/dynamic';
import { Box, CircularProgress } from '@mui/material';

const QSRPosStatus = dynamic(() => import('./dynamic'), {
    loading: () => (
        <Box
            sx={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
            }}
        >
            <CircularProgress size={24} />
        </Box>
    ),
    ssr: false,
});

export default QSRPosStatus;
