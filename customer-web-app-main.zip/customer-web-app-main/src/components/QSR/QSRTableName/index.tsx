import { getTableTitle } from '@/services/utils/config';
import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import {
    BillPageDescriptionModeEnum,
    IQrDetailsResponse,
    IRestaurant,
} from '@clubpay/customer-common-module/src/repository/vendor';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';

interface ITableNameProps {
    config?: IConfig | null;
    vendor?: IRestaurant;
    tableInfo?: IQrDetailsResponse;
}

const NewTableName = ({ vendor, config, tableInfo }: ITableNameProps) => {
    const { t } = useTranslation('common');
    switch (vendor?.config.billPageDescriptionMode || config?.billPageDescriptionMode) {
        case BillPageDescriptionModeEnum.PreferredTableName:
            return t('Table: {{name}}', { name: tableInfo?.table.preferredName || tableInfo?.table.id || '' });
        case BillPageDescriptionModeEnum.TableId:
            return t('Table: {{name}}', { name: tableInfo?.table.id || '' });
        case BillPageDescriptionModeEnum.TableName:
            return t('Table: {{name}}', { name: tableInfo?.table.tableName || tableInfo?.table.id || '' });
        default:
            return null;
    }
};

interface IProps {
    config?: IConfig | null;
    vendor?: IRestaurant;
    tableInfo?: IQrDetailsResponse;
}

export const QSRTableName = ({ config, vendor, tableInfo }: IProps) => {
    const { t } = useTranslation('common');
    const { url } = useQlubRouter();
    if (url.id === '0' && vendor?.orderConfig?.pagerEnable && vendor?.orderConfig?.enablePagerAssignMessage) {
        return <>{t('Pager will be assigned after the submit')}</>;
    }

    if (vendor?.config.billPageDescriptionMode || config?.billPageDescriptionMode) {
        return <NewTableName config={config} vendor={vendor} tableInfo={tableInfo} />;
    }

    const { pager, text } = getTableTitle(vendor, tableInfo?.table.tableName, tableInfo?.table.id || url.id);

    if (text) {
        if (text === '0') {
            return null;
        }
        return <>{`${pager ? t('Pager') : t('Table')} ${text}`}</>;
    }

    return null;
};

export default QSRTableName;
