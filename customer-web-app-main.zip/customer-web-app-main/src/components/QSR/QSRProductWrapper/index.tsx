import { FC, useMemo, useState } from 'react';
import { getMediaList } from '@/services/utils/k_media';
import { IProduct } from '@/repositories/menu/types';
import { KImage } from '@qlub-dev/qlub-kit';
import { Carousel } from 'react-responsive-carousel';
import { isIOS } from '@clubpay/customer-common-module/src/utility/k_user_agent';
import classNames from 'classnames';
import QSRImageDrawer from '@/components/QSR/QSRImageDrawer';
import CloseButton from '@/components/QSR/QSRCloseButton';

import 'react-responsive-carousel/lib/styles/carousel.min.css';
import styles from './index.module.scss';

interface IProps {
    product?: IProduct;
    onClose: () => void;
}

const QSRProductWrapper: FC<IProps> = ({ product, onClose, children }) => {
    const iOS = useMemo(() => isIOS(), []);
    const [imgIndex, setImgIndex] = useState(0);
    const [ImageDrawerOpen, setImageDrawerOpen] = useState(false);

    const clickHandler = () => {
        setImageDrawerOpen(true);
    };

    const imageHeader = useMemo(() => {
        if (!product?.media?.length) {
            return null;
        }

        const imageContainer = (index: number, src?: string, thumb?: string) => {
            if (!src) {
                return <>&nbsp;</>;
            }
            return (
                <div
                    className={styles.imgContainer}
                    style={{
                        backgroundImage: iOS ? '' : `url(${thumb || src})`,
                    }}
                    onClick={clickHandler}
                >
                    {!iOS && <div className={styles.productBlur} />}

                    <KImage
                        key={index}
                        src={src}
                        alt={product?.name}
                        className={classNames(styles.productImage, {
                            [styles.productImgNoAdditives]: !product.hasAdditives,
                        })}
                        maxSize={400}
                    />
                </div>
            );
        };
        if (product.media.length === 1) {
            return getMediaList(product?.media).map((media) => {
                return imageContainer(0, media.original, media.thumb);
            });
        }
        return (
            <Carousel
                infiniteLoop
                showArrows={false}
                showIndicators
                showStatus={false}
                showThumbs={false}
                className={styles.slider}
                swipeable
                swipeScrollTolerance={5}
                preventMovementUntilSwipeScrollTolerance
                dynamicHeight
                onChange={(idx) => {
                    setImgIndex(idx);
                }}
            >
                {getMediaList(product?.media).map((media, idx) => {
                    return imageContainer(idx, media.original, media.thumb);
                })}
            </Carousel>
        );
    }, [product, iOS]);

    return (
        <>
            <div className={styles.main}>
                <CloseButton onClose={onClose} variant="dark" />
                {imageHeader}
                <div className={styles.container}>{children}</div>
            </div>
            <QSRImageDrawer
                open={ImageDrawerOpen}
                onClose={() => setImageDrawerOpen(false)}
                selectedImage={getMediaList(product?.media)[imgIndex]}
            />
        </>
    );
};

export default QSRProductWrapper;
