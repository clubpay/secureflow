import React, { useCallback, useState } from 'react';
import { Box, IconButton } from '@mui/material';
import { SearchRounded, SortByAlpha } from '@mui/icons-material';
import { debounce } from 'lodash';

import styles from './index.module.scss';

interface IProps {
    onSearch: (term: string) => void;
    onSortToggle: () => void;
}

const QSRSocialLandingFilterArea: React.FC<IProps> = ({ onSearch, onSortToggle }) => {
    const [term, setTerm] = useState('');

    const debounceTermChange = useCallback(
        debounce((text) => {
            onSearch(text);
        }, 500),
        [],
    );

    const handleSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
        const text = event.target.value;
        setTerm(text);
        debounceTermChange(text);
    };

    const handleSortToggle = () => {
        onSortToggle();
    };

    return (
        <div className={styles.header}>
            <Box className={styles.searchArea}>
                <SearchRounded fontSize="medium" />
                <input placeholder="Search by restaurant name" value={term} onChange={handleSearch} />
            </Box>
            <IconButton className={styles.sortingButton} onClick={handleSortToggle}>
                <SortByAlpha fontSize="small" sx={{ marginTop: '' }} />
            </IconButton>
        </div>
    );
};

export default QSRSocialLandingFilterArea;
