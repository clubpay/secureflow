import { FC, useMemo } from 'react';
import { IAdditiveItem, IOrderItem, IProduct } from '@/repositories/menu/types';
import { translator } from '@/services/utils/k_qsr';

import styles from './index.module.scss';

interface IProps {
    lang: string;
    product: IProduct;
    item: IOrderItem;
}

const QSRModifierDisplay: FC<IProps> = ({ product, item, lang }): any => {
    if (!item.additives) {
        return null;
    }

    const productMap = useMemo(() => {
        const pm: { [key: string]: IProduct } = {};
        const extractProduct = (pr: IProduct) => {
            pr.products?.forEach((p) => {
                pm[p.id] = p;
                extractProduct(p);
            });
            pr.modifierGroups?.forEach((mg) => {
                mg.products?.forEach((mgp) => {
                    pm[mgp.id] = mgp;
                    extractProduct(mgp);
                });
            });
        };
        extractProduct(product);
        return pm;
    }, [product]);

    const childRenderer = (children: IAdditiveItem[]) => {
        return children.map((it) => {
            const prod = productMap[it.id];
            if (!prod) {
                return null;
            }
            return (
                <span key={it.id}>
                    <div className={styles.item}>
                        <div className={styles.additive}>
                            <div className={styles.qty}>{it.quantity}</div>
                            <div className={styles.name}>{translator(prod.name, prod.nameTranslations, lang)}</div>
                        </div>
                    </div>
                    {it.additives && <div className={styles.additiveContainer}>{childRenderer(it.additives)}</div>}
                </span>
            );
        });
    };

    return useMemo(() => {
        if (!item.additives) {
            return null;
        }
        return childRenderer(item.additives);
    }, [productMap, item]);
};

export default QSRModifierDisplay;
