import { useMemo } from 'react';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { IProduct, IQSROrder } from '@/repositories/menu/types';
import { CloseRounded } from '@mui/icons-material';
import { CircularProgress, IconButton, Skeleton, useTheme } from '@mui/material';
import { Divider, FoodItem, Typography, Button } from '@qlub-dev/qlub-kit';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import QSRPrice from '@/components/QSR/QSRPrice';
import QSRModifierDisplay from '@/components/QSR/QSRModifierDisplay';
import QSROrderId from '@/components/QSR/QSROrderId';
import { getCurrencyPrecision } from '@clubpay/customer-common-module/src/utility/k_currency';
import { convertMultiLocaleStringToObject } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { calculateItemPrice } from '@/services/utils/k_order';
import { translator } from '@/services/utils/k_qsr';

import styles from './index.module.scss';

interface IProps {
    loading: boolean;
    productMap: { [key: string]: IProduct };
    order?: IQSROrder;
    onClose: () => void;
}

const QSRPreparationOrder = ({ loading, productMap, onClose, order }: IProps) => {
    const { lang } = useQlubRouter();
    const { t } = useTranslation('common');
    const { vendor, currencyFormat } = useVendor();
    const theme = useTheme();

    const currencyPrecision = useMemo(() => getCurrencyPrecision(vendor?.country?.currencyCode), [vendor]);

    const specialRequestTitle = useMemo(() => {
        const defaultText = t('Special Request');
        return (
            convertMultiLocaleStringToObject(
                vendor?.orderConfig?.specialRequestTitle || (vendor?.config as any)?.specialRequestTitle || '',
                defaultText,
            )[lang] || defaultText
        );
    }, [vendor, lang, t]);

    if (!order || loading) {
        return (
            <div className={styles.main}>
                <div className={styles.header}>
                    <IconButton onClick={() => onClose()}>
                        <CloseRounded />
                    </IconButton>
                    <Typography typo="headline_sm">{t('Order details')}</Typography>
                </div>
                <QSROrderId order={order} />
                <div className={styles.loadingContainer}>
                    <CircularProgress size={64} thickness={2} />
                </div>
                <Button variant="contained" className={styles.closeButton} onClick={() => onClose()}>
                    {t('Close')}
                </Button>
            </div>
        );
    }

    return (
        <div className={styles.container}>
            <div className={styles.main}>
                <div className={styles.header}>
                    <IconButton onClick={() => onClose()}>
                        <CloseRounded />
                    </IconButton>
                    <Typography typo="headline_sm">{t('Order details')}</Typography>
                </div>
                <QSROrderId order={order} />
                <div className={styles.items}>
                    <div className={styles.title}>{t('Items')}</div>
                    {order?.orderData.items?.map((item, index) => {
                        if (loading) {
                            return <Skeleton />;
                        }
                        const product = { ...productMap[item.id], menuId: item.menuId };
                        if (!product) {
                            return null;
                        }

                        return (
                            <div key={index} className={styles.row}>
                                <FoodItem
                                    key={index}
                                    quantity={item.quantity}
                                    numberCircleColor={theme.qlub.palette.dim.main}
                                    multiplier
                                    name={translator(product.name, product.nameTranslations, lang)}
                                    classes={{
                                        foodCardOverrides: {
                                            paddingBottom: '0 !important',
                                        },
                                    }}
                                    attributes={<QSRModifierDisplay item={item} product={product} lang={lang} />}
                                    price={
                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                            <QSRPrice
                                                value={(item
                                                    ? calculateItemPrice(item, { currencyPrecision, vendor })
                                                    : product.price
                                                ).toFixed(currencyPrecision)}
                                                currencyFormat={{
                                                    ...currencyFormat,
                                                    currencyPrecision:
                                                        currencyPrecision || currencyFormat.currencyPrecision,
                                                }}
                                            />
                                        </div>
                                    }
                                />
                            </div>
                        );
                    })}
                </div>
                <Divider type="fullWidth" />
                {order.customerComment && (
                    <div className={styles.messageContainer}>
                        <Typography typo="title_md">{specialRequestTitle}</Typography>
                        <div className={styles.message}>
                            <Typography typo="body_sm">{order.customerComment}</Typography>
                        </div>
                    </div>
                )}
                <Button variant="contained" className={styles.closeButton} onClick={() => onClose()}>
                    {t('Close')}
                </Button>
            </div>
        </div>
    );
};

export default QSRPreparationOrder;
