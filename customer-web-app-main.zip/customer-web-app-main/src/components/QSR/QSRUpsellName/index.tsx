import { memo, useCallback, useEffect, useState } from 'react';
import { Skeleton } from '@mui/material';
import { ICategory, MenuTypeEnum } from '@/repositories/menu/types';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import MenuAPIManager from '@/repositories/menu';
import { translator } from '@/services/utils/k_qsr';

const categoryMap: { value: Record<string, ICategory> } = {
    value: {},
};

interface IProps {
    id: string;
}

const QSRUpsellName = ({ id }: IProps) => {
    const menuApi = MenuAPIManager.getInstance();
    const { lang, url, urlStr } = useQlubRouter();
    const { vendor } = useVendor();

    const [loading, setLoading] = useState(true);
    const [catName, setCatName] = useState<string>('');

    const fillData = useCallback(
        (cat: ICategory | undefined) => {
            if (!cat) {
                return;
            }

            setCatName(translator(cat.name, cat.nameTranslations, lang) || cat.name || '');
        },
        [lang],
    );

    useEffect(() => {
        if (!url.cc || !url.slug || !url.id || !url.f1 || !url.f2 || !id) {
            setLoading(false);
            return;
        }

        const cat = categoryMap.value?.[id];
        if (cat) {
            fillData(cat);
            setLoading(false);
            return;
        }

        setLoading(true);
        menuApi
            .getMenu(url, { page: 0, limit: 100 }, vendor)
            .then((res) => {
                const cats = res?.rows?.find((menu) => menu.type === MenuTypeEnum.UPSELL)?.categories || [];
                categoryMap.value = cats.reduce<Record<string, ICategory>>((acc, curr) => {
                    acc[curr.id] = curr;
                    return acc;
                }, {});

                fillData(categoryMap.value?.[id]);
            })
            .finally(() => {
                setLoading(false);
            });
    }, [urlStr, fillData]);

    if (loading) {
        return <Skeleton variant="rounded" height={24} width={100} />;
    }

    return <>{catName}</>;
};

export default memo(QSRUpsellName);
