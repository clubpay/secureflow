import { FC } from 'react';
import CarouselBanner from '@/components/Banner/Carousel';
import { SliderLocationEnum, SliderPositionEnum } from '@clubpay/customer-common-module/src/component/KSlider/enums';

import styles from './index.module.scss';

interface IProps {
    location: SliderLocationEnum;
    position?: SliderPositionEnum;
}

const QSRBanner: FC<IProps> = ({ location, position }) => {
    return (
        <div className={styles.container}>
            <CarouselBanner
                location={location}
                position={position}
                styleOverrides={{
                    multiSlide: styles.multiSlide,
                    commonContainer: styles.commonContainer,
                }}
            />
        </div>
    );
};

export default QSRBanner;
