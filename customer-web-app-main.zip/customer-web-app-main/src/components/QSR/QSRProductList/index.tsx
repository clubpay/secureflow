import { Divider } from '@qlub-dev/qlub-kit';
import React, { useCallback, useRef, useState } from 'react';
import MenuAPIManager from '@/repositories/menu';
import {
    BaseTypeEnum,
    ICategory,
    ICategoryProduct,
    IMenu,
    IOrderItem,
    IOrderVendorId,
    IProduct,
    UIVariantEnum,
} from '@/repositories/menu/types';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { Grid } from '@mui/material';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import QSRIndicator from '@/components/QSR/QSRIndicator';
import { getVendorId, useBasket } from '@/contexts/basket';
import { cloneDeep, debounce, uniqBy } from 'lodash';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Loading from '@qlub-dev/qlub-kit/dist/components/Loading';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import QSRPrice from '@/components/QSR/QSRPrice';
import { isAvailabilityConfigMatch } from '@/components/QSR/QSRAvailabilityHint';
import { OrderUnavailableItemPresentationEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import QSRCategoryHeader from '@/components/QSR/QSRCategoryHeader';
import QSRCategoryProductsWrapper from '@/components/QSR/QSRCategoryProductsWrapper';
import { ISearchCategoryProduct } from '@/components/QSR/QSRSearch';
import classNames from 'classnames';
import QSRUpsell, { VariantEnum } from '@/components/QSR/QSRUpsell';
import { mergeBasket } from '@/components/QSR/QSRProduct/utils';
import QSRMenuItemCell from '@/components/QSR/QSRMenuItemCell';
import Skeleton from './Skeleton';

import styles from './index.module.scss';

const limit = 100;

export const isValidCategory = (category?: ICategory) => {
    if (!category) {
        return false;
    }
    return Boolean(category.name || category.description) && (category.media?.[0] || category?.meta?._media?.[0]);
};

interface IQSRMenuTabSelect {
    product: IProduct;
    menu?: IMenu;
    category?: ICategory;
    selected?: IOrderItem;
}

export type QSRSelectFunc = (args: IQSRMenuTabSelect) => void;

interface IProps {
    menuId: string;
    categories: ICategory[];
    menu?: IMenu;
    isList: boolean;
    ui: UIVariantEnum;
    isQSR?: boolean;
    currencyPrecision: number;
    searchProducts: ISearchCategoryProduct[] | null;
    isEmbedVendor?: boolean;
    isSingleMenu?: boolean;
    setProductsLoading?: (value: boolean) => void;
    noMinHeight?: boolean;
    onSelect?: QSRSelectFunc;
    onRemoteLoad?: (catId: string) => void;
    onLoad?: (catId: string) => void;
    onCategoryChange?: (catId: string) => void;
}

export default function QSRProductList({
    isList,
    categories,
    isQSR,
    currencyPrecision,
    menu,
    menuId,
    searchProducts,
    setProductsLoading,
    noMinHeight,
    isEmbedVendor,
    isSingleMenu,
    ui,
    onSelect,
    onRemoteLoad,
    onLoad,
    onCategoryChange,
}: IProps) {
    const menuApi = MenuAPIManager.getInstance();
    const { t } = useTranslation('common');
    const { vendor, currencyFormat } = useVendor();
    const { basket, setBasket } = useBasket();
    const { url, lang } = useQlubRouter();
    const [loading, setLoading] = useState(true);
    const [scrollId, setScrollId] = useState('');
    const [productsMap, setProductsMap] = useState<{ [key: string]: ICategoryProduct[] }>({});
    const selectedCategoryIdRef = useRef('');

    const {
        qsr: { qsrCategorySwitchEvent },
    } = useQsrEventsCenter();

    const fetchCategoryHandler = (category: ICategory, mId: string, more?: boolean) => {
        if (menuId !== mId) {
            return;
        }

        setLoading(true);
        if (!category.id || !mId) {
            setLoading(false);
            return;
        }

        menuApi
            .getCategory(url, category.id, mId, {
                pagination: {
                    scrollId: more ? scrollId : undefined,
                    limit: category.size || limit,
                },
                vendor,
                category,
            })
            .then((res) => {
                if (menuId !== mId) {
                    return;
                }

                setScrollId(res.hasMorePage ? res.scrollId || '' : '');
                setProductsMap((pm) => {
                    const productsMapClone = cloneDeep(pm);
                    if (more) {
                        productsMapClone[category.id] = uniqBy(
                            [...(productsMapClone[category.id] || []), ...res.rows],
                            'id',
                        );
                        return productsMapClone;
                    }
                    productsMapClone[category.id] = res.rows;
                    return productsMapClone;
                });

                if (!res?._cache) {
                    onRemoteLoad?.(category.id);
                }
                onLoad?.(category.id);
            })
            .finally(() => {
                setLoading(false);
                setProductsLoading?.(false);
            });
    };

    const selectProduct = (product: ICategoryProduct, category: ICategory, upsell?: boolean) => {
        if (!onSelect) {
            return;
        }

        onSelect({
            product: upsell ? product : { ...product, menuId },
            menu,
            category,
        });
    };

    const productQtyChangeHandler =
        (category: ICategory, vendorId: IOrderVendorId, upsell?: boolean) =>
        (type: 'add' | 'change', num: number, selection?: IOrderItem, product?: IProduct) => {
            if (!basket || !selection) {
                return;
            }

            if (type === 'add' && product) {
                selectProduct(product, category, upsell);
                return;
            }

            setBasket(mergeBasket(basket, { ...selection, mgId: category.id }, { vendorId, isEmbedVendor }));
        };

    const indicatorComponent = (
        product: ICategoryProduct,
        category: ICategory,
        {
            disabled,
            forceListView,
            upsell,
        }: {
            disabled?: boolean;
            forceListView?: boolean;
            upsell?: boolean;
        },
    ) => {
        if (!product) {
            return null;
        }

        if (isQSR) {
            if (!basket) {
                return null;
            }

            return (
                <QSRIndicator
                    basket={basket}
                    product={product}
                    isList={forceListView || isList}
                    disabled={disabled}
                    menuId={product.menuId || menuId}
                    currencySymbol={vendor?.country.currencySymbol || ''}
                    currencyPrecision={currencyPrecision}
                    withIndicator={!product.hasAdditives}
                    skipClickEvent={!upsell}
                    isEmbedVendor={isEmbedVendor}
                    currencyFormat={currencyFormat}
                    ui={ui}
                    onChange={productQtyChangeHandler(category, getVendorId(url), upsell)}
                />
            );
        }

        return (
            <QSRPrice
                product={product}
                value={product.displayPrice}
                currencyFormat={{
                    ...currencyFormat,
                    currencyPrecision: currencyPrecision || currencyFormat.currencyPrecision,
                }}
                bold
                sx={{ paddingLeft: '5px' }}
                hasDiscount
            />
        );
    };

    const visibilityChangeHandler = (category: ICategory) => (visible: boolean) => {
        if (!visible || productsMap.hasOwnProperty(category.id)) {
            return;
        }

        fetchCategoryHandler(category, menuId);
    };

    const debounceCategoryChange = useCallback(
        debounce((category) => {
            selectedCategoryIdRef.current = category.id;
            qsrCategorySwitchEvent(category.name);
            onCategoryChange?.(category.id);
        }, 100),
        [],
    );

    const anchorChangeHandler = (category: ICategory) => (isTop: boolean) => {
        if (!isTop) {
            return;
        }

        debounceCategoryChange(category);
    };

    const getContent = (products: ICategoryProduct[], category: ICategory, forceListView?: boolean) => {
        if (!category) {
            return null;
        }

        if (category._lazy && category._type === BaseTypeEnum.Upsell) {
            if (!category._upsell) {
                return null;
            }

            return (
                <QSRUpsell
                    upsell={category._upsell}
                    variant={VariantEnum.Menu}
                    ui={ui}
                    indicator={(prod) => {
                        return indicatorComponent(prod, category, {
                            disabled: category.disabled,
                            forceListView,
                            upsell: true,
                        });
                    }}
                    gridView={!isList}
                />
            );
        }

        if (!products || !products.length || products.length === 0) {
            return null;
        }

        const listView = forceListView || isList;
        let normalProductIndex = 0;

        return (
            <>
                {searchProducts === null && isValidCategory(category) && (
                    <QSRCategoryHeader category={category} lang={lang} isList={listView} />
                )}
                <Grid
                    className={classNames(styles.products, {
                        [styles.gridView]: !listView,
                        [styles.v2]: ui === UIVariantEnum.V2,
                    })}
                    container
                    spacing={!listView ? 2 : 0}
                >
                    {products.map((product, index) => {
                        const disabled = product.disabled || category?.disabled || menu?.disabled;

                        if (product._lazy && product._type === BaseTypeEnum.Upsell) {
                            if (!product._upsell) {
                                return null;
                            }

                            normalProductIndex = 0;

                            return (
                                <Grid item sm={12} key={product.id}>
                                    <QSRUpsell
                                        key={product.id}
                                        upsell={product._upsell}
                                        variant={VariantEnum.Category}
                                        ui={ui}
                                        indicator={(prod) => {
                                            return indicatorComponent(prod, category, {
                                                disabled,
                                                forceListView,
                                                upsell: true,
                                            });
                                        }}
                                        gridView={!isList}
                                        divider
                                    />
                                </Grid>
                            );
                        }

                        if (
                            (category?.outOfSchedule &&
                                isAvailabilityConfigMatch(vendor, [
                                    OrderUnavailableItemPresentationEnum.HideProduct,
                                    OrderUnavailableItemPresentationEnum.HideCategory,
                                ])) ||
                            (product.outOfSchedule &&
                                isAvailabilityConfigMatch(vendor, [OrderUnavailableItemPresentationEnum.HideProduct]))
                        ) {
                            return null;
                        }

                        normalProductIndex++;
                        return (
                            <Grid
                                className={classNames(styles.item, {
                                    [styles.odd]: normalProductIndex % 2 === 1,
                                    [styles.even]: normalProductIndex % 2 === 0,
                                    [styles.first]: normalProductIndex === 1,
                                })}
                                item
                                xs={listView ? 12 : 6}
                                key={index}
                            >
                                <QSRMenuItemCell
                                    ui={ui}
                                    listView={listView}
                                    menu={menu}
                                    category={category}
                                    product={product}
                                    basket={basket}
                                    currencyFormat={currencyFormat}
                                    isEmbedVendor={isEmbedVendor}
                                    isQSR={isQSR}
                                    indicator={indicatorComponent(product, category, { disabled, forceListView })}
                                    onClick={() => selectProduct({ ...product, disabled }, category, false)}
                                />
                                {listView && <Divider />}
                            </Grid>
                        );
                    })}
                </Grid>
            </>
        );
    };

    if (categories?.length === 0 && searchProducts === null) {
        return (
            <div className={styles.noResult}>
                <div className={styles.title}>{t('Craving something?')}</div>
                <div className={styles.text}>{t('Search here to find your favourite food')}</div>
            </div>
        );
    }

    if (searchProducts) {
        if (searchProducts.length === 0) {
            return (
                <div className={styles.noResult}>
                    <div className={styles.title}>{t('Oops! We can’t find a match')}</div>
                    <div className={styles.text}>{t('Try searching in different menu')}</div>
                </div>
            );
        }

        return (
            <div className={styles.container}>
                <div className={styles.scroll}>
                    {searchProducts.map((prod) => {
                        return getContent([prod], prod._cat, true);
                    })}
                    <div className={styles.bottomGap} />
                </div>
            </div>
        );
    }

    return (
        <div
            className={classNames(styles.container, {
                [styles.noMinHeight]: noMinHeight,
            })}
        >
            {!productsMap && <Skeleton />}
            <div className={styles.scroll}>
                {categories?.map((category, i) => {
                    const productList = productsMap?.[category.id];
                    return (
                        <QSRCategoryProductsWrapper
                            key={category.id}
                            category={category}
                            lang={lang}
                            divider={i !== 0}
                            loading={!productList}
                            selectedCategoryIdRef={selectedCategoryIdRef}
                            isSingleMenu={isSingleMenu}
                            onVisibilityChange={visibilityChangeHandler(category)}
                            onAnchorChange={anchorChangeHandler(category)}
                            gridView={!isList}
                        >
                            {getContent(productList, category)}
                        </QSRCategoryProductsWrapper>
                    );
                })}
                {loading && Object.keys(productsMap || {}).length > 0 && (
                    <div className={styles.loading}>
                        <Loading color="outlined" />
                    </div>
                )}
            </div>
        </div>
    );
}
