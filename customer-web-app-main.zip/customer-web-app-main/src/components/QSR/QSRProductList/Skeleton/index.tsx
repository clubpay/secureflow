import { Grid, Skeleton } from '@mui/material';

import styles from './index.module.scss';

interface ISkeletonComponentSingleProps {
    childrenNumber?: number;
}

const SkeletonComponentSingle = ({ childrenNumber }: ISkeletonComponentSingleProps) => {
    return (
        <div className={styles.skeleton}>
            {Array.from({
                length: childrenNumber || 0,
            }).map((value, index) => (
                <div key={index} className={styles.skeletonItem}>
                    <Grid container>
                        <Grid item xs={12}>
                            <Skeleton variant="text" width="30%" height={40} />
                        </Grid>
                        <Grid item xs={12}>
                            <Skeleton variant="text" width="80%" height={40} />
                        </Grid>
                    </Grid>
                    <Skeleton variant="text" width="80%" height={150} />
                </div>
            ))}
        </div>
    );
};

export default SkeletonComponentSingle;
