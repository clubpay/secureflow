import React, { useEffect, useMemo, useState } from 'react';
import { Badge, IconButton, SwipeableDrawer, useTheme } from '@mui/material';
import { ChevronRightRounded, CloseRounded, TakeoutDiningRounded } from '@mui/icons-material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { QSRRouterModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import MenuAPIManager from '@/repositories/menu';
import { IQSROrder, OrderHistoryStatusEnum, OrderPaymentStatusEnum, OrderStatusEnum } from '@/repositories/menu/types';
import Format from '@qlub-dev/qlub-kit/dist/components/Format';
import Loading from '@qlub-dev/qlub-kit/dist/components/Loading';
import PendingIconSmall from '@/components/Common/Icons/PendingIconSmall';
import CheckIconSmall from '@/components/Common/Icons/CheckIconSmall';
import DeclinedIconSmall from '@/components/Common/Icons/DeclinedIconSmall';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { OrderIdPresentationEnum, OrderModeEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { ContentSwitcher, Typography } from '@qlub-dev/qlub-kit';
import { getRelativeTime } from '@clubpay/customer-common-module/src/utility/k_time';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import MyOrdersIcon from '@qlub-dev/qlub-kit/dist/assets/icons/MyOrdersIcon';
import classNames from 'classnames';
import { trimPathnameForEmbed } from '@/services/utils/k_qsr';

import styles from './index.module.scss';

interface QSROrderHistoryProps {
    iconOnly?: boolean;
}

const QSROrderHistory = ({ iconOnly }: QSROrderHistoryProps) => {
    const { vendor, currencyFormat } = useVendor();
    if (
        !vendor ||
        vendor?.orderConfig?.orderHistoryDisable ||
        [OrderModeEnum.DigitalMenu, OrderModeEnum.Default].includes(vendor?.orderMode || OrderModeEnum.Default)
    ) {
        return null;
    }

    const [tabIndex, setTabIndex] = React.useState(0);
    const menuApi = MenuAPIManager.getInstance();
    const { t } = useTranslation('common');
    const { url, routerPush, lang, pathname, query } = useQlubRouter();
    const theme = useTheme();
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [list, setList] = useState<IQSROrder[]>([]);
    const [count, setCount] = useState(0);
    const [status, setStatus] = useState<OrderHistoryStatusEnum>(OrderHistoryStatusEnum.Active);

    const btnWithoutText = query.qsr === QSRRouterModeEnum.Mixed && iconOnly;

    const {
        qsr: { qsrOrderHistorySelected, qsrNavigatedtoOrderPreparation },
    } = useQsrEventsCenter();

    useEffect(() => {
        menuApi.getOrderActiveCount(url).then((res) => {
            setCount(res);
        });
    }, []);

    const getOrder = () => {
        if (loading) {
            return;
        }

        setLoading(true);
        menuApi
            .getOrderHistory(url, { limit: 12, skip: 0, status }, vendor)
            .then((res) => {
                setList(res || []);
            })
            .finally(() => {
                setLoading(false);
            });
    };

    useEffect(() => {
        if (!open) {
            return;
        }

        getOrder();
    }, [open, status]);

    const closeHandler = () => {
        setOpen(false);
        setList([]);
        setLoading(false);
    };

    const orderClickHandler = (order: IQSROrder) => () => {
        qsrNavigatedtoOrderPreparation();
        routerPush(trimPathnameForEmbed('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr/preparation', pathname), {
            id: order.urlData.tableId,
            f1: order.urlData.f1 || '_',
            f2: order.urlData.f2 || '_',
            ...(order.urlData.hash ? { hash: order.urlData.hash } : {}),
            qOrderId: order.refId,
            qsr: vendor?.orderMode === OrderModeEnum.Mixed ? QSRRouterModeEnum.Mixed : QSRRouterModeEnum.True,
            ref: '',
        });
        closeHandler();
    };

    const getData = (item: IQSROrder) => {
        switch (item.orderStatus) {
            case OrderStatusEnum.ACTIVE:
            case OrderStatusEnum.APPROVED:
                return {
                    name: t('Approved'),
                    icon: <CheckIconSmall />,
                    color: '#EE7300',
                };
            case OrderStatusEnum.PICK_UP:
                return {
                    name: t('Pick up'),
                    icon: <TakeoutDiningRounded />,
                    color: '#0072c5',
                };
            case OrderStatusEnum.DECLINED:
            case OrderStatusEnum.CANCELLED:
                return {
                    name: t('Declined'),
                    icon: <DeclinedIconSmall />,
                    color: theme.qlub.palette.danger.main,
                };
            case OrderStatusEnum.CLOSED:
                return {
                    name: t('Done'),
                    icon: <CheckIconSmall />,
                    color: theme.qlub.palette.success.main,
                };
            case OrderStatusEnum.SYNC_FAILED:
            case OrderStatusEnum.FAILED:
                return {
                    name: t('Failed'),
                    icon: <DeclinedIconSmall />,
                    color: theme.qlub.palette.danger.main,
                };
            default:
                return {
                    name: t('Pending'),
                    icon: <PendingIconSmall />,
                    color: '#EE7300',
                };
        }
    };

    const tabChangeHandler = (event: React.SyntheticEvent, tab: number) => {
        setList([]);
        setTabIndex(tab);
        if (tab === 1) {
            setStatus(OrderHistoryStatusEnum.All);
        } else if (tab === 0) {
            setStatus(OrderHistoryStatusEnum.Active);
        }
    };

    const orderIdPresentation = (item: IQSROrder) => {
        if (vendor?.orderConfig?.orderIdPresentation === OrderIdPresentationEnum.TicketId) {
            return ` - ${item.ticketId}`;
        }
        return null;
    };
    const onHistoryIconClick = () => {
        switch (pathname) {
            case '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr/preparation':
            case '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/embed/qsr/preparation':
                qsrOrderHistorySelected('qsrPreparation');
                break;
            case '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr/[menu]':
            case '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/embed/qsr/[menu]':
                qsrOrderHistorySelected('qsrActiveMenu');
                break;
            case '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr':
            case '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/embed/qsr':
                qsrOrderHistorySelected('qsrLanding');
                break;
            default:
                qsrOrderHistorySelected('qsrLanding');
        }
        setOpen(true);
    };

    const tabs = useMemo(() => {
        const tabContent = () => {
            if (list.length === 0) {
                return (
                    <div className={styles.loading}>
                        {loading ? (
                            <Loading color="outlined" />
                        ) : (
                            <div className={styles.placeholder}>{t('You have no order within this session!')}</div>
                        )}
                    </div>
                );
            }
            return (
                <div className={styles.list}>
                    {list.map((part) => {
                        return (
                            <div key={part.refId} className={styles.item}>
                                <div className={styles.info}>
                                    {getData(part).icon}
                                    <div className={styles.content}>
                                        <Typography typo="caption_overline" sx={{ color: getData(part).color }}>
                                            {getData(part).name}
                                        </Typography>
                                        <div className={styles.price}>
                                            <Format
                                                currencyFormat={currencyFormat}
                                                value={part.total.toFixed(2)}
                                                sx={{
                                                    fontFamily: 'inherit',
                                                    fontWeight: '500',
                                                    fontSize: '1rem',
                                                    letterSpacing: '0.0015em',
                                                    color: theme.qlub.palette.onSurfaceColors.highEmphasis,
                                                }}
                                            />
                                            {!(
                                                part.orderStatus === OrderStatusEnum.CANCELLED ||
                                                OrderStatusEnum.DECLINED
                                            ) && (
                                                <Typography
                                                    typo="body_sm"
                                                    sx={{
                                                        display: 'flex',
                                                        gap: '4px',
                                                        color: theme.qlub.palette.onSurfaceColors.highEmphasis,
                                                    }}
                                                >
                                                    <span style={{ paddingLeft: '4px' }}>-</span>
                                                    {part.paymentStatus === OrderPaymentStatusEnum.Success
                                                        ? t('Paid')
                                                        : t('Not paid')}
                                                </Typography>
                                            )}
                                        </div>
                                        <Typography
                                            typo="body_sm"
                                            sx={{ color: theme.qlub.palette.onSurfaceColors.mediumEmphasis }}
                                        >
                                            {getRelativeTime(part.createdAt, lang)}
                                            {orderIdPresentation(part)}
                                        </Typography>
                                    </div>
                                </div>
                                <div className={styles.button}>
                                    <IconButton className={styles.chevron} onClick={orderClickHandler(part)}>
                                        <ChevronRightRounded />
                                    </IconButton>
                                </div>
                            </div>
                        );
                    })}
                </div>
            );
        };
        const items = [
            {
                children: tabContent(),
                index: 0,
                label: t('Active only'),
            },
            {
                children: tabContent(),
                index: 1,
                label: t('All'),
            },
        ];

        return <ContentSwitcher sticky value={tabIndex} onChange={tabChangeHandler} items={items} />;
    }, [list, status, tabIndex, lang, loading]);

    return (
        <>
            <Badge
                badgeContent={count}
                max={5}
                color="primary"
                sx={{
                    '& .MuiBadge-badge': { fontSize: 9, height: 16, minWidth: 16, transform: 'translate(4px, 0px)' },
                }}
            >
                <div
                    className={classNames(styles.myOrdersButton, {
                        [styles.isMixedOrder]: btnWithoutText,
                    })}
                    onClick={onHistoryIconClick}
                >
                    {!btnWithoutText && <div>{t('Orders')}</div>}
                    <MyOrdersIcon />
                </div>
            </Badge>
            <SwipeableDrawer
                anchor="bottom"
                open={open}
                onClose={closeHandler}
                onOpen={() => {
                    setOpen(true);
                }}
                BackdropProps={{ sx: { background: '#00000099' } }}
                PaperProps={{
                    sx: {
                        maxWidth: '552px',
                        minHeight: '200px',
                        margin: '0 auto',
                        background: '#fff',
                        borderRadius: '30px 30px 0 0',
                    },
                }}
            >
                <div className={styles.container}>
                    <div className={styles.content}>
                        <div className={styles.title}>{t('Your Order History')}</div>
                        <div>
                            <IconButton onClick={closeHandler}>
                                <CloseRounded />
                            </IconButton>
                        </div>
                    </div>
                    <p className={styles.description}>{t('Your orders within this session')}</p>
                    <div className={styles.orders}>{tabs}</div>
                </div>
            </SwipeableDrawer>
        </>
    );
};

export default QSROrderHistory;
