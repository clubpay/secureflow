import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Box, CircularProgress } from '@mui/material';
import classNames from 'classnames';
import { Badge, Button, Divider, SelectionIndicator } from '@qlub-dev/qlub-kit';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IRestaurant, OrderPricePresentationEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import QSRProductSelection from '@/components/QSR/QSRProductSelection';
import QSRProductWrapper from '@/components/QSR/QSRProductWrapper';
import QSRPrice from '@/components/QSR/QSRPrice';
import { UpsellUpdateChangeFunc } from '@/components/QSR/QSRUpsell';
import QSRAvailabilityHint from '@/components/QSR/QSRAvailabilityHint';
import QSRTags from '@/components/QSR/QSRTags';
import QSRModifiers from '@/components/QSR/QSRModifiers';
import QSRCalories from '@/components/QSR/QSRCalories';
import { ItemIndicatorChangeFunc } from '@/components/QSR/QSRItemSelector';
import MenuAPIManager from '@/repositories/menu';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import { getVendorId } from '@/contexts/basket';
import { translator } from '@/services/utils/k_qsr';
import { calculateTotalPrice } from '@/services/utils/k_order';
import {
    IAdditiveItem,
    ICategory,
    IMenu,
    IModifierGroupItemCount,
    IBasket,
    IOrderItem,
    IProduct,
    UIVariantEnum,
} from '@/repositories/menu/types';
import { checkValidation, getDefaultBasket, mergeBasket } from './utils';

import styles from './index.module.scss';

export interface IProductSelect {
    product: IProduct;
    category?: ICategory;
    menu?: IMenu;
    full?: boolean;
    selectionId?: number;
    menuId: string;
}

export interface QSRProductProps {
    qsr: boolean;
    vendor: IRestaurant | undefined;
    selectedProduct?: IProductSelect;
    basket: IBasket;
    currencyPrecision: number;
    isEmbedVendor: boolean;
    currencyFormat: CurrencyFormat;
    ui: UIVariantEnum;
    onClose: (open: boolean, mode?: string) => void;
    onBasketChange: (basket: IBasket) => void;
}

const QSRProduct = ({
    qsr,
    vendor,
    selectedProduct,
    currencyPrecision,
    basket,
    isEmbedVendor,
    currencyFormat,
    ui,
    onClose,
    onBasketChange,
}: QSRProductProps) => {
    const { t } = useTranslation('common');
    const [selected, setSelected] = useState<IProductSelect | undefined>(selectedProduct);
    const prod = selected?.product as IProduct;
    const menuApi = MenuAPIManager.getInstance();
    const { url, lang } = useQlubRouter();
    const [tempBasket, setTempBasket] = useState<IOrderItem | undefined>(
        basket.items.find(
            (item) =>
                item.id === prod.id && item.selectionId === selected?.selectionId && (!item.timestamp || isEmbedVendor),
        ),
    );
    const [upsellBasketItems, setUpsellBasketItems] = useState<IOrderItem[]>([]);
    const [drawerOpen, setDrawerOpen] = useState(false);
    const modifierRef = useRef<HTMLDivElement>(null);
    const modifierAnimationTimeout = useRef<any>(null);
    const {
        qsr: { qsrProductAddChartEvent },
    } = useQsrEventsCenter();

    useEffect(() => {
        if (!selectedProduct) {
            return;
        }

        setSelected(selectedProduct);
        menuApi
            .getProduct(url, selectedProduct.product?.id, selectedProduct.menuId, {
                vendor,
                category: selectedProduct?.category,
            })
            .then((res) => {
                setSelected({
                    product: { ...res, menuId: selectedProduct.menuId },
                    full: true,
                    menuId: selectedProduct.menuId,
                    selectionId:
                        selectedProduct.selectionId ||
                        (!res.hasAdditives
                            ? basket.items.find((o) => o.id === prod.id && (!o.timestamp || isEmbedVendor))?.selectionId
                            : undefined),
                });
            })
            .catch(() => {
                onClose(false, 'product');
            });
    }, [selectedProduct]);

    useEffect(() => {
        setTempBasket(
            basket.items.find(
                (item) =>
                    item.id === prod.id &&
                    item.selectionId === selected?.selectionId &&
                    (!item.timestamp || isEmbedVendor),
            ) || getDefaultBasket(prod, selectedProduct?.category?.id || ''),
        );
    }, [basket, prod, selected?.selectionId]);

    const alreadyInCart = useMemo<IOrderItem[]>(() => {
        if (selectedProduct?.selectionId) {
            return [];
        }
        return basket.items.filter(
            (item) => item.id === prod.id && item.selectionId !== selected?.selectionId && !item.timestamp,
        );
    }, [basket, prod, selected?.selectionId, isEmbedVendor]);

    const product = useMemo<IProduct>(() => {
        const getSelectedProduct = (child: IProduct, sel?: IAdditiveItem): IProduct => {
            const out: IProduct = {
                ...child,
                selected: sel
                    ? {
                          qty: sel.quantity,
                      }
                    : undefined,
                modifierGroups: child.modifierGroups?.map((mg) => {
                    const selectedItem: IModifierGroupItemCount = { selectedItems: 0, selectedDistinctItems: 0 };
                    return {
                        ...mg,
                        products: mg.products?.map((mgp) => {
                            const mgSel = sel?.additives?.find(
                                (o) => o.id === mgp.id && o.mgId === mg.id && o.quantity,
                            );
                            if (mgSel) {
                                if (selectedItem.selectedItems !== undefined) {
                                    selectedItem.selectedItems += mgSel.quantity;
                                }
                                if (selectedItem.selectedDistinctItems !== undefined) {
                                    selectedItem.selectedDistinctItems++;
                                }
                                if (!selectedItem.maxSelectedQty || selectedItem.maxSelectedQty < mgSel.quantity) {
                                    selectedItem.maxSelectedQty = mgSel.quantity;
                                }
                            }
                            return getSelectedProduct(mgp, mgSel);
                        }),
                        ...selectedItem,
                    };
                }),
                products: child.products?.map((pr) => {
                    return getSelectedProduct(
                        pr,
                        sel?.additives?.find((o) => o.id === pr.id && o.quantity),
                    );
                }),
            };

            const [valid, invalidMgIds] = checkValidation(out);
            out.valid = valid;
            out.invalidMgIds = invalidMgIds;
            return out;
        };
        return getSelectedProduct(prod, tempBasket);
    }, [prod, basket, tempBasket]);

    const valid = useMemo<boolean>(() => {
        const getNestedValidate = (child: IProduct): boolean => {
            return (
                (child.selected?.qty || 0) === 0 ||
                ((child.selected?.qty || 0) > 0 &&
                    !(
                        !child.valid ||
                        (child.products?.some((p) => !getNestedValidate(p)) ?? false) ||
                        (child.modifierGroups?.some((mg) => mg.products?.some((p) => !getNestedValidate(p)) ?? false) ??
                            false)
                    ))
            );
        };
        return getNestedValidate(product);
    }, [product]);

    const modifierSelectHandler: ItemIndicatorChangeFunc = (
        entries: Array<{ product: IProduct; mgId?: string }>,
        qty: number,
        single,
    ) => {
        const mapAdditives = (additives: undefined | IAdditiveItem[], depth?: number): undefined | IAdditiveItem[] => {
            depth = depth || 0;
            if (depth === entries.length) {
                return additives;
            }

            const item = entries[depth || 0];
            if (single && item.mgId && entries.length === depth + 1) {
                const mgIndex = additives?.findIndex((o) => o.mgId === item.mgId && o.quantity > 0) ?? -1;
                if (mgIndex > -1) {
                    additives?.splice(mgIndex, 1);
                }
            }

            const idx = additives?.findIndex((o) => o.id === item.product.id && o.mgId === item.mgId) ?? -1;
            if (additives && idx > -1) {
                if (entries.length === depth + 1) {
                    if (qty === 0) {
                        additives.splice(idx, 1);
                        return additives;
                    }
                    additives[idx].quantity = qty;
                    additives[idx].mgId = item.mgId;
                } else if (qty > 0 && !additives[idx].quantity) {
                    additives[idx].quantity = 1;
                    additives[idx].mgId = item.mgId;
                }

                additives[idx].additives = mapAdditives(additives[idx].additives, depth + 1);
                return additives;
            }

            return [
                ...(additives || []),
                ...(qty > 0
                    ? [
                          {
                              id: item.product.id,
                              price: item.product.price,
                              quantity: entries.length === depth + 1 ? qty : 1,
                              mgId: item.mgId,
                              optionId: item.product?.option?.id,
                              additives: mapAdditives(additives?.[idx]?.additives, depth + 1),
                          },
                      ]
                    : []),
            ];
        };
        setTempBasket((b) => {
            return {
                id: product.id,
                price: product.price,
                quantity: product.selected?.qty || 1,
                menuId: product.menuId,
                ...b,
                additives: mapAdditives(b?.additives),
            };
        });
    };

    const upsellSelectHandler: UpsellUpdateChangeFunc = (p, qty) => {
        setUpsellBasketItems((tt) => {
            const temp = [...tt];
            const idx = temp.findIndex((o) => o.id === p.id);
            if (idx > -1) {
                temp[idx].quantity = qty;
            } else {
                temp.push({
                    quantity: qty,
                    menuId: p.menuId,
                    price: p.price,
                    id: p.id,
                });
            }
            return temp;
        });
    };

    const addToCartHandler = () => {
        if (!valid) {
            setTimeout(() => {
                clearTimeout(modifierAnimationTimeout.current);
                const el = modifierRef.current?.querySelector('div[data-invalid="true"]');
                el?.scrollIntoView({
                    block: 'start',
                    behavior: 'smooth',
                });
                modifierRef.current?.removeAttribute('data-show-animation');
                setTimeout(() => {
                    modifierRef.current?.setAttribute('data-show-animation', 'true');
                }, 10);
                modifierAnimationTimeout.current = setTimeout(() => {
                    modifierRef.current?.removeAttribute('data-show-animation');
                }, 2100);
            }, 50);
            return;
        }

        qsrProductAddChartEvent({
            pageName: 'product details',
            productName: product.name,
            quantity: tempBasket?.quantity || 1,
        });
        const bsk = mergeBasket(
            basket,
            tempBasket || {
                id: product.id,
                price: product.price,
                quantity: 1,
                menuId: product.menuId,
            },
            {
                vendorId: getVendorId(url),
                isEmbedVendor,
            },
        );
        onBasketChange(
            upsellBasketItems.reduce((acc, curr) => {
                return mergeBasket(
                    acc,
                    { ...curr, quantity: curr.quantity * (tempBasket?.quantity || 0) },
                    {
                        vendorId: getVendorId(url),
                        isEmbedVendor,
                    },
                );
            }, bsk),
        );
        onClose(false, 'product');
    };

    const tempOrder = useMemo<IBasket | undefined>(() => {
        const temp: IBasket = {
            vendorId: getVendorId(url),
            extra: undefined,
            items: tempBasket ? [tempBasket] : [],
        };

        return upsellBasketItems.reduce((acc, curr) => {
            return mergeBasket(
                acc,
                { ...curr, quantity: curr.quantity * (tempBasket?.quantity || 0) },
                {
                    vendorId: getVendorId(url),
                    isEmbedVendor,
                },
            );
        }, temp);
    }, [tempBasket, upsellBasketItems]);

    const selectionChangeHandler = (item: IOrderItem) => {
        setSelected((o) => {
            if (!o) {
                return o;
            }
            return {
                ...o,
                selectionId: item.selectionId,
            };
        });
    };

    const disabled = product.disabled || selectedProduct?.category?.disabled || selectedProduct?.menu?.disabled;

    return (
        <>
            <QSRProductWrapper product={product} onClose={() => onClose(false, 'product')}>
                {!selected?.full ? (
                    <div className={styles.loadingContainer}>
                        <CircularProgress size={64} thickness={2} />
                    </div>
                ) : (
                    <div className={styles.container}>
                        <div className={styles.content}>
                            <div className={styles.productContent}>
                                <span className={styles.title}>
                                    {translator(product?.name, product?.nameTranslations, lang)}
                                </span>
                                <QSRCalories calories={product.calories} ui={ui} />
                                <QSRTags tags={product.tags} ui={ui} />
                                <p className={styles.ingredient}>
                                    {translator(product?.subTitle, product?.subTitleTranslations, lang)}
                                </p>
                                <p className={styles.description}>
                                    {translator(product?.description, product?.descriptionTranslations, lang)}
                                </p>
                                <div className={styles.price}>
                                    <QSRPrice
                                        product={product}
                                        value={product.displayPrice}
                                        currencyFormat={{
                                            ...currencyFormat,
                                            currencyPrecision: currencyPrecision || currencyFormat.currencyPrecision,
                                        }}
                                        bold
                                        hasAdditives={product.hasAdditives}
                                        hasDiscount
                                    />
                                    {disabled && (
                                        <Badge
                                            label={t('Out of Stock')}
                                            classes={{ labelOverrides: { color: '#1a1c23 ' } }}
                                        />
                                    )}
                                    {product.priceAdditiveName && (
                                        <Badge
                                            label={product?.priceAdditiveName}
                                            classes={{ labelOverrides: { color: '#1a1c23 ' } }}
                                        />
                                    )}
                                </div>
                                {disabled && (
                                    <div className={styles.availabilityHint}>
                                        <QSRAvailabilityHint
                                            menu={selectedProduct?.menu}
                                            category={selectedProduct?.category}
                                            product={product}
                                        />
                                    </div>
                                )}
                                {qsr && alreadyInCart.length > 0 && (
                                    <div className={styles.inCart}>
                                        <span className={styles.title}>{t('Same Product Already in Cart')}</span>
                                        <Button
                                            variant="text"
                                            size="small"
                                            onClick={() => {
                                                setDrawerOpen(true);
                                            }}
                                        >
                                            {t('Edit')}
                                        </Button>
                                    </div>
                                )}
                            </div>
                            <Divider />
                            <div className={styles.scroll} ref={modifierRef}>
                                <QSRModifiers
                                    product={product}
                                    lang={lang}
                                    vendor={vendor}
                                    qsr={qsr}
                                    currencyPrecision={currencyPrecision}
                                    disabled={disabled}
                                    currencyFormat={currencyFormat}
                                    ui={ui}
                                    onUpsellSelect={upsellSelectHandler}
                                    onModifierSelect={modifierSelectHandler}
                                />
                            </div>
                        </div>
                        <Box
                            className={classNames(styles.cart, {
                                [styles.closeButton]: !qsr,
                            })}
                        >
                            {qsr && <div className={styles.gap} />}
                            <Divider />
                            {qsr ? (
                                <Box className={styles.cartContent}>
                                    {vendor?.orderConfig?.pricePresentation !==
                                        OrderPricePresentationEnum.HidePrice && (
                                        <div className={styles.total}>
                                            <span>{t('Total')}</span>
                                            <QSRPrice
                                                value={(tempOrder
                                                    ? calculateTotalPrice(tempOrder, { currencyPrecision, vendor })
                                                    : product.price
                                                ).toFixed(currencyPrecision)}
                                                currencyFormat={{
                                                    ...currencyFormat,
                                                    currencyPrecision:
                                                        currencyPrecision || currencyFormat.currencyPrecision,
                                                }}
                                                bold
                                                hasDiscount
                                                discountDisplayLeft
                                            />
                                        </div>
                                    )}
                                    <div className={styles.buttonGroup}>
                                        <Box className={styles.indicator}>
                                            <SelectionIndicator
                                                value={tempBasket?.quantity || 0}
                                                min={product?.min || 1}
                                                max={product?.max}
                                                disabled={product.disabled}
                                                onValueChange={(num) => {
                                                    setTempBasket((b) => {
                                                        if (b) {
                                                            return {
                                                                ...b,
                                                                quantity: num,
                                                            };
                                                        }
                                                        return {
                                                            id: product.id,
                                                            menuId: product.menuId,
                                                            price: product.price,
                                                            quantity: num,
                                                        };
                                                    });
                                                }}
                                            />
                                        </Box>
                                        <Button
                                            fullWidth
                                            variant="contained"
                                            disabled={disabled}
                                            onClick={addToCartHandler}
                                        >
                                            {selected?.selectionId ? t('Update') : t('Add to cart')}
                                        </Button>
                                    </div>
                                </Box>
                            ) : (
                                <Box className={styles.closeButtonContent}>
                                    <Button fullWidth variant="contained" onClick={() => onClose(false, 'product')}>
                                        {t('Close')}
                                    </Button>
                                </Box>
                            )}
                        </Box>
                    </div>
                )}
            </QSRProductWrapper>
            <QSRProductSelection
                product={product}
                selectionList={alreadyInCart}
                open={drawerOpen}
                onOpen={(open) => {
                    setDrawerOpen(open);
                }}
                onSelect={selectionChangeHandler}
            />
        </>
    );
};

export default QSRProduct;
