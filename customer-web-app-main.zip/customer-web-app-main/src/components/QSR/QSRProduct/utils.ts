import {
    IAdditiveItem,
    IModifierGroup,
    IBasket,
    IOrderItem,
    IOrderVendorId,
    IProduct,
} from '@/repositories/menu/types';
import { cloneDeep, isEqual, omit } from 'lodash';

export const checkValidation = (prod: IProduct): [boolean, string[]] => {
    const ids: string[] = [];
    const v =
        (prod.min || 0) <= (prod.selected?.qty || 0) &&
        (prod.max || 10000) >= (prod.selected?.qty || 0) &&
        (prod.products?.every(
            (p) => (p.min || 0) <= (p.selected?.qty || 0) && (p.max || 10000) >= (p.selected?.qty || 0),
        ) ??
            true) &&
        (prod.modifierGroups?.every((mp) => {
            if (mp.disabled) {
                return true;
            }
            if (mp.products?.every((p) => p.disabled)) {
                return true;
            }
            const mpv =
                (mp.multiMax || 10000) >= (mp.maxSelectedQty || 0) &&
                (mp.distinctMax || 10000) >= (mp.selectedDistinctItems || 0) &&
                (mp.min || 0) <= (mp.selectedItems || 0) &&
                (mp.max || 10000) >= (mp.selectedItems || 0);
            if (!mpv) {
                ids.push(mp.id);
            }
            return (
                (mp.products?.length || 0) === 0 ||
                (mpv &&
                    (mp.products?.every(
                        (p) => (p.min || 0) <= (p.selected?.qty || 0) && (p.max || 10000) >= (p.selected?.qty || 0),
                    ) ??
                        true))
            );
        }) ??
            true);

    return [v, ids];
};

export const trimSelection = (productVariation: IAdditiveItem): IOrderItem => {
    const { additives, ...rest } = productVariation;
    const filteredAdditives = additives?.filter((o) => o.quantity);
    if (filteredAdditives && filteredAdditives.length > 0) {
        // @ts-ignore
        return {
            ...rest,
            additives: filteredAdditives.map((item) => trimSelection(item)),
        } as IOrderItem;
    }
    return { ...rest } as IOrderItem;
};

export interface IMergeBasketOptions {
    vendorId: IOrderVendorId;
    isEmbedVendor?: boolean;
}

export const mergeBasket = (basket: IBasket, productVariation: IOrderItem, options: IMergeBasketOptions): IBasket => {
    const bsk = cloneDeep(basket);
    const trimmedProductVariation = trimSelection(productVariation);
    const sameProducts = bsk.items.filter(
        (o) => o.id === trimmedProductVariation.id && (!o.timestamp || options.isEmbedVendor),
    );
    if (sameProducts.length > 0) {
        if (productVariation.selectionId) {
            const sameSelectionIdx = bsk.items.findIndex(
                (o) =>
                    o.id === productVariation.id &&
                    o.selectionId === productVariation.selectionId &&
                    (!o.timestamp || options.isEmbedVendor),
            );
            if (sameSelectionIdx > -1) {
                if (productVariation.quantity > 0) {
                    bsk.items[sameSelectionIdx] = { ...productVariation };
                } else {
                    bsk.items.splice(sameSelectionIdx, 1);
                }
                return bsk;
            }
        }
        const selection = sameProducts.find((o) =>
            isEqual(omit(o, 'selectionId', 'quantity'), omit(trimmedProductVariation, 'quantity')),
        );
        if (selection) {
            const idx = bsk.items.findIndex(
                (o) => o.id === selection.id && o.selectionId === selection.selectionId && !o.timestamp,
            );
            if (idx > -1) {
                const clonedBasked = cloneDeep(bsk);
                clonedBasked.items[idx].quantity += productVariation.quantity;
                return clonedBasked;
            }
        }
    }
    trimmedProductVariation.selectionId = sameProducts.length + 1;
    return {
        extra: bsk.extra,
        items: [...bsk.items, trimmedProductVariation],
        note: bsk.note,
        diningOption: bsk.diningOption,
        vendorId: options.vendorId,
        tableData: bsk.tableData,
    };
};

export const getDefaultBasket = (product: IProduct, catId: string): IOrderItem => {
    const initAdditives = (modifierGroups: Array<IModifierGroup<IProduct>>, products: IProduct[]): IProduct[] => {
        return modifierGroups.reduce((acc, curr) => {
            curr.products?.forEach((mp) => {
                acc.push({
                    ...mp,
                    mgId: curr.id,
                });
            });
            return acc;
        }, products);
    };

    const mapAdditives = (additives: IProduct[]): undefined | IAdditiveItem[] => {
        if (additives.length === 0) {
            return undefined;
        }

        return additives.map((item) => {
            const ads = mapAdditives(initAdditives(item.modifierGroups || [], item.products || []));

            const qty = () => {
                if (item.defaultQuantity && item.defaultQuantity <= item.max && item.defaultQuantity >= item.min) {
                    return item.defaultQuantity;
                }
                if (item.min) {
                    return item.min;
                }

                if (ads?.some((o) => o.quantity)) {
                    return 1;
                }

                return 0;
            };

            return {
                id: item.id,
                price: item.price,
                quantity: qty(),
                mgId: item.mgId,
                optionId: item?.option?.id,
                additives: ads,
            };
        });
    };
    return {
        id: product.id,
        price: product.price,
        quantity: product.min || 1,
        menuId: product.menuId,
        mgId: catId,
        additives: mapAdditives(initAdditives(product.modifierGroups || [], product.products || [])),
    };
};
