import React from 'react';
import classNames from 'classnames';
import { CardMedia, Typography } from '@mui/material';
import Badge from '@qlub-dev/qlub-kit/dist/components/Badge';
import QSRPrice from '@/components/QSR/QSRPrice';
import { IProduct } from '@/repositories/menu/types';
import { ICurrencyFormat } from '@clubpay/customer-common-module/src/repository/vendor';
import { getImageString } from '@/services/utils/k_media';
import noThumbnailProductImgSource from '@/assets/images/no-thumbnail-product.png';
import { IBaseProps } from '@/components/QSR/QSRMenuItemCell';

import styles from './index.module.scss';

export interface IProps extends IBaseProps {
    product: IProduct;
    currencyFormat: ICurrencyFormat;
}

const V2: React.FC<IProps> = ({
    title,
    indicator,
    image: img,
    badges,
    subBadge,
    subTitle,
    description,
    selected,
    gridView,
    product,
    currencyFormat,
    onClick,
}) => {
    const image = gridView ? img || getImageString(noThumbnailProductImgSource) : img;

    return (
        <div
            className={classNames(styles.cell, {
                [styles.gridView]: gridView,
                [styles.listView]: !gridView,
                [styles.selected]: selected,
            })}
            onClick={onClick}
        >
            <div className={styles.content}>
                <div className={styles.imageContainer}>
                    {image && <CardMedia component="img" src={image} className={styles.media} />}
                    {indicator && <div className={styles.indicatorOverlay}>{indicator}</div>}
                </div>
                <div className={styles.details}>
                    {(badges || subBadge) && (
                        <div className={styles.badgeCell}>
                            {badges && badges.map((badge, index) => <Badge key={index} label={badge} isV2 />)}
                            {subBadge}
                        </div>
                    )}
                    <div className={styles.headerCell}>
                        <Typography className={styles.title}>{title}</Typography>
                    </div>
                    {subTitle && <Typography className={styles.subtitle}>{subTitle}</Typography>}
                    {description && <Typography className={styles.description}>{description}</Typography>}
                    <div className={styles.priceContainer}>
                        <div className={styles.price}>
                            <QSRPrice
                                product={product}
                                value={product.displayPrice}
                                currencyFormat={currencyFormat}
                                bold
                                hasDiscount
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default V2;
