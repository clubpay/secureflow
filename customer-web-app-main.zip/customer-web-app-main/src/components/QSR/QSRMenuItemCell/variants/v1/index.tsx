import React from 'react';
import classNames from 'classnames';
import { CardMedia, Typography } from '@mui/material';
import { Badge } from '@qlub-dev/qlub-kit';
import { IBaseProps } from '@/components/QSR/QSRMenuItemCell';

import styles from './index.module.scss';

export interface IProps extends IBaseProps {}

const V1: React.FC<IProps> = ({
    title,
    indicator,
    image,
    badges,
    subBadge,
    subTitle,
    description,
    selected,
    onClick,
    gridView,
}) => {
    return (
        <div
            className={classNames(styles.cell, {
                [styles.gridView]: gridView,
                [styles.selected]: selected,
            })}
            onClick={onClick}
        >
            <div
                className={classNames(styles.lineColumn, {
                    [styles.selected]: selected,
                })}
            />
            <div
                className={classNames(styles.content, {
                    [styles.gridView]: gridView,
                })}
            >
                <div
                    className={classNames(styles.container, {
                        [styles.gridView]: gridView,
                    })}
                >
                    <div className={styles.detailsContainer}>
                        <Typography className={styles.title}>{title}</Typography>
                        <div className={styles.details}>
                            {(badges || subBadge) && (
                                <div className={styles.badgeCell}>
                                    {badges && badges.map((badge, index) => <Badge key={index} label={badge} />)}
                                    {subBadge}
                                </div>
                            )}
                            {subTitle && <p className={styles.subtitle}>{subTitle}</p>}
                            {description && <p className={styles.description}>{description}</p>}
                        </div>
                    </div>
                    {image && (
                        <div className={styles.imageContainer}>
                            <CardMedia
                                component="img"
                                src={image}
                                className={classNames(styles.media, { [styles.gridView]: gridView })}
                            />
                        </div>
                    )}
                </div>
                {indicator}
            </div>
        </div>
    );
};

export default V1;
