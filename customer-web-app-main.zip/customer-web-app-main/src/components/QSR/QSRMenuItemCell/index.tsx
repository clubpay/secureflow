import React, { useMemo } from 'react';
import { IBasket, ICategory, IMenu, IProduct, UIVariantEnum } from '@/repositories/menu/types';
import { translator } from '@/services/utils/k_qsr';
import { getImageString, getMediaFirstItem } from '@/services/utils/k_media';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import styles from '@/components/QSR/QSRProductList/index.module.scss';
import QSRCalories from '@/components/QSR/QSRCalories';
import QSRTags from '@/components/QSR/QSRTags';
import QSRAvailabilityHint from '@/components/QSR/QSRAvailabilityHint';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { ICurrencyFormat } from '@clubpay/customer-common-module/src/repository/vendor';
import V1 from './variants/v1';
import V2 from './variants/v2';

export interface IBaseProps {
    title?: string;
    indicator?: React.ReactNode;
    image?: string;
    badges?: Array<string>;
    subBadge?: React.ReactNode;
    subTitle?: string;
    description?: string | React.ReactNode;
    selected?: boolean;
    gridView?: boolean;
    onClick?: (e?: React.MouseEvent) => void;
}

interface IProps {
    ui: UIVariantEnum;
    listView: boolean;
    menu?: IMenu;
    category: ICategory;
    product: IProduct;
    basket: IBasket;
    isQSR?: boolean;
    currencyFormat: ICurrencyFormat;
    indicator?: React.ReactNode;
    isEmbedVendor?: boolean;
    onClick?: (e?: React.MouseEvent) => void;
}

const QSRMenuItemCell: React.FC<IProps> = ({
    ui,
    listView,
    menu,
    category,
    product,
    basket,
    isQSR,
    isEmbedVendor,
    indicator,
    currencyFormat,
    onClick,
}) => {
    const { t } = useTranslation();
    const { lang } = useQlubRouter();

    const badges = () => {
        if (product.status === 'DISABLED') {
            return [t('Out of Stock', { useLocale: true })];
        }

        return product.snoozed || product.inventory === 0
            ? [t('Out of Stock', { useLocale: true })]
            : product.priceAdditiveName
            ? [product.priceAdditiveName]
            : [];
    };

    const [title, subTitle, image, description, subBadge] = useMemo(() => {
        const sub = () => {
            if ((product.tags?.length || 0) < 1) {
                if ((product.calories?.max || 0) < 1 && (product.calories?.min || 0) < 1) {
                    return null;
                }
            }

            return (
                <div className={styles.subBadgeWrapper}>
                    <QSRCalories calories={product.calories} ui={ui} />
                    <QSRTags tags={product.tags} ui={ui} />
                </div>
            );
        };

        const desc = () => {
            return product.outOfSchedule || category?.outOfSchedule || menu?.outOfSchedule ? (
                <QSRAvailabilityHint menu={menu} product={product} category={category} />
            ) : (
                translator(product.description, product.descriptionTranslations, lang, 79)
            );
        };

        return [
            translator(product.name, product.nameTranslations, lang),
            translator(product.subTitle, product.subTitleTranslations, lang, 79),
            getImageString(getMediaFirstItem(product.media, true)),
            desc(),
            sub(),
        ];
    }, [product, lang]);

    const selected = useMemo(() => {
        return (
            isQSR && listView && basket?.items?.some((pb) => pb.id === product.id && (!pb.timestamp || isEmbedVendor))
        );
    }, [listView, basket, product.id]);

    const baseProps: IBaseProps = {
        title,
        subTitle,
        image,
        selected,
        badges: badges(),
        subBadge,
        description,
        gridView: !listView,
        indicator,
        onClick,
    };

    if (ui === UIVariantEnum.V2) {
        return <V2 {...baseProps} product={product} currencyFormat={currencyFormat} />;
    }

    return <V1 {...baseProps} />;
};

export default QSRMenuItemCell;
