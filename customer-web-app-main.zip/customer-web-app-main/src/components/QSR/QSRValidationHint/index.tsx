import { FC } from 'react';
import { ICommonMenuItemProp } from '@/repositories/menu/types';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import classNames from 'classnames';

import styles from './index.module.scss';

export enum QSRValidationHintTypeEnum {
    Product = 'product',
    ModifierGroup = 'modifierGroup',
}

interface IProps {
    item: ICommonMenuItemProp & { valid?: boolean };
    type: QSRValidationHintTypeEnum;
}

const QSRValidationHint: FC<IProps> = ({ item }) => {
    const { t } = useTranslation('common');

    if (!item.max && !item.min && !item.multiMax && !item.distinctMax) {
        return null;
    }
    const hint = () => {
        if (item.min && (item.max || item.distinctMax)) {
            if (item.min === 1 && (item.max || item.distinctMax) === 1) {
                return t('Select one!');
            }
            return t('Select min {{min}} and max {{max}} items', { min: item.min, max: item.max || item.distinctMax });
        }
        if (item.min) {
            return t('Select min {{min}} items', { min: item.min });
        }
        if (item.max || item.distinctMax) {
            return t('Select max {{max}} items', { max: item.max || item.distinctMax });
        }
        return null;
    };
    return hint() !== null ? (
        <div className={classNames(styles.hintWrapper, { [styles.valid]: item.valid })}>
            <div className={styles.quantity}>{hint()}</div>
        </div>
    ) : (
        <></>
    );
};

export default QSRValidationHint;
