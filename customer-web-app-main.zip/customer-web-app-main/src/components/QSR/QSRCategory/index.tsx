import React, { useEffect, useRef, useState } from 'react';
import { ICategory, MenuTypeEnum } from '@/repositories/menu/types';
import { ThemeModeEnum } from '@clubpay/customer-common-module/src/context/config';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import classNames from 'classnames';
import { Typography } from '@qlub-dev/qlub-kit';
import { translator } from '@/services/utils/k_qsr';
import { Skeleton, Tab, Tabs } from '@mui/material';
import { moveToStart } from '@/services/utils/k_menu';
import MenuAPIManager from '@/repositories/menu';
import SkeletonCategory from './Skeleton';

import styles from './index.module.scss';

interface IProps {
    selectedId: string;
    categories: ICategory[];
    loading?: boolean;
    isSingleMenu?: boolean;
    onChange: (id: string) => void;
}

const QSRCategory = ({ selectedId, categories, loading, onChange, isSingleMenu }: IProps) => {
    const { url, lang, theme } = useQlubRouter();
    const tabRefs = useRef<Record<string, any>>({}); // References for individual tabs
    const [categoryMap, setCategoryMap] = useState<Record<string, ICategory>>({});

    useEffect(() => {
        moveToStart(tabRefs.current[selectedId]);
    }, [selectedId]);

    useEffect(() => {
        if (!categories?.length || !categories.some((o) => o._lazy)) {
            return;
        }

        MenuAPIManager.getInstance()
            .getMenu(url, { page: 0, limit: 100 })
            .then((res) => {
                setCategoryMap(
                    res?.rows
                        ?.find((menu) => menu.type === MenuTypeEnum.UPSELL)
                        ?.categories.reduce<Record<string, ICategory>>((acc, curr) => {
                            acc[curr.id] = curr;
                            return acc;
                        }, {}) || {},
                );
            });
    }, [categories]);

    if (categories.length <= 1) {
        return null;
    }

    const isBlackMode = theme === ThemeModeEnum.Black;

    const tabChangeHandler = (e: any, catId: string) => {
        setTimeout(() => {
            onChange(catId);
        }, 100);
    };

    const renderTabsContent = () => {
        if (loading) {
            return <SkeletonCategory />;
        }

        return (
            <Tabs
                variant="scrollable"
                className={styles.tabs}
                TabIndicatorProps={{
                    hidden: true,
                }}
                scrollButtons={false}
                value={selectedId}
                onChange={tabChangeHandler}
            >
                {categories.map((item) => {
                    const lazyCategory = item._lazy && categoryMap[item.id];
                    return (
                        <Tab
                            key={item.id}
                            className={styles.tab}
                            classes={{
                                selected: styles.tabSelected,
                            }}
                            value={item.id}
                            label={
                                item._lazy && !lazyCategory ? (
                                    <Skeleton width="60" height="24" />
                                ) : item._lazy && lazyCategory ? (
                                    <Typography>
                                        {translator(lazyCategory.name, lazyCategory.nameTranslations, lang)}
                                    </Typography>
                                ) : (
                                    <Typography>{translator(item.name, item.nameTranslations, lang)}</Typography>
                                )
                            }
                            ref={(el) => {
                                tabRefs.current[item.id] = el;
                            }}
                        />
                    );
                })}
            </Tabs>
        );
    };

    return (
        <>
            <div
                className={classNames(styles.container, {
                    [styles.isSingleMenu]: isSingleMenu,
                    [styles.isBlackMode]: isBlackMode,
                })}
            >
                {renderTabsContent()}
            </div>
            <div
                className={classNames(styles.divider, {
                    [styles.isSingleMenu]: isSingleMenu,
                })}
            />
        </>
    );
};

export default QSRCategory;
