import { Box, Skeleton } from '@mui/material';

import styles from '../index.module.scss';

const SkeletonLoading = () => {
    return (
        <div className={styles.skeleton}>
            {Array.from({
                length: 5 || 0,
            }).map((value, index) => (
                <Box key={index} className={styles.skeletonBox}>
                    <Skeleton variant="rounded" width={100} height={32} />
                </Box>
            ))}
        </div>
    );
};

export default SkeletonLoading;
