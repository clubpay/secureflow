import { useMemo } from 'react';
import { IQSROrder, OrderPaymentStatusEnum, OrderStatusEnum, StepperStatusEnum } from '@/repositories/menu/types';
import TableIcon from '@qlub-dev/qlub-kit/dist/assets/icons/TableIcon';
import StepperMyOrderIcon from '@qlub-dev/qlub-kit/dist/assets/icons/StepperMyOrderIcon';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import {
    OrderPaymentMethodEnum,
    OrderPricePresentationEnum,
} from '@clubpay/customer-common-module/src/repository/vendor/type';
import QSRStepper from '@/components/QSR/QSRStepper';
import QSRBillPrice from '@/components/QSR/QSRBillPrice';
import QSRScheduledOrderInfo from '@/components/QSR/QSRScheduleOrderInfo';
import QSRTableName from '@/components/QSR/QSRTableName';
import QSRCircularProgress from '@/components/QSR/QSRCircularProgress';
import QSROrderStatusMessage from '@/components/QSR/QSROrderStatusMessage';

import styles from './index.module.scss';

interface IProps {
    order: IQSROrder | undefined;
    loading: boolean;
    showPayment: boolean;
    bannerComponent?: React.ReactElement<{ position: string }>;
}

const QSRPreparationStatus = ({ order, loading, showPayment, bannerComponent }: IProps) => {
    const { t } = useTranslation('common');
    const { vendor, tableInfo } = useVendor();
    const { config } = useConfigContext();

    const showPrices = vendor?.orderConfig?.pricePresentation !== OrderPricePresentationEnum.HidePrice;

    const stepperStatus = useMemo<StepperStatusEnum>(() => {
        switch (order?.orderStatus) {
            case OrderStatusEnum.DECLINED:
            case OrderStatusEnum.CANCELLED:
            case OrderStatusEnum.FAILED:
            case OrderStatusEnum.SYNC_FAILED:
                return StepperStatusEnum.ERROR;
            case OrderStatusEnum.CLOSED:
                return StepperStatusEnum.ENJOY;
            case OrderStatusEnum.VERIFYING:
                return StepperStatusEnum.VERIFYING;
            default:
                return StepperStatusEnum.PREPARING;
        }
    }, [order]);

    const tableInfoContent = useMemo(() => {
        if (!tableInfo || stepperStatus === StepperStatusEnum.VERIFYING) {
            return null;
        }

        if (stepperStatus === StepperStatusEnum.ERROR || stepperStatus === StepperStatusEnum.ENJOY) {
            return (
                <div className={styles.iconBtn}>
                    <TableIcon />
                    <div className={styles.label}>
                        <QSRTableName vendor={vendor} config={config} tableInfo={tableInfo} />
                    </div>
                </div>
            );
        }

        if (!order?.ticketId) {
            return null;
        }

        return (
            <div className={styles.iconBtn}>
                <StepperMyOrderIcon disabled />
                <div className={styles.text}>{t(`Order #{{orderId}}`, { orderId: order?.ticketId })}</div>
            </div>
        );
    }, [order, tableInfo, stepperStatus]);

    const content = useMemo(() => {
        if (!stepperStatus) {
            return null;
        }

        return <QSRCircularProgress order={order} stepperStatus={stepperStatus} />;
    }, [order, vendor, stepperStatus]);

    const scheduledContent = useMemo(() => {
        if (!vendor?.orderConfig?.scheduledOrderEnable) {
            return null;
        }

        return (
            <div className={styles.scheduledOrderInfo}>
                <QSRScheduledOrderInfo pickupAt={order?.scheduledAt && order?.pickupAt} />
            </div>
        );
    }, [vendor, order]);

    const paymentContent = useMemo(() => {
        if (
            vendor?.orderConfig?.paymentMethod === OrderPaymentMethodEnum.NoPayment ||
            !showPrices ||
            stepperStatus === StepperStatusEnum.VERIFYING
        ) {
            return null;
        }

        return <QSRBillPrice loading={loading} order={order} showPayment={showPayment} />;
    }, [showPayment, vendor, order]);

    const ticketInfoContent = useMemo(() => {
        if (
            !order?.ticketId ||
            (stepperStatus !== StepperStatusEnum.ENJOY && stepperStatus !== StepperStatusEnum.ERROR)
        ) {
            return null;
        }

        return <>{t(`Order #{{orderId}}`, { orderId: order.ticketId })}</>;
    }, [stepperStatus, order?.ticketId]);

    return (
        <div className={styles.container}>
            <div className={styles.stepper}>
                <QSRStepper
                    config={config}
                    vendor={vendor}
                    tableInfo={tableInfo}
                    status={stepperStatus}
                    isPaid={order?.paymentStatus === OrderPaymentStatusEnum.Success}
                />
                {bannerComponent?.props?.position === 'top' && bannerComponent}
            </div>
            <div className={styles.info}>{tableInfoContent}</div>
            <div className={styles.scheduledOrderInfo}>{scheduledContent}</div>
            <div className={styles.content}>{content}</div>
            <div className={styles.statusMessage}>
                <QSROrderStatusMessage order={order} stepperStatus={stepperStatus} />
            </div>
            {bannerComponent?.props?.position === 'middle' && bannerComponent}
            <div className={styles.payment}>{paymentContent}</div>
            <div className={styles.ticketInfo}>{ticketInfoContent}</div>
        </div>
    );
};

export default QSRPreparationStatus;
