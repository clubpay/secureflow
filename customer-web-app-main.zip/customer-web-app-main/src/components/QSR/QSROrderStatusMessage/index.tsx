import { memo, useMemo } from 'react';
import { IQSROrder, OrderStatusEnum, StepperStatusEnum } from '@/repositories/menu/types';
import MultiLocale from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import classNames from 'classnames';

import styles from './index.module.scss';

interface IProps {
    order: IQSROrder | undefined;
    stepperStatus: StepperStatusEnum;
}

const QSROrderStatusMessage = ({ order, stepperStatus }: IProps) => {
    const { t } = useTranslation('common');
    const { vendor } = useVendor();
    const { lang } = useQlubRouter();
    const { config } = useConfigContext();

    const orderMessage = useMemo<{
        title: string;
        subTitle?: string;
    }>(() => {
        switch (order?.orderStatus) {
            case OrderStatusEnum.DECLINED:
            case OrderStatusEnum.CANCELLED:
                const declinedTitle = vendor?.orderConfig?.statusTitle?.declined || config?.orderStatusTitle?.declined;
                const declinedDesc = vendor?.orderConfig?.statusDesc?.declined || config?.orderStatusDesc?.declined;
                return {
                    title: declinedTitle ? (
                        <MultiLocale value={declinedTitle} lang={lang} />
                    ) : (
                        t('Your order is DECLINED')
                    ),
                    subTitle: declinedDesc ? (
                        <MultiLocale value={declinedDesc} lang={lang} />
                    ) : (
                        t('Please contact to waiter or manager')
                    ),
                };
            case OrderStatusEnum.FAILED:
            case OrderStatusEnum.SYNC_FAILED:
                const failedTitle = vendor?.orderConfig?.statusTitle?.failed || config?.orderStatusTitle?.failed;
                const failedDesc = vendor?.orderConfig?.statusDesc?.failed || config?.orderStatusDesc?.failed;
                return {
                    title: failedTitle ? <MultiLocale value={failedTitle} lang={lang} /> : t('Your order is FAILED'),
                    subTitle: failedDesc ? <MultiLocale value={failedDesc} lang={lang} /> : t('Something went wrong'),
                };
            case OrderStatusEnum.VERIFYING:
                const verifyingTitle =
                    vendor?.orderConfig?.statusTitle?.verifying || config?.orderStatusTitle?.verifying;
                return {
                    title: verifyingTitle ? (
                        <MultiLocale value={verifyingTitle} lang={lang} />
                    ) : (
                        t('Your order has been received and is waiting for acceptance by the restaurant')
                    ),
                };
            case OrderStatusEnum.ACTIVE:
            case OrderStatusEnum.APPROVED:
                const activeTitle = vendor?.orderConfig?.statusTitle?.active || config?.orderStatusTitle?.active;
                const activeDesc = vendor?.orderConfig?.statusDesc?.active || config?.orderStatusDesc?.active;
                return {
                    title: activeTitle ? <MultiLocale value={activeTitle} lang={lang} /> : t('Hang on tight!'),
                    subTitle: activeDesc ? (
                        <MultiLocale value={activeDesc} lang={lang} />
                    ) : (
                        t('Your order is being prepared')
                    ),
                };
            case OrderStatusEnum.PICK_UP:
                const pickUpTitle = vendor?.orderConfig?.statusTitle?.pickUp || config?.orderStatusTitle?.pickUp;
                const pickUpDesc = vendor?.orderConfig?.statusDesc?.pickUp || config?.orderStatusDesc?.pickUp;
                return {
                    title: pickUpTitle ? <MultiLocale value={pickUpTitle} lang={lang} /> : t('Ready for pick up!'),
                    subTitle: pickUpDesc ? (
                        <MultiLocale value={pickUpDesc} lang={lang} />
                    ) : (
                        t('Get you order from counter')
                    ),
                };
            case OrderStatusEnum.CLOSED:
                const closedTitle = vendor?.orderConfig?.statusTitle?.closed || config?.orderStatusTitle?.closed;
                const closedDesc = vendor?.orderConfig?.statusDesc?.closed || config?.orderStatusDesc?.closed;
                return {
                    title: closedTitle ? <MultiLocale value={closedTitle} lang={lang} /> : t('Enjoy your meal'),
                    subTitle: closedDesc ? <MultiLocale value={closedDesc} lang={lang} /> : t('Your order is ready'),
                };
            default:
                const pendingTitle = vendor?.orderConfig?.statusTitle?.pending || config?.orderStatusTitle?.pending;
                const pendingDesc = vendor?.orderConfig?.statusDesc?.pending || config?.orderStatusDesc?.pending;
                return {
                    title: pendingTitle ? (
                        <MultiLocale value={pendingTitle} lang={lang} />
                    ) : (
                        t('Order waiting to be accepted')
                    ),
                    subTitle: pendingDesc ? (
                        <MultiLocale value={pendingDesc} lang={lang} />
                    ) : (
                        t('If there is a problem contact to manager')
                    ),
                };
        }
    }, [order, config, vendor]);

    return (
        <div className={styles.container}>
            <h1
                className={classNames({
                    [styles.large]:
                        stepperStatus === StepperStatusEnum.ERROR || stepperStatus === StepperStatusEnum.ENJOY,
                })}
            >
                {orderMessage.title}
            </h1>
            <p>{orderMessage.subTitle}</p>
        </div>
    );
};

export default memo(QSROrderStatusMessage);
