import { Box, IconButton, SwipeableDrawer } from '@mui/material';
import { CloseRounded } from '@mui/icons-material';
import { Button } from '@qlub-dev/qlub-kit';
import { IMenu } from '@/repositories/menu/types';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { translator } from '@/services/utils/k_qsr';

import styles from './index.module.scss';

interface IProps {
    selectedId?: string;
    menus: IMenu[];
    open: boolean;
    onClose: () => void;
    onOpen: () => void;
    onMenuSelect: (menu: IMenu) => void;
}

const QSRMenuDrawer = ({ selectedId, menus, open, onClose, onOpen, onMenuSelect }: IProps) => {
    const { lang } = useQlubRouter();
    const { t } = useTranslation('common');

    return (
        <SwipeableDrawer
            anchor="bottom"
            open={open}
            onClose={onClose}
            onOpen={onOpen}
            BackdropProps={{ sx: { background: '#00000099' } }}
            PaperProps={{
                sx: {
                    maxWidth: '552px',
                    margin: '0 auto',
                    background: '#fff',
                    borderRadius: '30px 30px 0 0',
                },
            }}
        >
            <div className={styles.drawerContainer}>
                <Box className={styles.drawerContent}>
                    <Box flexGrow={1} className={styles.drawerTitle}>
                        {t('Select meal')}
                    </Box>
                    <Box>
                        <IconButton onClick={onClose}>
                            <CloseRounded />
                        </IconButton>
                    </Box>
                </Box>
                <Box className={styles.categories}>
                    <p className={styles.description}>{t('Choose a menu')}</p>
                    {menus.map((m, index) => {
                        if (m.id === selectedId) {
                            return null;
                        }
                        return (
                            <Button key={index} variant="containedLight" onClick={() => onMenuSelect(m)}>
                                {translator(m.name, m.nameTranslations, lang)}
                            </Button>
                        );
                    })}
                </Box>
            </div>
        </SwipeableDrawer>
    );
};

export default QSRMenuDrawer;
