import { useMemo } from 'react';
import { ICategory, IMenu, IProduct } from '@/repositories/menu/types';
import DateService from '@clubpay/customer-common-module/src/service/date';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import {
    IRestaurant,
    OrderUnavailableItemPresentationEnum,
} from '@clubpay/customer-common-module/src/repository/vendor';

import styles from './index.module.scss';

export const isAvailabilityConfigMatch = (
    vendor: IRestaurant | undefined,
    values: OrderUnavailableItemPresentationEnum[],
) => {
    if (!vendor) {
        return false;
    }
    return vendor?.orderConfig?.unavailableItemPresentation?.some((o) => values.includes(o)) || false;
};

interface IProps {
    menu?: IMenu;
    category?: ICategory;
    product?: IProduct;
}

const QSRAvailabilityHint = ({ menu, category, product }: IProps) => {
    const { t } = useTranslation('common');
    const { vendor } = useVendor();

    const content = useMemo(() => {
        if (
            isAvailabilityConfigMatch(vendor, [
                OrderUnavailableItemPresentationEnum.HideProductHint,
                OrderUnavailableItemPresentationEnum.HideCategoryHint,
            ]) ||
            !product?.outOfSchedule
        ) {
            return t('Not Available Now');
        }
        const times = DateService.getInstance().getOverlapTime([
            menu?.availabilities || [],
            category?.availabilities || [],
            product?.availabilities || [],
        ]);
        if (times.length > 0) {
            return (
                <>
                    {t('Will be available in')}
                    {times.map((time: any, idx: number) => {
                        return (
                            <div key={idx} className={styles.item}>
                                {`${time.start} - ${time.end}`}
                            </div>
                        );
                    })}
                </>
            );
        }
        return t('Not Available Now');
    }, [menu, category, product, t]);

    return <div className={styles.hint}>{content}</div>;
};

export default QSRAvailabilityHint;
