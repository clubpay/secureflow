import { FC } from 'react';
import { IconButton } from '@mui/material';
import { CloseRounded } from '@mui/icons-material';
import classNames from 'classnames';
import styles from './index.module.scss';

type CloseButtonVariant = 'dark' | 'light';

interface IProps {
    onClose: () => void;
    variant?: CloseButtonVariant;
}

const CloseButton: FC<IProps> = ({ onClose, variant = 'dark' }) => {
    return (
        <div
            onClick={onClose}
            className={classNames(styles.close, {
                [styles.dark]: variant === 'dark',
                [styles.light]: variant === 'light',
            })}
        >
            <IconButton className={styles.icon}>
                <CloseRounded fontSize="small" />
            </IconButton>
        </div>
    );
};

export default CloseButton;
