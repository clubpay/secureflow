import React, { useMemo, useState } from 'react';
import { Accordion, AccordionDetails, AccordionSummary, Skeleton, useTheme } from '@mui/material';
import { groupBy, orderBy } from 'lodash';
import { ExpandMore } from '@mui/icons-material';
import { FoodItem, DollarIcon, TipIcon } from '@qlub-dev/qlub-kit';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import DateService from '@clubpay/customer-common-module/src/service/date';
import { OrderIdPresentationEnum, OrderPaymentMethodEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { getDateAndTimeMin } from '@clubpay/customer-common-module/src/utility/k_time';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getCurrencyPrecision } from '@clubpay/customer-common-module/src/utility/k_currency';
import QSROrderItem from '@/components/QSR/QSROrderItem';
import QSRPrice from '@/components/QSR/QSRPrice';
import { IQSROrder, OrderItemStatusEnum, OrderStatusEnum } from '@/repositories/menu/types';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import OrderListIcon from '@/components/Common/Icons/OrderListIcon';
import classNames from 'classnames';

import styles from './index.module.scss';

interface IProps {
    payLater: boolean;
    order: IQSROrder | undefined;
    loading: boolean;
    showPrices?: boolean;
}

const QSROrderBatchList = ({ payLater, order, loading, showPrices }: IProps) => {
    const { t } = useTranslation('common');
    const theme = useTheme();
    const { lang } = useQlubRouter();
    const { vendor, currencyFormat } = useVendor();
    const [open, setOpen] = useState(false);
    const [expanded, setExpanded] = useState(false);
    const {
        qsr: { qsrPrepOrderDetailsEvent },
    } = useQsrEventsCenter();

    const list = useMemo<IQSROrder[]>(() => {
        if (!open || !order) {
            return [];
        }

        const dateService = DateService.getInstance();

        const mapOrderStatusToItemStatus = (orderStatus: OrderStatusEnum): OrderItemStatusEnum => {
            switch (orderStatus) {
                case OrderStatusEnum.PENDING:
                case OrderStatusEnum.ACTIVE:
                case OrderStatusEnum.SCHEDULED:
                    return OrderItemStatusEnum.New;
                case OrderStatusEnum.APPROVED:
                    return OrderItemStatusEnum.Approved;
                case OrderStatusEnum.PICK_UP:
                    return OrderItemStatusEnum.PickUp;
                case OrderStatusEnum.CLOSED:
                case OrderStatusEnum.DELIVERED:
                    return OrderItemStatusEnum.Completed;
                default:
                    return OrderItemStatusEnum.Rejected;
            }
        };

        return orderBy(
            Object.entries(groupBy(order.orderData.items || [], (o) => o.timestamp || 0)).map(([unix, o]) => {
                const batchStatus =
                    o?.[0]?.status || mapOrderStatusToItemStatus(order.orderStatus || OrderStatusEnum.PENDING);
                return {
                    ...order,
                    orderData: {
                        ...order.orderData,
                        items: o,
                    },
                    date:
                        unix !== '0'
                            ? dateService.getDateFromUnix(Number(unix))
                            : vendor?.orderConfig?.paymentMethod === OrderPaymentMethodEnum.Default
                            ? order.paidAt || order.createdAt
                            : order.createdAt,
                    batchStatus,
                    batchId: o?.[0]?.uid,
                    batchSort: (batchStatus || '') < OrderItemStatusEnum.New, // sort by status with this
                    note: order.orderData.version === 'v2' ? o?.[0]?.batchNote : o?.[0]?.note,
                };
            }),
            ['date'],
            ['desc'],
        );
    }, [open, order, vendor]);

    const refIdOrOrderIdPresentation = useMemo(() => {
        switch (vendor?.orderConfig?.orderIdPresentation) {
            case OrderIdPresentationEnum.TicketId:
                return t('Ticket ID: {{value}}', {
                    value: order?.ticketId,
                });
            default:
                return t('Ref ID: {{value}}', {
                    value: order?.refId,
                });
        }
    }, [vendor?.orderConfig?.orderIdPresentation, order, lang]);

    const currencyPrecision = useMemo(() => getCurrencyPrecision(vendor?.country?.currencyCode), [vendor]);

    const tip =
        order?.paymentResponse?.tip && order.paymentResponse.tip !== 0 ? order.paymentResponse.tip.toString() : null;

    if (!vendor || vendor?.orderConfig?.orderHistoryDisable) {
        return null;
    }

    if (loading && !order) {
        return <Skeleton height={90} width="90%" />;
    }

    return (
        <div className={styles.content}>
            <Accordion
                expanded={expanded}
                onChange={(e, isExpanded) => {
                    setExpanded(isExpanded);
                    if (isExpanded) {
                        qsrPrepOrderDetailsEvent('qsrPreparation');
                    }
                }}
                onClick={() => {
                    setOpen(true);
                }}
                className={styles.accordion}
            >
                <AccordionSummary
                    className={classNames(styles.accordionSum, { [styles.expanded]: expanded })}
                    expandIcon={<ExpandMore fontSize="large" />}
                >
                    <OrderListIcon />
                    <div className={styles.summary}>
                        {Boolean(refIdOrOrderIdPresentation) && (
                            <TypographyT
                                typo="caption_overline"
                                sx={{ color: theme.qlub.palette.onSurfaceColors.mediumEmphasis }}
                            >
                                {refIdOrOrderIdPresentation}
                            </TypographyT>
                        )}
                        <TypographyT typo="title_md" sx={{ color: theme.qlub.palette.onSurfaceColors.highEmphasis }}>
                            {t('Order Details')}
                        </TypographyT>
                        <TypographyT
                            typo="caption_overline"
                            sx={{ color: theme.qlub.palette.onSurfaceColors.highEmphasis }}
                        >
                            {order &&
                                getDateAndTimeMin(
                                    vendor?.orderConfig?.paymentMethod === OrderPaymentMethodEnum.Default
                                        ? order.paidAt || order.createdAt
                                        : order.createdAt,
                                )}
                        </TypographyT>
                    </div>
                </AccordionSummary>
                <AccordionDetails className={styles.details}>
                    <div className={styles.orders}>
                        {list.map((item, index) => {
                            return <QSROrderItem order={item} key={item.batchId || index} />;
                        })}
                    </div>
                    {showPrices && payLater && (
                        <div className={styles.total}>
                            <FoodItem
                                icon={<DollarIcon style={{ height: '16px' }} />}
                                name={t('Subtotal')}
                                classes={{
                                    foodCardOverrides: {
                                        paddingBottom: '0 !important',
                                    },
                                }}
                                dimmed
                                price={
                                    <div
                                        style={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            color: theme.qlub.palette.onSurfaceColors.mediumEmphasis,
                                        }}
                                    >
                                        <QSRPrice
                                            value={order?.subTotal.toString()}
                                            currencyFormat={{
                                                ...currencyFormat,
                                                currencyPrecision:
                                                    currencyPrecision || currencyFormat.currencyPrecision,
                                            }}
                                            hasDiscount
                                        />
                                    </div>
                                }
                            />
                            {tip && (
                                <FoodItem
                                    icon={<TipIcon />}
                                    name={t('Tip Amount')}
                                    classes={{
                                        foodCardOverrides: {
                                            paddingBottom: '0 !important',
                                        },
                                    }}
                                    dimmed
                                    price={
                                        <div
                                            style={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                color: theme.qlub.palette.onSurfaceColors.mediumEmphasis,
                                            }}
                                        >
                                            <QSRPrice
                                                value={tip}
                                                currencyFormat={{
                                                    ...currencyFormat,
                                                    currencyPrecision:
                                                        currencyPrecision || currencyFormat.currencyPrecision,
                                                }}
                                            />
                                        </div>
                                    }
                                />
                            )}
                            <FoodItem
                                icon={<DollarIcon />}
                                name={t('Total')}
                                classes={{
                                    foodCardOverrides: {
                                        paddingBottom: '0 !important',
                                    },
                                }}
                                price={
                                    <div style={{ display: 'flex', alignItems: 'center' }}>
                                        <QSRPrice
                                            value={order?.total.toString()}
                                            currencyFormat={{
                                                ...currencyFormat,
                                                currencyPrecision:
                                                    currencyPrecision || currencyFormat.currencyPrecision,
                                            }}
                                        />
                                    </div>
                                }
                            />
                        </div>
                    )}
                </AccordionDetails>
            </Accordion>
        </div>
    );
};

export default QSROrderBatchList;
