import { useEffect, useMemo } from 'react';
import { IQSROrder, OrderStatusEnum, StepperStatusEnum } from '@/repositories/menu/types';
import QSRCircular, { QSRCircularColor } from '@qlub-dev/qlub-kit/dist/components/QSRCircular';
import OrderEnjoyIcon from '@qlub-dev/qlub-kit/dist/assets/icons/OrderEnjoyIcon';
import OrderErrorIcon from '@qlub-dev/qlub-kit/dist/assets/icons/OrderErrorIcon';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useTimer } from '@clubpay/customer-common-module/src/hook/timer';
import { preparationTimeDiff } from '@/services/utils/k_qsr';
import QSRPosStatus from '@/components/QSR/QSRPosStatus';

interface IProps {
    order: IQSROrder | undefined;
    stepperStatus: StepperStatusEnum;
}

const QSRCircularProgress = ({ order, stepperStatus }: IProps) => {
    const { vendor } = useVendor();
    const { text: timerText, setCurrentTime } = useTimer();

    useEffect(() => {
        if (
            !order ||
            ![OrderStatusEnum.APPROVED, OrderStatusEnum.PREPARING].includes(
                order.orderStatus || OrderStatusEnum.PENDING,
            )
        ) {
            return;
        }

        if (!order?.timer?.active || !order?.timer?.time) {
            return;
        }

        setCurrentTime(preparationTimeDiff(order?.timer?.time, order?.timer?.acceptedAt));
    }, [order]);

    const timerValue = useMemo(() => {
        if (
            !order ||
            ![OrderStatusEnum.APPROVED, OrderStatusEnum.PREPARING].includes(
                order.orderStatus || OrderStatusEnum.PENDING,
            )
        ) {
            return 0;
        }
        const percent = Math.round(
            (preparationTimeDiff(order?.timer?.time, order?.timer?.acceptedAt) / ((order?.timer?.time || 0) * 60)) *
                100,
        );

        return 100 - percent;
    }, [order]);

    const activeOrderStatus = useMemo(() => {
        switch (order?.orderStatus) {
            case OrderStatusEnum.DECLINED:
            case OrderStatusEnum.CANCELLED:
            case OrderStatusEnum.SYNC_FAILED:
            case OrderStatusEnum.FAILED:
                return QSRCircularColor.FAILED;
            case OrderStatusEnum.ACTIVE:
            case OrderStatusEnum.APPROVED:
            case OrderStatusEnum.PICK_UP:
                return QSRCircularColor.PRIMARY;
            case OrderStatusEnum.CLOSED:
                return QSRCircularColor.SUCCESS;
            default:
                return QSRCircularColor.SECONDARY;
        }
    }, [order]);

    if (stepperStatus === StepperStatusEnum.ERROR) {
        return (
            <div>
                <OrderErrorIcon />
            </div>
        );
    }

    if (stepperStatus === StepperStatusEnum.ENJOY) {
        return (
            <div>
                <OrderEnjoyIcon />
            </div>
        );
    }

    if (stepperStatus === StepperStatusEnum.VERIFYING) {
        return <QSRPosStatus />;
    }

    return (
        <QSRCircular
            value={timerValue}
            size={144}
            imgSrc={vendor?.logoBigUrl}
            thickness={3}
            timeCount={
                [OrderStatusEnum.APPROVED, OrderStatusEnum.PREPARING].includes(
                    order?.orderStatus || OrderStatusEnum.PENDING,
                )
                    ? timerText
                    : ''
            }
            activeStatus={activeOrderStatus}
            containerOverrides={{ justifyContent: 'space-evenly' }}
        />
    );
};

export default QSRCircularProgress;
