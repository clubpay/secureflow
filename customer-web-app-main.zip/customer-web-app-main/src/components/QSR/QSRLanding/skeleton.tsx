import { Grid, Skeleton } from '@mui/material';

import styles from './index.module.scss';

const SkeletonComponent = () => {
    return (
        <div className={styles.categoriesImgList}>
            <Grid container justifyContent="center" alignItems="center">
                <Skeleton variant="text" width="100%" height={150} />
                <Skeleton variant="text" width="70%" height={50} />
            </Grid>
            <Grid container justifyContent="center" alignItems="center">
                <Skeleton variant="text" width="100%" height={150} />
                <Skeleton variant="text" width="70%" height={50} />
            </Grid>
            <Grid container justifyContent="center" alignItems="center">
                <Skeleton variant="text" width="100%" height={150} />
                <Skeleton variant="text" width="70%" height={50} />
            </Grid>
            <Grid container justifyContent="center" alignItems="center">
                <Skeleton variant="text" width="100%" height={150} />
                <Skeleton variant="text" width="70%" height={50} />
            </Grid>
        </div>
    );
};
export default SkeletonComponent;
