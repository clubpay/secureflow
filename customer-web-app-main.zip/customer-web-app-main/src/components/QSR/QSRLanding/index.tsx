import { useEffect, useMemo } from 'react';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { IMenu } from '@/repositories/menu/types';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getMediaFirstItem } from '@/services/utils/k_media';
import classNames from 'classnames';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import TypographyT from '@qlub-dev/qlub-kit/dist/components/Typography';
import { KeyboardArrowLeftRounded, KeyboardArrowRightRounded } from '@mui/icons-material';
import { IconButton, useTheme } from '@mui/material';
import { CategoryItemV2, Divider } from '@qlub-dev/qlub-kit';
import foodPatternImg from '@/assets/images/food-pattern.png';
import { useQsrColors } from '@/hooks/qsrColors';
import { translator, trimPathnameForEmbed } from '@/services/utils/k_qsr';
import { SliderLocationEnum } from '@clubpay/customer-common-module/src/component/KSlider/enums';
import QSRBanner from '@/components/QSR/QSRBanner';
import SkeletonComponent from './skeleton';

import styles from './index.module.scss';

interface IProps {
    menu: IMenu[] | undefined;
    loading: boolean;
}

const QSRLanding = ({ menu, loading }: IProps) => {
    const { vendor } = useVendor();
    const { lang, routerPush, query, pathname } = useQlubRouter();
    const {
        qsr: { qsrMenuSelectEvent, qsrPageViewEvent },
    } = useQsrEventsCenter();
    const theme = useTheme();
    const { getByIndex } = useQsrColors();

    const { qrpc } = query;

    useEffect(() => {
        qsrPageViewEvent('qsrLanding');
    }, []);

    const menuOpenHandler = (m: IMenu) => {
        qsrMenuSelectEvent({ name: m.name, id: m.id });
        if (!m.id) {
            return;
        }

        return routerPush(trimPathnameForEmbed('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr/[menu]', pathname), {
            menu: m.id,
            ...(qrpc ? { qrpc } : {}),
        });
    };

    const menuList = useMemo(() => {
        if (!menu) {
            return null;
        }

        const showImgList = menu.some((item) => getMediaFirstItem(item?.media));

        const imageLessList = () => {
            return (
                <div className={styles.categoriesImgLessList}>
                    {menu?.map((m, index) => {
                        return (
                            <div
                                className={styles.menuItem}
                                style={{ backgroundColor: getByIndex(index) }}
                                key={index}
                                onClick={() => menuOpenHandler(m)}
                            >
                                <div className={styles.title}>
                                    <TypographyT
                                        typo="title_sm"
                                        sx={{
                                            display: '-webkit-box',
                                            color: theme.qlub.palette.onSurfaceColors.highEmphasis,
                                            overflow: 'hidden',
                                            textOverflow: 'ellipsis',
                                            WebkitLineClamp: '2',
                                            WebkitBoxOrient: 'vertical',
                                        }}
                                    >
                                        {translator(m.name, m.nameTranslations, lang)}
                                    </TypographyT>
                                    {Boolean(translator(m.description, m.descriptionTranslations, lang)) && (
                                        <TypographyT
                                            typo="caption_overline"
                                            sx={{
                                                color: theme.qlub.palette.onSurfaceColors.mediumEmphasis,
                                                display: '-webkit-box',
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                                WebkitLineClamp: '3',
                                                WebkitBoxOrient: 'vertical',
                                            }}
                                        >
                                            {translator(m.description, m.descriptionTranslations, lang)}
                                        </TypographyT>
                                    )}
                                </div>
                                <IconButton sx={{ padding: '0px' }}>
                                    {theme.direction === 'ltr' ? (
                                        <KeyboardArrowRightRounded
                                            sx={{ color: theme.qlub.palette.onSurfaceColors.disabled }}
                                        />
                                    ) : (
                                        <KeyboardArrowLeftRounded
                                            sx={{ color: theme.qlub.palette.onSurfaceColors.disabled }}
                                        />
                                    )}
                                </IconButton>
                            </div>
                        );
                    })}
                </div>
            );
        };

        const alternativeImg = (m: IMenu, index: number) => {
            if (getMediaFirstItem(m?.media)) {
                return null;
            }
            return (
                <div className={styles.placeholder} style={{ backgroundColor: getByIndex(index) }}>
                    <img src={foodPatternImg.src} alt="mask" className={styles.maskImg} />
                    {vendor?.orderConfig?.menuListWithLogo && (vendor?.logoBigUrl || vendor?.logoSmallUrl) && (
                        <img src={vendor?.logoBigUrl} alt="vendorlogo" className={styles.logoImg} />
                    )}
                </div>
            );
        };

        const withImageList = () => {
            return (
                <div className={styles.categoriesImgList}>
                    {menu?.map((m, index) => {
                        return (
                            <div className={styles.menuItem} key={index} onClick={() => menuOpenHandler(m)}>
                                {alternativeImg(m, index)}
                                <CategoryItemV2
                                    description={translator(m.description, m.descriptionTranslations, lang)}
                                    imageSrc={getMediaFirstItem(m?.media)}
                                    title={translator(m.name, m.nameTranslations, lang)}
                                />
                            </div>
                        );
                    })}
                </div>
            );
        };
        return showImgList ? withImageList() : imageLessList();
    }, [menu, lang, vendor, theme.direction]);

    return (
        <div
            className={classNames(styles.container, {
                [styles.noLogo]: !vendor?.logoBigUrl,
            })}
        >
            <Divider type="fullWidth" />
            <QSRBanner location={SliderLocationEnum.QSRMenusPage} />
            {loading && <SkeletonComponent />}
            {!loading && menuList}
        </div>
    );
};
export default QSRLanding;
