import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Box, Grid, TextField, Button } from '@mui/material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import PhoneInputV2 from '@clubpay/customer-common-module/src/component/PhoneInputV2';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { isValidText } from '@clubpay/customer-common-module/src/utility/k_lang';
import { parseJSON } from '@clubpay/customer-common-module/src/utility/k_json';
import { FastField, FieldProps, Formik } from 'formik';
import MenuAPIManager from '@/repositories/menu';
import { IUserInfo } from '@/repositories/menu/types';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import classNames from 'classnames';
import * as Yup from 'yup';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
// @ts-ignore
import { ObjectSchemaConstructor, StringSchema } from 'yup';
import { FormikHelpers } from 'formik/dist/types';
import { checkCPFInvalidity } from '@/components/QSR/QSRCustomerDetails/utils';
import { OrderCustomerDetailsKeyEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import MultiLocale from '@clubpay/customer-common-module/src/component/MultiLocale';
import { DiningOptionEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';

import styles from './index.module.scss';

export type SubmitFuncType = () => Promise<{ [key: string]: string } | undefined>;

interface IPromise {
    resolve?: any | null;
    reject?: any | null;
}

interface IProps {
    withButton?: boolean;
    withBoarder?: boolean;
    initData?: IUserInfo | undefined;
    diningOption?: DiningOptionEnum;
    submitFn?: (fn: SubmitFuncType) => void;
    onSubmit?: (values: Partial<IUserInfo>) => void;
    onDone?: () => void;
}

const QSRCustomerDetails = ({
    submitFn,
    withButton,
    withBoarder,
    initData,
    diningOption,
    onDone,
    onSubmit,
}: IProps) => {
    const menuApi = MenuAPIManager.getInstance();
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const { vendor } = useVendor();
    const { url, lang } = useQlubRouter();

    const submitButtonRef = useRef<HTMLButtonElement | null>(null);
    const [submitted, setSubmitted] = useState(false);
    const [isValidPhone, setIsValidPhone] = useState<boolean>(false);
    const [isSubmitBtnClicked, setIsSubmitBtnClicked] = useState<boolean>(false);
    const promise = useRef<IPromise>({
        resolve: null,
        reject: null,
    });

    const submitFnHandler: SubmitFuncType = () => {
        return new Promise((resolve, reject) => {
            promise.current.resolve = resolve;
            promise.current.reject = reject;
            submitButtonRef.current?.click();
        });
    };
    const {
        qsr: { qsrCustomerInfoEntered },
    } = useQsrEventsCenter();

    useEffect(() => {
        if (!submitFn) {
            return;
        }

        submitFn(submitFnHandler);
    }, [submitFn]);

    const blurHandler = (value: string, fieldName: string) => {
        if (value === '') {
            return;
        }

        qsrCustomerInfoEntered(fieldName);
    };

    const [extraFieldMap, extraFieldKeys] = useMemo(() => {
        const dd = Object.keys(vendor?.orderConfig?.customerExtraFields || {}).reduce<string[]>((acc, key) => {
            if (!key) {
                return acc;
            }
            acc.push(key);
            return acc;
        }, []);
        return [vendor?.orderConfig?.customerExtraFields || {}, dd.sort()];
    }, [vendor]);

    const toOmitFields: Record<DiningOptionEnum, string[]> = useMemo(() => {
        const parsedData = parseJSON(vendor?.orderConfig?.diningOptionToOmitFields);
        if (!parsedData || !Array.isArray(parsedData)) {
            return {} as Record<DiningOptionEnum, string[]>;
        }

        return parsedData.reduce<Record<DiningOptionEnum, string[]>>(
            (acc, { key, value }: { key: DiningOptionEnum; value: string }) => {
                if (!key || !value) {
                    return acc;
                }

                acc[key] = value.split(',').map((field) => field.trim());
                return acc;
            },
            {} as Record<DiningOptionEnum, string[]>,
        );
    }, [vendor?.orderConfig?.diningOptionToOmitFields]);

    const shouldIncludeField = useCallback(
        (fieldName: string) => {
            return !(diningOption && toOmitFields && toOmitFields[diningOption]?.includes(fieldName));
        },
        [diningOption, toOmitFields],
    );

    const validationSchema = useMemo(() => {
        const allowedLanguages = vendor?.orderConfig?.allowedInputLanguages || [];
        const checkLanguage = (item: StringSchema, name: string, additionalLanguages?: string[]): StringSchema => {
            if (allowedLanguages.length === 0) {
                return item;
            }

            return item.test(name, t('This language is not supported'), (value: any) =>
                isValidText(value, [...allowedLanguages, ...(additionalLanguages || [])], false),
            );
        };
        const fields =
            vendor?.orderConfig?.customerDetailsFields?.reduce<ObjectSchemaConstructor>((acc, curr) => {
                if (!shouldIncludeField(curr)) {
                    return acc;
                }

                switch (curr) {
                    default:
                    case OrderCustomerDetailsKeyEnum.Name:
                    case OrderCustomerDetailsKeyEnum.Address:
                        acc[curr] = checkLanguage(Yup.string(), curr);
                        break;
                    case OrderCustomerDetailsKeyEnum.CarPlate:
                        acc[curr] = checkLanguage(Yup.string(), curr, ['en']);
                        break;
                    case OrderCustomerDetailsKeyEnum.CPF:
                        acc[curr] = Yup.string().test(curr, t('CPF is not Valid'), (value) =>
                            value ? !checkCPFInvalidity(value) : true,
                        );
                        break;
                    case OrderCustomerDetailsKeyEnum.Email:
                        acc[curr] = checkLanguage(Yup.string().email(), curr, ['en']);
                        break;
                    case OrderCustomerDetailsKeyEnum.Phone:
                        acc[curr] = Yup.string().min(9, t('invalid phone number'));
                        if (!isValidPhone) {
                            acc[curr] = acc[curr].test(
                                'phone-validation',
                                t('invalid phone number'),
                                () => isValidPhone,
                            );
                        }
                        break;
                }
                if (vendor?.orderConfig?.customerDetailsRequiredFields?.includes(curr)) {
                    acc[curr] = acc[curr].required();
                }
                return acc;
            }, {}) || {};
        if (extraFieldKeys.length === 0) {
            return Yup.object(fields);
        }

        return Yup.object(
            extraFieldKeys.reduce<ObjectSchemaConstructor>((acc, key) => {
                if (!shouldIncludeField(key)) {
                    return acc;
                }

                acc[key] = checkLanguage(Yup.string(), key);
                if (vendor?.orderConfig?.customerDetailsRequiredFields?.includes(key as any)) {
                    acc[key] = acc[key].required();
                }
                return acc;
            }, fields),
        );
    }, [vendor, extraFieldKeys, isValidPhone, shouldIncludeField]);

    const initialValues = useMemo(() => {
        const fields =
            vendor?.orderConfig?.customerDetailsFields?.reduce<{ [key: string]: string }>((acc, curr) => {
                if ([OrderCustomerDetailsKeyEnum.CarPlate, OrderCustomerDetailsKeyEnum.CPF].includes(curr)) {
                    // @ts-ignore
                    acc[curr] = initData?.meta?.[curr] || '';
                    // @ts-ignore
                    if (initData?.meta?.[curr] !== '') {
                        qsrCustomerInfoEntered(curr);
                    }
                } else {
                    // @ts-ignore
                    acc[curr] = initData?.[curr] || '';
                    // @ts-ignore
                    if (initData?.[curr] !== '') {
                        qsrCustomerInfoEntered(curr);
                    }
                }
                return acc;
            }, {}) || {};
        if (extraFieldKeys.length === 0) {
            return fields;
        }

        return extraFieldKeys.reduce<{ [key: string]: string }>((acc, key) => {
            acc[key] = initData?.meta?.[key] || '';
            return acc;
        }, fields);
    }, [vendor, initData, extraFieldKeys]);

    const getLabel = (fieldName: string) => {
        switch (fieldName) {
            case OrderCustomerDetailsKeyEnum.Name:
                return t('Name');
            case OrderCustomerDetailsKeyEnum.Email:
                return t('Email');
            case OrderCustomerDetailsKeyEnum.Phone:
                return t('Phone');
            case OrderCustomerDetailsKeyEnum.Address:
                return t('Shipping Address');
            case OrderCustomerDetailsKeyEnum.CarPlate:
                return t('Car Plate');
            case OrderCustomerDetailsKeyEnum.CarColor:
                return t('Car Color');
            case OrderCustomerDetailsKeyEnum.CPF:
                return t('CPF');
            default:
                if (extraFieldMap.hasOwnProperty(fieldName)) {
                    return <MultiLocale value={extraFieldMap[fieldName]} lang={lang} />;
                }
                return '';
        }
    };

    const fieldRenderer = (fieldName: string, { field, meta, form }: FieldProps) => {
        const disabled = Boolean(!vendor?.orderConfig?.customerDetailsAllowEdit && initialValues[fieldName]);
        switch (fieldName) {
            default:
            case OrderCustomerDetailsKeyEnum.Name:
            case OrderCustomerDetailsKeyEnum.Email:
            case OrderCustomerDetailsKeyEnum.Address:
            case OrderCustomerDetailsKeyEnum.CarPlate:
            case OrderCustomerDetailsKeyEnum.CPF:
                return (
                    <TextField
                        {...field}
                        fullWidth
                        disabled={disabled}
                        type="text"
                        label={getLabel(fieldName)}
                        variant="outlined"
                        onBlur={() => blurHandler(field.value, fieldName)}
                        dir={fieldName === OrderCustomerDetailsKeyEnum.Email ? 'ltr' : undefined}
                        multiline={fieldName === OrderCustomerDetailsKeyEnum.Address}
                        minRows={fieldName === OrderCustomerDetailsKeyEnum.Address ? 3 : undefined}
                        error={!!meta.error && meta.touched}
                        helperText={meta.touched && meta.error}
                    />
                );
            case OrderCustomerDetailsKeyEnum.Phone:
                const phoneRequired = vendor?.orderConfig?.customerDetailsRequiredFields?.includes(
                    OrderCustomerDetailsKeyEnum.Phone,
                );
                return (
                    <PhoneInputV2
                        placeholder={getLabel(fieldName)}
                        lang={lang}
                        defaultCountry={url.cc || ''}
                        value={field.value}
                        onChange={(data) => {
                            form.setFieldValue(OrderCustomerDetailsKeyEnum.Phone, data.phone);
                        }}
                        validation={{
                            enable: true,
                            callbackFn: (isValid: boolean) => setIsValidPhone(isValid),
                        }}
                        errorText={t('Please enter a valid phone number!')}
                        countrySearchLabel={t('Search for countries')}
                        forceErrorText={phoneRequired && isSubmitBtnClicked}
                    />
                );
        }
    };

    const getContent = () => {
        return [...(vendor?.orderConfig?.customerDetailsFields || []), ...extraFieldKeys]?.map((fieldName) => {
            if (!shouldIncludeField(fieldName)) {
                return null;
            }

            return (
                <Grid key={fieldName} item xs={12}>
                    <FastField name={fieldName}>{(props: FieldProps) => fieldRenderer(fieldName, props)}</FastField>
                </Grid>
            );
        });
    };

    const handleValidationHighlight = () => {
        setIsSubmitBtnClicked(true);
        setTimeout(() => {
            const firstInvalidElement = document.querySelector('[aria-invalid="true"]') as HTMLElement;
            if (firstInvalidElement) {
                firstInvalidElement.scrollIntoView({
                    block: 'start',
                    behavior: 'smooth',
                });
            }
        }, 50);
    };

    const submitHandler = (values: any, formikHelpers: FormikHelpers<any>) => {
        const { name, phone, email, address, ...rest } = values;
        const editedValues: Partial<IUserInfo> = {
            name: name || '',
            phone: isValidPhone ? phone : '',
            email: email || '',
            address: address || '',
            meta: { ...rest },
        };

        formikHelpers
            .validateForm()
            .then(() => {
                promise.current.resolve?.(editedValues);
                onSubmit?.(editedValues);
                if (!onSubmit && !promise.current.resolve && withButton) {
                    formikHelpers.setSubmitting(true);
                    return menuApi
                        .setUserInfo(url, editedValues)
                        .then(() => {
                            setSubmitted(true);
                            enqueueSnackbar(t('User info successfully submitted'), { variant: 'success' });
                            formikHelpers.setSubmitting(false);
                            onDone?.();
                        })
                        .catch((err) => {
                            enqueueSnackbar(`${err.message}, ${err?.response?.data?.message}`, { variant: 'error' });
                            formikHelpers.setSubmitting(false);
                        });
                }
            })
            .catch((err) => {
                promise.current.reject?.(err);
            })
            .finally(() => {
                formikHelpers.setSubmitting(false);
            });
    };

    if (!vendor?.orderConfig?.customerDetailsFields?.length && extraFieldKeys.length === 0) {
        promise.current?.resolve?.(initialValues);
        return null;
    }

    return (
        <Box className={classNames(styles.form, { [styles.withBorder]: withBoarder })}>
            <div className={styles.title}>{t('Your info')}</div>
            <Formik
                enableReinitialize
                initialValues={initialValues}
                validationSchema={validationSchema}
                onSubmit={submitHandler}
            >
                {({ handleSubmit, handleReset, isSubmitting }) => (
                    <form onSubmit={handleSubmit} onReset={handleReset} key={lang}>
                        <Grid container spacing={2}>
                            {getContent()}
                            <Grid
                                item
                                xs={12}
                                sx={{
                                    display: !withButton ? 'none' : undefined,
                                }}
                            >
                                <Button
                                    className={styles.submit}
                                    disabled={isSubmitting}
                                    type="submit"
                                    variant="contained"
                                    color="primary"
                                    fullWidth
                                    onClick={() => handleValidationHighlight()}
                                    ref={(ref) => {
                                        submitButtonRef.current = ref;
                                    }}
                                >
                                    {submitted ? t('Submitted') : t('Submit')}
                                </Button>
                            </Grid>
                        </Grid>
                    </form>
                )}
            </Formik>
        </Box>
    );
};

export default QSRCustomerDetails;
