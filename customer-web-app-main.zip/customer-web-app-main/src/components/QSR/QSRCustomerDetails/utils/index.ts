export const checkCPFInvalidity = (cpf: string) => {
    const editedCpf = cpf?.replaceAll('.', '')?.replaceAll('-', '') || cpf;
    if (typeof editedCpf !== 'string' || editedCpf.length !== 11 || editedCpf === editedCpf[0].repeat(11)) {
        return true;
    }
    const isVerifiedDigit = (cpfDigit: number, remainder: number) => {
        return (remainder < 2 && cpfDigit === 0) || cpfDigit === 11 - remainder;
    };
    const cpfIntDigits = editedCpf.split('').map(Number);
    const weights1 = [10, 9, 8, 7, 6, 5, 4, 3, 2];
    let sum1 = 0;
    for (let i = 0; i < 9; i++) {
        sum1 += cpfIntDigits.slice(0, 9)[i] * weights1[i];
    }
    const firstRemainder = sum1 % 11;
    const weights2 = [11, 10, 9, 8, 7, 6, 5, 4, 3, 2];
    let sum2 = 0;
    for (let i = 0; i < 10; i++) {
        sum2 += cpfIntDigits[i] * weights2[i];
    }
    const secondRemainder = sum2 % 11;
    return !(isVerifiedDigit(cpfIntDigits[9], firstRemainder) && isVerifiedDigit(cpfIntDigits[10], secondRemainder));
};
