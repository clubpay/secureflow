import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Drawer } from '@mui/material';
import { KeyboardArrowDown } from '@mui/icons-material';
import classNames from 'classnames';
import { Typography, Button, DineInLogo, TakeAwayIcon, DriveThroughLogo } from '@qlub-dev/qlub-kit';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { convertMultiLocaleStringToObject } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { DiningOptionEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';
import { useBasket } from '@/contexts/basket';
import { checkEmpty } from '@/services/utils/k_qsr';

import styles from './index.module.scss';

const diningOptionDefault: { value?: DiningOptionEnum } = {
    value: undefined,
};

export const resetDiningOption = () => {
    diningOptionDefault.value = undefined;
};

export const DiningOptionButton = () => {
    const { t } = useTranslation('common');
    const { vendor } = useVendor();
    const { lang } = useQlubRouter();
    const { basket } = useBasket();

    const diningOptionEnabled = vendor?.orderConfig?.diningOptionEnable;

    if (!diningOptionEnabled) {
        return null;
    }

    const dineType = basket?.diningOption || '';

    const defaultTranslations: Record<string, any> = {
        [DiningOptionEnum.DineIn]: t('Dine-in'),
        [DiningOptionEnum.TakeAway]: t('Takeaway'),
        [DiningOptionEnum.DriveThrough]: t('Drive-through'),
    };

    const selectedDiningOption =
        convertMultiLocaleStringToObject(
            vendor?.orderConfig?.diningOptionCustomText?.[dineType] || '',
            defaultTranslations[dineType],
        )?.[lang] ||
        defaultTranslations[dineType] ||
        t('Select Option');

    const openDrawerHandler = () => {
        window.dispatchEvent(new Event('openDiningOptionDrawer'));
    };

    return (
        <div className={styles.dineOptionBtn} onClick={openDrawerHandler}>
            <div className={styles.text}>{selectedDiningOption}</div>
            <KeyboardArrowDown />
        </div>
    );
};

const QSRDiningOptionModal = () => {
    const { t } = useTranslation('common');
    const [diningOption, setDiningOption] = useState<DiningOptionEnum | undefined>(diningOptionDefault.value);
    const { basket, setBasket } = useBasket();
    const { vendor } = useVendor();
    const { lang } = useQlubRouter();
    const [open, setOpen] = useState(false);

    useEffect(() => {
        if (diningOption) {
            return;
        }

        setOpen(true);
    }, [diningOption]);

    useEffect(() => {
        const handleOpenDrawer = (event: Event) => {
            setOpen(true);
        };
        window.addEventListener('openDiningOptionDrawer', handleOpenDrawer);
        return () => {
            window.removeEventListener('openDiningOptionDrawer', handleOpenDrawer);
        };
    }, []);

    const iconMap = useMemo<Record<string, any>>(() => {
        return {
            [DiningOptionEnum.DineIn]: <DineInLogo />,
            [DiningOptionEnum.TakeAway]: <TakeAwayIcon />,
            [DiningOptionEnum.DriveThrough]: <DriveThroughLogo />,
        };
    }, []);

    const defaultTranslation = useCallback(
        (val: DiningOptionEnum) => {
            switch (val) {
                case DiningOptionEnum.DineIn:
                    return t('Dine-in');
                case DiningOptionEnum.TakeAway:
                    return t('Takeaway');
                case DiningOptionEnum.DriveThrough:
                    return t('Drive-through');
                default:
                    return t('Unknown');
            }
        },
        [lang, t],
    );

    const getItemTranslation = useCallback(
        (val: DiningOptionEnum) => {
            const defaultText = defaultTranslation(val);
            return (
                convertMultiLocaleStringToObject(vendor?.orderConfig?.diningOptionCustomText?.[val] || '', defaultText)[
                    lang
                ] || defaultText
            );
        },
        [vendor, defaultTranslation],
    );

    const doneHandler = useCallback(
        (selectedOption: DiningOptionEnum) => () => {
            diningOptionDefault.value = selectedOption;
            setDiningOption(selectedOption);
            setBasket({
                ...basket,
                diningOption: selectedOption,
            });
            setOpen(false);
        },
        [basket],
    );

    const renderButtons = useMemo(() => {
        const options: DiningOptionEnum[] = checkEmpty(vendor?.orderConfig?.diningOptionList) || [
            DiningOptionEnum.DineIn,
            DiningOptionEnum.TakeAway,
        ];
        const withIcon = vendor?.orderConfig?.diningOptionEnableIcons;

        return options.map((option) => {
            return (
                <Button
                    key={option}
                    variant="containedLight"
                    fullWidth
                    onClick={doneHandler(option)}
                    className={classNames({
                        [styles.textBtn]: !withIcon,
                    })}
                >
                    {withIcon ? iconMap[option] || null : null}
                    <Typography>{getItemTranslation(option)}</Typography>
                </Button>
            );
        });
    }, [vendor, getItemTranslation]);

    return (
        <Drawer
            variant="temporary"
            anchor="bottom"
            disablePortal
            open={open}
            classes={{
                paper: styles.drawerPaper,
            }}
            style={{
                height: '100vvh',
                zIndex: 2001,
            }}
            PaperProps={{
                sx: {
                    maxWidth: '552px',
                    margin: '0 auto',
                    background: '#fff',
                    borderRadius: '30px 30px 0 0',
                },
            }}
        >
            <div className={styles.title}>{t('Please select your preferred option')}</div>
            <div className={styles.buttons}>{renderButtons}</div>
        </Drawer>
    );
};

export default QSRDiningOptionModal;
