import React, { FC } from 'react';
import { Divider } from '@qlub-dev/qlub-kit';
import { BaseTypeEnum, IProduct, UIVariantEnum } from '@/repositories/menu/types';
import {
    IRestaurant,
    OrderUnavailableItemPresentationEnum,
} from '@clubpay/customer-common-module/src/repository/vendor';
import QSRProductItem from '@/components/QSR/QSRProductItem';
import QSRItemSelector, { IModifierProduct, ItemIndicatorChangeFunc } from '@/components/QSR/QSRItemSelector';
import { isAvailabilityConfigMatch } from '@/components/QSR/QSRAvailabilityHint';
import { CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import QSRModifierWrapper from '@/components/QSR/QSRModifierWrapper';
import QSRUpsell, { UpsellUpdateChangeFunc, VariantEnum } from '@/components/QSR/QSRUpsell';

interface IProps {
    product: IProduct;
    parentProducts?: IModifierProduct[];
    lang: string;
    currencyPrecision: number;
    vendor?: IRestaurant;
    qsr?: boolean;
    disabled?: boolean;
    currencyFormat: CurrencyFormat;
    ui: UIVariantEnum;
    onModifierSelect?: ItemIndicatorChangeFunc;
    onUpsellSelect?: UpsellUpdateChangeFunc;
}

const QSRModifiers: FC<IProps> = ({
    product,
    parentProducts,
    lang,
    currencyPrecision,
    vendor,
    qsr,
    disabled,
    currencyFormat,
    ui,
    onModifierSelect,
    onUpsellSelect,
}) => {
    return (
        <div>
            {product.modifierGroups?.map((modifier, idx) => {
                if (modifier._lazy && modifier._type === BaseTypeEnum.Upsell) {
                    if (!modifier._upsell) {
                        return null;
                    }

                    return (
                        <QSRUpsell
                            upsell={modifier._upsell}
                            variant={VariantEnum.Product}
                            divider={idx + 1 !== product.modifierGroups?.length}
                            ui={ui}
                            onChange={onUpsellSelect}
                        />
                    );
                }
                if (
                    modifier.outOfSchedule &&
                    isAvailabilityConfigMatch(vendor, [OrderUnavailableItemPresentationEnum.HideCategory])
                ) {
                    return null;
                }
                // const modifierSelected = modifier.products?.every((p) => !p.selected?.qty);

                if ((modifier.products?.length || 0) > 0) {
                    return (
                        <QSRModifierWrapper
                            key={modifier.id}
                            modifier={modifier}
                            product={product}
                            parentProducts={parentProducts}
                            lang={lang}
                            divider={!parentProducts && product.modifierGroups?.length !== idx + 1}
                            parentSelected={Boolean(product.selected)}
                            defaultExpanded={Boolean(product.modifierGroups?.length === 1)}
                        >
                            {modifier.products?.map((pro, idx2) => {
                                if (
                                    pro.outOfSchedule &&
                                    isAvailabilityConfigMatch(vendor, [
                                        OrderUnavailableItemPresentationEnum.HideProduct,
                                    ])
                                ) {
                                    return null;
                                }
                                const pps: IModifierProduct[] = [
                                    ...(parentProducts || []),
                                    {
                                        product: pro,
                                        mgId: modifier.id,
                                        disabledParent:
                                            disabled ||
                                            product.disabled ||
                                            modifier.disabled ||
                                            parentProducts?.[parentProducts?.length - 1].disabledParent,
                                    },
                                ];
                                return (
                                    <QSRProductItem
                                        key={idx2}
                                        product={pro}
                                        lang={lang}
                                        vendor={vendor}
                                        qsr={qsr}
                                        currencyPrecision={currencyPrecision}
                                        parentProducts={pps}
                                        modifier={modifier}
                                        onChange={onModifierSelect}
                                        Indicator={
                                            qsr ? (
                                                <QSRItemSelector
                                                    parentProducts={pps}
                                                    product={pro}
                                                    modifier={modifier}
                                                    onChange={onModifierSelect}
                                                />
                                            ) : undefined
                                        }
                                        currencyFormat={currencyFormat}
                                    >
                                        <QSRModifiers
                                            parentProducts={pps}
                                            product={pro}
                                            lang={lang}
                                            vendor={vendor}
                                            qsr={qsr}
                                            currencyPrecision={currencyPrecision}
                                            onModifierSelect={onModifierSelect}
                                            currencyFormat={currencyFormat}
                                            ui={ui}
                                        />
                                    </QSRProductItem>
                                );
                            })}
                        </QSRModifierWrapper>
                    );
                }
                return null;
            })}
            {Boolean(product.products && product.products.length) && <Divider />}
            {product.products?.map((pro, idx) => {
                const pps: IModifierProduct[] = [
                    ...(parentProducts || []),
                    {
                        product: pro,
                        disabledParent:
                            disabled || product.disabled || parentProducts?.[parentProducts?.length - 1].disabledParent,
                    },
                ];
                return (
                    <QSRProductItem
                        key={idx}
                        product={pro}
                        lang={lang}
                        vendor={vendor}
                        parentProducts={pps}
                        qsr={qsr}
                        currencyPrecision={currencyPrecision}
                        Indicator={qsr ? <QSRItemSelector parentProducts={pps} product={pro} /> : undefined}
                        currencyFormat={currencyFormat}
                    >
                        <QSRModifiers
                            parentProducts={pps}
                            product={pro}
                            lang={lang}
                            vendor={vendor}
                            qsr={qsr}
                            currencyPrecision={currencyPrecision}
                            onModifierSelect={onModifierSelect}
                            currencyFormat={currencyFormat}
                            ui={ui}
                        />
                    </QSRProductItem>
                );
            })}
        </div>
    );
};

export default QSRModifiers;
