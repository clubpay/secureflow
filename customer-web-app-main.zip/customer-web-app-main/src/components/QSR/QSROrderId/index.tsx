import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { OrderIdPresentationEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { IQSROrder } from '@/repositories/menu/types';

import styles from './index.module.scss';

interface IPropsRef {
    order?: IQSROrder;
    noRefId?: boolean;
    noTicketId?: boolean;
}

const QSROrderId = ({ order, noRefId, noTicketId }: IPropsRef) => {
    const { t } = useTranslation('common');
    const { vendor } = useVendor();

    const orderIdPresentation = vendor?.orderConfig?.orderIdPresentation || OrderIdPresentationEnum.TicketIdAndRefId;

    const getContent = () => {
        if (!order) {
            return null;
        }

        const { refId, ticketId } = order;

        if (!refId && (!ticketId || (ticketId && ticketId === 'null'))) {
            return null;
        }

        const getRefId = () => {
            if (!refId || noRefId) {
                return null;
            }
            return (
                <div className={styles.refId}>
                    {t('Ref ID: ')}
                    <div className={styles.value}>{refId}</div>
                </div>
            );
        };

        const getTicketId = () => {
            if (noTicketId || !ticketId || (ticketId && ticketId === 'null')) {
                return null;
            }
            return (
                <div className={styles.ticketId}>
                    {t('Ticket ID: ')}
                    <div className={styles.value}>{ticketId}</div>
                </div>
            );
        };
        switch (orderIdPresentation) {
            default:
            case OrderIdPresentationEnum.TicketIdAndRefId:
                return (
                    <>
                        {getRefId()}
                        {getTicketId()}
                    </>
                );
            case OrderIdPresentationEnum.RefId:
                return getRefId();
            case OrderIdPresentationEnum.TicketId:
                return getTicketId();
            case OrderIdPresentationEnum.TicketIdOrRefId:
                if (ticketId && ticketId !== 'null') {
                    return getTicketId();
                }
                return getRefId();
        }
    };

    return <div className={styles.container}>{getContent()}</div>;
};

export default QSROrderId;
