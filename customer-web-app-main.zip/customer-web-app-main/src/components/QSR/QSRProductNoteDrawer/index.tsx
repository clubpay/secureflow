import { useMemo, useState, useEffect, useCallback } from 'react';
import { IconButton, Drawer, Stack, Box, TextField, useTheme } from '@mui/material';
import { CloseRounded } from '@mui/icons-material';
import { Button, Typography } from '@qlub-dev/qlub-kit';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { isValidText } from '@clubpay/customer-common-module/src/utility/k_lang';
import { convertMultiLocaleStringToObject } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor';
import { IProductSelect } from '@/components/QSR/QSRProduct';
import { IBasket, IOrderItem } from '@/repositories/menu/types';
import { getVendorId } from '@/contexts/basket';
import { translator } from '@/services/utils/k_qsr';
import { mergeBasket } from '@/components/QSR/QSRProduct/utils';

import styles from './index.module.scss';

interface IProps {
    vendor: IRestaurant | undefined;
    basket: IBasket;
    selectedProduct?: IProductSelect | undefined;
    open: boolean;
    isEmbedVendor: boolean;
    onClose: () => void;
    onBasketChange: (basket: IBasket) => void;
}

const QSRProductNoteDrawer = ({
    vendor,
    basket,
    open,
    selectedProduct,
    isEmbedVendor,
    onClose,
    onBasketChange,
}: IProps) => {
    const { t } = useTranslation('common');
    const { url, lang } = useQlubRouter();
    const theme = useTheme();
    const [note, setNote] = useState('');
    const [error, setError] = useState<boolean>(false);

    const item = useMemo<IOrderItem | undefined>(() => {
        return basket.items.find(
            (o) =>
                o.id === selectedProduct?.product?.id &&
                o.selectionId === selectedProduct?.selectionId &&
                (!o.timestamp || isEmbedVendor),
        );
    }, [basket, selectedProduct, isEmbedVendor]);

    useEffect(() => {
        if (!open) {
            return;
        }

        if (item?.note) {
            setNote(item.note);
        } else {
            setNote('');
        }
    }, [open, selectedProduct]);

    const noteChangeHandler = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        setNote(e.target.value);
        setError(false);
    }, []);

    const noteBlurHandler = useCallback((e: React.FocusEvent<HTMLInputElement>) => {
        const allowedLanguages = vendor?.orderConfig?.allowedInputLanguages || [];
        if (allowedLanguages.length === 0) {
            return;
        }

        setError(e.target.value ? !isValidText(e.target.value, allowedLanguages, false) : false);
    }, []);

    const propagate = useCallback(
        (val: string) => {
            if (!item) {
                return;
            }

            onBasketChange(
                mergeBasket(
                    basket,
                    {
                        ...item,
                        note: val,
                    },
                    { vendorId: getVendorId(url), isEmbedVendor },
                ),
            );
            onClose();
        },
        [item, basket, url, isEmbedVendor],
    );

    const handleConfirm = useCallback(() => {
        propagate(note);
    }, [note]);

    const handleDeleteNote = useCallback(() => {
        propagate('');
    }, [note]);

    const specialRequestDesc = useMemo(() => {
        const defaultText = t('Allergies, dietary restrictions and etc');
        return (
            convertMultiLocaleStringToObject(
                vendor?.orderConfig?.specialRequestDesc || (vendor?.config as any)?.specialRequestDesc || '',
                defaultText,
            )[lang] || defaultText
        );
    }, [vendor, lang, t]);

    return (
        <Drawer
            anchor="bottom"
            open={open}
            onClose={onClose}
            BackdropProps={{ sx: { background: '#00000099' } }}
            PaperProps={{
                elevation: 0,
                sx: {
                    maxWidth: '552px',
                    margin: 'auto',
                    background: 'white',
                    borderRadius: '30px 30px 0px 0px',
                },
            }}
        >
            <div className={styles.main}>
                <Stack direction="row" spacing={2}>
                    <IconButton onClick={onClose} className={styles.closeIcon}>
                        <CloseRounded fontSize="small" />
                    </IconButton>
                </Stack>
                <div className={styles.content}>
                    <Typography className={styles.title}>{t('Add a request')}</Typography>
                    <Typography className={styles.subtitle}>
                        {t('Do you wish to add anything to your {{productName}}? Let us know!', {
                            productName:
                                translator(
                                    selectedProduct?.product.name,
                                    selectedProduct?.product.nameTranslations,
                                    lang,
                                ) || '',
                        })}
                    </Typography>
                    <Box className={styles.request}>
                        <TextField
                            inputProps={{
                                maxLength: 255,
                                sx: {
                                    '&::placeholder': {
                                        color: theme.qlub.palette.onSurfaceColors.disabled,
                                    },
                                },
                            }}
                            classes={{
                                root: styles.inputBox,
                            }}
                            placeholder={specialRequestDesc}
                            value={note}
                            onChange={noteChangeHandler}
                            onBlur={noteBlurHandler}
                            maxRows={6}
                            multiline
                            fullWidth
                            error={error}
                            helperText={error ? t('This language is not supported') : ''}
                        />
                    </Box>
                </div>
                <Stack direction="row" spacing={2} justifyContent="space-between">
                    {item?.note && (
                        <Button className={styles.deleteBtn} variant="contained" onClick={handleDeleteNote} fullWidth>
                            {t('Delete request')}
                        </Button>
                    )}
                    <Button variant="contained" onClick={handleConfirm} disabled={!note || error} fullWidth>
                        {t('Confirm')}
                    </Button>
                </Stack>
            </div>
        </Drawer>
    );
};

export default QSRProductNoteDrawer;
