import React, { FC, useEffect, useRef, useState } from 'react';
import { IconButton, SwipeableDrawer } from '@mui/material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Button } from '@qlub-dev/qlub-kit';
import { CloseRounded } from '@mui/icons-material';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import QSRCustomerDetails, { SubmitFuncType } from '@/components/QSR/QSRCustomerDetails';
import { CustomerDetailsInterfaceEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import MenuAPIManager from '@/repositories/menu';
import { IUserInfo } from '@/repositories/menu/types';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { DiningOptionEnum, IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor/type';

import styles from './index.module.scss';

const checkDenyEdit = (vendor: IRestaurant | undefined, initData: IUserInfo | undefined) => {
    return (
        !vendor?.orderConfig?.customerDetailsAllowEdit && (!initData || Object.values(initData).some((o) => Boolean(o)))
    );
};

interface IPromise {
    resolve?: any | null;
    reject?: any | null;
}

interface IProps {
    submitFn?: (fn: SubmitFuncType) => void;
    withButton?: boolean;
    diningOption?: DiningOptionEnum;
}

const QSRCustomerDetailsWrapper: FC<IProps> = ({ submitFn, withButton, diningOption }) => {
    const menuApi = MenuAPIManager.getInstance();
    const { t } = useTranslation('common');
    const { vendor } = useVendor();
    const { url } = useQlubRouter();
    const [initData, setInitData] = useState<IUserInfo | undefined>(undefined);
    const [open, setOpen] = useState(false);
    const [submitted, setSubmitted] = useState(false);
    const promise = useRef<IPromise>({
        resolve: null,
        reject: null,
    });

    useEffect(() => {
        menuApi.getUserInfo(url).then((res) => {
            setInitData(res || {});
        });
    }, []);

    const submitFnHandler: SubmitFuncType = () => {
        return new Promise((resolve, reject) => {
            promise.current.resolve = resolve;
            promise.current.reject = reject;
            if (checkDenyEdit(vendor, initData)) {
                const fields = [
                    ...(vendor?.orderConfig?.customerDetailsFields || []),
                    ...Object.keys(vendor?.orderConfig?.customerExtraFields || {}),
                ];
                resolve(
                    Object.entries(initData || {}).reduce<any>((a, [k, v]) => {
                        if (v && fields.includes(k as any)) {
                            a[k] = v;
                        }
                        return a;
                    }, {}),
                );
                return;
            }
            setOpen(true);
        });
    };

    useEffect(() => {
        if (!submitFn || vendor?.orderConfig?.customerDetailsInterfaceMode === CustomerDetailsInterfaceEnum.Inline) {
            return;
        }

        submitFn(submitFnHandler);
    }, [submitFn]);

    if (checkDenyEdit(vendor, initData)) {
        return null;
    }

    if (vendor?.orderConfig?.customerDetailsInterfaceMode === CustomerDetailsInterfaceEnum.Inline) {
        return (
            <QSRCustomerDetails
                submitFn={submitFn}
                withButton={withButton}
                withBoarder
                initData={initData}
                diningOption={diningOption}
            />
        );
    }

    const openHandler = () => {
        setOpen(true);
    };

    const closeHandler = () => {
        setOpen(false);
        promise.current.reject?.();
    };

    const submitHandler = (values: any) => {
        promise.current.resolve?.(values);
        closeHandler();
    };

    const doneHandler = () => {
        closeHandler();
        setSubmitted(true);
    };

    return (
        <>
            {withButton && (
                <Button variant="outlined" onClick={openHandler} className={styles.submitBtn} disabled={submitted}>
                    {submitted ? t('Submitted') : t('Fill your info')}
                </Button>
            )}
            <SwipeableDrawer
                anchor="bottom"
                keepMounted
                open={open}
                onClose={closeHandler}
                onOpen={openHandler}
                BackdropProps={{ sx: { background: '#00000099' } }}
                PaperProps={{
                    sx: {
                        maxWidth: '552px',
                        minHeight: '200px',
                        margin: '0 auto',
                        background: '#fff',
                        borderRadius: '30px 30px 0 0',
                    },
                }}
            >
                <div className={styles.modal}>
                    <IconButton onClick={closeHandler} className={styles.close}>
                        <CloseRounded fontSize="small" />
                    </IconButton>
                    <div className={styles.container}>
                        <QSRCustomerDetails
                            withButton
                            onSubmit={submitFn ? submitHandler : undefined}
                            onDone={doneHandler}
                            initData={initData}
                            diningOption={diningOption}
                        />
                    </div>
                </div>
            </SwipeableDrawer>
        </>
    );
};

export default QSRCustomerDetailsWrapper;
