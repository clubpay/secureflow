import { Drawer } from '@mui/material';
import QSRProduct, { QSRProductProps } from '@/components/QSR/QSRProduct';

interface QSRProductDrawerProps extends QSRProductProps {
    open: boolean;
    onClose: () => void;
    onOpen: () => void;
}

const QSRProductDrawer = ({
    open,
    qsr,
    vendor,
    selectedProduct,
    currencyPrecision,
    basket,
    isEmbedVendor,
    currencyFormat,
    ui,
    onClose,
    onBasketChange,
}: QSRProductDrawerProps) => {
    return (
        <Drawer
            anchor="bottom"
            open={open}
            onClose={onClose}
            BackdropProps={{ sx: { background: '#00000099' } }}
            PaperProps={{
                elevation: 0,
                sx: {
                    maxWidth: '552px',
                    margin: 'auto',
                    background: 'white',
                },
            }}
        >
            {selectedProduct?.product && (
                <QSRProduct
                    qsr={qsr}
                    vendor={vendor}
                    selectedProduct={selectedProduct}
                    basket={basket}
                    isEmbedVendor={isEmbedVendor}
                    currencyPrecision={currencyPrecision}
                    currencyFormat={currencyFormat}
                    ui={ui}
                    onBasketChange={onBasketChange}
                    onClose={onClose}
                />
            )}
        </Drawer>
    );
};

export default QSRProductDrawer;
