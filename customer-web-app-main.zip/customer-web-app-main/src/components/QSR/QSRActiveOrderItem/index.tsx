import React, { useEffect, useMemo, useRef } from 'react';
import { Typography } from '@qlub-dev/qlub-kit';
import { CircularProgress, IconButton, useTheme } from '@mui/material';
import { KeyboardArrowRightRounded } from '@mui/icons-material';
import ActiveOrderIcon from '@/assets/images/icons/activeOrderIcon';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IQSROrder, OrderStatusEnum } from '@/repositories/menu/types';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import StoveIcon from '@/assets/images/icons/stoveIcon';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import QSRDay from '@/components/QSR/QSRDay';
import { orderToSchedule, prepTimeDiffText, trimPathnameForEmbed } from '@/services/utils/k_qsr';
import ScheduledOrderIcon from '@/assets/images/icons/ScheduledOrderIcon';
import { format } from 'date-fns';

import styles from './index.module.scss';

interface IProps {
    order: IQSROrder;
    onView: (value: { el: any; refId: string }) => void;
}

const QSRActiveOrderItem = ({ order, onView }: IProps) => {
    const theme = useTheme();
    const { t } = useTranslation('common');
    const { vendor } = useVendor();
    const elRef = useRef<HTMLDivElement | null>(null);
    const { routerPush, lang, pathname } = useQlubRouter();

    const getData = useMemo(() => {
        switch (order.orderStatus) {
            case OrderStatusEnum.PENDING:
                return {
                    title: t('Your order is Submitted'),
                    subtitle: t('Waiting for restaurant confirmation'),
                    icon: <ActiveOrderIcon color={theme.qlub.palette.iris.main} />,
                    percentage: 25,
                };
            case OrderStatusEnum.ACTIVE:
            case OrderStatusEnum.APPROVED:
            case OrderStatusEnum.PREPARING:
            case OrderStatusEnum.PICK_UP:
                // eslint-disable-next-line no-case-declarations
                const remainedTime =
                    order.timer?.active && order.timer.time
                        ? prepTimeDiffText(order?.timer?.time, order?.timer?.acceptedAt)
                        : 0;
                return {
                    title: t('Preparing the Order'),
                    subtitle: remainedTime
                        ? t('Order will be served within {{min}} min.', {
                              min: remainedTime,
                          })
                        : t('Your order will be served soon'),
                    icon: <StoveIcon color={theme.qlub.palette.iris.main} />,
                    percentage: 75,
                };
            case OrderStatusEnum.SCHEDULED:
                // eslint-disable-next-line no-case-declarations
                const scheduledOrder = orderToSchedule(order, vendor);

                return {
                    title: t('You scheduled your order'),
                    subtitle: interpolateT(
                        t('<day>, <date>, {{start}} to {{end}}', {
                            start: scheduledOrder?.value?.timePeriod?.start || '',
                            end: scheduledOrder?.value?.timePeriod?.end || '',
                        }),
                        {
                            day: <QSRDay lang={lang} day={scheduledOrder?.value?.date} />,
                            date: order.pickupAt
                                ? format(new Date(order.pickupAt), lang === 'ja' ? 'yyyy/MM/dd' : 'dd/MM/yyyy')
                                : '',
                        },
                    ),
                    icon: <ScheduledOrderIcon color={theme.qlub.palette.iris.main} />,
                    percentage: 0,
                };

            default:
                return {
                    title: t('Your order is Submitted'),
                    subtitle: t('Waiting for restaurant confirmation'),
                    icon: <ActiveOrderIcon color={theme.qlub.palette.iris.main} />,
                    percentage: 25,
                };
        }
    }, [theme, vendor, order, lang]);

    const clickHandler = () => {
        routerPush(trimPathnameForEmbed('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/qsr/preparation', pathname), {
            id: order.urlData.tableId,
            f1: order.urlData.f1 || '_',
            f2: order.urlData.f2 || '_',
            ...(order.urlData.hash ? { hash: order.urlData.hash } : {}),
            qOrderId: order.refId,
            ref: '',
        });
    };

    useEffect(() => {
        if (!elRef.current) {
            return () => {
                //
            };
        }

        const callback: IntersectionObserverCallback = (items) => {
            if (items?.[0].intersectionRatio >= 0.5) {
                onView({ el: elRef.current, refId: order.refId });
            }
        };

        const observer = new IntersectionObserver(callback, {
            threshold: Array.from({ length: 10 }).map((o, idx) => idx * (1 / 10)),
        });
        observer.observe(elRef.current);
        return () => {
            if (elRef.current) {
                observer.unobserve(elRef.current);
            }
            observer.disconnect();
        };
    }, [elRef.current]);

    return (
        <div className={styles.activeOrderItem} onClick={clickHandler} ref={elRef}>
            <div className={styles.content}>
                <span className={styles.icon}>
                    <span className={styles.circular}>
                        <CircularProgress
                            variant="determinate"
                            value={getData.percentage}
                            size={38}
                            thickness={3}
                            color="primary"
                            className={styles.circularInner}
                        />
                    </span>

                    <span className={styles.whiteCircle} />
                    <span className={styles.orderIcon}>{getData.icon}</span>
                </span>
                <div className={styles.texts}>
                    <Typography typo="title_sm" className={styles.title}>
                        {getData.title}
                    </Typography>
                    <Typography typo="caption_overline" className={styles.subTitle}>
                        {getData.subtitle}
                    </Typography>
                </div>
            </div>
            <IconButton className={styles.iconButton}>
                <KeyboardArrowRightRounded className={styles.icon} />
            </IconButton>
        </div>
    );
};

export default QSRActiveOrderItem;
