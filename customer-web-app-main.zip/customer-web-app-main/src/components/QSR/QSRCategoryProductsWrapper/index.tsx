import React, { FC, MutableRefObject, useEffect, useMemo, useRef } from 'react';
import { ICategory } from '@/repositories/menu/types';
import SkeletonComponentSingle from '@/components/QSR/QSRProductList/Skeleton';
import { translator } from '@/services/utils/k_qsr';
import QSRUpsellName from '@/components/QSR/QSRUpsellName';
import classNames from 'classnames';

import styles from './index.module.scss';

interface IProps {
    category: ICategory | undefined;
    lang: string;
    loading?: boolean;
    divider?: boolean;
    selectedCategoryIdRef: MutableRefObject<string>;
    onVisibilityChange: (visible: boolean) => void;
    onAnchorChange: (top: boolean) => void;
    isSingleMenu?: boolean;
    gridView?: boolean;
}

const QSRCategoryProductsWrapper: FC<IProps> = ({
    category,
    lang,
    loading,
    selectedCategoryIdRef,
    onVisibilityChange,
    onAnchorChange,
    isSingleMenu,
    gridView,
    children,
}) => {
    const elRef = useRef<HTMLDivElement | null>(null);
    const intersectionRef = useRef<boolean>(false);
    const anchorIntersectionRef = useRef<boolean>(false);

    const [title, id] = useMemo(() => {
        if (!category) {
            return [null, ''];
        }
        return [translator(category.name, category.nameTranslations, lang), category.id];
    }, [category, lang]);

    useEffect(() => {
        if (!elRef.current) {
            return () => {
                //
            };
        }

        const small = (elRef.current?.getBoundingClientRect().height || 0) < 300;

        const callback: IntersectionObserverCallback = (items) => {
            const intersection = items?.[0]?.isIntersecting || false;
            if (!intersectionRef.current && intersection) {
                intersectionRef.current = true;
                onVisibilityChange(true);
            } else if (intersectionRef.current && !intersection) {
                intersectionRef.current = false;
                onVisibilityChange(false);
            }

            const top = items?.[0]?.boundingClientRect.top || 0;
            const height = items?.[0]?.boundingClientRect.height || 0;
            const isTop = -height + 60 < top && top < 50;
            if (
                (!anchorIntersectionRef.current && isTop) ||
                (!small && isTop && selectedCategoryIdRef.current && selectedCategoryIdRef.current !== category?.id)
            ) {
                anchorIntersectionRef.current = true;
                onAnchorChange(true);
            } else if (anchorIntersectionRef.current && !isTop) {
                anchorIntersectionRef.current = false;
                onAnchorChange(false);
            }
        };

        const iter = small ? 50 : 100;
        const observer = new IntersectionObserver(callback, {
            threshold: Array.from({ length: iter }).map((o, idx) => idx * (1 / iter)),
        });
        observer.observe(elRef.current);
        return () => {
            if (elRef.current) {
                observer.unobserve(elRef.current);
            }
            observer.disconnect();
        };
    }, [elRef.current]);

    return (
        <div
            data-anchor={id}
            ref={elRef}
            className={classNames(styles.wrapper, {
                [styles.singleMenu]: isSingleMenu,
            })}
        >
            <div className={styles.category}>{!title ? <QSRUpsellName id={id} /> : title}</div>
            <div
                className={classNames(styles.list, {
                    [styles.gridView]: gridView,
                })}
            >
                {loading ? <SkeletonComponentSingle childrenNumber={category?.size || 5} /> : children}
            </div>
        </div>
    );
};

export default QSRCategoryProductsWrapper;
