import React from 'react';
import { QSRRouterModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { getDiningSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import { getLoyaltyRedirectionArgs } from '@clubpay/loyalty/dist/utils/query';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { OrderModeEnum } from '@clubpay/customer-common-module/src/repository/vendor/type';

import styles from './index.module.scss';

const QSRPayBill = () => {
    const { t } = useTranslation('common');
    const { url, query, routerPush } = useQlubRouter();
    const { vendor } = useVendor();

    const enablePayBtnOnDm = vendor?.orderMode === OrderModeEnum.DigitalMenu && vendor.orderConfig?.enablePayBillBtn;

    if (query.qsr !== QSRRouterModeEnum.Mixed && !enablePayBtnOnDm) {
        return null;
    }

    const payBillHandler = () => {
        const diningSessionPayload = getDiningSession(url);

        onPushEvent('tap_on_pay_bill', {
            opsMode: vendor?.opsMode,
            restaurant_name: url.slug,
            diningSessionId: diningSessionPayload?.id,
            pg_name: vendor?.availablePGs,
        });
        if (url.id && url.id !== '_') {
            routerPush('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice', {
                source: 'landingPage',
                ...getLoyaltyRedirectionArgs(),
            });
        }
    };

    return (
        <div onClick={payBillHandler} className={styles.button}>
            {t('Pay Bill')}
        </div>
    );
};

export default QSRPayBill;
