import React, { FC, ReactNode, useEffect, useMemo, useState } from 'react';
import { IModifierGroup, IProduct } from '@/repositories/menu/types';
import { IRestaurant, OrderPricePresentationEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { useTheme } from '@mui/material';
import QSRValidationHint, { QSRValidationHintTypeEnum } from '@/components/QSR/QSRValidationHint';
import classNames from 'classnames';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { ZeroTypeEnum, CurrencyFormat } from '@qlub-dev/qlub-kit/dist/components/Format';
import QSRPrice from '@/components/QSR/QSRPrice';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import { IModifierProduct, ItemIndicatorChangeFunc } from '@/components/QSR/QSRItemSelector';
import { translator } from '@/services/utils/k_qsr';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

import styles from './index.module.scss';

interface IProps {
    product: IProduct;
    lang: string;
    currencyPrecision: number;
    vendor?: IRestaurant;
    qsr?: boolean;
    Indicator?: ReactNode;
    modifier?: IModifierGroup<IProduct>;
    onChange?: ItemIndicatorChangeFunc;
    parentProducts: IModifierProduct[];
    currencyFormat: CurrencyFormat;
    hideHint?: boolean;
}

const QSRProductItem: FC<IProps> = ({
    product,
    modifier,
    onChange,
    parentProducts,
    lang,
    currencyPrecision,
    vendor,
    qsr,
    Indicator,
    children,
    currencyFormat,
    hideHint,
}) => {
    const theme = useTheme();
    const { t } = useTranslation('common');
    const {
        qsr: { qsrModifierSelectEvent, qsrProductRemoveChartEvent, qsrProductAddChartEvent },
    } = useQsrEventsCenter();
    const [expanded, setExpanded] = useState(Boolean(product?.selected));

    const val = product.selected?.qty || 0;
    const single = modifier?.max === 1;
    const withAccordion = Boolean((parentProducts?.length || 0) > 0 && product.modifierGroups?.length);
    const isRootProduct = (parentProducts?.length || 0) === 1;

    const expansionAnchor = useMemo(() => {
        if (!withAccordion) {
            return null;
        }

        return (
            <div
                className={classNames(styles.expansionAnchor, {
                    [styles.expanded]: expanded,
                    [styles.rootProduct]: isRootProduct,
                })}
                onClick={() => {
                    setExpanded((o) => !o);
                }}
            >
                <ExpandMoreIcon />
            </div>
        );
    }, [withAccordion, expanded, isRootProduct]);

    useEffect(() => {
        setExpanded(Boolean(product?.selected));
    }, [Boolean(product?.selected)]);

    const handleClick = (e: any) => {
        const checkbox = product.max === 1 || (modifier?.min === 1 && modifier?.max === 1) || modifier?.multiMax === 1;
        if (
            ['button', 'svg', 'path'].includes(e.target.localName) ||
            product.disabled ||
            modifier?.disabled ||
            !checkbox
        ) {
            return;
        }

        if (val === 0) {
            qsrProductAddChartEvent({
                pageName: 'qsrActiveMenu',
                productName: product.name,
                quantity: 1,
            });
        } else {
            qsrProductRemoveChartEvent({
                pageName: 'qsrActiveMenu',
                productName: product.name,
                quantity: 0,
            });
        }
        qsrModifierSelectEvent(product.min > 0 || (modifier?.min || 0) > 0);
        onChange?.(parentProducts, val ? 0 : product.min || 1, single);
    };

    return (
        <>
            <div
                onClick={handleClick}
                className={classNames(styles.item, {
                    [styles.selected]: (product.selected?.qty || 0) > 0,
                    [styles.outOfDate]:
                        product.disabled ||
                        parentProducts?.[parentProducts?.length - 1]?.disabledParent ||
                        modifier?.disabled,
                })}
                style={
                    parentProducts?.length === 1 && (product.selected?.qty || 0) > 0
                        ? {
                              backgroundColor: theme.qlub.palette.iris_light.main,
                          }
                        : undefined
                }
                data-pr-id={product.id}
                data-invalid={product.selected?.qty && !product.valid ? 'true' : 'false'}
            >
                <div className={styles.title}>{translator(product.name, product.nameTranslations, lang)}</div>
                {hideHint && <QSRValidationHint item={product} type={QSRValidationHintTypeEnum.Product} />}
                <div className={styles.indicator}>
                    {vendor?.orderConfig?.pricePresentation !== OrderPricePresentationEnum.HidePrice && (
                        <>
                            {!product.price && vendor?.orderConfig?.zeroPriceMode === ZeroTypeEnum.Free ? (
                                t('free')
                            ) : (
                                <>
                                    {qsr && product.price && vendor?.orderConfig?.zeroPriceMode === ZeroTypeEnum.Zero
                                        ? '+ '
                                        : ''}
                                    <QSRPrice
                                        value={String(product.price || 0)}
                                        currencyFormat={{
                                            ...currencyFormat,
                                            currencyPrecision: currencyPrecision || currencyFormat.currencyPrecision,
                                        }}
                                        zeroPriceType={vendor?.orderConfig?.zeroPriceMode || ZeroTypeEnum.Null}
                                    />
                                </>
                            )}
                        </>
                    )}
                    {Indicator}
                </div>
                {expansionAnchor}
            </div>
            <div
                className={classNames(styles.indent, {
                    [styles.withAccordion]: withAccordion,
                    [styles.expanded]: expanded,
                })}
            >
                <div>{children}</div>
            </div>
        </>
    );
};

export default QSRProductItem;
