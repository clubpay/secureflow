import { useMemo } from 'react';
import { IOrderItem, IProduct } from '@/repositories/menu/types';
import { Box, Grid, IconButton, SwipeableDrawer, useTheme } from '@mui/material';
import { Button, Divider, FoodItem } from '@qlub-dev/qlub-kit';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { CloseRounded } from '@mui/icons-material';
import { translator } from '@/services/utils/k_qsr';

import styles from './index.module.scss';

interface IProps {
    product: IProduct;
    onSelect?: (item: IOrderItem) => void;
    selectionList: IOrderItem[];
    open: boolean;
    onOpen: (open: boolean) => void;
}

const QSRProductSelection = ({ open, onOpen, product, onSelect, selectionList }: IProps) => {
    const { lang } = useQlubRouter();
    const { t } = useTranslation('common');
    const theme = useTheme();

    const productMap = useMemo<{ [key: string]: string }>(() => {
        return (
            product.modifierGroups?.reduce(
                (a, b) => {
                    b.products?.forEach((c) => {
                        a[c.id] = translator(c.name, c.nameTranslations, lang);
                    });
                    return a;
                },
                product.products?.reduce<any>((a, b) => {
                    a[b.id] = translator(b.name, b.nameTranslations, lang);
                    return a;
                }, {}) || {},
            ) || {}
        );
    }, [product, lang]);

    return (
        <SwipeableDrawer
            anchor="bottom"
            open={open}
            onClose={() => onOpen(false)}
            onOpen={() => onOpen(true)}
            BackdropProps={{ sx: { background: '#00000099' } }}
            PaperProps={{
                sx: {
                    maxWidth: '552px',
                    margin: '0 auto',
                    background: '#fff',
                    borderRadius: '30px 30px 0 0',
                },
            }}
        >
            <div className={styles.drawerContainer}>
                <Box className={styles.drawerContent}>
                    <Box flexGrow={1} className={styles.drawerTitle}>
                        {t('Select Previous Product to Edit')}
                    </Box>
                    <Box>
                        <IconButton onClick={() => onOpen(false)}>
                            <CloseRounded />
                        </IconButton>
                    </Box>
                </Box>
                <Box className={styles.categories}>
                    <div className={styles.inItems}>
                        {selectionList.map((item, index) => {
                            return (
                                <>
                                    <Grid
                                        container
                                        className={styles.itemRow}
                                        key={index}
                                        justifyContent="space-between"
                                    >
                                        <Grid item>
                                            <FoodItem
                                                name={item.additives?.map((o) => (
                                                    <div>{productMap[o.id]}</div>
                                                ))}
                                                quantity={0}
                                                multiplier
                                                numberCircleColor={theme.qlub.palette.dim.main}
                                                key={index}
                                                classes={{
                                                    foodCardOverrides: {
                                                        paddingBottom: '0 !important',
                                                    },
                                                }}
                                                price={undefined}
                                            />
                                        </Grid>
                                        <Grid item>
                                            <Button
                                                variant="containedLight"
                                                onClick={() => {
                                                    onSelect?.(item);
                                                    onOpen(false);
                                                }}
                                                className={styles.drawerButton}
                                            >
                                                {t('Edit in cart')}
                                            </Button>
                                        </Grid>
                                    </Grid>
                                    {selectionList.length > index + 1 && <Divider />}
                                </>
                            );
                        })}
                    </div>
                </Box>
            </div>
        </SwipeableDrawer>
    );
};

export default QSRProductSelection;
