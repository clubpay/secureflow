import React from 'react';
import { Button, SubHeader } from '@qlub-dev/qlub-kit';
import Link from 'next/link';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { Skeleton } from '@mui/material';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import QSROrderHistory from '@/components/QSR/QSROrderHistory';
import classNames from 'classnames';
import { OrderModeEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import QSRTableName from '@/components/QSR/QSRTableName';

import styles from './index.module.scss';

const QSRHeader = () => {
    const { t } = useTranslation('common');
    const { getRouterParam, query } = useQlubRouter();
    const { vendor, tableInfo } = useVendor();

    if (!vendor) {
        return <Skeleton className={styles.title} height={60} width="70%" />;
    }

    const isSim = query.sim === 'true';

    return (
        <div
            className={classNames(styles.header, {
                [styles.withLogo]: Boolean(vendor.logoBigUrl),
                [styles.withBorder]: vendor.orderMode === OrderModeEnum.DigitalMenu,
                [styles.titleOnTop]: vendor.orderMode === OrderModeEnum.Mixed,
            })}
        >
            {vendor.orderMode === OrderModeEnum.DigitalMenu ? (
                <SubHeader
                    subTitle={<QSRTableName tableInfo={tableInfo} vendor={vendor} />}
                    title={vendor?.title || ''}
                    CTA={
                        !vendor?.orderConfig?.menuOnlyRestaurant ? (
                            <Button variant="text" sx={{ px: 0 }} disableRipple>
                                <Link href={getRouterParam('/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice')}>
                                    {t('View invoice')}
                                </Link>
                            </Button>
                        ) : undefined
                    }
                />
            ) : (
                <div className={styles.title}>
                    {vendor.opsMode === 'master' ? (
                        <span className={styles.socialLandingTitle}>{vendor.title}</span>
                    ) : (
                        <>
                            {vendor.orderMode === OrderModeEnum.Mixed && (
                                <span className={styles.viewInvoice}>
                                    <Button variant="text" sx={{ px: 0, background: 'transparent' }} disableRipple>
                                        <Link
                                            href={getRouterParam(
                                                '/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/invoice',
                                                undefined,
                                                ['qsrPayment'],
                                            )}
                                        >
                                            {t('Pay bill')}
                                        </Link>
                                    </Button>
                                </span>
                            )}
                            <span className={styles.restaurantTitle}>{vendor.title}</span>
                            {!isSim && (
                                <span className={styles.orderHistory}>
                                    <QSROrderHistory />
                                </span>
                            )}
                        </>
                    )}
                </div>
            )}
        </div>
    );
};

export default QSRHeader;
