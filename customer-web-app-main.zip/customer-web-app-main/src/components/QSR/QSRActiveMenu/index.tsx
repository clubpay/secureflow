import QSRProductList, { QSRSelectFunc } from '@/components/QSR/QSRProductList';
import React, { useEffect, useRef, useState } from 'react';
import { EmbedModeEnum, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { ICategory, IMenu, UIVariantEnum } from '@/repositories/menu/types';
import MenuAPIManager from '@/repositories/menu';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import useQsrEventsCenter from '@/hooks/qsrEventsCenter';
import { isAvailabilityConfigMatch } from '@/components/QSR/QSRAvailabilityHint';
import {
    OrderUnavailableItemPresentationEnum,
    MenuViewDefaultEnum,
} from '@clubpay/customer-common-module/src/repository/vendor';
import QSRMenu from '@/components/QSR/QSRMenu';
import QSRCategory from '@/components/QSR/QSRCategory';
import scrollIntoView from 'scroll-into-view';
import QSRSearch from '@/components/QSR/QSRSearch';
import QSRVendorInfo from '@/components/QSR/QSRVendorInfo';
import SkeletonTabs from './Skeleton';

import styles from './index.module.scss';

interface IProps {
    onSelect: QSRSelectFunc;
    isQSR?: boolean;
    menuId: string;
    currencyPrecision: number;
    ui: UIVariantEnum;
    onSearchOpen: (open: boolean) => void;
}

const ActiveMenu = ({ onSelect, isQSR, menuId, currencyPrecision, ui, onSearchOpen }: IProps) => {
    const menuApi = MenuAPIManager.getInstance();
    const { url, urlStr } = useQlubRouter();
    const { vendor } = useVendor();
    const wrapperRef = useRef<HTMLDivElement | null>(null);
    const [loading, setLoading] = useState(false);
    const [productsLoading, setProductsLoading] = useState(false);
    const [menus, setMenus] = useState<IMenu[]>([]);
    const [selectedMenu, setSelectedMenu] = useState<IMenu | undefined>(undefined);
    const [categories, setCategories] = useState<ICategory[]>([]);
    const [selectedCategoryId, setSelectedCategoryId] = useState('');
    const selectedCategoryIdRef = useRef('');
    const tabChangeBlocker = useRef(false);
    const timeoutId = useRef<any>(null);
    const {
        qsr: { qsrPageViewEvent },
    } = useQsrEventsCenter();

    const embedVendor = url.embed === EmbedModeEnum.Vendor;
    const isList = (vendor?.orderConfig?.menuViewDefault || MenuViewDefaultEnum.List) === MenuViewDefaultEnum.List;

    useEffect(() => {
        qsrPageViewEvent('qsrActiveMenu');
        if (!url.cc || !url.slug || !url.id || !url.f1 || !url.f2) {
            // eslint-disable-next-line @typescript-eslint/no-empty-function
            return;
        }

        setLoading(true);
        setProductsLoading(true);
        menuApi
            .getMenu(url, { page: 0, limit: 100 }, vendor)
            .then((res) => {
                setMenus(res.rows || []);
            })
            .catch((err) => console.log(err))
            .finally(() => {
                setLoading(false);
            });
    }, [urlStr]);

    const menuTabChangeHandler = (selectedMenuId: string) => {
        const m = menus?.find((o) => o.id === selectedMenuId);
        setSelectedMenu(m);
        const cats =
            m?.categories?.filter(
                (o) =>
                    !o.outOfSchedule ||
                    !isAvailabilityConfigMatch(vendor, [OrderUnavailableItemPresentationEnum.HideCategory]),
            ) || [];
        setCategories(cats);
        setSelectedCategoryId(cats?.[0]?.id || '');
    };

    useEffect(() => {
        menuTabChangeHandler(menuId);
    }, [menus, menuId]);

    const scrollToCat = (catId: string, instant?: boolean) => {
        const el: HTMLDivElement | null | undefined = wrapperRef.current?.querySelector(`div[data-anchor="${catId}"]`);
        if (!el) {
            return;
        }
        if (instant) {
            el.scrollTop = 0;
            el.scrollIntoView({
                block: 'start',
            });
        } else {
            scrollIntoView(el, {
                align: {
                    top: 0,
                },
                cancellable: true,
                time: 200,
            });
        }
    };

    const tabChangeHandler = (catId: string) => {
        setSelectedCategoryId(catId);
        tabChangeBlocker.current = true;

        if (timeoutId.current) {
            clearTimeout(timeoutId.current);
        }

        timeoutId.current = setTimeout(() => {
            tabChangeBlocker.current = false;
            timeoutId.current = null;
        }, 900);

        selectedCategoryIdRef.current = catId;
        scrollToCat(catId);
    };

    const remoteLoadHandler = (cadId: string) => {
        if (cadId !== selectedCategoryIdRef.current) {
            return;
        }

        setTimeout(() => {
            scrollToCat(cadId, true);
        }, 10);
    };

    return (
        <>
            <QSRSearch
                key={selectedMenu?.id || ''}
                menu={selectedMenu}
                menus={menus}
                currencyPrecision={currencyPrecision}
                isQSR={isQSR}
                ui={ui}
                onSelect={onSelect}
                onOpen={onSearchOpen}
            />
            <div className={styles.vendorContent}>
                {menus && menus?.length > 1 && (
                    <QSRMenu menus={menus} selectedId={menuId} onChange={menuTabChangeHandler} />
                )}
            </div>
            {loading && productsLoading ? (
                <SkeletonTabs />
            ) : (
                <div className={styles.wrapper} ref={wrapperRef}>
                    <QSRCategory
                        categories={categories}
                        selectedId={selectedCategoryId}
                        onChange={tabChangeHandler}
                        isSingleMenu={menus?.length === 1}
                    />
                    <QSRVendorInfo />
                    <QSRProductList
                        key={`${selectedMenu?.id}`}
                        menuId={selectedMenu?.id || ''}
                        categories={categories}
                        isList={isList}
                        isQSR={isQSR}
                        menu={selectedMenu}
                        currencyPrecision={currencyPrecision}
                        searchProducts={null}
                        setProductsLoading={setProductsLoading}
                        isEmbedVendor={embedVendor}
                        isSingleMenu={menus?.length === 1}
                        ui={ui}
                        onSelect={onSelect}
                        onRemoteLoad={remoteLoadHandler}
                        onCategoryChange={(catId) => {
                            if (!tabChangeBlocker.current) {
                                return setSelectedCategoryId(catId);
                            }
                        }}
                    />
                </div>
            )}
        </>
    );
};

export default ActiveMenu;
