import { ContentSwitcher } from '@qlub-dev/qlub-kit';
import { Box, Grid, Skeleton, useTheme } from '@mui/material';

import styles from '../index.module.scss';

const SkeletonComponent = () => {
    const items = [1, 2, 3, 4, 5];
    return (
        <div className={styles.skeleton}>
            {items.map((item) => (
                <Box
                    key={item}
                    sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '16px' }}
                >
                    <Grid container justifyContent="space-between" alignItems="space-between">
                        <Skeleton variant="text" width="30%" height={40} />
                        <Skeleton variant="text" width="80%" height={40} />
                    </Grid>
                    <Skeleton variant="text" width="80%" height={150} />
                </Box>
            ))}
        </div>
    );
};

const SkeletonTabs = () => {
    const theme = useTheme();
    return (
        <ContentSwitcher
            sx={{ backgroundColor: theme.qlub.palette.white.main }}
            items={[1, 2, 3].map((c, i) => {
                return {
                    children: <SkeletonComponent />,
                    index: i,
                    label: <Skeleton width={80} height={40} />,
                };
            })}
        />
    );
};
export default SkeletonTabs;
