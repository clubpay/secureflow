import { useMemo } from 'react';

import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { hasCookieAccess } from '@clubpay/customer-common-module/src/utility/k_error';
import { qlubSessionStorage } from '@clubpay/customer-common-module/src/service/storage/sessionStorage';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getDiningSession, getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import { SliderLocationEnum } from '@clubpay/customer-common-module/src/component/KSlider/enums';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import {
    EnableEnum,
    SmartTipModalEventConditionEnum,
    SmartTipModalTriggerPointConditionEnum,
} from '@clubpay/customer-common-module/src/repository/vendor';
import { getPaymentSuccessLoyaltyEventArgs } from '@clubpay/loyalty/dist/utils/analytics';
import type { IAppliedDiscount } from '@clubpay/loyalty/dist/types/entities/discount';
import { getPaymentGoogleEventArgs } from '@clubpay/payment-kit';

import { getEventPrefix } from '@/hooks/utils';
import { checkField } from '@/components/Tip/normal/utils/tip';
import { SliderPositionEnum } from '@/components/Banner';
import { getVentureReviewConfigs } from '@/components/Review/utils';
import type { IModalTrigger, ITip } from '@/components/Tip/normal/types';
import {
    calcAdditionalTipRoundingAmount,
    IsTipRoundingFeatureEnable,
} from '@/components/Tip/normal/utils/rounding-calculations';

const useEventsCenter = () => {
    const { vendor } = useVendor();
    const { config: country } = useConfigContext();

    const { url, query, source, lang } = useQlubRouter();
    const { method, paymentElement, gatewayId } = query;
    const { cc, slug } = url;
    const prefix = getEventPrefix(url);
    const reviewConfigs = getVentureReviewConfigs(vendor?.config, country);
    const is3ds = query.is3ds === 'true';

    const dsi = getDiningSession(url)?.id || '';
    const sessionID = getSession();

    const modalTrigger: IModalTrigger = useMemo(() => {
        return {
            point: vendor?.config?.tipModalTriggerCondition || country?.tipModalTriggerCondition,
            event: vendor?.config?.tipModalEventCondition || country?.tipModalEventCondition,
        };
    }, [vendor, country]);

    const universalParams = {
        diningSessionId: dsi,
        party_id: sessionID,
        country_code: cc,
        restaurant_name: slug,
    };

    const commonTipParams = {
        ...universalParams,
        trigger_point: modalTrigger.point,
        trigger_event: modalTrigger.event,
        pg_name: vendor?.availablePGs,
    };

    const commonPromotionalBannerParams = {
        ...universalParams,
        pg_name: `${method}_${paymentElement}`.toLowerCase(),
        banner_name: vendor?.config?.promotionalBannerName ? vendor?.config?.promotionalBannerName : 'No name',
        promotional_banner_size: vendor?.config?.promotionalBannerSize,
        promotional_banner_placement: vendor?.config.promotionalBannerPlacement,
    };

    const commonVentureBannerParams = {
        ...universalParams,
        banner_name: vendor?.config?.ventureBannerName ? vendor?.config?.ventureBannerName : 'No name',
        pg_name: `${method}_${paymentElement}`.toLowerCase(),
    };

    const commonVoucherCampaignParams = {
        ...universalParams,
        pg_name: vendor?.availablePGs,
    };

    const ventureReviewCommonVars = {
        ...universalParams,
        pg_name: `${query.method}_${query.paymentElement}`.toLowerCase(),
        googlePlaceId: vendor?.googlePlaceId,
        reviewMode: reviewConfigs?.reviewMode,
        goodRatingThreshold: reviewConfigs?.goodRatingThreshold,
    };

    const tip = {
        defaultEvents: (modal?: boolean) => {
            if (modal) {
                return;
            }
            const gamification = vendor?.config.tipGamificationMode || country?.tipGamificationMode;
            const mostCommon = vendor?.config.mostCommonTip || country?.mostCommonTip;
            const tipDefault = vendor?.config.tipDefault || country?.tipDefault;
            const tipDefaultForModal = vendor?.config.tipDefaultForTipModal;

            if (gamification) {
                onPushEvent(
                    'Gamification_Added',
                    {
                        ...universalParams,
                    },
                    prefix,
                );
            }
            if (mostCommon) {
                onPushEvent(
                    'MostCommonTipOption_Set',
                    {
                        ...universalParams,
                        pg_name: vendor?.availablePGs,
                    },
                    prefix,
                );
            }
            if (tipDefault) {
                onPushEvent(
                    'DefaultTip_Set',
                    {
                        ...commonTipParams,
                        tip_source: 'tipBox',
                    },
                    prefix,
                );
            }
            if (tipDefaultForModal) {
                onPushEvent(
                    'DefaultTip_Set',
                    {
                        ...commonTipParams,
                        tip_source: 'tipModal',
                    },
                    prefix,
                );
            }
            if (modalTrigger.point) {
                onPushEvent('TipModal_Toggled', commonTipParams, prefix);
            }
        },
        payTipEvents: (
            tipValue: number | string | undefined,
            pgName: string | undefined,
            totalAmount: number,
            tipOptionValue?: number,
        ) => {
            const mostCommon = vendor?.config.mostCommonTip || country?.mostCommonTip;
            const tipDefault = vendor?.config.tipDefault || country?.tipDefault || vendor?.config.tipDefaultForTipModal;
            const tipNumber = Number(tipValue);

            // tip round related data
            let tipAdditionalValue: string | undefined;
            const isTipRoundigEnable = IsTipRoundingFeatureEnable(vendor, country);
            if (tipOptionValue && isTipRoundigEnable && tipValue) {
                tipAdditionalValue = calcAdditionalTipRoundingAmount(Number(tipValue), tipOptionValue, totalAmount);
            }

            if (tipNumber && tipNumber > 0) {
                onPushEvent(
                    'Tip_Added',
                    {
                        ...universalParams,
                        is_most_common: tipNumber === mostCommon,
                        is_pre_selected: tipNumber === tipDefault,
                        pg_name: pgName,
                        tipRounded: tipNumber > 0 && isTipRoundigEnable,
                        ...(isTipRoundigEnable && tipAdditionalValue ? { tipRoundupAmount: tipAdditionalValue } : {}),
                    },
                    prefix,
                );
            } else {
                onPushEvent(
                    'No_Tip_Added',
                    {
                        ...universalParams,
                        pg_name: pgName,
                    },
                    prefix,
                );
            }
        },
        tipModalConfirmEvents: (tipData: ITip) => {
            if (tipData.finalValue && tipData.status !== 'custom' && tipData.finalValue > 0) {
                onPushEvent(
                    'TipModal_Tip_Selected',
                    {
                        ...commonTipParams,
                        is_most_common: checkField('mostCommonTip', vendor?.config, country, tipData.amount),
                        is_pre_selected: checkField('tipDefaultForTipModal', vendor?.config, country, tipData.amount),
                    },
                    prefix,
                );
            } else if (tipData.finalValue && tipData.status === 'custom') {
                onPushEvent('TipModal_CustomTip_Selected', commonTipParams, prefix);
            } else if (tipData.finalValue === 0 && tipData.status === 'custom') {
                onPushEvent(
                    'TipModal_tip_removed',
                    {
                        ...commonTipParams,
                        is_pre_selected: checkField('tipDefaultForTipModal', vendor?.config, country, tipData.amount),
                    },
                    prefix,
                );
            } else {
                onPushEvent('TipModal_NoTip_Selected', commonTipParams, prefix);
            }
        },
        tipModalCloseEvent: () => {
            onPushEvent('TipModal_Closed', commonTipParams, prefix);
        },
        tipModalDisplayEvent: () => {
            onPushEvent('TipModal_Displayed', commonTipParams, prefix);
        },
        tipModalNotNowEnableEvent: () => {
            onPushEvent('tipModal_notNow_enabled', commonTipParams, prefix);
        },
        tipBoxCustomTipEvents: (tipData: ITip) => {
            if (tipData?.finalValue && tipData?.finalValue > 0) {
                onPushEvent('TipBox_CustomTip_Selected', commonTipParams, prefix);
            } else if (!tipData?.finalValue && tipData?.finalValue === 0) {
                onPushEvent(
                    'tipBox_tip_removed',
                    {
                        ...commonTipParams,
                        is_pre_selected: checkField('tipDefault', vendor?.config, country, tipData.amount),
                    },
                    prefix,
                );
            }
        },
        tipBoxNotNowEnableEvent: () => {
            onPushEvent('tipBox_notNow_enabled', commonTipParams, prefix);
        },
        tipBoxTipRemoveEvent: (val: number) => {
            onPushEvent(
                'tipBox_tip_removed',
                {
                    ...commonTipParams,
                    is_pre_selected: checkField('tipDefault', vendor?.config, country, val),
                },
                prefix,
            );
        },
        tipBoxTipSelectedEvent: (val: number) => {
            onPushEvent(
                'TipBox_Tip_Selected',
                {
                    ...commonTipParams,
                    is_most_common: checkField('mostCommonTip', vendor?.config, country, val),
                    is_pre_selected: checkField('tipDefault', vendor?.config, country, val),
                    tip_label_type: vendor?.config.tipLabelType || country?.tipLabelType,
                },
                prefix,
            );
        },
        tipBoxNoTipSelectedEvent: () => {
            onPushEvent('TipBox_NoTip_Selected', commonTipParams, prefix);
        },
        tipBoxDisplayEvent: () => {
            if (!hasCookieAccess()) return;
            const isTipEnabled = country && country.showTip && vendor?.config?.tipHide !== true;
            const isTipEventTriggered = qlubSessionStorage.get('qlub.tip.display_event');
            if (isTipEnabled && !isTipEventTriggered) {
                qlubSessionStorage.set('qlub.tip.display_event', 'true');
                onPushEvent('TipBox_Displayed', commonTipParams, prefix);
            }
        },
        tipModalScrollEvent: (newVar: Record<string, unknown>) => {
            onPushEvent('tipModal_scroll', { ...commonTipParams, ...newVar }, prefix);
        },
        tipBoxScrollEvent: (newVar: Record<string, unknown>) => {
            onPushEvent('tipbox_scroll', { ...commonTipParams, ...newVar }, prefix);
        },
        tipModalActivePaymentEvent: () => {
            onPushEvent('tipModal_with_payment_enabled', commonTipParams, prefix);
        },
        tipRoundUpSetEvent: () => {
            onPushEvent('tipRoundUpSet', universalParams);
        },
        tipAddedWithRoundUpEvent: (tipAmount: number) => {
            onPushEvent('tipAddedWithRoundUp', {
                ...universalParams,
                tipAmount,
            });
        },
        modalTrigger,
    };

    const promotionalBanner = {
        displayEvent: () => {
            onPushEvent('promotionalBannerShown', commonPromotionalBannerParams, prefix, true);
        },
        clickEvent: () => {
            onPushEvent('tapOnPromotionalBanner', commonPromotionalBannerParams, prefix);
        },
        redirectEvent: () => {
            onPushEvent('redirectFromBanner', commonPromotionalBannerParams, prefix);
        },
    };

    const ventureBanner = {
        clickEvent: () => {
            onPushEvent('tap_on_venture_banner', commonVentureBannerParams);
        },
        viewEvent: () => {
            onPushEvent(
                'view_venture_banner',
                {
                    ...commonVentureBannerParams,
                },
                undefined,
                true,
            );
        },
    };

    const voucherCampaign = {
        promoCodeEnabledEvent: () => {
            onPushEvent('promoCodeEnabled', commonVoucherCampaignParams);
        },
        tapOnPromoCodeTabEvent: () => {
            onPushEvent('tapOnPromoCodeTab', commonVoucherCampaignParams);
        },
        applyPromoCodeEvent: () => {
            onPushEvent('applyPromoCode', commonVoucherCampaignParams);
        },
        deletePromoCodeEvent: () => {
            onPushEvent('deletePromoCode', commonVoucherCampaignParams);
        },
        editPromoCodeEvent: () => {
            onPushEvent('editPromoCode', commonVoucherCampaignParams);
        },
        tapOnPayWithPromoCodeEvent: (isCodeAppied: boolean) => {
            if (isCodeAppied) {
                onPushEvent('tapOnPayWithPromoCode', commonVoucherCampaignParams);
            }
        },
        paymentSuccessfulWithPromoCodeEvent: (withPromo: boolean, pgName: string) => {
            if (withPromo) {
                onPushEvent(
                    'paymentSuccessfulWithPromoCode',
                    { ...universalParams, pg_name: pgName },
                    undefined,
                    true,
                    true,
                );
            }
        },
        paymentFailedWithPromoCodeEvent: (withPromo: boolean, pgName: string) => {
            if (withPromo) {
                onPushEvent(
                    'paymentFailedWithPromoCode',
                    { ...universalParams, pg_name: pgName },
                    undefined,
                    true,
                    true,
                );
            }
        },
    };

    const userProfile = {
        tapOnLoginEvent: () => {
            onPushEvent('tap_on_login', {
                ...universalParams,
                pg_name: vendor?.availablePGs,
                source,
            });
        },
    };

    const ventureReview = {
        ventureReviewEnabledEvent: () => {
            onPushEvent(
                'ventureReviewEnabled',
                {
                    ...ventureReviewCommonVars,
                    enableGoogleReviewAutoRedirect: reviewConfigs?.enableGoogleReviewAutoRedirect || EnableEnum.Disable,
                },
                undefined,
                true,
            );
        },
        tapOnReviewStarsEvent: (rate: number, embed?: boolean) => {
            onPushEvent('tapOnReviewStars', {
                ...ventureReviewCommonVars,
                customerRate: rate,
                isModal: !embed,
                enableGoogleReviewAutoRedirect: reviewConfigs?.enableGoogleReviewAutoRedirect || EnableEnum.Disable,
            });
        },
        tapOnReviewSubmitEvent: (rate: number, review: boolean) => {
            onPushEvent('tapOnReviewSubmit', {
                ...ventureReviewCommonVars,
                customerRate: rate,
                customerReview: review,
                enableGoogleReviewAutoRedirect: reviewConfigs?.enableGoogleReviewAutoRedirect || EnableEnum.Disable,
            });
        },
        closeReviewEvent: () => {
            onPushEvent('closeReview', {
                ...ventureReviewCommonVars,
                enableGoogleReviewAutoRedirect: reviewConfigs?.enableGoogleReviewAutoRedirect || EnableEnum.Disable,
            });
        },
        viewGoogleReviewEvent: () => {
            onPushEvent('viewGoogleReview', {
                ...ventureReviewCommonVars,
                enableGoogleReviewAutoRedirect: reviewConfigs?.enableGoogleReviewAutoRedirect || EnableEnum.Disable,
            });
        },
        closeGoogleReviewEvent: () => {
            onPushEvent('closeGoogleReview', ventureReviewCommonVars);
        },
        tapOnGoogleReviewEvent: () => {
            onPushEvent('tapOnGoogleReview', ventureReviewCommonVars);
        },
        reviewModalDefaultRateSubmittedEvent: (review: boolean) => {
            onPushEvent('reviewModalDefaultRateSubmitted', {
                ...ventureReviewCommonVars,
                customerReview: review,
            });
        },
    };

    const landing = {
        billAvailable: () => {
            onPushEvent('landingBillAvailable', universalParams);
        },
        billUnavailable: (err: any) => {
            onPushEvent('landingBillNotAvailable', {
                ...universalParams,
                error_code: err?.code,
                error_item: err?.items,
            });
        },
        noBillFetch: () => {
            onPushEvent('landingNoBillFetch', universalParams);
        },
        tapOnPayBill: (btnVariant: string) => {
            onPushEvent('tap_on_pay_bill', {
                ...universalParams,
                button_variant: btnVariant,
                opsMode: vendor?.opsMode,
                pg_name: vendor?.availablePGs,
            });
        },
    };

    const carouselBanner = {
        showCarouselBannerEvent: (
            name: string | undefined,
            location: SliderLocationEnum | undefined,
            placement: SliderPositionEnum | undefined,
        ) => {
            onPushEvent(
                'promotionalBannerShown',
                {
                    ...universalParams,
                    banner_name: name,
                    banner_location: location,
                    banner_placement: placement,
                },
                undefined,
                true,
                true,
            );
        },
        tapOnSliderEvent: (
            name: string | undefined,
            location: SliderLocationEnum | undefined,
            placement: SliderPositionEnum | undefined,
        ) => {
            onPushEvent(
                'tapOnPromotionalBanner',
                {
                    ...universalParams,
                    banner_name: name,
                    banner_location: location,
                    banner_placement: placement,
                },
                undefined,
                true,
                true,
            );
        },
        redirectFromSliderEvent: (
            name: string | undefined,
            location: SliderLocationEnum | undefined,
            placement: SliderPositionEnum | undefined,
        ) => {
            onPushEvent(
                'redirectFromBanner',
                {
                    ...universalParams,
                    banner_name: name,
                    banner_location: location,
                    banner_placement: placement,
                },
                undefined,
                true,
                true,
            );
        },
    };

    const payment = {
        tapPayBtn: (billAmount: number, pgName: string, _tip: number, hasSplit: boolean) => {
            onPushEvent('tap_pay_button', {
                ...universalParams,
                pg_name: pgName,
                tip_added: (_tip ?? 0) > 0 ? `${vendor?.country.currencySymbol} ${_tip}` : 0,
                Split_bill: hasSplit ? 1 : 0,
                bill_amount: billAmount,
                opsMode: vendor?.opsMode,
                ...getPaymentGoogleEventArgs(gatewayId),
            });
        },
        initiated: (success: boolean, pgName: string) => {
            onPushEvent('payment_initialized', {
                ...universalParams,
                pg_name: pgName,
                status: success ? 'successful' : 'failed',
                opsMode: vendor?.opsMode,
                is3ds,
                ...getPaymentGoogleEventArgs(gatewayId),
            });
        },
        success: (pgName: string, amount: number, _tip: number, discounts?: IAppliedDiscount[]) => {
            onPushEvent(
                'payment_success',
                {
                    ...universalParams,
                    opsMode: vendor?.opsMode,
                    pg_name: pgName,
                    is3ds,
                    amount,
                    tip: _tip,
                    ...getPaymentGoogleEventArgs(gatewayId),
                    ...getPaymentSuccessLoyaltyEventArgs(discounts),
                },
                undefined,
                true,
                false,
            );
        },
        failure: (pgName: string, amount: number) => {
            onPushEvent(
                'payment_failed',
                {
                    ...universalParams,
                    opsMode: vendor?.opsMode,
                    pg_name: pgName,
                    is3ds,
                    amount,
                    ...getPaymentGoogleEventArgs(gatewayId),
                },
                undefined,
                true,
                false,
            );
        },
    };

    const email = {
        receipt: (pgName: string) => {
            onPushEvent('email_receipt', {
                ...universalParams,
                opsMode: vendor?.opsMode,
                pg_name: pgName,
            });
        },
    };

    const corporateDiscounts = {
        tapOnCTA: (billAmount: number) => {
            onPushEvent('corporate_discounts_tap_cta', {
                ...universalParams,
                opsMode: vendor?.opsMode,
                bill_amount: billAmount,
            });
        },
        submitEmail: (emailDomain: string, billAmount: number) => {
            onPushEvent('corporate_discounts_submit_email', {
                ...universalParams,
                ops_mode: vendor?.opsMode,
                email_domain: emailDomain,
                bill_amount: billAmount,
            });
        },
        discountApplied: (emailDomain: string, discountAmount: number, billAmount: number) => {
            onPushEvent('corporate_discounts_discount_applied', {
                ...universalParams,
                ops_mode: vendor?.opsMode,
                bill_amount: billAmount,
                email_domain: emailDomain,
                discount: discountAmount,
            });
        },
    };

    const cAppTutorial = {
        tutorialDisplayed: () => {
            onPushEvent('cappTutorialDisplayed', {
                ...universalParams,
                language: lang,
            });
        },

        tutorialComplete: () => {
            onPushEvent('cappTutorialComplete', {
                ...universalParams,
                language: lang,
            });
        },

        tutorialSkipped: () => {
            onPushEvent('cappTutorialSkipped', {
                ...universalParams,
                language: lang,
            });
        },
    };

    const receipts = {
        view: (loyaltyEnabled: boolean) => {
            onPushEvent(
                'paymentReceiptsOpen',
                {
                    country_code: cc,
                    restaurant_name: url.slug,
                    loyaltyEnabled,
                },
                undefined,
                true,
                true,
            );
        },
    };

    const bill = {
        view: (billAmount: number, discount?: number) => {
            onPushEvent('view_bill', {
                ...universalParams,
                table_param: `${url.id}/${url.f1}/${url.f2}`,
                has_active_discount: discount ? 'yes' : 'no',
                bill_amount: billAmount,
                opsMode: vendor?.opsMode,
                source,
                pg_name: vendor?.availablePGs,
            });
        },
        refresh: () => {
            onPushEvent('refresh_bill', {
                ...universalParams,
                opsMode: vendor?.opsMode,
            });
        },
        tapBillItems: () => {
            onPushEvent('tap_bill_items', {
                ...universalParams,
                opsMode: vendor?.opsMode,
            });
        },
    };

    const smartTip = {
        tipRoundingModalDisplayed: (
            isMostCommon: boolean,
            eventTrigger: SmartTipModalEventConditionEnum,
            preRoundingBill: number,
            _smartTip: number,
            postRoundingBill: number,
            triggerAction?: SmartTipModalTriggerPointConditionEnum,
        ) => {
            onPushEvent('tipRoundingModalDisplayed', {
                ...universalParams,
                trigger_action: triggerAction,
                is_most_common: isMostCommon,
                event_trigger: eventTrigger,
                pre_rounding_bill: preRoundingBill,
                smart_tip: _smartTip,
                post_rounding_bill: postRoundingBill,
            });
        },
        tipRoundingSelectedOnModal: (
            isMostCommon: boolean,
            eventTrigger: SmartTipModalEventConditionEnum,
            preRoundingBill: number,
            _smartTip: number,
            postRoundingBill: number,
            triggerAction?: SmartTipModalTriggerPointConditionEnum,
        ) => {
            onPushEvent('tipRoundingSelectedOnModal', {
                ...universalParams,
                trigger_action: triggerAction,
                is_most_common: isMostCommon,
                event_trigger: eventTrigger,
                pre_rounding_bill: preRoundingBill,
                smart_tip: _smartTip,
                post_rounding_bill: postRoundingBill,
            });
        },
        tipRoundingNotSelectedOnModal: (
            isMostCommon: boolean,
            eventTrigger: SmartTipModalEventConditionEnum,
            preRoundingBill: number,
            _smartTip: number,
            postRoundingBill: number,
            triggerAction?: SmartTipModalTriggerPointConditionEnum,
        ) => {
            onPushEvent('tipRoundingNotSelectedOnModal', {
                ...universalParams,
                trigger_action: triggerAction,
                is_most_common: isMostCommon,
                event_trigger: eventTrigger,
                pre_rounding_bill: preRoundingBill,
                smart_tip: _smartTip,
                post_rounding_bill: postRoundingBill,
            });
        },
        tipRoundingModalManuallyClosed: (
            isMostCommon: boolean,
            eventTrigger: SmartTipModalEventConditionEnum,
            preRoundingBill: number,
            _smartTip: number,
            postRoundingBill: number,
            triggerAction?: SmartTipModalTriggerPointConditionEnum,
        ) => {
            onPushEvent('tipRoundingModalManuallyClosed', {
                ...universalParams,
                trigger_action: triggerAction,
                is_most_common: isMostCommon,
                event_trigger: eventTrigger,
                pre_rounding_bill: preRoundingBill,
                smart_tip: _smartTip,
                post_rounding_bill: postRoundingBill,
            });
        },
        tipRoundingToggleOn: (
            isMostCommon: boolean,
            eventTrigger: SmartTipModalEventConditionEnum,
            preRoundingBill: number,
            _smartTip: number,
            postRoundingBill: number,
        ) => {
            onPushEvent('tipRoundingToggleOn', {
                ...universalParams,
                is_most_common: isMostCommon,
                event_trigger: eventTrigger,
                pre_rounding_bill: preRoundingBill,
                smart_tip: _smartTip,
                post_rounding_bill: postRoundingBill,
            });
        },
        tipRoundingToggleOff: (
            isMostCommon: boolean,
            eventTrigger: SmartTipModalEventConditionEnum,
            preRoundingBill: number,
            _smartTip: number,
            postRoundingBill: number,
        ) => {
            onPushEvent('tipRoundingToggleOff', {
                ...universalParams,
                is_most_common: isMostCommon,
                event_trigger: eventTrigger,
                pre_rounding_bill: preRoundingBill,
                smart_tip: _smartTip,
                post_rounding_bill: postRoundingBill,
            });
        },
    };

    return {
        bill,
        tip,
        promotionalBanner,
        ventureBanner,
        voucherCampaign,
        userProfile,
        ventureReview,
        landing,
        carouselBanner,
        payment,
        email,
        corporateDiscounts,
        cAppTutorial,
        receipts,
        smartTip,
    };
};

export default useEventsCenter;
