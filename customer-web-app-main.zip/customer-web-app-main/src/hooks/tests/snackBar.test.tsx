import { useSnackbar } from 'notistack';
import { act, renderHook } from '@testing-library/react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';

jest.mock('notistack', () => ({
    useSnackbar: jest.fn(),
}));

jest.mock('@clubpay/customer-common-module/src/hook/translations', () => ({
    useTranslation: jest.fn(),
}));

describe('snackBar', () => {
    let closeSnackbar: jest.Mock;
    let enqueueSnackbar: jest.Mock;

    beforeEach(() => {
        closeSnackbar = jest.fn();
        enqueueSnackbar = jest.fn();
        (useSnackbar as jest.Mock).mockReturnValue({ closeSnackbar, enqueueSnackbar });
        (useTranslation as jest.Mock).mockReturnValue({
            t: (key: string) => key,
            i18n: {
                changeLanguage: jest.fn(),
            },
        });
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    // TODO: Fix failing test
    // it('should trigger a snackbar', () => {
    //     const { result } = renderHook(() => snackBar());

    //     act(() => {
    //         result.current.triggerSnackBar('Hello, world!');
    //     });

    //     expect(enqueueSnackbar).toHaveBeenCalledWith('Hello, world!', { persist: true });
    // });

    it('should close a snackbar', () => {
        const { result } = renderHook(() => snackBar());

        act(() => {
            result.current.closeSnackbar();
        });

        expect(closeSnackbar).toHaveBeenCalled();
    });

    it('should close snackbar on scroll after 5 seconds of last pull to refresh', () => {
        jest.useFakeTimers();

        const { result } = renderHook(() => snackBar());

        // Trigger a snackbar
        act(() => {
            result.current.triggerSnackBar('Hello, world!');
        });

        // Simulate a scroll after 4 seconds of the snackbar being triggered
        act(() => {
            jest.advanceTimersByTime(4000);
            window.dispatchEvent(new Event('scroll'));
        });

        // Snackbar should not be closed yet
        expect(closeSnackbar).not.toHaveBeenCalled();

        // Simulate another scroll after 6 seconds of the snackbar being triggered
        act(() => {
            jest.advanceTimersByTime(2000);
            window.dispatchEvent(new Event('scroll'));
        });

        // Snackbar should be closed
        expect(closeSnackbar).toHaveBeenCalled();
    });
});
