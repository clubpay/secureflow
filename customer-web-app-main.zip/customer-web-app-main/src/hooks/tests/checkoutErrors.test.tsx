/*
 * Creation Time: April 26 - 2023
 * Created By: yasincelebi
 * Name: checkoutErrors.test.tsx
 * Copyright 2023 customer-web-app
 */

import { isCheckoutError, useCheckoutErrorExtract } from '@/hooks/checkoutErrors';
import { renderHook } from '@testing-library/react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

jest.mock('@clubpay/customer-common-module/src/hook/translations', () => ({
    useTranslation: jest.fn(),
}));
describe('checkoutErrors', () => {
    beforeEach(() => {
        (useTranslation as jest.Mock).mockReturnValue({
            t: (key: string) => key,
            i18n: {
                changeLanguage: jest.fn(),
            },
        });
    });

    afterEach(() => {
        jest.clearAllMocks();
    });
    describe('isCheckoutError', () => {
        it('should return false if message is not empty', () => {
            expect(isCheckoutError('')).toBe(false);
        });

        it('returns false when message is undefined', () => {
            expect(isCheckoutError()).toBe(false);
        });

        it('returns true when message contains square brackets and other characters', () => {
            expect(isCheckoutError('[ERROR] Something went wrong.')).toBe(true);
        });

        it('returns false when message only contains square brackets', () => {
            expect(isCheckoutError('[ERROR]')).toBe(false);
        });

        it('returns true when message does not contain square brackets', () => {
            expect(isCheckoutError('Something went wrong.')).toBe(true);
        });
    });

    describe('useCheckoutErrorExtract', () => {
        it('it should return undefined if message is undefined, null or empty string', () => {
            const { result } = renderHook(() => useCheckoutErrorExtract());
            expect(result.current.getErrorMessage()).toBe(undefined);
            expect(result.current.getErrorMessage(null as any)).toBe(undefined);
            expect(result.current.getErrorMessage('')).toBe(undefined);
        });

        it('it should return actual message if message does not contain square brackets', () => {
            const { result } = renderHook(() => useCheckoutErrorExtract());
            expect(result.current.getErrorMessage('Something went wrong.')).toBe('Something went wrong.');
        });

        it('it should return actual message if message contains square brackets but no error code', () => {
            const { result } = renderHook(() => useCheckoutErrorExtract());
            expect(result.current.getErrorMessage('[ERROR]Something went wrong.')).toBe('Something went wrong.');
        });
    });
});
