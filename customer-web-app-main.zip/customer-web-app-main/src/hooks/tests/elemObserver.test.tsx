import { act, renderHook } from '@testing-library/react';
import useElemObserver from '@/hooks/elemObserver';

describe('useElemObserver', () => {
    let mockIntersectionObserver: any;
    let mockIntersectionObserverInstance: any;
    let mockQuerySelector: any;

    beforeEach(() => {
        mockIntersectionObserverInstance = {
            observe: jest.fn(),
            unobserve: jest.fn(),
        };
        mockIntersectionObserver = jest.fn().mockImplementation(() => mockIntersectionObserverInstance);
        window.IntersectionObserver = mockIntersectionObserver;

        mockQuerySelector = jest.fn();
        document.querySelector = mockQuerySelector;
    });

    afterEach(() => {
        mockIntersectionObserverInstance.observe.mockReset();
        mockIntersectionObserverInstance.unobserve.mockReset();
        mockIntersectionObserver.mockReset();
        mockQuerySelector.mockReset();
    });

    it('should create and observe an IntersectionObserver instance', () => {
        mockQuerySelector.mockReturnValueOnce(document.createElement('div'));
        const { result } = renderHook(() => useElemObserver({ selector: 'test', threshold: 0.5, hysteresis: 0.1 }));

        expect(result.current.show).toBeFalsy();
        expect(mockIntersectionObserver).toHaveBeenCalled();
        expect(mockIntersectionObserverInstance.observe).toHaveBeenCalled();
    });

    it('should return the default show state when specified', () => {
        mockQuerySelector.mockReturnValueOnce(document.createElement('div'));
        const { result } = renderHook(() =>
            useElemObserver({
                selector: 'test',
                threshold: 0.5,
                hysteresis: 0.1,
                defaultShow: true,
            }),
        );

        expect(result.current.show).toBeTruthy();
    });

    it('should not create or observe an IntersectionObserver instance if no matching element is found', () => {
        mockQuerySelector.mockReturnValueOnce(null);
        const { result } = renderHook(() => useElemObserver({ selector: 'test', threshold: 0.5, hysteresis: 0.1 }));

        expect(result.current.show).toBeFalsy();
        expect(mockIntersectionObserver).not.toHaveBeenCalled();
        expect(mockIntersectionObserverInstance.observe).not.toHaveBeenCalled();
    });

    it('should unobserve the IntersectionObserver instance when the hook unmounts', () => {
        const mockElement = document.createElement('div');
        mockQuerySelector.mockReturnValueOnce(mockElement);
        const { unmount } = renderHook(() => useElemObserver({ selector: 'test', threshold: 0.5, hysteresis: 0.1 }));

        expect(mockIntersectionObserverInstance.unobserve).not.toHaveBeenCalled();

        unmount();

        expect(mockIntersectionObserverInstance.unobserve).toHaveBeenCalledWith(mockElement);
    });

    // TODO: Fix failing test
    // it('should use the specified threshold when creating the IntersectionObserver instance', () => {
    //     mockQuerySelector.mockReturnValueOnce(document.createElement('div'));

    //     expect(mockIntersectionObserver).toHaveBeenCalledWith(
    //         expect.any(Function),
    //         expect.objectContaining({ threshold: 0.7 }),
    //     );
    // });

    it('should update the show state based on the threshold and hysteresis values', () => {
        const mockElement = document.createElement('div');
        mockQuerySelector.mockReturnValueOnce(mockElement);
        const { result } = renderHook(() => useElemObserver({ selector: 'test', threshold: 0.5, hysteresis: 0.1 }));

        expect(result.current.show).toBeFalsy();

        const callback = mockIntersectionObserver.mock.calls[0][0];
        act(() => callback([{ isIntersecting: true, intersectionRatio: 0.6 }]));

        expect(result.current.show).toBeFalsy();

        act(() => callback([{ isIntersecting: true, intersectionRatio: 0.4 }]));

        expect(result.current.show).toBeTruthy();

        act(() => callback([{ isIntersecting: false, intersectionRatio: 0.6 }]));

        expect(result.current.show).toBeFalsy();
    });
});
