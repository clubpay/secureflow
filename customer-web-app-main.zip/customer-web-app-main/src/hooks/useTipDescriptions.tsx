import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

function useTipDescriptions() {
    const { t } = useTranslation('common');

    const descriptions = {
        satisfaction: [t('Not satisfied'), t('Satisfied'), t('Very satisfied'), t('Delighted')],
        service: [t('Poor service'), t('Average service'), t('Good service'), t('Delighted')],
    };

    return [descriptions];
}

export { useTipDescriptions };
