import { useCallback } from 'react';
import MenuAPIManager from '@/repositories/menu';
import { IOrderItem } from '@/repositories/menu/types';
import { parseJSON } from '@clubpay/customer-common-module/src/utility/k_json';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { translator } from '@/services/utils/k_qsr';

interface IError {
    statusCode: number;
    message: any;
    description: string;
}

export const useQsrError = () => {
    const menuApi = MenuAPIManager.getInstance();
    const { t } = useTranslation('common');
    const { url, lang } = useQlubRouter();
    const { vendor } = useVendor();
    const { triggerSnackBar: enqueueSnackbar } = snackBar();

    const handleDefaultError = useCallback(
        (err: IError) => {
            enqueueSnackbar(t('Something went wrong ({{message}})', { message: err?.message || 'NA' }), {
                variant: 'error',
            });
        },
        [t],
    );

    const handle400Error = useCallback(
        (err: IError, items: IOrderItem[]) => {
            const data = parseJSON(err?.description);
            let ids: string[] = [];
            switch (err.message) {
                case 'PRICE_IS_NOT_VALID':
                    enqueueSnackbar(t('Something went wrong: {{message}}', { message: t('Price is invalid') }), {
                        variant: 'error',
                    });
                    return;
                case 'INVALID_SCHEDULED_TIME':
                    enqueueSnackbar(
                        t('Something went wrong: {{message}}', { message: t('Selected scheduled time is too early') }),
                        {
                            variant: 'error',
                        },
                    );
                    return;
                case 'OUT_OF_STOCK':
                    ids = data?.outOfStockIds || [];
                    break;
                case 'DISABLED_MENU_ITEM':
                    ids = data?.disabledItemIds || [];
                    break;
                case 'INSUFFICIENT_INVENTORY':
                    ids = data?.insufficientIds || [];
                    break;
                default:
                    handleDefaultError(err);
                    return;
            }

            if (ids.length === 0) {
                handleDefaultError(err);
                return;
            }

            const list = items.reduce<Array<{ menuId: string; productId: string }>>((a, c) => {
                if (ids.includes(c.id)) {
                    a.push({ menuId: c.menuId, productId: c.id });
                }
                return a;
            }, []);
            if (list.length === 0) {
                handleDefaultError(err);
                return;
            }

            menuApi.getManyProduct(url, list, vendor).then((res) => {
                const names = Object.values(res).map((item) => {
                    return translator(item?.name, item?.nameTranslations, lang);
                });
                if (!names.length) {
                    return;
                }

                enqueueSnackbar(
                    names.length === 1
                        ? t('{{name}} is not available', {
                              name: names[0],
                          })
                        : t('{{name}} are not available', {
                              name: names.join(', '),
                          }),
                    {
                        variant: 'info',
                    },
                );
            });
        },
        [handleDefaultError],
    );

    const handle403Error = useCallback(
        (err: IError) => {
            switch (err.message) {
                case 'DYNAMIC_QR_TTL_EXPIRED':
                    enqueueSnackbar(t('The QR code has timed out, scan a fresh code to continue'), {
                        variant: 'error',
                    });
                    return;
                case 'DYNAMIC_QR_IS_EXPIRED':
                    enqueueSnackbar(
                        t('This QR code has expired, please request the latest QR code to continue ordering'),
                        {
                            variant: 'error',
                        },
                    );
                    return;
                case 'DYNAMIC_QR_ORDER_EXIST':
                    enqueueSnackbar(
                        t('An order has already been submitted using this QR code, please scan a new one to proceed'),
                        {
                            variant: 'error',
                        },
                    );
                    return;
                default:
                    enqueueSnackbar(t('This link is not valid, please contact the restaurant representative'), {
                        variant: 'error',
                    });
            }
        },
        [handleDefaultError],
    );

    const handleError = useCallback(
        (err: IError, items: IOrderItem[]) => {
            switch (err?.message?.statusCode || err?.statusCode) {
                case 400:
                    return handle400Error(err, items);
                case 403:
                    return handle403Error(err);
                default:
                    return handleDefaultError(err);
            }
        },
        [handle400Error, handle403Error, handleDefaultError],
    );

    return {
        handleError,
    };
};
