import { useCallback, useMemo } from 'react';
import { useTheme } from '@mui/material';

export const useQsrColors = () => {
    const theme = useTheme();

    const list = useMemo(() => {
        return [
            theme.qlub.palette.dynamicColors?.purple,
            theme.qlub.palette.dynamicColors?.yellow,
            theme.qlub.palette.dynamicColors?.blue,
            theme.qlub.palette.dynamicColors?.green,
        ];
    }, [theme]);

    const getByIndex = useCallback((index: number) => {
        return list[index % list.length];
    }, []);

    return {
        list,
        getByIndex,
    };
};
