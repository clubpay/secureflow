import 'intersection-observer';
import { useEffect, useState } from 'react';
import { isKeyboardOpen } from '@/hooks/useWindowResize';

interface IOptions {
    selector: string;
    threshold: number;
    hysteresis: number;
    defaultShow?: boolean;
    checkInside?: boolean;
}

const useElemObserver = ({ selector, hysteresis, threshold, defaultShow, checkInside }: IOptions) => {
    const [show, setShow] = useState(defaultShow || false);

    useEffect(() => {
        const el = document.querySelector(selector);
        if (!el) {
            return;
        }

        // @ts-ignore
        IntersectionObserver.prototype.POLL_INTERVAL = 100;
        const intersectionObserver = new IntersectionObserver(
            (entries) => {
                if (isKeyboardOpen()) {
                    return;
                }
                if (checkInside) {
                    setShow(entries[0].intersectionRatio > threshold + (show ? hysteresis : 0));
                } else {
                    setShow(entries[0].intersectionRatio <= threshold + (show ? hysteresis : 0));
                }
            },
            {
                threshold: threshold + (show ? hysteresis : 0),
            },
        );
        intersectionObserver.observe(el);

        return () => {
            intersectionObserver.unobserve(el);
        };
    }, [selector, show]);

    return { show, setShow };
};

export default useElemObserver;
