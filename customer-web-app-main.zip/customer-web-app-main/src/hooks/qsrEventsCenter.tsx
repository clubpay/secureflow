import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { getEventPrefix } from '@/hooks/utils';

const useQsrEventsCenter = () => {
    const { url } = useQlubRouter();
    const prefix = getEventPrefix(url);

    const qsr = {
        qsrPageViewEvent: (pageName: string) => {
            onPushEvent('page_viewed', { page_name: pageName }, prefix);
        },
        qsrMenuSelectEvent: (menuInfo: { name: string; id: string }) => {
            onPushEvent('menu_selected', { menu_name_id: `${menuInfo.name}/${menuInfo.id}` }, prefix);
        },
        qsrGridViewSelectEvent: (menuInfo: { name: string; id: string }) => {
            onPushEvent('grid_view_selected', { menu_name_id: `${menuInfo.name}/${menuInfo.id}` }, prefix);
        },
        qsrListViewSelectEvent: (menuInfo: { name: string; id: string }) => {
            onPushEvent('list_view_selected', { menu_name_id: `${menuInfo.name}/${menuInfo.id}` }, prefix);
        },
        qsrCategorySwitchEvent: (categoryName: string) => {
            onPushEvent('category_switched', { category_name: categoryName }, prefix);
        },
        qsrMenuListDisplayedEvent: () => {
            onPushEvent('menu_list_displayed', undefined, prefix);
        },
        qsrMenuSwitchedEvent: () => {
            onPushEvent('menu_switched', undefined, prefix);
        },
        qsrProductModalEvent: (productName: string) => {
            onPushEvent('product_details_viewed', { product_name: productName }, prefix);
        },
        qsrProductAddChartEvent: (val: { pageName: string; productName: string; quantity: number }) => {
            onPushEvent(
                'added_to_cart',
                {
                    page_name: val.pageName,
                    product_name: val.productName,
                    quantity: val.quantity,
                },
                prefix,
            );
        },
        qsrModifierSelectEvent: (mandatory: boolean) => {
            onPushEvent('Modifier_selected', { is_selection_mandatory: mandatory }, prefix);
        },
        qsrViewPayEvent: () => {
            onPushEvent('View_pay_option_selection', undefined, prefix);
        },
        qsrProductRemoveChartEvent: (val: { pageName: string; productName: string; quantity: number }) => {
            onPushEvent(
                'product_removed',
                {
                    page_name: val.pageName,
                    product_name: val.productName,
                    quantity: val.quantity,
                },
                prefix,
            );
        },
        qsrSpecialRequestEvent: () => {
            onPushEvent('Special_request_added', undefined, prefix);
        },
        qsrProceedToCheckoutEvent: () => {
            onPushEvent('Proceed_to_checkout', undefined, prefix);
        },
        qsrPrepOrderDetailsEvent: (pageName: string) => {
            onPushEvent('order_details_checked', { page_name: pageName }, prefix);
        },
        qsrBackButtonEvent: (pageName: string) => {
            onPushEvent('back_button_selected', { page_name: pageName }, prefix);
        },
        qsrOrderHistorySelected: (pageName: string) => {
            onPushEvent('qsr_OrderHistory_selected', { page_name: pageName });
        },
        qsrNavigatedtoOrderPreparation: () => {
            onPushEvent('qsr_NavigatedtoOrderPreparation');
        },
        qsrCustomerInfoEntered: (fieldName: string) => {
            onPushEvent('qsr_Customerinfo_entered', { field_name: fieldName });
        },
        qsrPayNowButtonSelected: () => {
            onPushEvent('qsr_PayNowButtonSelected');
        },
        qsrSelectGetReceipt: () => {
            onPushEvent('qsr_SelectGetReceipt');
        },
        qsrEnterGetReceiptInfo: () => {
            onPushEvent('qsr_EnterGetReceiptInfo');
        },
        qsrRequestTheReceipt: () => {
            onPushEvent('qsr_RequesttheReceipt');
        },
        qsrDownloadTheReceipt: () => {
            onPushEvent('qsr_DownloadTheReceipt');
        },
        qsrAsapTypeSelected: () => {
            onPushEvent('qsr_Asap_type_selected');
        },
        qsrScheduleTypeSelected: () => {
            onPushEvent('qsr_Schedule_type_selected');
        },
        qsrOrderScheduled: (selectedDate: string, selectedRange: string) => {
            onPushEvent('qsr_Order_Scheduled', { selected_date: selectedDate, selected_range: selectedRange });
        },
        qsrSwitchedAsap: (val: { actionLocation: string }) => {
            onPushEvent('qsr_Switched_Asap', {
                action_location: val.actionLocation,
            });
        },
        qsrScheduledCancelled: () => {
            onPushEvent('qsr_Scheduled_cancelled');
        },
        qsrAddToOrderSelected: (pageName: string) => {
            onPushEvent('qsr_AddToOrder_Selected', { page_name: pageName });
        },
        qsrNewOrderSelected: (pageName: string) => {
            onPushEvent('qsr_NewOrder_selected', { page_name: pageName });
        },
        qsrSearchSelected: () => {
            onPushEvent('qsr_Search_Selected');
        },
        qsrSearchTyped: (searchInput: string) => {
            onPushEvent('qsr_Search_Typed', { search_input: searchInput });
        },
    };
    return {
        qsr,
    };
};

export default useQsrEventsCenter;
