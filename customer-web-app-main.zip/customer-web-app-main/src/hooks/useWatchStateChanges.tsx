/*
 * Creation Time: November 30 - 2022
 * Created By: yasincelebi
 * Name: useWatchStateChanges.tsx
 * Copyright 2022 customer-web-app
 */

import { useEffect, useRef } from 'react';
import { isEqual } from 'lodash';

const useWatchStateChanges = (callback: any, args: any[]) => {
    const argsRef = useRef<any[]>(args);

    const isChanged = !isEqual(argsRef.current, args);

    useEffect(() => {
        if (isChanged) {
            argsRef.current = args;
            callback(...args);
        }
    }, [args, isChanged]);
};

export default useWatchStateChanges;
