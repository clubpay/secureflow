/*
 * Creation Time: November 18 - 2022
 * Created By: yasincelebi
 * Name: tracker.tsx
 * Copyright 2022 customer-web-app
 */

import { useEffect, useRef, useState } from 'react';
import { isEqual } from 'lodash';
import { AxiosError } from 'axios';

export interface ITracker {
    componentName: string;
    dispatchOnMount?: (data: any) => { event: string };
}

class _OLD_Tracker {
    private static instance: _OLD_Tracker;

    private static elementName: string = '';

    protected constructor() {
        _OLD_Tracker.trackWindowErrors();
    }

    public static getInstance() {
        if (!this.instance) {
            this.instance = new _OLD_Tracker();
        }

        return this.instance;
    }

    static trackObject: any[] = [];

    track({ event, data }: { event: string; data: any }) {
        const newTrackItem = {
            component: _OLD_Tracker.elementName,
            event: `${event}`,
            data,
            date: new Date(),
            location: window.location.href,
        };

        _OLD_Tracker.trackObject.push(newTrackItem);
    }

    trackApi({ event, data }: { event: string; data: any }) {
        console.log(data);
        const newData = this.parseData(data);

        this.track({
            event: `${event}_api`,
            data: newData,
        });
    }

    convertApiObject(response: any) {
        return {
            traceID: response?.headers?.['qlub-trace-id'],
            httpCode: response?.status,
            method: response?.config.method,
            response: response?.data,
        };
    }

    parseData(data: any) {
        let apiData: any = {};
        if (data.res instanceof AxiosError) {
            apiData = this.convertApiObject(data.res.response);
        } else {
            apiData = this.convertApiObject(data.res);
        }

        return {
            payload: data.data,
            endpoint: data.url,
            ...apiData,
        };
    }

    static trackWindowErrors() {
        window.addEventListener('error', (e) => {
            // Get the error properties from the error event object
            const { message, filename, lineno, colno, error } = e;

            _OLD_Tracker.getInstance().track({
                event: 'ERROR',
                data: {
                    message,
                    filename,
                    lineno,
                    colno,
                    error,
                },
            });
        });
    }

    trackComponent({ componentName, dispatchOnMount }: ITracker) {
        _OLD_Tracker.elementName = componentName;
        return (WrappedComponent: any) => (props: any) => {
            const [state, setState] = useState({});
            const prevPropsRef = useRef();
            useEffect(() => {
                if (dispatchOnMount) {
                    const { event } = dispatchOnMount(state);
                    _OLD_Tracker.getInstance().track({
                        event,
                        data: prevPropsRef.current,
                    });
                }
            }, []);
            useEffect(() => {
                prevPropsRef.current = props;
            });
            const prevProps = prevPropsRef.current;

            useEffect(() => {
                if (!isEqual(prevProps, props)) {
                    setState(props);

                    _OLD_Tracker.getInstance().track({
                        event: 'component_update',
                        data: JSON.parse(JSON.stringify(props)), // remove function props
                    });
                }
            }, [props]);

            return <WrappedComponent {...props} />;
        };
    }

    trackStateChanges(state: any) {
        this.track({
            event: 'component_update',
            data: state,
        });
    }
}

export { _OLD_Tracker };
