import { IURLTopology, QSRRouterModeEnum } from '@clubpay/customer-common-module/src/hook/router';

export const getEventPrefix = (url: IURLTopology) => {
    const { qsr } = url;
    switch (qsr) {
        default:
            return '';
        case QSRRouterModeEnum.True:
        case QSRRouterModeEnum.Mixed:
            return 'qsr_';
        case QSRRouterModeEnum.DigitalMenu:
            return 'dm_';
    }
};
