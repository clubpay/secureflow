import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { getDiningSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';

const useMenuEventsCenter = () => {
    const { vendor } = useVendor();
    const { url } = useQlubRouter();
    const diningSessionPayload = getDiningSession(url);
    const menu = {
        viewBillwithPayBillCTAEvent: () => {
            onPushEvent('View_Bill_with_Pay_bill_CTA', {
                restaurant_name: vendor?.name,
                diningSessionId: diningSessionPayload?.id,
                menu_type: vendor?.config?.menuMode,
            });
        },
        viewBillwithoutPayBillCTAEvent: () => {
            onPushEvent('View_Bill_without_Pay_bill_CTA', {
                restaurant_name: vendor?.name,
                diningSessionId: diningSessionPayload?.id,
                menu_type: vendor?.config?.menuMode,
            });
        },
        viewBillClickPayBillCTAEvent: () => {
            onPushEvent('View_Bill_click_Pay_bill_CTA', {
                restaurant_name: vendor?.name,
                diningSessionId: diningSessionPayload?.id,
            });
        },
    };
    return {
        menu,
    };
};

export default useMenuEventsCenter;
