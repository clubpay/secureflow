import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { EnableEnum } from '@clubpay/customer-common-module/src/repository/vendor';

interface IProps {
    odf: string;
}

const useODFAvailabilityCheck = ({ odf }: IProps) => {
    const { vendor } = useVendor();
    const { config } = useConfigContext();

    if (Number(odf || '0') === 0) {
        return false;
    }

    if (vendor?.config?.commissionOptionalDinerFee === EnableEnum.Disable) {
        return false;
    }

    if (
        vendor?.config?.commissionOptionalDinerFee !== EnableEnum.Enable &&
        config?.commissionOptionalDinerFee !== EnableEnum.Enable
    ) {
        return false;
    }

    return true;
};

export default useODFAvailabilityCheck;
