import { getLocaleText } from '@clubpay/customer-common-module/src/component/MultiLocale';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

interface IProps {
    tip?: number;
}

export const useGetInclusiveChargesMessage = ({ tip }: IProps): { inclusiveChargesMessage: string } => {
    const { t } = useTranslation('common');
    const { lang } = useQlubRouter();
    const { vendor } = useVendor();

    const { config: countryConfig } = useConfigContext();

    const vendorLvlDisplayTxt = getLocaleText(vendor?.config?.inclusiveChargesText || '', lang, '');
    const countryLvlDisplayTxt = getLocaleText(countryConfig?.inclusiveChargesText || '', lang, '');
    const vendorLvlDisplayTxtWithTip = getLocaleText(vendor?.config?.inclusiveChargesTextWithTip || '', lang, '');
    const countryLvlDisplayTxtWithTip = getLocaleText(countryConfig?.inclusiveChargesTextWithTip || '', lang, '');

    const displayText = vendorLvlDisplayTxt || countryLvlDisplayTxt || t('Inclusive of all taxes and charges');
    const displayTextWithTip =
        vendorLvlDisplayTxtWithTip || countryLvlDisplayTxtWithTip || t('Includes tip, taxes and charges');

    const inclusiveChargesMessage = tip && tip > 0 ? displayTextWithTip : displayText;

    return {
        inclusiveChargesMessage,
    };
};
