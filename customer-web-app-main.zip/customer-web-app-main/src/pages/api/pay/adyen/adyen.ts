import axiosInstance from '@clubpay/customer-common-module/src/repository/axios';
import { AxiosResponse } from 'axios';
import { NextApiRequest, NextApiResponse } from 'next';

export type RegisterPayload = {
    merchantAccount: string;
    amount: {
        value: number;
        currency: string;
    };
    returnUrl: string;
    reference: string;
    countryCode: string;
};

const createSession = async ({
    merchantAccount,
    amount,
    returnUrl,
    reference,
    countryCode,
}: RegisterPayload): Promise<any> => {
    const url = 'https://checkout-test.adyen.com/v70/sessions';

    const data = {
        merchantAccount,
        amount,
        returnUrl,
        reference,
        countryCode,
    };

    const apiKey =
        'AQEhhmfuXNWTK0Qc+iSBnnE6jssOYyXYSpSNzl7qNJMjdSuIEMFdWw2+5HzctViMSCJMYAc=-hEw66FkMz96yxttcEPWDF+ryL00EIf/lmjSJcDil9Ew=-AN38#cr,]wsqHdvr';
    const result = await axiosInstance.Post(url, {}, { params: data, headers: { 'x-API-key': apiKey } });

    return result;
};

const handler = async (req: NextApiRequest, res: NextApiResponse) => {
    const { merchantAccount, amount, returnUrl, reference, countryCode } = req.body as RegisterPayload;
    const resp = (await createSession({
        merchantAccount,
        amount,
        returnUrl,
        reference,
        countryCode,
    })) as AxiosResponse<any>;

    return res.status(200).json(resp.data);
};
export default handler;
