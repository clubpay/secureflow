import { ReactElement } from 'react';
import QSRManualAmount from '@/views/QSR/ManualAmount';
import { BasketContextProvider } from '@/contexts/basket';
import QlubLayout from '@/layout/QlubLayout';

QSRManualAmount.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="static">
            <BasketContextProvider>{page}</BasketContextProvider>
        </QlubLayout>
    );
};

export default QSRManualAmount;
