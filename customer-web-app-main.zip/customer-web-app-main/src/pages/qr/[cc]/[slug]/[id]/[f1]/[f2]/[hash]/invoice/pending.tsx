/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import { ReactElement } from 'react';
import Confirm from '@/views/Bill/Confirm';
import QlubLayout from '@/layout/QlubLayout';
import WalletBalance from '@clubpay/loyalty/dist/drivers/customer/WalletBalance';

function ConfirmPending(props: any) {
    return <Confirm {...props} />;
}

ConfirmPending.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout
            variant="compact"
            borderBottom
            startComponent={() => <WalletBalance />}
            hideVendorLogo
            hideVendorTitle
            hideHeaderIfEmpty
            hideFooter
        >
            {page}
        </QlubLayout>
    );
};

export default ConfirmPending;
