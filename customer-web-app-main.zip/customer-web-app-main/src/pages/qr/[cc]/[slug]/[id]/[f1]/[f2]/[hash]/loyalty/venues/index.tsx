import PageTitle from '@/components/Common/PageTitle';
import QlubLayout from '@/layout/QlubLayout';
import Venues from '@/views/Loyalty/Venues';
import { ReactElement } from 'react';

Venues.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout
            variant="compact"
            title={<PageTitle />}
            forceTitle
            titleFullWidth
            withBack={typeof document !== 'undefined' && document.referrer !== ''}
            hideFooter
            key="venues"
        >
            {page}
        </QlubLayout>
    );
};

export default Venues;
