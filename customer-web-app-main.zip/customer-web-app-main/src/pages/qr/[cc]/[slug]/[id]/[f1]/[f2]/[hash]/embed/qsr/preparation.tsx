import QSRPreparation from '@/views/QSR/Preparation';
import { ReactElement } from 'react';
import { BasketContextProvider } from '@/contexts/basket';
import QlubLayout from '@/layout/QlubLayout';
import { BridgeContextProvider } from 'contexts/bridge';

function EmbedQSRPreparation(props: any) {
    return <QSRPreparation {...props} />;
}

EmbedQSRPreparation.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="none" borderBottom hideFooter>
            <BasketContextProvider>
                <BridgeContextProvider>{page}</BridgeContextProvider>
            </BasketContextProvider>
        </QlubLayout>
    );
};

export default EmbedQSRPreparation;
