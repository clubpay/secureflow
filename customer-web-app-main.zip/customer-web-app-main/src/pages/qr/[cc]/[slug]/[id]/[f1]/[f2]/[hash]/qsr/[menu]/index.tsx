import { ReactElement } from 'react';
import QSRMenu from '@/views/QSR/Menu';
import { BasketContextProvider } from '@/contexts/basket';
import QlubLayout from '@/layout/QlubLayout';
import PageTitle from '@/components/Common/PageTitle';
import QSROrderHistory from '@/components/QSR/QSROrderHistory';
import QSRPayBillButton from '@/components/QSR/QSRPayBillButton';

function QSRMenuSelected(props: any) {
    return <QSRMenu {...props} />;
}

QSRMenuSelected.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout
            variant="compact"
            title={<PageTitle />}
            endComponent={
                <>
                    <QSRPayBillButton />
                    <QSROrderHistory iconOnly />
                </>
            }
            withBack
            borderBottom
            openingHoursBanner
        >
            <BasketContextProvider>{page}</BasketContextProvider>
        </QlubLayout>
    );
};

export default QSRMenuSelected;
