/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import { ReactElement } from 'react';
import Invoice from '@/views/Bill/Invoice';
import QlubLayout from '@/layout/QlubLayout';

// Invoice.getLayout = function getLayout(page: ReactElement) {
//     return (
//         <RefreshContextProvider>
//             <LayoutExpanded
//                 logoSize="small"
//                 isBlur
//                 noDiscount
//                 customBackgroundImage
//                 footer
//                 fixed
//                 pullable
//                 showAuth
//                 disableScroll
//             >
//                 {page}
//             </LayoutExpanded>
//         </RefreshContextProvider>
//     );
// };

Invoice.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="small" logoSize="small" hideFooter hideVendorTitle pullable>
            {page}
        </QlubLayout>
    );
};

export default Invoice;
