import PageTitle from '@/components/Common/PageTitle';
import QlubLayout from '@/layout/QlubLayout';
import Subscription from '@/views/Subscription/Manage';
import { ReactElement } from 'react';

Subscription.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout
            variant="compact"
            title={<PageTitle />}
            forceTitle
            titleFullWidth
            withBack
            hideFooter
            key="subscription"
        >
            {page}
        </QlubLayout>
    );
};

export default Subscription;
