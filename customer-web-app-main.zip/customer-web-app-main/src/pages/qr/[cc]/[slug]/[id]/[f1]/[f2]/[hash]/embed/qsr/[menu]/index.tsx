import { ReactElement } from 'react';
import QSRMenu from '@/views/QSR/Menu';
import { BasketContextProvider } from '@/contexts/basket';
import QlubLayout from '@/layout/QlubLayout';
import { BridgeContextProvider } from 'contexts/bridge';

function EmbedQSRMenuSelected(props: any) {
    return <QSRMenu {...props} />;
}

EmbedQSRMenuSelected.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="none" borderBottom hideFooter>
            <BasketContextProvider>
                <BridgeContextProvider>{page}</BridgeContextProvider>
            </BasketContextProvider>
        </QlubLayout>
    );
};

export default EmbedQSRMenuSelected;
