import { ReactElement } from 'react';
import Profile from '@/views/User/Profile';
import PageTitle from '@/components/Common/PageTitle';
import QlubLayout from '@/layout/QlubLayout';
import withAuth from '@/components/Common/RouteProtector';

Profile.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="compact" title={<PageTitle />} withBack forceTitle borderBottom key="user-profile">
            {page}
        </QlubLayout>
    );
};

export default withAuth(Profile);
