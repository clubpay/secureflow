import QSRPreparation from '@/views/QSR/Preparation';

export default QSRPreparation;
