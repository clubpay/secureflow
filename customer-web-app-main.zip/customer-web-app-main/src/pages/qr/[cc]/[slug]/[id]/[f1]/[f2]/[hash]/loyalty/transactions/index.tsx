import PageTitle from '@/components/Common/PageTitle';
import QlubLayout from '@/layout/QlubLayout';
import Transactions from '@/views/Loyalty/Tranactions';
import { ReactElement } from 'react';

Transactions.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout
            variant="compact"
            title={<PageTitle />}
            forceTitle
            titleFullWidth
            withBack
            hideFooter
            key="transactions"
        >
            {page}
        </QlubLayout>
    );
};

export default Transactions;
