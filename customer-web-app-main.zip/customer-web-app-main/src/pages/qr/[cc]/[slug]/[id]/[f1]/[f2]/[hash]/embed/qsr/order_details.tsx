import { ReactElement } from 'react';
import QSROrderDetails from '@/views/QSR/OrderDetails';
import QlubLayout from '@/layout/QlubLayout';
import { BasketContextProvider } from '@/contexts/basket';
import { BridgeContextProvider } from 'contexts/bridge';

function EmbedQSROrderDetails(props: any) {
    return <QSROrderDetails {...props} />;
}

EmbedQSROrderDetails.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="none" borderBottom hideFooter>
            <BasketContextProvider>
                <BridgeContextProvider>{page}</BridgeContextProvider>
            </BasketContextProvider>
        </QlubLayout>
    );
};

export default EmbedQSROrderDetails;
