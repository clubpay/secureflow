import { ReactElement } from 'react';
import QSROrderDetails from '@/views/QSR/OrderDetails';
import PageTitle from '@/components/Common/PageTitle';
import QlubLayout from '@/layout/QlubLayout';
import { BasketContextProvider } from '@/contexts/basket';

// QSROrderDetails.getLayout = function getLayout(page: ReactElement) {
//     return (
//         <BasketContextProvider>
//             <LayoutCompact qsr animation customBackgroundImage blurBg withGradient showBackIcon>
//                 {page}
//             </LayoutCompact>
//         </BasketContextProvider>
//     );
// };

QSROrderDetails.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="compact" title={<PageTitle />} withBack borderBottom>
            <BasketContextProvider>{page}</BasketContextProvider>
        </QlubLayout>
    );
};

export default QSROrderDetails;
