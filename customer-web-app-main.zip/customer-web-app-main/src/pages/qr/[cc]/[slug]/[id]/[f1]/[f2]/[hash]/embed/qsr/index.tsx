import { ReactElement } from 'react';
import QlubLayout from '@/layout/QlubLayout';
import QSRMenu from '@/views/QSR/Menu';
import { BasketContextProvider } from '@/contexts/basket';
import { BridgeContextProvider } from 'contexts/bridge';

function EmbedQSRMenu(props: any) {
    return <QSRMenu {...props} />;
}

EmbedQSRMenu.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="none" borderBottom hideFooter>
            <BasketContextProvider>
                <BridgeContextProvider>{page}</BridgeContextProvider>
            </BasketContextProvider>
        </QlubLayout>
    );
};

export default EmbedQSRMenu;
