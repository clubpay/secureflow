/*
    Creation Time: 2022 - May - 10
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import Iframe from '@/views/Bill/Iframe';

export default Iframe;
