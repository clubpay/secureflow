import { ReactElement } from 'react';
import QlubLayout from '@/layout/QlubLayout';
import QSRMenu from '@/views/QSR/Menu';
import { BasketContextProvider } from '@/contexts/basket';
import PageTitle from '@/components/Common/PageTitle';
import QSROrderHistory from '@/components/QSR/QSROrderHistory';
import QSRPayBillButton from '@/components/QSR/QSRPayBillButton';

QSRMenu.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout
            variant="scrollable"
            title={<PageTitle />}
            endComponent={
                <>
                    <QSRPayBillButton />
                    <QSROrderHistory iconOnly />
                </>
            }
            openingHoursBanner
        >
            <BasketContextProvider>{page}</BasketContextProvider>
        </QlubLayout>
    );
};

export default QSRMenu;
