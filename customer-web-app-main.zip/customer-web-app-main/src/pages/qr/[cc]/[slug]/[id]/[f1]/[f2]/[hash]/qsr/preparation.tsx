import QSRPreparation from '@/views/QSR/Preparation';
import { ReactElement } from 'react';
import { BasketContextProvider } from '@/contexts/basket';
import PageTitle from '@/components/Common/PageTitle';
import QlubLayout from '@/layout/QlubLayout';
import QSROrderHistory from '@/components/QSR/QSROrderHistory';

// QSRPreparation.getLayout = function getLayout(page: ReactElement) {
//     return (
//         <BasketContextProvider>
//             <LayoutCompact
//                 animation
//                 customBackgroundImage
//                 blurBg
//                 withGradient
//                 showAuth
//                 showBackIcon
//                 endComponent={<QSROrderHistory />}
//             >
//                 {page}
//             </LayoutCompact>
//         </BasketContextProvider>
//     );
// };

QSRPreparation.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout
            key="preparation"
            variant="compact"
            title={<PageTitle />}
            endComponent={<QSROrderHistory />}
            titleFullWidth
        >
            <BasketContextProvider>{page}</BasketContextProvider>
        </QlubLayout>
    );
};

export default QSRPreparation;
