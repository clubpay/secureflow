import { ReactElement } from 'react';
import SocialMenu from '@/views/QSR/SocialMenu';
import { BasketContextProvider } from '@/contexts/basket';
import QSROrderHistory from '@/components/QSR/QSROrderHistory';
import PageTitle from '@/components/Common/PageTitle';
import QlubLayout from '@/layout/QlubLayout';

SocialMenu.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="scrollable" title={<PageTitle />} endComponent={<QSROrderHistory />}>
            <BasketContextProvider>{page}</BasketContextProvider>
        </QlubLayout>
    );
};

export default SocialMenu;
