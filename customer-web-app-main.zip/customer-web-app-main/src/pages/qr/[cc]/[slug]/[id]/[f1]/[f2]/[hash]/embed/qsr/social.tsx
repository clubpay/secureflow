import { ReactElement } from 'react';
import SocialMenu from '@/views/QSR/SocialMenu';
import { BasketContextProvider } from '@/contexts/basket';
import QlubLayout from '@/layout/QlubLayout';
import { BridgeContextProvider } from 'contexts/bridge';

function EmbedSocialMenu(props: any) {
    return <SocialMenu {...props} />;
}

EmbedSocialMenu.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="none" borderBottom hideFooter>
            <BasketContextProvider>
                <BridgeContextProvider>{page}</BridgeContextProvider>
            </BasketContextProvider>
        </QlubLayout>
    );
};

export default EmbedSocialMenu;
