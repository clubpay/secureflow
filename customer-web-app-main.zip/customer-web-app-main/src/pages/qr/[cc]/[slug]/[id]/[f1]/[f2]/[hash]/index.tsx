/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import { ReactElement } from 'react';
import Landing from 'views/Bill/Landing';
import QlubLayout from '@/layout/QlubLayout';

Landing.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="static" key="landing">
            {page}
        </QlubLayout>
    );
};

export default Landing;
