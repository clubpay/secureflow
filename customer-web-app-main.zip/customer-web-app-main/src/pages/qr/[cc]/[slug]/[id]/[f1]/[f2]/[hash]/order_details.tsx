import QSROrderDetails from '@/views/QSR/OrderDetails';

export default QSROrderDetails;
