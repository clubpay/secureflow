/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import { ReactElement } from 'react';
import LegacyMenu from 'views/Menu/LegacyMenu';
import QlubLayout from '@/layout/QlubLayout';

LegacyMenu.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="small" logoSize="small" pullable>
            {page}
        </QlubLayout>
    );
};
export default LegacyMenu;
