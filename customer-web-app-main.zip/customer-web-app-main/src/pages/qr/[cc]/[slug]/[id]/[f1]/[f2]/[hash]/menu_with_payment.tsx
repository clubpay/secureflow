/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import Menu from 'views/Menu/Menu';
import { ReactElement } from 'react';
import QlubLayout from '@/layout/QlubLayout';

function MenuWithPayment(props: any) {
    return <Menu {...props} />;
}

MenuWithPayment.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="small" logoSize="small">
            {page}
        </QlubLayout>
    );
};

export default MenuWithPayment;
