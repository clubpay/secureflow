/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import { ReactElement } from 'react';
import Invoice from '@/views/Bill/Invoice';
import QlubLayout from '@/layout/QlubLayout';

// Invoice.getLayout = function getLayout(page: ReactElement) {
//     return (
//         <RefreshContextProvider>
//             <LayoutCompact showBackIcon pullable>
//                 {page}
//             </LayoutCompact>
//         </RefreshContextProvider>
//     );
// };

function QSRCheckout(props: any) {
    return <Invoice {...props} />;
}

QSRCheckout.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="compact" logoSize="small" hideFooter pullable borderBottom>
            {page}
        </QlubLayout>
    );
};

export default QSRCheckout;
