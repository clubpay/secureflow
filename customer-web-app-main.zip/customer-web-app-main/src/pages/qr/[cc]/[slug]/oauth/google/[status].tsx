import { useEffect } from 'react';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { getRedirection } from '@clubpay/customer-common-module/src/component/Login/DataManager/utils';
import SplashLegacy from '@clubpay/customer-common-module/src/component/SplashLegacy';

interface IOauthParam {
    status: string;
    access: string;
    refresh: string;
    newUser: boolean;
}

const GoogleOAuth = () => {
    const { query, push } = useQlubRouter();
    const { storeAuthToken, setIsNewUserStorage } = useAuth();
    const { status, access, refresh, newUser } = query as unknown as IOauthParam;

    useEffect(() => {
        if (status === 'success') {
            setIsNewUserStorage(newUser);
            storeAuthToken({ access, refresh });
        }

        const redirection = getRedirection();

        if (redirection) {
            push(redirection);
        }
    }, [status, access, refresh]);

    return (
        <div
            style={{
                position: 'fixed',
                top: 0,
                left: 0,
                bottom: 0,
                right: 0,
                zIndex: 999999,
            }}
        >
            <SplashLegacy />;
        </div>
    );
};

export default GoogleOAuth;
