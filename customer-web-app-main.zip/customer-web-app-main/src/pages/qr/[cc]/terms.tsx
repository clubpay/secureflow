/*
    Creation Time: 2021 - Oct - 30
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import { ReactElement } from 'react';
import QlubLayout from '@/layout/QlubLayout';
import Markdown from '@/views/Bill/Terms';
import PageTitle from '@/components/Common/PageTitle';

Markdown.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="compact" title={<PageTitle />}>
            {page}
        </QlubLayout>
    );
};

export default Markdown;
