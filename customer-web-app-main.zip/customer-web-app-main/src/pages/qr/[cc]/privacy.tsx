/*
    Creation Time: 2021 - Oct - 30
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import PageTitle from '@/components/Common/PageTitle';
import QlubLayout from '@/layout/QlubLayout';
import Markdown from '@/views/Bill/Static/markdown';
import privacyData from '@/views/Bill/Static/markdown/privacy';
import { countries } from '@clubpay/customer-common-module/src/const';
import { ReactElement } from 'react';

Markdown.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="compact" title={<PageTitle />}>
            {page}
        </QlubLayout>
    );
};

export default Markdown;

export async function getStaticPaths() {
    return {
        paths: countries.map((cc) => ({
            params: {
                cc,
            },
        })),
        fallback: false,
    };
}

export async function getStaticProps() {
    return {
        props: {
            title: 'Privacy and Policy',
            content: privacyData,
        },
    };
}
