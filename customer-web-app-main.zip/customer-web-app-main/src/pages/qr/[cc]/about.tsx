/*
    Creation Time: 2021 - Oct - 30
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import Markdown from '@/views/Bill/Static/markdown';
import aboutData from '@/views/Bill/Static/markdown/about';
import { countries } from '@clubpay/customer-common-module/src/const';

export default Markdown;

export async function getStaticPaths() {
    return {
        paths: countries.map((cc) => ({
            params: {
                cc,
            },
        })),
        fallback: false,
    };
}

export async function getStaticProps() {
    return {
        props: {
            title: 'About Us',
            content: aboutData,
        },
    };
}
