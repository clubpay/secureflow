import PageTitle from '@/components/Common/PageTitle';
import withAuth from '@/components/Common/RouteProtector';
import QlubLayout from '@/layout/QlubLayout';
import Receipt from '@/views/Receipt/details';
import { ReactElement } from 'react';

Receipt.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout
            variant="compact"
            title={<PageTitle />}
            hideVendorTitle
            hideVendorLogo
            hideMenu
            forceTitle
            titleFullWidth
            withBack
            hideFooter
            pullable={false}
            key="receipt-details"
        >
            {page}
        </QlubLayout>
    );
};

export default withAuth(Receipt);
