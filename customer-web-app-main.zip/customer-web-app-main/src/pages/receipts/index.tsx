import { ReactElement } from 'react';
import Receipts from '@/views/Receipt/receipts';
import QlubLayout from '@/layout/QlubLayout';
import PageTitle from '@/components/Common/PageTitle';
import withAuth from '@/components/Common/RouteProtector';

Receipts.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout
            variant="compact"
            title={<PageTitle />}
            hideVendorTitle
            hideVendorLogo
            hideMenu
            forceTitle
            titleFullWidth
            withBack
            hideFooter
            key="receipt-list"
        >
            {page}
        </QlubLayout>
    );
};

export default withAuth(Receipts);
