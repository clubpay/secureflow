import { useEffect } from 'react';

function diff(list: string[], newList: string[]) {
    let idx = 0;
    let newIdx = 0;
    const addedIdx: number[] = [];
    const removedIdx: number[] = [];
    // eslint-disable-next-line no-constant-condition
    while (true) {
        if (list[idx] === newList[newIdx]) {
            idx++;
            newIdx++;
        } else {
            let j = newIdx + 1;
            // eslint-disable-next-line no-constant-condition
            while (true) {
                if (list[idx] === newList[j]) {
                    removedIdx.push(newIdx);
                    break;
                } else {
                    addedIdx.push(newIdx);
                }
                j++;
            }
        }
        if (list.length <= idx + 1) {
            break;
        }
    }
    return [addedIdx, removedIdx];
}

export default function Test() {
    useEffect(() => {
        console.log(diff([], []));
    }, []);
    return 'test';
}
