/*
    Creation Time: 2021 - Oct - 30
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import Markdown from '@/views/Bill/Terms';
import termsData from '@/views/Bill/Static/markdown/terms';

export default Markdown;

export async function getStaticProps() {
    return {
        props: {
            title: 'Terms and Conditions',
            content: termsData,
        },
    };
}
