import PageTitle from '@/components/Common/PageTitle';
import QlubLayout from '@/layout/QlubLayout';
import Venues from '@/views/Loyalty/Venues/seo';
import { ReactElement } from 'react';

Venues.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout
            variant="compact"
            title={<PageTitle />}
            forceTitle
            titleFullWidth
            withBack={typeof document !== 'undefined' && document.referrer !== ''}
            hideFooter
            key="venues-short"
        >
            {page}
        </QlubLayout>
    );
};

export default Venues;
