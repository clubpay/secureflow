/*
    Creation Time: 2022 - Aug - 1
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import StaticMenu from '@/views/StaticMenu/Static';

export default StaticMenu;

const links = [
    {
        title: 'Wine and Drinks Menu',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/06/TB-drinks.pdf',
    },
    {
        title: 'Breakfast 8AM – 11AM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/Breakfast-TB-Digital.pdf',
    },
    {
        title: 'Lunch 11AM – 4PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/05/MMTB-Daytime-Menu-10522.pdf',
    },
    {
        title: 'Afternoon 4PM – 5.30PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/Afternoon-TB-Digital.pdf',
    },
    {
        title: 'Dinner 5.30PM – 10:30PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/08/Dinner-TB-Digital-25-mac-and-cheese-32-tartare.pdf',
    },
    {
        title: 'Brunch (Sat – Sun – PH) 8AM – 4PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/Brunch-TB-Digital.pdf',
    },
];

export async function getStaticProps() {
    return {
        props: {
            links,
            socials: [],
        },
    };
}
