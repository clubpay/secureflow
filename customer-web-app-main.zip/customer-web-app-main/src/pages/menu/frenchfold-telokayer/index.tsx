/*
    Creation Time: 2022 - Aug - 1
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import StaticMenu from '@/views/StaticMenu/Static';

export default StaticMenu;

const links = [
    {
        title: 'Wine and Drinks Menu',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/FFTA-Drinks-DigitalV2.pdf',
    },
    {
        title: 'Breakfast 8AM – 11AM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/FFTA-Breakfast-digital.pdf',
    },
    {
        title: 'Lunch 11AM – 4PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/FFTA-Daytime-digital-29-7-22.pdf',
    },
    {
        title: 'Afternoon 4PM – 5.30PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/FFTA-Afternoon-digital.pdf',
    },
    {
        title: 'Dinner 5.30PM – 10:30PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/FFTA-Evening-Digital.pdf',
    },
    {
        title: 'Brunch (Sat – Sun – PH) 8AM – 4PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/FFTA-Brunch-digital.pdf',
    },
];

export async function getStaticProps() {
    return {
        props: {
            links,
            socials: [],
        },
    };
}
