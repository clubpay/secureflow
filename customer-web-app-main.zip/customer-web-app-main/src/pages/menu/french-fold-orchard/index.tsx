/*
    Creation Time: 2022 - Aug - 1
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import MenuStatic from '@/views/StaticMenu/Static';

export default MenuStatic;

const links = [
    {
        title: 'Wine and Drinks',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/FFPR-Drinks-Digital.pdf',
    },
    {
        title: 'Breakfast 9AM – 11AM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/FFPR-breakfast-digital-1.pdf',
    },
    {
        title: 'Lunch 11AM – 3PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/08/FFPR-Lunch-digital-1.pdf',
    },
    {
        title: 'Afternoon 3PM – 5:30PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/FFPR-Afternoon-digital-1.pdf',
    },
    {
        title: 'Dinner 5:30PM-10:30PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/08/FFPR-Evening-digital-2.pdf',
    },
    {
        title: 'Brunch Weekends-PH 9AM – 4PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/FFPR-BRUNCH-digital-1.pdf',
    },
];

export async function getStaticProps() {
    return {
        props: {
            links,
            socials: [],
        },
    };
}
