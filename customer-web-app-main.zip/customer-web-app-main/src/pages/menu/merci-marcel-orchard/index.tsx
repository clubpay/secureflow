/*
    Creation Time: 2022 - Aug - 1
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import MenuStatic from '@/views/StaticMenu/Static';

export default MenuStatic;

const links = [
    {
        title: 'Wine and Drinks Menu',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/PR-Drinks-Menu-Digital-2.pdf',
    },
    {
        title: 'Breakfast 8AM – 11AM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/PR-Breakfast-menu-Digital.pdf',
    },
    {
        title: 'Lunch 11AM – 4PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/PR-Daytime-Menu-Digital.pdf',
    },
    {
        title: 'Afternoon 4PM – 6PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/PR-Afternoon-Menu-Digital.pdf',
    },
    {
        title: 'Dinner 6PM – 10:30PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/PR-Dinner-Menu-Digital.pdf',
    },
    {
        title: 'Brunch (Sat – Sun – PH) 8AM – 4PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/PR-Brunch-Menu-Digital.pdf',
    },
];

export async function getStaticProps() {
    return {
        props: {
            links,
            socials: [],
        },
    };
}
