import MenuStatic from '@/views/StaticMenu/Static';

export default MenuStatic;

const links = [
    {
        title: 'Online Menu',
        link: 'https://www.zaytinya.ae/menu/abudhabi/en-US',
        noNewTab: true,
    },
    {
        title: 'Al Seef Menu',
        link: 'https://www.zaytinya.ae/alseefmenu.pdf',
    },
    {
        title: 'Bawadi Menu',
        link: 'https://www.zaytinya.ae/bawadimenu.pdf',
    },
];

const socials = [
    {
        link: 'https://www.facebook.com/ZaytinyaME',
        label: '@ZaytinyaME facebook',
        icon: 'facebook',
    },
    {
        link: 'https://www.instagram.com/zaytinyame/',
        label: '@zaytinyame instagram',
        icon: 'instagram',
    },
];

export async function getStaticProps() {
    return {
        props: {
            links,
            socials,
        },
    };
}
