/*
    Creation Time: 2022 - Aug - 1
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import MenuStatic from '@/views/StaticMenu/Static';

export default MenuStatic;

const links = [
    {
        title: 'Wine and Drinks Menu',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/CS-Drinks-menu-digital-29.07.pdf',
    },
    {
        title: 'Breakfast 8AM – 11AM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/CS-Breakfast-digital-1.pdf',
    },
    {
        title: 'Lunch 11AM – 4PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/CS-Daytime-n-Setlunch.pdf',
    },
    {
        title: 'Afternoon 4PM – 6PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/CS-Afternoon-digital.pdf',
    },
    {
        title: 'Dinner 6PM – 10:30P',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/CS-Dinner-digital.n.n.n.pdf',
    },
    {
        title: 'Brunch (Sat – Sun – PH) 8AM – 4PM',
        link: 'https://mercimarcelgroup.com/wp-content/uploads/2022/07/CS-Brunch-menu-digital.pdf',
    },
];

export async function getStaticProps() {
    return {
        props: {
            links,
            socials: [],
        },
    };
}
