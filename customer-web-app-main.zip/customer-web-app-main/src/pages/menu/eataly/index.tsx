/*
    Creation Time: 2022 - Aug - 1
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import MenuStatic from '@/views/StaticMenu/Static';

export default MenuStatic;

const links = [
    {
        title: 'La Cucina Menu',
        link: 'https://drive.google.com/file/d/1ARs5vGrMwe2fKjLRZSZsQV0WAiYX05g7/view?usp=sharing',
    },
    {
        title: 'La Cucina Menu ( Arabic )',
        link: 'https://drive.google.com/file/d/17OITutsFgtXmqDbrqjELhhDWgqFjn2Tj/view?usp=sharing',
    },
    {
        title: 'Dessert Menu',
        link: 'https://drive.google.com/file/d/1-gHYO0URbyDjxNU_d8g6f08H6zFfxcyZ/view?usp=sharing',
    },
    {
        title: 'La Scuola di Eataly',
        link: 'https://drive.google.com/file/d/1gPoaxJjj4SthRrdvP768_h0fm64gmFMa/view?usp=sharing',
    },
];

const socials = [
    {
        link: 'https://www.facebook.com/EatalyArabia',
        label: '@EatalyUAE facebook',
        icon: 'facebook',
    },
    {
        link: 'https://instagram.com/eatalyarabia',
        label: '@EatalyUAE instagram',
        icon: 'instagram',
    },
];

export async function getStaticProps() {
    return {
        props: {
            links,
            socials,
        },
    };
}
