import Receipt from '@/views/Bill/Receipt';
import { ReactElement } from 'react';
import QlubLayout from '@/layout/QlubLayout';

Receipt.getLayout = function getLayout(page: ReactElement) {
    return (
        <QlubLayout variant="compact" key="softpos-receipt" titleFullWidth>
            {page}
        </QlubLayout>
    );
};

export default Receipt;
