/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

export default function Custom404() {
    const { t } = useTranslation('common');
    return <h1>{t('404 - Page Not Found')}</h1>;
}
