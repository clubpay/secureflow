/*
    Creation Time: 2021 - Oct - 30
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import Markdown from '@/views/Bill/Static/markdown';
import privacyData from '@/views/Bill/Static/markdown/privacy';

export default Markdown;

export async function getStaticProps() {
    return {
        props: {
            title: 'Privacy and Policy',
            content: privacyData,
        },
    };
}
