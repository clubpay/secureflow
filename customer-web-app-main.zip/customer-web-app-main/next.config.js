const path = require('path');
// eslint-disable-next-line import/order
const runtimeCaching = require('./pwa.config');

const isDev = process.env.NODE_ENV === 'development';

const withPWA = require('next-pwa')({
    dest: 'public',
    disable: isDev,
    runtimeCaching,
});

const { withSentryConfig } = require('@sentry/nextjs');

const settings = {
    ...(!isDev ? { output: 'export' } : {}),
    transpilePackages: [
        'next-export-i18n',
        'i18next',
        '@clubpay/customer-common-module',
        '@clubpay/customer-payment-module',
        '@clubpay/loyalty',
        '@mui/icons-material',
        '@mui/material-nextjs',
        '@mui/material',
        '@mui/lab',
        '@clubpay/payment-kit',
    ],
    sassOptions: {
        includePaths: [path.join(__dirname, 'styles')],
    },
    webpack: {
        resolve: {
            aliasFields: ['module'],
        },
    },
    serverRuntimeConfig: {
        httpApiURL: process.env.NEXT_PUBLIC_API_HTTP_URL,
        wsApiURL: process.env.NEXT_PUBLIC_API_WS_URL,
        recaptchaKey: process.env.NEXT_PUBLIC_RECAPTCHA,
    },
    publicRuntimeConfig: {
        httpApiURL: process.env.NEXT_PUBLIC_API_HTTP_URL,
        wsApiURL: process.env.NEXT_PUBLIC_API_WS_URL,
        recaptchaKey: process.env.NEXT_PUBLIC_RECAPTCHA,
    },
    eslint: {
        // Warning: This allows production builds to successfully complete even if
        // your project has ESLint errors.
        // ignoreDuringBuilds: true,
    },
    typescript: {
        // !! WARN !!
        // Dangerously allow production builds to successfully complete even if
        // your project has type errors.
        // !! WARN !!
        ignoreBuildErrors: true,
    },
    ...(isDev && {
        async rewrites() {
            return [
                {
                    source: '/api/:path*',
                    destination: `${process.env.NEXT_PUBLIC_API_HTTP_URL}/:path*`,
                },
            ];
        },
    }),
};

const moduleExports = isDev ? settings : withPWA(settings);
// Make sure adding Sentry options is the last code to run before exporting, to
// ensure that your source maps include changes from all other Webpack plugins
module.exports =
    process.env.SENTRY_DISABLE === 'true'
        ? moduleExports
        : withSentryConfig(moduleExports, {
              // Additional config options for the Sentry Webpack plugin. Keep in mind that
              // the following options are set automatically, and overriding them is not
              // recommended:
              //   release, url, org, project, authToken, configFile, stripPrefix,
              //   urlPrefix, include, ignore
              org: process.env.SENTRY_ORG,
              project: process.env.SENTRY_PROJECT,
              authToken: process.env.SENTRY_AUTH_TOKEN,
              silent: true, // Suppresses all logs
              hideSourceMaps: true,
              // For all available options, see:
              // https://github.com/getsentry/sentry-webpack-plugin#options.
          });
