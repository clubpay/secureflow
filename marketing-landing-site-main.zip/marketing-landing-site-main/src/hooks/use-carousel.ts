"use client"

import {
   CarouselApi,
} from "@/components/ui/carousel";
import { useCallback, useEffect, useState } from "react";

type UseCarouselType = {
   selectedIndex: number
   scrollSnaps: number[]
   onSnapButtonClick: (index: number) => void
}

export const useCarousel = (
   emblaApi: CarouselApi | undefined
): UseCarouselType => {
   const [selectedIndex, setSelectedIndex] = useState(0)
   const [scrollSnaps, setScrollSnaps] = useState<number[]>([])

   const onSnapButtonClick = useCallback(
      (index: number) => {
         if (!emblaApi) return
         emblaApi.scrollTo(index)
      },
      [emblaApi]
   )

   const onInit = useCallback((emblaApi: CarouselApi) => {
      if (!emblaApi) return
      setScrollSnaps(emblaApi?.scrollSnapList())
   }, [])

   const onSelect = useCallback((emblaApi: CarouselApi) => {
      if (!emblaApi) return
      setSelectedIndex(emblaApi.selectedScrollSnap())
   }, [])

   useEffect(() => {
      if (!emblaApi) return

      onInit(emblaApi)
      onSelect(emblaApi)
      emblaApi.on('reInit', onInit).on('reInit', onSelect).on('select', onSelect)
   }, [emblaApi, onInit, onSelect])

   return {
      selectedIndex,
      scrollSnaps,
      onSnapButtonClick
   }
}