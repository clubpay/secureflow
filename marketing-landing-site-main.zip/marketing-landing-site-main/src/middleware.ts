import { NextRequest, NextResponse } from "next/server";
import { SOURCES, DEFAULT_SOURCE } from "./lib/constants";

const sources = SOURCES
const defaultSource = DEFAULT_SOURCE

export function middleware(request: NextRequest) {
   // Check if there is any source in the pathname
   const { pathname } = request.nextUrl
   const pathnameHasSource = sources.some(
      (source) => pathname.startsWith(`/${source}/`) || pathname === `/${source}`
   )

   if (pathnameHasSource) return

   // Rewrite if there is no source
   request.nextUrl.pathname = `/${defaultSource}${pathname}`
   // e.g. incoming request is /
   // The new URL is now /none
   return NextResponse.rewrite(request.nextUrl)
}

export const config = {
   matcher: [
      "/((?!api/|_next/|_static/|_vercel|[\\w-]+\\.\\w+).*)",
   ],
}