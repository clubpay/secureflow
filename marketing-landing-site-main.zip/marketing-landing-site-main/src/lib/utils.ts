import { type ClassValue, clsx } from "clsx"
import { ReadonlyURLSearchParams } from "next/navigation";
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function updateSearchParam(searchParams: ReadonlyURLSearchParams, param: string, value: string) {
  const currentSearchParams = new URLSearchParams(Array.from(searchParams.entries()));
  currentSearchParams.set(param, value);

  return currentSearchParams;
}

export function sourcedPath(path: string, source: string | string[]) {
  if (Array.isArray(source)) {
    return path;
  }

  const isDefaultSource = source === "none";

  if (isDefaultSource) {
    return path;
  }

  return `/${source}${path}`;
}