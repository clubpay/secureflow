import { ComboboxOptionsGroup } from "@/components/ui/combobox";

export const POS: ComboboxOptionsGroup[] = [
   {
      heading: "POS",
      options: [
         { value: "Surge POS", label: "Surge POS" },
         { value: "Micros Simphony", label: "Micros Simphony" },
         { value: "Sapaad", label: "Sapaad" },
         { value: "Squirrel", label: "Squirrel" },
         { value: "iiko", label: "iiko" },
         { value: "Syrve", label: "Syrve" },
         { value: "Micros 3700", label: "Micros 3700" },
         { value: "Foodics", label: "Foodics" },
         { value: "Posist", label: "Posist" },
         { value: "Omega", label: "Omega" },
         { value: "Revel", label: "Revel" },
         { value: "Bimpos", label: "Bimpos" },
         { value: "Touche", label: "Touche" },
         { value: "Totpos", label: "Totpos" },
         { value: "Lingaros", label: "Lingaros" },
         { value: "Tevalis", label: "Tevalis" },
         { value: "Quadranet", label: "Quadranet" },
         { value: "Odoo", label: "Odoo" },
         { value: "Lightspeed", label: "Lightspeed" },
         { value: "Kitopi", label: "Kitopi" },
         { value: "LS Retail", label: "LS Retail" },
         { value: "Grubtech", label: "Grubtech" },
         { value: "Dimensions", label: "Dimensions" },
         { value: "Sentinel", label: "Sentinel" },
         { value: "G5", label: "G5" },
         { value: "Tissl", label: "Tissl" },
         { value: "Success Numbers", label: "Success Numbers" },
         { value: "Compucash", label: "Compucash" },
         { value: "PixelPoint", label: "PixelPoint" },
         { value: "PetPooja", label: "PetPooja" },
         { value: "Aldelo", label: "Aldelo" },
         { value: "NCR", label: "NCR" },
         { value: "Lavu", label: "Lavu" },
         { value: "ePosNow", label: "ePosNow" },
         { value: "xPient", label: "xPient" },
         { value: "Loyverse", label: "Loyverse" },
         { value: "Megapos", label: "Megapos" },
         { value: "Shiji Infrasys", label: "Shiji Infrasys" },
         { value: "Microsoft NAV", label: "Microsoft NAV" },
         { value: "Easy Resto", label: "Easy Resto" },
         { value: "Armada", label: "Armada" },
         { value: "Cratis", label: "Cratis" },
         { value: "Limetray", label: "Limetray" },
         { value: "Dineware", label: "Dineware" },
         { value: "Maitre'D", label: "Maitre'D" },
         { value: "Agilisys", label: "Agilisys" },
      ],
   },
];

export const REVENUE_INTERVALS: { value: string, gtmValue: number }[] = [
   {
      value: "Under 100,000 AED/mo",
      gtmValue: 0
   },
   {
      value: "100,000 - 200,000 AED/mo",
      gtmValue: 10
   },
   {
      value: "200,000 - 500,000 AED/mo",
      gtmValue: 50
   },
   {
      value: "Over 500,000 AED/mo",
      gtmValue: 250
   }
];

// These are the optional sources that are used for the source parameter in the path
export const SOURCES = ["uae-referral", "m-home"]

export const DEFAULT_SOURCE = "none"