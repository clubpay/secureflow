import { z } from 'zod'

export const BookDemoSchema = z.object({
   "pos": z.object({
      name: z.string().min(2, {
         message: "POS name must be at least 2 characters.",
      }),
   }),
   "monthly-revenue": z.object({
      interval: z.string().min(1, {
         message: "Monthly revenue is required."
      }),
   }),
   "contact": z.object({
      firstName: z.string().min(1, {
         message: "First name is required.",
      }),
      lastName: z.string().min(1, {
         message: "Last name is required.",
      }),
      organization: z.string().min(1, {
         message: "Organization is required.",
      }),
      email: z.string().email({
         message: "Invalid email address.",
      }).min(3, {
         message: "Email must be at least 3 characters.",
      }),
      phone: z.string().min(1, {
         message: "Phone number is required.",
      }),
      isRestaurant: z.enum(["true", "false"], {
         required_error: "Please select an option.",
      }),
   })
})

export type BookDemoSchemaType = z.infer<typeof BookDemoSchema>;