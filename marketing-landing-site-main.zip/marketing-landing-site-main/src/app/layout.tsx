import type { Metadata, Viewport } from "next";
import "@/styles/globals.css";
import "@/styles/marquee.css";
import { cn } from "@/lib/utils";
import { Plus_Jakarta_Sans, Poppins } from "next/font/google";
import { GoogleTagManager } from "@next/third-parties/google";

export const metadata: Metadata = {
  title: "Contactless payment for Restaurants - Qlub",
  description:
    "Qlub is the fastest, most secure form of digital menu & contactless payment for customers at restaurants, clubs & lounges.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  // Also supported by less commonly used
  // interactiveWidget: 'resizes-visual',
};

const poppins = Poppins({
  subsets: ["latin"],
  display: "swap",
  weight: ["400", "500", "600"],
  variable: "--font-poppins",
});

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-plus-jakarta-sans",
});

const gtmId = process.env.GOOGLE_TAG_MANAGER_ID;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      {gtmId && <GoogleTagManager gtmId={gtmId} />}
      <body
        className={cn(
          "min-h-screen bg-background font-sans font-medium antialiased",
          poppins.variable,
          plusJakartaSans.variable,
        )}
      >
        {children}
      </body>
    </html>
  );
}
