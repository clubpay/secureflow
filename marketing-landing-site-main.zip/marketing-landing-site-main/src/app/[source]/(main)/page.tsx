import { FeatureCarousel } from "@/components/home/features-carousel";
import { Hero } from "@/components/home/hero";
import { HeroMarquee } from "../../../components/home/hero/marquee";
import { Scroller } from "@/components/home/scroller";
import { CTA } from "@/components/home/cta";
import { Explainer } from "@/components/home/explainer";
import { Testimonials } from "@/components/home/testimonials";

export default function Home() {
  return (
    <main>
      <Hero />
      <HeroMarquee />
      <FeatureCarousel />
      <Scroller />
      <CTA
        heading="Get started today"
        paragraph="Request a demo to discover how Qlub can help you."
        items={[
          {
            icon: <>&#127462;&#127466;</>,
            text: "Trusted by Top Restaurants Across UAE",
          },
          { icon: <>&#128274;</>, text: "100% safe and secure payments" },
        ]}
        className="md:mt-16"
      />
      <Explainer />
      <Testimonials />
      <CTA
        heading="Have a taste of Qlub"
        paragraph="Request a demo to discover how Qlub can help you."
        items={[
          {
            icon: <>&#x1F3C3;&#x200D;&#x2642;</>,
            text: "Go live in less than 48 hours after the Demo",
          },
          { icon: <>&#128222;</>, text: "We are available 24/7 for support" },
        ]}
      />
    </main>
  );
}
