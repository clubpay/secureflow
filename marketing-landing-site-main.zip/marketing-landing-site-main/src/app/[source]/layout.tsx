import { DEFAULT_SOURCE, SOURCES } from "@/lib/constants";

export async function generateStaticParams() {
  const sources = [...SOURCES, DEFAULT_SOURCE];

  return sources.map((source) => ({
    source,
  }));
}

export default function SourceLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return children;
}
