import { BookDemoForm } from "@/components/book-demo/form";
import { Loader2 } from "lucide-react";
import { Suspense } from "react";
import { Separator } from "@/components/ui/separator";

export default function BookDemoPage() {
  return (
    <main className="flex min-h-screen flex-col bg-purple-50">
      <div className="flex flex-1 justify-center py-32">
        <Suspense
          fallback={
            <div className="my-auto flex items-center justify-center text-electric-violet-700">
              <Loader2 className="size-8 animate-spin" />
            </div>
          }
        >
          <BookDemoForm />
        </Suspense>
      </div>
      <Separator className="mt-auto" />
    </main>
  );
}
