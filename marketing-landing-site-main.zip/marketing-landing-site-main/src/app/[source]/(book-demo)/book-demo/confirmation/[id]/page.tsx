import { Calendly } from "@/components/book-demo/confirmation/calendly";
import { BookDemoConfirmationHeader } from "@/components/book-demo/confirmation/header";
import { BookDemoConfirmationSocials } from "@/components/book-demo/confirmation/socials";
import { REVENUE_INTERVALS } from "@/lib/constants";
import { getSheetDataById } from "@/server/actions/google";
import { notFound } from "next/navigation";

export default async function BookDemoConfirmationPage({
  params,
}: {
  params: { id: string };
}) {
  const { id } = params;
  const data = await getSheetDataById(id);

  if (!data) return notFound();

  const [
    _id,
    date,
    organization,
    monthlyRevenue,
    pos,
    firstName,
    lastName,
    email,
    phone,
    isRestaurant,
    source,
  ] = data;

  const isHighRevenue = monthlyRevenue !== REVENUE_INTERVALS[0].value;
  const canBookMeeting = isHighRevenue && isRestaurant === "true";

  return (
    <main className="min-h-screen bg-purple-50 py-14 md:py-16">
      <div className="container max-w-4xl space-y-10 md:space-y-14">
        <BookDemoConfirmationHeader />
        {/* {canBookMeeting && <Calendly />} */}
        <BookDemoConfirmationSocials />
      </div>
    </main>
  );
}
