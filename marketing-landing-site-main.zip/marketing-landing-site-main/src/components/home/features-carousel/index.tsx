"use client";

import { motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import {
  Carousel,
  CarouselApi,
  CarouselContent,
  CarouselItem,
} from "@/components/ui/carousel";
import { useCarousel } from "@/hooks/use-carousel";
import { cn } from "@/lib/utils";

import Fade from "embla-carousel-fade";
import { Separator } from "@/components/ui/separator";
import { QlubIcon } from "@/svgs/icon";
import { BackgroundVideoPlayer } from "@/components/common/background-video";

type Feature = {
  label: string;
  heading: string;
  paragraph: string;
  video: string;
};

let features: Feature[] = [
  {
    label: "Menu",
    heading: "Instant Menu Access",
    paragraph:
      "Guests can access your full menu instantly by scanning a QR code, making it easy to explore dish details.",
    video: "https://jshk8cf4q0putns8.public.blob.vercel-storage.com/Menu.webm",
  },
  {
    label: "Tip",
    heading: "Triple Your Staff's Tips",
    paragraph:
      "Encourage more generous tipping by allowing guests to tip in a few clicks without awkwardness.",
    video: "https://jshk8cf4q0putns8.public.blob.vercel-storage.com/Tips.webm",
  },
  {
    label: "Pay",
    heading: "Self-Service Checkout",
    paragraph:
      "Guests enjoy the convenience of settling their bill right from their phone, utilizing their preferred payment methods.",
    video: "https://jshk8cf4q0putns8.public.blob.vercel-storage.com/Pay.webm",
  },
];

export function FeatureCarousel() {
  const [api, setApi] = useState<CarouselApi>();
  const { onSnapButtonClick, scrollSnaps, selectedIndex } = useCarousel(api);

  return (
    <section className="mx-auto my-16 md:my-32">
      <div className="container">
        <Header />
        <Separator className="my-9 md:my-16" />
      </div>
      <div className="container max-sm:px-4">
        <div className="rounded-xl bg-purple-50 lg:py-20">
          <div className="mx-auto max-w-[72rem] lg:px-12">
            <div className="rounded-lg px-5 py-14 lg:rounded-none lg:p-0">
              <Carousel
                setApi={setApi}
                plugins={[Fade()]}
                opts={{
                  watchDrag: false,
                }}
              >
                <CarouselContent>
                  {features.map((feature, index) => (
                    <CarouselItem
                      key={index}
                      className="flex flex-col justify-end"
                    >
                      <CarouselItemContent
                        feature={feature}
                        index={index}
                        selectedIndex={selectedIndex}
                      />
                    </CarouselItem>
                  ))}
                </CarouselContent>
              </Carousel>
              <CarouselButtons
                onSnapButtonClick={onSnapButtonClick}
                selectedIndex={selectedIndex}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Header() {
  return (
    <div className="space-y-4 md:space-y-4">
      <QlubIcon />
      <h2 className="text-3xl leading-tight tracking-[-0.04em] md:text-4xl lg:text-5xl lg:leading-[1.1]">
        Customer Experience <br />
        Starts with a Scan
      </h2>
      <p className="max-w-2xl text-lg text-primary/85 md:text-xl md:leading-normal">
        Step into the future of dining with technology that speeds up payments
        and enriches guest interactions.
      </p>
    </div>
  );
}

function CarouselItemContent({
  feature,
  index,
  selectedIndex,
}: {
  feature: Feature;
  index: number;
  selectedIndex: number;
}) {
  const ref = useRef<HTMLVideoElement>(null);

  if (ref.current) {
    if (index !== selectedIndex) {
      ref.current.pause();
      ref.current.currentTime = 0;
    } else {
      ref.current.play();
    }
  }

  return (
    <div className="space-y-9 pb-8 lg:flex lg:items-center lg:gap-10 lg:space-y-0">
      <div className="space-y-1.5 text-center lg:max-w-[28rem] lg:pt-20 lg:text-left">
        <h3 className="text-[1.6rem] font-medium leading-tight tracking-[-0.04em] md:text-4xl lg:text-4xl lg:leading-[1.1] xl:text-[2.5rem]">
          {feature.heading}
        </h3>
        <p className="mx-auto max-w-lg text-[0.95rem] leading-[1.4] text-primary/80 sm:text-base md:text-lg">
          {feature.paragraph}
        </p>
      </div>
      <BackgroundVideoPlayer
        url={feature.video}
        className="relative mx-auto !aspect-square overflow-hidden rounded-xl bg-purple-50 lg:mr-0 lg:max-w-md xl:max-w-lg"
        ref={ref}
      />
    </div>
  );
}

function CarouselButtons({
  onSnapButtonClick,
  selectedIndex,
}: {
  onSnapButtonClick: (index: number) => void;
  selectedIndex: number;
}) {
  return (
    <div className="flex justify-center gap-4 lg:ml-auto lg:max-w-md xl:max-w-lg">
      {features.map((feature, index) => (
        <button
          key={index}
          className={cn(
            "relative rounded-full border-2 border-electric-violet-600 px-7 py-2.5 text-sm font-medium text-electric-violet-800 transition delay-50",
            {
              "text-purple-50": selectedIndex === index,
            },
          )}
          onClick={() => onSnapButtonClick(index)}
        >
          {selectedIndex === index && (
            <motion.span
              layoutId="bubble"
              className="absolute inset-0 z-0 rounded-full bg-electric-violet-600"
              transition={{ type: "spring", bounce: 0, duration: 0.5 }}
            />
          )}
          <span className="relative z-10">{feature.label}</span>
        </button>
      ))}
    </div>
  );
}
