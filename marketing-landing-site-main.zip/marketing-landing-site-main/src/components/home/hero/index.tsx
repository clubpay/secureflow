import React from "react";
import { CTAForm } from "../../common/cta-form";
import { ValueProposition } from "@/components/common/value-props";
import { Separator } from "@/components/ui/separator";
import { BackgroundVideo } from "@/components/common/background-video";

export function Hero() {
  return (
    <section className="space-y-8 bg-purple-50 pt-24 md:space-y-16 lg:pt-16">
      <div className="container flex max-w-7xl flex-col items-center space-y-4 text-center max-sm:px-6 lg:flex-row lg:justify-start lg:text-left">
        <div className="space-y-4 md:space-y-6">
          <Header />
          <CTAForm align="left" />
          <ValueProposition
            items={[
              { icon: <>&#128274;</>, text: "100% safe and secure payments" },
              {
                icon: <>&#127462;&#127466;</>,
                text: "The #1 choice in the UAE",
              },
            ]}
            direction="horizontal"
            align="left"
          />
        </div>
        <div className="max-w-[80%] lg:basis-3/5">
          <Video />
        </div>
      </div>
      <Separator />
    </section>
  );
}

function Header() {
  return (
    <div className="space-y-3">
      <h1 className="text-[2.5rem] font-semibold leading-[1.05] tracking-[-0.04em] md:text-5xl md:font-semibold xl:text-6xl xl:text-[3.9rem] xl:leading-[1.03]">
        Turn Tables Faster
        <br />
        with QR Payments
      </h1>
      <p className="mx-auto max-w-2xl text-sm leading-[1.4] text-primary/80 sm:text-lg lg:leading-snug">
        Qlub enables guests to view and pay restaurant bills in seconds. Boost
        tips, reviews, and overall revenue — works with your current POS.
      </p>
    </div>
  );
}

function Video() {
  return (
    <BackgroundVideo
      fileName="Hero.webm"
      className="relative mx-auto !aspect-square !w-full max-w-md overflow-hidden rounded-xl lg:max-w-none"
    />
  );
}
