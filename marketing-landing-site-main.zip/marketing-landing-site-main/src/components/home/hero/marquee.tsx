import React from "react";
import { Marquee } from "../../ui/marquee";
import { AlSafadi } from "@/svgs/home/AlSafadi";
import { LPM } from "@/svgs/home/LPM";
import { MamaEsh } from "@/svgs/home/MamaEsh";
import { Nandos } from "@/svgs/home/Nandos";
import { Paul } from "@/svgs/home/Paul";

export function HeroMarquee() {
  return (
    <section className="space-y-7 bg-purple-50 py-6 md:py-7 lg:space-y-6 lg:py-8">
      <div className="container text-center font-semibold text-primary/80">
        <p className="font-semibold lg:text-lg">
          Trusted by 1000+ restaurants and hotels
        </p>
      </div>
      <Marquee className="select-none" speed={0.4} direction="right">
        <div className="flex items-center gap-20 pl-20 md:gap-24">
          <AlSafadi className="block h-12 w-auto md:h-16" />
          <LPM className="block h-12 w-auto md:h-16" />
          <MamaEsh className="block h-12 w-auto md:h-16" />
          <Nandos className="block h-10 w-auto md:h-12" />
          <Paul className="block h-8 w-auto md:h-10" />
        </div>
      </Marquee>
    </section>
  );
}
