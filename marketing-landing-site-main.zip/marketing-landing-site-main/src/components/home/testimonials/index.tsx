import testimonialImage from "../../../../public/images/home/testimonials/testimonial-image.webp";
import testimonialLogo from "../../../../public/images/home/testimonials/testimonial-logo.png";
import Image from "next/image";

export function Testimonials() {
  return (
    <section className="mt-16 space-y-5 md:mt-32 md:space-y-12">
      <h2 className="container text-3xl leading-tight tracking-[-0.04em] md:text-4xl lg:text-5xl lg:leading-[1.1]">
        Top restaurants and hotels use Qlub
      </h2>
      <div className="container max-sm:px-4">
        <div className="rounded-xl bg-purple-50 px-6 py-12 text-center md:py-24">
          <div className="mb-4 md:mb-6">
            <Image
              src={testimonialLogo}
              alt={`Testimonial logo from Almayass`}
              className="mx-auto h-14 w-auto md:h-20"
            />
          </div>
          <blockquote className="mx-auto text-lg text-primary/90 md:max-w-3xl md:text-2xl md:leading-normal lg:text-3xl lg:leading-snug">
            &quot;Qlub has made it so easy for guests to make their payments. We
            saw an increase in efficiency of tables closed and customer
            satisfaction!&quot;
          </blockquote>
          <div className="mt-8 flex items-center justify-center gap-4 text-left md:mt-10 md:gap-6">
            <div>
              <div className="relative mx-auto size-16 overflow-hidden rounded-full md:size-24">
                <Image
                  src={testimonialImage}
                  alt="Testimonial image from Almayass"
                  className="object-cover"
                  sizes="(min-width: 1024px) 600px, 200px"
                  fill
                />
              </div>
            </div>
            <div className="md:text-xl">
              <h3>Restaurant manager</h3>
              <p>Ghadi Ghaoui</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
