import { cn } from "@/lib/utils";
import { BackgroundVideo } from "@/components/common/background-video";

type Step = {
  label: string;
  heading: string;
  paragraph: string;
  video: string;
};

let steps: Step[] = [
  {
    label: "Improve your operations",
    heading: "Always integrated and in-sync with your POS",
    paragraph:
      "Your guests will always see the most updated bill, automatically fetched from your POS.",
    video: "POS.webm",
  },
  {
    label: "Improve guest experience",
    heading: "Easy and slick bill splitting for your guests",
    paragraph:
      "Enable bill splitting equally, by items, or by amount to save time.",
    video: "PaySplit.webm",
  },
  {
    label: "Smarter tracking and reporting",
    heading: "Instant notifications for all bill payments",
    paragraph:
      "You'll always know when your guest have paid with options to receive notifications.",
    video: "Notifications.webm",
  },
];

export function Explainer() {
  return (
    <section>
      <Header />
      <div className="container space-y-7 max-sm:px-4 lg:space-y-12">
        {steps.map((step, index) => (
          <StepItem key={index} step={step} index={index} />
        ))}
      </div>
    </section>
  );
}

function Header() {
  return (
    <div className="container mb-16 space-y-4">
      <h2 className="text-3xl leading-tight tracking-[-0.04em] md:text-4xl lg:text-5xl lg:leading-[1.1]">
        Benefits to your guests,
        <br />
        restaurant and staff
      </h2>
      <p className="max-w-2xl text-lg leading-normal text-primary/85 md:text-xl">
        Every time a guest uses Qlub, you earn more than just revenue: more
        time, better reviews and greater tips.
      </p>
    </div>
  );
}

function StepItem({ step, index }: { step: Step; index: number }) {
  return (
    <div
      className={cn(
        "space-y-6 rounded-xl bg-purple-50 md:flex md:justify-between md:space-y-0",
        {
          "md:flex-row-reverse": index % 2 === 0,
        },
      )}
    >
      <div className="flex flex-col gap-6 p-6 pb-0 md:basis-1/2 md:p-10">
        <p className="flex items-center gap-3.5 font-medium text-purple-600">
          <span className="flex size-8 items-center justify-center rounded-full bg-purple-600 text-secondary">
            {index + 1}
          </span>
          {step.label}
        </p>
        <h3 className="max-w-md text-2xl leading-tight tracking-[-0.04em] sm:text-3xl md:text-2xl lg:text-4xl lg:leading-[1.2]">
          {step.heading}
        </h3>
        <p className="mt-auto max-w-md text-[0.9rem] text-primary/85 lg:text-[1.3rem] lg:leading-9">
          {step.paragraph}
        </p>
      </div>
      <BackgroundVideo
        fileName={step.video}
        className="mt-auto !aspect-square md:shrink-0 md:basis-1/2"
      />
    </div>
  );
}
