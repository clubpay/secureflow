import React from "react";
import ScrollerSection from "./section";
import { Separator } from "@/components/ui/separator";
import paymentsImage from "../../../../public/images/home/scroller/payments.jpg";

export function Scroller() {
  return (
    <section className="container">
      <Separator className="mb-8 md:mb-16" />
      <ScrollerSection
        heading="Drive Positive Feedback"
        paragraph="Encourage immediate guest reviews to enhance your restaurant's online presence and reputation, fostering a cycle of trust and new customer interest."
        video="Review.webm"
      />
      <Separator className="my-16" />
      <ScrollerSection
        heading="Save time for what matters"
        paragraph="No more waiting for menus, bills, or paper receipts. Let your guests enjoy their meal while your staff earns 3x more tips."
        illustrationComponent={
          <div className="flex aspect-square w-full shrink-0 flex-col justify-center space-y-4 rounded-xl bg-purple-50 p-[7.5%] md:basis-1/2 md:p-[3.4%] lg:max-w-lg">
            <h4 className="text-2xl md:text-3xl">Checkout</h4>
            <div className="space-y-5">
              <div className="space-y-2">
                <p className="font-medium">Before: 5-10 minutes</p>
                <div className="h-12 w-full rounded-md bg-muted-foreground/20" />
              </div>
              <div className="space-y-2">
                <p className="font-medium">Qlub: 10 seconds</p>
                <div className="h-12 w-[5%] rounded-md bg-electric-violet-700" />
              </div>
            </div>
          </div>
        }
      >
        <ul className="mt-5 space-y-2 text-sm text-primary/70 lg:text-base">
          <li className="flex items-center gap-2">
            <span className="size-5 rounded-full bg-muted-foreground/20 lg:size-6" />
            Before (Your Set-Up)
          </li>
          <li className="flex items-center gap-2">
            <span className="size-5 rounded-full bg-electric-violet-700 lg:size-6" />
            Qlub Set-Up
          </li>
        </ul>
      </ScrollerSection>
      <Separator className="my-16" />
      <ScrollerSection
        heading="Simplify payments"
        paragraph="Guests can choose to pay with Apple Pay, Google Pay, or any card."
        illustration={paymentsImage}
      />
      <Separator className="mt-8 md:mt-16" />
    </section>
  );
}
