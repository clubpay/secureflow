import { cn } from "@/lib/utils";
import Image, { StaticImageData } from "next/image";
import React from "react";
import { BackgroundVideo } from "@/components/common/background-video";

export default function ScrollerSection({
  heading,
  paragraph,
  className,
  children,
  illustration,
  illustrationComponent,
  video,
}: {
  heading: string;
  paragraph: string;
  className?: string;
  children?: React.ReactNode;
  illustration?: StaticImageData;
  illustrationComponent?: React.ReactNode;
  video?: string;
}) {
  return (
    <div
      className={cn(
        "md:flex md:items-stretch md:justify-between md:gap-10",
        className,
      )}
    >
      <div className="max-w-lg justify-between md:flex md:flex-col">
        <h3 className="mb-2 text-[1.75rem] font-medium leading-tight tracking-[-0.04em] lg:text-4xl lg:leading-[1.1]">
          {heading}
        </h3>
        <div className="mb-16 md:mb-0">
          <p className="text-[0.95rem] text-primary/85 md:text-lg xl:text-[1.4rem] xl:leading-9">
            {paragraph}
          </p>
          {children}
        </div>
      </div>

      {illustrationComponent}

      {illustration && (
        <div className="relative aspect-square w-full shrink-0 rounded-xl bg-purple-50 md:basis-1/2 lg:max-w-lg">
          <Image
            src={illustration}
            alt={heading}
            className="object-cover"
            fill
          />
        </div>
      )}
      {video && (
        <BackgroundVideo
          fileName={video}
          className="!aspect-square w-full shrink-0 overflow-hidden rounded-xl md:basis-1/2 lg:max-w-lg"
        />
      )}
    </div>
  );
}
