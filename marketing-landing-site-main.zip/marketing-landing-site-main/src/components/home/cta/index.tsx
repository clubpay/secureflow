import { CTAForm } from "@/components/common/cta-form";
import { ValueProposition } from "@/components/common/value-props";
import { cn } from "@/lib/utils";
import React from "react";

export function CTA({
  heading,
  paragraph,
  items,
  className,
}: {
  heading: string;
  paragraph: string;
  items: { icon: React.ReactNode; text: string }[];
  className?: string;
}) {
  return (
    <section
      className={cn(
        "container my-16 text-center max-sm:px-4 md:my-32",
        className,
      )}
    >
      <div className="space-y-5 rounded-xl bg-purple-50 px-5 py-12 md:space-y-6 md:px-6 md:py-32">
        <div className="space-y-1 max-sm:mx-auto">
          <h2 className="text-3xl font-medium leading-tight tracking-[-0.04em] md:text-4xl lg:text-5xl lg:leading-[1.1]">
            {heading}
          </h2>
          <p className="mx-auto max-w-72 text-[0.95rem] text-primary/85 sm:max-w-none md:text-xl">
            {paragraph}
          </p>
        </div>
        <CTAForm />
        <ValueProposition items={items} />
      </div>
    </section>
  );
}
