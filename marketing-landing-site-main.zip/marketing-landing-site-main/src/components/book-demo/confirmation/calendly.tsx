export function Calendly() {
  return (
    <div className="space-y-10">
      <div className="space-y-2">
        <h2 className="text-[1.4rem] leading-tight tracking-[-0.04em] md:text-2xl lg:leading-[1.1]">
          Prefer to book an online meeting?
        </h2>
        <p className="text-primary/80">
          If yes, feel free to schedule a time with one of our experts.
        </p>
      </div>

      <div className="overflow-hidden rounded-md">
        <iframe
          src={process.env.CALENDLY_URL}
          className="h-[49rem] w-full border-none sm:h-[60rem]"
        ></iframe>
      </div>
    </div>
  );
}
