export function BookDemoConfirmationHeader() {
  return (
    <div className="space-y-2 pt-16 md:pt-24">
      <h1 className="text-4xl leading-tight tracking-[-0.04em] md:text-4xl lg:leading-[1.1] xl:text-[2.5rem]">
        Thanks!
      </h1>
      <p className="text-lg text-primary/80">
        We&apos;ll be in touch ASAP to power your business.
      </p>
    </div>
  );
}
