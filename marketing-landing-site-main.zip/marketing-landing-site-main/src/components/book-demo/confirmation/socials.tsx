import { Button } from "@/components/ui/button";
import Link from "next/link";
import React from "react";

export function BookDemoConfirmationSocials() {
  return (
    <div className="mx-auto max-w-xl space-y-4 py-10 md:space-y-7 md:py-20 md:text-center">
      <p className="text-xl leading-tight tracking-[-0.04em] md:text-2xl lg:leading-[1.1]">
        Connect with us on Instagram, Facebook, and LinkedIn
      </p>
      <div className="flex flex-col space-y-3">
        <Button asChild variant="electric">
          <a
            href="https://www.instagram.com/qlub_uae/"
            target="_blank"
            rel="noopener noreferrer"
          >
            Follow on Instagram
          </a>
        </Button>
        <Button asChild variant="electric">
          <a
            href="https://www.facebook.com/qlubglobal"
            target="_blank"
            rel="noopener noreferrer"
          >
            Follow on Facebook
          </a>
        </Button>
        <Button asChild variant="electric">
          <a
            href="https://www.linkedin.com/company/qlub-pay/"
            target="_blank"
            rel="noopener noreferrer"
          >
            Connect on LinkedIn
          </a>
        </Button>
      </div>
    </div>
  );
}
