import { Button } from "@/components/ui/button";
import { ArrowRight, ChevronLeft } from "lucide-react";
import React from "react";

export default function Controls({
  prev,
  stepHandle,
  disabled,
}: {
  prev: () => void;
  stepHandle: string;
  disabled: boolean;
}) {
  if (stepHandle === "monthly-revenue") {
    return (
      <div className="flex justify-start">
        <Button
          onClick={prev}
          type="button"
          variant="electric-faded"
          size="icon"
        >
          <ChevronLeft className="size-4" />
        </Button>
      </div>
    );
  }

  if (stepHandle === "contact") {
    return (
      <div className="flex justify-between gap-4">
        <Button
          onClick={prev}
          type="button"
          variant="electric-faded"
          size="icon"
          className="shrink-0"
        >
          <ChevronLeft className="size-4" />
        </Button>
        <Button
          type="submit"
          className="w-full max-w-96 shrink"
          variant="electric"
          disabled={disabled}
        >
          Get a demo
          <ArrowRight className="ml-2 size-4" />
        </Button>
      </div>
    );
  }

  return (
    <div className="flex justify-start md:justify-end">
      <Button
        type="submit"
        className="w-full max-w-72"
        variant="electric"
        disabled={disabled}
      >
        Continue
        <ArrowRight className="ml-2 size-4" />
      </Button>
    </div>
  );
}
