import { cn } from "@/lib/utils";
import { Check } from "lucide-react";
import React from "react";
import { MultiStep } from ".";

export default function Stepper({
  steps,
  step,
  goTo,
  className,
}: {
  steps: MultiStep[];
  step: number;
  goTo: (step: number) => void;
  className: string;
}) {
  return (
    <ol className={cn("flex w-full items-center justify-center", className)}>
      {steps.map((_, index) => (
        <button
          className={cn("flex items-center text-violet-600/[0.09]", {
            "after:inline-block after:h-1 after:w-20 after:border-4 after:border-b after:border-violet-600/[0.09] after:content-[''] md:after:w-36":
              index !== steps.length - 1,
            "text-primary": index === step,
          })}
          key={index}
          onClick={() => {
            if (index < step) goTo(index);
          }}
          disabled={index >= step}
        >
          <span
            className={cn(
              "flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-violet-600/[0.09] text-primary/70 transition-colors lg:h-11 lg:w-11",
              {
                "bg-electric-violet-700 text-white": index === step,
              },
            )}
          >
            {index < step ? <Check className="size-4" /> : index + 1}
          </span>
        </button>
      ))}
    </ol>
  );
}
