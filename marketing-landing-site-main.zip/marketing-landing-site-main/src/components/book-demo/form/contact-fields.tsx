import React from "react";

import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { BookDemoSchemaType } from "@/lib/schema";
import { useFormContext } from "react-hook-form";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export function ContactFields() {
  const { control } = useFormContext<BookDemoSchemaType>();

  return (
    <div className="grid gap-4">
      <div className="grid grid-cols-2 gap-4">
        <FormField
          control={control}
          name="contact.firstName"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="relative after:absolute after:-right-2 after:top-0 after:text-purple-600 after:content-['*']">
                First name
              </FormLabel>
              <FormControl>
                <Input
                  placeholder="First name"
                  {...field}
                  className="h-14 w-full rounded-md border-0 border-transparent bg-violet-600/[0.09] px-4 font-medium text-primary placeholder:text-primary/80 md:px-8"
                  required
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={control}
          name="contact.lastName"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="relative after:absolute after:-right-2 after:top-0 after:text-purple-600 after:content-['*']">
                Last name
              </FormLabel>
              <FormControl>
                <Input
                  placeholder="Last name"
                  {...field}
                  className="h-14 w-full rounded-md border-0 border-transparent bg-violet-600/[0.09] px-4 font-medium text-primary placeholder:text-primary/80 md:px-8"
                  required
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <FormField
          control={control}
          name="contact.email"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="relative after:absolute after:-right-2 after:top-0 after:text-purple-600 after:content-['*']">
                Email
              </FormLabel>
              <FormControl>
                <Input
                  placeholder="Email"
                  {...field}
                  className="h-14 w-full rounded-md border-0 border-transparent bg-violet-600/[0.09] px-4 font-medium text-primary placeholder:text-primary/80 md:px-8"
                  required
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={control}
          name="contact.phone"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="relative after:absolute after:-right-2 after:top-0 after:text-purple-600 after:content-['*']">
                Phone
              </FormLabel>
              <FormControl>
                <Input
                  placeholder="Phone"
                  {...field}
                  className="h-14 w-full rounded-md border-0 border-transparent bg-violet-600/[0.09] px-4 font-medium text-primary placeholder:text-primary/80 md:px-8"
                  type="tel"
                  required
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>
      <FormField
        control={control}
        name="contact.isRestaurant"
        render={({ field }) => (
          <FormItem className="space-y-3">
            <FormLabel className="relative after:absolute after:-right-2 after:top-0 after:text-purple-600 after:content-['*']">
              Interested in Qlub
            </FormLabel>
            <FormControl>
              <RadioGroup
                onValueChange={field.onChange}
                defaultValue={field.value}
                className="flex flex-col space-y-1 rounded-md bg-violet-600/[0.09] px-4 py-6 md:px-8"
              >
                <FormItem className="flex items-center space-x-3 space-y-0">
                  <FormControl>
                    <RadioGroupItem value="true" />
                  </FormControl>
                  <FormLabel className="cursor-pointer font-medium">
                    for my restaurant
                  </FormLabel>
                </FormItem>
                <FormItem className="flex items-center space-x-3 space-y-0">
                  <FormControl>
                    <RadioGroupItem value="false" />
                  </FormControl>
                  <FormLabel className="cursor-pointer font-medium">
                    not for a restaurant
                  </FormLabel>
                </FormItem>
              </RadioGroup>
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
    </div>
  );
}
