import React from "react";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useFormContext } from "react-hook-form";
import { BookDemoSchemaType } from "@/lib/schema";
import { buttonVariants } from "@/components/ui/button";
import { REVENUE_INTERVALS } from "@/lib/constants";

export function MonthlyRevenueFields({
  submitHandler,
}: {
  submitHandler: () => void;
}) {
  const { control } = useFormContext<BookDemoSchemaType>();

  return (
    <FormField
      control={control}
      name="monthly-revenue.interval"
      render={({ field }) => (
        <FormItem className="space-y-3">
          <FormLabel className="sr-only">Monthly revenue</FormLabel>
          <FormControl>
            <RadioGroup
              onValueChange={(value) => {
                field.onChange(value.split("---")[0]);
                setTimeout(() => submitHandler(), 200);
              }}
              defaultValue={field.value}
              className="flex flex-col space-y-1"
            >
              {REVENUE_INTERVALS.map((interval) => (
                <FormRadioItem
                  key={interval.value}
                  value={interval.value + "---" + Math.random()}
                  label={interval.value}
                  selected={field.value}
                />
              ))}
            </RadioGroup>
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );
}

function FormRadioItem({
  value,
  label,
  selected,
}: {
  value: string;
  label: string;
  selected: string;
}) {
  return (
    <FormItem className="flex items-center space-x-3">
      <FormLabel className="w-full cursor-pointer [&:has([data-state=checked])>div]:border-primary">
        <FormControl>
          <RadioGroupItem value={value} className="sr-only" />
        </FormControl>
        <span
          className={buttonVariants({
            variant:
              value.split("---")[0] === selected
                ? "electric"
                : "electric-faded",
            className: "w-full",
            size: "lg",
          })}
        >
          {label}
        </span>
      </FormLabel>
    </FormItem>
  );
}
