import {
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { BookDemoSchemaType } from "@/lib/schema";
import { useFormContext } from "react-hook-form";
import { Combobox } from "@/components/ui/combobox";
import { POS } from "@/lib/constants";

export function POSFields() {
  const { setValue, watch } = useFormContext<BookDemoSchemaType>();
  const { control } = useFormContext<BookDemoSchemaType>();
  const selected = watch("pos.name");

  return (
    <FormField
      control={control}
      name="pos.name"
      render={({ field }) => (
        <FormItem className="flex flex-col">
          <FormLabel className="sr-only">POS</FormLabel>
          <Combobox
            mode="single"
            groups={POS}
            buttonPlaceholder="Select your system"
            selected={selected}
            variant="electric-faded"
            size="lg"
            onChange={(value) =>
              setValue("pos.name", value as string, {
                shouldValidate: true,
                shouldDirty: true,
                shouldTouch: true,
              })
            }
            onCreate={(value) => {
              setValue("pos.name", value, {
                shouldValidate: true,
                shouldDirty: true,
                shouldTouch: true,
              });
            }}
          />
          <FormDescription>
            Don&apos;t see your POS? You can add it by typing the name and Qlub
            will integrate with it as well.
          </FormDescription>
          <FormMessage />
        </FormItem>
      )}
    />
  );
}
