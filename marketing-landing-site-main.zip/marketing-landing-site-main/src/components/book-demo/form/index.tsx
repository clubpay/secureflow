"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { FieldErrors, useForm } from "react-hook-form";

import { Form } from "@/components/ui/form";
import { BookDemoSchema, BookDemoSchemaType } from "@/lib/schema";
import { useEffect, useState } from "react";
import { POSFields } from "./pos-fields";
import {
  useParams,
  usePathname,
  useRouter,
  useSearchParams,
} from "next/navigation";
import { MonthlyRevenueFields } from "./monthly-revenue-fields";
import { ContactFields } from "./contact-fields";
import Stepper from "./stepper";
import { motion, AnimatePresence } from "framer-motion";
import Controls from "./controls";
import { insertSheetData } from "@/server/actions/google";
import { nanoid } from "nanoid";
import { ZodError } from "zod";
import { sourcedPath, updateSearchParam } from "@/lib/utils";
import { sendGTMEvent } from "@next/third-parties/google";
import { REVENUE_INTERVALS } from "@/lib/constants";

type StepKey = keyof BookDemoSchemaType;

export type MultiStep = {
  handle: StepKey;
  title: string;
  description: string;
  gtmEventName?: string;
};

const STEPS: MultiStep[] = [
  {
    handle: "pos",
    title: "What is your POS?",
    description: "So we can integrate in 10 minutes.",
    gtmEventName: "Funnel_Submit_POS",
  },
  {
    handle: "monthly-revenue",
    title: "What is your monthly dine-in revenue?",
    description:
      "Doesn’t affect pricing. Select a range excluding delivery revenue.",
    gtmEventName: "Funnel_Submit_Monthly-revenue",
  },
  {
    handle: "contact",
    title: "How can we get in touch?",
    description: "",
  },
];

export function BookDemoForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const pathname = usePathname();
  const { source }: { source: string } = useParams();

  const stepParam = searchParams.get("step");
  const organizationParam = searchParams.get("organization");
  const stepParamIndex = STEPS.findIndex((step) => step.handle === stepParam);

  const [submittedSuccessfully, setSubmittedSuccessfully] =
    useState<boolean>(false);
  const [completed, setCompleted] = useState<number>(-1);
  const [index, setIndex] = useState<number>(
    stepParamIndex > -1 ? stepParamIndex : 0,
  );

  const step = STEPS[index];
  const stepsToValidate = STEPS.slice(0, index + 1);
  const { title, description } = step;
  const isFinalStep = index === STEPS.length - 1;
  const isInitialLoad = completed === -1;

  const pickConfig = stepsToValidate.reduce(
    (obj, step) => {
      obj[step.handle] = true;
      return obj;
    },
    {} as { [key in StepKey]: true },
  );

  const form = useForm<BookDemoSchemaType>({
    resolver: zodResolver(BookDemoSchema.passthrough().pick(pickConfig)),
    defaultValues: {
      pos: {
        name: "",
      },
      "monthly-revenue": {
        interval: "",
      },
      contact: {
        firstName: "",
        lastName: "",
        organization: "",
        email: "",
        phone: "",
        isRestaurant: undefined,
      },
    },
  });

  const { formState } = form;
  const { isSubmitting, isValid } = formState;
  const disabled = isSubmitting || !isValid || submittedSuccessfully;

  function prev() {
    setIndex((curr) => curr - 1);
  }

  async function next() {
    if (completed < index) {
      if (step.gtmEventName) {
        const values = form.getValues();
        sendGTMEvent({
          event: step.gtmEventName,
          organization: values.contact.organization,
          pos: values.pos.name,
          revenue: values["monthly-revenue"].interval,
          funnelStep: step.gtmEventName,
        });
      }

      setCompleted(index);
    }

    setIndex((curr) => curr + 1);
  }

  async function goTo(step: number) {
    setIndex(step);
  }

  async function onSubmit(values: BookDemoSchemaType) {
    if (!isFinalStep) {
      return next();
    }

    const { success, data, error } = BookDemoSchema.safeParse(values);

    if (success) {
      const id = nanoid();

      try {
        await insertSheetData([
          id,
          new Date().toLocaleString("en-US", { timeZone: "Asia/Dubai" }),
          data.contact.organization,
          data["monthly-revenue"].interval,
          data.pos.name,
          data.contact.firstName,
          data.contact.lastName,
          data.contact.email,
          data.contact.phone,
          data.contact.isRestaurant,
          source,
        ]);

        const gtmRevenueValue =
          REVENUE_INTERVALS.find(
            (interval) => interval.value === data["monthly-revenue"].interval,
          )?.gtmValue ?? 0;

        const gtmIsRestaurantValue =
          data.contact.isRestaurant === "true" ? 100 : 0;

        const gtmValue = gtmRevenueValue * gtmIsRestaurantValue;

        sendGTMEvent({
          event: "purchase",
          funnelStep: "Funnel_Purchase",
          id,
          organization: data.contact.organization,
          revenue: data["monthly-revenue"].interval,
          pos: data.pos.name,
          firstName: data.contact.firstName,
          lastName: data.contact.lastName,
          email: data.contact.email,
          phone: data.contact.phone,
          isRestaurant: data.contact.isRestaurant,
          currency: "AED",
          country: "ae",
          value: gtmValue,
        });

        setSubmittedSuccessfully(true);

        router.push(sourcedPath(`/book-demo/confirmation/${id}`, source));
      } catch (error) {
        router.push(sourcedPath("/", source));
      }
    }
  }

  function onError(
    errors: FieldErrors<BookDemoSchemaType> | ZodError<BookDemoSchemaType>,
  ) {
    const firstErrorStep = STEPS.find((step) => {
      return Object.keys(errors).some((key) => key.startsWith(step.handle));
    });

    if (!firstErrorStep) {
      return router.push(sourcedPath("/", source));
    }

    if (firstErrorStep?.handle) {
      router.push(
        `${pathname}?${updateSearchParam(searchParams, "step", firstErrorStep?.handle)}`,
      );
    }
  }

  const submitHandler = form.handleSubmit(onSubmit, onError);

  useEffect(() => {
    if (organizationParam) {
      form.setValue("contact.organization", organizationParam);
    }
  }, [organizationParam, form, router]);

  useEffect(() => {
    if (!organizationParam) {
      return router.push(sourcedPath("/", source));
    }

    router.push(
      `${pathname}?${updateSearchParam(searchParams, "step", step.handle)}`,
    );
  }, [step, router, pathname, searchParams, organizationParam, source]);

  useEffect(() => {
    if (stepParamIndex > -1) {
      setIndex(stepParamIndex);
    }
  }, [stepParamIndex]);

  if (index > completed + 1) {
    setIndex(completed + 1);
  }

  return (
    <div className="container max-w-4xl">
      <Stepper
        steps={STEPS}
        goTo={goTo}
        step={index}
        className="mb-8 md:mb-16"
      />
      <AnimatePresence mode="wait">
        <motion.div
          initial={{ opacity: isInitialLoad ? 1 : 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          key={step.handle}
          className="mb-6 space-y-1 md:mb-10"
        >
          <h1 className="text-3xl leading-tight tracking-[-0.04em] md:text-4xl lg:leading-[1.1] xl:text-[2.5rem]">
            {title}
          </h1>
          <p className="text-lg text-primary/75">{description}</p>
        </motion.div>
      </AnimatePresence>
      <Form {...form}>
        <form onSubmit={submitHandler}>
          <AnimatePresence mode="wait">
            <motion.div
              initial={{
                opacity: isInitialLoad ? 1 : 0,
                y: isInitialLoad ? 0 : -5,
              }}
              animate={{ opacity: 1, y: isInitialLoad ? undefined : 0 }}
              exit={{ opacity: 0, y: 5 }}
              key={step.handle}
              className="space-y-8"
            >
              {index === 0 && <POSFields />}
              {index === 1 && (
                <MonthlyRevenueFields submitHandler={submitHandler} />
              )}
              {index === 2 && <ContactFields />}
              <Controls
                prev={prev}
                stepHandle={step.handle}
                key={index}
                disabled={disabled}
              />
            </motion.div>
          </AnimatePresence>
        </form>
      </Form>
    </div>
  );
}
