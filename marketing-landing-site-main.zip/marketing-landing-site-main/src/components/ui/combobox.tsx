"use client";

import * as React from "react";
import { Check, ChevronsUpDown, Plus } from "lucide-react";

import { cn } from "@/lib/utils";
import { Button, ButtonProps, buttonVariants } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Drawer, DrawerContent, DrawerTrigger } from "@/components/ui/drawer";
import { ScrollArea } from "./scroll-area";
import { useMediaQuery } from "@/hooks/use-media-query";
import { VariantProps } from "class-variance-authority";

export type ComboboxOptions = {
  value: string;
  label: string;
};

export type ComboboxOptionsGroup = {
  heading?: string;
  options: ComboboxOptions[];
};

type Mode = "single" | "multiple";

interface ComboboxProps {
  mode?: Mode;
  groups: ComboboxOptionsGroup[];
  selected: string | string[]; // Updated to handle multiple selections
  className?: string;
  variant?: VariantProps<typeof buttonVariants>["variant"];
  size?: VariantProps<typeof buttonVariants>["size"];
  buttonPlaceholder?: string;
  inputPlaceholder?: string;
  onChange?: (event: string | string[]) => void; // Updated to handle multiple selections
  onCreate?: (value: string) => void;
}

export function Combobox({
  groups,
  selected,
  className,
  variant,
  size,
  buttonPlaceholder,
  inputPlaceholder,
  mode = "single",
  onChange,
  onCreate,
}: ComboboxProps) {
  const [open, setOpen] = React.useState(false);
  const [query, setQuery] = React.useState<string>("");
  const isDesktop = useMediaQuery("(min-width: 768px)");

  const options = groups.flatMap((group) => group.options);

  const isCustomValue =
    !!selected && !options.find((item) => item.value === selected);

  const isExactSearch = !!options.find(
    (item) => item.value.toLowerCase() === query.toLowerCase().trim(),
  );

  React.useEffect(() => {
    const timeoutId = setTimeout(() => {
      setQuery("");
    }, 200);

    return () => clearTimeout(timeoutId);
  }, [open]);

  if (isDesktop) {
    return (
      <div className={cn("block", className)}>
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <CommandTriggerButton
              selected={selected}
              buttonPlaceholder={buttonPlaceholder}
              open={open}
              setOpen={setOpen}
              mode={mode}
              options={options}
              isCustomValue={isCustomValue}
              variant={variant}
              size={size}
            />
          </PopoverTrigger>
          <PopoverContent className="popover-content-width-full p-0">
            <CommandWrapper
              setOpen={setOpen}
              groups={groups}
              selected={selected}
              inputPlaceholder={inputPlaceholder}
              mode={mode}
              onChange={onChange}
              onCreate={onCreate}
              query={query}
              setQuery={setQuery}
              isCustomValue={isCustomValue}
              isExactSearch={isExactSearch}
            />
          </PopoverContent>
        </Popover>
      </div>
    );
  }

  return (
    <Drawer open={open} onOpenChange={setOpen}>
      <DrawerTrigger asChild>
        <CommandTriggerButton
          selected={selected}
          buttonPlaceholder={buttonPlaceholder}
          open={open}
          setOpen={setOpen}
          mode={mode}
          options={options}
          isCustomValue={isCustomValue}
          variant={variant}
          size={size}
        />
      </DrawerTrigger>
      <DrawerContent className="max-h-full">
        <div className="mt-4 border-t">
          <CommandWrapper
            setOpen={setOpen}
            groups={groups}
            selected={selected}
            inputPlaceholder={inputPlaceholder}
            mode={mode}
            onChange={onChange}
            onCreate={onCreate}
            query={query}
            setQuery={setQuery}
            isCustomValue={isCustomValue}
            isExactSearch={isExactSearch}
          />
        </div>
      </DrawerContent>
    </Drawer>
  );
}

const CommandTriggerButton = React.forwardRef<
  HTMLButtonElement,
  ButtonProps & {
    selected: string | string[];
    buttonPlaceholder?: string;
    open: boolean;
    setOpen: React.Dispatch<React.SetStateAction<boolean>>;
    mode: Mode;
    options: ComboboxOptions[];
    isCustomValue: boolean;
  }
>(
  (
    {
      selected,
      buttonPlaceholder,
      setOpen,
      mode,
      open,
      options,
      isCustomValue,
      className,
      ...props
    },
    ref,
  ) => {
    return (
      <Button
        key="combobox-trigger"
        type="button"
        variant="outline"
        role="combobox"
        aria-expanded={open}
        className={cn(
          "w-full justify-between",
          !selected && "text-primary/70",
          className,
        )}
        ref={ref}
        {...props}
      >
        {selected && selected.length > 0 ? (
          <div className="relative mr-auto flex flex-grow flex-wrap items-center overflow-hidden">
            <span>
              {mode === "multiple" && Array.isArray(selected)
                ? selected
                    .map(
                      (selectedValue: string) =>
                        options.find((item) => item.value === selectedValue)
                          ?.label,
                    )
                    .join(", ")
                : mode === "single" && isCustomValue
                  ? selected
                  : options.find((item) => item.value === selected)?.label}
            </span>
          </div>
        ) : (
          buttonPlaceholder ?? "Select Item..."
        )}
        <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
      </Button>
    );
  },
);

CommandTriggerButton.displayName = "CommandTriggerButton";

function CommandWrapper({
  setOpen,
  groups,
  selected,
  inputPlaceholder,
  mode,
  onChange,
  onCreate,
  query,
  setQuery,
  isCustomValue,
  isExactSearch,
}: {
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
  mode?: Mode;
  groups: ComboboxOptionsGroup[];
  selected: string | string[];
  buttonPlaceholder?: string;
  inputPlaceholder?: string;
  onChange?: (event: string | string[]) => void;
  onCreate?: (value: string) => void;
  query: string;
  setQuery: React.Dispatch<React.SetStateAction<string>>;
  isCustomValue: boolean;
  isExactSearch: boolean;
}) {
  return (
    <Command
      filter={(value, search) => {
        if (value.toLowerCase().includes(search.trim().toLowerCase())) {
          return 1;
        }

        return 0;
      }}
      shouldFilter={true}
    >
      <CommandInput
        placeholder={inputPlaceholder ?? "Search..."}
        value={query}
        onValueChange={(value: string) => setQuery(value)}
      />
      <ScrollArea className="flex max-h-96 flex-col lg:max-h-72" type="always">
        <CommandList className="max-h-none">
          <CommandEmpty
            onClick={() => {
              if (onCreate) {
                onCreate(query);
                setQuery("");
              }
            }}
          >
            No results found.
          </CommandEmpty>

          {query || isCustomValue ? (
            <CommandGroup heading="Custom">
              {isCustomValue && typeof selected === "string" && (
                <CommandListItem
                  key={selected}
                  option={{ value: selected, label: selected }}
                  selected={selected}
                  mode={mode}
                  onChange={onChange}
                  setOpen={setOpen}
                />
              )}
              {query &&
                query.toLowerCase().trim() !== selected &&
                !isExactSearch && (
                  <CommandListItem
                    key={query}
                    option={{ value: query, label: query }}
                    selected={selected}
                    mode={mode}
                    onChange={onChange}
                    setOpen={setOpen}
                    icon={Plus}
                  />
                )}
            </CommandGroup>
          ) : null}
          {groups.map((group, i) => (
            <CommandGroup heading={group.heading} key={group.heading}>
              {group.options.map((option) => (
                <CommandListItem
                  key={option.label}
                  option={option}
                  selected={selected}
                  mode={mode}
                  onChange={onChange}
                  setOpen={setOpen}
                />
              ))}
            </CommandGroup>
          ))}
        </CommandList>
      </ScrollArea>
    </Command>
  );
}

interface CommandListItemProps {
  mode?: Mode;
  option: ComboboxOptions;
  selected: string | string[];
  className?: string;
  placeholder?: string;
  onChange?: (event: string | string[]) => void; // Updated to handle multiple selections
  onCreate?: (value: string) => void;
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
  icon?: React.ComponentType<React.SVGProps<SVGSVGElement>>;
}

function CommandListItem({
  option,
  onChange,
  selected,
  mode,
  setOpen,
  icon: Icon,
}: CommandListItemProps) {
  const isSelected =
    mode === "multiple" && Array.isArray(selected)
      ? selected.includes(option.value)
      : selected === option.value;

  return (
    <CommandItem
      key={option.label}
      value={option.label}
      onSelect={(currentValue) => {
        if (onChange) {
          if (mode === "multiple" && Array.isArray(selected)) {
            onChange(
              selected.includes(currentValue)
                ? selected.filter((item) => item !== currentValue)
                : [...selected, currentValue],
            );
          } else {
            onChange(currentValue);
          }
        }

        setOpen(false);
      }}
    >
      {Icon ? (
        <Icon
          className={cn(
            "mr-2 h-4 w-4",
            isSelected ? "opacity-0" : "opacity-100",
          )}
        />
      ) : (
        <Check
          className={cn(
            "mr-2 h-4 w-4",
            isSelected ? "opacity-100" : "opacity-0",
          )}
        />
      )}

      {option.label}
    </CommandItem>
  );
}
