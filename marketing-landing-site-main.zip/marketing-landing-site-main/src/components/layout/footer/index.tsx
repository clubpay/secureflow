import { Facebook } from "@/svgs/facebook";
import { Instagram } from "@/svgs/instagram";
import { QlubLogo } from "@/svgs/logo";
import { Linkedin } from "lucide-react";
import Link from "next/link";
import React from "react";

export function Footer({ navigation = true }: { navigation?: boolean }) {
  return (
    <footer className="bg-purple-50 pb-16 pt-8 md:pb-32 md:pt-12">
      <div className="container space-y-5 lg:space-y-7">
        {navigation && (
          <>
            <QlubLogo className="h-auto w-20 md:w-28" />
            <div className="flex gap-2">
              <a
                href="https://www.facebook.com/qlubglobal"
                className="flex size-8 items-center justify-center rounded-sm bg-electric-violet-700"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Facebook className="size-5 text-white" />
              </a>
              <a
                href="https://www.instagram.com/qlub_uae/"
                className="flex size-8 items-center justify-center rounded-sm bg-electric-violet-700"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Instagram className="size-5 text-white" />
              </a>
            </div>
          </>
        )}

        <div className="max-w-6xl space-y-5 text-xs text-primary/60 lg:text-sm">
          <p>
            Disclaimer: All statistics and claims about increased revenue and
            customer engagement are based on Qlub&apos;s data analysis, customer
            feedback, and market studies. Actual results may vary depending on
            numerous factors including business size, market conditions, and
            customer demographics. Qlub integrates with various POS systems to
            enhance service without replacing existing setups. Visit our Terms
            of Service and Privacy Policy for more details.
          </p>
          <p>
            Additional Resources: Learn more about how Qlub can transform your
            restaurant&apos;s operational efficiency and customer satisfaction.
            Read our Editorial Guidelines and review our comprehensive FAQ to
            better understand our services and offers.
          </p>
          <p>Fast Technology Services FZCO - Established in Dubai, UAE.</p>
        </div>
      </div>
    </footer>
  );
}
