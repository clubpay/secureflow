import { QlubLogo } from "@/svgs/logo";
import React from "react";

export default function Header() {
  return (
    <header className="fixed left-0 right-0 top-0 z-50 backdrop-blur-xl">
      <div className="container py-4 max-sm:px-5">
        <QlubLogo className="h-auto w-[5.5rem]" />
      </div>
    </header>
  );
}
