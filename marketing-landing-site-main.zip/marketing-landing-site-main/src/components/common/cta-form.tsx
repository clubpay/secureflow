"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { sendGTMEvent } from "@next/third-parties/google";
import { sourcedPath, cn } from "@/lib/utils";
import { useParams, useRouter } from "next/navigation";

const formSchema = z.object({
  organization: z.string().min(2, {
    message: "Restaurant name must be at least 2 characters.",
  }),
});

export function CTAForm({
  className,
  align = "center",
}: {
  className?: string;
  align?: "center" | "left";
}) {
  const router = useRouter();
  const { source } = useParams();
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      organization: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    sendGTMEvent({
      event: "Funnel_Submit_Organization",
      organization: values.organization,
      funnelStep: "Funnel_Submit_Organization",
    });

    return router.push(
      sourcedPath(`/book-demo?organization=${values.organization}`, source),
    );
  }

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(onSubmit)}
        className={cn("w-full space-y-8", className)}
      >
        <FormField
          control={form.control}
          name="organization"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="sr-only">Username</FormLabel>
              <div
                className={cn(
                  "relative mx-auto w-full max-w-lg space-y-2 md:space-y-0",
                  {
                    "lg:mx-0": align === "left",
                  },
                )}
              >
                <FormControl>
                  <Input
                    placeholder="What's your restaurant's name?"
                    {...field}
                    className="w-full border-0 border-transparent bg-violet-600/[0.09] py-7 text-center font-medium text-primary placeholder:text-primary/80 focus-visible:ring-0 focus-visible:ring-offset-0 md:px-6 md:py-8 md:text-left md:text-base"
                  />
                </FormControl>
                <Button
                  type="submit"
                  className="w-full px-4 py-6 md:absolute md:bottom-1.5 md:right-1.5 md:top-1.5 md:h-auto md:w-auto"
                  variant="electric"
                >
                  Get a demo
                </Button>
              </div>
              <FormMessage />
            </FormItem>
          )}
        />
      </form>
    </Form>
  );
}
