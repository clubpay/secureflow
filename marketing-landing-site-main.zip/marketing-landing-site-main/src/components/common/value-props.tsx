import { cn } from "@/lib/utils";

type Props = {
  items: {
    icon: React.ReactNode;
    text: string;
  }[];
  direction?: "vertical" | "horizontal";
  align?: "center" | "left";
};

export function ValueProposition({
  items,
  direction = "vertical",
  align = "center",
}: Props) {
  return (
    <div
      className={cn(
        "flex flex-col items-center gap-1.5 -space-y-0.5 text-center text-xs text-primary/80 md:text-[0.8rem]",
        {
          "sm:flex-row sm:justify-center": direction === "horizontal",
          "lg:justify-start": align === "left",
        },
      )}
    >
      {items.map((item) => (
        <p
          key={item.text}
          className="flex items-center justify-center rounded-full border p-[2px]"
        >
          <span className="flex size-7 items-center justify-center rounded-full bg-violet-600/[0.09] text-lg">
            {item.icon}
          </span>
          <span className="pl-1.5 pr-3">{item.text}</span>
        </p>
      ))}
    </div>
  );
}
