import { list } from "@vercel/blob";
import { Suspense, forwardRef } from "react";

export async function BackgroundVideo({
  fileName,
  ...props
}: {
  fileName: string;
  className?: string;
}) {
  const { blobs } = await list({
    prefix: fileName,
    limit: 1,
  });
  const { url } = blobs[0];

  return (
    <Suspense>
      <BackgroundVideoPlayer url={url} {...props} />
    </Suspense>
  );
}

type Props = {
  url: string;
} & React.HTMLAttributes<HTMLDivElement>;

export type Ref = HTMLVideoElement;

export const BackgroundVideoPlayer = forwardRef<Ref, Props>(
  function BackgroundVideoPlayer(props, ref) {
    const { url } = props;

    return (
      <div {...props}>
        <video
          preload="none"
          aria-label="Video player"
          playsInline
          autoPlay
          muted
          loop
          className="h-full w-full"
          ref={ref}
        >
          <source src={url} type="video/webm" />
          Your browser does not support the video tag.
        </video>
      </div>
    );
  },
);
