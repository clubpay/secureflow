"use client";

import { DEFAULT_SOURCE } from "@/lib/constants";
import Link from "next/link";
import { useParams } from "next/navigation";
import React from "react";

/**
 * Use this component to create a Next.js `<Link />` that persists the current source in the url,
 * without having to explicitly pass it as a prop.
 */
export const SourcedClientLink = ({
  children,
  href,
  ...props
}: {
  children?: React.ReactNode;
  href: string;
  className?: string;
  onClick?: () => void;
  passHref?: true;
  [x: string]: any;
}) => {
  const { source } = useParams();

  const isDefaultSource = source === DEFAULT_SOURCE;

  return (
    <Link href={isDefaultSource ? href : `/${source}${href}`} {...props}>
      {children}
    </Link>
  );
};
