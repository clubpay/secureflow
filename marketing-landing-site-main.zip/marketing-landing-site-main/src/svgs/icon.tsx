import React from "react";

export function QlubIcon() {
  return (
    <svg
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="1.8038" cy="1.8038" r="1.8038" fill="#7D01D4" />
      <circle
        cx="21.745"
        cy="1.8038"
        r="1.8038"
        transform="rotate(90 21.745 1.8038)"
        fill="#7D01D4"
      />
      <circle
        cx="21.745"
        cy="21.7392"
        r="1.8038"
        transform="rotate(-180 21.745 21.7392)"
        fill="#7D01D4"
      />
      <circle
        cx="1.8038"
        cy="21.7392"
        r="1.8038"
        transform="rotate(-90 1.8038 21.7392)"
        fill="#7D01D4"
      />
      <circle cx="1.8038" cy="6.12998" r="1.8038" fill="#7D01D4" />
      <circle
        cx="17.4143"
        cy="1.8038"
        r="1.8038"
        transform="rotate(90 17.4143 1.8038)"
        fill="#7D01D4"
      />
      <circle
        cx="21.745"
        cy="17.4091"
        r="1.8038"
        transform="rotate(-180 21.745 17.4091)"
        fill="#7D01D4"
      />
      <circle
        cx="6.13449"
        cy="21.7392"
        r="1.8038"
        transform="rotate(-90 6.13449 21.7392)"
        fill="#7D01D4"
      />
      <circle cx="6.13449" cy="1.8038" r="1.8038" fill="#7D01D4" />
      <circle
        cx="21.745"
        cy="6.12997"
        r="1.8038"
        transform="rotate(90 21.745 6.12997)"
        fill="#7D01D4"
      />
      <circle
        cx="17.4143"
        cy="21.7392"
        r="1.8038"
        transform="rotate(-180 17.4143 21.7392)"
        fill="#7D01D4"
      />
      <circle
        cx="1.8038"
        cy="17.4091"
        r="1.8038"
        transform="rotate(-90 1.8038 17.4091)"
        fill="#7D01D4"
      />
    </svg>
  );
}
