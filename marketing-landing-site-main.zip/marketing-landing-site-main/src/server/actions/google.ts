"use server";

import { google } from "googleapis";

const credential = JSON.parse(
   Buffer.from(process.env.GCP_SA_JSON_KEY ?? "", "base64").toString()
);

export async function insertSheetData(data: string[]) {
   const auth = await google.auth.getClient({
      scopes: ["https://www.googleapis.com/auth/spreadsheets"],
      credentials: {
         client_email: credential.client_email,
         private_key: credential.private_key,
      }
   });

   const sheets = google.sheets({ version: "v4", auth });

   const range = "LP Leads!A2:J1000";

   const response = await sheets.spreadsheets.values.append({
      spreadsheetId: process.env.GOOGLE_SHEET_ID,
      range,
      valueInputOption: "RAW",
      requestBody: {
         values: [data],
      },
   });

   return response.data;
}

export async function getSheetDataById(id: string) {
   const auth = await google.auth.getClient({
      scopes: ["https://www.googleapis.com/auth/spreadsheets"],
      credentials: {
         client_email: credential.client_email,
         private_key: credential.private_key,
      }
   });

   const sheets = google.sheets({ version: "v4", auth });

   const range = "LP Leads!A2:J1000";

   const response = await sheets.spreadsheets.values.get({
      spreadsheetId: process.env.GOOGLE_SHEET_ID,
      range,
   });

   const { values } = response.data;

   if (!values) {
      return undefined;
   }

   return values.find((row) => row[0] === id);
}