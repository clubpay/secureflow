# customer-app-payment-module

## Installation

```bash
# with npm
npm i @clubpay/customer-common-module
npm i @clubpay/customer-payment-module
```

```bash
# with yarn
yarn add @clubpay/customer-common-module
yarn add @clubpay/customer-payment-module
```

This project needs to be transpiled to work with your Next.js application. It is recommended to use Next.js `13.1.0`’s [built-in module tranpilation](https://nextjs.org/blog/next-13-1#built-in-module-transpilation-stable). (Up until Next.js `13.1.0`, [`next-transpile-modules`](https://github.com/martpie/next-transpile-modules) handled this use case.)

```js
// next.config.js

/**
 * @type {import('next').NextConfig}
 */
const nextConfig = {
  reactStrictMode: true,
  pageExtensions: ["tsx", "ts"],
  swcMinify: true,
  transpilePackages: ["@clubpay/customer-payment-module"],
};

module.exports = nextConfig;
```
