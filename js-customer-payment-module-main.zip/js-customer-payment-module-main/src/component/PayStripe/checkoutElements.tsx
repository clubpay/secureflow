/*
    Creation Time: 2022 - Jan - 9
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { PaymentElement, useElements, useStripe } from '@stripe/react-stripe-js';
import { CreditCard, VerifiedUserOutlined } from '@mui/icons-material';
import { useConfirmCallback, usePaymentTimeout } from '@clubpay/customer-common-module/src/hook/payment';
import { CustomerContainer } from '@qlub-dev/qlub-kit';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IStripeGateway } from '../../repository/type/paymentGateway';
import PayButtonElement from '../PayButtonElement';
import { usePaymentError } from '../../hook/paymentError';
import PaymentAPIManager from '../../repository';

import styles from './index.module.scss';

interface IProps extends IPGProps {
    intentId: string;
    clientSecret: string;
    refId: string;
    config: IStripeGateway;
    onRefreshIntent: (onlyRefId?: boolean) => void;
}

export default function CheckoutElements({
    diningSessionID,
    sessionId,
    intentId,
    clientSecret,
    refId,
    amount,
    tip,
    name,
    currencyPrecision,
    config,
    vendor,
    disable,
    gatewayId,
    updateTimestamp,
    onBeforePayment,
    onUnlockPayment,
    onFail,
    onPending,
    onIndicator,
    onLoad,
    onRefreshIntent,
    onPgRegister,
    onTraceStart,
    onTraceClose,
}: IProps) {
    const { t } = useTranslation('common');
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);
    const { timeoutDone } = usePaymentTimeout({
        indicatorTimeout: config?.indicatorTimeout || 0,
        fallbackTimeout: config?.fallbackTimeout || 0,
        indicatorCallback: onIndicator,
        fallbackCallback: onLoad,
    });
    const { lang } = useQlubRouter();
    const [componentKey, setComponentKey] = useState(getRandomString());
    const { getCallbackUrl } = useConfirmCallback();
    const { showError } = usePaymentError();
    const stripe = useStripe();
    const elements = useElements();
    const formRef = useRef<HTMLFormElement | null>(null);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const { hasPgGroup } = vendor.paymentGatewayList;

    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    useEffect(() => {
        elements?.update({
            locale: (lang || 'en') as any,
        });
        setComponentKey(getRandomString());
    }, [lang]);

    const buttonElement = useMemo(() => {
        return (
            <div className={styles.submit}>
                <PayButtonElement
                    variant="contained"
                    type="submit"
                    onClick={(e) => handleSubmit(e)}
                    disabled={disable || loading || success || !elements}
                    fullWidth
                    loading={loading}
                    showConfirmText={!hasPgGroup}
                />
            </div>
        );
    }, [loading, success, disable, amount, tip, elements, updateTimestamp, lang]);

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.CardPay,
            name: t('Card'),
            icon: <CreditCard />,
            buttonElement,
        });
    }, [elements, buttonElement, updateTimestamp, lang]);

    const submitHandler = async (e: any) => {
        e.preventDefault();

        if (loading) {
            return;
        }

        setLoading(true);

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.CardPay,
                refId,
            },
        });

        onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.CardPay,
            tip,
        })
            .then((ok) => {
                if (!ok) {
                    setLoading(false);
                    return;
                }

                const lastIntentId = intentId;
                PaymentAPIManager.getInstance()
                    .paymentStripePay({
                        id: sessionId,
                        reference: refId,
                        diningSessionID,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                        gatewayID: gatewayId,
                        intentID: intentId,
                    })
                    .then(() => {
                        if (lastIntentId !== intentId) {
                            return Promise.reject(Error(t('Wrong intentId')));
                        }
                        if (!stripe || !elements) {
                            return Promise.reject(Error(t('stripe is not initialized')));
                        }
                        const amountStr = sumAmounts(currencyPrecision, amount, tip).toFixed(currencyPrecision || 0);
                        const tipStr = tip.toFixed(currencyPrecision || 0);

                        const returnUrl = getCallbackUrl({
                            ref: refId,
                            method: name,
                            paymentElement: PaymentElementEnum.CardPay,
                            tip: tipStr,
                            dsi: diningSessionID,
                            amount: amountStr,
                            currencySymbol: vendor.country.currencySymbol,
                            traceId: traceStart?.traceId,
                            lang,
                        });

                        return stripe
                            .confirmPayment({
                                elements,
                                confirmParams: {
                                    return_url: returnUrl.pending,
                                    payment_method_data: {
                                        billing_details: {
                                            address: {
                                                country: config?.countryCode || 'US',
                                            },
                                        },
                                    },
                                },
                            })
                            .then((confirmPaymentRes) => {
                                if (confirmPaymentRes.error) {
                                    return Promise.reject(confirmPaymentRes.error);
                                }
                                return stripe.retrievePaymentIntent(clientSecret).then((retrievePaymentIntentRes) => {
                                    if (retrievePaymentIntentRes.error) {
                                        onTraceClose?.({
                                            error: retrievePaymentIntentRes.error,
                                            location: 'stripe.retrievePaymentIntent',
                                            traceRef,
                                            traceStart,
                                        });

                                        onFail({
                                            paymentElement: PaymentElementEnum.CardPay,
                                            refId,
                                            traceId: traceStart?.traceId,
                                        });

                                        return Promise.reject(retrievePaymentIntentRes.error);
                                    }
                                    setSuccess(true);

                                    return retrievePaymentIntentRes;
                                });
                            });
                    })
                    .catch((err: any) => {
                        onTraceClose?.({
                            error: err,
                            location: 'paymentStripePay',
                            traceRef,
                            traceStart,
                        });

                        const errData = err?.response?.data || err || {};

                        showError(errData, err?.message);

                        const isNetworkError = checkNetworkError(err as AxiosError);
                        if (isNetworkError) {
                            onPending({
                                paymentElement: PaymentElementEnum.CardPay,
                                refId,
                                traceId: traceStart?.traceId,
                            });
                        } else {
                            if (
                                (errData.code === 412 && errData.items === 'PAYMENT_REFERENCE_CONFLICTS_TRANSACTION') ||
                                (err.type && err.type.length > 0)
                            ) {
                                onRefreshIntent();
                            } else {
                                onRefreshIntent(true);
                            }

                            onUnlockPayment();
                        }
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            })
            .catch(() => {
                setLoading(false);
            });
    };

    const handleSubmit = (event: React.MouseEvent<HTMLButtonElement>) => {
        if (formRef.current) {
            submitHandler(event);
        }
    };

    return (
        <form ref={formRef} className={styles.formContainer} onSubmit={submitHandler}>
            <CustomerContainer
                key={componentKey}
                padding="1rem 0.5rem 3rem"
                margin="0 0 0rem 0"
                className={styles.cardContainer}
            >
                <PaymentElement
                    options={{
                        wallets: {
                            applePay: 'never',
                            googlePay: 'never',
                        },
                        fields: {
                            billingDetails: {
                                address: {
                                    country: 'never',
                                },
                            },
                        },
                    }}
                    onReady={() => {
                        timeoutDone();
                    }}
                />

                <div className={styles.secureWrapper}>
                    <div className={styles.secureIcon}>
                        <VerifiedUserOutlined />
                    </div>
                    <div className={styles.secureText}>
                        {vendor.config.hideLogo
                            ? t('100% Secure payments')
                            : t('100% Secure payments powered by Qlub_')}
                    </div>
                </div>
            </CustomerContainer>
            {!hasPgGroup && buttonElement}
        </form>
    );
}
