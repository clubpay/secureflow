/*
    Creation Time: 2022 - April - 12
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { usePaymentTimeout } from '@clubpay/customer-common-module/src/hook/payment';
import { CircularProgress } from '@mui/material';
import { getQRPath, useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { Link } from '@mui/icons-material';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import Modal from '@clubpay/customer-common-module/src/component/Modal';
import { qlubLocalStorage } from '@clubpay/customer-common-module/src/service/storage/localStorage';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IDGPayGateway } from '../../repository/type/paymentGateway';
import PayButtonElement from '../PayButtonElement';
import PaymentWrapper from '../PaymentWrapper';
import PaymentAPIManager from '../../repository';

import styles from './index.module.scss';

const qlubToken = 'qlub.dgpay.token';

export interface IProps extends IPGProps {
    config: IDGPayGateway;
}

export default function PayDGPay({
    diningSessionID,
    sessionId,
    jwt,
    url,
    amount,
    tip,
    name,
    currencyPrecision,
    disable,
    vendor,
    config,
    gatewayId,
    updateTimestamp,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onIndicator,
    onLoad,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onTraceClose,
}: IProps) {
    const { lang } = useQlubRouter();
    const [loading, setLoading] = useState(false);
    const [iframeUrl, setIframeUrl] = useState<string>('');
    const [refId, setRefId] = useState('');
    const { timeoutDone } = usePaymentTimeout({
        indicatorTimeout: config?.indicatorTimeout || 0,
        fallbackTimeout: config?.fallbackTimeout || 0,
        indicatorCallback: onIndicator,
        fallbackCallback: onLoad,
    });
    const [iframeLoading, setIframeLoading] = useState(false);
    const [open, setOpen] = useState(false);
    const [loadCount, setLoadTime] = useState(0);
    const { hasPgGroup } = vendor.paymentGatewayList;
    const totalAmount = sumAmounts(currencyPrecision, amount, tip);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    const closeHandler = () => {
        setOpen(false);
        setLoadTime(0);
        setLoading(false);
    };

    useEffect(() => {
        const windowMessageHandler = (e: MessageEvent) => {
            if (e.origin === window.location.origin) {
                try {
                    const msg = JSON.parse(e.data) as {
                        status?: string;
                        Token?: string;
                    };
                    if (msg.status === 'success') {
                        onDone({
                            paymentElement: PaymentElementEnum.CardPay,
                            refId,
                        });

                        closeHandler();
                    } else if (msg.status === 'fail') {
                        onTraceClose?.({
                            error: msg,
                            location: 'paymentCheckoutPayByToken',
                            traceRef,
                            traceStart,
                        });

                        onFail({
                            paymentElement: PaymentElementEnum.CardPay,
                            refId,
                            traceId: traceStart?.traceId,
                        });

                        closeHandler();
                    }
                    if (msg.Token) {
                        qlubLocalStorage.set(qlubToken, msg.Token);
                    }
                } catch {
                    onUnlockPayment();
                }
            }
        };
        window.addEventListener('message', windowMessageHandler);
        return () => {
            window.removeEventListener('message', windowMessageHandler);
        };
    }, [refId, totalAmount]);

    const openHandler = () => {
        setOpen(true);
        setIframeLoading(true);
    };

    const submitHandler = () => {
        setLoading(true);

        const referenceId = getRandomString();
        setRefId(referenceId);

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.CardPay,
                refId: referenceId,
            },
        });

        onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.CardPay,
            tip,
        })
            .then((ok) => {
                if (!ok) {
                    setLoading(false);
                    return;
                }
                const orderId = getRandomString();
                const getPaymentUrl = (success: boolean) => {
                    const langStr = lang ? `&lang=${lang}` : '';
                    return `${window.location.origin}/qr/${getQRPath(url)}/invoice/iframe?status=${
                        success ? 'success' : 'fail'
                    }${langStr}`;
                };

                PaymentAPIManager.getInstance()
                    .paymentDGPaySession({
                        id: sessionId,
                        reference: referenceId,
                        diningSessionID,
                        orderID: orderId,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                        successUrl: getPaymentUrl(true),
                        failureUrl: getPaymentUrl(false),
                        gatewayID: gatewayId,
                    })
                    .then((res) => {
                        const dgPayUrl = config?.sandbox
                            ? 'https://dgpftestapi.dgpays.com'
                            : 'https://dgpfapi.dgpays.com';
                        const langStr = lang ? `&lang=${lang}` : '';
                        const token = qlubLocalStorage.get(qlubToken);
                        const tokenStr = token ? `&Token=${token}` : '';
                        setIframeUrl(
                            `${dgPayUrl}/api/Payment/ThreeDSecure/${res.data.threeDSessionID}?amount=${(
                                Number(res.data.totalAmount) * 100
                            ).toFixed(0)}${tokenStr}&jwt=${jwt}${langStr}`,
                        );
                        openHandler();
                    })
                    .catch((err) => {
                        onTraceClose?.({
                            error: err,
                            location: 'paymentDGPaySession',
                            traceRef,
                            traceStart,
                        });

                        onFail({
                            paymentElement: PaymentElementEnum.CardPay,
                            refId,
                            traceId: traceStart?.traceId,
                        });
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            })
            .catch(() => {
                setLoading(false);
            });
    };

    const buttonElement = useMemo(() => {
        return (
            <PayButtonElement
                variant="contained"
                size="large"
                className={styles.button}
                disabled={disable || loading}
                onClick={submitHandler}
                fullWidth
                id="dgpay-action-btn"
                loading={loading}
                showConfirmText={!hasPgGroup}
            />
        );
    }, [tip, disable, loading, updateTimestamp]);

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            name: 'Link',
            elem: PaymentElementEnum.LinkPay,
            icon: <Link />,
            placement: 'bottom',
            buttonElement,
        });
    }, [updateTimestamp, loading]);

    const loadHandler = () => {
        if (loadCount === 0) {
            timeoutDone();
        }
        setTimeout(() => {
            setIframeLoading(false);
        }, 500);
        setLoadTime((o) => o + 1);
    };

    const getDrawerContent = () => {
        return (
            <div className={styles.dgpayIframe}>
                {iframeLoading && (
                    <div className={styles.loading}>
                        <CircularProgress size={48} thickness={2} color="primary" />
                    </div>
                )}
                <div className={styles.iframe} style={{ opacity: iframeLoading ? '0' : '1' }}>
                    <iframe
                        style={{ visibility: !open || iframeLoading ? 'hidden' : 'visible' }}
                        title="DGPay"
                        src={iframeUrl}
                        onLoad={loadHandler}
                    />
                </div>
            </div>
        );
    };

    return (
        <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.LinkPay)}>
            <div className={styles.form}>
                <Modal sx={{ zIndex: 100000001 }} open={open} closeHandler={closeHandler} openHandler={openHandler}>
                    {getDrawerContent()}
                </Modal>
                <div className={styles.submit}>{!hasPgGroup && buttonElement}</div>
            </div>
        </PaymentWrapper>
    );
}
