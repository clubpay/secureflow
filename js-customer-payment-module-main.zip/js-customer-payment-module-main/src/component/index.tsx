import React from 'react';
import { IPGPropsAll, PaymentTypeEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import PayCheckout from './PayCheckout';
import PayCheckoutPlatform from './PayCheckoutPlatform';
import PayTM from './PayTM';
import PaySMBCLink from './PaySMBCLink';
import PayStripe from './PayStripe';
import PayStripeConnect from './PayStripeConnect';
import PayDGPay from './PayDGPay';
import PayTuna from './PayTuna';
import PayPaypay from './PayPaypay';
import PayMoyasar from './PayMoyasar';
import PayMaf from './PayMaf';
import PayMafV2 from './PayMafV2';
import PayTicket from './PayTicket';
import PayIndiaGooglePay from './PayIndiaGooglePay';
import PayMasterpass from './PayMasterpass';
import PayVostro from './PayVostro/dynamic';
import PayTapp from './PayTapp';
import PayMashreq from './PayMashreq';
import PayAdyen from './PayAdyen';
import PayMoyasarV2 from './PayMoyasarV2';
import PayNGenius from './PayNGenius';
import PayMasterpassDirect from './PayMasterpassDirect';
import PayTyro from './PayTyro';

interface IProps extends IPGPropsAll {
    type?: PaymentTypeEnum;
}

const Payment = ({ type, ...props }: IProps) => {
    switch (type) {
        case PaymentTypeEnum.Checkout:
            return <PayCheckout {...props} key="pay-checkout" />;
        case PaymentTypeEnum.CheckoutPlatform:
            return <PayCheckoutPlatform {...props} key="pay-checkout-platform" />;
        case PaymentTypeEnum.PayTM:
            return <PayTM {...props} key="pay-tm" />;
        case PaymentTypeEnum.SMBCLink:
            return <PaySMBCLink {...props} key="smbc-link" />;
        case PaymentTypeEnum.Stripe:
            return <PayStripe {...props} key="stripe" />;
        case PaymentTypeEnum.StripeConnect:
            return <PayStripeConnect {...props} key="stripe-connect" />;
        case PaymentTypeEnum.DGPay:
            return <PayDGPay {...props} key="dgpay" />;
        case PaymentTypeEnum.Tuna:
            return <PayTuna {...props} key="tuna" />;
        case PaymentTypeEnum.PayPay:
            return <PayPaypay {...props} key="paypay" />;
        case PaymentTypeEnum.Moyasar:
            return <PayMoyasar {...props} key="moyasar" />;
        case PaymentTypeEnum.MoyasarV2:
            return <PayMoyasarV2 {...props} key="moyasar-v2" />;
        case PaymentTypeEnum.Maf:
            return <PayMaf {...props} key="maf" />;
        case PaymentTypeEnum.MafV2:
            return <PayMafV2 {...props} key="maf-v2" />;
        case PaymentTypeEnum.Ticket:
            return <PayTicket {...props} key="ticket" />;
        case PaymentTypeEnum.IndiaGooglePayDirect:
            return <PayIndiaGooglePay {...props} key="india-google-pay" />;
        case PaymentTypeEnum.MasterPass:
            return <PayMasterpass {...props} key="master-pass" />;
        case PaymentTypeEnum.Vostro:
            return <PayVostro {...props} key="vostro" />;
        case PaymentTypeEnum.Tapp:
            return <PayTapp {...props} key="tap" />;
        case PaymentTypeEnum.Mashreq:
            return <PayMashreq {...props} key="mashreq" />;
        case PaymentTypeEnum.Adyen:
            return <PayAdyen {...props} key="adyen" />;
        case PaymentTypeEnum.NGenius:
            return <PayNGenius {...props} key="n-genius" />;
        case PaymentTypeEnum.MasterPassDirect:
            return <PayMasterpassDirect {...props} key="master-pass-direct" />;
        case PaymentTypeEnum.Tyro:
            return <PayTyro {...props} key="tyro" />;
        default:
            return null;
    }
};

export default Payment;
