import {
    IPayBeforePaymentHandler,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';

declare global {
    interface Window {
        Moyasar: {
            init: (config: IMoyasarConfig) => void;
            setAmount: (amount: number) => void;
            onBeforePayment: (payload: IPayBeforePaymentHandler) => Promise<boolean>;
            ref: string;
            intentID: string;
            tip: number;
            initialized: boolean;
        };
    }
}

export interface Source {
    type: string;
    company: string;
    name: string;
    number: string;
    gateway_id: string;
    reference_number?: any;
    token?: any;
    message?: any;
    transaction_url: string;
    statement_descriptor?: any;
}

export interface PaymentObject {
    id: string;
    status: string;
    amount: number;
    fee: number;
    currency: string;
    refunded: number;
    refunded_at?: any;
    captured: number;
    captured_at?: any;
    voided_at?: any;
    description: string;
    amount_format: string;
    fee_format: string;
    refunded_format: string;
    captured_format: string;
    invoice_id?: any;
    ip: string;
    callback_url: string;
    created_at: Date;
    updated_at: Date;
    source: {
        type: IMethods;
        company: string | null;
        name: string | null;
        number: string | null;
        gateway_id: string | null;
        reference_number: string | null;
        token: string | null;
        message: string | null;
        transaction_url: string | null;
    };
}

export type IMethods = 'creditcard' | 'applepay' | 'stcpay';

export interface IMoyasarConfig {
    element: '.mysr-form';
    amount: number;
    currency: string;
    description: string;
    direction: string;
    publishable_api_key: string;
    callback_url?: string;
    methods?: IMethods[];
    metadata?: any;
    on_failure?: (error: any) => void;
    on_initiating?: () => any | void;
    on_completed?: (data: PaymentObject) => Promise<any> | void;
    on_redirect?: (data: any) => void;
    fixed_width?: boolean;
    language: string | null;
    apple_pay?: {
        country: string;
        label: string;
        validate_merchant_url: string;
        supported_countries: typeof supportedCountries;
    };
    source?: any;
    statement_descriptor?: string;
}

export const supportedCountries = [
    'ZA',
    'AU',
    'CN',
    'HK',
    'JP',
    'MO',
    'MY',
    'NZ',
    'SG',
    'KR',
    'TW',
    'AM',
    'AT',
    'AZ',
    'BY',
    'BE',
    'BG',
    'HR',
    'CY',
    'CZ',
    'DK',
    'EE',
    'FO',
    'FI',
    'FR',
    'GE',
    'DE',
    'GR',
    'GL',
    'GG',
    'HU',
    'IS',
    'IE',
    'IM',
    'IT',
    'KZ',
    'JE',
    'LV',
    'LI',
    'LT',
    'LU',
    'MT',
    'MD',
    'MC',
    'ME',
    'NL',
    'NO',
    'PL',
    'PT',
    'RO',
    'SM',
    'RS',
    'SK',
    'SI',
    'ES',
    'SE',
    'CH',
    'UA',
    'GB',
    'AR',
    'BR',
    'CO',
    'CR',
    'SV',
    'GT',
    'HN',
    'MX',
    'PA',
    'PE',
    'BH',
    'IL',
    'JO',
    'KW',
    'PS',
    'QA',
    'SA',
    'AE',
    'US',
] as const;

export const getPaymentMethod = (method: IMethods) => {
    if (method === 'creditcard') return PaymentElementEnum.CardPay;
    return method;
};
