import React, { useEffect, useMemo, useRef, useState } from 'react';
import Head from 'next/head';
import Scripts from 'next/script';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { CreditCard } from '@mui/icons-material';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { Stack, useTheme } from '@mui/material';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import PaymentWrapper from '../PaymentWrapper';
import PayButtonElement from '../PayButtonElement';
import PaymentAPIManager from '../../repository';
import { usePaymentError } from '../../hook/paymentError';
import { IMethods, PaymentObject, getPaymentMethod, supportedCountries } from './moyasarlib';
import { STCPayLogo } from '../../asset/icon';

import styles from './index.module.scss';

export interface IProps extends IPGProps {
    config: any;
}

const PayMoyasar = ({
    diningSessionID,
    sessionId,
    amount,
    tip,
    name,
    currencyPrecision,
    disable,
    gatewayId,
    config,
    vendor,
    onBeforePayment,
    onUnlockPayment,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onTraceClose,
}: IProps) => {
    const btnRef = useRef<HTMLButtonElement | null>(null);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const { lang } = useQlubRouter();
    const { showError } = usePaymentError();
    const { t } = useTranslation('common');
    const theme = useTheme();
    const { getCallbackUrl } = useConfirmCallback();
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const currentLang = useRef(lang);
    const [loading, setLoading] = useState(false);
    const [isInitialized, setIsInitialized] = useState(false);

    const { hasPgGroup } = vendor.paymentGatewayList;
    const { unique } = vendor;

    if (window.Moyasar) {
        window.Moyasar.onBeforePayment = onBeforePayment;
    }

    const createStatementDescriptor = (vendorName: string) => {
        const specialCharactersRegex = /[^a-zA-Z0-9\s]/g;

        let restaurantName: string = vendorName || unique;
        if (restaurantName.length > 13) {
            restaurantName = restaurantName.substring(0, 13);
        }

        let restaurantUnique: string = unique;
        if (restaurantUnique.length > 13) {
            restaurantUnique = restaurantUnique.substring(0, 13);
        }

        const nameOrUnique = restaurantName || restaurantUnique;

        const nameOrUniqueWithoutSpecialCharacters = nameOrUnique.replace(specialCharactersRegex, '');

        return `${nameOrUniqueWithoutSpecialCharacters} qlub ${vendor.country.code}`.toLowerCase();
    };

    const { selectorIcon, selectorName } = useMemo(() => {
        if (config.enableStcPay && !config.hideCardPay) {
            return {
                selectorIcon: (
                    <Stack spacing={2} alignItems="center" direction="row">
                        <CreditCard />
                        <STCPayLogo />
                    </Stack>
                ),
                selectorName: 'Card or stc pay',
            };
        }
        if (config.enableStcPay && config.hideCardPay) {
            return {
                selectorIcon: <STCPayLogo />,
                selectorName: 'STC Pay',
            };
        }
        return {
            selectorIcon: <CreditCard />,
            selectorName: 'Card',
        };
    }, [config]);

    const statementDescriptor: string = createStatementDescriptor(vendor.name);

    const submitHandler = async (
        paymentObj: PaymentObject,
        sid: string,
        referenceId: string,
        intentId: string,
    ): Promise<any> => {
        const errorTranslations: { [key: string]: string } = {
            PAYMENT_AMOUNT_IS_TOO_LARGE: t('You’re paying too much'),
            PAYMENT_AMOUNT_IS_ZERO: t('You are trying to pay for a bill that is already paid for'),
            DEFAULT_ERROR: t('The payment did not proceed, Please try again'),
        };
        try {
            return PaymentAPIManager.getInstance().payMoyasarPayment({
                diningSessionID,
                id: sid,
                paymentId: paymentObj.id,
                intentID: intentId,
                reference: referenceId,
                statementDescriptor,
                paymentMethod: getPaymentMethod(paymentObj.source?.type),
            });
        } catch (err: any) {
            const errData = err?.response?.data || err || {};
            showError(errData, err?.message);
            return Promise.reject(errorTranslations[errData.items] || errorTranslations.DEFAULT_ERROR);
        }
    };

    const updateInvoice = (sid: string, referenceId: string, intentId: string, tipAmount = 0): Promise<any> => {
        return PaymentAPIManager.getInstance().payMoyasarUpdateIntent({
            diningSessionID,
            id: sid,
            intentID: intentId,
            tipAmount: tipAmount.toFixed(currencyPrecision),
            statementDescriptor,
        });
    };

    const isElemValid = () => {
        return Boolean(document.querySelector('.mysr-form'));
    };

    const triggerOriginalButton = () => {
        if (btnRef.current) {
            btnRef.current.click();
        }
    };

    const renderMoyasar = () => {
        if (!isElemValid()) {
            return;
        }

        window.Moyasar.initialized = true;
        window.Moyasar.ref = getRandomString();
        const amountStr = amount.toFixed(currencyPrecision || 0);
        const tipStr = tip.toFixed(currencyPrecision || 0);

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.CardPay,
                refId: window.Moyasar.ref,
            },
        });

        PaymentAPIManager.getInstance()
            .payMoyasarCreateIntent({
                id: sessionId,
                diningSessionID,
                tipAmount: tipStr,
                gatewayID: gatewayId,
                reference: window.Moyasar.ref,
                statementDescriptor,
            })
            .then((res) => {
                if (!isElemValid()) {
                    window.Moyasar.initialized = false;
                    return;
                }

                const callbackUrl = getCallbackUrl({
                    ref: window.Moyasar.ref,
                    method: name,
                    paymentElement: PaymentElementEnum.CardPay,
                    sid: sessionId,
                    tip: tipStr,
                    amount: amountStr,
                    currencySymbol: vendor.country.currencySymbol,
                    dsi: diningSessionID,
                    gwid: gatewayId,
                    lang: currentLang.current || lang,
                    traceId: traceStart?.traceId,
                });

                const paymentMethods: IMethods[] = [];
                if (!config.hideCardPay) paymentMethods.push('creditcard');
                if (!config.hideApplePay) paymentMethods.push('applepay');
                if (config.enableStcPay) paymentMethods.push('stcpay');

                window.Moyasar.intentID = res.data.intentID || '';
                window.Moyasar.onBeforePayment = onBeforePayment;
                window.Moyasar.tip = tip;

                window.Moyasar.init({
                    amount: total * 100 + 0.5,
                    callback_url: callbackUrl.pending,
                    currency: vendor.country.currencyCode?.toUpperCase() || 'SAR',
                    description: 'Payment for order',
                    element: '.mysr-form',
                    fixed_width: false,
                    publishable_api_key: config?.publishableKey,
                    methods: paymentMethods,
                    apple_pay: {
                        country: 'SA',
                        supported_countries: supportedCountries,
                        label: 'qlub',
                        validate_merchant_url: 'https://api.moyasar.com/v1/applepay/initiate',
                    },
                    language: currentLang.current || lang,
                    statement_descriptor: statementDescriptor,

                    on_completed: (paymentObj: PaymentObject) => {
                        return submitHandler(
                            paymentObj,
                            sessionId,
                            window.Moyasar.ref,
                            window.Moyasar.intentID,
                        ).finally(() => {
                            setLoading(false);
                        });
                    },
                    on_failure: () => {
                        setLoading(false);
                        onUnlockPayment();
                    },
                    on_initiating: () => {
                        setLoading(true);
                        return updateInvoice(
                            sessionId,
                            window.Moyasar.ref,
                            window.Moyasar.intentID,
                            window.Moyasar.tip,
                        ).then(() => {
                            return window.Moyasar.onBeforePayment({
                                gatewayId,
                                paymentElement: PaymentElementEnum.CardPay,
                                tip: window.Moyasar.tip,
                            }).then((ok) => {
                                if (!ok) {
                                    setLoading(false);
                                }
                                return ok;
                            });
                        });
                    },
                    direction: theme.direction,
                    metadata: {
                        intentID: res.data?.intentID || '',
                        reference: window.Moyasar.ref,
                    },
                });
                setIsInitialized(true);
            })
            .catch((err: any) => {
                onTraceClose?.({
                    error: err,
                    location: 'payMoyasarCreateIntent',
                    traceRef,
                    traceStart,
                });

                showError(err);
                onUnlockPayment();
            });
    };

    useEffect(() => {
        const observer = new MutationObserver((e) => {
            e.forEach((mutation) => {
                if (
                    mutation.addedNodes.length &&
                    mutation.type === 'childList' &&
                    (mutation.target as HTMLElement).classList.contains('mysr-form') &&
                    mutation.target.contains(document.querySelector('[class="mysr-form-button"]'))
                ) {
                    btnRef.current = document.querySelector('[class="mysr-form-button"]') as HTMLButtonElement;
                    if (btnRef.current) {
                        btnRef.current.style.display = 'none';
                    }
                }
            });
        });

        observer.observe(document.body, { childList: true, subtree: true });

        return () => {
            observer.disconnect();
        };
    }, []);

    const total = sumAmounts(currencyPrecision, amount, tip);

    useEffect(() => {
        const element = document.getElementById('mysr-form-form-el');

        if (!window.Moyasar || !element) {
            return;
        }

        if (window.Moyasar && tip + amount > 0 && window.Moyasar.initialized) {
            window.Moyasar.setAmount(Math.round(total * 100));
            window.Moyasar.tip = tip;
        } else if (!window.Moyasar.initialized) {
            window.Moyasar.initialized = true;
            renderMoyasar();
        }
    }, [tip, amount]);

    useEffect(() => {
        currentLang.current = lang;
        if (!window.Moyasar) {
            return;
        }
        renderMoyasar();
    }, [lang]);

    useEffect(() => {
        if (isInitialized && !config.hideCardPay) {
            onPgRegister?.({
                pgId: gatewayId,
                elem: PaymentElementEnum.CardPay,
                icon: selectorIcon,
                name: t(selectorName),
                buttonElement: (
                    <PayButtonElement
                        disabled={disable || loading}
                        loading={loading}
                        size="large"
                        variant="contained"
                        fullWidth
                        onClick={() => triggerOriginalButton()}
                    />
                ),
            });
        }
    }, [lang, loading, disable, isInitialized]);

    return (
        <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}>
            <Head>
                <link rel="stylesheet" type="text/css" href="https://cdn.moyasar.com/mpf/1.9.0/moyasar.css" />
            </Head>
            {total === 0 ? (
                <div className={styles.hint}>{t('Amount cannot be zero')}</div>
            ) : (
                <>
                    <div className="mysr-form" />

                    {!hasPgGroup && (
                        <PayButtonElement
                            disabled={disable || loading}
                            loading={loading}
                            size="large"
                            variant="contained"
                            fullWidth
                            onClick={() => triggerOriginalButton()}
                            showConfirmText
                        />
                    )}
                </>
            )}

            <Scripts id="polyfill" src="https://polyfill.io/v3/polyfill.min.js?features=fetch" />

            <Scripts src="https://cdn.moyasar.com/mpf/1.11.0/moyasar.js" onReady={renderMoyasar} />
        </PaymentWrapper>
    );
};

export default PayMoyasar;
