/*
 * Creation Time: December 28 - 2022
 * Created By: yasincelebi
 * Name: index.tsx
 * Copyright 2022 customer-web-app
 */

import { FC } from 'react';

interface IProps {
    hasPgGroup: boolean;
    visible?: boolean;
    children: React.ReactNode;
}

const PaymentWrapper: FC<IProps> = ({ hasPgGroup, visible, children }) => {
    const enableSelector = hasPgGroup;
    if (!children) {
        return null;
    }

    return (
        <div
            style={{
                display: !enableSelector || visible ? 'block' : 'none',
            }}
        >
            {children}
        </div>
    );
};

export default PaymentWrapper;
