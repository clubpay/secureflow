/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: index.tsx
 * Copyright 2023 customer-web-app
 */

import { Typography, Box, Skeleton } from '@mui/material';
import { AddCircleRounded, DeleteRounded } from '@mui/icons-material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useContext, useEffect, useMemo, useState } from 'react';
import {
    AmericanExpressLogoIcon,
    MasterpassLogo,
    VisaLogoIcon,
    MasterCardIcon,
} from '@clubpay/customer-common-module/src/component/SVG';

import { Card, Divider } from '@qlub-dev/qlub-kit';
import { MasterpassCardType } from '../../types';
import { MasterpassActionTypeEnum, MasterpassContext } from '../../context';
import PayButtonElement from '../../../PayButtonElement';
import { detectCardType } from '../../utils/cardBrand';
import { useGetCards } from '../../hooks/useGetCards';

import styles from './index.module.scss';

export interface IProps {
    handleDelete: (cardID: string, Name: string) => void;
    currencySymbol: string;
    handlePay: () => void;
    isSplitted: boolean;
    reference: string;
    diningSessionID: string;
    sessionId: string;
    gatewayId: string;
    total: number;
    tip?: number;
}

const CardSelect = ({
    handleDelete,
    total,
    handlePay,
    isSplitted,
    diningSessionID,
    sessionId,
    gatewayId,
    tip,
}: IProps) => {
    const { t } = useTranslation('common');
    const { state, dispatch } = useContext(MasterpassContext);
    const [loading, setLoading] = useState(false);
    const { getCards } = useGetCards({ gatewayID: gatewayId, diningSessionID, sessionId });
    const [formattedTotal, setFormattedTotal] = useState('');

    useEffect(() => {
        setLoading(true);
        getCards().finally(() => setLoading(false));
    }, []);

    const addNewCard = () => {
        dispatch({ type: MasterpassActionTypeEnum.ADD_NEW_CARD });
    };

    const selectCardHandler = (cardID: string) => {
        dispatch({ type: MasterpassActionTypeEnum.CHECK_CARD, payload: { cardID } });
    };

    const cardDeleteHandler = (cardID: string, name: string) => {
        if (confirm(`${name} isimli kartı silmek ister misiniz?`)) {
            handleDelete(cardID, name);
        }
    };

    useEffect(() => {
        const finalTotal = total.toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' });
        setFormattedTotal(finalTotal);
    }, [total]);

    const cards = useMemo(() => {
        const getCardIcon = (type: string) => {
            switch (type) {
                case 'visa':
                    return <VisaLogoIcon />;
                case 'mastercard':
                    return <MasterCardIcon />;
                case 'amex':
                    return <AmericanExpressLogoIcon />;
                default:
                    return <MasterpassLogo />;
            }
        };
        return (
            state.cards?.map((card) => {
                return {
                    ...card,
                    icon: getCardIcon(detectCardType(card.mask)),
                };
            }) || []
        );
    }, [state.cards]);

    return (
        <div className={styles.wrapper}>
            <div className={styles.cardsContainer}>
                {loading && (
                    <Box
                        sx={{
                            display: 'flex',
                            gap: '16px',
                            flexDirection: 'column',
                        }}
                    >
                        <Skeleton variant="rounded" width="100%" height={40} />
                        <Skeleton variant="rounded" width="100%" height={40} />
                        <Skeleton variant="rounded" width="100%" height={40} />
                    </Box>
                )}
                {!loading &&
                    cards.map((card: MasterpassCardType) => {
                        return (
                            <Card
                                customIcon={card.icon}
                                selected={card.selected}
                                label={`${card.mask} (${card.Name})`}
                                key={card.UniqueId}
                                iconPosition="left"
                                onClick={() => selectCardHandler(card.UniqueId)}
                                buttons={[
                                    {
                                        onClick: () => cardDeleteHandler(card.UniqueId, card.Name),
                                        disabled: false,
                                        icon: <DeleteRounded />,
                                    },
                                ]}
                                cardTextOverrides={{
                                    display: 'inline',
                                    whiteSpace: 'nowrap',
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis',
                                }}
                                selectCardOverrides={{ minWidth: 0 }}
                            />
                        );
                    })}
                <div onClick={addNewCard} className={styles.addNewCard}>
                    <AddCircleRounded color="primary" />
                    <span>{t('Add a new card')}</span>
                </div>
            </div>

            <Divider />
            <div className={styles.bottomSection}>
                <Box>
                    <Typography className={styles.youPaying}>{t('You are paying')}</Typography>
                    <Typography className={styles.taxes}>
                        {tip && tip > 0
                            ? t('Includes tip, taxes and charges')
                            : t('Inclusive of all taxes and charges')}
                    </Typography>
                </Box>
                <Typography className={styles.amount}>{`${formattedTotal}`}</Typography>
            </div>
            <div className={styles.buttonWrapper}>
                <PayButtonElement
                    disabled={Boolean(!state.cards?.find((e: any) => e.selected)) || state.loading}
                    variant="contained"
                    size="large"
                    type="submit"
                    id="pay-bill"
                    fullWidth
                    onClick={handlePay}
                    loading={state.loading}
                >
                    {isSplitted ? t('Pay your share') : t('Pay full bill')}
                </PayButtonElement>
            </div>
        </div>
    );
};
export default CardSelect;
