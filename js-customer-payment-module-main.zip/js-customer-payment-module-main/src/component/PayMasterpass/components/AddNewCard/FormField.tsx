/*
 * Creation Time: February 2 - 2023
 * Created By: yasincelebi
 * Name: FormField.tsx
 * Copyright 2023 customer-web-app
 */

import classNames from 'classnames';
import React from 'react';
import { Typography } from '@qlub-dev/qlub-kit';
import NoOutlinedInput from '@qlub-dev/qlub-kit/dist/components/NoOutlinedInput';

import styles from './index.module.scss';

interface IProps {
    label: string;
    placeholder?: string;
    name: string;
    error?: string;
    touched?: boolean;
    setFieldValue: (name: string, value: string) => void;
    handleBlur: (e: React.FocusEvent<HTMLInputElement>) => void;
    value: string;
}

const FormField = ({ label, name, error, touched, setFieldValue, handleBlur, placeholder, value }: IProps) => {
    return (
        <>
            <NoOutlinedInput
                variant="outlined"
                placeholder={placeholder || label}
                fullWidth
                label={label}
                onChange={(e) => setFieldValue(name, e.target.value)}
                onBlur={handleBlur}
                sx={{
                    fieldset: {
                        borderColor: error && touched ? 'var(--destructive-text) !important' : 'var(--iris) !important',
                        borderRadius: '8px',
                    },
                }}
                name={name}
                className={classNames({
                    [styles.hasError]: error && touched,
                })}
                value={value}
                inputProps={{
                    id: name,
                }}
                error={Boolean(error && touched)}
            />

            {error && touched && (
                <Typography typo="caption_overline" className={styles.error}>
                    {error}
                </Typography>
            )}
        </>
    );
};

export default FormField;
