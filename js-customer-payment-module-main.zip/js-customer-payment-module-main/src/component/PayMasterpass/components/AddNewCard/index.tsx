/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: index.tsx
 * Copyright 2023 customer-web-app
 */

import React, { useContext, useRef, useState } from 'react';
import Box from '@mui/material/Box';
import { Form, Formik, FormikProps } from 'formik';

import * as Yup from 'yup';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { number as cardNumberValidator, expirationDate as expirationDateValidator } from 'card-validator';
import { CustomerContainer, Typography, Divider, CategoryCard } from '@qlub-dev/qlub-kit';
import { IAddNewCardFormValues } from '../../types';
import { creditCardFormat, expirationDateFormat, getAdditionalParameters, removeSlashesAndReverse } from '../../utils';
import FormField from './FormField';
import { useMasterpassAddNewCardTranslation } from '../../hooks/useMasterpassTranslation';
import PayButtonElement from '../../../PayButtonElement';
import { MasterpassActionTypeEnum, MasterpassContext } from '../../context';
import Masterpass from '../../lib/masterpass';
import { MASTERPASS_PF_BANK_ICA, MASTERPASS_RESPONSE_CODE } from '../../const';
import { useMasterpassAPI } from '../../api';
import { useMasterpassError } from '../../hooks/useMasterpassError';
import { IMasterpassGateway } from '../../../../repository/type/paymentGateway';

import styles from './index.module.scss';
import { usePgEvent } from '../../../../hook/usePgEvent';

export interface IProps {
    amount: number;
    tip: number;
    referenceNo: string;
    diningSessionID: string;
    sessionId: string;
    currencyPrecision?: number;
    gatewayId: string;
    total: number;
    name: string;
    vendor: IRestaurant;
    config: IMasterpassGateway;
}

const initialValues: IAddNewCardFormValues = {
    cardNumber: '',
    label: '',
    expirationDate: '',
};

const AddNewCard = ({
    amount,
    tip,
    referenceNo,
    diningSessionID,
    sessionId,
    currencyPrecision,
    gatewayId,
    total,
    name,
    vendor,
    config,
}: IProps) => {
    const { t } = useTranslation('common');
    const [expirationDate, setExpirationDate] = useState('');
    const [cardNumber, setCardNumber] = useState('');
    const formRef = useRef<FormikProps<IAddNewCardFormValues>>(null);
    const { state, dispatch } = useContext(MasterpassContext);
    const { getCallbackUrl } = useConfirmCallback();
    const { formErrors, safetyTips, formLabels, amountTips, buttonTexts } = useMasterpassAddNewCardTranslation(tip);
    const { masterPassGenerateToken } = useMasterpassAPI();
    const { showError } = useMasterpassError();

    const { sendEvent } = usePgEvent({
        pgName: `${name}_${PaymentElementEnum.CardPay}`.toLowerCase(),
        diningSessionId: diningSessionID,
        restaurantName: vendor.name,
    });

    const addNewCardSchema = Yup.object().shape({
        label: Yup.string().required(formErrors.label.required),
        cardNumber: Yup.string()
            .min(13, formErrors.cardNumber.invalid)
            .required(formErrors.cardNumber.required)
            .test('cardNumber', formErrors.cardNumber.invalid, (value) => {
                if (!value) {
                    return false;
                }
                return cardNumberValidator(creditCardFormat(value).formatted).isValid;
            }),
        expirationDate: Yup.string()
            .required(formErrors.expirationDate.required)
            .min(5, formErrors.expirationDate.invalid)
            .test('verifyExpDate', formErrors.expirationDate.invalid, (value) => {
                if (!value) {
                    return true;
                }

                return expirationDateValidator(expirationDateFormat(value).formatted).isValid;
            }),
    });

    const registerAndPurchase = async () => {
        dispatch({
            type: MasterpassActionTypeEnum.LOADING,
        });

        try {
            const returnUrl = getCallbackUrl({
                ref: referenceNo,
                method: name,
                paymentElement: PaymentElementEnum.CardPay,
                tip,
                dsi: diningSessionID,
                sid: sessionId,
                amount: amount.toFixed(currencyPrecision || 0),
                currencySymbol: vendor?.country.currencySymbol,
            });

            const masterpassResponse = await masterPassGenerateToken({
                gatewayID: gatewayId,
                verbose: true,
                reference: referenceNo,
                diningSessionID,
                id: sessionId,
                computeReturnURL: true,
                forRegisterCard: true,
                failURL: returnUrl.fail,
                successURL: returnUrl.success,
                tipAmount: tip.toFixed(currencyPrecision || 0),
            });

            const totalAmount = (total * 100).toFixed(0);
            const additionalParameters = getAdditionalParameters({
                bankIca: config?.bankICA || MASTERPASS_PF_BANK_ICA.ipara,
                total: totalAmount,
                restaurantUnique: vendor.unique,
            });

            Masterpass.getInstance().purchaseAndRegister(
                {
                    referenceNo,
                    msisdn: masterpassResponse?.customerPhone,
                    amount: totalAmount,
                    accountAliasName: formRef.current?.values.label || '',
                    expiryDate: removeSlashesAndReverse(expirationDate),
                    token: masterpassResponse?.token,
                    orderNo: masterpassResponse?.orderID,
                    rtaPan: cardNumber.replace(/\s/g, ''),
                    userId:
                        config?.bankICA === MASTERPASS_PF_BANK_ICA.sipay
                            ? masterpassResponse.customerID
                            : masterpassResponse.customerPhone,
                    ...additionalParameters,
                },
                (responseCode, response) => {
                    if (response?.responseCode === MASTERPASS_RESPONSE_CODE.SUCCESS_REDIRECT_TO_3D) {
                        const returnURL = masterpassResponse?.computedCallbackURL;
                        if (!returnURL) {
                            showError({}, response?.responseDescription);
                            dispatch({
                                type: MasterpassActionTypeEnum.RESET,
                            });
                        }
                        sendEvent('payment_initialized', { status: '3ds' });
                        window.location.assign(`${response?.url3D}&returnUrl=${returnURL}`);
                    } else if (
                        [MASTERPASS_RESPONSE_CODE.OTP, MASTERPASS_RESPONSE_CODE.OTHER_OTP].includes(
                            response?.responseCode,
                        )
                    ) {
                        dispatch({ type: MasterpassActionTypeEnum.MASTERPASS_BANK_OTP_CODE });
                        sendEvent('payment_initialized', { status: 'otp' });
                    } else {
                        sendEvent('payment_initialized', { status: 'failed' });
                        showError({}, response?.responseDescription);
                        dispatch({ type: MasterpassActionTypeEnum.RESET });
                    }
                },
            );
        } catch (err: any) {
            dispatch({
                type: MasterpassActionTypeEnum.RESET,
            });

            const errData = err?.response?.data || err || {};

            showError(errData, err?.message);
        }
    };

    const handleMaskDate = (text: string) => {
        const { formatted } = expirationDateFormat(text);

        setExpirationDate(formatted);
    };

    const formatCardNumber = (value: string) => {
        const { formatted } = creditCardFormat(value);

        setCardNumber(formatted);
    };

    return (
        <CustomerContainer centered direction="column" className={styles.formContainer}>
            <Box sx={{ margin: '0 0 32px' }}>
                <CategoryCard
                    categoryName={safetyTips.title}
                    description={safetyTips.content}
                    info={t('Important text.')}
                />
            </Box>
            <Formik
                innerRef={formRef}
                initialValues={initialValues}
                onSubmit={registerAndPurchase}
                validationSchema={addNewCardSchema}
                validateOnMount={false}
                enableReinitialize
            >
                {({ errors, touched, handleBlur, setFieldValue, values }) => {
                    return (
                        <Form className={styles.form}>
                            <div className={styles.inputs}>
                                <Box>
                                    <FormField
                                        label={formLabels.label}
                                        name="label"
                                        error={errors.label}
                                        touched={touched.label}
                                        setFieldValue={setFieldValue}
                                        handleBlur={handleBlur}
                                        value={values.label}
                                    />
                                </Box>
                                <Box>
                                    <FormField
                                        label={formLabels.cardNumber}
                                        name="cardNumber"
                                        placeholder="4444 4444 4444 4444"
                                        error={errors.cardNumber}
                                        touched={touched.cardNumber}
                                        setFieldValue={(e, value) => {
                                            formatCardNumber(value);
                                            setFieldValue('cardNumber', value);
                                        }}
                                        handleBlur={handleBlur}
                                        value={cardNumber}
                                    />
                                </Box>
                                <Box>
                                    <FormField
                                        label={formLabels.expirationDate}
                                        name="expirationDate"
                                        placeholder="01/01"
                                        error={errors.expirationDate}
                                        touched={touched.expirationDate}
                                        setFieldValue={(e, value) => {
                                            handleMaskDate(value);
                                            setFieldValue('expirationDate', value);
                                        }}
                                        handleBlur={handleBlur}
                                        value={expirationDate}
                                    />
                                </Box>
                            </div>
                            <Divider type="small" />
                            <div className={styles.bottomSection}>
                                <Box>
                                    <Typography>{amountTips.title}</Typography>
                                    <Typography className={styles.taxInfo}>{amountTips.taxes}</Typography>
                                </Box>
                                <Typography
                                    className={styles.fontWeightSemi}
                                >{`${vendor?.country.currencySymbol} ${total}`}</Typography>
                            </div>

                            <div className={styles.buttonAndLogo}>
                                <PayButtonElement
                                    loading={state.loading}
                                    disabled={state.loading}
                                    variant="contained"
                                    size="large"
                                    type="submit"
                                    id="continue"
                                    fullWidth
                                >
                                    {buttonTexts.continue}
                                </PayButtonElement>
                            </div>
                        </Form>
                    );
                }}
            </Formik>
        </CustomerContainer>
    );
};

export default AddNewCard;
