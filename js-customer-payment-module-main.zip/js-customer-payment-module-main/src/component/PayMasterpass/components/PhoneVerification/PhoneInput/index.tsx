/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: index.tsx
 * Copyright 2023 customer-web-app
 */

import MuiPhoneNumber from 'material-ui-phone-number';
import React, { useContext, useMemo } from 'react';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Script from 'next/script';
import { Label, Typography } from '@qlub-dev/qlub-kit';
import ReCaptcha from '../../../lib/reCaptcha';
import { MasterpassActionTypeEnum, MasterpassContext } from '../../../context';
import PayButtonElement from '../../../../PayButtonElement';

import styles from './index.module.scss';

export interface IProps {
    countryCode?: string;
    onChangePhone: (phone: any) => any;
    confirmPhone: (token: string) => any;
}

const _OLD_PhoneInput = ({ countryCode, onChangePhone, confirmPhone }: IProps) => {
    const { t } = useTranslation('common');
    const { state, dispatch } = useContext(MasterpassContext);
    const onChange = (num: any) => {
        dispatch({ type: MasterpassActionTypeEnum.SET_ERROR, payload: { errors: { phone: false } } });
        onChangePhone(num);
    };

    const handleConfirm = () => {
        ReCaptcha.getInstance()
            .getToken()
            .then((reCaptcha: string) => {
                confirmPhone(reCaptcha);
            })
            .catch(() => {
                console.log('reCaptcha error');
            });
    };

    const onLoad = () => {
        ReCaptcha.getInstance()
            .render('recaptcha')
            .then(() => {
                console.log('reCaptcha loaded');
            });
    };

    const PrivacyAndTerms = useMemo(() => {
        return {
            privacy: (
                <a
                    target="_blank"
                    tabIndex={-1}
                    href="https://policies.google.com/privacy"
                    rel="noopener noreferrer"
                    style={{ color: 'var(--iris)' }}
                >
                    {t('Privacy Policy')}
                </a>
            ),
            terms: (
                <a
                    target="_blank"
                    style={{ color: 'var(--iris)' }}
                    tabIndex={-1}
                    href="https://policies.google.com/terms"
                    rel="noopener noreferrer"
                >
                    {t('Terms of Service')}
                </a>
            ),
        };
    }, [t]);

    const renderGooglePrivacyPolicy = () => {
        return interpolateT(
            'This site is protected by reCAPTCHA and the Google <privacy> and <terms> apply.',
            PrivacyAndTerms,
        );
    };

    return (
        <>
            <Script
                onLoad={onLoad}
                src={`https://www.google.com/recaptcha/api.js?render=${process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY}`}
            />
            <Label label={t('Phone Number')} htmlFor="phone-number" hasError={state.errors?.phone}>
                <MuiPhoneNumber
                    disableAreaCodes
                    fullWidth
                    focused
                    InputProps={{
                        disableUnderline: true,
                        id: 'phone-number',
                    }}
                    onChange={onChange}
                    countryCodeEditable={false}
                    error={state.errors?.phone}
                    className={styles.input}
                    autoFormat
                    autoFocus
                    defaultCountry={countryCode?.toLowerCase()}
                    sx={{
                        '& svg': {
                            height: '1em', // fix safari flag issue ref: https://github.com/alexplumb/material-ui-phone-number/issues/111
                        },
                    }}
                />
            </Label>
            {state.errors?.phone && <div className={styles.error}>{t('Enter valid phone number to continue')}</div>}
            <Typography marginTop="0.3rem" typo="caption_overline" style={{ color: 'var(--onSurfaceColors-disabled)' }}>
                {renderGooglePrivacyPolicy()}
            </Typography>
            <PayButtonElement
                variant="contained"
                size="large"
                fullWidth
                type="submit"
                onClick={handleConfirm}
                sx={{ marginTop: '1rem' }}
                disabled={state.loading}
                loading={state.loading}
            >
                {t('Confirm phone')}
            </PayButtonElement>
            <div id="recaptcha" />
        </>
    );
};

export default _OLD_PhoneInput;
