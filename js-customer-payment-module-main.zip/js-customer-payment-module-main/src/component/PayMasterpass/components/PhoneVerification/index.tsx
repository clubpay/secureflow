/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: index.tsx
 * Copyright 2023 customer-web-app
 */

import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Box from '@mui/material/Box';
import React, { useState } from 'react';
import PhoneInput from './PhoneInput';

import styles from './index.module.scss';

export interface IProps {
    confirmPhone: (phone: string) => any;
}

const _OLD_PhoneVerification = ({ confirmPhone }: IProps) => {
    const { t } = useTranslation('common');
    const [phoneInfo, setPhoneInfo] = useState<string | undefined>(undefined);

    const handlePhoneChange = (phone: string) => {
        setPhoneInfo(phone);
    };

    const handleConfirm = () => {
        if (phoneInfo) {
            confirmPhone(phoneInfo);
        }
    };

    return (
        <div className={styles.phoneVerificationContainer}>
            <div className={styles.description}>{t('Enter your phone number in order to use Masterpass')}</div>
            <Box display="flex" flexDirection="column">
                <PhoneInput confirmPhone={handleConfirm} countryCode="TR" onChangePhone={handlePhoneChange} />
            </Box>
        </div>
    );
};

export default _OLD_PhoneVerification;
