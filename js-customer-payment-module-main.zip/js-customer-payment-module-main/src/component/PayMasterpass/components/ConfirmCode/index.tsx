/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: index.tsx
 * Copyright 2023 customer-web-app
 */

import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Box from '@mui/material/Box';
import ConfirmCodeInput from './ConfirmCodeInput';

import styles from './index.module.scss';

export interface IProps {
    confirmCode: (e: string) => void;
    description: string;
    resendSMS: () => void;
    hasError?: boolean;
    resetInput: () => void;
    length: number;
}

const ConfirmCode = ({ confirmCode, resendSMS, hasError, resetInput, length }: IProps) => {
    const { t } = useTranslation('common');
    return (
        <div className={styles.confirmCodeContainer}>
            <Box display="flex" flexDirection="column">
                <ConfirmCodeInput
                    hasError={hasError}
                    resendSMS={resendSMS}
                    label={t('Code')}
                    confirmCode={confirmCode}
                    length={length}
                    resetInput={resetInput}
                />
            </Box>
        </div>
    );
};

export default ConfirmCode;
