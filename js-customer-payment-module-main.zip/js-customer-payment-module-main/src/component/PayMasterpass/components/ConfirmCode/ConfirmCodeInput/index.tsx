/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: index.tsx
 * Copyright 2023 customer-web-app
 */

import React, { useContext, useState } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import OtpSection from '@clubpay/customer-common-module/src/component/Login/OTP/OtpV2';
import { MasterpassContext } from '../../../context';
import PayButtonElement from '../../../../PayButtonElement';

export interface IProps {
    label: string;
    length: number;
    confirmCode: (e: string) => void;
    resendSMS: () => void;
    hasError?: boolean;
    resetInput: () => void;
}

const ConfirmCodeInput = ({ length, confirmCode, resendSMS, hasError }: IProps) => {
    const { t } = useTranslation('common');
    const { isReachedLimit } = useContext(MasterpassContext);
    const [error, setError] = useState(hasError || false);

    const { state } = useContext(MasterpassContext);
    const [code, setCode] = useState('');

    const resendCode = () => {
        setCode('');
        resendSMS();
    };

    const handleConfirm = () => {
        const otpOnlyNumbers = code.replace(/\D/g, '');

        if (otpOnlyNumbers.length !== length) {
            setError(true);
        } else {
            confirmCode(otpOnlyNumbers);
            setError(false);
        }
    };

    return (
        <>
            <OtpSection
                isReachedLimit={isReachedLimit}
                numInputs={length}
                code={code}
                onSetCode={(c) => {
                    setCode(c);
                }}
                backButton={false}
                showResendCode
                resendSms={resendCode}
                error={error}
                resendSmsCooldown={30}
            />

            <PayButtonElement
                size="large"
                variant="contained"
                fullWidth
                type="submit"
                id="confirm-code"
                onClick={handleConfirm}
                sx={{ marginBlock: '1rem', fontWeight: '700 !important' }}
                loading={state.loading}
                disabled={state.loading}
            >
                {t('Confirm Code')}
            </PayButtonElement>
        </>
    );
};

export default ConfirmCodeInput;
