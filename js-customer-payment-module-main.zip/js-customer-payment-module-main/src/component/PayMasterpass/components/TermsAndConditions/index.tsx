import React, { useState } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import 'react-pdf/dist/esm/Page/TextLayer.css';
import 'react-pdf/dist/esm/Page/AnnotationLayer.css';

pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

const TermsAndConditions = () => {
    const [numPages, setNumPages] = useState<number>();

    const options = {
        cMapUrl: '/cmaps/',
        standardFontDataUrl: '/standard_fonts/',
    };
    return (
        <div id="pdf-container">
            <Document
                renderMode="canvas"
                file="https://qlub-cloud.s3.ap-southeast-1.amazonaws.com/masterpass-terms-and-conditions-tr.pdf"
                onLoadSuccess={({ numPages: pageCount }) => setNumPages(pageCount)}
                options={options}
            >
                {Array.from(new Array(numPages), (_, index) => (
                    <Page
                        key={`page_${index + 1}`}
                        pageNumber={index + 1}
                        width={document?.getElementById('pdf-container')?.offsetWidth}
                    />
                ))}
            </Document>
        </div>
    );
};

export default TermsAndConditions;
