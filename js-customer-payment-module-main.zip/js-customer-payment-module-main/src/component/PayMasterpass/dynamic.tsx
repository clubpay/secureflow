/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: dynamic.tsx
 * Copyright 2023 customer-web-app
 */

import React, { useContext, useEffect, useMemo, useState } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Scripts from 'next/script';
import { useConfirmCallback, usePaymentTimeout } from '@clubpay/customer-common-module/src/hook/payment';
import { HTTP_STATUS_CODES } from '@clubpay/customer-common-module/src/repository/axios/constants';
import { Button, SwipeableCustomerDrawer } from '@qlub-dev/qlub-kit';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { MasterpassLogo } from '@clubpay/customer-common-module/src/component/SVG';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { getAuth } from '@clubpay/customer-common-module/src/service/session/auth';
import AuthManager from '@clubpay/customer-common-module/src/repository/auth';
import Masterpass from './lib/masterpass';
import { useMasterpassAPI } from './api';
import { getAdditionalParameters, getFirstSixDigits, isDev } from './utils';
import {
    MASTERPASS_ACCOUNT_STATUS,
    MASTERPASS_BASE_ENDPOINT,
    MASTERPASS_PF_BANK_ICA,
    MASTERPASS_RESPONSE_CODE,
} from './const';
import PaymentAPIManager from '../../repository';
import { useMasterpassError } from './hooks/useMasterpassError';
import { MasterpassActionTypeEnum, MasterpassContext, MasterpassProvider } from './context';
import PayButtonElement from '../PayButtonElement';
import PaymentWrapper from '../PaymentWrapper';
import { IMasterpassGateway } from '../../repository/type/paymentGateway';
import ConfirmCode from './components/ConfirmCode';
import CardSelect from './components/CardSelectContainer';
import AddNewCard from './components/AddNewCard';
import { useGetCards } from './hooks/useGetCards';
import { MasterpassStepEnum, VerificationTypeEnum } from './types';
import TermsAndConditions from './components/TermsAndConditions';
import styles from './index.module.scss';
import { usePgEvent } from '../../hook/usePgEvent';

export interface IMasterpassProps extends IPGProps {
    remainingAmount: number;
    config: IMasterpassGateway;
}

const IS_DEV = isDev();

const PayMasterpass = ({
    diningSessionID,
    sessionId,
    gatewayId,
    amount,
    tip,
    name,
    currencyPrecision,
    disable,
    config,
    vendor,
    url,
    onIndicator,
    onLoad,
    onPgRegister,
    remainingAmount,
    isPgElemVisible,
}: IMasterpassProps) => {
    const { t } = useTranslation('common');
    const [scriptsLoaded, setScriptsLoaded] = useState<boolean>(false);
    const [referenceNo, setReferenceNo] = useState<string>('');
    const { timeoutDone } = usePaymentTimeout({
        indicatorTimeout: config?.indicatorTimeout || 0,
        fallbackTimeout: config?.fallbackTimeout || 0,
        indicatorCallback: onIndicator,
        fallbackCallback: onLoad,
    });
    const { state, dispatch } = useContext(MasterpassContext);
    const { showError } = useMasterpassError();
    const { getCallbackUrl } = useConfirmCallback();
    const { hasPgGroup } = vendor.paymentGatewayList;
    const { masterPassGenerateToken, masterpassGenerateReference } = useMasterpassAPI();
    const { login, isLogin, setDrawerConstants, logout, isAuthorizedUser } = useAuth();
    const { getCards } = useGetCards({ gatewayID: gatewayId, diningSessionID, sessionId });

    const { sendEvent } = usePgEvent({
        pgName: `${name}_${PaymentElementEnum.CardPay}`.toLowerCase(),
        diningSessionId: diningSessionID,
        restaurantName: url.slug,
    });

    const linkCardToClient = async (ref: string) => {
        try {
            const masterpassResponse = await masterPassGenerateToken({
                gatewayID: gatewayId,
                verbose: true,
                reference: ref,
                forRegisterCard: false,
                id: sessionId,
                diningSessionID,
                computeReturnURL: false,
            });

            Masterpass.getInstance().linkCardToClient(
                {
                    referenceNo: ref,
                    token: masterpassResponse?.token,
                    msisdn: masterpassResponse?.customerPhone,
                },
                (responseCode, response) => {
                    if (responseCode !== HTTP_STATUS_CODES.SUCCESS) {
                        throw new Error(response);
                    }
                    if (
                        response?.responseCode === MASTERPASS_RESPONSE_CODE.OTP ||
                        response?.responseCode === MASTERPASS_RESPONSE_CODE.OTHER_OTP
                    ) {
                        dispatch({
                            type: MasterpassActionTypeEnum.MASTERPASS_BANK_OTP_CODE,
                        });
                    } else if (response?.responseCode === MASTERPASS_RESPONSE_CODE.SUCCESS) {
                        dispatch({
                            type: MasterpassActionTypeEnum.HAS_MASTERPASS_ACCOUNT_USED_QLUB,
                        });
                    } else {
                        const errData = response || {};

                        showError(errData, errData?.responseDescription);

                        dispatch({
                            type: MasterpassActionTypeEnum.RESET,
                        });
                    }
                },
            );
        } catch (err: any) {
            dispatch({
                type: MasterpassActionTypeEnum.RESET,
            });

            const errData = err?.response?.data || err || {};

            showError(errData, err?.message);
        }
    };

    const checkMasterPass = (ref: string, token: string, customerPhone: string) => {
        Masterpass.getInstance().checkMasterPass(
            {
                referenceNo: ref,
                token,
                userId: customerPhone,
            },
            (responseCode, response) => {
                if (!response?.accountStatus) {
                    showError({}, response?.responseDescription);
                    dispatch({
                        type: MasterpassActionTypeEnum.CLOSE_DRAWER,
                    });
                    return;
                }
                const accountStatus = getFirstSixDigits(response?.accountStatus) || '';

                if (
                    responseCode === HTTP_STATUS_CODES.SUCCESS &&
                    (response?.responseCode === MASTERPASS_RESPONSE_CODE.SUCCESS || response?.responseCode === '')
                ) {
                    switch (accountStatus) {
                        case MASTERPASS_ACCOUNT_STATUS.HAS_NOT_MASTERPASS_ACCOUNT:
                            dispatch({
                                type: MasterpassActionTypeEnum.ADD_NEW_CARD,
                            });
                            break;
                        case MASTERPASS_ACCOUNT_STATUS.HAS_MASTERPASS_ACCOUNT_USED_QLUB:
                            dispatch({
                                type: MasterpassActionTypeEnum.HAS_MASTERPASS_ACCOUNT_USED_QLUB,
                            });
                            break;
                        case MASTERPASS_ACCOUNT_STATUS.HAS_MASTERPASS_ACCOUNT_NOT_USED_QLUB:
                            linkCardToClient(ref);
                            break;
                        default:
                            dispatch({
                                type: MasterpassActionTypeEnum.CLOSE_DRAWER,
                            });
                            break;
                    }
                } else {
                    showError({}, response?.responseDescription);
                    dispatch({
                        type: MasterpassActionTypeEnum.CLOSE_DRAWER,
                    });
                }
            },
        );
    };

    const isSplitted = useMemo(() => {
        return amount < remainingAmount;
    }, [amount, remainingAmount]);

    const setMasterpassInitialStep = async () => {
        try {
            const reference = await masterpassGenerateReference();

            setReferenceNo(reference);

            const masterpassResponse = await masterPassGenerateToken({
                gatewayID: gatewayId,
                verbose: true,
                reference,
                forRegisterCard: false,
                computeReturnURL: false,
                id: sessionId,
                diningSessionID,
            });
            checkMasterPass(reference, masterpassResponse?.token, masterpassResponse?.customerPhone);
        } catch (error: any) {
            const errData = error?.response?.data || error || {};

            if ([400, 403].includes(errData?.code || 0)) {
                const jwt = getAuth()?.JWTToken;
                if (!jwt) {
                    logout();
                } else {
                    AuthManager.getInstance()
                        .validateToken({
                            JWTToken: jwt,
                        })
                        .then((validateRes) => {
                            if (!validateRes?.validated) {
                                logout();
                            }
                        });
                }
                dispatch({
                    type: MasterpassActionTypeEnum.CLOSE_DRAWER,
                });
                showError(errData, t('Please try again!'));
            } else {
                dispatch({
                    type: MasterpassActionTypeEnum.RESET,
                });
                showError(errData, error?.message);
            }
        }
    };

    const openDrawer = async () => {
        sendEvent('attempt_to_pay');
        dispatch({
            type: MasterpassActionTypeEnum.LOADING,
        });

        setDrawerConstants({
            text: {
                phone: {
                    title: t('Qlub verification'),
                    description: t('Enter your phone number in order to use Masterpass'),
                    buttonText: t('Confirm'),
                },
                otp: {
                    title: t('Qlub verification'),
                    description: t('Enter the code sent to your mobile from qlub'),
                    buttonText: t('Confirm'),
                },
                done: {
                    title: t('Redirecting...'),
                    description: t('Your phone number has been verified. You are being redirected.'),
                    buttonText: '',
                },
            },
            numInputs: 5,

            termsAndConditions: {
                show: true,
                label: t('I have read and examined the clarification text regarding processing of personal data'),
                defaultChecked: true,
                content: <TermsAndConditions />,
            },
        });

        /* const ok = await onBeforePayment({
method: name,
tip,
gatewayId,
paymentElement: PaymentElementEnum.CardPay,
});
if (!ok) {
dispatch({
type: MasterpassActionType.CLOSE_DRAWER,
});
return;
} */

        try {
            if (!isLogin || !isAuthorizedUser) {
                const validated = await login({ closeTimeout: 3000 });

                if (validated) {
                    await setMasterpassInitialStep();
                } else {
                    showError({});
                }
            } else {
                await setMasterpassInitialStep();
            }
        } catch (e: any) {
            dispatch({
                type: MasterpassActionTypeEnum.CLOSE_DRAWER,
            });
            // return;

            // showError({});
        }
    };

    const confirmMasterpassCode = (code: string) => {
        dispatch({
            type: MasterpassActionTypeEnum.LOADING,
        });

        Masterpass.getInstance().sendOTPForm(
            {
                referenceNo,
                validationCode: code,
            },
            (status, response) => {
                if (response.responseCode === MASTERPASS_RESPONSE_CODE.OTP || response.responseCode === '') {
                    dispatch({
                        type: MasterpassActionTypeEnum.HAS_MASTERPASS_ACCOUNT_USED_QLUB,
                    });
                } else {
                    showError({}, response?.responseDescription);
                    dispatch({
                        type: MasterpassActionTypeEnum.RESET,
                    });
                }
            },
        );
    };

    const getTitle = useMemo((): string => {
        let title: string;

        switch (state.step) {
            case MasterpassStepEnum.SELECT_CARD:
                title = t('Select your card and pay');
                break;
            case MasterpassStepEnum.ADD_NEW_CARD:
                title = t('Add new card and pay');
                break;
            default:
            case MasterpassStepEnum.OTP_CODE:
                title = t('Masterpass verification');
                break;
        }

        return title;
    }, [state.step]);

    const getCaption = useMemo((): string => {
        let caption: string;

        switch (state.step) {
            case MasterpassStepEnum.SELECT_CARD:
                caption = t('Select your card and pay');
                break;
            case MasterpassStepEnum.ADD_NEW_CARD:
                caption = t('Add new card and pay');
                break;
            default:
            case MasterpassStepEnum.OTP_CODE:
                caption = t('Enter the code sent to card holder’s mobile number.');
                break;
        }

        return caption;
    }, [state.step]);

    const handlePay = async () => {
        dispatch({
            type: MasterpassActionTypeEnum.LOADING,
        });

        try {
            const returnUrl = getCallbackUrl({
                ref: referenceNo,
                method: name,
                paymentElement: PaymentElementEnum.CardPay,
                tip,
                dsi: diningSessionID,
                sid: sessionId,
                amount: amount.toFixed(currencyPrecision || 0),
                currencySymbol: vendor?.country.currencySymbol,
            });
            const selectedCard = state.cards && state.cards.find((card: any) => card.selected);
            const masterpassResponse = await masterPassGenerateToken({
                gatewayID: gatewayId,
                verbose: true,
                reference: referenceNo,
                diningSessionID,
                id: sessionId,
                computeReturnURL: true,
                forRegisterCard: false,
                failURL: returnUrl.fail,
                successURL: returnUrl.success,
                tipAmount: tip.toFixed(currencyPrecision || 0),
            });

            const totalAmount = (sumAmounts(currencyPrecision, amount, tip) * 100).toFixed(0);
            const additionalParameters = getAdditionalParameters({
                total: totalAmount,
                bankIca: config?.bankICA || MASTERPASS_PF_BANK_ICA.ipara,
                restaurantUnique: vendor.unique,
            });

            Masterpass.getInstance().payWithRegisteredCard(
                {
                    msisdn: masterpassResponse?.customerPhone,
                    token: masterpassResponse?.token,
                    orderNo: masterpassResponse?.orderID,
                    userId:
                        config?.bankICA === MASTERPASS_PF_BANK_ICA.sipay
                            ? masterpassResponse.customerID
                            : masterpassResponse.customerPhone,
                    referenceNo,
                    listAccountName: selectedCard?.Name,
                    amount: totalAmount,
                    ...additionalParameters,
                },
                async (responseCode, response) => {
                    const returnURL = masterpassResponse?.computedCallbackURL;

                    if (response?.responseCode === MASTERPASS_RESPONSE_CODE.SUCCESS_REDIRECT_TO_3D) {
                        sendEvent('payment_initialized', { status: '3ds' });
                        window.location.assign(`${response?.url3D}&returnUrl=${returnURL}`);
                    } else if (
                        [MASTERPASS_RESPONSE_CODE.OTP, MASTERPASS_RESPONSE_CODE.OTHER_OTP].includes(
                            response?.responseCode,
                        )
                    ) {
                        dispatch({ type: MasterpassActionTypeEnum.MASTERPASS_BANK_OTP_CODE });
                        sendEvent('payment_initialized', { status: 'otp' });
                    } else {
                        sendEvent('payment_initialized', { status: 'failed' });
                        showError({}, response?.responseDescription);
                        dispatch({ type: MasterpassActionTypeEnum.RESET });
                    }
                },
            );
        } catch (error: any) {
            const errData = error?.response?.data || error || {};

            showError(errData, error?.message);
            dispatch({ type: MasterpassActionTypeEnum.RESET });
        }
    };

    const deleteCard = async (cardID: string, cardName: string) => {
        dispatch({
            type: MasterpassActionTypeEnum.LOADING,
        });

        const masterpassResponse = await masterPassGenerateToken({
            gatewayID: gatewayId,
            verbose: true,
            reference: referenceNo,
            forRegisterCard: false,
            id: sessionId,
            diningSessionID,
            computeReturnURL: false,
        });

        Masterpass.getInstance().deleteCard(
            {
                referenceNo,
                msisdn: masterpassResponse?.customerPhone,
                token: masterpassResponse?.token,
                accountAliasName: cardName,
            },
            () => {
                dispatch({
                    type: MasterpassActionTypeEnum.HAS_MASTERPASS_ACCOUNT_USED_QLUB,
                });
            },
        );

        getCards();
    };

    useEffect(() => {
        dispatch({
            type: MasterpassActionTypeEnum.RESET_SMS_LIMIT,
        });

        if (!state.isOpenDrawer) {
            Masterpass.removeForms(true);
        }
    }, [state.isOpenDrawer]);

    const resendCodeFromBank = async () => {
        dispatch({
            type: MasterpassActionTypeEnum.LOADING,
        });

        dispatch({ type: MasterpassActionTypeEnum.INCREASE_SMS_LIMIT });

        try {
            const token = Masterpass.getInstance().getLastToken();

            Masterpass.getInstance().resendOTP(token, 'tur', (responseCode, response) => {
                if (
                    [MASTERPASS_RESPONSE_CODE.OTP, MASTERPASS_RESPONSE_CODE.OTHER_OTP].includes(response?.responseCode)
                ) {
                    dispatch({
                        type: MasterpassActionTypeEnum.RESET,
                    });
                } else if (response?.responseCode === MASTERPASS_RESPONSE_CODE.HAS_REACHED_THE_SMS_LIMIT) {
                    showError({}, response?.responseDescription);
                    dispatch({
                        type: MasterpassActionTypeEnum.RESET,
                    });
                    dispatch({
                        type: MasterpassActionTypeEnum.REACHED_SMS_LIMIT,
                    });
                } else {
                    showError({}, response?.responseDescription);
                    dispatch({
                        type: MasterpassActionTypeEnum.RESET,
                    });
                }
            });
        } catch (error: any) {
            const errData = error?.response?.data || error || {};

            showError(errData, error?.message);
            dispatch({
                type: MasterpassActionTypeEnum.RESET,
            });
        }
    };

    const total = sumAmounts(currencyPrecision, amount, tip);
    const resetInput = (errorName: string) => {
        dispatch({ type: MasterpassActionTypeEnum.SET_ERROR, payload: { errors: { [errorName]: false } } });
    };
    const renderMasterpassSteps = useMemo(() => {
        switch (state.step) {
            case MasterpassStepEnum.SELECT_CARD:
                return (
                    <CardSelect
                        handlePay={handlePay}
                        handleDelete={deleteCard}
                        total={total}
                        currencySymbol={vendor?.country.currencySymbol || ''}
                        isSplitted={isSplitted}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        reference={referenceNo}
                        gatewayId={gatewayId}
                        tip={tip}
                    />
                );
            case MasterpassStepEnum.ADD_NEW_CARD:
                return (
                    <AddNewCard
                        amount={amount}
                        tip={tip}
                        total={total}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        referenceNo={referenceNo}
                        currencyPrecision={currencyPrecision}
                        gatewayId={gatewayId}
                        name={name}
                        config={config}
                        vendor={vendor}
                    />
                );
            case MasterpassStepEnum.OTP_CODE:
                return (
                    <ConfirmCode
                        hasError={state.errors?.masterpassOTP}
                        resendSMS={resendCodeFromBank}
                        description={t("Enter the code sent to card holder's mobile number.")}
                        confirmCode={confirmMasterpassCode}
                        length={6}
                        resetInput={() => resetInput('masterpassOTP')}
                    />
                );
            case MasterpassStepEnum.BANK_OTP_CODE:
                return (
                    <ConfirmCode
                        resendSMS={resendCodeFromBank}
                        description={t('Enter the code sent to your mobile from bank')}
                        confirmCode={confirmMasterpassCode}
                        hasError={state.errors?.bankOTP}
                        length={6}
                        resetInput={() => resetInput('bankOTP')}
                    />
                );
            default:
                return (
                    <CardSelect
                        handlePay={handlePay}
                        handleDelete={deleteCard}
                        total={total}
                        currencySymbol={vendor?.country.currencySymbol || ''}
                        isSplitted={isSplitted}
                        reference={referenceNo}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        gatewayId={gatewayId}
                    />
                );
        }
    }, [
        state.step,
        state.verificationType,
        state.cards,
        state.errors,
        referenceNo,
        state.hasReachedLimit,
        state.resendedCounter,
        state.isOpenDrawer,
    ]);

    const masterpassLoadHandler = () => {
        onPgRegister?.({
            name: t('Masterpass'),
            icon: <MasterpassLogo />,
            elem: PaymentElementEnum.CardPay,
            pgId: gatewayId,
            placement: 'bottom',
        });

        Masterpass.getInstance().init({
            clientId: config.clientId,
            address: MASTERPASS_BASE_ENDPOINT[config.env],
        });
        setScriptsLoaded(true);
        timeoutDone();
    };

    const unLinkHandler = async () => {
        const reference = await masterpassGenerateReference();
        const masterpassResponse = await masterPassGenerateToken({
            gatewayID: gatewayId,
            verbose: true,
            reference,
            forRegisterCard: false,
            id: sessionId,
            diningSessionID,
            computeReturnURL: false,
        });

        PaymentAPIManager.getInstance()
            .unlinkMasterpass({
                gatewayID: gatewayId,
                reference,
                sendSMS: true,
                token: masterpassResponse?.token,
                smsLanguage: 'tur',
            })
            .then((response) => {
                console.log(response);
                showError({}, 'unlinked');
            })
            .catch((error: any) => {
                console.log(error);
            });
    };

    return (
        <>
            <Scripts
                id="mfs-client"
                src="/pg_sdk/mfs-client.min.js"
                onReady={masterpassLoadHandler}
                strategy="afterInteractive"
            />
            <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}>
                <div className={styles.masterPassContainer}>
                    <div className={styles.buttonContainer}>
                        <PayButtonElement
                            disabled={!scriptsLoaded || disable || state.loading}
                            size="large"
                            type="submit"
                            fullWidth
                            onClick={() => openDrawer()}
                            variant="contained"
                            loading={state.loading}
                        >
                            {t('Pay by Masterpass')}
                        </PayButtonElement>
                    </div>

                    {state.isOpenDrawer && (
                        <SwipeableCustomerDrawer
                            onClose={() => dispatch({ type: MasterpassActionTypeEnum.CLOSE_DRAWER })}
                            onOpen={() => dispatch({ type: MasterpassActionTypeEnum.RESET })}
                            open={state.isOpenDrawer}
                            headerTitle={getTitle}
                            caption={getCaption}
                            hasOverflow
                            contentStyle={{ display: 'flex', flexDirection: 'column', gap: 4 }}
                        >
                            {state.verificationType === VerificationTypeEnum.MASTERPASS && renderMasterpassSteps}
                        </SwipeableCustomerDrawer>
                    )}

                    {/* <CardSelect
                        handlePay={handlePay}
                        handleDelete={deleteCard}
                        total={total}
                        currencySymbol={vendor?.country.currencySymbol || ''}
                        isSplitted={isSplitted}
                        reference={referenceNo}
                        diningSessionID={diningSessionID}
                        gatewayId={gatewayId}
                    /> */}
                    {IS_DEV && (
                        <Button
                            fullWidth
                            size="large"
                            variant="contained"
                            style={{ marginTop: 5 }}
                            onClick={unLinkHandler}
                        >
                            Unlink me please(for test purposes)
                        </Button>
                    )}
                </div>
            </PaymentWrapper>
        </>
    );
};

const PayMasterpassWithContext = (props: IMasterpassProps) => {
    return (
        <MasterpassProvider>
            <PayMasterpass {...props} />
        </MasterpassProvider>
    );
};

export default PayMasterpassWithContext;
