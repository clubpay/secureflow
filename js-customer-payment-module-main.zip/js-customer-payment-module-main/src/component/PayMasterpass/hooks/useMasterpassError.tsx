/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: useMasterpassError.tsx
 * Copyright 2023 customer-web-app
 */

import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';

export const useMasterpassError = () => {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar, actionButton } = snackBar();

    const showError = (err: any, message?: any, cb?: any) => {
        if (err && err.code) {
            if (err.code === 400 && err.items === 'INVALID_SMS_ID') {
                enqueueSnackbar(t('Your SMS code has expired. Please try again.'), {
                    variant: 'warning',
                    action: actionButton,
                });

                cb?.();

                return;
            }

            if (err.code === 400 && err.items === 'INVALID_PHONE') {
                enqueueSnackbar(t('Invalid phone number'), {
                    variant: 'error',
                    action: actionButton,
                });

                cb?.();

                return;
            }
        }

        if (message) {
            enqueueSnackbar(message, {
                variant: 'error',
                action: actionButton,
            });

            cb?.();

            return;
        }

        enqueueSnackbar(t('An error occured. Please try again.'), {
            variant: 'error',
            action: actionButton,
        });

        cb?.();
    };

    return { showError };
};
