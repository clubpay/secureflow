import { useContext } from 'react';
import Masterpass from '../lib/masterpass';
import { useMasterpassAPI } from '../api';
import { useMasterpassError } from './useMasterpassError';
import { MasterpassActionTypeEnum, MasterpassContext } from '../context';
import { IMasterpassCard, MasterpassCardType } from '../types';

export const useGetCards = ({
    gatewayID,
    diningSessionID,
    sessionId,
}: {
    gatewayID: string;
    diningSessionID: string;
    sessionId: string;
}) => {
    const { masterPassGenerateToken, masterpassGenerateReference } = useMasterpassAPI();
    const { dispatch } = useContext(MasterpassContext);
    const { showError } = useMasterpassError();

    const getCards = async () => {
        try {
            const masterpassResponse = await masterPassGenerateToken({
                gatewayID,
                verbose: true,
                reference: await masterpassGenerateReference(),
                forRegisterCard: false,
                id: sessionId,
                diningSessionID,
                computeReturnURL: false,
            });

            let newCards: MasterpassCardType[] = [];

            Masterpass.getInstance().listCards(
                masterpassResponse?.customerPhone,
                masterpassResponse?.token,
                (responseCode, response) => {
                    if (!response?.cards || response?.cards?.length === 0) {
                        dispatch({
                            type: MasterpassActionTypeEnum.ADD_NEW_CARD,
                        });

                        return;
                    }

                    newCards = response.cards.map((card: IMasterpassCard) => ({
                        selected: false,
                        mask: card?.Value1?.match(/.{1,4}/g)?.join(' '), // to seperate card number with space 123456******7890 -> 1234 56** **** 7890
                        ...card,
                    }));

                    dispatch({
                        type: MasterpassActionTypeEnum.SET_CARDS,
                        payload: { cards: newCards },
                    });
                },
            );
        } catch (error: any) {
            const errData = error?.response?.data || error || {};

            showError(errData, error?.message);
        }
    };
    return { getCards };
};
