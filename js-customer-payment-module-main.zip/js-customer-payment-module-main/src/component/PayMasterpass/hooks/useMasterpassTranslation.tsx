/*
 * Creation Time: February 2 - 2023
 * Created By: yasincelebi
 * Name: useMasterpassTranslation.tsx
 * Copyright 2023 customer-web-app
 */

import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useMemo } from 'react';

export const getChargesTranslation = (tip?: number) => {
    const { t } = useTranslation('common');

    if (tip && tip > 0) {
        return t('Includes tip, taxes and charges');
    }
    return t('Inclusive of all taxes and charges');
};

export const useMasterpassAddNewCardTranslation = (tip?: number) => {
    const { t } = useTranslation('common');

    const formErrors = useMemo(
        () => ({
            label: {
                required: t('Card label is required'),
            },
            cardNumber: {
                required: t('Card number is required'),
                invalid: t('Card number is invalid'),
            },
            expirationDate: {
                required: t('Expiration date is required'),
                invalid: t('Expiration date is invalid'),
            },
            cvv: {
                required: t('CVV is required'),
                invalid: t('CVV is invalid'),
            },
        }),
        [t],
    );

    const safetyTips = useMemo(
        () => ({
            title: t('Safety'),
            content: t(
                'Your card information will be saved. Qlub does not keep any card information. Your card information is kept and secured by Masterpass',
            ),
        }),
        [t],
    );

    const formLabels = useMemo(
        () => ({
            cardNumber: t('Card Number'),
            expirationDate: t('Expiration Date'),
            label: t('Card Label'),
            cvv: t('CVV'),
        }),
        [t],
    );

    const amountTips = useMemo(
        () => ({
            title: t('You are paying'),
            taxes: getChargesTranslation(tip),
        }),
        [t, tip],
    );

    const buttonTexts = useMemo(
        () => ({
            continue: t('Continue'),
        }),
        [t],
    );

    return { formErrors, safetyTips, formLabels, amountTips, buttonTexts };
};
