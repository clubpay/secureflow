/*
 * Creation Time: February 2 - 2023
 * Created By: yasincelebi
 * Name: index.tsx
 * Copyright 2023 customer-web-app
 */

import React, { createContext, Dispatch, useMemo, useReducer } from 'react';
import { qlubLocalStorage } from '@clubpay/customer-common-module/src/service/storage/localStorage';
import {
    initialState,
    MasterpassAction,
    MasterpassActionTypeEnum,
    masterpassReducer,
    MasterpassState,
} from './reducer';
import { getStorage } from '../utils';

const MasterpassContext = createContext<{
    state: MasterpassState;
    dispatch: Dispatch<MasterpassAction>;
    tokenStorage: Record<string, any>;
    isReachedLimit: boolean;
}>({
    state: initialState,
    dispatch: () => null,
    tokenStorage: {},
    isReachedLimit: false,
});

export interface MasterpassProviderProps {
    children: React.ReactNode;
}

const MasterpassProvider: React.FC<MasterpassProviderProps> = ({ children }) => {
    const [state, dispatch] = useReducer(masterpassReducer, initialState);

    const tokenObj = {
        userJWTToken: qlubLocalStorage.get('userJWTToken'),
        userRefreshToken: qlubLocalStorage.get('userRefreshToken'),
    };

    const tokenStorage: Record<string, any> = useMemo(() => {
        return getStorage(localStorage, tokenObj);
    }, [qlubLocalStorage.get('userJWTToken'), qlubLocalStorage.get('userRefreshToken')]);

    const isReachedLimit = useMemo(() => {
        return state.resendedCounter > 1 || state.hasReachedLimit;
    }, [state.resendedCounter, state.hasReachedLimit]);

    return (
        <MasterpassContext.Provider value={{ state, dispatch, tokenStorage, isReachedLimit }}>
            {children}
        </MasterpassContext.Provider>
    );
};

export { MasterpassContext, MasterpassProvider, MasterpassActionTypeEnum };
