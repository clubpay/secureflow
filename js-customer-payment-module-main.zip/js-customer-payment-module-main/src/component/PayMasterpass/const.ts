/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: const.ts
 * Copyright 2023 customer-web-app
 */

export const MASTERPASS_ACCOUNT_STATUS = {
    HAS_NOT_MASTERPASS_ACCOUNT: '000000',
    HAS_MASTERPASS_ACCOUNT_NOT_USED_QLUB: '011000',
    HAS_MASTERPASS_ACCOUNT_USED_QLUB: '011100',
};

export const MASTERPASS_RESPONSE_CODE = {
    OTP: '5001',
    OTHER_OTP: '5008',
    SUCCESS: '0000',
    SUCCESS_REDIRECT_TO_3D: '5010',
    CONFLICT_WITH_ANOTHER_ORDERID: '1999',
    HAS_REACHED_THE_SMS_LIMIT: '1430',
};

export const MASTERPASS_BASE_ENDPOINT = {
    test: 'https://test.masterpassturkiye.com/MasterpassJsonServerHandler/v2',
    uat: 'https://uatui.masterpassturkiye.com/v2',
    prod: 'https://ui.masterpassturkiye.com/v2',
};

export const MASTERPASS_PF_BANK_ICA = {
    sipay: '1017',
    ipara: '1002',
};
