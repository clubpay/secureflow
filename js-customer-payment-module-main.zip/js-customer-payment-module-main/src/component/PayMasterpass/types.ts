/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: types.ts
 * Copyright 2023 customer-web-app
 */

export interface Card {
    id: string;
    mask: string;
    selected: boolean;
}

export enum QlubStepEnum {
    PHONE = 1,
    OTP_CODE = 2,
}

export enum MasterpassStepEnum {
    OTP_CODE = 1,
    ADD_NEW_CARD = 2,
    SELECT_CARD = 3,
    BANK_OTP_CODE = 4,
}

export enum VerificationTypeEnum {
    QLUB = 'qlub',
    MASTERPASS = 'masterpass',
}

export interface IError {
    phone?: boolean;
    qlubOTP?: boolean;
    bankOTP?: boolean;

    masterpassOTP?: boolean;
}

export interface IOtpResponse {
    phone: string;
    otpID: string;
    smsID: string;
}

export interface IAddNewCardFormValues {
    cardNumber: string;
    label: string;
    expirationDate: string;
    cvv?: string;
}

export interface IMasterpassCard {
    Name: string;
    PromtCpin: string;
    Value1: string;
    Value2: string;
    IsMasterPassMember?: string;
    CardStatus: string;
    BankIca: string;
    LoyaltyCode: string;
    ProductName: string;
    UniqueId: string;
    EftCode: string;
}

export interface MasterpassCardType extends IMasterpassCard {
    selected: boolean;
    mask: string;
    icon?: any;
}

export interface ICheckMasterpassValues {
    userId: string;
    token: string;
    referenceNo: string;
    sendSmsLanguage: string;
    sendSms: string;
}

export interface IPurchaseAndRegister extends Partial<IMasterpassActionBaseValues> {
    accountAliasName: string;
    rtaPan: string;
    expiryDate: string;
    cvc?: string;
    cardHolderName?: string;
    amount: string;
    macroMerchantId?: string;
    orderNo?: string;
    installmentCount?: number;
    rewardName?: string;
    rewardValue?: string;
    actionType?: string;
    paymentType?: string | null;
    additionalParameters?: Record<any, any>;
    userId: string;
}

export interface IMasterpassActionBaseValues {
    msisdn: string;
    token: string;
    referenceNo: string;
    sendSmsLanguage?: string;
    sendSms?: string;
}

export interface IPurchase extends IMasterpassActionBaseValues {
    listAccountName?: string;
    macroMerchantId?: string;
    orderNo?: string;
    sendSmsMerchant: 'Y' | 'N';
    aav?: 'aav';
    clientIp?: string;
    encCPin?: string;
    encPassword?: string;
    password?: string;
    amount: string;
    cvc?: string;
    userId: string;
    additionalParameters?: Record<any, any>;
}

export interface IRegisterCard
    extends Omit<
        IPurchaseAndRegister,
        'amount' | 'macroMerchantId' | 'orderNo' | 'installmentCount' | 'rewardName' | 'rewardValue' | 'paymentType'
    > {
    actionType: string;
    clientIp: string;
    delinkReason: string;
    eActionType: string;
    cardTypeFlag: string;
    cpinFlag: string;
    defaultAccount: string;
    mmrpConfig: string;
    identityVerificationFlag: string;
    mobileAccountConfig: string;
    timeZone: string;
    uiChannelType: string;
}

export interface IOTPFromValues extends Omit<IMasterpassActionBaseValues, 'msisdn' | 'token'> {
    validationCode: string;
    pinType: string;
}

export interface IDeleteCard extends IMasterpassActionBaseValues {
    accountAliasName: string;
}

export type FormTypes =
    | IMasterpassActionBaseValues
    | ICheckMasterpassValues
    | IPurchaseAndRegister
    | Partial<IOTPFromValues>
    | IRegisterCard
    | IDeleteCard
    | IPurchase;

export interface ICallbackUrlProps {
    isSuccess: boolean;
    cc: string;
    slug: string;
    id: string;
    f1: string;
    f2: string;
    hash: string;
    referenceNo: string;
    currencySymbol: string;
    amount: number;
    diningSessionID: string;
    lang?: string;
}

export interface IDirectPurchase extends IMasterpassActionBaseValues {
    sendSmsLanguage?: string;
    macroMerchantId?: string;
    rtaPan: string;
    expiryDate: string;
    orderNo?: string;
    installmentCount?: number;
    rewardName?: string;
    rewardValue?: string;
    amount: string;
    cvc?: string;
    userId: string;
    additionalParameters?: Record<any, any>;
    accountAliasName: string;
    cardHolderName?: string;
    actionType?: string;
    paymentType?: string | null;
    returnURL?: string | null;
    directPurchase?: any;
}
