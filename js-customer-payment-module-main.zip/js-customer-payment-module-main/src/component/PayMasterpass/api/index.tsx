/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: index.tsx
 * Copyright 2023 customer-web-app
 */

import AuthManager from '@clubpay/customer-common-module/src/repository/auth';
import { ITokenPayload } from '@clubpay/customer-common-module/src/repository/auth/type';
import {
    IAuthenticatePayload,
    IMasterPassGenerateTokenPayload,
    IResendSMSPayload,
} from '../../../repository/type/masterpass';
import PaymentAPIManager from '../../../repository';
import ReCaptcha from '../lib/reCaptcha';

export const useMasterpassAPI = () => {
    const authManager = AuthManager.getInstance();

    const masterpassGenerateReference = async () => {
        const { data } = await PaymentAPIManager.getInstance().masterpassGenerateReference();
        return data.reference;
    };

    const sendOTP = async (payload: IAuthenticatePayload) => {
        return authManager.sendSms(payload);
    };

    const refreshToken = async (refresh: string) => {
        return authManager.refreshToken({ refresh });
    };

    const getRecaptchaToken = async () => {
        return ReCaptcha.getInstance().getToken();
    };

    const resendQlubCode = async (payload: IResendSMSPayload) => {
        return authManager.resendSms(payload);
    };

    const getUserToken = async (payload: ITokenPayload) => {
        const { data } = await authManager.getUserToken(payload);
        return data;
    };

    const masterPassGenerateToken = async (payload: IMasterPassGenerateTokenPayload) => {
        const { data } = await PaymentAPIManager.getInstance().masterPassGenerateToken(payload);
        return data;
    };

    const masterPassDirectGenerateToken = async (payload: IMasterPassGenerateTokenPayload) => {
        const { data } = await PaymentAPIManager.getInstance().masterPassDirectGenerateToken(payload);
        return data;
    };

    return {
        masterpassGenerateReference,
        sendOTP,
        refreshToken,
        getRecaptchaToken,
        resendQlubCode,
        getUserToken,
        masterPassGenerateToken,
        masterPassDirectGenerateToken,
    };
};
