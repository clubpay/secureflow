/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: index.tsx
 * Copyright 2023 customer-web-app
 */

import dynamic from 'next/dynamic';
import { Box, CircularProgress } from '@mui/material';
import { IMasterpassProps } from './dynamic';

import styles from './index.module.scss';

const PayMasterpass = dynamic<IMasterpassProps>(() => import('./dynamic'), {
    loading: () => (
        <Box className={styles.masterPassBox}>
            <CircularProgress size={24} />
        </Box>
    ),
    ssr: false,
});

export default PayMasterpass;
