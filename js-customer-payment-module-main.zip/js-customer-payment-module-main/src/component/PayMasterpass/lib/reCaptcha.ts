/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: reCaptcha.ts
 * Copyright 2023 customer-web-app
 */

declare global {
    interface Window {
        grecaptcha: {
            execute(opt_widget_id?: number): PromiseLike<void>;
            execute(siteKey: string, action: Action): PromiseLike<string>;
            ready(callback: () => void): void;
            render(container: string | HTMLElement, parameters?: Parameters, inherit?: boolean): number;
            reset(opt_widget_id?: number): void;
            getResponse(opt_widget_id?: number): string;
        };
    }
}
type Theme = 'light' | 'dark';
type Type = 'image' | 'audio';
type Size = 'normal' | 'compact' | 'invisible';
type Badge = 'bottomright' | 'bottomleft' | 'inline';

interface Action {
    action: string;
}

interface Parameters {
    sitekey?: string | undefined;
    theme?: Theme | undefined;
    type?: Type | undefined;
    size: Size;
    tabindex?: number | undefined;
    badge?: Badge | undefined;
    isolated?: boolean | undefined;

    callback?(response: string): void;

    'expired-callback'?(): void;

    'error-callback'?(): void;
}

export default class ReCaptcha {
    private static instance: ReCaptcha;

    public static getInstance(): ReCaptcha {
        if (!this.instance) {
            this.instance = new ReCaptcha();
        }
        return this.instance;
    }

    public async getToken(): Promise<any> {
        return window.grecaptcha.execute(process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY || '', { action: 'login' });
    }

    public async render(containerId: string, parameters?: Partial<Parameters>): Promise<void> {
        window.grecaptcha.ready(() => {
            return window.grecaptcha.render(containerId, {
                sitekey: process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY,
                size: 'invisible',
                ...parameters,
            });
        });
    }
}
