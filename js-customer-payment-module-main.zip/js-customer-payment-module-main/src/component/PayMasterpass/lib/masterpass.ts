/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: masterpass.ts
 * Copyright 2023 customer-web-app
 */

import $ from 'jquery';
import { omit } from 'lodash';
import {
    FormTypes,
    ICheckMasterpassValues,
    IDeleteCard,
    IMasterpassActionBaseValues,
    IOTPFromValues,
    IPurchase,
    IPurchaseAndRegister,
    IRegisterCard,
    IDirectPurchase,
} from '../types';

declare global {
    interface Window {
        MFS: {
            setClientId: (clientId?: string) => any;
            setAddress: (address?: string) => any;
            checkMasterPass: (form: JQuery<Element>, callback: (status: number, response: any) => any) => void;
            linkCardToClient: (form: JQuery<Element>, callback: (status: number, response: any) => any) => void;
            purchaseAndRegister: (form: JQuery<Element>, callback: (status: number, response: any) => any) => void;
            validateTransaction: (form: JQuery<Element>, callback: (status: number, response: any) => any) => void;
            register: (form: JQuery<Element>, callback: (status: number, response: any) => any) => void;
            listCards: (msisdn: string, token: string, callback: (status: number, response: any) => any) => void;
            purchase: (form: JQuery<Element>, callback: (status: number, response: any) => any) => void;
            deleteCard: (form: JQuery<Element>, callback: (status: number, response: any) => any) => void;
            resendOtp: (token: string, lang: string, callback: (status: number, response: any) => any) => void;
            getLastToken: () => string;
            setAdditionalParameters: (params: any) => void;
            directPurchase: (form: JQuery<Element>, callback: (status: number, response: any) => any) => void;
        };
    }
}

export default class Masterpass {
    private static instance: Masterpass;

    public static getInstance(): Masterpass {
        // remove all forms except last one before creating new instance
        this.removeForms(false);

        if (!this.instance) {
            this.instance = new Masterpass();
        }

        return this.instance;
    }

    public init({ clientId, address }: { clientId: string; address: string }): void {
        window.MFS.setClientId(clientId);
        window.MFS.setAddress(address);
    }

    public createForm<T extends FormTypes>(values: T): HTMLFormElement {
        const form = document.createElement('form');
        form.id = 'mfs-client-form';
        form.style.display = 'none';
        const inputNames = Object.keys(values);
        const inputs = inputNames.map((name) => {
            const input = document.createElement('input');
            input.name = name;
            input.setAttribute('value', values[name as keyof FormTypes] as string);

            input.value = values[name as keyof FormTypes] as string;

            return input;
        });

        form.append(...inputs);

        return form;
    }

    public checkMasterPass(
        values: Partial<ICheckMasterpassValues>,
        callback: (status: number, response: any) => any,
    ): void {
        const defaultValues = {
            sendSms: 'Y',
            sendSmsLanguage: 'tur',
        };

        Object.assign(values, defaultValues);
        const form = this.createForm(values);

        document.body.append(form);

        window.MFS.checkMasterPass($(form), callback);
    }

    public linkCardToClient(
        values: IMasterpassActionBaseValues,
        callback: (status: number, response: any) => any,
    ): void {
        const defaultValues = {
            sendSms: 'Y',
            sendSmsLanguage: 'tur',
        };

        Object.assign(values, defaultValues);
        const form = this.createForm(values);

        document.body.append(form);

        window.MFS.linkCardToClient($(form), callback);
    }

    public purchaseAndRegister(values: IPurchaseAndRegister, callback: (status: number, response: any) => any): void {
        const defaultValues = {
            actionType: 'A',
            sendSms: 'Y',
            sendSmsLanguage: 'tur',
            macroMerchantId: '',
        };

        const newValues = omit(values, ['additionalParameters']);

        Object.assign(newValues, defaultValues);
        const form = this.createForm(newValues);

        document.body.append(form);

        if (values.additionalParameters) {
            window.MFS.setAdditionalParameters(values.additionalParameters);
        }

        window.MFS.purchaseAndRegister($(form), callback);
    }

    public sendOTPForm(values: Partial<IOTPFromValues>, callback: (status: number, response: any) => any): void {
        const defaultValues = {
            pinType: 'otp',
            sendSms: 'Y',
            sendSmsLanguage: 'tur',
        };
        Object.assign(values, defaultValues);
        const form = this.createForm(values);

        document.body.append(form);

        window.MFS.validateTransaction($(form), callback);
    }

    public registerCard(values: IRegisterCard, callback: (status: number, response: any) => any): void {
        const form = this.createForm(values);

        document.body.append(form);

        window.MFS.register($(form), callback);
    }

    public listCards(msisdn: string, token: string, callback: (status: number, response: any) => any): void {
        window.MFS.listCards(msisdn, token, callback);
    }

    public deleteCard(values: IDeleteCard, callback: (status: number, response: any) => any): void {
        const defaultValues = {
            sendSms: 'Y',
            sendSmsLanguage: 'tur',
        };

        Object.assign(values, defaultValues);
        const form = this.createForm(values);

        document.body.append(form);
        window.MFS.deleteCard($(form), callback);
    }

    public payWithRegisteredCard(values: Partial<IPurchase>, callback: (status: number, response: any) => any): void {
        const defaultValues = {
            sendSmsLanguage: 'tur',
            sendSms: 'Y',
            aav: 'aav',
            sendSmsMerchant: 'Y',
            clientIp: '',
            encCPin: '',
            encPassword: '',
            password: '',
            macroMerchantId: '',
        };

        const newValues = omit(values, ['additionalParameters']);

        Object.assign(newValues, defaultValues);
        const form = this.createForm(newValues);

        document.body.append(form);
        if (values.additionalParameters) {
            window.MFS.setAdditionalParameters(values.additionalParameters);
        }
        window.MFS.purchase($(form), callback);
    }

    public directPurchase = (
        values: Partial<IDirectPurchase>,
        callback: (status: number, response: any) => any,
    ): void => {
        const defaultValues = {
            msisdn: '',
            rtaPan: '',
            expiryDate: '',
            cvc: '',
            cardHolderName: '',
            amount: '',
            token: '',
            referenceNo: '',
            sendSmsLanguage: '',
            macroMerchantId: '',
            orderNo: '',
            sendSms: 'Y',
        };

        const newValues = omit(values, ['additionalParameters']);

        Object.assign(newValues, defaultValues);
        const form = this.createForm(values);

        document.body.append(form);
        if (values.additionalParameters) {
            console.log('additional form values', { values });
            window.MFS.setAdditionalParameters(values.additionalParameters);
        }
        window.MFS.directPurchase($(form), callback);
    };

    public resendOTP(token: string, lang: string, callback: (status: number, response: any) => any): any {
        return window.MFS.resendOtp(token, lang, callback);
    }

    public getLastToken(): string {
        return window.MFS.getLastToken();
    }

    public static removeForms(isAll: boolean): void {
        const forms = document.querySelectorAll('form#mfs-client-form');
        forms.forEach((form, index) => {
            if (isAll || index === forms.length - 1) {
                form.remove();
            }
            return form;
        });
    }
}
