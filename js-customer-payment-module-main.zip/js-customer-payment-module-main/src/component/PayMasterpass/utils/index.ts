/*
 * Creation Time: February 13 - 2023
 * Created By: yasincelebi
 * Name: index.ts
 * Copyright 2023 customer-web-app
 */

import { number } from 'card-validator';
import { MASTERPASS_PF_BANK_ICA } from '../const';

export const getFirstSixDigits = (accountStatus: string) => {
    return accountStatus?.substring(0, 6) || '';
};

// masterpass wants to expire date in format "YYMM" format but input is in "MM/YY" format
export const removeSlashesAndReverse = (str: string) => {
    return str?.split('/')?.reverse()?.join('') || '';
};

export const getStorage = (storage: Storage, targetObj: Record<string, any>): ProxyHandler<any> => {
    return new Proxy(targetObj, {
        set: (obj, prop: string, value) => {
            storage.setItem(prop, value);
            return true;
        },
        get: (obj, prop) => {
            return storage.getItem(prop as string);
        },
    });
};

export const expirationDateFormat = (value: string) => {
    const formatted = value
        .replace(/[^0-9]/g, '')
        .replace(/(\d{2})(\d)/, '$1/$2')
        .substring(0, 5)
        .trim();

    return { formatted };
};

export const cvvFormat = (value: string, cType: CardType) => {
    let formatted = value.replace(/[^0-9]/g, '');

    if (cType === 'American Express' || 'AMEX') {
        formatted = formatted.substring(0, 4).trim();
    } else {
        formatted = formatted.substring(0, 3).trim();
    }

    return { formatted };
};

export type CardType = 'American Express' | 'Visa' | 'Mastercard' | 'Discover' | 'Invalid';
export const creditCardFormat = (value: string) => {
    let ccNumString = value;

    ccNumString = ccNumString.replace(/[^0-9]/g, '');

    // max length of 19 ref: https://en.wikipedia.org/wiki/Payment_card_number but we are limiting to 16 in Turkey
    if (ccNumString.length > 16) {
        ccNumString = ccNumString.slice(0, 16);
    }

    let formatted = '';

    const cType: CardType = number(ccNumString).card?.niceType as CardType;

    const obj = {
        'American Express': ccNumString.replace(/(.{4})(.{6})(.*)/, '$1 $2 $3'),
        Visa: ccNumString.replace(/(.{4})/g, '$1 '),
        Mastercard: ccNumString.replace(/(.{4})/g, '$1 '),
        Discover: ccNumString.replace(/(.{4})/g, '$1 '),
        Invalid: ccNumString.replace(/(.{4})/g, '$1 '),
    };

    formatted = obj[cType] || obj.Invalid;

    // call the callback function if it exists

    return { formatted: formatted?.trim(), cType };
};

export function isDev() {
    const params = new URLSearchParams(window.location.search);
    return params.get('dev') === 'true';
}

export const getAdditionalParameters = ({
    total,
    restaurantUnique,
    bankIca,
}: {
    total: string;
    restaurantUnique: string;
    bankIca?: string;
}) => {
    const additionalParameters = {
        [MASTERPASS_PF_BANK_ICA.ipara]: {},
        [MASTERPASS_PF_BANK_ICA.sipay]: {
            additionalParameters: {
                order_product_name_arr: [restaurantUnique],
                order_product_code_arr: [restaurantUnique],
                order_price_arr: [total],
                order_qty_arr: ['1'],
                order_product_info_arr: [restaurantUnique],
            },
        },
    };

    return additionalParameters[bankIca || MASTERPASS_PF_BANK_ICA.ipara] || {};
};
