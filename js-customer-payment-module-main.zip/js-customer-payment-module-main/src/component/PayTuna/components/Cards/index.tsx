import { Card, Divider, Typography } from '@qlub-dev/qlub-kit';
import { Accordion, AccordionDetails, Box } from '@mui/material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import NoOutlinedInput from '@qlub-dev/qlub-kit/dist/components/NoOutlinedInput';
import { Lock } from '@mui/icons-material';
import { number } from 'card-validator';
import { cvcFormat } from '../../utils';
import { CardBrandType, getCardIcon } from '../../../../utility/payment_checkout';
import { ICard } from '../../type';

import styles from './index.module.scss';

export type ICardsType = 'card' | 'mealVoucher';
export type CardsRemoveFunc = (type: ICardsType, card: ICard, idx: number) => void;

interface IProps {
    items: ICard[];
    onSelect: (item: ICard, idx: number) => void;
    onInputChange: (text: string, item: ICard, idx: number) => void;
    onRemove: CardsRemoveFunc;
    type: ICardsType;
    cvv?: string;
    submitted?: boolean;
}

const Cards = ({ items, onSelect, onInputChange, onRemove, type, cvv, submitted }: IProps) => {
    const { t } = useTranslation('common');

    if (!items.length) return null;

    return (
        <div>
            {items.map((item, idx) => (
                <Accordion key={idx} className={styles.accordion} data-name="creditCardButton" expanded={item.selected}>
                    <Card
                        label={item.maskedNumber}
                        onClick={() => {
                            onSelect(item, idx);
                        }}
                        selected={item.selected}
                        customIcon={getCardIcon(item.brand?.toLocaleLowerCase() as CardBrandType, type)}
                        cardOverrides={{
                            borderRadius: item.selected ? '8px 8px 0 0' : '8px',
                            boxShadow: 'none',
                            border: !item.selected ? '1px solid #E5E5E5' : 'none',
                        }}
                    />
                    <AccordionDetails className={styles.accordionDetails}>
                        <NoOutlinedInput
                            fullWidth
                            onChange={(e) => {
                                const { value: cvvNumString } = e.target;
                                const { formatted } = cvcFormat(cvvNumString, number(item.bin).card?.code.size || 4);
                                onInputChange(formatted, item, idx);
                            }}
                            placeholder={t('CVV')}
                            value={cvv}
                            submitted={submitted}
                            hasError={submitted && !cvv}
                            variant="outlined"
                        />
                        {!submitted && !cvv && (
                            <Typography typo="caption_overline" sx={{ color: 'red', marginTop: '8px' }}>
                                {t('Required field')}
                            </Typography>
                        )}
                        <>
                            <Divider />
                            <Box display="flex" marginTop={2} gap={1} alignItems="center">
                                <Lock color="primary" fontSize="small" />
                                <Typography
                                    color="primary"
                                    secondColor
                                    style={{ alignSelf: 'center', flexGrow: 1 }}
                                    typo="caption_overline"
                                >
                                    {t('100% Secure payments powered by Qlub_')}
                                </Typography>
                                <Typography
                                    color="primary"
                                    secondColor
                                    style={{ textAlign: 'right', cursor: 'pointer' }}
                                    typo="caption_overline"
                                    onClick={() => {
                                        onRemove(type, item, idx);
                                    }}
                                >
                                    {t('Remove card')}
                                </Typography>
                            </Box>
                        </>
                    </AccordionDetails>
                </Accordion>
            ))}
        </div>
    );
};

export default Cards;
