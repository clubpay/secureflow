import {
    SodexoLogoIcon,
    VRLogoIcon,
    VisaLogoIcon,
    MasterCardLogoIcon,
    AmericanExpressLogoIcon,
} from '@clubpay/customer-common-module/src/component/SVG';

import { ICardsType } from '../Cards';

interface IProps {
    type?: ICardsType;
}

const DefaultIcons = ({ type }: IProps) => {
    if (type === 'mealVoucher') {
        return (
            <>
                <div
                    style={{
                        backgroundColor: 'white',
                        width: '32px',
                        height: '26px',
                        padding: '2px',
                        borderRadius: '5px',
                    }}
                >
                    <SodexoLogoIcon width="100%" height="100%" />
                </div>
                <VRLogoIcon />
            </>
        );
    }

    return (
        <>
            <VisaLogoIcon />
            <MasterCardLogoIcon />
            <AmericanExpressLogoIcon />
        </>
    );
};

export default DefaultIcons;
