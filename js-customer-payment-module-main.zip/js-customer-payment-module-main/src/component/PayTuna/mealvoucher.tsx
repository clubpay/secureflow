import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Card, NewCard, Typography } from '@qlub-dev/qlub-kit';
import { Accordion, AccordionDetails, Box, InputLabel, TextField } from '@mui/material';
import classNames from 'classnames';
import { isEmpty, some } from 'lodash';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import * as CardValidator from 'card-validator';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { useTunaTranslation } from './hooks';
import { usePaymentError } from '../../hook/paymentError';
import { ICardModel } from './card';
import PaymentAPIManager from '../../repository';
import useTunaStyles from './paytuna.styles';
import PayButtonElement from '../PayButtonElement';
import { IBindResponse, ICard } from './type';
import Cards, { CardsRemoveFunc } from './components/Cards';
import DefaultIcons from './components/DefaultIcon';
import useTunaCards from './hooks/card';
import { formatCPF } from './utils';
import { MealVoucherIcon } from '../../asset/icon';

import styles from './index.module.scss';

interface IProps extends IPGBaseProps, IPGStateCallbacks, IPGHooks {
    tuna: any;
    referenceId: string;
    tunaSessionId: string;
    customerId?: string;
    cards: ICard[];
    onRefreshSession: () => void;
    onRemove: CardsRemoveFunc;
}

const FORM_INITIAL_VALUES = {
    cardNumber: '',
    cardHolder: '',
    expirationDate: '',
    cvv: '',
    save: true,
};

const FORM_INITIAL_ERRORS = {
    cardNumber: false,
    cardHolder: false,
    expirationDate: false,
    cvv: false,
};

export default function MealVoucherElement({
    disable,
    gatewayId,
    currencyPrecision,
    tip,
    name,
    vendor,
    tuna,
    referenceId,
    diningSessionID,
    sessionId,
    tunaSessionId,
    updateTimestamp,
    customerId,
    cards,
    onPgRegister,
    onBeforePayment,
    onRemove,
    onDone,
    onPending,
    onFail,
    onUnlockPayment,
    onRefreshSession,
    onTraceStart,
    onTraceClose,
}: IProps) {
    const { labels, errorMessages } = useTunaTranslation();
    const { showError } = usePaymentError();
    const [formValues, setFormValues] = useState<ICardModel>(FORM_INITIAL_VALUES);
    const [error, setError] = useState<Partial<Record<keyof ICardModel, boolean>>>(FORM_INITIAL_ERRORS);
    const [loading, setLoading] = useState(false);
    const { t } = useTranslation('common');
    const [cpf, setCpf] = useState('');
    const { cpfStyle } = useTunaStyles();
    const { hasPgGroup } = vendor.paymentGatewayList;
    const [cvv, setCvv] = useState<string>('');
    const { isAddingCard, handleAddNewCard, handleSelectCard, selectedCard, setIsAddingCard } = useTunaCards();
    const [submitted, setSubmitted] = useState(false);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    useEffect(() => {
        setFormValues(FORM_INITIAL_VALUES);
        setCvv('');
        setSubmitted(false);
        setError(FORM_INITIAL_ERRORS);
        setIsAddingCard(cards.length === 0);
    }, [cards.length]);

    // format as 000.000.000-00
    const handleChangeCpf = (event: any) => {
        const tempCPF = event.target.value;
        const formattedCPF = formatCPF(tempCPF);
        setCpf(formattedCPF);
    };

    const getEventSuffix = () => {
        return selectedCard ? 'saved' : '';
    };

    const handleMealVoucherPay = async () => {
        setLoading(true);

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.MealVoucherPay,
                refId: referenceId,
            },
        });

        if (isFormValid()) {
            const ok = await onBeforePayment({
                gatewayId,
                paymentElement: PaymentElementEnum.MealVoucherPay,
                tip,
                meta: {
                    gaEventSuffix: getEventSuffix(),
                },
            });

            if (!ok) {
                setLoading(false);

                return;
            }
        }

        if (tuna) {
            setSubmitted(true);
            try {
                if (!isFormValid()) {
                    setLoading(false);

                    return false;
                }

                const additionalParameters = {
                    method: 'F',
                    document: cpf,
                    documentType: 'CPF',
                };
                let response: any;

                if (selectedCard) {
                    response = {
                        cardData: {
                            cardHolderName: selectedCard.cardHolderName,
                            cardNumber: selectedCard.bin,
                            expirationMonth: selectedCard.expirationMonth,
                            expirationYear: selectedCard.expirationYear,
                            cvv,
                            singleUse: false,
                        },
                        tokenData: {
                            token: selectedCard.token,
                            brand: selectedCard.brand,
                        },
                        success: true,
                    };
                } else {
                    const expDate = formValues.expirationDate?.split('/');
                    let expYear = null;
                    let expMonth = null;
                    if (expDate && expDate.length === 2) {
                        expYear = expDate[1].length === 2 ? `20${expDate[1]}` : expDate[1];
                        [expMonth] = expDate;
                    }

                    const cardNumber = formValues.cardNumber?.replace(/\D/g, '');

                    response = await tuna.getCheckoutData({
                        cardHolderName: formValues.cardHolder,
                        cardNumber,
                        expirationMonth: Number(expMonth),
                        expirationYear: Number(expYear),
                        cvv: formValues.cvv,
                        singleUse: !formValues.save,
                        customer: {
                            ...(cpf ? { cpf } : {}),
                            iD: customerId,
                        },
                    });
                }

                if (response.success) {
                    PaymentAPIManager.getInstance()
                        .tunaCardPayment({
                            gatewayID: gatewayId,
                            diningSessionID,
                            reference: referenceId,
                            id: sessionId,
                            tipAmount: tip.toFixed(currencyPrecision || 0),
                            cardToken: response.tokenData.token,
                            sessionToken: tunaSessionId,
                            cardExpireMonth: response.cardData.expirationMonth,
                            cardExpiryYear: response.cardData.expirationYear,
                            cardHolderName: response.cardData.cardHolderName,
                            tokenSingleUse: response.cardData.singleUse || true,
                            cardBrand: response.tokenData.brand,
                            cardBin: response.tokenData.bin,
                            ...additionalParameters,
                        })
                        .then((res) => {
                            if (res.data.success) {
                                onDone({
                                    paymentElement: PaymentElementEnum.MealVoucherPay,
                                    refId: referenceId,
                                    traceId: traceStart?.traceId,
                                    meta: {
                                        gaEventSuffix: getEventSuffix(),
                                    },
                                });
                            } else {
                                onTraceClose?.({
                                    error: res.data,
                                    location: 'tunaMealVoucherPayment.onFail',
                                    traceRef,
                                    traceStart,
                                });

                                onFail({
                                    paymentElement: PaymentElementEnum.MealVoucherPay,
                                    refId: referenceId,
                                    traceId: traceStart?.traceId,
                                    meta: {
                                        gaEventSuffix: getEventSuffix(),
                                    },
                                });
                            }
                        })
                        .catch((err) => {
                            onTraceClose?.({
                                error: err,
                                location: 'tunamealVoucherPayment.onFail',
                                traceRef,
                                traceStart,
                            });
                            const isNetworkError = checkNetworkError(err);
                            if (err?.response?.data?.items === 'PAYMENT_REFERENCE_CONFLICTS_TRANSACTION') {
                                onRefreshSession();
                            } else if (isNetworkError) {
                                onPending({
                                    paymentElement: PaymentElementEnum.MealVoucherPay,
                                    refId: referenceId,
                                    traceId: traceStart?.traceId,
                                    meta: {
                                        gaEventSuffix: getEventSuffix(),
                                    },
                                });
                            } else {
                                onFail({
                                    paymentElement: PaymentElementEnum.MealVoucherPay,
                                    refId: referenceId,
                                    traceId: traceStart?.traceId,
                                    meta: {
                                        gaEventSuffix: getEventSuffix(),
                                    },
                                });
                            }
                            onUnlockPayment();
                        })
                        .finally(() => {
                            setLoading(false);
                        });
                } else {
                    setLoading(false);
                    showError({}, response.message);
                }
            } catch (e: any) {
                onTraceClose?.({
                    error: e,
                    location: 'tunaMealVoucherPayment.catch',
                    traceRef,
                    traceStart,
                });

                // tuna sends error like "[ERR:07] - errorText", this regex removes the [ERR:07] part
                const err = e.message.replace(/(\[.+])/g, '');

                showError({}, err);
                setLoading(false);
            }
        } else {
            setLoading(false);
        }
    };

    const buttonElement = (
        <PayButtonElement
            variant="contained"
            size="large"
            fullWidth
            loading={loading}
            disabled={disable || loading || Boolean(!isAddingCard && !selectedCard)}
            onClick={handleMealVoucherPay}
            id="tuna-mealvoucher-pay-button"
            showConfirmText={!hasPgGroup}
        />
    );

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.MealVoucherPay,
            name: t('Meal Voucher'),
            icon: <MealVoucherIcon />,
            buttonElement,
        });
    }, [buttonElement, updateTimestamp, loading]);

    const bindTheSelectedCard = async () => {
        const tokenizer = await tuna?.tokenizator();

        const response: IBindResponse = await tokenizer?.bind(selectedCard?.token, cvv);

        return response;
    };

    const isFormValid = () => {
        let isValid = true;

        let hasFormEmptyFields: boolean;

        const isFieldRequiredAndEmpty = (value?: string | boolean) => {
            return isEmpty(value) && typeof value === 'string';
        };

        if (selectedCard) {
            hasFormEmptyFields = cvv === '';
            bindTheSelectedCard().then((res) => {
                isValid = res.code === 1;
            });
        } else {
            hasFormEmptyFields = some(formValues, isFieldRequiredAndEmpty);
        }

        if (hasFormEmptyFields || some(error, Boolean) || !cpf) {
            isValid = false;
        }
        return isValid;
    };

    const cardList = useMemo(() => {
        return cards.map((c) => {
            return {
                ...c,
                selected: c.token === selectedCard?.token,
            };
        });
    }, [cards, selectedCard]);

    const cardsSelectHandler = (c: ICard) => {
        setCvv('');
        setSubmitted(false);
        handleSelectCard(c);
    };

    const cardsInputChangeHandler = (text: string) => {
        setCvv(text);
    };

    const handleFormChange = (newModel: ICardModel) => {
        setError((prev) => ({
            ...prev,
            cardNumber: newModel.cardNumber?.replace(/\D/g, '')?.length !== 16,
            expirationDate: !CardValidator.expirationDate(newModel.expirationDate).isValid,
            cvv: !/^[0-9]{3,4}$/.test(newModel.cvv || ''),
            cardHolder: !CardValidator.cardholderName(newModel.cardHolder).isValid,
        }));
        setFormValues(newModel);
    };

    return (
        <div className={styles.container}>
            <Cards
                type="mealVoucher"
                items={cardList}
                onSelect={cardsSelectHandler}
                onInputChange={cardsInputChangeHandler}
                onRemove={onRemove}
                cvv={cvv}
                submitted={Boolean(submitted)}
            />
            <div>
                <Accordion className={styles.accordion} data-name="creditCardButton" expanded={isAddingCard}>
                    <Card
                        label={t('Add new card')}
                        onClick={() => {
                            handleAddNewCard();
                            setSubmitted(false);
                        }}
                        selected={isAddingCard}
                        customIcon={<DefaultIcons type="mealVoucher" />}
                    />

                    <AccordionDetails className={styles.accordionDetails}>
                        <NewCard
                            labels={labels}
                            setModel={handleFormChange}
                            classicPattern
                            errorText={errorMessages}
                            submitted={Boolean(submitted)}
                            showFooter
                            model={formValues}
                            showSaveCard
                            showHeader={false}
                            error={error}
                        />
                    </AccordionDetails>
                </Accordion>
                {isAddingCard || selectedCard ? (
                    <Box>
                        <InputLabel
                            sx={{
                                padding: '0 24px',
                                fontSize: '14px',
                                margin: '24px 0 9px',
                            }}
                            htmlFor="CPF"
                        >
                            CPF
                        </InputLabel>
                        <TextField
                            id="CPF"
                            onChange={handleChangeCpf}
                            value={cpf}
                            name="cpf"
                            InputLabelProps={{ shrink: false }}
                            placeholder="000.000.000-00"
                            sx={cpfStyle}
                            variant="outlined"
                            inputProps={{
                                style: { padding: '8px 16px', fontSize: '14px' },
                            }}
                            className={classNames({
                                hasError: submitted && !cpf,
                                valid: cpf,
                            })}
                        />
                        {submitted && !cpf && (
                            <Typography typo="caption_overline" sx={{ color: 'red', marginTop: '8px' }}>
                                {t('Required field')}
                            </Typography>
                        )}
                    </Box>
                ) : null}
            </div>
            {!hasPgGroup && <div className={styles.submit}>{buttonElement}</div>}
        </div>
    );
}
