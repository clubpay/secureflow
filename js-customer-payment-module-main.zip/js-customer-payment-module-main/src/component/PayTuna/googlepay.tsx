/*
 * Creation Time: November 24 - 2022
 * Created By: yasincelebi
 * Name: googlepay.tsx
 * Copyright 2022 customer-web-app
 */

import React, { useMemo, useRef, useState } from 'react';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Scripts from 'next/script';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import {
    IPayBeforePaymentHandler,
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { GooglePay } from '@clubpay/customer-common-module/src/component/SVG';
import GooglePayCTA from '../GooglePayCTA';
import { ITunaGateway } from '../../repository/type/paymentGateway';
import PaymentAPIManager from '../../repository';

import styles from './index.module.scss';

interface IProps extends IPGBaseProps, IPGStateCallbacks, IPGHooks {
    config: ITunaGateway;
    sessionToken: string;
    hasPgGroup: boolean;
}

let beforeFn: (payload: IPayBeforePaymentHandler) => Promise<boolean>;
let tunaTotalAmount = 0;
let tunaTipAmount = 0;

export default function PayTunaGooglePay({
    diningSessionID,
    sessionId,
    amount,
    tip,
    currencyPrecision,
    config,
    gatewayId,
    vendor,
    sessionToken,
    name,
    hasPgGroup,
    onBeforePayment,
    onDone,
    onPending,
    onFail,
    onPgRegister,
    onTraceStart,
    onPgUnregister,
    onTraceClose,
    onUnlockPayment,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [loading, setLoading] = useState(false);
    const paymentsClientRef = useRef<google.payments.api.PaymentsClient | null>(null);
    const totalAmount = sumAmounts(currencyPrecision, amount, tip);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const [refId, setRefId] = useState<string>(getRandomString());

    beforeFn = onBeforePayment;
    tunaTotalAmount = totalAmount;
    tunaTipAmount = tip;

    const baseRequest = {
        apiVersion: 2,
        apiVersionMinor: 0,
    };

    const tokenizationSpecification = {
        type: 'PAYMENT_GATEWAY',
        parameters: {
            gateway: name,
            gatewayMerchantId: config?.merchantID || '',
        },
    };

    const baseCardPaymentMethod: google.payments.api.IsReadyToPayPaymentMethodSpecification = {
        type: 'CARD',
        parameters: {
            allowedAuthMethods: config?.googleAllowedAuthMethods || ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
            allowedCardNetworks: config?.googleAllowedCardNetworks || ['VISA', 'MASTERCARD', 'AMEX', 'DISCOVER', 'JCB'],
        },
    };

    const getGoogleIsReadyToPayRequest = (): google.payments.api.IsReadyToPayRequest => {
        return { ...baseRequest, allowedPaymentMethods: [baseCardPaymentMethod] } as any;
    };

    const getGooglePaymentsClient = () => {
        if (paymentsClientRef.current === null) {
            paymentsClientRef.current = new google.payments.api.PaymentsClient({
                environment: config?.sandbox ? 'TEST' : 'PRODUCTION',
            });
        }
        return paymentsClientRef.current;
    };

    const cardPaymentMethod = { ...baseCardPaymentMethod, tokenizationSpecification };

    const getGoogleTransactionInfo = (): google.payments.api.TransactionInfo => {
        return {
            totalPriceStatus: 'FINAL',
            totalPrice: tunaTotalAmount.toFixed(currencyPrecision || 0),
            countryCode: config?.countryCode || vendor.country.code.toUpperCase() || 'AE', // should be uppercase ISO 3166-1 alpha-2 country code
            currencyCode: vendor.country.currencyCode?.toUpperCase() || 'BRL',
        };
    };

    const getGooglePaymentDataRequest = (): google.payments.api.PaymentDataRequest => {
        const paymentDataRequest: any = { ...baseRequest };
        paymentDataRequest.allowedPaymentMethods = [cardPaymentMethod];
        paymentDataRequest.transactionInfo = getGoogleTransactionInfo();
        paymentDataRequest.merchantInfo = {
            merchantId: config?.googleMerchantId || '',
            merchantName: 'qlub',
        };
        return paymentDataRequest;
    };

    /**
     * Show Google Pay payment sheet when Google Pay payment button is clicked
     */
    console.log(sessionToken);
    const onGooglePaymentButtonClicked = () => {
        if (loading) {
            return;
        }

        setLoading(true);
        setRefId(getRandomString());

        beforeFn({
            gatewayId,
            paymentElement: PaymentElementEnum.GooglePay,
            tip,
        }).then((ok) => {
            if (!ok) {
                setLoading(false);
                return;
            }

            const paymentDataRequest = getGooglePaymentDataRequest();
            paymentDataRequest.transactionInfo = getGoogleTransactionInfo();

            const paymentsClient = getGooglePaymentsClient();
            console.log({ paymentDataRequest });

            paymentsClient
                .loadPaymentData(paymentDataRequest)
                .then((paymentData) => {
                    // handle the response
                    PaymentAPIManager.getInstance()
                        .paymentTunaPayByGoogle({
                            id: sessionId,
                            diningSessionID,
                            tipAmount: tunaTipAmount.toFixed(currencyPrecision || 0),
                            sessionToken,
                            reference: refId,
                            gatewayID: gatewayId,
                            googleToken: paymentData.paymentMethodData.tokenizationData.token,
                            method: '1',
                        })
                        .then((res) => {
                            if (res.data.success) {
                                onDone({
                                    paymentElement: PaymentElementEnum.GooglePay,
                                    refId,
                                    traceId: traceStart?.traceId,
                                });

                                enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                            } else {
                                onTraceClose?.({
                                    error: res?.data,
                                    location: 'paymentTunaPayByGoogle.then',
                                    traceRef,
                                    traceStart,
                                });
                                onFail({
                                    paymentElement: PaymentElementEnum.GooglePay,
                                    refId,
                                    traceId: traceStart?.traceId,
                                });
                            }
                        })
                        .catch((err) => {
                            onTraceClose?.({
                                error: err,
                                location: 'paymentTunaPayByGoogle.catch',
                                traceRef,
                                traceStart,
                            });
                            const isNetworkError = checkNetworkError(err);
                            if (isNetworkError) {
                                onPending({
                                    paymentElement: PaymentElementEnum.GooglePay,
                                    refId,
                                    traceId: traceStart?.traceId,
                                });
                            }

                            onFail({
                                paymentElement: PaymentElementEnum.GooglePay,
                                refId,
                                traceId: traceStart?.traceId,
                            });
                        })
                        .finally(() => {
                            setLoading(false);
                        });
                })
                .catch((err) => {
                    // show error in developer console for debugging
                    console.error(err);
                    setLoading(false);
                    onUnlockPayment();
                });
        });
    };

    const addGooglePayButton = () => {
        const paymentsClient = getGooglePaymentsClient();
        const button = paymentsClient.createButton({
            onClick: onGooglePaymentButtonClicked,
            allowedPaymentMethods: [baseCardPaymentMethod],
            buttonSizeMode: 'fill',
            buttonType: 'pay',
        });
        document.querySelector('#google-pay')?.appendChild(button);
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.GooglePay,
            name: t('Google Pay'),
            icon: <GooglePay />,
            placement: 'bottom',
        });
    };

    const loadScriptHandler = () => {
        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.GooglePay,
                refId,
            },
        });

        const paymentsClient = getGooglePaymentsClient();
        paymentsClient
            .isReadyToPay(getGoogleIsReadyToPayRequest())
            .then((response) => {
                if (response.result) {
                    addGooglePayButton();
                }
            })
            .catch((err) => {
                // show error in developer console for debugging
                console.error(err);
                onTraceClose?.({
                    error: err,
                    location: 'paymentsClient.isReadyToPay',
                    traceRef,
                    traceStart,
                });
                onPgUnregister?.({
                    pgId: gatewayId,
                    elem: PaymentElementEnum.GooglePay,
                });
            });
    };
    return (
        <div className={styles.tunaGoogleForm}>
            <Scripts src="https://pay.google.com/gp/p/js/pay.js" onReady={loadScriptHandler} />
            <GooglePayCTA id="google-pay" loading={loading} hasPgGroup={hasPgGroup} />
        </div>
    );
}
