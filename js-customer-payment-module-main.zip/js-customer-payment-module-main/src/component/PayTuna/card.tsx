import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Card, NewCard } from '@qlub-dev/qlub-kit';
import { CreditCard } from '@mui/icons-material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Accordion, AccordionDetails } from '@mui/material';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import * as CardValidator from 'card-validator';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import PaymentAPIManager from '../../repository';
import { useTunaTranslation } from './hooks';
import { usePaymentError } from '../../hook/paymentError';
import PayButtonElement from '../PayButtonElement';
import { IBindResponse, ICard } from './type';
import Cards, { CardsRemoveFunc } from './components/Cards';
import DefaultIcons from './components/DefaultIcon';
import useTunaCards from './hooks/card';
import { isFormValid, parseExpirationDate } from './utils';

import styles from './index.module.scss';

interface IProps extends IPGBaseProps, IPGStateCallbacks, IPGHooks {
    tuna: any;
    referenceId: string;
    tunaSessionId: string;
    customerId?: string;
    cards: ICard[];
    onRemove: CardsRemoveFunc;
    onRefreshSession: () => void;
}

export interface ICardModel {
    cardNumber?: string;
    cardHolder?: string;
    expirationDate?: string;
    cvv?: string;
    save?: boolean;
}

const FORM_INITIAL_VALUES = {
    cardNumber: '',
    cardHolder: '',
    expirationDate: '',
    cvv: '',
    save: true,
};

const FORM_INITIAL_ERRORS = {
    cardNumber: false,
    cardHolder: false,
    expirationDate: false,
    cvv: false,
};

export default function CardElement({
    disable,
    gatewayId,
    currencyPrecision,
    tip,
    tuna,
    referenceId,
    diningSessionID,
    sessionId,
    tunaSessionId,
    updateTimestamp,
    vendor,
    cards,
    customerId,
    name,
    onBeforePayment,
    onPgRegister,
    onRemove,
    onDone,
    onFail,
    onPending,
    onUnlockPayment,
    onRefreshSession,
    onTraceStart,
    onTraceClose,
}: IProps) {
    const { labels, errorMessages } = useTunaTranslation();
    const { showError } = usePaymentError();
    const [formValues, setFormValues] = useState<ICardModel>(FORM_INITIAL_VALUES);
    const [error, setError] = useState<Partial<Record<keyof ICardModel, boolean>>>(FORM_INITIAL_ERRORS);
    const [loading, setLoading] = useState(false);
    const { t } = useTranslation('common');
    const { hasPgGroup } = vendor.paymentGatewayList;
    const [cvv, setCvv] = useState<string>('');
    const { isAddingCard, handleAddNewCard, handleSelectCard, selectedCard, setIsAddingCard } = useTunaCards();
    const [submitted, setSubmitted] = useState(false);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    useEffect(() => {
        setFormValues(FORM_INITIAL_VALUES);
        setCvv('');
        setSubmitted(false);
        setError(FORM_INITIAL_ERRORS);
        setIsAddingCard(cards.length === 0);
    }, [cards.length]);

    const formValid = () => {
        return isFormValid({ selectedCard, cvv, formValues, error, bindSelectedCb: bindTheSelectedCard });
    };

    const getEventSuffix = () => {
        return selectedCard ? 'saved' : '';
    };

    const handleCardPayment = async () => {
        const tipCheckResponse = await onBeforePayment({
            checkTipOnly: true,
            gatewayId,
            paymentElement: PaymentElementEnum.CardPay,
            tip,
        });

        if (!tipCheckResponse) {
            return;
        }

        setLoading(true);
        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.CardPay,
                refId: referenceId,
            },
        });

        if (formValid()) {
            const ok = await onBeforePayment({
                gatewayId,
                paymentElement: PaymentElementEnum.CardPay,
                tip,
                meta: {
                    gaEventSuffix: getEventSuffix(),
                },
            });

            if (!ok) {
                setLoading(false);
                return undefined;
            }
        }

        if (tuna) {
            setSubmitted(true);
            try {
                const additionalParameters = {
                    method: '1',
                    document: '',
                    documentType: '',
                };

                if (!formValid()) {
                    setLoading(false);

                    return false;
                }

                let response: any;

                if (selectedCard) {
                    response = {
                        cardData: {
                            cardHolderName: selectedCard.cardHolderName,
                            cardNumber: selectedCard.bin,
                            expirationMonth: selectedCard.expirationMonth,
                            expirationYear: selectedCard.expirationYear,
                            cvv,
                            singleUse: false,
                        },
                        tokenData: {
                            token: selectedCard.token,
                            brand: selectedCard.brand,
                        },
                        success: true,
                    };
                } else {
                    const { expYear, expMonth } = parseExpirationDate(formValues.expirationDate);

                    const cardNumber = formValues.cardNumber?.replace(/\D/g, '');
                    response = await tuna.getCheckoutData({
                        cardHolderName: formValues.cardHolder,
                        cardNumber,
                        expirationMonth: Number(expMonth),
                        expirationYear: Number(expYear),
                        cvv: formValues.cvv,
                        singleUse: !formValues.save,
                        iD: customerId,
                    });
                }

                if (response.success) {
                    PaymentAPIManager.getInstance()
                        .tunaCardPayment({
                            gatewayID: gatewayId,
                            diningSessionID,
                            reference: referenceId,
                            id: sessionId,
                            tipAmount: tip.toFixed(currencyPrecision || 0),
                            cardToken: response.tokenData.token,
                            sessionToken: tunaSessionId,
                            cardExpireMonth: response.cardData.expirationMonth,
                            cardExpiryYear: response.cardData.expirationYear,
                            cardHolderName: response.cardData.cardHolderName,
                            tokenSingleUse: response.cardData.singleUse || true,
                            cardBrand: response.tokenData.brand,
                            cardBin: response.tokenData.bin,
                            ...additionalParameters,
                        })
                        .then((res) => {
                            if (res.data.success) {
                                onDone({
                                    paymentElement: PaymentElementEnum.CardPay,
                                    refId: referenceId,
                                    traceId: traceStart?.traceId,
                                    meta: {
                                        gaEventSuffix: getEventSuffix(),
                                    },
                                });
                            } else {
                                onTraceClose?.({
                                    error: res.data,
                                    location: 'tunaCardPayment.onFail',
                                    traceRef,
                                    traceStart,
                                });
                                onFail({
                                    paymentElement: PaymentElementEnum.CardPay,
                                    refId: referenceId,
                                    traceId: traceStart?.traceId,
                                    meta: {
                                        gaEventSuffix: getEventSuffix(),
                                    },
                                });
                            }
                        })
                        .catch((err) => {
                            onTraceClose?.({
                                error: err,
                                location: 'tunaCardPayment.catch',
                                traceRef,
                                traceStart,
                            });
                            const isNetworkError = checkNetworkError(err as AxiosError);

                            if (err?.response?.data?.items === 'PAYMENT_REFERENCE_CONFLICTS_TRANSACTION') {
                                onRefreshSession();
                            } else if (isNetworkError) {
                                onPending({
                                    paymentElement: PaymentElementEnum.CardPay,
                                    refId: referenceId,
                                    traceId: traceStart?.traceId,
                                    meta: {
                                        gaEventSuffix: getEventSuffix(),
                                    },
                                });
                            } else {
                                onFail({
                                    paymentElement: PaymentElementEnum.CardPay,
                                    refId: referenceId,
                                    traceId: traceStart?.traceId,
                                    meta: {
                                        gaEventSuffix: getEventSuffix(),
                                    },
                                });
                            }
                            onUnlockPayment();
                        })
                        .finally(() => {
                            setLoading(false);
                        });
                } else {
                    setLoading(false);
                }
            } catch (e: any) {
                // tuna sends error like "[ERR:07] - errorText", this regex removes the [ERR:07] part
                const err = e?.message?.replace(/(\[.+])/g, '');

                showError({}, err);
                setLoading(false);
            }
        } else {
            setLoading(false);
        }
    };

    const buttonElement = (
        <PayButtonElement
            variant="contained"
            size="large"
            fullWidth
            loading={loading}
            disabled={disable || loading || Boolean(!isAddingCard && !selectedCard)}
            onClick={handleCardPayment}
            id="tuna-card-pay-button"
            showConfirmText={!hasPgGroup}
        />
    );

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.CardPay,
            name: t('Card'),
            icon: <CreditCard />,
            buttonElement,
        });
    }, [buttonElement, updateTimestamp, loading]);

    const bindTheSelectedCard = async () => {
        const tokenizer = await tuna.tokenizator();

        const response: IBindResponse = await tokenizer?.bind(selectedCard?.token, cvv);

        return response;
    };

    const cardList = useMemo(() => {
        return cards.map((c) => {
            return {
                ...c,
                selected: c.token === selectedCard?.token,
            };
        });
    }, [cards, selectedCard]);

    const cardsSelectHandler = (c: ICard) => {
        setCvv('');
        setSubmitted(false);
        handleSelectCard(c);
    };

    const cardsInputChangeHandler = (text: string) => {
        setCvv(text);
    };

    const handleFormChange = (newModel: ICardModel) => {
        setError((prev) => ({
            ...prev,
            cardNumber: !CardValidator.number(newModel.cardNumber).isValid,
            expirationDate: !CardValidator.expirationDate(newModel.expirationDate).isValid,
            cvv: !/^[0-9]{3,4}$/.test(newModel.cvv || ''),
            cardHolder: !CardValidator.cardholderName(newModel.cardHolder).isValid,
        }));
        setFormValues({
            ...newModel,
            cvv: newModel.cvv?.substring(0, CardValidator.number(newModel.cardNumber).card?.code.size || 4),
        });
    };

    return (
        <div className={styles.container}>
            <Cards
                type="card"
                items={cardList}
                onSelect={cardsSelectHandler}
                onInputChange={cardsInputChangeHandler}
                onRemove={onRemove}
                cvv={cvv}
            />
            <div>
                <Accordion className={styles.accordion} data-name="creditCardButton" expanded={isAddingCard}>
                    <Card
                        label={t('Add new card')}
                        onClick={() => {
                            handleAddNewCard();

                            setSubmitted(false);
                        }}
                        selected={isAddingCard}
                        customIcon={<DefaultIcons type="card" />}
                    />

                    <AccordionDetails className={styles.accordionDetails}>
                        <NewCard
                            errorText={errorMessages}
                            error={error}
                            showFooter
                            labels={labels}
                            model={formValues}
                            setModel={handleFormChange}
                            submitted={Boolean(submitted)}
                            showSaveCard
                            showHeader={false}
                        />
                    </AccordionDetails>
                </Accordion>
            </div>

            {!hasPgGroup && <div className={styles.submit}>{buttonElement}</div>}
        </div>
    );
}
