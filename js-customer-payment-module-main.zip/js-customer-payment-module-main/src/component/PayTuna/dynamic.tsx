/*
    Creation Time: 2022 - May - 13
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/
import React, { useEffect, useMemo, useRef, useState } from 'react';
import Scripts from 'next/script';
import { usePaymentTimeout } from '@clubpay/customer-common-module/src/hook/payment';
import Head from 'next/head';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { SnackbarAction } from 'notistack';
import { Box } from '@mui/material';
import { Close } from '@mui/icons-material';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { isSafari } from '@clubpay/customer-common-module/src/utility/mobile_check';
import PaymentAPIManager from '../../repository';
import PaymentWrapper from '../PaymentWrapper';
import PayTunaGooglePay from './googlepay';
import PixPayment from './pix';
import CardElement from './card';
import MealVoucherElement from './mealvoucher';
import useTunaCards from './hooks/card';
import { formatMaskedCard, getCardMealVoucherType, isCardMealVoucher } from './utils';
import { ICard } from './type';
import { CardsRemoveFunc } from './components/Cards';
import { ITunaGateway } from '../../repository/type/paymentGateway';
import ApplePay from './components/ApplePay';
import { applePayJsAvailable } from '../ApplePayButton/utils/handlers';
import styles from './index.module.scss';

export interface IProps extends IPGProps {
    config: ITunaGateway;
}

const PayTuna = ({
    name,
    gatewayId,
    tip,
    config,
    vendor,
    disable,
    url,
    diningSessionID,
    sessionId,
    jwt,
    currencyPrecision,
    amount,
    updateTimestamp,
    onBeforePayment,
    onUnlockPayment,
    onIndicator,
    onLoad,
    onDone,
    onPending,
    onFail,
    onPgRegister,
    onTraceStart,
    onPgUnregister,
    isPgElemVisible,
    onTraceClose,
}: IProps) => {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar, closeSnackbar } = snackBar();
    const { timeoutDone } = usePaymentTimeout({
        indicatorTimeout: config?.indicatorTimeout || 0,
        fallbackTimeout: config?.fallbackTimeout || 0,
        indicatorCallback: onIndicator,
        fallbackCallback: onLoad,
    });
    const { lang } = useQlubRouter();
    const { isLogin, login } = useAuth();
    const { setCards, setSelectedCard, cards, parseBrand } = useTunaCards();

    const [pixOpen, setPixOpen] = useState(false);
    const [scriptsLoaded, setScriptsLoaded] = useState(false);
    const [tunaSessionId, setTunaSessionId] = useState<string>('');
    const [customerId, setCustomerId] = useState('');
    const [tunaLoaded, setTunaLoaded] = useState<boolean>(false);
    const tuna = useRef<any>(null);
    const [referenceId, setReferenceId] = useState<string>(getRandomString());
    const [hasApplePay, setHasApplePay] = useState(false);
    const [hasGooglePay, setHasGooglePay] = useState(false);

    const { hasPgGroup } = vendor.paymentGatewayList;

    useEffect(() => {
        if (!isLogin) {
            login({ guest: true }).then(() => {
                console.log('called');
                getTunaSession();
            });
        } else {
            getTunaSession();
        }
    }, []);

    const getTunaSession = () => {
        const refId = getRandomString();
        setReferenceId(refId);
        setTunaLoaded(false);
        setTunaSessionId('');
        PaymentAPIManager.getInstance()
            .paymentTunaSession({
                gatewayID: gatewayId,
                reference: refId,
                diningSessionID,
                id: sessionId,
            })
            .then((res) => {
                setTunaSessionId(res.data.sessionToken);
                setCustomerId(res.data.customerID);
            })

            .catch((err) => {
                console.log(err);
            });
    };

    const getCards = async () => {
        const tokenizer = await tuna.current?.tokenizator();
        const list = await tokenizer?.list();

        if (!list.tokens.length) return;

        setCards(
            list.tokens.map((card: ICard) => {
                return {
                    ...card,
                    maskedNumber: formatMaskedCard(card.maskedNumber),
                    brand: card.brand === 'unknown' ? parseBrand(card.bin) : card.brand,
                };
            }),
        );
    };

    const loadScriptHandler = () => {
        setScriptsLoaded(true);
        timeoutDone();
    };

    const initializeTuna = () => {
        tuna.current = window.Tuna(tunaSessionId);

        getCards();
    };

    useEffect(() => {
        if (scriptsLoaded && tunaSessionId && !tunaLoaded && !!window.Tuna) {
            setTunaLoaded(true);
            initializeTuna();
        }
    }, [scriptsLoaded, tunaSessionId]);

    useEffect(() => {
        if (tunaLoaded && !!window.Tuna) {
            initializeTuna();
        }
    }, [lang]);

    const showDeletedCardMessage = () => {
        const actionButton: SnackbarAction = (key) => (
            <Box onClick={() => closeSnackbar(key)}>
                <Close />
            </Box>
        );
        enqueueSnackbar(t('Your card details archived.'), {
            variant: 'info',
            action: actionButton,
        });
    };

    const removeCardHandler: CardsRemoveFunc = async (type, card) => {
        const tokenizer = await tuna.current?.tokenizator();
        const response = await tokenizer?.delete(card.token);

        if (response?.code === 1) {
            setCards(cards.filter((c) => c.token !== card.token));
            showDeletedCardMessage();
            setSelectedCard(null);

            onPushEvent('tuna_removesavedcard', {
                pg_name: name,
                restaurant_name: url.slug,
                opsMode: vendor?.opsMode,
                diningSessionId: diningSessionID,
            });
        }
    };

    const [creditCardList, mealVoucherCardList] = useMemo<[Array<ICard>, Array<ICard>]>(() => {
        return cards.reduce<[Array<ICard>, Array<ICard>]>(
            (a, card) => {
                if (isCardMealVoucher(card.bin)) {
                    a[1].push({
                        ...card,
                        brand: getCardMealVoucherType(card.bin),
                    });
                } else {
                    a[0].push(card);
                }
                return a;
            },
            [[], []],
        );
    }, [cards]);

    useEffect(() => {
        applePayJsAvailable().then((enable) => {
            setHasApplePay(enable);
        });

        setHasGooglePay(!isSafari());
    }, [url.cc, url.slug, url.id]);

    return (
        <>
            <Head>
                <link rel="stylesheet" type="text/css" href="https://js.tuna.uy/css/components.min.css" />
            </Head>
            <div className={!hasPgGroup ? styles.form : undefined}>
                <Scripts
                    src="https://code.jquery.com/jquery-3.5.1.min.js"
                    integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
                    crossOrigin="anonymous"
                />
                <Scripts id="tunaCode" src="https://js.tuna.uy/tuna.js" onReady={loadScriptHandler} />
                {scriptsLoaded && (
                    <>
                        {config.googleMerchantId && config.hideGooglePay !== true && tunaSessionId && (
                            <PaymentWrapper
                                hasPgGroup={hasPgGroup}
                                visible={isPgElemVisible?.(PaymentElementEnum.GooglePay)}
                            >
                                <PayTunaGooglePay
                                    name={name}
                                    onPgUnregister={onPgUnregister}
                                    sessionToken={tunaSessionId}
                                    diningSessionID={diningSessionID}
                                    sessionId={sessionId}
                                    jwt={jwt}
                                    tip={tip}
                                    currencyPrecision={currencyPrecision}
                                    gatewayId={gatewayId}
                                    disable={disable}
                                    onPending={onPending}
                                    onBeforePayment={onBeforePayment}
                                    onUnlockPayment={onUnlockPayment}
                                    config={config}
                                    amount={amount}
                                    onDone={onDone}
                                    onFail={onFail}
                                    vendor={vendor}
                                    url={url}
                                    onPgRegister={onPgRegister}
                                    updateTimestamp={updateTimestamp}
                                    onTraceStart={onTraceStart}
                                    hasPgGroup={hasPgGroup}
                                    onTraceClose={onTraceClose}
                                />
                            </PaymentWrapper>
                        )}
                        <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.PixPay)}>
                            <PixPayment
                                name={name}
                                config={config}
                                tuna={tuna}
                                referenceId={referenceId}
                                tunaSessionId={tunaSessionId}
                                onRefreshSession={getTunaSession}
                                pixOpen={pixOpen}
                                setPixOpen={setPixOpen}
                                diningSessionID={diningSessionID}
                                sessionId={sessionId}
                                jwt={jwt}
                                tip={tip}
                                currencyPrecision={currencyPrecision}
                                gatewayId={gatewayId}
                                onDone={onDone}
                                onFail={onFail}
                                onPending={onPending}
                                onBeforePayment={onBeforePayment}
                                onUnlockPayment={onUnlockPayment}
                                onPgRegister={onPgRegister}
                                disable={disable}
                                url={url}
                                vendor={vendor}
                                amount={amount}
                                updateTimestamp={updateTimestamp}
                                onTraceStart={onTraceStart}
                                onTraceClose={onTraceClose}
                            />
                        </PaymentWrapper>
                        {config.hideCardPay !== true && (
                            <PaymentWrapper
                                hasPgGroup={hasPgGroup}
                                visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}
                            >
                                <CardElement
                                    name={name}
                                    config={config}
                                    amount={amount}
                                    vendor={vendor}
                                    url={url}
                                    onPgRegister={onPgRegister}
                                    disable={disable}
                                    currencyPrecision={currencyPrecision}
                                    gatewayId={gatewayId}
                                    onBeforePayment={onBeforePayment}
                                    onUnlockPayment={onUnlockPayment}
                                    tuna={tuna.current}
                                    referenceId={referenceId}
                                    tunaSessionId={tunaSessionId}
                                    diningSessionID={diningSessionID}
                                    sessionId={sessionId}
                                    jwt={jwt}
                                    tip={tip}
                                    onDone={onDone}
                                    onFail={onFail}
                                    onPending={onPending}
                                    onRefreshSession={getTunaSession}
                                    updateTimestamp={updateTimestamp}
                                    customerId={customerId}
                                    cards={creditCardList}
                                    onRemove={removeCardHandler}
                                    onTraceStart={onTraceStart}
                                    onTraceClose={onTraceClose}
                                />
                            </PaymentWrapper>
                        )}

                        {config?.supportMealVoucher && (
                            <PaymentWrapper
                                hasPgGroup={hasPgGroup}
                                visible={isPgElemVisible?.(PaymentElementEnum.MealVoucherPay)}
                            >
                                <MealVoucherElement
                                    name={name}
                                    tuna={tuna.current}
                                    referenceId={referenceId}
                                    tunaSessionId={tunaSessionId}
                                    onRefreshSession={getTunaSession}
                                    diningSessionID={diningSessionID}
                                    sessionId={sessionId}
                                    jwt={jwt}
                                    url={url}
                                    vendor={vendor}
                                    tip={tip}
                                    currencyPrecision={currencyPrecision}
                                    gatewayId={gatewayId}
                                    disable={disable}
                                    config={config}
                                    onDone={onDone}
                                    onFail={onFail}
                                    onPending={onPending}
                                    onBeforePayment={onBeforePayment}
                                    onUnlockPayment={onUnlockPayment}
                                    onPgRegister={onPgRegister}
                                    amount={amount}
                                    updateTimestamp={updateTimestamp}
                                    customerId={customerId}
                                    cards={mealVoucherCardList}
                                    onRemove={removeCardHandler}
                                    onTraceStart={onTraceStart}
                                    onTraceClose={onTraceClose}
                                />
                            </PaymentWrapper>
                        )}
                    </>
                )}

                {!config?.hideApplePay && hasApplePay && !hasGooglePay && tunaSessionId && (
                    <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.ApplePay)}>
                        <ApplePay
                            name={name}
                            diningSessionID={diningSessionID}
                            sessionId={sessionId}
                            url={url}
                            amount={amount}
                            tip={tip}
                            currencyPrecision={currencyPrecision}
                            vendor={vendor}
                            config={config}
                            gatewayId={gatewayId}
                            disable={disable}
                            hasPgGroup={hasPgGroup}
                            sessionToken={tunaSessionId}
                            onBeforePayment={onBeforePayment}
                            onUnlockPayment={onUnlockPayment}
                            onDone={onDone}
                            onPending={onPending}
                            onFail={onFail}
                            onPgRegister={onPgRegister}
                            onTraceStart={onTraceStart}
                            onTraceClose={onTraceClose}
                        />
                    </PaymentWrapper>
                )}
            </div>
        </>
    );
};

export default PayTuna;
