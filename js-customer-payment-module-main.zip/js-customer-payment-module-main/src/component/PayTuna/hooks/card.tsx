import { useState } from 'react';
import * as valid from 'card-validator';
import { ICard } from '../type';
import { CardBrandType } from '../../../utility/payment_checkout';

const CardTypes = {
    'american-express': 'amex',
    visa: 'Visa',
    mastercard: 'Mastercard',
};

const useTunaCards = () => {
    const [cards, setCards] = useState<Array<ICard>>([]);
    const [isAddingCard, setIsAddingCard] = useState(false);
    const [selectedCard, setSelectedCard] = useState<ICard | null>(null);

    const parseBrand = (bin: string): CardBrandType => {
        const cardInfo = valid.number(bin);
        if (cardInfo.card) {
            return CardTypes[cardInfo.card.type as keyof typeof CardTypes] as CardBrandType;
        }
        return 'unknown';
    };

    const handleSelectCard = (card: ICard) => {
        setCards(
            cards.map((c) => {
                return {
                    ...c,
                    selected: c.token === card.token ? !c.selected : false,
                };
            }),
        );
        setSelectedCard(card.selected ? null : card);
        setIsAddingCard(false);
    };

    const handleAddNewCard = () => {
        setIsAddingCard(!isAddingCard);
        // set all cards to unselected
        setCards(
            cards.map((c) => {
                return {
                    ...c,
                    selected: false,
                };
            }),
        );
        setSelectedCard(null);
    };

    return {
        cards,
        setCards,
        isAddingCard,
        setIsAddingCard,
        handleSelectCard,
        selectedCard,
        setSelectedCard,
        handleAddNewCard,
        parseBrand,
    };
};

export default useTunaCards;
