import { useMemo } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

export const useTunaTranslation = () => {
    const { t } = useTranslation('common');

    const labels = useMemo(
        () => ({
            cardHolderName: t('Cardholder name'),
            newCard: t('New card'),
            cvv: t('CVV'),
            cardNumber: t('Card Number'),
            expirationDate: t('Expiration Date'),
            saveCard: t('Save card'),
            securePayment: t('100% Secure payments powered by Qlub_'),
        }),
        [t],
    );

    const errorMessages = useMemo(
        () => ({
            cvv: {
                invalid: t('Invalid CVV'),
                required: t('CVV is required'),
            },
            cardNumber: {
                invalid: t('Invalid card number'),
                required: t('Card number is required'),
            },
            cardHolderName: {
                invalid: t('Invalid cardholder name'),
                required: t('Card holdername is required'),
            },
            expirationDate: {
                invalid: t('Invalid expiration date'),
                required: t('Expiration date is required'),
            },
        }),
        [t],
    );

    return { labels, errorMessages };
};
