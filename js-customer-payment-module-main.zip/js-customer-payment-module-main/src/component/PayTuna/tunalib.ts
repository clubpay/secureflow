declare global {
    interface Window {
        Tuna: (id: string) => any;
    }
}

export {};
