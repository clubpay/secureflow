// migrated to qlub-kit but cant use right now.

const useTunaStyles = () => {
    const cpfStyle = {
        width: '100%',
        '& .MuiOutlinedInput-root': {
            width: '100%',
            '&:hover fieldset': {
                borderColor: 'var(--iris)',
            },
            '&.Mui-focused fieldset': {
                border: '1px solid var(--iris)', // focus
            },
        },
        '&.hasError': {
            '& .MuiOutlinedInput-root': {
                '& fieldset': {
                    borderColor: '#DF1D17',
                },
            },
        },
        '&.valid': {
            '& .MuiOutlinedInput-root': {
                '& fieldset': {
                    borderColor: '#616475',
                },
            },
        },
    };

    return {
        cpfStyle,
    };
};

export default useTunaStyles;
