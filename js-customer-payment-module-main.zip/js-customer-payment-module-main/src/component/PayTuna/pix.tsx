import { CircularProgress } from '@mui/material';
import { Dispatch, SetStateAction, useEffect, useMemo, useRef, useState } from 'react';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import Modal from '@clubpay/customer-common-module/src/component/Modal';
import { qlubSessionStorage } from '@clubpay/customer-common-module/src/service/storage/sessionStorage';
import PayButtonElement from '../PayButtonElement';
import { usePaymentError } from '../../hook/paymentError';
import PaymentAPIManager from '../../repository';
import { PixLogo } from '../../asset/icon';
import { ITunaGateway } from '../../repository/type/paymentGateway';
import { ITunaPixPaymentResponse } from '../../repository/type/tuna';

import styles from './index.module.scss';

interface IProps extends IPGBaseProps, IPGStateCallbacks, IPGHooks {
    config: ITunaGateway;
    referenceId: string;
    tunaSessionId: string;
    pixOpen: boolean;
    tuna?: any;
    onRefreshSession: () => void;
    setPixOpen: Dispatch<SetStateAction<boolean>>;
}

interface IPixCallbackProps {
    allowRetry: boolean;
    code: number;
    paymentApproved: boolean;
    paymentMethodConfimed: boolean;
    paymentStatusFound: string;
}

const PixPayment = ({
    pixOpen,
    onBeforePayment,
    diningSessionID,
    sessionId,
    gatewayId,
    tuna,
    referenceId,
    tunaSessionId,
    amount,
    tip,
    disable,
    currencyPrecision,
    updateTimestamp,
    name,
    setPixOpen,
    onDone,
    onUnlockPayment,
    onPending,
    onRefreshSession,
    onPgRegister,
    onTraceStart,
    onTraceClose,
}: IProps) => {
    const [pixLoading, setPixLoading] = useState(false);
    const pixParams = useRef<ITunaPixPaymentResponse | null>(null);
    const [loading, setLoading] = useState(false);
    const { t } = useTranslation('common');
    const { showError } = usePaymentError();
    const { lang } = useQlubRouter();
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    useEffect(() => {
        qlubSessionStorage.set('qlub.pix.refId', referenceId);
    }, [referenceId]);

    const buttonElement = (
        <PayButtonElement
            variant="contained"
            size="large"
            fullWidth
            loading={loading}
            disabled={disable || loading}
            onClick={() => openPixHandler()}
        />
    );

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.PixPay,
            name: t('Pix'),
            icon: <PixLogo />,
            buttonElement,
            placement: 'bottom',
        });
    }, [buttonElement, lang, amount, tip, updateTimestamp]);

    const loadLoadQR = (res: ITunaPixPaymentResponse) => {
        const pixBoxOpts = {
            title: '',
            subtitle: '',
            copyCodeButtonText: 'Copiar o código',
            showLoader: true,
            loaderText: 'Aguardando pagamento…',
            instructions: [
                'Copie o código',
                'Opção PIX "Copia e cola" no aplicativo do seu banco',
                'Pague e retorne a esta página',
                'Seu pagamento deve ser confirmado em 1 minuto, é só esperar um pouquinho!',
            ],
            methodID: res.methodID,
            pixInfo: {
                qrImage: res.qrImage.includes('https') ? res.qrImage : `data:image/png;base64,${res.qrImage}`,
                qrContent: res.qrContent,
            },
            paymentKey: res.paymentKey,
        };
        pixParams.current = res;

        tuna.current.useQrCodePayment('#pixRoot', pixBoxOpts, (result: IPixCallbackProps) => {
            if (result.paymentApproved) {
                verifyPixPayment();
            }
        });
    };

    const verifyPixPayment = () => {
        if (loading) {
            return;
        }
        setLoading(true);
        PaymentAPIManager.getInstance()
            .tunaVerifyPix({
                gatewayID: gatewayId,
                diningSessionID,
                reference: referenceId,
                id: sessionId,
            })
            .then((res) => {
                if (res.data.success) {
                    onDone({
                        paymentElement: PaymentElementEnum.PixPay,
                        refId: referenceId,
                        traceId: traceStart?.traceId,
                    });
                } else {
                    onTraceClose?.({
                        error: res,
                        location: 'tunaVerifyFix.pending',
                        traceRef,
                        traceStart,
                    });
                    onPending({
                        paymentElement: PaymentElementEnum.PixPay,
                        refId: referenceId,
                        traceId: traceStart?.traceId,
                    });
                }
            })
            .catch((err) => {
                console.log(err);
                onUnlockPayment();
            })
            .finally(() => {
                closeHandler();
                setLoading(false);
            });
    };

    useEffect(() => {
        const focusHandler = () => {
            if (!pixOpen || !tuna.current || !pixParams.current) {
                return;
            }
            tuna.current.doStatusLongPolling(
                (result: IPixCallbackProps) => {
                    if (result.paymentApproved) {
                        verifyPixPayment();
                    }
                },
                pixParams.current.methodID,
                pixParams.current.paymentKey,
            );
        };

        window.addEventListener('focus', focusHandler);
        return () => {
            window.removeEventListener('focus', focusHandler);
        };
    }, [pixOpen]);

    const handlePixPayment = async () => {
        if (tuna.current) {
            try {
                setPixLoading(true);

                traceRef.current = traceStart?.startSpan({
                    dataName: name,
                    span: {
                        element: PaymentElementEnum.PixPay,
                        refId: referenceId,
                    },
                });

                PaymentAPIManager.getInstance()
                    .tunaPixPayment({
                        gatewayID: gatewayId,
                        diningSessionID,
                        reference: referenceId,
                        id: sessionId,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                        method: 'D',
                        sessionToken: tunaSessionId,
                    })
                    .then((res) => {
                        if (res.data) {
                            loadLoadQR(res.data);
                            onBeforePayment({
                                gatewayId,
                                paymentElement: PaymentElementEnum.PixPay,
                                tip,
                            }).catch(() => {
                                setPixLoading(false);
                                setPixOpen(false);
                            });
                        }
                    })
                    .catch((err) => {
                        if (err?.response?.data?.items === 'PAYMENT_REFERENCE_CONFLICTS_TRANSACTION') {
                            onRefreshSession();

                            showError();
                        }

                        onUnlockPayment();
                    })
                    .finally(() => {
                        setPixLoading(false);
                    });
            } catch (err) {
                showError();
                setPixOpen(false);
            }
        } else {
            setPixOpen(false);
        }
    };
    const openPixHandler = () => {
        setPixOpen(true);
        handlePixPayment();
    };

    const closeHandler = () => {
        setPixOpen(false);
        onUnlockPayment();
        onRefreshSession();
    };

    return (
        <>
            <Modal
                sx={{ zIndex: 100000001 }}
                open={pixOpen}
                openHandler={openPixHandler}
                closeHandler={closeHandler}
                noPadding
                key={tunaSessionId}
            >
                {pixLoading && (
                    <div className={styles.modalLoading}>
                        <CircularProgress size={24} />
                    </div>
                )}
                <div className={styles.pixContainer}>
                    <div id="pixRoot" />
                </div>
            </Modal>
            {/* {buttonElement} */}
        </>
    );
};
export default PixPayment;
