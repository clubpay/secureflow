import { isEmpty, some } from 'lodash';
import { IIsFormValid } from '../type';

export const formatMaskedCard = (cardNumber: string) => {
    return cardNumber
        .replace(/x/g, '•')
        .replace(/(.{4})/g, '$1 ')
        .trim();
};

const list = {
    vr: ['637036', '637201', '627416', '637202'],
    sodexo: ['606071', '603389', '606068', '606069'],
};

export const isCardMealVoucher = (bin: string): boolean => {
    return [...list.vr, ...list.sodexo].includes(bin);
};

export const getCardMealVoucherType = (bin: string) => {
    if (list.vr.includes(bin)) {
        return 'vr';
    }
    if (list.sodexo.includes(bin)) {
        return 'sodexo';
    }
    return 'unknown';
};

export const cvcFormat = (value: string, maxLength?: number) => {
    const formatted = value
        .replace(/[^0-9]/g, '')
        .substring(0, maxLength || 4)
        .trim();

    return { formatted };
};

export const isFormValid = ({ selectedCard, cvv, formValues, error, bindSelectedCb }: IIsFormValid) => {
    let isValid = true;

    let hasFormEmptyFields: boolean;

    const isFieldRequiredAndEmpty = (value?: string | boolean) => {
        return isEmpty(value) && typeof value === 'string';
    };

    if (selectedCard && cvv) {
        hasFormEmptyFields = cvv === '';
        bindSelectedCb().then((res) => {
            isValid = res.code === 1;
        });
    } else {
        hasFormEmptyFields = some(formValues, isFieldRequiredAndEmpty);
    }

    // Check if any of the values in the "values" object are falsy, excluding the "saveCard" key

    if (hasFormEmptyFields || some(error, Boolean)) {
        isValid = false;
    }
    return isValid;
};

export const parseExpirationDate = (expirationDate?: string) => {
    const [expMonth = null, expYearRaw = null] = expirationDate?.split('/').map((e) => e.trim()) ?? [];
    const expYear = expYearRaw?.length === 2 ? `20${expYearRaw}` : expYearRaw;

    return { expYear, expMonth };
};

export const formatCPF = (cpf?: string) => {
    if (!cpf) return '';
    return cpf
        .replace(/\D/g, '')
        .replace(/(\d{3})(\d)/, '$1.$2')
        .replace(/(\d{3})(\d)/, '$1.$2')
        .replace(/(\d{3})(\d{1,2})/, '$1-$2')
        .replace(/(-\d{2})\d+?$/, '$1');
};
