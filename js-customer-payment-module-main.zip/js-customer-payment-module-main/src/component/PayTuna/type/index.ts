import { ICardModel } from '../card';
import { CardBrandType } from '../../../utility/payment_checkout';

export interface IBindResponse {
    code: number;
    message: string;
    validFor: number | null;
    authenticationInformation: unknown;
}

export interface ICard {
    bin: string;
    brand?: CardBrandType;
    cardHolderName: string;
    data: null;
    expirationMonth: number;
    expirationYear: number;
    maskedNumber: string;
    singleUse: boolean;
    token: string;
    selected: boolean;
}

export interface ICardData {
    cardNumber?: string;
    expirationDate?: string;
    cvv?: string;
    cardHolderName?: string;
    saveCard?: boolean;
}

export type IIsFormValid = {
    selectedCard: ICard | null;
    cvv: string;
    formValues: ICardModel;
    error: Partial<Record<keyof ICardModel, boolean>>;
    bindSelectedCb: () => Promise<IBindResponse>;
};
