/* eslint-disable no-empty */
/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useState, useRef, useMemo } from 'react';
import Scripts from 'next/script';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { Apple } from '@mui/icons-material';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import {
    IPGBaseProps,
    IPGExchangeProps,
    IPGHooks,
    IPGSplitProps,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import isEmpty from 'lodash/isEmpty';
import { ICheckoutGateway } from '../../repository/type/paymentGateway';
import { useExchangeInteruption } from '../../hook/useExchangeInteruption';
import { ICheckoutPayByApplePayload } from '../../repository/type/checkout';
import { ApplePayButton } from '../ApplePayButton';
import PaymentAPIManager from '../../repository';
import { getPaymentExchangeDecision } from '../../utility/exchange';
import { usePgEvent } from '../../hook/usePgEvent';
import { getApplePayShippingBillingConfig, disableApplePayBilling } from '../../utility/shipping_info';

import styles from './index.module.scss';

interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks, IPGExchangeProps, IPGSplitProps {
    config: ICheckoutGateway;
    hasPgGroup: boolean;
}

export default function PayCheckoutApple({
    diningSessionID,
    sessionId,
    amount,
    tip,
    url,
    name,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    hasPgGroup,
    exchange,
    hasSplitPayment,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onPending,
    onFail,
    onPgRegister,
    onPgUnregister,
    onTraceStart,
    onTraceClose,
    onExchangeChange,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [loading, setLoading] = useState(false);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    const initialSession = useRef<any>(null);
    const retrySession = useRef<any>(null);

    const { sendEvent } = usePgEvent({
        pgName: `${name}_${PaymentElementEnum.GooglePay}`.toLowerCase(),
        diningSessionId: diningSessionID,
        restaurantName: url.slug,
    });
    const { getCallbackUrl } = useConfirmCallback();
    const { triggerInteruption } = useExchangeInteruption({
        pgConfig: config,
        restaurantConfig: vendor.config,
        diningSessionId: diningSessionID,
        pgName: name,
        pgId: gatewayId,
        paymentMethod: PaymentElementEnum.ApplePay,
        restaurantName: url.slug,
        onExchangeChange,
        onPgUnregister,
    });

    const totalAmount = exchange?.isApplied ? exchange.total : sumAmounts(currencyPrecision, amount, tip);

    const createSession = (request: ApplePayJS.ApplePayPaymentRequest, shouldRetry = false) => {
        const session = new ApplePaySession(config?.appleSDKVersion || 3, request);

        session.onvalidatemerchant = (e) => {
            // Call your own server to request a new merchant session.
            onBeforePayment({
                gatewayId,
                paymentElement: PaymentElementEnum.ApplePay,
                tip,
            })
                .then((ok) => {
                    if (!ok) {
                        try {
                            session?.abort();
                        } catch (err) {}
                        return;
                    }

                    setLoading(true);

                    PaymentAPIManager.getInstance()
                        .paymentCheckoutValidateApplePaySession({
                            diningSessionID,
                            applePayUrl: e.validationURL,
                            gatewayID: gatewayId,
                            hostname: window.location.hostname,
                        })
                        .then((res) => {
                            session.completeMerchantValidation(JSON.parse(res.data.jsonData));
                        })
                        .catch(() => {
                            try {
                                session?.abort();
                            } catch (_) {}
                            onUnlockPayment();
                        })
                        .finally(() => {
                            setLoading(false);
                        });
                })
                .catch(() => {
                    setLoading(false);
                });
        };

        session.onpaymentmethodselected = (e) => {
            //* * assume there is no active card in the wallet */
            if (!e.paymentMethod?.type) {
                initialSession.current?.abort();
                setTimeout(() => {
                    retrySession.current?.begin();
                }, config.applepayRetryingTimeout || 500);
                return;
            }

            const update: ApplePayJS.ApplePayPaymentMethodUpdate = {
                newTotal: {
                    label: 'Qlub_',
                    type: 'final',
                    amount: totalAmount.toFixed(currencyPrecision || 0),
                },
            };
            session.completePaymentMethodSelection(update);
        };

        session.onshippingmethodselected = () => {
            const update: any = {};
            session.completeShippingMethodSelection(update);
        };

        session.onshippingcontactselected = () => {
            const update: any = {};
            session.completeShippingContactSelection(update);
        };

        session.onpaymentauthorized = (e) => {
            setLoading(true);

            const refId = getRandomString();
            traceRef.current = traceStart?.startSpan({
                dataName: name,
                span: {
                    element: PaymentElementEnum.ApplePay,
                    refId,
                },
            });

            const returnUrl = getCallbackUrl({
                ref: refId,
                method: name,
                paymentElement: PaymentElementEnum.ApplePay,
                dsi: diningSessionID,
                amount: totalAmount.toFixed(currencyPrecision || 0),
                currencySymbol: vendor.country.currencySymbol,
                traceId: traceStart?.traceId,
                is3ds: true,
            });

            const requestPayload: ICheckoutPayByApplePayload = {
                id: sessionId,
                diningSessionID,
                tipAmount: tip.toFixed(currencyPrecision || 0),
                appleToken: JSON.stringify(e.payment?.token || {}),
                shippingContact: e.payment?.shippingContact,
                billingContact: e.payment?.billingContact,
                reference: refId,
                gatewayID: gatewayId,
                cardType: e.payment?.token?.paymentMethod?.network || '',
                hostname: window.location.hostname,
                isSplitPayment: hasSplitPayment || false,
                exchangeDecision: getPaymentExchangeDecision(exchange),
                successUrl: returnUrl.success,
                failureUrl: returnUrl.fail,
            };

            PaymentAPIManager.getInstance()
                .paymentCheckoutPayByApple(requestPayload)
                .then((response) => {
                    if (response.data.needVerification && response.data.redirectUrl) {
                        sendEvent('payment_initialized', { status: '3ds' });
                        window.location.href = response.data.redirectUrl;
                        return;
                    }
                    if (response.data.exchangeData) {
                        /**
                         *  handle when detect a international card
                         */
                        onUnlockPayment();
                        session.completePayment({ status: ApplePaySession.STATUS_FAILURE });
                        triggerInteruption(response.data.exchangeData, response.data.routingApplied);
                        return;
                    }
                    const result: ApplePayJS.ApplePayPaymentAuthorizationResult = {
                        status: ApplePaySession.STATUS_SUCCESS,
                    };

                    try {
                        session.completePayment(result);
                    } catch (_) {}

                    onDone({
                        paymentElement: PaymentElementEnum.ApplePay,
                        refId,
                        traceId: traceStart?.traceId,
                        meta: {
                            isExchangeInterrupted: !!exchange,
                            isExchangeUsed: exchange?.isApplied,
                        },
                    });

                    enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                })
                .catch((err: Error) => {
                    onTraceClose?.({
                        error: err,
                        location: 'paymentCheckoutPayByApple',
                        traceRef,
                        traceStart,
                    });

                    const result: ApplePayJS.ApplePayPaymentAuthorizationResult = {
                        status: ApplePaySession.STATUS_FAILURE,
                    };
                    try {
                        session.completePayment(result);
                    } catch (_) {}

                    const isNetworkError = checkNetworkError(err as AxiosError);
                    if (isNetworkError) {
                        onPending({
                            paymentElement: PaymentElementEnum.ApplePay,
                            refId,
                            traceId: traceStart?.traceId,
                        });
                    }

                    onFail({
                        paymentElement: PaymentElementEnum.ApplePay,
                        refId,
                        traceId: traceStart?.traceId,
                        meta: {
                            isExchangeInterrupted: !!exchange,
                            isExchangeUsed: exchange?.isApplied,
                        },
                    });
                })
                .finally(() => {
                    setLoading(false);
                });
        };

        session.oncancel = (e: any) => {
            // Payment cancelled by WebKit
            disableApplePayBilling();
            setLoading(false);
            onUnlockPayment();
            onTraceClose?.({
                error: e,
                location: 'checkout_applepay_cancel',
                traceRef,
                traceStart,
            });

            onPushEvent('applepay_cancel', {
                pg_name: name,
                restaurant_name: url.slug,
                opsMode: vendor?.opsMode,
                diningSessionId: diningSessionID,
                forex_ui: vendor?.config?.forexUI ?? 'v1',
            });

            if (shouldRetry) {
                setTimeout(() => {
                    retrySession.current?.begin();
                }, config.applepayRetryingTimeout || 500);
            }
        };

        return session;
    };

    const payHandler = () => {
        if (!ApplePaySession) {
            return;
        }

        const isAttempted = sessionStorage.getItem('attempt_with_preferred_networks');

        const supportedNetworks = config?.supportedNetworksList ||
            config?.supportedNetworks || ['visa', 'masterCard', 'amex', 'discover'];

        const preferredNetworks = config?.preferredNetworks || [];
        const shouldRetry = !isEmpty(preferredNetworks) && !isAttempted;

        const request: ApplePayJS.ApplePayPaymentRequest = {
            countryCode: config?.countryCode || vendor.country.code || 'AE',
            currencyCode:
                (exchange?.isApplied ? exchange.currencyCode : vendor.country.currencyCode)?.toUpperCase() || '',
            merchantCapabilities: (config?.merchantCapabilitiesList as any) ||
                (config?.merchantCapabilities as any) || ['supports3DS'],
            supportedNetworks,
            total: {
                label: 'Qlub_',
                type: 'final',
                amount: totalAmount.toFixed(currencyPrecision || 0),
            },
            ...getApplePayShippingBillingConfig(config),
        };

        initialSession.current = createSession(
            {
                ...request,
                supportedNetworks: shouldRetry ? preferredNetworks : supportedNetworks,
            },
            shouldRetry,
        );

        if (shouldRetry) {
            retrySession.current = createSession(request);
        }

        initialSession.current?.begin();
        sessionStorage.setItem('attempt_with_preferred_networks', 'true');
    };

    const loadScriptHandler = () => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.ApplePay,
            name: 'Apple Pay',
            icon: <Apple />,
            placement: 'bottom',
        });
    };

    return (
        <div className={styles.payButton}>
            <Scripts src="/pg_sdk/apple-pay-sdk.js" onReady={loadScriptHandler} />
            <div className={styles.container} data-area="submit">
                <ApplePayButton
                    onClick={payHandler}
                    theme="dark"
                    disabled={disable || loading}
                    id="checkout-applepay-action-btn"
                    hasPgGroup={hasPgGroup}
                />
            </div>
        </div>
    );
}
