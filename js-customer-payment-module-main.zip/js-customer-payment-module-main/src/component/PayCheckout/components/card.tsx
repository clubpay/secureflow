import { Accordion } from '@mui/material';
import { Card } from '@qlub-dev/qlub-kit';
import React from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { Delete, Edit } from '@mui/icons-material';
import { CardBrandType, getCardIcon } from '../../../utility/payment_checkout';

import styles from '../index.module.scss';

export type ISavedCard = {
    selected: boolean;
    maskedNumber: string;
    brand: string;
    onSelect: () => void;
    onChangeClick: () => void;
    onUnsaveClick: () => void;
    disabled?: boolean;
};
const SavedCard = ({ selected, maskedNumber, brand, onSelect, onChangeClick, onUnsaveClick, disabled }: ISavedCard) => {
    const { t } = useTranslation('common');

    const buttons = [
        {
            onClick: onChangeClick,
            disabled,
            icon: <Edit />,
        },
        {
            onClick: onUnsaveClick,
            disabled,
            icon: <Delete />,
        },
    ];
    return (
        <Accordion className={styles.accordion} data-name="creditCardButton" expanded>
            <Card
                iconPosition="left"
                label={maskedNumber}
                onClick={() => {
                    onSelect();
                }}
                disabled={disabled}
                secondayButtonLabel={t('Change')}
                selected={selected}
                customIcon={getCardIcon(brand?.toLocaleLowerCase() as CardBrandType, 'card')}
                cardOverrides={{
                    borderRadius: '8px',
                    boxShadow: 'none',
                    border: !selected ? '1px solid #E5E5E5' : 'none',
                }}
                buttons={buttons}
            />
        </Accordion>
    );
};

export default SavedCard;
