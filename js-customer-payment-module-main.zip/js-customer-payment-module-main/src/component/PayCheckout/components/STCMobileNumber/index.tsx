import { Button, CustomerContainer, Typography } from '@qlub-dev/qlub-kit';
import { useEffect, useState } from 'react';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import PhoneInputV2 from '@clubpay/customer-common-module/src/component/PhoneInputV2';
import { Box, Stack } from '@mui/material';

interface Props {
    loading: boolean;
    saveStcPayPhoneNumber: boolean;
    sandbox: boolean;
    onConfirm: (phoneNumber: string) => void;
}

const STCMobileNumber = ({ loading, saveStcPayPhoneNumber, sandbox, onConfirm }: Props) => {
    const [phoneNumber, setPhoneNumber] = useState<{ phone: string; inputValue: string }>({
        phone: '',
        inputValue: '',
    });

    const [isValidPhoneNumber, setIsValidPhoneNumber] = useState<boolean>();
    const [showError, setShowError] = useState(false);

    const { url, lang } = useQlubRouter();
    const { t } = useTranslation('common');

    const isValidSandboxPhoneNumber = sandbox && phoneNumber.phone.endsWith('222222222');

    const handleConfirm = () => {
        if (isValidPhoneNumber || isValidSandboxPhoneNumber) {
            onConfirm(phoneNumber?.inputValue);
        } else {
            setShowError(true);
        }
    };

    useEffect(() => {
        const savedPhoneNumber = localStorage.getItem('qlub.stcpay_phone_number');
        if (savedPhoneNumber && saveStcPayPhoneNumber) {
            setPhoneNumber({ phone: savedPhoneNumber, inputValue: '' });
            onConfirm(savedPhoneNumber);
        }
    }, []);

    return (
        <div>
            <CustomerContainer>
                <Stack spacing={1.5} sx={{ pb: 2 }}>
                    <Typography typo="caption_overline" sx={{ color: 'var(--onSurfaceColors-mediumEmphasis)', pb: 2 }}>
                        {t('Enter your phone number in order to use STC pay')}
                    </Typography>
                    <PhoneInputV2
                        value={phoneNumber.phone}
                        onChange={setPhoneNumber}
                        defaultCountry={url.cc}
                        lang={lang}
                        hideErrorText={!showError || isValidSandboxPhoneNumber}
                        errorText={t('Please enter a valid phone number!')}
                        countrySearchLabel={t('Search for countries')}
                        placeholder={t('Enter mobile no')}
                        validation={{
                            enable: true,
                            callbackFn: (isValid) => setIsValidPhoneNumber(isValid),
                            debounceWait: 1000,
                        }}
                    />
                    <Box sx={{ pt: 16 }}>
                        <Button
                            variant="contained"
                            fullWidth
                            onClick={handleConfirm}
                            disabled={loading}
                            loading={loading}
                        >
                            {t('Confirm')}
                        </Button>
                    </Box>
                </Stack>
            </CustomerContainer>
        </div>
    );
};

export default STCMobileNumber;
