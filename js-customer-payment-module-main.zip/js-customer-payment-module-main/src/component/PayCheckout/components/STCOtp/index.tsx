import { useState } from 'react';
import { Button, CustomerContainer, Typography } from '@qlub-dev/qlub-kit';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { TextField } from '@mui/material';
import styles from './index.module.scss';

interface Props {
    phoneNumber: string;
    loading: boolean;
    onConfirm: (otp: string) => void;
}

const STCMobileNumber = ({ phoneNumber, loading, onConfirm }: Props) => {
    const [otp, setOtp] = useState('');
    const { t } = useTranslation('common');

    const handleConfirm = () => onConfirm(otp);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { value } = e.target;
        const numberRegex = /^(\d{1,6})?$/;
        if (numberRegex.test(value)) setOtp(value);
    };

    return (
        <div>
            <CustomerContainer sx={{ pb: 2 }}>
                <div>
                    <Typography typo="caption_overline" sx={{ color: 'var(--onSurfaceColors-mediumEmphasis)' }}>
                        {interpolateT(t('Enter the code sent to your mobile <phoneNumber> from qlub'), {
                            phoneNumber: <span style={{ direction: 'ltr', unicodeBidi: 'embed' }}>{phoneNumber}</span>,
                        })}
                    </Typography>
                    <div className={styles.otpContainer}>
                        <TextField
                            value={otp}
                            className={styles.input}
                            fullWidth
                            label={t('OTP code')}
                            onChange={handleChange}
                        />
                    </div>
                    <Button
                        variant="contained"
                        fullWidth
                        disabled={otp.length < 3 || loading}
                        loading={loading}
                        onClick={handleConfirm}
                    >
                        {t('Confirm and pay')}
                    </Button>
                </div>
            </CustomerContainer>
        </div>
    );
};

export default STCMobileNumber;
