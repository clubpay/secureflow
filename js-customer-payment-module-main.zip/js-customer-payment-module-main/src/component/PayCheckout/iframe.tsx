/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useEffect, useMemo, useRef, useState } from 'react';
import Scripts from 'next/script';
import getConfig from 'next/config';
import { CardNumber, Cvv, ExpiryDate, Frames as CheckoutFrames } from 'frames-react';
import { Box, Grid } from '@mui/material';
import { Checkbox, CustomerContainer, CustomerGrid } from '@qlub-dev/qlub-kit';
import { CreditCard, VerifiedUserOutlined } from '@mui/icons-material';
import {
    FrameCardBinChangedEvent,
    FrameCardTokenizationFailedEvent,
    FrameCardTokenizedEvent,
    FramePaymentMethodChangedEvent,
    FrameValidationChangedEvent,
} from 'frames-react/types/types';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useConfirmCallback, usePaymentTimeout } from '@clubpay/customer-common-module/src/hook/payment';
import { detectRTLFromLang } from '@clubpay/customer-common-module/src/utility/k_lang';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import { ErrorBoundary } from '@sentry/nextjs';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { useExchangeInteruption } from '../../hook/useExchangeInteruption';
import PayButtonElement from '../PayButtonElement';
import { isCheckoutError, useCheckoutErrors } from '../../hook/checkoutErrors';
import SavedCard from './components/card';
import { ICheckoutCard } from './types';
import { maskAndFormatNumber } from './utils';
import { ICheckoutGateway } from '../../repository/type/paymentGateway';
import { isCardMada } from '../../utility/payment_checkout';
import PaymentAPIManager from '../../repository';
import americanExpressLogo from '../../asset/image/american-express.svg';
import masterCardLogo from '../../asset/image/mastercard.svg';
import visaLogo from '../../asset/image/visa.svg';

import styles from './index.module.scss';
import { getPaymentExchangeDecision } from '../../utility/exchange';

const { publicRuntimeConfig } = getConfig();
const pubKey = process?.env?.NEXT_PUBLIC_CHECKOUT_PUB_KEY || '';

interface IProps extends IPGProps {
    config: ICheckoutGateway;
}

let checkoutTotalAmount = 0;
let checkoutTipAmount = 0;
let isMada = false;
let checkoutSaveCard = true;

export default function PayCheckoutIframe({
    diningSessionID,
    sessionId,
    amount,
    tip,
    url,
    currencyPrecision,
    config,
    disable,
    enableButton,
    gatewayId,
    vendor,
    updateTimestamp,
    name,
    exchange,
    hasSplitPayment,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onPending,
    onOverlayClick,
    onIndicator,
    onLoad,
    onPgRegister,
    onPgUnregister,
    onTraceStart,
    onTraceClose,
    onExchangeChange,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [cardType, setCardType] = useState('');
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);
    const [scriptsLoaded, setScriptsLoaded] = useState(false);
    const { timeoutDone } = usePaymentTimeout({
        indicatorTimeout: config?.indicatorTimeout || 0,
        fallbackTimeout: config?.fallbackTimeout || 0,
        indicatorCallback: onIndicator,
        fallbackCallback: onLoad,
    });
    const { lang } = useQlubRouter();
    const { getCallbackUrl } = useConfirmCallback();
    const buttonRef = useRef<HTMLButtonElement | null>(null);
    const [componentKey, setComponentKey] = useState(getRandomString());
    const { hasPgGroup } = vendor.paymentGatewayList;
    const [ref, setRef] = useState(getRandomString());
    const exchangeRef = useRef(exchange);
    const hasSplitPaymentRef = useRef(!!hasSplitPayment);
    const [saveCard, setSaveCard] = useState(true);
    const [savedCard, setSavedCard] = useState<ICheckoutCard | null>(null);
    const [selectedCard, setSelectedCard] = useState<boolean>(false);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const [frameValidation, setFrameValidation] = useState({
        'card-number': { element: 'card-number', isValid: false, isEmpty: false },
        'expiry-date': { element: 'expiry-date', isValid: false, isEmpty: false },
        cvv: { element: 'cvv', isValid: false, isEmpty: false },
    });
    const { setErrorType } = useCheckoutErrors();
    const { isLogin } = useAuth();
    const isRtl = useMemo(() => detectRTLFromLang(lang || ''), [lang]);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    const { triggerInteruption } = useExchangeInteruption({
        pgConfig: config,
        restaurantConfig: vendor.config,
        diningSessionId: diningSessionID,
        pgName: name,
        pgId: gatewayId,
        paymentMethod: PaymentElementEnum.CardPay,
        restaurantName: url.slug,
        onExchangeChange,
        onPgUnregister,
    });

    useEffect(() => {
        setComponentKey(getRandomString());
    }, [lang]);

    useEffect(() => {
        checkoutSaveCard = saveCard;
    }, [saveCard]);

    useEffect(() => {
        exchangeRef.current = exchange;
    }, [exchange]);
    useEffect(() => {
        hasSplitPaymentRef.current = !!hasSplitPayment;
    }, [hasSplitPayment]);

    useEffect(() => {
        if (!isLogin || config?.disableSavedCard) {
            return;
        }
        const fetchPaymentCheckout = async () => {
            const api = PaymentAPIManager.getInstance();
            const res = await api.paymentCheckoutSavedCardDetails();
            setSavedCard(res?.data || null);
            setSelectedCard(!!res?.data);
        };

        fetchPaymentCheckout().catch(() => {
            setSavedCard(null);
            setSelectedCard(false);
        });
    }, [isLogin]);

    const cardNumberChangeHandler = (e: FramePaymentMethodChangedEvent) => {
        setCardType(e.paymentMethod);
    };
    const cardBinChangeHandler = (e: FrameCardBinChangedEvent) => {
        isMada = isCardMada(e.bin);
    };
    const checkoutCardErrorHandler = () => {
        setErrorType(frameValidation);
    };

    const getEventSuffix = () => {
        return savedCard && selectedCard ? 'saved' : '';
    };

    const makePayment = (e?: FrameCardTokenizedEvent) => {
        const amountStr = checkoutTotalAmount.toFixed(currencyPrecision || 0);
        const returnUrl = getCallbackUrl({
            ref,
            method: name,
            paymentElement: PaymentElementEnum.CardPay,
            dsi: diningSessionID,
            amount: amountStr,
            currencySymbol: vendor.country.currencySymbol,
            traceId: traceStart?.traceId,
            lang,
            is3ds: true,
        });

        const pay = () => {
            if (savedCard && selectedCard) {
                return PaymentAPIManager.getInstance().paymentCheckoutPayWithSavedCard({
                    id: sessionId,
                    reference: ref,
                    diningSessionID,
                    tipAmount: checkoutTipAmount.toFixed(currencyPrecision || 0),
                    successUrl: returnUrl.success,
                    failureUrl: returnUrl.fail,
                    gatewayID: gatewayId,
                    sourceId: savedCard.sourceId,
                    isMada: savedCard.isMada,
                    isSplitPayment: hasSplitPaymentRef.current,
                    exchangeDecision: getPaymentExchangeDecision(exchangeRef.current),
                });
            }

            return PaymentAPIManager.getInstance().paymentCheckoutPayByToken({
                id: sessionId,
                reference: ref,
                diningSessionID,
                cardToken: e?.token,
                tipAmount: checkoutTipAmount.toFixed(currencyPrecision || 0),
                successUrl: returnUrl.success,
                failureUrl: returnUrl.fail,
                gatewayID: gatewayId,
                cardType: isMada ? 'mada' : e?.card_type,
                saveCard: config?.disableSavedCard ? false : checkoutSaveCard,
                issuerCountry: e?.issuer_country,
                scheme: e?.scheme,
                isSplitPayment: hasSplitPaymentRef.current,
                exchangeDecision: getPaymentExchangeDecision(exchangeRef.current),
            });
        };

        pay()
            .then((res) => {
                setSuccess(true);

                if (res.data.exchangeData) {
                    onUnlockPayment();
                    triggerInteruption(res.data.exchangeData, res.data.routingApplied);
                    CheckoutFrames.enableSubmitForm();
                    setSuccess(false);
                    return;
                }

                if (res.data.needVerification) {
                    if (!res.data.redirectUrl) {
                        setErrorType(frameValidation, 'otp');
                    }

                    onPushEvent('payment_initialized', {
                        pg_name: name,
                        status: '3ds',
                        restaurant_name: url?.slug,
                        diningSessionId: diningSessionID,
                        isExchangeInterrupted: Boolean(exchangeRef.current),
                        isExchangeUsed: Boolean(exchangeRef.current?.isApplied),
                        forex_ui: vendor?.config?.forexUI ?? 'v1',
                    });

                    window.location.href = res.data.redirectUrl;
                } else {
                    onDone({
                        paymentElement: PaymentElementEnum.CardPay,
                        refId: ref,
                        traceId: traceStart?.traceId,
                        meta: {
                            gaEventSuffix: getEventSuffix(),
                            isExchangeInterrupted: Boolean(exchangeRef.current),
                            isExchangeUsed: Boolean(exchangeRef.current?.isApplied),
                        },
                    });

                    enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                }
            })
            .catch((err) => {
                onTraceClose?.({
                    error: err,
                    location: 'paymentCheckoutPayByToken',
                    traceRef,
                    traceStart,
                });

                const isNetworkError = checkNetworkError(err);
                const match = isCheckoutError(err?.response?.data?.message);
                if (match) {
                    setErrorType(frameValidation, err?.response?.data?.message);

                    setComponentKey(getRandomString());

                    onUnlockPayment();
                } else if (isNetworkError) {
                    onPending({
                        paymentElement: PaymentElementEnum.CardPay,
                        refId: ref,
                        traceId: traceStart?.traceId,
                        meta: {
                            gaEventSuffix: getEventSuffix(),
                        },
                    });
                } else {
                    onFail({
                        paymentElement: PaymentElementEnum.CardPay,
                        refId: ref,
                        traceId: traceStart?.traceId,
                        meta: {
                            gaEventSuffix: getEventSuffix(),
                            isExchangeInterrupted: Boolean(exchangeRef.current),
                            isExchangeUsed: Boolean(exchangeRef.current?.isApplied),
                        },
                    });
                }
            })
            .finally(() => {
                setLoading(false);
            });
    };

    const submitHandler = () => {
        const newRef = getRandomString();
        setRef(newRef);

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.CardPay,
                refId: newRef,
            },
        });

        setLoading(true);
        onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.CardPay,
            tip,
            meta: {
                gaEventSuffix: getEventSuffix(),
            },
        })
            .then((ok) => {
                if (!ok) {
                    setLoading(false);
                    return;
                }
                checkoutTotalAmount = sumAmounts(currencyPrecision, amount, tip);
                checkoutTipAmount = tip;

                if (savedCard && selectedCard && !config?.disableSavedCard) {
                    makePayment();
                    return;
                }

                if (CheckoutFrames.isCardValid()) {
                    CheckoutFrames.submitCard();
                } else {
                    checkoutCardErrorHandler();
                    onUnlockPayment();
                    setLoading(false);
                }
            })
            .catch(() => {
                setLoading(false);
            });
    };

    const cardTokenizeHandler = (e: FrameCardTokenizedEvent) => {
        makePayment(e);
    };
    const cardTokenizeFailedHandler = (e: FrameCardTokenizationFailedEvent) => {
        enqueueSnackbar(`${e.errorCode} ${e.message}`, { variant: 'error' });
        setLoading(false);
    };

    useEffect(() => {
        setComponentKey(getRandomString());
    }, [lang]);

    const buttonElement = useMemo(() => {
        return (
            <PayButtonElement
                variant="contained"
                size="large"
                disabled={disable || loading || success}
                onClick={() => submitHandler()}
                fullWidth
                id="checkout-action-btn"
                loading={loading}
                ref={buttonRef}
                showConfirmText={!hasPgGroup}
            />
        );
    }, [
        tip,
        disable,
        loading,
        success,
        lang,
        updateTimestamp,
        JSON.stringify(frameValidation),
        saveCard,
        selectedCard,
    ]);

    const loadScriptHandler = () => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.CardPay,
            name: t('Card'),
            icon: <CreditCard />,
            buttonElement,
        });
        setScriptsLoaded(true);
        timeoutDone();
        onUnlockPayment();
    };

    const frameValidationChangeHandler = (e: FrameValidationChangedEvent) => {
        setFrameValidation((prevState) => ({ ...prevState, [e.element]: { ...e } }));
    };

    useEffect(() => {
        if (!scriptsLoaded) {
            return;
        }
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.CardPay,
            name: t('Card'),
            icon: <CreditCard />,
            buttonElement,
        });
    }, [lang, buttonElement, updateTimestamp, scriptsLoaded, componentKey, saveCard]);

    const handleScriptError = (err: Error) => {
        onTraceClose?.({
            error: err,
            location: 'paymentCheckoutLoadingScript',
            traceRef,
            traceStart,
        });
    };

    const unsaveCardHandler = () => {
        if (!savedCard) {
            return;
        }
        setLoading(true);

        PaymentAPIManager.getInstance()
            .paymentCheckoutUnsaveCard()
            .then((res) => {
                if (res.data.result) {
                    setSavedCard(null);
                    setSelectedCard(false);
                    setComponentKey(getRandomString());
                    enqueueSnackbar(t('Card has been deleted'), {
                        variant: 'success',
                    });
                } else {
                    enqueueSnackbar(t('Something went wrong while deleting card'), {
                        variant: 'error',
                    });
                }
            })
            .catch(() => {
                enqueueSnackbar(t('Something went wrong while deleting card'), {
                    variant: 'error',
                });
            })
            .finally(() => {
                setLoading(false);
            });
    };

    return (
        <>
            {savedCard && !config?.disableSavedCard && (
                <SavedCard
                    selected={selectedCard}
                    maskedNumber={maskAndFormatNumber(savedCard.bin, savedCard.last4)}
                    brand={savedCard.scheme.toLowerCase()}
                    onSelect={() => {
                        setSelectedCard(true);
                    }}
                    onChangeClick={() => setSelectedCard(false)}
                    onUnsaveClick={() => unsaveCardHandler()}
                    disabled={loading}
                />
            )}
            <ErrorBoundary
                fallback={<>{t('Something went wrong. Please contact the company representative')}</>}
                onError={handleScriptError}
            >
                <Scripts src="https://cdn.checkout.com/js/framesv2.min.js" onReady={loadScriptHandler} />

                {scriptsLoaded && (
                    <>
                        {!selectedCard && (
                            <CustomerContainer className={styles.checkoutContainer}>
                                <Box className={styles.innerForm}>
                                    <CheckoutFrames
                                        key={componentKey}
                                        config={{
                                            publicKey:
                                                config?.publicKey || publicRuntimeConfig.checkoutPublicKey || pubKey,
                                            localization: {
                                                cardNumberPlaceholder: t('Card Number'),
                                                expiryMonthPlaceholder: t('MM'),
                                                expiryYearPlaceholder: t('YY'),
                                                cvvPlaceholder: t('CVV'),
                                            },
                                            style: {
                                                base: {
                                                    fontSize: '18px',
                                                },
                                            },
                                            modes: isRtl ? ['right_to_left'] : undefined,
                                        }}
                                        paymentMethodChanged={cardNumberChangeHandler}
                                        cardBinChanged={cardBinChangeHandler}
                                        cardTokenized={(e) => cardTokenizeHandler(e)}
                                        cardTokenizationFailed={cardTokenizeFailedHandler}
                                        frameValidationChanged={frameValidationChangeHandler}
                                    >
                                        <CustomerContainer padding="1rem 0.5rem 0" className={styles.cardContainer}>
                                            {!enableButton && (
                                                <div className={styles.cardOverlay} onClick={onOverlayClick} />
                                            )}
                                            <CustomerGrid spacing={1}>
                                                <Grid item xs={7}>
                                                    <CardNumber className={styles.cardNumber} />
                                                </Grid>
                                                <Grid item xs={3}>
                                                    <ExpiryDate className={styles.expiryDate} />
                                                </Grid>
                                                <Grid item xs={2}>
                                                    <Cvv className={styles.cvv} />
                                                </Grid>
                                            </CustomerGrid>
                                            <Grid item xs={12} mb={3}>
                                                <div className={styles.cards}>
                                                    <img
                                                        src={visaLogo.src}
                                                        alt="visa"
                                                        className={cardType === 'Visa' ? styles.selected : undefined}
                                                    />
                                                    <img
                                                        src={masterCardLogo.src}
                                                        alt="master card"
                                                        className={
                                                            cardType === 'Mastercard' ? styles.selected : undefined
                                                        }
                                                    />
                                                    <img
                                                        src={americanExpressLogo.src}
                                                        alt="american express"
                                                        className={
                                                            cardType === 'American Express'
                                                                ? styles.selected
                                                                : undefined
                                                        }
                                                    />
                                                </div>
                                            </Grid>
                                        </CustomerContainer>
                                    </CheckoutFrames>
                                    {!config?.disableSavedCard && (
                                        <Checkbox
                                            formOverrides={{ paddingInline: '0.5rem' }}
                                            label={t('Save this card')}
                                            checked={saveCard}
                                            onClick={() => setSaveCard((prevState) => !prevState)}
                                        />
                                    )}
                                </Box>
                                <div className={styles.secureWrapper}>
                                    <div className={styles.secureIcon}>
                                        <VerifiedUserOutlined />
                                    </div>
                                    <div className={styles.secureText}>
                                        {vendor.config.hideLogo
                                            ? t('100% Secure payments')
                                            : t('100% Secure payments powered by Qlub_')}
                                    </div>
                                </div>
                            </CustomerContainer>
                        )}

                        {enableButton && !hasPgGroup && <Box className={styles.submit}>{buttonElement}</Box>}
                    </>
                )}
            </ErrorBoundary>
        </>
    );
}
