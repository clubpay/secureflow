export interface ICheckoutCard {
    bin: string;
    isMada: boolean;
    last4: string;
    scheme: string;
    sourceId: string;
}
