/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useEffect, useState } from 'react';
import { isSafari } from '@clubpay/customer-common-module/src/utility/mobile_check';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { applePayJsAvailable } from '../ApplePayButton/utils/handlers';
import PayCheckoutApple from './applepay';
import PayCheckoutGoogle from './googlepay';
import PayCheckoutIframe from './iframe';
import PaymentWrapper from '../PaymentWrapper';
import { ICheckoutGateway } from '../../repository/type/paymentGateway';

import styles from './index.module.scss';
import StcPay from './stcpay';

export interface IProps extends IPGProps {
    config: ICheckoutGateway;
}

export default function PayCheckout({
    name,
    diningSessionID,
    sessionId,
    jwt,
    url,
    amount,
    tip,
    currencyPrecision,
    config,
    disable,
    enableButton,
    gatewayId,
    vendor,
    updateTimestamp,
    exchange,
    hasSplitPayment,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onPending,
    onOverlayClick,
    onIndicator,
    onLoad,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onPgUnregister,
    onTraceClose,
    onExchangeChange,
}: IProps) {
    const [hasApplePay, setHasApplePay] = useState(false);
    const [hasGooglePay, setHasGooglePay] = useState(false);
    const [refId] = useState<string>(getRandomString());

    const { hasPgGroup } = vendor.paymentGatewayList;
    const { login, isLogin } = useAuth();
    useEffect(() => {
        if (!isLogin) {
            login({ guest: true });
        }
    }, [isLogin]);

    useEffect(() => {
        applePayJsAvailable().then((enable) => {
            setHasApplePay(enable);
        });

        setHasGooglePay(!isSafari());
    }, [url.cc, url.slug, url.id]);

    return (
        <div className={styles.form}>
            {config?.hideApplePay !== true && hasApplePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.ApplePay)}>
                    <PayCheckoutApple
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        vendor={vendor}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        exchange={exchange}
                        hasPgGroup={hasPgGroup}
                        hasSplitPayment={hasSplitPayment}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        onPgUnregister={onPgUnregister}
                        onExchangeChange={onExchangeChange}
                    />
                </PaymentWrapper>
            )}

            {config?.hideGooglePay !== true && hasGooglePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.GooglePay)}>
                    <PayCheckoutGoogle
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        vendor={vendor}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        hasPgGroup={hasPgGroup}
                        onPgUnregister={onPgUnregister}
                        onTraceClose={onTraceClose}
                    />
                </PaymentWrapper>
            )}
            {config?.hideCardPay !== true && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}>
                    <PayCheckoutIframe
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        vendor={vendor}
                        enableButton={enableButton}
                        exchange={exchange}
                        hasSplitPayment={hasSplitPayment}
                        updateTimestamp={updateTimestamp}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onOverlayClick={onOverlayClick}
                        onIndicator={onIndicator}
                        onLoad={onLoad}
                        onPgRegister={onPgRegister}
                        onPgUnregister={onPgUnregister}
                        onTraceStart={onTraceStart}
                        onExchangeChange={onExchangeChange}
                    />
                </PaymentWrapper>
            )}
            {config.enableStcPay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.STCPay)}>
                    <StcPay
                        hasPgGroup={hasPgGroup}
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        refId={refId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        vendor={vendor}
                        updateTimestamp={updateTimestamp}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                    />
                </PaymentWrapper>
            )}
        </div>
    );
}
