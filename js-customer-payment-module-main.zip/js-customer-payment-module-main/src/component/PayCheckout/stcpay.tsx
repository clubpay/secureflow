import React, { useEffect, useMemo, useRef, useState } from 'react';
import { SwipeableCustomerDrawer } from '@qlub-dev/qlub-kit';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import Head from 'next/head';
import { ICheckoutGateway } from '../../repository/type/paymentGateway';
import PaymentAPIManager from '../../repository';
import STCMobileNumber from './components/STCMobileNumber';
import STCOtp from './components/STCOtp';
import { splitPhoneNumber } from './utils';
import { STCPayLogo } from '../../asset/icon';
import { usePgEvent } from '../../hook/usePgEvent';
import PayButtonElement from '../PayButtonElement';

interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks {
    config: ICheckoutGateway;
    hasPgGroup: boolean;
    refId: string;
}

const StcPay = ({
    diningSessionID,
    sessionId,
    refId,
    tip,
    name,
    gatewayId,
    hasPgGroup,
    currencyPrecision,
    disable,
    config,
    vendor,
    url,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onPending,
    onPgRegister,
    onTraceStart,
    onTraceClose,
}: IProps) => {
    const [phoneNumber, setPhoneNumber] = useState('');
    const [open, setOpen] = useState(false);
    const [stcPaymentId, setStcPaymentId] = useState('');
    const [step, setStep] = useState<'mobile' | 'otp'>('mobile');
    const [loading, setLoading] = useState(false);

    const { sendEvent } = usePgEvent({
        pgName: `${name}_${PaymentElementEnum.STCPay}`.toLowerCase(),
        diningSessionId: diningSessionID,
        restaurantName: url.slug,
    });

    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);

    const { getCallbackUrl } = useConfirmCallback();
    const { t } = useTranslation('common');
    const { lang } = useQlubRouter();

    const { triggerSnackBar, actionButton } = snackBar();

    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    const toggleDrawer = () => setOpen(!open);

    const handlePay = async () => {
        const response = await onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.STCPay,
            tip,
            checkTipOnly: true,
        });

        if (response) {
            setStep('mobile');
            setOpen(true);
        }
    };

    const handleConfirmPhoneNumber = async (value: string) => {
        sendEvent('submit_phone_no');
        setLoading(true);

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.STCPay,
                refId,
            },
        });

        try {
            const initialResponse = await onBeforePayment({
                gatewayId,
                paymentElement: PaymentElementEnum.STCPay,
                tip,
            });
            if (!initialResponse) return setLoading(false);

            const { countryCode, number } = splitPhoneNumber(value);

            const returnUrl = getCallbackUrl({
                ref: refId,
                method: name,
                paymentElement: PaymentElementEnum.CardPay,
                dsi: diningSessionID,
                currencySymbol: vendor.country.currencySymbol,
            });

            const response = await PaymentAPIManager.getInstance().paymentCheckoutPayBySTCPay({
                id: sessionId,
                diningSessionID,
                tipAmount: tip.toFixed(currencyPrecision || 0),
                reference: refId,
                gatewayID: gatewayId,
                success_url: returnUrl.success,
                failure_url: returnUrl.fail,
                customer: {
                    name: vendor.name,
                    email: vendor.email,
                    phone: {
                        countryCode: config.sandbox ? '111' : countryCode,
                        number,
                    },
                },
            });
            setStcPaymentId(response.data.id);
            setPhoneNumber(value);
            setStep('otp');
            onUnlockPayment();
        } catch (error) {
            triggerSnackBar(
                t('The payment did not proceed, Please try again'),
                {
                    variant: 'error',
                    autoHideDuration: 3000,
                    action: actionButton,
                },
                true,
            );
            onTraceClose?.({
                error,
                location: 'paymentCheckoutPayByStcPay',
                traceRef,
                traceStart,
            });
            onUnlockPayment();
        }

        setLoading(false);
    };

    const handleConfirmOtp = async (value: string) => {
        sendEvent('submit_otp');
        setLoading(true);

        try {
            const response = await PaymentAPIManager.getInstance().paymentCheckoutPayBySTCPayCapture({
                id: sessionId,
                diningSessionID,
                tipAmount: tip.toFixed(currencyPrecision || 0),
                reference: refId,
                gatewayID: gatewayId,
                paymentId: stcPaymentId,
                processing: {
                    otp_value: value,
                },
            });

            if (config.saveStcPayPhoneNumber) {
                localStorage.setItem('qlub.stcpay_phone_number', phoneNumber);
            }
            setOpen(false);

            if (response.data.isPending) {
                onPending({
                    refId,
                    paymentElement: PaymentElementEnum.STCPay,
                });
            } else {
                onDone({
                    refId,
                    paymentElement: PaymentElementEnum.STCPay,
                });
            }
        } catch (error) {
            triggerSnackBar(
                t('The payment did not proceed, Please try again'),
                {
                    variant: 'error',
                    autoHideDuration: 3000,
                    action: actionButton,
                },
                true,
            );
            onUnlockPayment();
            onTraceClose?.({
                error,
                location: 'paymentCheckoutPayByStcPay',
                traceRef,
                traceStart,
            });
        }
        setLoading(false);
    };

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.STCPay,
            name: 'STC Pay',
            icon: <STCPayLogo />,
            placement: 'bottom',
        });
    }, [lang]);

    return (
        <div>
            <Head>
                <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1" />
            </Head>
            <div data-area="submit">
                <PayButtonElement
                    fullWidth
                    variant="contained"
                    onClick={handlePay}
                    disabled={disable}
                    showConfirmText={hasPgGroup}
                    sx={{ mt: 2 }}
                >
                    {t('Pay with STC pay')}
                </PayButtonElement>
            </div>

            <SwipeableCustomerDrawer
                open={open}
                headerTitle={t(step === 'mobile' ? 'Enter phone number' : 'Enter OTP')}
                onClose={toggleDrawer}
                onOpen={toggleDrawer}
                ModalProps={{ keepMounted: false }}
            >
                {step === 'mobile' && (
                    <STCMobileNumber
                        loading={loading}
                        saveStcPayPhoneNumber={config.saveStcPayPhoneNumber}
                        sandbox={config.sandbox}
                        onConfirm={handleConfirmPhoneNumber}
                    />
                )}
                {step === 'otp' && <STCOtp loading={loading} phoneNumber={phoneNumber} onConfirm={handleConfirmOtp} />}
            </SwipeableCustomerDrawer>
        </div>
    );
};

export default StcPay;
