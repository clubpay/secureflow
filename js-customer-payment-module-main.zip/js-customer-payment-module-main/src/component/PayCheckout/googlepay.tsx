/*
    Creation Time: 2022 - July - 19
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Scripts from 'next/script';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import {
    IPayBeforePaymentHandler,
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { GooglePay } from '@clubpay/customer-common-module/src/component/SVG';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import GooglePayCTA from '../GooglePayCTA';
import { ICheckoutGateway } from '../../repository/type/paymentGateway';
import PaymentAPIManager from '../../repository';
import { usePgEvent } from '../../hook/usePgEvent';

import styles from './index.module.scss';

interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks {
    config: ICheckoutGateway;
    hasPgGroup: boolean;
}

let beforeFn: (payload: IPayBeforePaymentHandler) => Promise<boolean>;
let checkoutTotalAmount = 0;
let checkoutTipAmount = 0;

export default function PayCheckoutGoogle({
    diningSessionID,
    sessionId,
    amount,
    tip,
    name,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    hasPgGroup,
    url,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onPending,
    onFail,
    onPgRegister,
    onTraceStart,
    onPgUnregister,
    onTraceClose,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [loading, setLoading] = useState(false);
    const [refId, setRefId] = useState<string>(getRandomString());
    const paymentsClientRef = useRef<google.payments.api.PaymentsClient | null>(null);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const language = useRef<string>();

    const { sendEvent } = usePgEvent({
        pgName: `${name}_${PaymentElementEnum.GooglePay}`.toLowerCase(),
        diningSessionId: diningSessionID,
        restaurantName: url.slug,
    });
    const { getCallbackUrl } = useConfirmCallback();
    const { lang } = useQlubRouter();

    beforeFn = onBeforePayment;
    checkoutTotalAmount = sumAmounts(currencyPrecision, amount, tip);
    checkoutTipAmount = tip;

    const baseRequest = {
        apiVersion: 2,
        apiVersionMinor: 0,
    };

    const tokenizationSpecification = {
        type: 'PAYMENT_GATEWAY',
        parameters: {
            gateway: 'checkoutltd',
            gatewayMerchantId: config?.publicKey || '',
        },
    };

    const baseCardPaymentMethod: google.payments.api.IsReadyToPayPaymentMethodSpecification = {
        type: 'CARD',
        parameters: {
            allowedAuthMethods: config?.googleAllowedAuthMethods || ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
            allowedCardNetworks: config?.googleAllowedCardNetworks || ['MASTERCARD', 'VISA'],
        },
    };

    const getGoogleIsReadyToPayRequest = (): google.payments.api.IsReadyToPayRequest => {
        return { ...baseRequest, allowedPaymentMethods: [baseCardPaymentMethod] } as any;
    };

    const getGooglePaymentsClient = () => {
        if (paymentsClientRef.current === null) {
            paymentsClientRef.current = new google.payments.api.PaymentsClient({
                environment: config?.sandbox ? 'TEST' : 'PRODUCTION',
            });
        }
        return paymentsClientRef.current;
    };

    const cardPaymentMethod = { ...baseCardPaymentMethod, tokenizationSpecification };

    const getGoogleTransactionInfo = (): google.payments.api.TransactionInfo => {
        return {
            totalPriceStatus: 'FINAL',
            totalPrice: checkoutTotalAmount.toFixed(currencyPrecision || 0),
            countryCode: config?.countryCode || vendor.country.code || 'AE',
            currencyCode: vendor.country.currencyCode?.toUpperCase() || '',
        };
    };

    const getGooglePaymentDataRequest = (): google.payments.api.PaymentDataRequest => {
        const paymentDataRequest: any = { ...baseRequest };
        paymentDataRequest.allowedPaymentMethods = [cardPaymentMethod];
        paymentDataRequest.transactionInfo = getGoogleTransactionInfo();
        paymentDataRequest.merchantInfo = {
            merchantId: config?.googleMerchantId || '',
            merchantName: 'qlub',
        };
        return paymentDataRequest;
    };

    // @ts-ignore
    // function prefetchGooglePaymentData() {
    //     const paymentDataRequest = getGooglePaymentDataRequest();
    //     // transactionInfo must be set but does not affect cache
    //     paymentDataRequest.transactionInfo = {
    //         totalPrice: totalAmount.toFixed(currencyPrecision || 0),
    //         totalPriceStatus: 'NOT_CURRENTLY_KNOWN',
    //         countryCode: config?.countryCode || region || 'AE',
    //         currencyCode: currencyCode?.toUpperCase() || '',
    //     };
    //     const paymentsClient = getGooglePaymentsClient();
    //     paymentsClient.prefetchPaymentData(paymentDataRequest);
    // }

    /**
     * Show Google Pay payment sheet when Google Pay payment button is clicked
     */
    const onGooglePaymentButtonClicked = () => {
        if (disable || loading) {
            return;
        }

        setLoading(true);

        setRefId(getRandomString());
        beforeFn({
            gatewayId,
            paymentElement: PaymentElementEnum.GooglePay,
            tip,
        }).then((ok) => {
            if (!ok) {
                setLoading(false);
                return;
            }

            const paymentDataRequest = getGooglePaymentDataRequest();
            paymentDataRequest.transactionInfo = getGoogleTransactionInfo();

            const returnUrl = getCallbackUrl({
                ref: refId,
                method: name,
                paymentElement: PaymentElementEnum.GooglePay,
                dsi: diningSessionID,
                amount: checkoutTotalAmount.toFixed(currencyPrecision || 0),
                currencySymbol: vendor.country.currencySymbol,
                traceId: traceStart?.traceId,
                lang: language.current,
                is3ds: true,
            });

            const paymentsClient = getGooglePaymentsClient();
            paymentsClient
                .loadPaymentData(paymentDataRequest)
                .then((paymentData) => {
                    // handle the response
                    PaymentAPIManager.getInstance()
                        .paymentCheckoutPayByGoogle({
                            id: sessionId,
                            diningSessionID,
                            tipAmount: checkoutTipAmount.toFixed(currencyPrecision || 0),
                            googleToken: paymentData.paymentMethodData.tokenizationData.token,
                            reference: refId,
                            gatewayID: gatewayId,
                            cardType: paymentData.paymentMethodData.info?.cardNetwork || '',
                            successUrl: returnUrl.success,
                            failureUrl: returnUrl.fail,
                        })
                        .then((response) => {
                            if (response.data.needVerification && response.data.redirectUrl) {
                                sendEvent('payment_initialized', { status: '3ds' });
                                window.location.href = response.data.redirectUrl;
                            } else {
                                onDone({
                                    paymentElement: PaymentElementEnum.GooglePay,
                                    refId,
                                    traceId: traceStart?.traceId,
                                });

                                enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                            }
                        })
                        .catch((err: Error) => {
                            onTraceClose?.({
                                error: err,
                                location: 'paymentCheckoutPayByGoogle',
                                traceRef,
                                traceStart,
                            });

                            const isNetworkError = checkNetworkError(err as AxiosError);
                            if (isNetworkError) {
                                onPending({
                                    paymentElement: PaymentElementEnum.GooglePay,
                                    refId,
                                    traceId: traceStart?.traceId,
                                });
                            }

                            onFail({
                                paymentElement: PaymentElementEnum.GooglePay,
                                refId,
                                traceId: traceStart?.traceId,
                            });
                        })
                        .finally(() => {
                            setLoading(false);
                        });
                })
                .catch((err) => {
                    // show error in developer console for debugging
                    console.error(err);
                    setLoading(false);
                    onUnlockPayment();
                });
        });
    };

    const addGooglePayButton = () => {
        const paymentsClient = getGooglePaymentsClient();
        const button = paymentsClient.createButton({
            onClick: onGooglePaymentButtonClicked,
            allowedPaymentMethods: [baseCardPaymentMethod],
            buttonSizeMode: 'fill',
            buttonType: 'pay',
        });
        document.querySelector('#checkout-google-pay')?.appendChild(button);
    };

    const loadScriptHandler = () => {
        traceRef.current = traceStart?.startSpan?.({
            dataName: name,
            span: {
                element: PaymentElementEnum.GooglePay,
                refId,
            },
        });

        const paymentsClient = getGooglePaymentsClient();
        paymentsClient
            .isReadyToPay(getGoogleIsReadyToPayRequest())
            .then((response) => {
                if (response.result) {
                    onPgRegister?.({
                        pgId: gatewayId,
                        elem: PaymentElementEnum.GooglePay,
                        icon: <GooglePay />,
                        name: t('Google Pay'),
                        placement: 'bottom',
                    });
                    addGooglePayButton();
                }
            })
            .catch((err) => {
                onTraceClose?.({
                    error: err,
                    location: 'paymentsClient.isReadyToPay',
                    traceRef,
                    traceStart,
                });
                onPgUnregister?.({
                    pgId: gatewayId,
                    elem: PaymentElementEnum.GooglePay,
                });
            });
    };

    useEffect(() => {
        language.current = lang;
    }, [lang]);

    return (
        <div className={styles.payButton}>
            <Scripts src="https://pay.google.com/gp/p/js/pay.js" onReady={loadScriptHandler} />
            <GooglePayCTA id="checkout-google-pay" loading={loading} hasPgGroup={hasPgGroup} />
        </div>
    );
}
