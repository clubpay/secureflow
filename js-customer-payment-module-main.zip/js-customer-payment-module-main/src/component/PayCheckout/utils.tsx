/*
 * Creation Time: May 4 - 2023
 * Created By: yasincelebi
 * Name: utils.tsx
 * Copyright 2023 customer-web-app
 */

import { formatMaskedCard } from '../PayTuna/utils';

export function maskNumber(binStr: string, last4: string): string {
    return `${binStr}${'*'.repeat(6)}${last4}`;
}

export function maskAndFormatNumber(binStr: string, last4: string): string {
    return formatMaskedCard(`${binStr}${'*'.repeat(6)}${last4}`);
}

export const splitPhoneNumber = (phoneNumber: string) => {
    const arr = phoneNumber.split(' ');

    const countryCode = arr.shift()?.substring(1) || '';
    const number = arr.join('').replace(/[()-]/g, '');

    return { countryCode, number };
};
