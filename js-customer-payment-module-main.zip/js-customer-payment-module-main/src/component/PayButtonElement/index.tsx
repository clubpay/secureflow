import { FC, ReactNode } from 'react';
import { Button } from '@qlub-dev/qlub-kit';
// @ts-ignore
import { IButtonProps } from '@qlub-dev/qlub-kit/dist/components/Button';
import PaymentTerms from '@clubpay/customer-common-module/src/component/PaymentTerms';

import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { useConfigContext } from '@clubpay/customer-common-module/src/context/config';
import { EnableEnum } from '@clubpay/customer-common-module/src/repository/vendor';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { getConfig } from '../../utility/config';
import styles from './index.module.scss';

interface IProp extends IButtonProps {
    id?: string;
    showConfirmText?: boolean;
    children?: ReactNode;
}

const PayButtonElement: FC<IProp> = ({ id, showConfirmText, loading, children, ...rest }) => {
    const { t } = useTranslation('common');
    const { vendor } = useVendor();
    const { config } = useConfigContext();
    const { lang } = useQlubRouter();

    const changePayNowButtonTextForSG =
        getConfig(vendor?.config, config, 'changePayNowButtonTextForSG') === EnableEnum.Enable && lang === 'en';

    const getContent = () => {
        if (loading) return t('Loading');
        if (children) return children;
        if (changePayNowButtonTextForSG) return t('Pay bill');
        return t('Pay Now');
    };

    return (
        <div className={styles.container}>
            {showConfirmText && <PaymentTerms />}
            <Button sx={{ mt: 2, mb: 3 }} className={styles.button} id={id} loading={loading} {...rest}>
                {getContent()}
            </Button>
        </div>
    );
};
export default PayButtonElement;
