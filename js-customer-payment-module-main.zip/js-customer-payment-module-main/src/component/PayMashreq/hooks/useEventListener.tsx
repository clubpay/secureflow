import { useRef, useEffect, useCallback, RefObject } from 'react';

const isSSR = !(typeof window !== 'undefined' && window.document?.createElement);

function isRefObject<T>(value: unknown): value is RefObject<T> {
    return typeof value === 'object' && value !== null && 'current' in value;
}

const getRefElement = <T,>(element?: RefObject<Element> | T): Element | T | undefined | null => {
    if (element) {
        if (isRefObject(element)) {
            return element.current;
        }
        return element;
    }
    return undefined;
};

interface UseEventListener {
    type: keyof WindowEventMap;
    listener: EventListener;
    element?: RefObject<Element> | Document | Window | null;
    options?: AddEventListenerOptions;
}

export const useEventListener = ({
    type,
    listener,
    element = isSSR ? undefined : window,
    options,
}: UseEventListener): void => {
    const savedListener = useRef<EventListener>();

    useEffect(() => {
        savedListener.current = listener;
    }, [listener]);

    const handleEventListener = useCallback((event: Event) => {
        savedListener.current?.(event);
    }, []);

    useEffect(() => {
        const target = getRefElement(element);
        target?.addEventListener(type, handleEventListener, options);
        return () => target?.removeEventListener(type, handleEventListener);
    }, [type, element, options, handleEventListener]);
};
