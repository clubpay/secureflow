import { IMashreqGateway } from '../../../repository/type/paymentGateway';

interface PaymentSessionConfig {
    session: string;
    fields: any;
    frameEmbeddingMitigation: string[];
    callbacks: any;
    interaction: any;
    locale: string;
}

const SCRIPT_URL = {
    PROD: 'https://ap-gateway.mastercard.com/form/version/72/merchant/',
    TEST: 'https://test-gateway.mastercard.com/form/version/72/merchant/',
};

const usePaymentSession = (qlubConfig: IMashreqGateway) => {
    const generateScriptUrlWithEnv = () => {
        const uppercasedEnv = (qlubConfig?.env?.toUpperCase() as 'PROD' | 'TEST') || 'PROD';
        const params = {
            debug: qlubConfig?.env?.toUpperCase() === 'TEST' ? 'true' : 'false',
        };

        const url = new URL(`${qlubConfig.merchantId}/session.js`, SCRIPT_URL[uppercasedEnv]);
        url.search = new URLSearchParams(params).toString();

        return url.toString();
    };

    const generateSession = async (config: PaymentSessionConfig) => {
        const scriptSrc = generateScriptUrlWithEnv();

        const loadScript = () => {
            return new Promise((resolve, reject) => {
                const existingScript = document.querySelector(`script[src*="${scriptSrc}"]`);
                console.log('existingScript', existingScript);
                if (existingScript) {
                    existingScript.remove();
                    window.PaymentSession = undefined;
                }

                const scriptElement = document.createElement('script');
                scriptElement.src = scriptSrc;
                scriptElement.onload = resolve;
                scriptElement.onerror = reject;
                document.body.appendChild(scriptElement);
            });
        };

        // PaymentSession object not available yet, wait for the script to load
        return loadScript()
            .then(() => {
                console.log('PaymentSession script loaded.');
                if (window.PaymentSession && typeof window.PaymentSession.configure === 'function') {
                    window.PaymentSession.configure(config);
                    console.log('PAYMENT SESSION', window.PaymentSession);
                    console.log('configured', config);
                } else {
                    console.error('PaymentSession object is not available after script loading.');
                }
            })
            .catch((error) => {
                console.error('Failed to load PaymentSession script:', error);
            });
    };

    return { generateSession };
};

export default usePaymentSession;
