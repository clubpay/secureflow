import React, { useState, useCallback, useRef, useMemo } from 'react';
import Scripts from 'next/script';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { Apple } from '@mui/icons-material';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { ApplePayButton } from '../ApplePayButton';
import PaymentAPIManager from '../../repository';
import { IMashreqGateway } from '../../repository/type/paymentGateway';

import styles from './index.module.scss';

interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks {
    config: IMashreqGateway;
    hasPgGroup: boolean;
    mashreqSessionId: string;
}

export default function PayMashreqApple({
    diningSessionID,
    sessionId,
    amount,
    tip,
    name,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    mashreqSessionId,
    vendor,
    hasPgGroup,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onPending,
    onFail,
    onPgRegister,
    onTraceStart,
    onTraceClose,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [loading, setLoading] = useState(false);
    const [scriptsLoaded, setScriptsLoaded] = useState(false);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    const totalAmount = sumAmounts(currencyPrecision, amount, tip);

    const payHandler = useCallback(() => {
        if (!ApplePaySession) {
            return;
        }

        // Define ApplePayPaymentRequest
        const request: ApplePayJS.ApplePayPaymentRequest = {
            countryCode: config?.countryCode?.toUpperCase() || vendor.country.code?.toUpperCase() || 'AE',
            currencyCode: vendor.country.currencyCode?.toUpperCase() || '',
            merchantCapabilities: (config?.merchantCapabilitiesList as any) ||
                (config?.merchantCapabilities as any) || ['supports3DS'],
            supportedNetworks: (config?.supportedNetworksList as any) ||
                (config?.supportedNetworks as any) || ['visa', 'masterCard', 'amex', 'discover'],
            total: {
                label: 'Qlub_',
                type: 'final',
                amount: totalAmount.toFixed(currencyPrecision || 0),
            },
            ...(config.applePayBillingDetails
                ? {
                      requiredBillingContactFields: ['phone', 'email', 'name'],
                  }
                : {}),
            ...(config.applePayShippingDetails
                ? {
                      requiredShippingContactFields: ['phone', 'email', 'name'],
                  }
                : {}),
        };

        const refId = getRandomString();
        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.ApplePay,
                refId,
            },
        });

        try {
            // Create ApplePaySession
            const session: ApplePaySession = new ApplePaySession(config?.appleSDKVersion || 3, request);

            session.onvalidatemerchant = (e) => {
                console.log({ onvalidatemerchant: e });
                // Call your own server to request a new merchant session.
                onBeforePayment({
                    gatewayId,
                    paymentElement: PaymentElementEnum.ApplePay,
                    tip,
                })
                    .then((ok) => {
                        if (!ok) {
                            try {
                                session?.abort();
                            } catch (err) {
                                console.log(err);
                            }
                            return;
                        }

                        setLoading(true);

                        PaymentAPIManager.getInstance()
                            .paymentMashreqValidateApplePaySession({
                                diningSessionID,
                                applePayUrl: e.validationURL,
                                gatewayID: gatewayId,
                                hostname: window.location.hostname,
                            })
                            .then((res) => {
                                console.log({ res }, JSON.parse(res.data.jsonData));
                                session.completeMerchantValidation(JSON.parse(res.data.jsonData));
                            })
                            .catch((error: any) => {
                                console.log('error.onValidateMerchant.catch', error);
                                try {
                                    session?.abort();
                                } catch (err) {
                                    console.log(err);
                                }
                                onUnlockPayment();
                            })
                            .finally(() => {
                                setLoading(false);
                            });
                    })
                    .catch((error: any) => {
                        console.log('error.onBeforePayment.onValidateMerchant.catch', error);
                        setLoading(false);
                    });
            };

            session.onpaymentmethodselected = (e) => {
                // Define ApplePayPaymentMethodUpdate based on the selected payment method.
                // No updates or errors are needed, pass an empty object.
                const update: ApplePayJS.ApplePayPaymentMethodUpdate = {
                    newTotal: {
                        label: 'Qlub_',
                        type: 'final',
                        amount: totalAmount.toFixed(currencyPrecision || 0),
                    },
                };
                session.completePaymentMethodSelection(update);
                console.log({ onpaymentmethodselected: e });
            };

            session.onshippingmethodselected = (e) => {
                // Define ApplePayShippingMethodUpdate based on the selected shipping method.
                // No updates or errors are needed, pass an empty object.
                const update: any = {};
                session.completeShippingMethodSelection(update);
                console.log({ onshippingmethodselected: e });
            };

            session.onshippingcontactselected = (e) => {
                // Define ApplePayShippingContactUpdate based on the selected shipping contact.
                const update: any = {};
                session.completeShippingContactSelection(update);
                console.log({ onshippingcontactselected: e });
            };

            session.onpaymentauthorized = (e) => {
                setLoading(true);
                PaymentAPIManager.getInstance()
                    .paymentMashreqPayByApple({
                        id: sessionId,
                        diningSessionID,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                        appleToken: JSON.stringify(e.payment?.token || {}),
                        shippingContact: e.payment?.shippingContact,
                        billingContact: e.payment?.billingContact,
                        reference: refId,
                        gatewayID: gatewayId,
                        cardType: e.payment?.token?.paymentMethod?.network || '',
                        hostname: window.location.hostname,
                        mashreqSessionId,
                    })
                    .then(() => {
                        const result: ApplePayJS.ApplePayPaymentAuthorizationResult = {
                            status: ApplePaySession.STATUS_SUCCESS,
                        };

                        try {
                            session.completePayment(result);
                        } catch (err) {
                            console.log(err);
                        }

                        onDone({
                            paymentElement: PaymentElementEnum.ApplePay,
                            refId,
                            traceId: traceStart?.traceId,
                        });

                        enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                    })
                    .catch((err: Error) => {
                        onTraceClose?.({
                            error: err,
                            location: 'paymentMashreqPayByApple',
                            traceRef,
                            traceStart,
                        });

                        // Define ApplePayPaymentAuthorizationResult
                        const result: ApplePayJS.ApplePayPaymentAuthorizationResult = {
                            status: ApplePaySession.STATUS_FAILURE,
                        };
                        try {
                            session.completePayment(result);
                        } catch (error) {
                            console.log(error);
                        }

                        const isNetworkError = checkNetworkError(err as AxiosError);
                        if (isNetworkError) {
                            onPending({
                                paymentElement: PaymentElementEnum.ApplePay,
                                refId,
                                traceId: traceStart?.traceId,
                            });
                        }

                        onFail({
                            paymentElement: PaymentElementEnum.ApplePay,
                            refId,
                            traceId: traceStart?.traceId,
                        });

                        console.log({ onpaymentauthorized: e, err });
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            };

            session.oncancel = (e: any) => {
                // Payment cancelled by WebKit
                setLoading(false);
                console.log({ oncancel: e });
                onUnlockPayment();
            };

            session.begin();
        } catch (e) {
            console.warn({ applePay: e });
        }
    }, [amount, tip, scriptsLoaded, onBeforePayment]);

    const loadScriptHandler = () => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.ApplePay,
            name: 'Apple Pay',
            icon: <Apple />,
            placement: 'bottom',
        });

        setScriptsLoaded(true);
    };

    return (
        <div className={styles.payButton}>
            <Scripts src="/pg_sdk/apple-pay-sdk.js" onReady={loadScriptHandler} />
            <div className={styles.container} data-area="submit">
                <ApplePayButton
                    onClick={payHandler}
                    theme="dark"
                    disabled={disable || loading}
                    id="mashreq-applepay-action-btn"
                    hasPgGroup={hasPgGroup}
                />
            </div>
        </div>
    );
}
