declare global {
    interface Window {
        PaymentSession?: {
            configure: ({ options }: any) => void;
            updateSessionFromForm: (type: string) => void;
            setFocusStyle: (elems: string[], props: Record<string, string>) => void;
            onCardTypeChange(param: (selector: string, result: any) => void): void;
        };
    }
}

export {};
