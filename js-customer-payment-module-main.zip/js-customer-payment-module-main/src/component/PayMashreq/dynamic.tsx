import React, { useEffect, useState } from 'react';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import PaymentAPIManager from '../../repository';
import Card from './card';
import PaymentWrapper from '../PaymentWrapper';
import PayMashreqApple from './applepay';
import { applePayJsAvailable } from '../ApplePayButton/utils/handlers';
import { IMashreqGateway } from '../../repository/type/paymentGateway';

export interface IProps extends IPGProps {
    config: IMashreqGateway;
}

const PayMashreq = ({
    amount,
    disable,
    diningSessionID,
    sessionId,
    jwt,
    gatewayId,
    config,
    vendor,
    tip,
    currencyPrecision,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onPending,
    onTraceStart,
    onTraceClose,
    name,
    onPgRegister,
    url,
    isPgElemVisible,
    updateTimestamp,
    onPgUnregister,
}: IProps) => {
    const [mashreqSessionId, setMashreqSessionId] = useState<string>('');
    const { hasPgGroup } = vendor.paymentGatewayList;

    console.log('hasPgGroup', { vendor });

    const [hasApplePay, setHasApplePay] = useState(false);
    const { login, isLogin } = useAuth();
    useEffect(() => {
        if (!isLogin) {
            login({ guest: true });
        }
    }, [isLogin]);

    useEffect(() => {
        applePayJsAvailable().then((enable) => {
            setHasApplePay(enable);
        });
    }, [url.cc, url.slug, url.id]);

    useEffect(() => {
        generateSession();
    }, []);

    const generateSession = () => {
        PaymentAPIManager.getInstance()
            .generateSessionMashreq({
                diningSessionID,
                gatewayID: gatewayId,
            })
            .then((res) => {
                if (res.data) {
                    setMashreqSessionId(res.data.sessionId);
                }
            })
            .catch((err) => {
                console.log(err);
            });
    };
    return (
        <div>
            {config?.hideApplePay !== true && hasApplePay && mashreqSessionId && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.ApplePay)}>
                    <PayMashreqApple
                        mashreqSessionId={mashreqSessionId}
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        vendor={vendor}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        onPgUnregister={onPgUnregister}
                        hasPgGroup={hasPgGroup}
                    />
                </PaymentWrapper>
            )}
            {config?.hideCardPay !== true && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}>
                    {mashreqSessionId && (
                        <Card
                            mashreqSessionId={mashreqSessionId}
                            disable={disable}
                            config={config}
                            vendor={vendor}
                            amount={amount}
                            tip={tip}
                            gatewayId={gatewayId}
                            diningSessionID={diningSessionID}
                            sessionId={sessionId}
                            jwt={jwt}
                            onBeforePayment={onBeforePayment}
                            currencyPrecision={currencyPrecision}
                            name={name}
                            url={url}
                            onPending={onPending}
                            onPgRegister={onPgRegister}
                            onTraceStart={onTraceStart}
                            onTraceClose={onTraceClose}
                            onFail={onFail}
                            onDone={onDone}
                            onUnlockPayment={onUnlockPayment}
                            setMashreqSessionId={setMashreqSessionId}
                        />
                    )}
                </PaymentWrapper>
            )}
        </div>
    );
};

export default PayMashreq;
