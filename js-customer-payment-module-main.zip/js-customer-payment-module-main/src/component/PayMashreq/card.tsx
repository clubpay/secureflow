import { CustomerContainer, CustomerDrawer, CustomerGrid } from '@qlub-dev/qlub-kit';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Box, Grid, Skeleton } from '@mui/material';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import { CreditCard } from '@mui/icons-material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { parseJSON } from '@clubpay/customer-common-module/src/utility/k_json';
import { LOCK_OVERLAY_Z_INDEX } from '@clubpay/customer-common-module/src/const';
import { debounce } from 'lodash';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { FormSessionResponse, ResponseStatus } from './types';
import useMashreqError from './useMashreqError';
import { usePaymentError } from '../../hook/paymentError';
import usePaymentSession from './hooks';
import { useEventListener } from '../PayTapp/useEventListener';
import { IMashreqGateway } from '../../repository/type/paymentGateway';
import PaymentAPIManager from '../../repository';
import MashreqInput from './components/input';
import PayButtonElement from '../PayButtonElement';

import styles from './index.module.scss';

export interface ICardFormProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks {
    mashreqSessionId: string;
    setMashreqSessionId: (sessionId: string) => void;
    config: IMashreqGateway;
}

const Card = ({
    disable,
    diningSessionID,
    sessionId,
    gatewayId,
    tip,
    config,
    name,
    currencyPrecision,
    amount,
    vendor,
    onTraceStart,
    mashreqSessionId,
    setMashreqSessionId,
    onDone,
    onFail,
    onPending,
    updateTimestamp,
    onBeforePayment,
    onTraceClose,
    onPgRegister,
}: ICardFormProps) => {
    const [loading, setLoading] = useState(false);
    const { lang } = useQlubRouter();
    const { handleError, showError, errorTranslations } = useMashreqError();
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const { showError: showPaymentError } = usePaymentError();
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const { t } = useTranslation('common');
    const [iframeHtml, setIframeHtml] = useState<string | undefined>(undefined);
    const [open3DS, setOpen3DS] = useState(false);
    const [refId, setRefId] = useState<string>(getRandomString());
    const [showInputs, setShowInputs] = useState(false);
    const [containerKey, setContainerKey] = useState(1);
    const { hasPgGroup } = vendor.paymentGatewayList;

    const { getCallbackUrl } = useConfirmCallback();

    useEventListener({ type: 'message', element: window, listener: handle3DSResponse });

    function handle3DSResponse(event: Event) {
        const { data } = event as MessageEvent;
        if (!data) {
            return;
        }
        const threeDsData = parseJSON(data) as { result: string };
        if (!threeDsData || !threeDsData.result) {
            return;
        }

        const { result } = threeDsData;

        setOpen3DS(false);
        setIframeHtml(undefined);

        if (result !== 'SUCCESS') {
            onFail({
                paymentElement: PaymentElementEnum.CardPay,
                refId,
                traceId: traceStart?.traceId,
            });
            return;
        }

        PaymentAPIManager.getInstance()
            .paymentMashreqAuthorize({ mashreqSessionId })
            .then((response) => {
                switch (response.data.status) {
                    case 'success':
                        onDone({
                            paymentElement: PaymentElementEnum.CardPay,
                            refId,
                            traceId: traceStart?.traceId,
                        });
                        break;
                    case 'pending':
                    default:
                        onPending({
                            paymentElement: PaymentElementEnum.CardPay,
                            refId,
                            traceId: traceStart?.traceId,
                        });
                        break;
                }
            })
            .catch(() => {
                onFail({
                    paymentElement: PaymentElementEnum.CardPay,
                    refId,
                    traceId: traceStart?.traceId,
                });
            });
    }

    const totalAmount = sumAmounts(currencyPrecision, amount, tip);

    const { generateSession } = usePaymentSession(config);

    const getMashreqSession = async () => {
        setContainerKey((o) => o + 1);
        setShowInputs(false);
        await generateSession({
            session: mashreqSessionId,
            fields: {
                card: {
                    number: '#card-number',
                    securityCode: '#security-code',
                    expiryMonth: '#expiry-month',
                    expiryYear: '#expiry-year',
                },
            },
            frameEmbeddingMitigation: ['javascript', 'x-frame-options', 'csp'],
            locale: lang || 'en',
            callbacks: {
                initialized(response: any) {
                    handleEvents();
                    console.log('before initialized', response);
                    setShowInputs(true);
                    console.log('initialized');
                },
                formSessionUpdate(response: FormSessionResponse) {
                    console.log(response);
                    if (response?.status === ResponseStatus.OK) {
                        const { session } = response;
                        setMashreqSessionId(session.id);
                        if (!response.sourceOfFunds.provided.card.securityCode) {
                            showError(errorTranslations.ERROR_IN_FIELDS.securityCode!.missing);
                            return;
                        }

                        makeQlubPayment({
                            cardBrand: response.sourceOfFunds.provided.card.scheme,
                            sessId: session.id,
                        });
                    } else {
                        handleError(response);
                    }
                },
            },
            interaction: {
                displayControl: {
                    formatCard: 'EMBOSSED',
                    invalidFieldCharacters: 'REJECT',
                },
            },
        });
    };

    useEffect(() => {
        const delayedGenerateSession = debounce(() => {
            getMashreqSession();
        }, 512);
        delayedGenerateSession();
        return () => {
            // Cleanup the debounce timer when the effect is re-run or unmounted
            delayedGenerateSession.cancel();
        };
    }, [mashreqSessionId, updateTimestamp, lang, totalAmount]);

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.CardPay,
            name: t('Card'),
            icon: <CreditCard />,
            buttonElement: buttonElement(),
        });
    }, [disable, loading, updateTimestamp, totalAmount]);

    const buttonElement = () => {
        return (
            <PayButtonElement
                variant="contained"
                size="large"
                disabled={disable || loading}
                onClick={() => pay()}
                fullWidth
                id="mashreq-action-btn"
                loading={loading}
                showConfirmText={!hasPgGroup}
            />
        );
    };

    const makeQlubPayment = ({ cardBrand, sessId }: { cardBrand: string; sessId: string }) => {
        const ref = getRandomString();
        setRefId(ref);

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.CardPay,
                refId: ref,
            },
        });

        const returnUrl = getCallbackUrl({
            ref,
            method: name,
            paymentElement: PaymentElementEnum.CardPay,
            dsi: diningSessionID,
            amount: totalAmount,
            currencySymbol: vendor.country.currencySymbol,
            traceId: traceStart?.traceId,
            lang,
        });

        onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.ApplePay,
            tip,
        }).then((ok) => {
            if (!ok) {
                setLoading(false);
                return;
            }

            PaymentAPIManager.getInstance()
                .paymentMashreqPay({
                    id: sessionId,
                    diningSessionID,
                    cardBrand,
                    billingCountry: vendor.country.code,
                    failureUrl: returnUrl.fail,
                    gatewayID: gatewayId,
                    mashreqSessionId: sessId,
                    reference: ref,
                    successUrl: returnUrl.success,
                    tipAmount: tip.toFixed(currencyPrecision || 0),
                })
                .then((res) => {
                    if (res.data.needVerification) {
                        if (!res.data.redirectUrl && !res.data.redirectHtml) {
                            showPaymentError();
                            setLoading(false);
                            return;
                        }

                        if (res.data.redirectHtml) {
                            setIframeHtml(res.data.redirectHtml);
                            setOpen3DS(true);
                        } else if (res.data.redirectUrl) {
                            window.location.href = res.data.redirectUrl;
                        } else {
                            showPaymentError();
                            setLoading(false);
                        }
                    } else {
                        onDone({
                            paymentElement: PaymentElementEnum.CardPay,
                            refId: ref,
                            traceId: traceStart?.traceId,
                        });
                    }
                })
                .catch((err) => {
                    onTraceClose?.({
                        error: err,
                        location: 'paymentCheckoutPayByToken',
                        traceRef,
                        traceStart,
                    });

                    const isNetworkError = checkNetworkError(err);

                    if (isNetworkError) {
                        onPending({
                            paymentElement: PaymentElementEnum.CardPay,
                            refId: ref,
                            traceId: traceStart?.traceId,
                        });
                    } else {
                        onFail({
                            paymentElement: PaymentElementEnum.CardPay,
                            refId: ref,
                            traceId: traceStart?.traceId,
                        });
                    }
                })
                .finally(() => {
                    setLoading(false);
                });
        });
    };

    const pay = () => {
        window.PaymentSession?.updateSessionFromForm('card');
    };

    const handleEvents = () => {
        window.PaymentSession?.setFocusStyle(
            ['card.number', 'card.securityCode', 'card.expiryYear', 'card.expiryMonth'],
            {
                outline: '0',
                borderColor: 'hsla(210, 96%, 45%, 50%)',
                boxShadow:
                    '0px 1px 1px rgba(0, 0, 0, 0.03), 0px 3px 6px rgba(0, 0, 0, 0.02), 0 0 0 3px hsla(210, 96%, 45%, 25%), 0 1px 1px 0 rgba(0, 0, 0, 0.08)',
            },
        );
    };

    useEffect(() => {
        if (!open3DS || !iframeHtml) return;

        console.log('??');
        const script = document.getElementById('authenticate-payer-script') as HTMLScriptElement;
        if (script) {
            // eslint-disable-next-line no-eval
            eval(script.text);
        }
    }, [open3DS, iframeHtml]);

    return (
        <>
            <CustomerContainer className={styles.formContainer}>
                <CustomerGrid key={containerKey} container spacing={1} sx={{ display: showInputs ? 'flex' : 'none' }}>
                    <Grid item xs={12}>
                        <MashreqInput
                            title="card number"
                            id="card-number"
                            ariaLabel="enter your card number"
                            placeholder="1234 1234 1234 1234"
                            label={t('Card Number')}
                        />
                    </Grid>
                    <Grid item xs={6}>
                        <MashreqInput
                            title="expiry month"
                            id="expiry-month"
                            ariaLabel="enter expiry month"
                            placeholder="MM"
                            label={t('Expiry Month')}
                        />
                    </Grid>
                    <Grid item xs={6}>
                        <MashreqInput
                            title="expiry year"
                            id="expiry-year"
                            ariaLabel="enter expiry year"
                            placeholder="YY"
                            label={t('Expiry Year')}
                        />
                    </Grid>
                    <Grid item xs={12}>
                        <MashreqInput
                            title="security code"
                            id="security-code"
                            ariaLabel="enter security code"
                            placeholder="123"
                            label={t('Security Code')}
                        />
                    </Grid>
                </CustomerGrid>
                {!showInputs && (
                    <>
                        <Skeleton height="64px" width="100%" />
                        <Box display="flex" gap={1}>
                            <Skeleton height="64px" width="50%" />
                            <Skeleton height="64px" width="50%" />
                        </Box>
                        <Skeleton height="64px" width="100%" />
                    </>
                )}
            </CustomerContainer>
            {open3DS && iframeHtml && (
                <CustomerDrawer
                    disablePortal
                    open={open3DS}
                    sx={{ zIndex: LOCK_OVERLAY_Z_INDEX + 1 }}
                    onClose={() => {
                        setOpen3DS(false);
                    }}
                    classes={{
                        root: '3ds-modal',
                    }}
                    headerTitle="3D Secure"
                >
                    <div className={styles.modal}>
                        <div id="3ds-modal" dangerouslySetInnerHTML={{ __html: iframeHtml }} />
                    </div>
                </CustomerDrawer>
            )}
            {!hasPgGroup && buttonElement()}
        </>
    );
};
export default Card;
