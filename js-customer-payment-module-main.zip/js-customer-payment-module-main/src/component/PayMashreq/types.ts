export type FormSessionResponse = {
    status: ResponseStatus;
    sourceOfFunds: {
        provided: {
            card: {
                securityCode: string;
                scheme: string;
            };
        };
    };
    errors?: FormErrors;
    session: {
        id: string;
    };
};
export type FormErrors = {
    cardNumber?: FormErrorType;
    expiryYear?: FormErrorType;
    expiryMonth?: FormErrorType;
    securityCode?: FormErrorType;
    cardHolderName?: FormErrorType;
    message?: string;
};
export type FormErrorType = 'invalid' | 'missing';

export enum ResponseStatus {
    OK = 'ok',
    ERROR_IN_FIELDS = 'fields_in_error',
    REQUEST_TIMEOUT = 'request_timeout',
    SYSTEM_ERROR = 'system_error',
}
