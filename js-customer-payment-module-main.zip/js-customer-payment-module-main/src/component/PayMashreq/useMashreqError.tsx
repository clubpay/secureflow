/*
 * Creation Time: June 6 - 2023
 * Created By: yasincelebi
 * Name: useMashreqError.tsx
 * Copyright 2023 customer-web-app
 */

import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { FormErrors, FormErrorType, FormSessionResponse, ResponseStatus } from './types';

type ErrorTranslations = {
    SYSTEM_ERROR: string;
    REQUEST_TIMEOUT: string;
    ERROR_IN_FIELDS: {
        [key in keyof FormErrors]: {
            [type in FormErrorType]: string;
        };
    } & {
        default: string;
    };
};
const useMashreqError = () => {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar, actionButton } = snackBar();
    const errorTranslations: ErrorTranslations = {
        SYSTEM_ERROR: t('The payment did not proceed, please try again'),
        REQUEST_TIMEOUT: t('The payment transaction has been timed out, please try again'),
        ERROR_IN_FIELDS: {
            cardNumber: {
                invalid: t('Card number is invalid'),
                missing: t('Card number is required'),
            },
            cardHolderName: {
                invalid: t('Card holder name is invalid'),
                missing: t('Card holder name is required'),
            },
            expiryYear: {
                invalid: t('Expiry year is invalid'),
                missing: t('Expiry year is required'),
            },
            expiryMonth: {
                invalid: t('Expiry month is invalid'),
                missing: t('Expiry month is required'),
            },
            securityCode: {
                invalid: t('Security code is invalid'),
                missing: t('Security code is required'),
            },
            default: t('Form is invalid. Please check and try again.'),
        },
    } as const;

    const handleError = (response: FormSessionResponse) => {
        switch (response.status) {
            case ResponseStatus.SYSTEM_ERROR:
                handleSystemError();
                break;
            case ResponseStatus.ERROR_IN_FIELDS:
                handleValidationError(response.errors);
                break;
            case ResponseStatus.REQUEST_TIMEOUT:
                handleTimeoutError();
                break;
            default:
                handleSystemError();
                break;
        }
    };

    const showError = (message: string) => {
        enqueueSnackbar(message, { variant: 'error', action: actionButton });
    };

    const handleSystemError = () => {
        showError(errorTranslations.SYSTEM_ERROR);
    };

    const handleTimeoutError = () => {
        showError(errorTranslations.REQUEST_TIMEOUT);
    };

    const handleValidationError = (errs?: FormErrors) => {
        if (!errs) {
            showError(errorTranslations.ERROR_IN_FIELDS.default);
            return;
        }

        const errors: FormErrors = errs || {};
        const errorKeys = Object.keys(errors) as Array<keyof FormErrors>;
        const firstErr = errorKeys.find((key) => errors[key] === 'missing' || errors[key] === 'invalid');
        const message = firstErr ? errorTranslations.ERROR_IN_FIELDS[firstErr] : undefined;

        if (!message || !firstErr) {
            showError(errorTranslations.ERROR_IN_FIELDS.default);
            return;
        }

        showError(message[errors[firstErr] as FormErrorType]);
    };

    return {
        handleError,
        errorTranslations,
        showError,
    };
};

export default useMashreqError;
