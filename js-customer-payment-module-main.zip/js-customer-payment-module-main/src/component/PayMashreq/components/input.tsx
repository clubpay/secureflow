import styles from '../index.module.scss';

export type MashreqInputProps = {
    id: string;
    label: string;
    title: string;
    ariaLabel: string;
    placeholder: string;
};
const MashreqInput = (props: MashreqInputProps) => {
    return (
        <div className={styles.formGroup}>
            <label htmlFor={props.id}>{props.label}</label>
            <input
                style={{ width: '100%' }}
                readOnly
                type="text"
                className={styles.textField}
                id={props.id}
                placeholder={props.placeholder}
            />
        </div>
    );
};

export default MashreqInput;
