/*
    Creation Time: 2022 - feb - 3
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/
import React, { useEffect, useState } from 'react';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js/pure';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { CircularProgress } from '@mui/material';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import ButtonPaymentElements from './buttonElements';
import CheckoutElements from './checkoutElements';
import PaymentAPIManager from '../../repository';
import PaymentWrapper from '../PaymentWrapper';
import { IStripeConnectGateway } from '../../repository/type/paymentGateway';
import { IStripeConnectPaymentIntentResponse } from '../../repository/type/stripeConnect';

import styles from './index.module.scss';

export interface IProps extends IPGProps {
    config: IStripeConnectGateway;
}

const stripeState: {
    isLoaded: boolean;
    promise: any;
} = {
    isLoaded: false,
    promise: undefined,
};

export default function PayStripeConnect({
    name,
    diningSessionID,
    sessionId,
    jwt,
    url,
    amount,
    tip,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    updateTimestamp,
    enableButton,
    onBeforePayment,
    onUnlockPayment,
    onFail,
    onDone,
    onPending,
    onIndicator,
    onLoad,
    onOverlayClick,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onTraceClose,
}: IProps) {
    const { lang } = useQlubRouter();
    const [loading, setLoading] = useState(false);
    const [intentRes, setIntentRes] = useState<IStripeConnectPaymentIntentResponse | undefined>(undefined);
    const [refId, setRefId] = useState<string>(getRandomString());
    const [error, setError] = useState<string>('');
    const [innerEnableButton, setInnerEnableButton] = useState(true);
    const [paymentInit, setPaymentInit] = useState(false);
    const { hasPgGroup } = vendor.paymentGatewayList;
    const { login, isLogin } = useAuth();

    if (!stripeState.isLoaded) {
        stripeState.isLoaded = true;
        loadStripe.setLoadParameters({
            advancedFraudSignals: false,
        });
        stripeState.promise = loadStripe(config?.publishableKey || '', {
            locale: (lang || 'en') as any,
        });
    }

    const getPaymentIntent = () => {
        if (loading) {
            return;
        }
        setLoading(true);
        const ref = getRandomString();
        setRefId(ref);
        setIntentRes(undefined);
        PaymentAPIManager.getInstance()
            .paymentStripeConnectCreatePaymentIntent({
                id: sessionId,
                reference: ref,
                diningSessionID,
                gatewayID: gatewayId,
                automaticPaymentMethodParams: true,
            })
            .then((res) => {
                setIntentRes(res.data);
                setError('');
            })
            .catch((err: any) => {
                console.log({ paymentStripeCreatePaymentIntentErr: err });
            })
            .finally(() => {
                setLoading(false);
            });
    };

    useEffect(() => {
        getPaymentIntent();
    }, []);

    useEffect(() => {
        if (!isLogin) {
            login({ guest: true });
        }
    }, [isLogin]);

    const readyHandler = (isSupported: boolean) => {
        if (!paymentInit) {
            setPaymentInit(true);
            setInnerEnableButton(!isSupported);
        }
    };

    const overlayClickHandler = () => {
        if (!innerEnableButton) {
            setInnerEnableButton(true);
        }
    };

    const refreshIntentHandler = (onlyRefId?: boolean) => {
        if (onlyRefId) {
            setRefId(getRandomString());
        } else {
            // setRefId(getRandomString());
            setIntentRes(undefined);
            setTimeout(() => {
                getPaymentIntent();
            }, 100);
        }
    };

    const total = Math.round(sumAmounts(currencyPrecision, amount, tip) * 100);

    return (
        <div className={styles.form}>
            {intentRes && config?.hideButtonElement !== true && (
                <PaymentWrapper
                    hasPgGroup={hasPgGroup}
                    visible={
                        isPgElemVisible?.(PaymentElementEnum.ApplePay) ||
                        isPgElemVisible?.(PaymentElementEnum.GooglePay)
                    }
                >
                    <Elements
                        stripe={stripeState.promise}
                        options={{
                            locale: (lang || 'en') as any,
                            appearance: {
                                rules: {
                                    '.ApplePayButton': {
                                        borderRadius: '100px',
                                    },
                                },
                                variables: {
                                    borderRadius: '100px',
                                },
                            },
                        }}
                    >
                        <ButtonPaymentElements
                            name={name}
                            diningSessionID={diningSessionID}
                            sessionId={sessionId}
                            jwt={jwt}
                            url={url}
                            intentId={intentRes?.intentID || ''}
                            clientSecret={intentRes?.clientSecret || ''}
                            refId={refId}
                            amount={amount}
                            tip={tip}
                            config={config}
                            currencyPrecision={currencyPrecision}
                            gatewayId={gatewayId}
                            disable={disable}
                            vendor={vendor}
                            onBeforePayment={onBeforePayment}
                            onUnlockPayment={onUnlockPayment}
                            onReady={readyHandler}
                            onDone={onDone}
                            onFail={onFail}
                            onPending={onPending}
                            onLoad={onLoad}
                            onIndicator={onIndicator}
                            onRefreshIntent={refreshIntentHandler}
                            onOverlayClick={onOverlayClick}
                            enableButton={enableButton}
                            onPgRegister={onPgRegister}
                            updateTimestamp={updateTimestamp}
                            onTraceStart={onTraceStart}
                            hasPgGroup={hasPgGroup}
                            onTraceClose={onTraceClose}
                        />
                    </Elements>
                </PaymentWrapper>
            )}
            {config?.hideCardElement !== true && total > 0 && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}>
                    <Elements
                        stripe={stripeState.promise}
                        options={{
                            appearance: {
                                theme: 'stripe',
                                variables: {
                                    fontSizeBase: '18px',
                                },
                            },
                            locale: (lang || 'en') as any,
                            mode: 'payment',
                            currency: vendor.country.currencyCode?.toLowerCase(),
                            amount: total,
                            paymentMethodCreation: 'manual',
                        }}
                    >
                        <CheckoutElements
                            name={name}
                            url={url}
                            refId={refId}
                            disable={disable}
                            enableButton={innerEnableButton}
                            onBeforePayment={onBeforePayment}
                            onUnlockPayment={onUnlockPayment}
                            config={config}
                            gatewayId={gatewayId}
                            amount={amount}
                            vendor={vendor}
                            tip={tip}
                            currencyPrecision={currencyPrecision}
                            diningSessionID={diningSessionID}
                            sessionId={sessionId}
                            jwt={jwt}
                            onFail={onFail}
                            onDone={onDone}
                            onPending={onPending}
                            onOverlayClick={overlayClickHandler}
                            onIndicator={onIndicator}
                            onLoad={onLoad}
                            onRefreshIntent={refreshIntentHandler}
                            onPgRegister={onPgRegister}
                            updateTimestamp={updateTimestamp}
                            onTraceStart={onTraceStart}
                            onTraceClose={onTraceClose}
                        />
                    </Elements>
                </PaymentWrapper>
            )}
            {error !== '' && <div className={styles.error}>{error}</div>}
            {loading && (
                <div className={styles.loading}>
                    <CircularProgress size={24} />
                </div>
            )}
        </div>
    );
}
