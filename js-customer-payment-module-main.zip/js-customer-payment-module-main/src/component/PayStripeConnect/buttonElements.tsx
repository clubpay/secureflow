import React, { useEffect, useMemo, useRef, useState } from 'react';
import { PaymentRequestButtonElement, useElements, useStripe } from '@stripe/react-stripe-js';
import {
    PaymentRequest,
    PaymentRequestPaymentMethodEvent,
    PaymentRequestWallet,
} from '@stripe/stripe-js/types/stripe-js/payment-request';
import { trimAmountStep, trimCurrency } from '@clubpay/customer-common-module/src/utility/k_currency';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { Apple } from '@mui/icons-material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import * as Sentry from '@sentry/browser';
import {
    IPGProps,
    PaymentElementEnum,
    PaymentTypeEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { isEmpty } from 'lodash';
import { GooglePay } from '@clubpay/customer-common-module/src/component/SVG';
import PaymentTerms from '@clubpay/customer-common-module/src/component/PaymentTerms';
import { disableApplePayBilling, getApplePayShippingBillingConfig } from '../../utility/shipping_info';
import { IStripeConnectGateway } from '../../repository/type/paymentGateway';
import { usePaymentError } from '../../hook/paymentError';
import PaymentAPIManager from '../../repository';

import styles from './index.module.scss';

interface IProps extends IPGProps {
    intentId: string;
    clientSecret: string;
    refId: string;
    config: IStripeConnectGateway;
    onRefreshIntent: (onlyRefId?: boolean) => void;
    onReady: (ready: boolean) => void;
    hasPgGroup: boolean;
}

let checkoutTotalAmount = 0;
let checkoutTipAmount = 0;

export default function ButtonPaymentElements({
    diningSessionID,
    sessionId,
    intentId,
    clientSecret,
    refId,
    amount,
    tip,
    config,
    currencyPrecision,
    gatewayId,
    vendor,
    name,
    hasPgGroup,
    onBeforePayment,
    onUnlockPayment,
    onReady,
    onPending,
    onRefreshIntent,
    onPgRegister,
    onTraceStart,
    onTraceClose,
}: IProps) {
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const pr = useRef<PaymentRequest | undefined>(undefined);
    const { showError } = usePaymentError();
    const [loading, setLoading] = useState(false);
    const [disableBilling, setDisableBilling] = useState(false);
    const stripe = useStripe();
    const elements = useElements();
    const [paymentRequest, setPaymentRequest] = useState<any>(null);
    const [paymentElementState, setPaymentElementState] = useState<PaymentElementEnum>(PaymentElementEnum.CardPay);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    const { t } = useTranslation('common');

    const paymentMethodHandler = async (e: PaymentRequestPaymentMethodEvent) => {
        if (!stripe || !elements || loading) {
            return;
        }

        setLoading(true);

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: paymentElementState,
                refId,
            },
        });
        const beforePaymentRes = await onBeforePayment({
            gatewayId,
            paymentElement: paymentElementState,
            tip,
        });

        if (!beforePaymentRes) {
            setLoading(false);
            e.complete('fail');
            return;
        }

        try {
            await PaymentAPIManager.getInstance().paymentStripeConnectPay({
                id: sessionId,
                reference: refId,
                diningSessionID,
                tipAmount: trimAmountStep(checkoutTipAmount, config?.step || 0).toFixed(currencyPrecision || 0),
                gatewayID: gatewayId,
                intentID: intentId,
                shippingContact: {
                    payerName: e.payerName,
                    payerEmail: e.payerEmail,
                    payerPhone: e.payerPhone,
                },
                cardBrand: e.paymentMethod.card?.brand,
                issuerCountry: e.paymentMethod.card?.country,
                paymentMethod: paymentElementState,
                funding: e.paymentMethod.card?.funding,
            });

            const { error: stripeError, paymentIntent } = await stripe.confirmCardPayment(
                clientSecret,
                {
                    payment_method: e.paymentMethod.id,
                },
                { handleActions: true },
            );

            if (stripeError) {
                throw stripeError;
            }

            await PaymentAPIManager.getInstance().paymentStripeConnectVerify({
                id: sessionId,
                reference: refId,
                diningSessionID,
                gatewayID: gatewayId,
                intentID: intentId,
                success: paymentIntent?.status === 'succeeded',
                billAmount: checkoutTotalAmount.toFixed(currencyPrecision || 0),
                tipAmount: checkoutTipAmount.toFixed(currencyPrecision || 0),
                paymentMethod: paymentElementState,
            });

            onPending({
                paymentElement: paymentElementState,
                refId,
                traceId: traceStart?.traceId,
            });

            e.complete(paymentIntent?.status === 'succeeded' ? 'success' : 'fail');
        } catch (err: any) {
            onTraceClose?.({
                error: err,
                location: 'paymentMethodHandler',
                traceRef,
                traceStart,
            });

            console.log({ payStripeConnectError: err });
            e.complete('fail');
            const errData = err?.response?.data || err || {};
            showError(errData, err?.message);

            const isNetworkError = checkNetworkError(err as AxiosError);
            if (isNetworkError) {
                onPending({
                    paymentElement: paymentElementState,
                    refId,
                    traceId: traceStart?.traceId,
                });
            }

            if (
                (errData.code === 412 && errData.items === 'PAYMENT_REFERENCE_CONFLICTS_TRANSACTION') ||
                (err.type && err.type.length > 0)
            ) {
                onRefreshIntent();
            } else {
                onRefreshIntent(true);
            }
            onUnlockPayment();
        }
        setLoading(false);
    };

    useEffect(() => {
        if (!stripe || !elements) {
            return;
        }

        const totalAmount = Math.max(0, sumAmounts(currencyPrecision, amount, tip));
        const shippingBillingConfig = getApplePayShippingBillingConfig(config, PaymentTypeEnum.Stripe);

        try {
            const disableWallets: PaymentRequestWallet[] = ['browserCard'];
            if (config?.hideGooglePay) {
                disableWallets.push('googlePay');
            }
            if (config?.hideApplePay) {
                disableWallets.push('applePay');
            }
            pr.current = stripe.paymentRequest({
                country: config?.countryCode.toUpperCase() || 'US',
                currency: vendor.country.currencyCode.toLocaleLowerCase(),
                total: {
                    label: 'Total',
                    amount: trimCurrency(totalAmount, currencyPrecision),
                },
                requestPayerName: false,
                disableWallets,
                ...shippingBillingConfig,
            });

            pr.current.on('cancel', () => {
                disableApplePayBilling();
                setDisableBilling(true);
                if (!isEmpty(shippingBillingConfig)) {
                    setPaymentRequest(null);
                }
            });

            pr.current.on('shippingaddresschange', async (ev) => {
                if (ev.shippingAddress.country !== 'US') {
                    ev.updateWith({ status: 'invalid_shipping_address' });
                } else {
                    // Perform server-side request to fetch shipping options
                    console.log('shippingaddresschange', { ev });
                }
            });

            // Check the availability of the Payment Request API.
            pr.current?.canMakePayment().then((result) => {
                if (result) {
                    if (result?.applePay) {
                        setPaymentElementState(PaymentElementEnum.ApplePay);

                        onPgRegister?.({
                            elem: PaymentElementEnum.ApplePay,
                            icon: <Apple />,
                            name: t('Apple Pay'),
                            pgId: gatewayId,
                            placement: 'bottom',
                        });
                    } else if (result?.googlePay) {
                        setPaymentElementState(PaymentElementEnum.GooglePay);

                        onPgRegister?.({
                            elem: PaymentElementEnum.GooglePay,
                            icon: <GooglePay />,
                            name: 'Google Pay',
                            pgId: gatewayId,
                            placement: 'bottom',
                        });
                    }

                    setPaymentRequest(pr.current);
                    onReady(true);
                } else {
                    onReady(false);
                }
            });
        } catch (e: any) {
            Sentry.withScope((scope) => {
                scope.setLevel('info');
                Sentry.setContext('errorData', {
                    message: e.message,
                    name: e.name,
                });
                Sentry.captureMessage(e.name);
            });

            enqueueSnackbar(e, { variant: 'error' });
            onUnlockPayment();
        }
    }, [stripe, elements, disableBilling]);

    useEffect(() => {
        if (!pr.current) {
            return undefined;
        }
        pr.current?.on('paymentmethod', paymentMethodHandler);

        return () => {
            pr.current?.off('paymentmethod', paymentMethodHandler);
        };
    }, [pr.current, paymentMethodHandler]);

    useEffect(() => {
        if (pr.current && !pr.current?.isShowing()) {
            const totalAmount = sumAmounts(currencyPrecision, amount, tip);
            pr.current.update({
                currency: vendor.country.currencyCode.toLocaleLowerCase(),
                total: {
                    label: 'Total',
                    amount: trimCurrency(trimAmountStep(totalAmount, config?.step || 0), currencyPrecision),
                },
            });
        }
    }, [pr.current, amount, tip]);

    const clickHandler = () => {
        checkoutTotalAmount = Math.max(0, sumAmounts(currencyPrecision, amount, tip));
        checkoutTipAmount = Math.max(0, tip);
    };

    return (
        <div className={styles.applePay}>
            {paymentRequest && (
                <>
                    {hasPgGroup && <PaymentTerms />}
                    <div data-area="submit">
                        <PaymentRequestButtonElement
                            options={{
                                paymentRequest,
                                style: {
                                    paymentRequestButton: {
                                        type: 'check-out',
                                        height: '46px',
                                    },
                                },
                            }}
                            onClick={clickHandler}
                        />
                    </div>
                </>
            )}
        </div>
    );
}
