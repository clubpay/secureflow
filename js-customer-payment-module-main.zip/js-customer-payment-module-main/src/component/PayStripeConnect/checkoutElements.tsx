/*
    Creation Time: 2022 - Feb - 3
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { PaymentElement, useElements, useStripe } from '@stripe/react-stripe-js';
import { CreditCard, VerifiedUserOutlined } from '@mui/icons-material';
import { useConfirmCallback, usePaymentTimeout } from '@clubpay/customer-common-module/src/hook/payment';
import { CustomerContainer } from '@qlub-dev/qlub-kit';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { getSession } from '@clubpay/customer-common-module/src/service/session/dsi';
import { IStripeConnectGateway } from '../../repository/type/paymentGateway';
import PayButtonElement from '../PayButtonElement';
import { usePaymentError } from '../../hook/paymentError';
import PaymentAPIManager from '../../repository';

import styles from './index.module.scss';

interface IProps extends IPGProps {
    refId: string;
    config: IStripeConnectGateway;
    onRefreshIntent: (onlyRefId?: boolean) => void;
}

export default function CheckoutElements({
    diningSessionID,
    refId,
    amount,
    tip,
    name,
    currencyPrecision,
    config,
    vendor,
    disable,
    enableButton,
    gatewayId,
    updateTimestamp,
    onBeforePayment,
    onUnlockPayment,
    onPending,
    onOverlayClick,
    onIndicator,
    onLoad,
    onRefreshIntent,
    onPgRegister,
    onTraceStart,
    onTraceClose,
}: IProps) {
    const { t } = useTranslation('common');
    const { lang } = useQlubRouter();
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);
    const { timeoutDone } = usePaymentTimeout({
        indicatorTimeout: config?.indicatorTimeout || 0,
        fallbackTimeout: config?.fallbackTimeout || 0,
        indicatorCallback: onIndicator,
        fallbackCallback: onLoad,
    });
    const [componentKey, setComponentKey] = useState(getRandomString());
    const { showError } = usePaymentError();
    const stripe = useStripe();
    const elements = useElements();
    const { getCallbackUrl } = useConfirmCallback();
    const formRef = useRef<HTMLFormElement | null>(null);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const { hasPgGroup } = vendor.paymentGatewayList;

    useEffect(() => {
        elements?.update({
            locale: (lang || 'en') as any,
        });
        setComponentKey(getRandomString());
    }, [lang]);

    const submitHandler = async () => {
        if (!stripe || !elements || loading) {
            return;
        }

        setLoading(true);

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.CardPay,
                refId,
            },
        });

        const beforePaymentRes = await onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.CardPay,
            tip,
        });

        if (!beforePaymentRes) {
            setLoading(false);
            return;
        }

        try {
            const { error: submitError } = await elements?.submit();
            if (submitError) throw submitError;

            const sessionId = getSession();

            const { error: paymentMethodError, paymentMethod } = await stripe.createPaymentMethod({
                elements,
                params: {
                    billing_details: {
                        address: {
                            country: config?.countryCode || 'US',
                        },
                    },
                },
            });

            if (paymentMethodError) throw paymentMethodError;

            const paymentIntent = await PaymentAPIManager.getInstance().paymentStripeConnectCreatePaymentIntent({
                id: sessionId,
                reference: refId,
                diningSessionID,
                gatewayID: gatewayId,
                automaticPaymentMethodParams: true,
            });

            await PaymentAPIManager.getInstance().paymentStripeConnectPay({
                id: sessionId,
                reference: refId,
                diningSessionID,
                tipAmount: tip.toFixed(currencyPrecision || 0),
                gatewayID: gatewayId,
                intentID: paymentIntent.data.intentID,
                cardBrand: paymentMethod.card?.brand,
                issuerCountry: paymentMethod.card?.country,
                paymentMethod: paymentMethod.type,
                funding: paymentMethod.card?.funding,
            });

            const amountStr = sumAmounts(currencyPrecision, amount, tip).toFixed(currencyPrecision || 0);
            const tipStr = tip.toFixed(currencyPrecision || 0);

            const returnUrl = getCallbackUrl({
                ref: refId,
                method: name,
                paymentElement: PaymentElementEnum.CardPay,
                tip: tipStr,
                dsi: diningSessionID,
                amount: amountStr,
                currencySymbol: vendor.country.currencySymbol,
                traceId: traceStart?.traceId,
                lang,
            });

            const { error: confirmError } = await stripe.confirmPayment({
                clientSecret: paymentIntent.data.clientSecret,
                confirmParams: {
                    return_url: returnUrl.pending,
                    payment_method: paymentMethod.id,
                },
            });
            if (confirmError) throw confirmError;

            const { error: paymentIntentError } = await stripe.retrievePaymentIntent(paymentIntent.data.clientSecret);
            if (paymentIntentError) throw paymentIntentError;

            setSuccess(true);
        } catch (error: any) {
            onTraceClose?.({
                error,
                location: 'paymentStripeConnectPay',
                traceRef,
                traceStart,
            });

            const errorData = error?.response?.data || error || {};
            const isNetworkError = checkNetworkError(errorData as AxiosError);

            if (isNetworkError) {
                onPending({
                    paymentElement: PaymentElementEnum.CardPay,
                    refId,
                    traceId: traceStart?.traceId,
                });
            } else {
                onUnlockPayment();
                onRefreshIntent(true);
                showError(errorData, error?.message);
            }
        }

        setLoading(false);
    };

    const buttonElement = useMemo(() => {
        return (
            <div className={styles.submit}>
                <PayButtonElement
                    variant="contained"
                    size="large"
                    fullWidth
                    loading={loading}
                    disabled={disable || loading || success || !elements}
                    onClick={submitHandler}
                    showConfirmText={!hasPgGroup}
                />
            </div>
        );
    }, [loading, elements, success, disable, amount, tip, updateTimestamp, lang]);

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.CardPay,
            name: t('Card'),
            icon: <CreditCard />,
            buttonElement,
        });
    }, [elements, buttonElement, amount, lang]);

    return (
        <form ref={formRef} onSubmit={submitHandler}>
            <CustomerContainer
                key={componentKey}
                className={styles.cardContainer}
                margin="0 0 0 0"
                padding="1rem 0.5rem 3rem"
            >
                {!enableButton && <div className={styles.cardOverlay} onClick={onOverlayClick} />}
                <PaymentElement
                    options={{
                        wallets: {
                            applePay: 'never',
                            googlePay: 'never',
                        },
                        fields: {
                            billingDetails: {
                                address: {
                                    country: 'never',
                                },
                            },
                        },
                    }}
                    onReady={() => {
                        timeoutDone();
                    }}
                />
                <CustomerContainer padding="xs" className={styles.secureWrapper}>
                    <div className={styles.secureIcon}>
                        <VerifiedUserOutlined />
                    </div>
                    <div className={styles.secureText}>
                        {vendor.config.hideLogo
                            ? t('100% Secure payments')
                            : t('100% Secure payments powered by Qlub_')}
                    </div>
                </CustomerContainer>
            </CustomerContainer>
            {enableButton && !hasPgGroup && buttonElement}
        </form>
    );
}
