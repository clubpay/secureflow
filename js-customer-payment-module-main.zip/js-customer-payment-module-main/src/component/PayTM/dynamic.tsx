/*
    Creation Time: 2022 - April - 7
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useEffect, useMemo, useRef, useState } from 'react';
import Scripts from 'next/script';
import { CircularProgress, Link } from '@mui/material';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useConfirmCallback, usePaymentTimeout } from '@clubpay/customer-common-module/src/hook/payment';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import PaymentWrapper from '../PaymentWrapper';
import PayButtonElement from '../PayButtonElement';
import { IPayTMGateway } from '../../repository/type/paymentGateway';
import PaymentAPIManager from '../../repository';

import styles from './index.module.scss';

export interface IProps extends IPGProps {
    config: IPayTMGateway;
}

export default function PayTM({
    diningSessionID,
    sessionId,
    amount,
    tip,
    name,
    config,
    disable,
    gatewayId,
    currencyPrecision,
    vendor,
    updateTimestamp,
    onBeforePayment,
    onUnlockPayment,
    onFail,
    onIndicator,
    onLoad,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onTraceClose,
}: IProps) {
    const [loading, setLoading] = useState(false);
    const [scriptsLoaded, setScriptsLoaded] = useState(false);
    const { timeoutDone } = usePaymentTimeout({
        indicatorTimeout: config?.indicatorTimeout || 0,
        fallbackTimeout: config?.fallbackTimeout || 0,
        indicatorCallback: onIndicator,
        fallbackCallback: onLoad,
    });
    const { hasPgGroup } = vendor.paymentGatewayList;
    const { getCallbackUrl } = useConfirmCallback();
    const totalAmount = sumAmounts(currencyPrecision, amount, tip);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    const { lang } = useQlubRouter();

    const submitHandler = () => {
        setLoading(true);

        const refId = getRandomString();
        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.LinkPay,
                refId,
            },
        });

        onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.LinkPay,
            tip,
        })
            .then((ok) => {
                if (!ok) {
                    setLoading(false);
                    return;
                }

                const totalAmountStr = sumAmounts(currencyPrecision, amount, tip).toFixed(currencyPrecision || 0);
                const orderId = getRandomString();

                const returnUrl = getCallbackUrl({
                    ref: refId,
                    method: name,
                    paymentElement: PaymentElementEnum.LinkPay,
                    dsi: diningSessionID,
                    sid: sessionId,
                    amount: totalAmountStr,
                    currencySymbol: vendor.country.currencySymbol,
                    orderId,
                    traceId: traceStart?.traceId,
                    lang,
                });
                const successUrl = returnUrl.success;
                const failureUrl = returnUrl.fail;
                PaymentAPIManager.getInstance()
                    .paymentPayTMInitiateTransaction({
                        id: sessionId,
                        reference: refId,
                        diningSessionID,
                        orderID: orderId,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                        successUrl,
                        failureUrl,
                        gatewayID: gatewayId,
                    })
                    .then((res) => {
                        if (scriptsLoaded) {
                            // @ts-ignore
                            window.invokeApp(
                                config?.mid || '',
                                res.data.orderID,
                                res.data.token,
                                totalAmount.toFixed(currencyPrecision || 0),
                            );
                        }
                    })
                    .catch((err) => {
                        onTraceClose?.({
                            error: err,
                            location: 'paymentPayTMInitiateTransaction',
                            traceRef,
                            traceStart,
                        });

                        onFail({
                            paymentElement: PaymentElementEnum.LinkPay,
                            refId,
                            traceId: traceStart?.traceId,
                        });

                        onUnlockPayment();
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            })
            .catch(() => {
                setLoading(false);
            });
    };

    const buttonElement = useMemo(() => {
        return (
            <PayButtonElement
                variant="contained"
                size="large"
                fullWidth
                loading={loading}
                disabled={disable || loading}
                onClick={submitHandler}
                id="paytm-action-btn"
                showConfirmText={!hasPgGroup}
            />
        );
    }, [tip, disable, loading, updateTimestamp]);

    const loadScriptHandler = () => {
        onPgRegister?.({
            pgId: gatewayId,
            icon: <Link />,
            elem: PaymentElementEnum.LinkPay,
            name: 'PayTM',
            placement: 'bottom',
        });
        setScriptsLoaded(true);
        timeoutDone();
    };

    useEffect(() => {
        if (!scriptsLoaded) {
            return;
        }
        onPgRegister?.({
            pgId: gatewayId,
            icon: <Link />,
            elem: PaymentElementEnum.LinkPay,
            name: 'PayTM',
            placement: 'bottom',
        });
    }, [updateTimestamp]);

    return (
        <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.LinkPay)}>
            <div className={styles.form}>
                <Scripts src="https://securegw.paytm.in/merchantpgpui/appinvoke" onReady={loadScriptHandler} />
                {scriptsLoaded ? buttonElement : <CircularProgress size={24} />}
            </div>
        </PaymentWrapper>
    );
}
