/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React from 'react';
import classNames from 'classnames';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import PaymentTerms from '@clubpay/customer-common-module/src/component/PaymentTerms';
import AppleIcon from './AppleIcon';

import styles from './index.module.scss';

interface IProps {
    theme: any;
    onClick?: any;
    disabled?: boolean;
    id?: string;
    hasPgGroup?: boolean;
    onSubmit?: any;
}

export const ApplePayButton = ({ theme, onClick, disabled, hasPgGroup, onSubmit, id }: IProps) => {
    const { t } = useTranslation('common');

    return (
        <div className={styles.applepayWrapper}>
            {hasPgGroup && <PaymentTerms />}
            <button
                className={classNames(styles.applePayButton, {
                    [styles.applePayButtonLight]: theme === 'light',
                    [styles.applePayButtonDark]: theme === 'dark',
                })}
                type="button"
                onClick={onClick}
                onSubmit={onSubmit}
                disabled={disabled}
                id={id}
            >
                <div className={styles.wrapper}>
                    <div className={styles.text}>{interpolateT(t('Pay with <icon>'), { icon: <AppleIcon /> })}</div>
                </div>
            </button>
        </div>
    );
};
