/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import getConfig from 'next/config';

const { publicRuntimeConfig } = getConfig();

export const merchantIdentifier = publicRuntimeConfig.appleMerchantId || process.env.NEXT_PUBLIC_APPLE_MERCHANT_ID;
export const merchantDisplay =
    publicRuntimeConfig.appleMerchantDisplay || process.env.NEXT_PUBLIC_APPLE_MERCHANT_DISPLAY;
