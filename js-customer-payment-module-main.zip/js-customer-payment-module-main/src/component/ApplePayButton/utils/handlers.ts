/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

const applePayJsApiExists = () => {
    return new Promise((resolve, reject) => {
        try {
            const enabled = ApplePaySession && ApplePaySession.canMakePayments();
            resolve(enabled);
        } catch (err) {
            // console.warn(err);
            reject(err);
        }
    });
};

export const applePayJsAvailable = () => {
    return applePayJsApiExists()
        .then(() => {
            return true;
            // return ApplePaySession?.canMakePaymentsWithActiveCard(merchantIdentifier) || false;
        })
        .catch(() => {
            return false;
        });
};
