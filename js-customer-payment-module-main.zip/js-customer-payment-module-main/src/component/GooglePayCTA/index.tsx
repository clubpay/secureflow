import { FC } from 'react';
import PaymentTerms from '@clubpay/customer-common-module/src/component/PaymentTerms';

import styles from './index.module.scss';

interface IProp {
    loading: boolean;
    hasPgGroup?: boolean;
    id: string;
}

const GooglePayCTA: FC<IProp> = ({ loading, id, hasPgGroup }) => {
    return (
        <div className={styles.googleConatiner}>
            {hasPgGroup && <PaymentTerms />}
            <div id={id} className={loading ? styles.googleLoading : ''} data-area="submit" />
        </div>
    );
};

export default GooglePayCTA;
