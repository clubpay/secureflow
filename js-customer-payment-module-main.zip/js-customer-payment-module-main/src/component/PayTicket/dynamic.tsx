import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Button, NewLoading } from '@qlub-dev/qlub-kit';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import PaymentWrapper from '../PaymentWrapper';
import PaymentAPIManager from '../../repository';

import styles from './index.module.scss';
import { TicketPayWhite, TicketPayRed } from '../../asset/icon';

export interface IProps extends IPGBaseProps, IPGHooks, Partial<IPGStateCallbacks> {}

const PayTicket = ({
    diningSessionID,
    sessionId,
    amount,
    tip,
    currencyPrecision,
    disable,
    gatewayId,
    vendor,
    updateTimestamp,
    name,
    onBeforePayment,
    onUnlockPayment,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onTraceClose,
}: IProps) => {
    const [loading, setLoading] = useState(false);
    const { t } = useTranslation('common');
    const { getCallbackUrl } = useConfirmCallback();
    const { hasPgGroup } = vendor.paymentGatewayList;
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const { lang } = useQlubRouter();

    const submitHandler = () => {
        setLoading(true);

        const refId = getRandomString();

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.LinkPay,
                refId,
            },
        });

        onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.LinkPay,
            tip,
        })
            .then((ok: boolean) => {
                if (!ok) {
                    setLoading(false);
                    return;
                }
                const orderId = getRandomString();

                const returnUrl = getCallbackUrl({
                    ref: refId,
                    method: name,
                    paymentElement: PaymentElementEnum.LinkPay,
                    tip,
                    dsi: diningSessionID,
                    sid: sessionId,
                    amount,
                    currencySymbol: vendor.country.currencySymbol,
                    orderId,
                    traceId: traceStart?.traceId,
                    lang,
                });
                PaymentAPIManager.getInstance()
                    .payTicketGenerateLink({
                        diningSessionID,
                        gatewayID: gatewayId,
                        id: sessionId,
                        reference: refId,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                        successURL: returnUrl.success,
                        failureURL: returnUrl.fail,
                    })
                    .then((res) => {
                        if (res?.data) {
                            const { data } = res;

                            if (data) {
                                if (data?.paymentURL === returnUrl.fail) {
                                    onTraceClose?.({
                                        error: res,
                                        location: 'payTicketGenerateLink.then',
                                        traceRef,
                                        traceStart,
                                    });
                                }

                                window.location.href = `${data?.paymentURL}`;
                            }
                        } else {
                            onUnlockPayment();
                        }
                    })
                    .catch((err) => {
                        onTraceClose?.({
                            error: err,
                            location: 'payTicketGenerateLink.catch',
                            traceRef,
                            traceStart,
                        });

                        onUnlockPayment();
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            })
            .catch(() => {
                setLoading(false);
            });
    };

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.LinkPay,
            name: 'Ticket',
            icon: <TicketPayRed />,
            placement: 'bottom',
        });
    }, [updateTimestamp]);

    return (
        <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.LinkPay)}>
            <div className={styles.form}>
                <div className={styles.submit}>
                    <Button
                        variant="contained"
                        color="primary"
                        size="large"
                        disabled={disable || loading}
                        onClick={submitHandler}
                        fullWidth
                        id="pay-ticket-action-btn"
                        className={styles.button}
                    >
                        <TicketPayWhite />
                        {loading ? <NewLoading /> : t('Pay with Ticket')}
                        <ArrowForwardIosIcon />
                    </Button>
                </div>
            </div>
        </PaymentWrapper>
    );
};
export default PayTicket;
