import dynamic from 'next/dynamic';
import { Box, CircularProgress } from '@mui/material';
import { IMasterpassDirectProps } from './dynamic';
import styles from './index.module.scss';

const PayMasterpassDirect = dynamic<IMasterpassDirectProps>(() => import('./dynamic'), {
    loading: () => (
        <Box className={styles.masterPassBox}>
            <CircularProgress size={24} />
        </Box>
    ),
    ssr: false,
});

export default PayMasterpassDirect;
