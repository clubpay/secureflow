import React, { useContext, useRef, useState } from 'react';
import Box from '@mui/material/Box';
import { Form, Formik, FormikProps } from 'formik';
import * as Yup from 'yup';
import { CustomerContainer, Divider } from '@qlub-dev/qlub-kit';
import {
    number as cardNumberValidator,
    expirationDate as expirationDateValidator,
    cvv as cvvValidator,
} from 'card-validator';
import { PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { IRestaurant } from '@clubpay/customer-common-module/src/repository/vendor';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { IAddNewCardFormValues } from '../../../PayMasterpass/types';
import {
    creditCardFormat,
    expirationDateFormat,
    cvvFormat,
    getAdditionalParameters,
    removeSlashesAndReverse,
} from '../../../PayMasterpass/utils';
import { useMasterpassAddNewCardTranslation } from '../../../PayMasterpass/hooks/useMasterpassTranslation';
import PayButtonElement from '../../../PayButtonElement';
import { MasterpassActionTypeEnum, MasterpassContext } from '../../../PayMasterpass/context';
import { IMasterpassGateway } from '../../../../repository/type/paymentGateway';
import Masterpass from '../../../PayMasterpass/lib/masterpass';
import { MASTERPASS_PF_BANK_ICA, MASTERPASS_RESPONSE_CODE } from '../../../PayMasterpass/const';
import { useMasterpassAPI } from '../../../PayMasterpass/api';
import { useMasterpassError } from '../../../PayMasterpass/hooks/useMasterpassError';
import FormField from './FormField';

import styles from './index.module.scss';

export interface IProps {
    amount: number;
    tip: number;
    referenceNo: string;
    diningSessionID: string;
    sessionId: string;
    currencyPrecision?: number;
    gatewayId: string;
    total: number;
    name: string;
    vendor: IRestaurant;
    config: IMasterpassGateway;
    masterpassResponse?: any;
    masterpassToken?: string;
    isSplitted?: boolean;
    disabled?: boolean;
}

const initialValues: IAddNewCardFormValues = {
    cardNumber: '',
    label: '',
    expirationDate: '',
    cvv: '',
};

const MasterPassDirectPurchase = ({
    amount,
    tip,
    referenceNo,
    diningSessionID,
    sessionId,
    currencyPrecision,
    gatewayId,
    name,
    vendor,
    config,

    disabled,
}: IProps) => {
    const [expirationDate, setExpirationDate] = useState('');
    const [cvv, setcvv] = useState('');
    const [cardNumber, setCardNumber] = useState('');
    const [cardType, setCardType] = useState('');
    const formRef = useRef<FormikProps<IAddNewCardFormValues>>(null);
    const { state, dispatch } = useContext(MasterpassContext);
    const { getCallbackUrl } = useConfirmCallback();
    const { formErrors, formLabels } = useMasterpassAddNewCardTranslation(tip);
    const { masterPassDirectGenerateToken } = useMasterpassAPI();
    const { showError } = useMasterpassError();

    const directPurchase = async () => {
        dispatch({
            type: MasterpassActionTypeEnum.LOADING,
        });

        try {
            const returnUrl = getCallbackUrl({
                ref: referenceNo,
                method: name,
                paymentElement: PaymentElementEnum.CardPay,
                tip,
                dsi: diningSessionID,
                sid: sessionId,
                amount: amount.toFixed(currencyPrecision || 0),
                currencySymbol: vendor?.country.currencySymbol,
            });
            const masterpassResponse = await masterPassDirectGenerateToken({
                gatewayID: gatewayId,
                verbose: true,
                reference: referenceNo,
                diningSessionID,
                id: sessionId,
                computeReturnURL: true,
                forRegisterCard: false,
                failURL: returnUrl.fail,
                successURL: returnUrl.success,
                tipAmount: tip.toFixed(currencyPrecision || 0),
            });

            const totalAmount = (sumAmounts(currencyPrecision, amount, tip) * 100).toFixed(0);
            const additionalParameters = getAdditionalParameters({
                total: totalAmount,
                bankIca: config?.bankICA || MASTERPASS_PF_BANK_ICA.ipara,
                restaurantUnique: vendor.unique,
            });

            Masterpass.getInstance().directPurchase(
                {
                    token: masterpassResponse?.token,
                    // msisdn: masterpassResponse?.customerID || masterpassResponse?.customerPhone || '',
                    msisdn: '',
                    orderNo: masterpassResponse?.orderID,
                    userId:
                        config?.bankICA === MASTERPASS_PF_BANK_ICA.sipay
                            ? masterpassResponse.customerID
                            : masterpassResponse?.customerPhone,
                    referenceNo,
                    amount: totalAmount,
                    expiryDate: removeSlashesAndReverse(expirationDate),
                    rtaPan: cardNumber.replace(/\s/g, ''),
                    cvc: cvv,
                    returnURL: masterpassResponse?.computedCallbackURL,
                    ...additionalParameters,
                },
                async (responseCode, response) => {
                    const returnURL = masterpassResponse?.computedCallbackURL;
                    const commitPurchasePattern = /\/masterpass-turkiye\/commit-purchase\/.*/;

                    if (response?.responseCode === MASTERPASS_RESPONSE_CODE.SUCCESS_REDIRECT_TO_3D) {
                        // 3D Secure
                        window.location.assign(`${response?.url3D}&returnUrl=${returnURL}`);
                    } else if (commitPurchasePattern.test(masterpassResponse?.computedCallbackURL ?? '')) {
                        window.location.assign(`${response?.directPurchase}`);
                    } else if (
                        [MASTERPASS_RESPONSE_CODE.OTP, MASTERPASS_RESPONSE_CODE.OTHER_OTP].includes(
                            response?.responseCode,
                        )
                    ) {
                        dispatch({ type: MasterpassActionTypeEnum.MASTERPASS_BANK_OTP_CODE });
                    } else {
                        showError({}, response?.responseDescription);
                        dispatch({ type: MasterpassActionTypeEnum.RESET });
                    }
                },
            );
        } catch (error: any) {
            const errData = error?.response?.data || error || {};

            showError(errData, error?.message);
            dispatch({ type: MasterpassActionTypeEnum.RESET });
        }
    };

    const addNewCardSchema = Yup.object().shape({
        cardNumber: Yup.string()
            .min(13, formErrors.cardNumber.invalid)
            .required(formErrors.cardNumber.required)
            .test('cardNumber', formErrors.cardNumber.invalid, (value) => {
                if (!value) {
                    return false;
                }
                return cardNumberValidator(creditCardFormat(value).formatted).isValid;
            }),
        expirationDate: Yup.string()
            .required(formErrors.expirationDate.required)
            .min(5, formErrors.expirationDate.invalid)
            .test('verifyExpDate', formErrors.expirationDate.invalid, (value) => {
                if (!value) {
                    return true;
                }

                return expirationDateValidator(expirationDateFormat(value).formatted).isValid;
            }),
        cvv: Yup.string()
            .required(formErrors.cvv.required)
            .test('cvv', formErrors.cvv.invalid, (value) => {
                if (!value) {
                    return false;
                }

                if (cardType === 'American Express' || cardType === 'AMEX') {
                    return value.length === 4;
                }
                return value.length === 3;
            })
            .test('cvv', formErrors.cvv.invalid, (value) => {
                if (!value) {
                    return false;
                }

                return cvvValidator(value).isValid || (cardType === 'American Express' && value.length === 4);
            }),
    });

    const handleMaskDate = (text: string) => {
        const { formatted } = expirationDateFormat(text);

        setExpirationDate(formatted);
    };

    const formatCardNumber = (value: string) => {
        const { formatted, cType } = creditCardFormat(value);
        setCardType(cType);

        setCardNumber(formatted);
    };

    const formatCvvNumber = (value: string) => {
        const { formatted } = cvvFormat(value, cardType as any);

        setcvv(formatted);
    };

    return (
        <CustomerContainer centered direction="column" className={styles.formContainer}>
            <Formik
                innerRef={formRef}
                initialValues={initialValues}
                onSubmit={directPurchase}
                validationSchema={addNewCardSchema}
                validateOnMount={false}
                enableReinitialize
            >
                {({ errors, touched, handleBlur, setFieldValue }) => {
                    return (
                        <Form className={styles.form}>
                            <div className={styles.inputs}>
                                <Box>
                                    <FormField
                                        label={formLabels.cardNumber}
                                        name="cardNumber"
                                        placeholder="4444 4444 4444 4444"
                                        error={errors.cardNumber}
                                        touched={touched.cardNumber}
                                        setFieldValue={(e, value) => {
                                            formatCardNumber(value);
                                            setFieldValue('cardNumber', value);
                                        }}
                                        handleBlur={handleBlur}
                                        value={cardNumber}
                                    />
                                </Box>
                                <Box>
                                    <FormField
                                        label={formLabels.expirationDate}
                                        name="expirationDate"
                                        placeholder="01/12"
                                        error={errors.expirationDate}
                                        touched={touched.expirationDate}
                                        setFieldValue={(e, value) => {
                                            handleMaskDate(value);
                                            setFieldValue('expirationDate', value);
                                        }}
                                        handleBlur={handleBlur}
                                        value={expirationDate}
                                    />
                                </Box>
                                <Box>
                                    <FormField
                                        label={formLabels.cvv}
                                        name="cvv"
                                        placeholder="..."
                                        error={errors.cvv}
                                        touched={touched.cvv}
                                        setFieldValue={(e, value) => {
                                            formatCvvNumber(value);
                                            setFieldValue('cvv', value);
                                        }}
                                        handleBlur={handleBlur}
                                        value={cvv}
                                    />
                                </Box>
                            </div>
                            <Divider type="small" />
                            <div className={styles.buttonAndLogo}>
                                <PayButtonElement
                                    loading={state.loading}
                                    disabled={disabled || state.loading}
                                    variant="contained"
                                    size="large"
                                    type="submit"
                                    id="continue"
                                    fullWidth
                                />
                            </div>
                        </Form>
                    );
                }}
            </Formik>
        </CustomerContainer>
    );
};

export default MasterPassDirectPurchase;
