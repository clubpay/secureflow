import React, { createContext, Dispatch, useMemo, useReducer } from 'react';
import { qlubLocalStorage } from '@clubpay/customer-common-module/src/service/storage/localStorage';
import {
    initialState,
    MasterpassAction,
    MasterpassActionTypeEnum,
    masterpassReducer,
    MasterpassState,
} from './reducer';
import { getStorage } from '../utils';

const MasterpassContext = createContext<{
    state: MasterpassState;
    dispatch: Dispatch<MasterpassAction>;
    tokenStorage: Record<string, any>;
    isReachedLimit: boolean;
}>({
    state: initialState,
    dispatch: () => null,
    tokenStorage: {},
    isReachedLimit: false,
});

const MasterpassDirectContext = createContext<{
    state: MasterpassState;
    dispatch: Dispatch<MasterpassAction>;
    tokenStorage: Record<string, any>;
    isReachedLimit: boolean;
}>({
    state: initialState,
    dispatch: () => null,
    tokenStorage: {},
    isReachedLimit: false,
});

export interface MasterpassDirectProviderProps {
    children: React.ReactNode;
}

const MasterpassDirectProvider: React.FC<MasterpassDirectProviderProps> = ({ children }) => {
    const [state, dispatch] = useReducer(masterpassReducer, initialState);

    const tokenObj = {
        userJWTToken: qlubLocalStorage.get('userJWTToken'),
        userRefreshToken: qlubLocalStorage.get('userRefreshToken'),
    };

    const tokenStorage: Record<string, any> = useMemo(() => {
        return getStorage(localStorage, tokenObj);
    }, [qlubLocalStorage.get('userJWTToken'), qlubLocalStorage.get('userRefreshToken')]);

    const isReachedLimit = useMemo(() => {
        return state.resendedCounter > 1 || state.hasReachedLimit;
    }, [state.resendedCounter, state.hasReachedLimit]);

    return (
        <MasterpassDirectContext.Provider value={{ state, dispatch, tokenStorage, isReachedLimit }}>
            {children}
        </MasterpassDirectContext.Provider>
    );
};

export { MasterpassDirectContext, MasterpassDirectProvider, MasterpassContext, MasterpassActionTypeEnum };
