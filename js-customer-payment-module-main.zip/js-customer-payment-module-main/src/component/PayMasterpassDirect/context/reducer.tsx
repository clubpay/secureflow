import {
    IError,
    MasterpassStepEnum,
    MasterpassCardType,
    QlubStepEnum,
    VerificationTypeEnum,
} from '../../PayMasterpass/types';
import { IAuthenticateResponse } from '../../../repository/type/masterpass';

export interface MasterpassState {
    verificationType?: VerificationTypeEnum;
    step?: QlubStepEnum | MasterpassStepEnum;
    loading?: boolean;
    errors?: IError;
    isOpenDrawer?: boolean;
    cards?: MasterpassCardType[] | [];
    cardID?: string;
    otpResponse?: IAuthenticateResponse;
    resendedCounter: number;
    hasReachedLimit: boolean;
}

export const initialState: MasterpassState = {
    verificationType: VerificationTypeEnum.MASTERPASS,
    step: MasterpassStepEnum.OTP_CODE,
    loading: false,
    errors: {},
    isOpenDrawer: false,
    cards: [],
    cardID: '',
    otpResponse: { otpID: '', phone: '', smsID: '' },
    resendedCounter: 0,
    hasReachedLimit: false,
};

export enum MasterpassActionTypeEnum {
    QLUB_PHONE = 'QLUB_PHONE',
    QLUB_OTP_CODE = 'QLUB_OTP_CODE',
    HAS_NOT_MASTERPASS_ACCOUNT = 'HAS_NOT_MASTERPASS_ACCOUNT',
    HAS_MASTERPASS_ACCOUNT_USED_QLUB = 'HAS_MASTERPASS_ACCOUNT_USED_QLUB',
    HAS_MASTERPASS_ACCOUNT_NOT_USED_QLUB = 'HAS_MASTERPASS_ACCOUNT_NOT_USED_QLUB',
    MASTERPASS_BANK_OTP_CODE = 'MASTERPASS_BANK_OTP_CODE',
    ADD_NEW_CARD = 'ADD_NEW_CARD',
    CHECK_CARD = 'CHECK_CARD',
    LOADING = 'LOADING',
    RESET = 'RESET',
    CLOSE_DRAWER = 'CLOSE_DRAWER',
    SET_ERROR = 'SET_ERROR',
    INCREASE_SMS_LIMIT = 'INCREASE_SMS_LIMIT',
    RESET_SMS_LIMIT = 'RESET_SMS_LIMIT',
    REACHED_SMS_LIMIT = 'REACHED_SMS_LIMIT',
    SET_CARDS = 'SET_CARDS',
}

export interface MasterpassAction {
    type: string;
    payload?: Partial<MasterpassState>;
}

export const masterpassReducer = (state: MasterpassState, action: MasterpassAction) => {
    const { type, payload } = action;

    switch (type) {
        case MasterpassActionTypeEnum.QLUB_PHONE:
            return {
                ...state,
                step: QlubStepEnum.PHONE,
                verificationType: VerificationTypeEnum.QLUB,
                loading: false,
                isOpenDrawer: true,
            };
        case MasterpassActionTypeEnum.QLUB_OTP_CODE:
            return {
                ...state,
                step: QlubStepEnum.OTP_CODE,
                verificationType: VerificationTypeEnum.QLUB,
                loading: false,
                isOpenDrawer: true,
                otpResponse: payload?.otpResponse,
            };
        case MasterpassActionTypeEnum.MASTERPASS_BANK_OTP_CODE:
            return {
                ...state,
                step: MasterpassStepEnum.BANK_OTP_CODE,
                verificationType: VerificationTypeEnum.MASTERPASS,
                loading: false,
                isOpenDrawer: true,
            };
        case MasterpassActionTypeEnum.HAS_NOT_MASTERPASS_ACCOUNT:
            return {
                ...state,
                step: MasterpassStepEnum.ADD_NEW_CARD,
                verificationType: VerificationTypeEnum.MASTERPASS,
                loading: false,
                isOpenDrawer: true,
            };
        case MasterpassActionTypeEnum.HAS_MASTERPASS_ACCOUNT_USED_QLUB:
            return {
                ...state,
                step: MasterpassStepEnum.SELECT_CARD,
                verificationType: VerificationTypeEnum.MASTERPASS,
                loading: false,
                isOpenDrawer: true,
            };
        case MasterpassActionTypeEnum.CHECK_CARD:
            return {
                ...state,
                cards: state?.cards?.map((card) => {
                    card.selected = card.UniqueId === payload?.cardID;
                    return card;
                }),
            };

        case MasterpassActionTypeEnum.SET_CARDS:
            return {
                ...state,
                cards: payload?.cards || [],
            };

        case MasterpassActionTypeEnum.HAS_MASTERPASS_ACCOUNT_NOT_USED_QLUB:
            return {
                ...state,
                step: MasterpassStepEnum.OTP_CODE,
                verificationType: VerificationTypeEnum.MASTERPASS,
                loading: false,
                isOpenDrawer: true,
            };
        case MasterpassActionTypeEnum.ADD_NEW_CARD:
            return {
                ...state,
                step: MasterpassStepEnum.ADD_NEW_CARD,
                verificationType: VerificationTypeEnum.MASTERPASS,
                loading: false,
                isOpenDrawer: true,
            };
        case MasterpassActionTypeEnum.LOADING:
            return {
                ...state,
                loading: true,
            };
        case MasterpassActionTypeEnum.RESET:
            return {
                ...state,
                loading: false,
                isOpenDrawer: true,
            };
        case MasterpassActionTypeEnum.CLOSE_DRAWER:
            return {
                ...state,
                isOpenDrawer: false,
                loading: false,
            };
        case MasterpassActionTypeEnum.SET_ERROR:
            return {
                ...state,
                errors: { ...state.errors, ...payload?.errors },
            };
        case MasterpassActionTypeEnum.INCREASE_SMS_LIMIT:
            return {
                ...state,
                resendedCounter: state.resendedCounter && state.resendedCounter + 1,
            };
        case MasterpassActionTypeEnum.RESET_SMS_LIMIT:
            return {
                ...state,
                resendedCounter: 0,
                hasReachedLimit: false,
            };
        case MasterpassActionTypeEnum.REACHED_SMS_LIMIT:
            return {
                ...state,
                hasReachedLimit: true,
            };
        default:
            return state;
    }
};
