import React, { useContext, useEffect, useMemo, useState } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Scripts from 'next/script';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { usePaymentTimeout } from '@clubpay/customer-common-module/src/hook/payment';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { CardIcon } from '@clubpay/customer-common-module/src/component/SVG';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import Masterpass from '../PayMasterpass/lib/masterpass';
import { useMasterpassAPI } from '../PayMasterpass/api';
import { MASTERPASS_BASE_ENDPOINT } from '../PayMasterpass/const';
import { IMasterpassGateway } from '../../repository/type/paymentGateway';
import { useMasterpassError } from '../PayMasterpass/hooks/useMasterpassError';
import { MasterpassActionTypeEnum, MasterpassContext } from './context';
import PaymentWrapper from '../PaymentWrapper';

import styles from './index.module.scss';
import DirectPurchase from './components/DirectPurchase';

export interface IMasterpassDirectProps extends IPGProps {
    remainingAmount: number;
    config: IMasterpassGateway;
}

const PayMasterpassDirect = ({
    diningSessionID,
    sessionId,
    disable,
    gatewayId,
    amount,
    tip,
    name,
    currencyPrecision,
    config,
    vendor,
    onIndicator,
    onLoad,
    onPgRegister,
    remainingAmount,
    isPgElemVisible,
}: IMasterpassDirectProps) => {
    const { t } = useTranslation('common');
    const [scriptsLoaded, setScriptsLoaded] = useState<boolean>(false);
    const [referenceNo, setReferenceNo] = useState<string>('');
    const { timeoutDone } = usePaymentTimeout({
        indicatorTimeout: config?.indicatorTimeout || 0,
        fallbackTimeout: config?.fallbackTimeout || 0,
        indicatorCallback: onIndicator,
        fallbackCallback: onLoad,
    });
    const { state, dispatch } = useContext(MasterpassContext);
    const { showError } = useMasterpassError();
    const { hasPgGroup } = vendor.paymentGatewayList;
    const { masterpassGenerateReference } = useMasterpassAPI();
    const { login, isLogin, isAuthorizedUser, logout } = useAuth();

    const isSplitted = useMemo(() => {
        return amount < remainingAmount;
    }, [amount, remainingAmount]);

    const setMasterpassInitialStep = async () => {
        try {
            const reference = await masterpassGenerateReference();

            setReferenceNo(reference);
        } catch (error: any) {
            const errData = error?.response?.data || error || {};

            if ([400, 403].includes(errData?.code || 0)) {
                logout();
                showError(errData, t('Please try again!'));
            } else {
                dispatch({
                    type: MasterpassActionTypeEnum.RESET,
                });
                showError(errData, error?.message);
            }
        }
    };

    const total = sumAmounts(currencyPrecision, amount, tip);

    const handleLogin = async () => {
        try {
            if (!isLogin || !isAuthorizedUser) {
                const validated = await login({ guest: true });

                if (validated) {
                    await setMasterpassInitialStep();
                } else {
                    showError({});
                }
            } else {
                await setMasterpassInitialStep();
            }
        } catch (e: any) {
            console.log(e);
        }
    };

    const masterpassLoadHandler = () => {
        onPgRegister?.({
            name: t('Card'),
            icon: <CardIcon />,
            elem: PaymentElementEnum.CardPay,
            pgId: gatewayId,
            placement: 'bottom',
        });

        Masterpass.getInstance().init({
            clientId: config.clientId,
            address: MASTERPASS_BASE_ENDPOINT[config.env],
        });

        handleLogin();
        timeoutDone();
    };

    useEffect(() => {
        setTimeout(() => {
            if (!scriptsLoaded) {
                masterpassLoadHandler();
            }
        }, 3000);
    }, []);

    const renderMasterpassDirectPurchase = (
        <DirectPurchase
            amount={amount}
            sessionId={sessionId}
            tip={tip}
            referenceNo={referenceNo}
            diningSessionID={diningSessionID}
            gatewayId={gatewayId}
            total={total}
            name={name}
            vendor={vendor}
            config={config}
            isSplitted={isSplitted}
            disabled={!scriptsLoaded || disable || state.loading}
            currencyPrecision={currencyPrecision}
        />
    );

    return (
        <>
            <Scripts
                id="mfs-client-direct"
                src="/pg_sdk/mfs-client.min.js?direct=true"
                onReady={() => {
                    setScriptsLoaded(true);
                }}
                strategy="afterInteractive"
            />
            <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}>
                <div className={styles.masterPassContainer}>{renderMasterpassDirectPurchase}</div>
            </PaymentWrapper>
        </>
    );
};

export default PayMasterpassDirect;
