export const config = {
    style: {
        bodyBackgroundColor: '#fafafb',
        bodyColor: '',
        themeBackgroundColor: '#dfa231',
        themeColor: '#ffffff',
        headerBackgroundColor: '#284055',
        headerColor: '#ffffff',
        errorColor: '',
        successColor: '',
        card: {
            padding: '',
            backgroundColor: '',
        },
    },
    jsFile: '',
    data: {},
    merchant: {
        mid: 'GRSDES73497546565027',
        name: 'Qlub_',
        logo: '',
        redirect: false,
    },
    mapClientMessage: {},
    labels: {},
    payMode: {
        labels: {},
        filter: {
            exclude: [],
        },
        order: ['NB', 'CARD', 'LOGIN'],
    },
    flow: 'mweb',
};
