/*
    Creation Time: 2021 - Sep - 13
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useMemo, useState } from 'react';
import { CircularProgress } from '@mui/material';
// @ts-ignore
import { Checkout, CheckoutProvider } from 'paytm-blink-checkout-react';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { cloneDeep } from 'lodash';
import { useConfirmCallback, usePaymentTimeout } from '@clubpay/customer-common-module/src/hook/payment';
import { Button, CustomerContainer } from '@qlub-dev/qlub-kit';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IPayTMLegacyGateway } from '../../repository/type/paymentGateway';
import PaymentAPIManager from '../../repository';
import { config as paytmConfig } from './config';

import styles from './index.module.scss';

export interface IProps extends IPGProps {
    config: IPayTMLegacyGateway;
}

interface IPayParams {
    refId: string;
    orderId: string;
    sid: string;
}

export default function PayTM({
    diningSessionID,
    sessionId,
    amount,
    tip,
    currencyPrecision,
    config,
    vendor,
    disable,
    gatewayId,
    name,
    onBeforePayment,
    onFail,
    onIndicator,
    onLoad,
}: IProps) {
    const { t } = useTranslation('common');
    const [showCheckout, setShowCheckout] = useState(false);
    const [loading, setLoading] = useState(false);
    const [final, setFinal] = useState(false);
    const [gatewayConfig, setGatewayConfig] = useState<any>({ ...paytmConfig });
    const [successUrl, setSuccessUrl] = useState<string>('');
    const [failUrl, setFailUrl] = useState<string>('');
    const [payParams, setPayParams] = useState<IPayParams>({
        sid: '',
        refId: '',
        orderId: '',
    });
    const { timeoutDone } = usePaymentTimeout({
        indicatorTimeout: config?.indicatorTimeout || 0,
        fallbackTimeout: config?.fallbackTimeout || 0,
        indicatorCallback: onIndicator,
        fallbackCallback: onLoad,
    });
    const { getCallbackUrl } = useConfirmCallback();
    const { lang } = useQlubRouter();

    const totalAmount = sumAmounts(currencyPrecision, amount, tip);

    const notifyMerchantHandler = (eventType: any, data: any) => {
        console.log('MERCHANT NOTIFY LOG', eventType, data);
        setFinal(false);
        setLoading(false);
        setShowCheckout(false);
    };

    const transactionStatusHandler = (data: any) => {
        console.log('status', data);
        setShowCheckout(false);
        PaymentAPIManager.getInstance()
            .paymentPayTMLegacyVerifyTransaction({
                id: payParams.sid,
                reference: payParams.refId,
                diningSessionID,
                orderID: payParams.orderId,
                txnType: '',
                gatewayID: gatewayId,
            })
            .then(() => {
                window.location.href = successUrl;
            })
            .catch(() => {
                window.location.href = failUrl;
            });
    };

    const submitHandler = () => {
        onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.CardPay,
            tip,
        })
            .then((ok) => {
                if (!ok) {
                    return;
                }
                const refId = getRandomString();
                const orderId = getRandomString();
                setPayParams({
                    refId,
                    sid: sessionId,
                    orderId,
                });
                setShowCheckout(true);
                const totalAmountStr = totalAmount.toFixed(currencyPrecision || 0);
                const returnUrl = getCallbackUrl({
                    ref: refId,
                    method: name,
                    paymentElement: PaymentElementEnum.CardPay,
                    dsi: diningSessionID,
                    amount: totalAmountStr,
                    currencySymbol: vendor.country.currencySymbol,
                    orderId,
                    lang,
                });
                setSuccessUrl(returnUrl.success);
                setFailUrl(returnUrl.fail);
                PaymentAPIManager.getInstance()
                    .paymentPayTMLegacyInitiateTransaction({
                        id: sessionId,
                        reference: refId,
                        diningSessionID,
                        orderID: orderId,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                        callbackUrl: returnUrl.success,
                        gatewayID: gatewayId,
                    })
                    .then((res) => {
                        setFinal(true);
                        gatewayConfig.data = {
                            orderId: res.data.orderID,
                            amount: totalAmount.toFixed(currencyPrecision || 0),
                            token: res.data.token,
                            tokenType: 'TXN_TOKEN',
                        };
                        if (config) {
                            gatewayConfig.merchant.mid = config.mid;
                            gatewayConfig.merchant.name = config.label;
                        }
                        setGatewayConfig(cloneDeep(gatewayConfig));
                    })
                    .catch(() => {
                        onFail({
                            paymentElement: PaymentElementEnum.CardPay,
                            refId,
                        });
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            })
            .catch(() => {
                setLoading(false);
            });
    };

    const checkoutContent = useMemo(() => {
        if (showCheckout) {
            gatewayConfig.handler = {
                notifyMerchant: notifyMerchantHandler,
                transactionStatus: transactionStatusHandler,
                onLoad: (success: boolean) => {
                    if (success) {
                        timeoutDone();
                    }
                },
            };
            return (
                <CustomerContainer padding="sm" centered className={styles.cardContainer}>
                    <CheckoutProvider config={gatewayConfig} env={config?.sandbox ? 'STAGE' : 'PROD'}>
                        <Checkout />
                    </CheckoutProvider>
                    <CircularProgress size={24} />
                </CustomerContainer>
            );
        }
        return null;
    }, [showCheckout, gatewayConfig]);

    return (
        <div className={styles.form}>
            {checkoutContent}
            {!final && !showCheckout && (
                <div className={styles.submit}>
                    <Button
                        variant="contained"
                        size="large"
                        disabled={disable || loading}
                        onClick={submitHandler}
                        fullWidth
                        id="paytm-legacy-action-btn"
                        loading={loading}
                    >
                        {t('Pay Now')}
                    </Button>
                </div>
            )}
        </div>
    );
}
