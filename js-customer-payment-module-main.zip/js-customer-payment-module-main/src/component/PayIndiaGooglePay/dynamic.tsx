import React, { useEffect, useMemo, useRef, useState } from 'react';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { isIOS } from '@clubpay/customer-common-module/src/utility/k_user_agent';
import { GooglePay, GooglePayDark } from '@clubpay/customer-common-module/src/component/SVG';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { qlubSessionStorage } from '@clubpay/customer-common-module/src/service/storage/sessionStorage';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IIndiaGooglePayConfig } from '../../repository/type/paymentGateway';
import PaymentWrapper from '../PaymentWrapper';
import PaymentAPIManager from '../../repository';

import styles from './index.module.scss';

const canMakePaymentCache = 'googlePayIndiaCanMakePayment';

export interface IProps extends IPGProps {
    config: IIndiaGooglePayConfig;
}

const PayIndiaGooglePay = ({
    diningSessionID,
    sessionId,
    amount,
    tip,
    currencyPrecision,
    config,
    vendor,
    gatewayId,
    name,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onLoad,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onTraceClose,
}: IProps) => {
    const { hasPgGroup } = vendor.paymentGatewayList;
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [refId, setRefId] = useState(getRandomString());
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const iOS = useMemo(() => isIOS(), []);

    useEffect(() => {
        onLoad(!iOS);
    }, [iOS]);

    if (iOS) {
        return null;
    }

    useEffect(() => {
        setRefId(getRandomString());

        onPgRegister?.({
            pgId: gatewayId,
            icon: <GooglePay />,
            elem: PaymentElementEnum.GooglePay,
            name: 'Google Pay',
            placement: 'bottom',
        });
    }, []);

    /**
     * Check whether can make payment with Google Pay or not. It will check session storage
     * cache first and use the cache directly if it exists. Otherwise, it will call
     * canMakePayment method from PaymentRequest object and return the result, the
     * result will also be stored in the session storage cache for future usage.
     *
     * @private
     * @param {PaymentRequest} request The payment request object.
     * @return {Promise} a promise containing the result of whether can make payment.
     */
    const checkCanMakePayment = (request: any) => {
        // Checks canMakePayment cache, and use the cache result if it exists.
        const val = qlubSessionStorage.get(canMakePaymentCache);
        if (val) {
            return Promise.resolve(JSON.parse(val));
        }

        // If canMakePayment() isn't available, default to assume the method is
        // supported.
        let canMakePaymentPromise = Promise.resolve(true);

        // Feature detect canMakePayment().
        if (request.canMakePayment) {
            canMakePaymentPromise = request.canMakePayment();
        }

        return canMakePaymentPromise
            .then((result) => {
                // Store the result in cache for future usage.
                qlubSessionStorage.set(canMakePaymentCache, JSON.stringify(result));
                return result;
            })
            .catch((err) => {
                console.log(`Error calling canMakePayment: ${err}`);
                return onUnlockPayment();
            });
    };

    /** Redirect to PlayStore. */
    const handleNotReadyToPay = () => {
        // eslint-disable-next-line no-alert
        if (confirm('Google Pay is not ready to pay. You need to install Google Pay to continue.')) {
            window.location.href =
                'https://play.google.com/store/apps/details?id=com.google.android.apps.nbu.paisa.user&hl=en&gl=IN';
        }
    };

    /**
     * Process the response from browser.
     *
     * @private
     * @param {PaymentResponse} instrument The payment instrument that was authed.
     */
    const processResponse = (instrument: any) => {
        return PaymentAPIManager.getInstance()
            .googlePayIndiaSync({
                diningSessionID,
                id: sessionId,
                reference: refId,
                tipAmount: tip.toFixed(currencyPrecision || 0),
                billAmount: amount.toFixed(currencyPrecision || 0),
                gatewayID: gatewayId,
                paymentResponse: JSON.stringify(instrument),
            })
            .then((res: any) => {
                const result = res.data.result ? 'success' : 'fail';
                instrument
                    .complete(result)
                    .then(() => {
                        enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                        onDone({
                            paymentElement: PaymentElementEnum.GooglePay,
                            refId,
                        });
                    })
                    .catch((err: any) => {
                        console.log(err);
                        enqueueSnackbar(t('Payment Failed!'), { variant: 'error' });

                        onTraceClose?.({
                            error: err,
                            location: 'intrument.catch',
                            traceRef,
                            traceStart,
                        });

                        onFail({
                            paymentElement: PaymentElementEnum.GooglePay,
                            refId,
                            traceId: traceStart?.traceId,
                        });
                    });
            })
            .catch((err: any) => {
                console.log(err);
                const errData = err?.response?.data || err || {};
                if (errData.code === 412 && errData.items === 'PAYMENT_REFERENCE_CONFLICTS_TRANSACTION') {
                    setRefId(getRandomString());
                }
                instrument.complete('fail');
                return onUnlockPayment();
            });
    };

    /**
     * Show the payment request UI.
     *
     * @private
     * @param {PaymentRequest} request The payment request object.
     * @param {Promise} canMakePayment The promise for whether can make payment.
     */
    const showPaymentUI = (request: any, canMakePayment: any) => {
        // Redirect to play store if can't make payment.
        if (!canMakePayment) {
            handleNotReadyToPay();
            return;
        }

        // Set payment timeout.
        const paymentTimeout = setTimeout(
            () => {
                request
                    .abort()
                    .then(() => {
                        console.log('Payment timed out after 20 minutes.');
                    })
                    .catch((err: any) => {
                        console.log(`Unable to abort, user is in the process of paying. Error: ${err}`);
                    });
            },
            20 * 60 * 1000,
        ); /* 20 minutes */

        request
            .show()
            .then((instrument: any) => {
                clearTimeout(paymentTimeout);
                return processResponse(instrument); // Handle response from browser.
            })
            .catch((err: any) => {
                console.log(err);
                return onUnlockPayment();
            });
    };

    const startPayment = () => {
        if (!window.PaymentRequest) {
            enqueueSnackbar(t('Web payments are not supported in this browser.'), { variant: 'error' });
            console.log('Web payments are not supported in this browser.');
            return;
        }

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.GooglePay,
                refId,
            },
        });

        onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.GooglePay,
            tip,
        }).then((ok) => {
            if (!ok) {
                return;
            }

            const supportedInstruments = [
                {
                    supportedMethods: 'https://tez.google.com/pay',
                    data: {
                        pa: config.vpa,
                        pn: config.merchantName,
                        tr: refId,
                        url: window.location.href,
                        mc: config.businessCatCode,
                    },
                },
            ];

            const details = {
                total: {
                    label: 'Total',
                    amount: {
                        currency: vendor.country.currencyCode,
                        value: amount.toString(),
                    },
                },
                displayItems: [
                    {
                        label: 'Total Amount',
                        amount: {
                            currency: vendor.country.currencyCode,
                            value: amount.toString(),
                        },
                    },
                    {
                        label: 'Tip Amount',
                        amount: {
                            currency: vendor.country.currencyCode,
                            value: tip.toString(),
                        },
                    },
                ],
            };

            let request: PaymentRequest | null = null;
            try {
                request = new PaymentRequest(supportedInstruments, details);
            } catch (e) {
                console.log(`Payment Request Error: ${e}`);
                return;
            }
            if (!request) {
                console.log('Web payments are not supported in this browser.');
                return;
            }

            const canMakePaymentPromise = checkCanMakePayment(request);
            canMakePaymentPromise
                .then((result) => {
                    showPaymentUI(request, result);
                })
                .catch((err) => {
                    console.log(`Error calling checkCanMakePayment: ${err}`);
                    return onUnlockPayment();
                });
        });
    };

    return (
        <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.GooglePay)}>
            <button
                onClick={startPayment}
                className={styles.googlepay}
                type="button"
                aria-label="Pay"
                data-area="submit"
            >
                {interpolateT(t('Checkout with <icon>'), { icon: <GooglePayDark /> })}
            </button>
        </PaymentWrapper>
    );
};

export default PayIndiaGooglePay;
