import { useEffect, useState } from 'react';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { isSafari } from '@clubpay/customer-common-module/src/utility/mobile_check';
import { IMoyasarV2Gateway } from '../../repository/type/paymentGateway';
import { applePayJsAvailable } from '../ApplePayButton/utils/handlers';
import PaymentWrapper from '../PaymentWrapper';
import PayMoyasarV2ApplePay from './applepay';

export interface IProps extends IPGProps {
    config: IMoyasarV2Gateway;
}

export default function PayMoyasarV2({
    name,
    diningSessionID,
    sessionId,
    url,
    amount,
    tip,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onPending,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onTraceClose,
}: IProps) {
    const [hasApplePay, setHasApplePay] = useState(false);
    const [hasGooglePay, setHasGooglePay] = useState(false);
    const { hasPgGroup } = vendor.paymentGatewayList;
    const { login, isLogin } = useAuth();
    useEffect(() => {
        if (!isLogin) {
            login({ guest: true });
        }
    }, [isLogin]);

    useEffect(() => {
        applePayJsAvailable().then((enable) => {
            setHasApplePay(enable);
        });

        setHasGooglePay(!isSafari());
    }, [url.cc, url.slug, url.id]);

    return (
        <div>
            {!config?.hideApplePay && hasApplePay && !hasGooglePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.ApplePay)}>
                    <PayMoyasarV2ApplePay
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        vendor={vendor}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        hasPgGroup={hasPgGroup}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onPending={onPending}
                        onFail={onFail}
                        onPgRegister={onPgRegister}
                        onTraceStart={onTraceStart}
                        onTraceClose={onTraceClose}
                    />
                </PaymentWrapper>
            )}
        </div>
    );
}
