/*
 * Creation Time: June 19 - 2023
 * Created By: yasincelebi
 * Name: maflib.ts
 * Copyright 2023 customer-web-app
 */

declare global {
    interface Window {
        MafPay: {
            setLanguage: (lang: string) => void;
            lang: string;
            defaultStyle: boolean;
            env: 'sandbox' | 'production';
        };
    }
}

export {};
