/*
 * Creation Time: June 19 - 2023
 * Created By: yasincelebi
 * Name: types.ts
 * Copyright 2023 customer-web-app
 */

export interface PayMafSubmitEvent {
    responseMessage: string;
    responseCode: string;
    cardToken: string;
    cardBin: string;
    status: string;
    cardVerificationRef: string;
    threeDsAuthId: string;
    threeDsAccessToken: string;
    threeDsVersion: string;
    verifyCard: string;
    merchantId: string;
    apiKey: string;
    command: string;
    expiryMonth: string;
    expiryYear: string;
    cardBrand: string;
    cardType: string;
    cardMaskedNumber: string;
}
