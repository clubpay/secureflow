import { useMemo, useRef, useState } from 'react';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Scripts from 'next/script';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import {
    IPayBeforePaymentHandler,
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { GooglePay } from '@clubpay/customer-common-module/src/component/SVG';
import GooglePayCTA from '../GooglePayCTA';
import { IMafGatewayConfig } from '../../repository/type/paymentGateway';
import PaymentAPIManager from '../../repository';

import styles from './index.module.scss';

interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks {
    config: IMafGatewayConfig;
    hasPgGroup: boolean;
    processCompleteHandler: (responseCode: string, traceId: string, ref: string) => void;
}

let beforeFn: (payload: IPayBeforePaymentHandler) => Promise<boolean>;
let mafV2TotalAmount = 0;
let mafV2TipAmount = 0;

export default function PayMafV2Google({
    diningSessionID,
    sessionId,
    amount,
    tip,
    name,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    hasPgGroup,
    onBeforePayment,
    onUnlockPayment,
    onPending,
    onFail,
    onPgRegister,
    onTraceStart,
    onPgUnregister,
    onTraceClose,
    processCompleteHandler,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [loading, setLoading] = useState(false);
    const [refId, setRefId] = useState<string>(getRandomString());
    const paymentsClientRef = useRef<google.payments.api.PaymentsClient | null>(null);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    beforeFn = onBeforePayment;
    mafV2TotalAmount = sumAmounts(currencyPrecision, amount, tip);
    mafV2TipAmount = tip;

    const baseRequest = {
        apiVersion: 2,
        apiVersionMinor: 0,
    };

    const tokenizationSpecification = {
        type: 'PAYMENT_GATEWAY',
        parameters: {
            gateway: config?.gateway || 'cybersource',
            gatewayMerchantId: config?.gatewayMerchantId || 'TEST999999962',
        },
    };

    const baseCardPaymentMethod: google.payments.api.IsReadyToPayPaymentMethodSpecification = {
        type: 'CARD',
        parameters: {
            allowedAuthMethods: config?.googleAllowedAuthMethods || ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
            allowedCardNetworks: config?.googleAllowedCardNetworks || ['MASTERCARD', 'VISA'],
        },
    };

    const getGoogleIsReadyToPayRequest = (): google.payments.api.IsReadyToPayRequest => {
        return { ...baseRequest, allowedPaymentMethods: [baseCardPaymentMethod] } as any;
    };

    const getGooglePaymentsClient = () => {
        if (paymentsClientRef.current === null) {
            paymentsClientRef.current = new google.payments.api.PaymentsClient({
                environment: config?.sandbox ? 'TEST' : 'PRODUCTION',
            });
        }
        return paymentsClientRef.current;
    };

    const cardPaymentMethod = { ...baseCardPaymentMethod, tokenizationSpecification };

    const getGoogleTransactionInfo = (): google.payments.api.TransactionInfo => {
        return {
            totalPriceStatus: 'FINAL',
            totalPrice: mafV2TotalAmount.toFixed(currencyPrecision || 0),
            countryCode: config?.countryCode || vendor.country.code.toUpperCase() || 'AE',
            currencyCode: vendor.country.currencyCode?.toUpperCase() || '',
        };
    };

    const getGooglePaymentDataRequest = (): google.payments.api.PaymentDataRequest => {
        const paymentDataRequest: any = { ...baseRequest };
        paymentDataRequest.allowedPaymentMethods = [cardPaymentMethod];
        paymentDataRequest.transactionInfo = getGoogleTransactionInfo();
        paymentDataRequest.merchantInfo = {
            merchantId: config?.googleMerchantId || '',
            merchantName: 'qlub',
        };
        return paymentDataRequest;
    };

    // @ts-ignore
    // function prefetchGooglePaymentData() {
    //     const paymentDataRequest = getGooglePaymentDataRequest();
    //     // transactionInfo must be set but does not affect cache
    //     paymentDataRequest.transactionInfo = {
    //         totalPrice: totalAmount.toFixed(currencyPrecision || 0),
    //         totalPriceStatus: 'NOT_CURRENTLY_KNOWN',
    //         countryCode: config?.countryCode || region || 'AE',
    //         currencyCode: currencyCode?.toUpperCase() || '',
    //     };
    //     const paymentsClient = getGooglePaymentsClient();
    //     paymentsClient.prefetchPaymentData(paymentDataRequest);
    // }

    /**
     * Show Google Pay payment sheet when Google Pay payment button is clicked
     */
    const onGooglePaymentButtonClicked = () => {
        if (disable || loading) {
            return;
        }

        setLoading(true);

        setRefId(getRandomString());
        beforeFn({
            gatewayId,
            paymentElement: PaymentElementEnum.GooglePay,
            tip,
        }).then((ok) => {
            if (!ok) {
                setLoading(false);
                return;
            }

            const paymentDataRequest = getGooglePaymentDataRequest();
            paymentDataRequest.transactionInfo = getGoogleTransactionInfo();

            const paymentsClient = getGooglePaymentsClient();
            paymentsClient
                .loadPaymentData(paymentDataRequest)
                .then((paymentData) => {
                    // handle the response
                    PaymentAPIManager.getInstance()
                        .paymentMafV2PayByGoogle({
                            id: sessionId,
                            diningSessionID,
                            tipAmount: mafV2TipAmount.toFixed(currencyPrecision || 0),
                            googleToken: paymentData.paymentMethodData.tokenizationData.token,
                            reference: refId,
                            gatewayID: gatewayId,
                            cardType: paymentData.paymentMethodData.info?.cardNetwork || '',
                        })
                        .then((res) => {
                            processCompleteHandler(res.data.responseCode, traceStart?.traceId || '', refId);

                            enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                        })
                        .catch((err: Error) => {
                            onTraceClose?.({
                                error: err,
                                location: 'paymentMafV2PayByGoogle',
                                traceRef,
                                traceStart,
                            });

                            const isNetworkError = checkNetworkError(err as AxiosError);
                            if (isNetworkError) {
                                onPending({
                                    paymentElement: PaymentElementEnum.GooglePay,
                                    refId,
                                    traceId: traceStart?.traceId,
                                });
                            }

                            onFail({
                                paymentElement: PaymentElementEnum.GooglePay,
                                refId,
                                traceId: traceStart?.traceId,
                            });
                        })
                        .finally(() => {
                            setLoading(false);
                        });
                })
                .catch((err) => {
                    // show error in developer console for debugging
                    console.error(err);
                    setLoading(false);
                    onUnlockPayment();
                });
        });
    };

    const addGooglePayButton = () => {
        const paymentsClient = getGooglePaymentsClient();
        const button = paymentsClient.createButton({
            onClick: onGooglePaymentButtonClicked,
            allowedPaymentMethods: [baseCardPaymentMethod],
            buttonSizeMode: 'fill',
            buttonType: 'pay',
        });
        document.querySelector('#mafV2-google-pay')?.appendChild(button);
    };

    const loadScriptHandler = () => {
        traceRef.current = traceStart?.startSpan?.({
            dataName: name,
            span: {
                element: PaymentElementEnum.GooglePay,
                refId,
            },
        });

        const paymentsClient = getGooglePaymentsClient();
        paymentsClient
            .isReadyToPay(getGoogleIsReadyToPayRequest())
            .then((response) => {
                if (response.result) {
                    onPgRegister?.({
                        pgId: gatewayId,
                        elem: PaymentElementEnum.GooglePay,
                        icon: <GooglePay />,
                        name: t('Google Pay'),
                        placement: 'bottom',
                    });
                    addGooglePayButton();
                }
            })
            .catch((err) => {
                onTraceClose?.({
                    error: err,
                    location: 'paymentsClient.isReadyToPay',
                    traceRef,
                    traceStart,
                });
                onPgUnregister?.({
                    pgId: gatewayId,
                    elem: PaymentElementEnum.GooglePay,
                });
            });
    };

    return (
        <div className={styles.payButton}>
            <Scripts src="https://pay.google.com/gp/p/js/pay.js" onReady={loadScriptHandler} />
            <GooglePayCTA id="mafV2-google-pay" loading={loading} hasPgGroup={hasPgGroup} />
        </div>
    );
}
