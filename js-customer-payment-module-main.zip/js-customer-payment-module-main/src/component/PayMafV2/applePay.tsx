/*
 * Creation Time: June 19 - 2023
 * Created By: yasincelebi
 * Name: applePay.tsx
 * Copyright 2023 customer-web-app
 */

import React, { useState, useRef, useMemo, useEffect } from 'react';
import Scripts from 'next/script';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { Apple } from '@mui/icons-material';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IMafGatewayConfig } from '../../repository/type/paymentGateway';
import { ApplePayButton } from '../ApplePayButton';
import PaymentAPIManager from '../../repository';
import { disableApplePayBilling, getApplePayShippingBillingConfig } from '../../utility/shipping_info';

import styles from './index.module.scss';

interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks {
    config: IMafGatewayConfig;
    hasPgGroup: boolean;
    refId: string;
    onLoading: (loading: boolean) => void;
    onLock: (loading: boolean) => void;
    onRefreshRef: () => void;
    processCompleteHandler: (responseCode: string, traceId: string, ref: string) => void;
}

export default function PayMafV2Apple({
    diningSessionID,
    sessionId,
    amount,
    tip,
    url,
    name,
    refId,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    hasPgGroup,
    onBeforePayment,
    onUnlockPayment,
    onPending,
    onFail,
    onPgRegister,
    onTraceStart,
    onTraceClose,
    onLoading,
    onRefreshRef,
    onLock,
    processCompleteHandler,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [loading, setLoading] = useState(false);
    const [, setScriptsLoaded] = useState(false);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const [lock, setLock] = useState(false);

    const totalAmount = sumAmounts(currencyPrecision, amount, tip);

    useEffect(() => {
        onLoading(loading);
    }, [loading]);

    useEffect(() => {
        onLock(lock);
    }, [lock]);

    const payHandler = () => {
        if (!ApplePaySession) {
            return;
        }

        // Define ApplePayPaymentRequest
        const request: ApplePayJS.ApplePayPaymentRequest = {
            countryCode: config?.countryCode?.toUpperCase() || vendor.country.code?.toUpperCase() || 'AE',
            currencyCode: vendor.country.currencyCode?.toUpperCase() || '',
            merchantCapabilities: (config?.merchantCapabilitiesList as any) ||
                (config?.merchantCapabilities as any) || ['supports3DS'],
            supportedNetworks: (config?.supportedNetworksList as any) ||
                (config?.supportedNetworks as any) || ['visa', 'masterCard', 'amex', 'discover'],
            total: {
                label: 'Qlub_',
                type: 'final',
                amount: totalAmount.toFixed(currencyPrecision || 0),
            },
            ...getApplePayShippingBillingConfig(config),
        };

        console.log({ request });

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.ApplePay,
                refId,
            },
        });

        try {
            // Create ApplePaySession
            const session: ApplePaySession = new ApplePaySession(config?.appleSDKVersion || 3, request);

            session.onvalidatemerchant = (e) => {
                setLock(true);
                console.log({ onvalidatemerchant: e });
                // Call your own server to request a new merchant session.
                onBeforePayment({
                    gatewayId,
                    paymentElement: PaymentElementEnum.ApplePay,
                    tip,
                })
                    .then((ok) => {
                        if (!ok) {
                            try {
                                session?.abort();
                            } catch (err) {
                                console.log(err);
                            } finally {
                                setLock(false);
                            }
                            return;
                        }

                        setLoading(true);

                        PaymentAPIManager.getInstance()
                            .paymentMafV2ValidateApplePaySession({
                                diningSessionID,
                                applePayUrl: e.validationURL,
                                gatewayID: gatewayId,
                            })
                            .then((res) => {
                                console.log({ res }, JSON.parse(res.data.jsonData));
                                session.completeMerchantValidation(JSON.parse(res.data.jsonData));
                            })
                            .catch(() => {
                                try {
                                    session?.abort();
                                } catch (err) {
                                    console.log(err);
                                }
                                onUnlockPayment();
                                setLock(false);
                            })
                            .finally(() => {
                                setLoading(false);
                            });
                    })
                    .catch(() => {
                        setLoading(false);
                    });
            };

            session.onpaymentmethodselected = (e) => {
                // Define ApplePayPaymentMethodUpdate based on the selected payment method.
                // No updates or errors are needed, pass an empty object.
                const update: ApplePayJS.ApplePayPaymentMethodUpdate = {
                    newTotal: {
                        label: 'Qlub_',
                        type: 'final',
                        amount: totalAmount.toFixed(currencyPrecision || 0),
                    },
                };
                session.completePaymentMethodSelection(update);
                console.log({ onpaymentmethodselected: e });
            };

            session.onshippingmethodselected = (e) => {
                // Define ApplePayShippingMethodUpdate based on the selected shipping method.
                // No updates or errors are needed, pass an empty object.
                const update: any = {};
                session.completeShippingMethodSelection(update);
                console.log({ onshippingmethodselected: e });
            };

            session.onshippingcontactselected = (e) => {
                // Define ApplePayShippingContactUpdate based on the selected shipping contact.
                const update: any = {};
                session.completeShippingContactSelection(update);
                console.log({ onshippingcontactselected: e });
            };

            session.onpaymentauthorized = (e) => {
                setLoading(true);
                PaymentAPIManager.getInstance()
                    .paymentMafV2PayByApple({
                        id: sessionId,
                        diningSessionID,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                        appleToken: JSON.stringify(e.payment?.token || {}),
                        shippingContact: e.payment?.shippingContact,
                        billingContact: e.payment?.billingContact,
                        reference: refId,
                        gatewayID: gatewayId,
                        cardType: e.payment?.token?.paymentMethod?.network || '',
                    })
                    .then((res) => {
                        const result: ApplePayJS.ApplePayPaymentAuthorizationResult = {
                            status: ApplePaySession.STATUS_SUCCESS,
                        };

                        try {
                            session.completePayment(result);
                        } catch (err) {
                            console.log(err);
                        }

                        processCompleteHandler(res.data.responseCode, traceStart?.traceId || '', refId);

                        enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                    })
                    .catch((err: Error) => {
                        onRefreshRef();
                        onTraceClose?.({
                            error: err,
                            location: 'paymentCheckoutPayByApple',
                            traceRef,
                            traceStart,
                        });

                        // Define ApplePayPaymentAuthorizationResult
                        const result: ApplePayJS.ApplePayPaymentAuthorizationResult = {
                            status: ApplePaySession.STATUS_FAILURE,
                        };
                        try {
                            session.completePayment(result);
                        } catch (error) {
                            console.log(error);
                        }

                        const isNetworkError = checkNetworkError(err as AxiosError);
                        if (isNetworkError) {
                            onPending({
                                paymentElement: PaymentElementEnum.ApplePay,
                                refId,
                                traceId: traceStart?.traceId,
                            });
                        }

                        onFail({
                            paymentElement: PaymentElementEnum.ApplePay,
                            refId,
                            traceId: traceStart?.traceId,
                        });

                        console.log({ onpaymentauthorized: e, err });
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            };

            session.oncancel = (e: any) => {
                disableApplePayBilling();

                // Payment cancelled by WebKit
                setLoading(false);
                console.log({ oncancel: e });
                onUnlockPayment();
                onTraceClose?.({
                    error: e,
                    location: 'mafv2_applepay_cancel',
                    traceRef,
                    traceStart,
                });

                onPushEvent('applepay_cancel', {
                    pg_name: name,
                    restaurant_name: url.slug,
                    opsMode: vendor?.opsMode,
                    diningSessionId: diningSessionID,
                });
                setLock(false);
            };

            session.begin();
        } catch (e) {
            console.warn({ applePay: e });
        }
    };

    const loadScriptHandler = () => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.ApplePay,
            name: 'Apple Pay',
            icon: <Apple />,
            placement: 'bottom',
        });

        setScriptsLoaded(true);
    };

    return (
        <div className={styles.payButton}>
            <Scripts src="/pg_sdk/apple-pay-sdk.js" onReady={loadScriptHandler} />
            <div className={styles.container} data-area="submit">
                <ApplePayButton
                    onClick={payHandler}
                    theme="dark"
                    disabled={disable || loading}
                    id="maf-applepay-action-btn"
                    hasPgGroup={hasPgGroup}
                />
            </div>
        </div>
    );
}
