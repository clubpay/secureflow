/*
 * Creation Time: {today.year} - {today.month} - {today.day}
 */

import React, { useEffect, useRef, useState } from 'react';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { isSafari } from '@clubpay/customer-common-module/src/utility/mobile_check';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { defineCustomElements } from '@qlub-dev/weblib';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import Loading from '@qlub-dev/qlub-kit/dist/components/Loading';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IMafGatewayConfig } from '../../repository/type/paymentGateway';
import PaymentWrapper from '../PaymentWrapper';
import PayMafV2Google from './googlePay';
import PayMafV2Apple from './applePay';
import CardForm from './cardForm';
import { applePayJsAvailable } from '../ApplePayButton/utils/handlers';

import styles from './index.module.scss';
import '@qlub-dev/weblib/dist/mafpay/mafpay.css';

export interface IProps extends IPGProps {
    config: IMafGatewayConfig;
}

const PayMafV2 = ({
    name,
    diningSessionID,
    sessionId,
    jwt,
    url,
    amount,
    tip,
    currencyPrecision,
    config,
    gatewayId,
    vendor,
    disable,
    updateTimestamp,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onPending,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onPgUnregister,
    onTraceClose,
    onLoading,
}: IProps) => {
    const { lang } = useQlubRouter();
    const [refId, setRefId] = useState<string>(getRandomString());
    const [hasApplePay, setHasApplePay] = useState(false);
    const [hasGooglePay, setHasGooglePay] = useState(false);
    const [loadingList, setLoadingList] = useState<string[]>([]);
    const [lock, setLock] = useState(false);
    const hasUpdateInLoading = useRef(false);
    const { hasPgGroup } = vendor.paymentGatewayList;
    const { login, isLogin } = useAuth();

    useEffect(() => {
        if (!isLogin) {
            login({ guest: true });
        }
    }, [isLogin]);

    useEffect(() => {
        window.MafPay = {
            ...window.MafPay,
            lang: lang === 'ar' ? 'ar' : 'en',
            defaultStyle: true,
            env: config?.sandbox ? 'sandbox' : 'production',
        };
    }, []);

    useEffect(() => {
        // maf just supports en and ar
        window.MafPay.setLanguage(lang === 'ar' ? 'ar' : 'en');
        // custom elements are not updating when parent component is updated

        defineCustomElements();
    }, [lang]);

    useEffect(() => {
        onLoading?.(loadingList.length > 0);
    }, [loadingList]);

    const refreshRefHandler = () => {
        if (loadingList.length > 0) {
            hasUpdateInLoading.current = true;
            return;
        }
        if (lock) {
            return;
        }

        setRefId(getRandomString());
    };

    const totalAmount = sumAmounts(currencyPrecision, amount, tip);

    useEffect(() => {
        refreshRefHandler();
    }, [totalAmount]);

    useEffect(() => {
        applePayJsAvailable().then((enable) => {
            setHasApplePay(enable);
        });

        if (!isSafari()) {
            setHasGooglePay(true);
        }
    }, [url.cc, url.slug, url.id]);

    const loadingChangeHandler = (elem: string) => (val: boolean) => {
        const clone = [...loadingList];
        const idx = clone.indexOf(elem);
        if (val) {
            if (idx === -1) {
                clone.push(elem);
            }
        } else if (idx > -1) {
            clone.splice(idx, 1);
        }
        setLoadingList(clone);
        if (hasUpdateInLoading.current && !val) {
            hasUpdateInLoading.current = false;
            refreshRefHandler();
        }
    };

    const lockChangeHandler = (val: boolean) => {
        setLock(val);
    };

    const processCompleteHandler =
        (elem: PaymentElementEnum) => (responseCode: string, traceId: string, ref: string) => {
            switch (responseCode) {
                case '000':
                    onDone?.({
                        paymentElement: elem,
                        refId: ref,
                    });

                    break;

                case '700':
                    onPending?.({
                        paymentElement: elem,
                        refId: ref,
                    });

                    break;

                case '600':
                case '602':
                default:
                    onFail?.({
                        paymentElement: elem,
                        refId: ref,
                        traceId,
                    });

                    break;
            }
        };

    return (
        <div className={styles.mafpayWrapper}>
            {Boolean(hasPgGroup && loadingList.length > 0 && isPgElemVisible?.(PaymentElementEnum.CardPay)) && (
                <Loading color="outlined" />
            )}
            {config?.hideApplePay !== true && hasApplePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.ApplePay)}>
                    <PayMafV2Apple
                        refId={refId}
                        onRefreshRef={refreshRefHandler}
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        vendor={vendor}
                        currencyPrecision={currencyPrecision}
                        amount={amount}
                        tip={tip}
                        gatewayId={gatewayId}
                        disable={disable}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        config={config}
                        onPgRegister={onPgRegister}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        onPgUnregister={onPgUnregister}
                        hasPgGroup={hasPgGroup}
                        onTraceClose={onTraceClose}
                        onLoading={loadingChangeHandler('apple')}
                        onLock={lockChangeHandler}
                        processCompleteHandler={processCompleteHandler(PaymentElementEnum.ApplePay)}
                    />
                </PaymentWrapper>
            )}
            {config?.hideGooglePay !== true && hasGooglePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.GooglePay)}>
                    <PayMafV2Google
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        vendor={vendor}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        hasPgGroup={hasPgGroup}
                        onPgUnregister={onPgUnregister}
                        onTraceClose={onTraceClose}
                        processCompleteHandler={processCompleteHandler(PaymentElementEnum.GooglePay)}
                    />
                </PaymentWrapper>
            )}
            {config?.hideCardPay !== true && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}>
                    <CardForm
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        currencyPrecision={currencyPrecision}
                        disable={disable}
                        config={config}
                        vendor={vendor}
                        amount={amount}
                        tip={tip}
                        refId={refId}
                        gatewayId={gatewayId}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onRefreshRef={refreshRefHandler}
                        onPgRegister={onPgRegister}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        onTraceClose={onTraceClose}
                        onLoading={loadingChangeHandler('card')}
                        processCompleteHandler={processCompleteHandler(PaymentElementEnum.CardPay)}
                    />
                </PaymentWrapper>
            )}
            {lock && <div className={styles.lockOverlay} />}
        </div>
    );
};

export default PayMafV2;
