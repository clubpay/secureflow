import { useEffect, useMemo, useRef, useState } from 'react';
import { Button, NewLoading, QlubKitTheme } from '@qlub-dev/qlub-kit';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { PayPayLogo } from '@clubpay/customer-common-module/src/component/SVG';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { CreditCard } from '@mui/icons-material';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import PaymentWrapper from '../PaymentWrapper';
import PaymentAPIManager from '../../repository';

import styles from './index.module.scss';

export interface IProps extends IPGBaseProps, IPGHooks, Partial<IPGStateCallbacks> {}

const PayPaypay = ({
    diningSessionID,
    sessionId,
    amount,
    tip,
    name,
    currencyPrecision,
    disable,
    gatewayId,
    vendor,
    updateTimestamp,
    onBeforePayment,
    onUnlockPayment,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onTraceClose,
}: IProps) => {
    const [loading, setLoading] = useState(false);
    const { getCallbackUrl } = useConfirmCallback();
    const { hasPgGroup } = vendor.paymentGatewayList;
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const { lang } = useQlubRouter();

    const submitHandler = () => {
        setLoading(true);

        const refId = getRandomString();
        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.LinkPay,
                refId,
            },
        });

        onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.LinkPay,
            tip,
        })
            .then((ok: boolean) => {
                if (!ok) {
                    setLoading(false);
                    return;
                }

                const orderId = getRandomString();

                const returnUrl = getCallbackUrl({
                    ref: refId,
                    method: name,
                    paymentElement: PaymentElementEnum.LinkPay,
                    tip,
                    dsi: diningSessionID,
                    sid: sessionId,
                    amount,
                    currencySymbol: vendor.country.currencySymbol,
                    orderId,
                    traceId: traceStart?.traceId,
                    lang,
                });
                PaymentAPIManager.getInstance()
                    .payPayRegister({
                        id: sessionId,
                        reference: refId,
                        diningSessionID,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                        gatewayID: gatewayId,
                        orderID: orderId,
                        successUrl: returnUrl.success,
                        failureUrl: returnUrl.fail,
                    })
                    .then((res) => {
                        const { data } = res;

                        window.location.href = `${data?.startURL}?AccessID=${data?.accessID}&Token=${data?.token}`;
                    })
                    .catch((err) => {
                        onTraceClose?.({
                            error: err,
                            location: 'payPayRegister',
                            traceRef,
                            traceStart,
                        });

                        onUnlockPayment();
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            })
            .catch(() => {
                setLoading(false);
            });
    };

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.LinkPay,
            name,
            icon: <CreditCard />,
        });
    }, [updateTimestamp]);

    return (
        <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.LinkPay)}>
            <div className={styles.form}>
                <div className={styles.submit}>
                    <Button
                        variant="contained"
                        color="primary"
                        size="large"
                        disabled={disable || loading}
                        onClick={submitHandler}
                        fullWidth
                        id="pay-pay-action-btn"
                        className={styles.button}
                    >
                        <PayPayLogo fill={QlubKitTheme.palette.common.white} />
                        {loading ? <NewLoading /> : 'PayPayで支払う'}
                        <ArrowForwardIosIcon />
                    </Button>
                </div>
            </div>
        </PaymentWrapper>
    );
};
export default PayPaypay;
