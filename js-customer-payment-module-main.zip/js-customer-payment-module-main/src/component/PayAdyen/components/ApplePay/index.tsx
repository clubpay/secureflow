import React, { useState, useRef, useMemo } from 'react';
import Scripts from 'next/script';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { Apple } from '@mui/icons-material';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import {
    IPGBaseProps,
    IPGHooks,
    IPGSplitProps,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { IAdyenAdvancedPaymentsPayload } from '../../../../repository/type/adyen';
import { IAdyenGateway } from '../../../../repository/type/paymentGateway';
import { disableApplePayBilling, getApplePayShippingBillingConfig } from '../../../../utility/shipping_info';
import { ApplePayButton } from '../../../ApplePayButton';
import PaymentAPIManager from '../../../../repository';

interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks, IPGSplitProps {
    config: IAdyenGateway;
    hasPgGroup: boolean;
}

export default function ApplePay({
    diningSessionID,
    sessionId,
    amount,
    tip,
    url,
    name,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    hasPgGroup,
    onBeforePayment,
    onUnlockPayment,
    onPending,
    onFail,
    onPgRegister,
    onTraceStart,
    onTraceClose,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [loading, setLoading] = useState(false);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    const totalAmount = sumAmounts(currencyPrecision, amount, tip);

    const payHandler = () => {
        if (!ApplePaySession) {
            return;
        }

        setLoading(true);

        const request: ApplePayJS.ApplePayPaymentRequest = {
            countryCode: (config?.countryCode || vendor.country.code).toLocaleUpperCase(),
            currencyCode: vendor.country.currencyCode?.toUpperCase(),
            merchantCapabilities: config?.merchantCapabilities || ['supports3DS'],
            supportedNetworks: config?.supportedNetworksList || ['visa', 'masterCard', 'amex', 'discover'],
            total: {
                label: 'Qlub_',
                type: 'final',
                amount: totalAmount.toFixed(currencyPrecision || 0),
            },
            ...getApplePayShippingBillingConfig(config),
        };

        const refId = getRandomString();
        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.ApplePay,
                refId,
            },
        });

        try {
            const session: ApplePaySession = new ApplePaySession(config?.appleSDKVersion || 3, request);
            session.begin();

            session.onvalidatemerchant = async (e) => {
                try {
                    const initialResponse = await onBeforePayment({
                        gatewayId,
                        paymentElement: PaymentElementEnum.ApplePay,
                        tip,
                    });

                    if (!initialResponse) throw new Error();

                    const validationResponse = await PaymentAPIManager.getInstance().payAdyenValidateApplePay({
                        applePayUrl: e.validationURL,
                        diningSessionID,
                        gatewayID: gatewayId,
                    });

                    session.completeMerchantValidation(JSON.parse(validationResponse.data.jsonData));
                } catch (error) {
                    setLoading(false);
                    onUnlockPayment();
                    session?.abort();
                }
            };

            session.onpaymentmethodselected = () => {
                const update: ApplePayJS.ApplePayPaymentMethodUpdate = {
                    newTotal: {
                        label: 'Qlub_',
                        type: 'final',
                        amount: totalAmount.toFixed(currencyPrecision || 0),
                    },
                };
                session.completePaymentMethodSelection(update);
            };

            session.onpaymentauthorized = async (e) => {
                try {
                    const requestPayload: IAdyenAdvancedPaymentsPayload = {
                        id: sessionId,
                        diningSessionID,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                        reference: refId,
                        gatewayID: gatewayId,
                        paymentMethod: {
                            type: 'applepay',
                            applePayToken: btoa(JSON.stringify(e.payment.token.paymentData)),
                        },
                        shippingContact: e.payment?.shippingContact,
                        billingContact: e.payment?.billingContact,
                        hostname: window.location.hostname,
                    };

                    await PaymentAPIManager.getInstance().payAdyenAdvancedPayments(requestPayload);

                    /** to avoid throwing error when backend taking
                     *  long time to complete the payment
                     */
                    try {
                        session.completePayment(ApplePaySession.STATUS_SUCCESS);
                        // eslint-disable-next-line no-empty
                    } catch (_) {}

                    onPending({
                        paymentElement: PaymentElementEnum.ApplePay,
                        refId,
                        traceId: traceStart?.traceId,
                    });

                    enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                } catch (error: any) {
                    setLoading(false);
                    session.completePayment(ApplePaySession.STATUS_FAILURE);
                    onTraceClose?.({
                        error,
                        location: 'paymentAdyenPayByApple',
                        traceRef,
                        traceStart,
                    });

                    if (!error?.data) {
                        onPending({
                            paymentElement: PaymentElementEnum.ApplePay,
                            refId,
                            traceId: traceStart?.traceId,
                        });
                    } else {
                        onFail({
                            paymentElement: PaymentElementEnum.ApplePay,
                            refId,
                            traceId: traceStart?.traceId,
                        });
                    }
                }
            };

            session.oncancel = (error: any) => {
                setLoading(false);
                disableApplePayBilling();
                onUnlockPayment();
                onTraceClose?.({
                    error,
                    location: 'adyen_applepay_cancel',
                    traceRef,
                    traceStart,
                });

                onPushEvent('applepay_cancel', {
                    pg_name: name,
                    restaurant_name: url.slug,
                    opsMode: vendor?.opsMode,
                    diningSessionId: diningSessionID,
                });
            };
        } catch (error) {
            setLoading(false);
            onTraceClose?.({
                error,
                location: 'paymentAdyenPayByApple',
                traceRef,
                traceStart,
            });
        }
    };

    const loadScriptHandler = () => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.ApplePay,
            name: 'Apple Pay',
            icon: <Apple />,
            placement: 'bottom',
        });
    };

    return (
        <div>
            <Scripts src="/pg_sdk/apple-pay-sdk.js" onReady={loadScriptHandler} />
            <div data-area="submit">
                <ApplePayButton
                    onClick={payHandler}
                    theme="dark"
                    disabled={disable || loading}
                    id="adyen-applepay-action-btn"
                    hasPgGroup={hasPgGroup}
                />
            </div>
        </div>
    );
}
