import React, { useMemo, useRef, useState, useEffect } from 'react';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Scripts from 'next/script';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import {
    IPayBeforePaymentHandler,
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { GooglePay } from '@clubpay/customer-common-module/src/component/SVG';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import GooglePayCTA from '../../../GooglePayCTA';
import { IAdyenGateway } from '../../../../repository/type/paymentGateway';
import PaymentAPIManager from '../../../../repository';

import styles from '../../index.module.scss';
import { IAdyenGetMethodListResponse } from '../../../../repository/type/adyen';

interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks {
    config: IAdyenGateway;
    hasPgGroup: boolean;
    lang: string;
    paymentMethodResponse?: IAdyenGetMethodListResponse;
}

let beforeFn: (payload: IPayBeforePaymentHandler) => Promise<boolean>;
let adyenTotalAmount = 0;

export default function PayAdyenGoogle({
    lang,
    diningSessionID,
    sessionId,
    amount,
    tip,
    name,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    hasPgGroup,
    onBeforePayment,
    onUnlockPayment,
    onPending,
    onFail,
    onPgRegister,
    onTraceStart,
    onPgUnregister,
    onTraceClose,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [loading, setLoading] = useState(false);
    const [refId, setRefId] = useState<string>(getRandomString());
    const paymentsClientRef = useRef<google.payments.api.PaymentsClient | null>(null);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const { getCallbackUrl } = useConfirmCallback();
    const onBeforeRef = useRef(onBeforePayment);
    const tipRef = useRef(tip);

    beforeFn = onBeforePayment;
    adyenTotalAmount = sumAmounts(currencyPrecision, amount, tip);

    const baseRequest = {
        apiVersion: 2,
        apiVersionMinor: 0,
    };

    const tokenizationSpecification = {
        type: 'PAYMENT_GATEWAY',
        parameters: {
            gateway: 'adyen',
            gatewayMerchantId: config.merchantAccount,
        },
    };

    const baseCardPaymentMethod: google.payments.api.IsReadyToPayPaymentMethodSpecification = {
        type: 'CARD',
        parameters: {
            allowedAuthMethods: config?.googleAllowedAuthMethods || ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
            allowedCardNetworks: config?.googleAllowedCardNetworks || ['MASTERCARD', 'VISA'],
        },
    };

    const getGoogleIsReadyToPayRequest = (): google.payments.api.IsReadyToPayRequest => {
        return { ...baseRequest, allowedPaymentMethods: [baseCardPaymentMethod] } as any;
    };

    const getGooglePaymentsClient = () => {
        if (paymentsClientRef.current === null) {
            paymentsClientRef.current = new google.payments.api.PaymentsClient({
                environment: config?.sandbox ? 'TEST' : 'PRODUCTION',
            });
        }
        return paymentsClientRef.current;
    };

    const cardPaymentMethod = { ...baseCardPaymentMethod, tokenizationSpecification };

    const getGoogleTransactionInfo = (): google.payments.api.TransactionInfo => {
        return {
            totalPriceStatus: 'FINAL',
            totalPrice: adyenTotalAmount.toFixed(currencyPrecision || 0),
            countryCode: (config?.countryCode || vendor.country.code)?.toUpperCase() || 'AE',
            currencyCode: vendor.country.currencyCode?.toUpperCase() || '',
        };
    };

    const getGooglePaymentDataRequest = (): google.payments.api.PaymentDataRequest => {
        const paymentDataRequest: any = { ...baseRequest };
        paymentDataRequest.allowedPaymentMethods = [cardPaymentMethod];
        paymentDataRequest.transactionInfo = getGoogleTransactionInfo();
        paymentDataRequest.merchantInfo = {
            merchantId: config?.googleMerchantId || '',
            merchantName: 'qlub',
        };
        return paymentDataRequest;
    };

    // @ts-ignore
    // function prefetchGooglePaymentData() {
    //     const paymentDataRequest = getGooglePaymentDataRequest();
    //     // transactionInfo must be set but does not affect cache
    //     paymentDataRequest.transactionInfo = {
    //         totalPrice: totalAmount.toFixed(currencyPrecision || 0),
    //         totalPriceStatus: 'NOT_CURRENTLY_KNOWN',
    //         countryCode: config?.countryCode || region || 'AE',
    //         currencyCode: currencyCode?.toUpperCase() || '',
    //     };
    //     const paymentsClient = getGooglePaymentsClient();
    //     paymentsClient.prefetchPaymentData(paymentDataRequest);
    // }
    useEffect(() => {
        onBeforeRef.current = onBeforePayment;
        tipRef.current = tip;
    }, [amount, tip]);

    /**
     * Show Google Pay payment sheet when Google Pay payment button is clicked
     */
    const onGooglePaymentButtonClicked = () => {
        if (disable || loading) {
            return;
        }

        setLoading(true);

        setRefId(getRandomString());
        beforeFn({
            gatewayId,
            paymentElement: PaymentElementEnum.GooglePay,
            tip,
        }).then((ok) => {
            if (!ok) {
                setLoading(false);
                return;
            }

            const paymentDataRequest = getGooglePaymentDataRequest();
            paymentDataRequest.transactionInfo = getGoogleTransactionInfo();

            const returnUrl = getCallbackUrl({
                ref: refId,
                method: name,
                paymentElement: PaymentElementEnum.CardPay,
                dsi: diningSessionID,
                amount,
                currencySymbol: vendor.country.currencySymbol,
                traceId: traceStart?.traceId,
                lang,
            });

            const paymentsClient = getGooglePaymentsClient();
            paymentsClient
                .loadPaymentData(paymentDataRequest)
                .then((paymentData) => {
                    PaymentAPIManager.getInstance()
                        .payAdyenAdvancedPayments({
                            diningSessionID,
                            gatewayID: gatewayId,
                            id: sessionId,
                            reference: refId,
                            returnUrl: returnUrl.pending,
                            tipAmount: tipRef.current.toFixed(2),
                            paymentMethod: {
                                type: 'googlepay',
                                googlePayToken: paymentData.paymentMethodData.tokenizationData.token,
                            },
                        })
                        .then(() => {
                            onPending({
                                paymentElement: PaymentElementEnum.GooglePay,
                                refId,
                                traceId: traceStart?.traceId,
                            });

                            enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                        })
                        .catch((error: any) => {
                            onTraceClose?.({
                                error,
                                location: 'paymentAdyenPayByGoogle',
                                traceRef,
                                traceStart,
                            });

                            if (!error?.data) {
                                onPending({
                                    paymentElement: PaymentElementEnum.GooglePay,
                                    refId,
                                    traceId: traceStart?.traceId,
                                });
                            } else {
                                onFail({
                                    paymentElement: PaymentElementEnum.GooglePay,
                                    refId,
                                    traceId: traceStart?.traceId,
                                });
                            }
                        })
                        .finally(() => {
                            setLoading(false);
                        });
                })
                .catch((err) => {
                    console.error(err);
                    setLoading(false);
                    onUnlockPayment();
                });
        });
    };

    const addGooglePayButton = () => {
        const paymentsClient = getGooglePaymentsClient();
        const button = paymentsClient.createButton({
            onClick: onGooglePaymentButtonClicked,
            allowedPaymentMethods: [baseCardPaymentMethod],
            buttonSizeMode: 'fill',
            buttonType: 'pay',
        });
        document.querySelector('#adyen-google-pay')?.appendChild(button);
    };

    const loadScriptHandler = () => {
        traceRef.current = traceStart?.startSpan?.({
            dataName: name,
            span: {
                element: PaymentElementEnum.GooglePay,
                refId,
            },
        });

        const paymentsClient = getGooglePaymentsClient();
        paymentsClient
            .isReadyToPay(getGoogleIsReadyToPayRequest())
            .then((response) => {
                if (response.result) {
                    onPgRegister?.({
                        pgId: gatewayId,
                        elem: PaymentElementEnum.GooglePay,
                        icon: <GooglePay />,
                        name: t('Google Pay'),
                        placement: 'bottom',
                    });
                    addGooglePayButton();
                }
            })
            .catch((err) => {
                onTraceClose?.({
                    error: err,
                    location: 'paymentsClient.isReadyToPay',
                    traceRef,
                    traceStart,
                });
                onPgUnregister?.({
                    pgId: gatewayId,
                    elem: PaymentElementEnum.GooglePay,
                });
            });
    };

    return (
        <div className={styles.payButton}>
            <Scripts src="https://pay.google.com/gp/p/js/pay.js" onReady={loadScriptHandler} />
            <GooglePayCTA id="adyen-google-pay" loading={loading} hasPgGroup={hasPgGroup} />
        </div>
    );
}
