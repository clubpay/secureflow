/* eslint-disable no-empty */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import AdyenCheckout from '@adyen/adyen-web';
import '@adyen/adyen-web/dist/adyen.css';
import CardElement from '@adyen/adyen-web/dist/types/components/Card/Card';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { CreditCard } from '@mui/icons-material';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';

import { IAdyenGetMethodListResponse, IAdyenPaymentRequest } from '../../../../repository/type/adyen';
import PaymentAPIManager from '../../../../repository';
import { IAdyenGateway } from '../../../../repository/type/paymentGateway';
import PayButtonElement from '../../../PayButtonElement';

interface IProps extends IPGProps {
    config: IAdyenGateway;
    paymentMethodResponse: IAdyenGetMethodListResponse;
}

const PayAdyenCard = ({
    diningSessionID,
    sessionId,
    amount,
    tip,
    config,
    gatewayId,
    vendor,
    name,
    onBeforePayment,
    onUnlockPayment,
    onFail,
    onPgRegister,
    onTraceStart,
    onTraceClose,
    onPending,
    paymentMethodResponse,
}: IProps) => {
    const paymentContainer = useRef(null);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const [cardElement, setCardElement] = useState<CardElement>();
    const [loading, setLoading] = useState(false);
    const { getCallbackUrl } = useConfirmCallback();
    const checkoutRef = useRef<any>();
    const onBeforeRef = useRef(onBeforePayment);
    const tipRef = useRef(tip);

    const { lang } = useQlubRouter();
    const { t } = useTranslation('common');

    const { hasPgGroup } = vendor.paymentGatewayList;

    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    const handleSubmit = async () => {
        setLoading(true);
        const tipCheckResponse = await onBeforeRef.current({
            checkTipOnly: true,
            gatewayId,
            paymentElement: PaymentElementEnum.CardPay,
            tip: tipRef.current,
        });

        if (!tipCheckResponse) {
            setLoading(false);
            return;
        }
        setLoading(false);
        if (cardElement) cardElement.submit();
    };

    const handlePay = async (e: IAdyenPaymentRequest) => {
        setLoading(true);

        const refId = getRandomString();

        try {
            traceRef.current = traceStart?.startSpan({
                dataName: name,
                span: {
                    element: PaymentElementEnum.CardPay,
                    refId,
                },
            });

            const returnUrl = getCallbackUrl({
                ref: refId,
                method: name,
                paymentElement: PaymentElementEnum.CardPay,
                dsi: diningSessionID,
                amount,
                currencySymbol: vendor.country.currencySymbol,
                traceId: traceStart?.traceId,
                lang,
            });

            const onBeforeResponse = await onBeforeRef.current({
                gatewayId,
                paymentElement: PaymentElementEnum.CardPay,
                tip: tipRef.current,
            });
            if (!onBeforeResponse) return;

            try {
                await PaymentAPIManager.getInstance().payAdyenAdvancedPayments({
                    diningSessionID,
                    gatewayID: gatewayId,
                    id: sessionId,
                    reference: refId,
                    returnUrl: returnUrl.pending,
                    tipAmount: tipRef.current.toFixed(2),
                    paymentMethod: e.data.paymentMethod,
                });

                onPending({
                    paymentElement: PaymentElementEnum.CardPay,
                    refId,
                    traceId: traceStart?.traceId,
                });
            } catch (error: any) {
                if (!error?.data) {
                    onTraceClose?.({
                        error,
                        location: 'pay_adyen_card',
                        traceRef,
                        traceStart,
                    });
                    onPending({
                        paymentElement: PaymentElementEnum.CardPay,
                        refId,
                        traceId: traceStart?.traceId,
                    });
                } else throw error;
            }
        } catch (error: any) {
            onTraceClose?.({
                error,
                location: 'pay_adyen_card',
                traceRef,
                traceStart,
            });

            onFail({
                paymentElement: PaymentElementEnum.CardPay,
                refId,
                traceId: traceStart?.traceId,
            });
        } finally {
            setLoading(false);
            onUnlockPayment();
            cardElement?.update({});
        }
    };

    const configuration = {
        locale: (lang || 'en') as any,
        environment: config.sandbox ? 'test' : 'live',
        clientKey: config?.clientKey || 'test_5AX7FFAR4VBHRKWO6PMKPTXWNYKRP2AQ',
        paymentMethodsResponse: paymentMethodResponse,
        onSubmit: handlePay,
        paymentMethodsConfiguration: {
            card: {
                hasHolderName: config?.hasHolderName || false,
                holderNameRequired: true,
            },
        },
    };

    useEffect(() => {
        const initAdyenCheckout = async () => {
            try {
                const checkout = await AdyenCheckout(configuration);
                checkoutRef.current = checkout;
                if (paymentContainer.current) {
                    const card = checkout.create('card').mount(paymentContainer.current);
                    setCardElement(card);
                }
            } catch (_) {}
        };
        initAdyenCheckout();
    }, []);

    useEffect(() => {
        onBeforeRef.current = onBeforePayment;
        tipRef.current = tip;
    }, [amount, tip]);

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.CardPay,
            name: t('Card'),
            icon: <CreditCard />,
            buttonElement: (
                <PayButtonElement
                    variant="contained"
                    fullWidth
                    loading={loading}
                    disabled={loading}
                    onClick={handleSubmit}
                />
            ),
        });
    }, [lang, cardElement, loading]);

    return (
        <div>
            <div id="card-container">
                <div ref={paymentContainer} />
            </div>
            {!hasPgGroup && (
                <PayButtonElement
                    variant="contained"
                    fullWidth
                    showConfirmText
                    disabled={loading}
                    onClick={handleSubmit}
                />
            )}
        </div>
    );
};

export default PayAdyenCard;
