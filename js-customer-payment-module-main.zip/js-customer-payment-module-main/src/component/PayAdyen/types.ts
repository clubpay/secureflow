export interface IAdyenCard {
    bin: string;
    isMada: boolean;
    last4: string;
    scheme: string;
    sourceId: string;
}
