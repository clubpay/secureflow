import React, { useMemo, useRef, useEffect, useState } from 'react';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { isSafari } from '@clubpay/customer-common-module/src/utility/mobile_check';
import { applePayJsAvailable } from '../ApplePayButton/utils/handlers';
import PaymentWrapper from '../PaymentWrapper';
import PayAdyenCard from './components/Card';
import { IAdyenGateway } from '../../repository/type/paymentGateway';
import PaymentAPIManager from '../../repository';
import ApplePay from './components/ApplePay';
import PayAdyenGoogle from './components/GooglePay';
import styles from './index.module.scss';

export interface IProps extends IPGProps {
    config: IAdyenGateway;
}

export default function PayAdyen({
    name,
    diningSessionID,
    url,
    amount,
    tip,
    currencyPrecision,
    config,
    disable,
    enableButton,
    gatewayId,
    sessionId,
    vendor,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onPending,
    onOverlayClick,
    onIndicator,
    onLoad,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onTraceClose,
    jwt,
    updateTimestamp,
    onPgUnregister,
}: IProps) {
    const [hasApplePay, setHasApplePay] = useState(false);
    const [hasGooglePay, setHasGooglePay] = useState(false);
    const { hasPgGroup } = vendor.paymentGatewayList;
    const { login, isLogin } = useAuth();
    const { lang } = useQlubRouter();
    const [paymentMethodResponse, setPaymentMethodResponse] = useState<any>();
    const totalAmount = sumAmounts(currencyPrecision, amount, tip);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    // const payReference = useRef<string>(getRandomString());

    const getPaymentMethodList = async () => {
        try {
            const res = await PaymentAPIManager.getInstance().payAdyenPaymentMethodList({ gatewayId });
            setPaymentMethodResponse(res.data);
            console.log('paymentmethod resp', { res });
        } catch (err) {
            console.error('Error fetching payment method list:', err);
        }
    };

    console.log('hasgooglepay', { hasGooglePay });

    useEffect(() => {
        if (!isLogin) {
            login({ guest: true });
        }

        const ref = getRandomString();
        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.ApplePay,
                refId: ref,
            },
        });

        getPaymentMethodList();
    }, [isLogin]);

    useEffect(() => {
        setPaymentMethodResponse(paymentMethodResponse);
    }, [gatewayId, totalAmount]);

    useEffect(() => {
        applePayJsAvailable().then((enable) => {
            setHasApplePay(enable);
        });

        setHasGooglePay(!isSafari());
    }, [url.cc, url.slug, url.id]);

    return (
        <div className={styles.form}>
            {!config?.hideApplePay && hasApplePay && !hasGooglePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.ApplePay)}>
                    <ApplePay
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        vendor={vendor}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        hasPgGroup={hasPgGroup}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onPending={onPending}
                        onFail={onFail}
                        onPgRegister={onPgRegister}
                        onTraceStart={onTraceStart}
                        onTraceClose={onTraceClose}
                    />
                </PaymentWrapper>
            )}

            {config?.hideCardPay !== true && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}>
                    <PayAdyenCard
                        name={name}
                        diningSessionID={diningSessionID}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        config={config}
                        gatewayId={gatewayId}
                        jwt={jwt}
                        disable={disable}
                        vendor={vendor}
                        sessionId={sessionId}
                        enableButton={enableButton}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onOverlayClick={onOverlayClick}
                        onIndicator={onIndicator}
                        onLoad={onLoad}
                        onPgRegister={onPgRegister}
                        onTraceStart={onTraceStart}
                        paymentMethodResponse={paymentMethodResponse}
                        onPgUnregister={onPgUnregister}
                    />
                </PaymentWrapper>
            )}
            {!config?.hideGooglePay && hasGooglePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.GooglePay)}>
                    <PayAdyenGoogle
                        lang={lang}
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        vendor={vendor}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        hasPgGroup={hasPgGroup}
                        onPgUnregister={onPgUnregister}
                        onTraceClose={onTraceClose}
                    />
                </PaymentWrapper>
            )}
        </div>
    );
}
