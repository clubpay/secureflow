const { host, protocol } = window.location;

export const httpPost = async (endpoint: string, data: any): Promise<any> => {
    const response = await fetch(`${protocol}//${host}/${endpoint}`, {
        method: 'POST',
        headers: {
            Accept: 'application/json, text/plain, */*',
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    });

    return response.json();
};

export const checkPaymentResult = (resultCode?: string): boolean =>
    ['authorised', 'received', 'pending'].includes(resultCode?.toLowerCase() ?? '');

export const getSearchParameters = (search: string = window.location.search): Record<string, string> => {
    return search
        .replace(/\?/g, '')
        .split('&')
        .reduce((acc: Record<string, string>, cur: string) => {
            const [key, prop = ''] = cur.split('=');
            acc[key] = decodeURIComponent(prop);
            return acc;
        }, {});
};

export const setSearchParams = (params: Record<string, string>): void => {
    const newSearchParams = new URLSearchParams(params);
    window.location.href = `${window.location.origin}${window.location.pathname}?${newSearchParams.toString()}`;
};

export const insertHeader = (pages: { name: string; id: string }[]): void => {
    const isManualFlow = getSearchParameters(window.location.search).session === 'manual';
    const container = document.querySelector('header');
    const links = pages
        .filter((page) => page.id !== 'Result')
        .map(({ name, id }, index) => {
            const url = `/${index ? id.toLowerCase() : ''}`;
            const isActivePage = window.location.pathname === url;

            return `
            <li class="playground-nav__item ${isActivePage ? 'playground-nav__item--active' : ''}">
                <a href="${url}" class="playground-nav__link">${name}</a>
            </li>
        `;
        });

    const header = `
        <button type="button" class="playground-nav-button" aria-label="Toggle nav">
            <span aria-hidden></span>
        </button>

        <h1>Adyen Web <span class="env">Dev</span></h1>

        <nav class="playground-nav">
            <ul class="playground-nav__list">${links.join('')}</ul>
        </nav>
        
        <nav class="session-switch">
            <ul class="session-switch__list">
                <li><button class="session-switch__button session-switch__button--session ${
                    !isManualFlow ? 'session-switch__button--active' : ''
                }">Session</button></li>
                <li><button class="session-switch__button session-switch__button--manual ${
                    isManualFlow ? 'session-switch__button--active' : ''
                }">Manual</button></li>
            </ul>
        </nav>
    `;

    if (container) container.innerHTML = header;
};
