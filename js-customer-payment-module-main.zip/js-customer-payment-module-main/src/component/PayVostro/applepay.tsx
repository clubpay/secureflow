import React, { useState, useCallback, useMemo, useRef } from 'react';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Scripts from 'next/script';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { Apple } from '@mui/icons-material';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IVostroGateway } from '../../repository/type/paymentGateway';
import PaymentAPIManager from '../../repository';
import { ApplePayButton } from '../ApplePayButton';

import styles from './index.module.scss';

interface IProps extends IPGBaseProps, IPGStateCallbacks, IPGHooks {
    config: IVostroGateway;
    hasPgGroup: boolean;
}

const defaultMerchantCapabilities = ['supports3DS'];
const defaultSupportedNetworks = ['visa', 'masterCard', 'amex', 'discover'];

export default function PayVostroApple({
    name,
    diningSessionID,
    sessionId,
    amount,
    tip,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    hasPgGroup,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onPending,
    onFail,
    onPgRegister,
    onTraceStart,
    onTraceClose,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [loading, setLoading] = useState(false);
    const [scriptsLoaded, setScriptsLoaded] = useState(false);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    const {
        countryCode = vendor.country.code || 'AU',
        merchantCapabilitiesList = config?.merchantCapabilitiesList ||
            config?.merchantCapabilities ||
            defaultMerchantCapabilities,
        supportedNetworksList = config?.supportedNetworksList || config?.supportedNetworks || defaultSupportedNetworks,
        appleSDKVersion = config?.appleSDKVersion || 3,
    } = config || {};

    const totalAmount = sumAmounts(currencyPrecision, amount, tip);

    console.log({ config });

    const request: ApplePayJS.ApplePayPaymentRequest = {
        countryCode: countryCode ?? vendor.country.code ?? 'AU',
        currencyCode: vendor.country.currencyCode?.toUpperCase() || 'AUD',
        merchantCapabilities: merchantCapabilitiesList as any,
        supportedNetworks: supportedNetworksList as any,
        total: {
            label: 'Qlub_',
            type: 'final',
            amount: totalAmount.toFixed(currencyPrecision || 2),
        },
    };

    const payHandler = useCallback(() => {
        console.log({ request });
        const refId = getRandomString();

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.ApplePay,
                refId,
            },
        });

        if (!ApplePaySession) {
            console.log({ config });
            return;
        }

        try {
            // Creqte a new Apple Pay session
            const session: ApplePaySession = new ApplePaySession(appleSDKVersion, request);

            session.onvalidatemerchant = (e) => {
                console.log({ onvalidatemerchant: e });
                // Call your own server to request a new merchant session.
                onBeforePayment({
                    gatewayId,
                    paymentElement: PaymentElementEnum.ApplePay,
                    tip,
                })
                    .then((ok) => {
                        if (!ok) {
                            try {
                                session?.abort();
                            } catch (err) {
                                console.log(err);
                            }
                            return;
                        }
                        setLoading(true);
                        PaymentAPIManager.getInstance()
                            .paymentVostroValidateApplePaySession({
                                diningSessionID,
                                applePayUrl: e.validationURL,
                                gatewayID: gatewayId,
                            })
                            .then((res) => {
                                console.log({ res }, JSON.parse(res.data.jsonData));
                                session.completeMerchantValidation(JSON.parse(res.data.jsonData));
                            })
                            .catch(() => {
                                try {
                                    session?.abort();
                                } catch (err) {
                                    console.log(err);
                                }
                                onUnlockPayment();
                            })
                            .finally(() => {
                                setLoading(false);
                            });
                    })
                    .catch(() => {
                        setLoading(false);
                    });
            };

            session.onpaymentmethodselected = (e) => {
                const update: ApplePayJS.ApplePayPaymentMethodUpdate = {
                    newTotal: {
                        label: 'Qlub_',
                        type: 'final',
                        amount: totalAmount.toFixed(currencyPrecision || 0),
                    },
                };
                session.completePaymentMethodSelection(update);
                console.log({ onpaymentmethodselected: e });
            };

            session.onshippingmethodselected = (e) => {
                const update: any = {};
                session.completeShippingMethodSelection(update);
                console.log({ onshippingmethodselected: e });
            };

            session.onshippingcontactselected = (e) => {
                const update: any = {};
                session.completeShippingContactSelection(update);
                console.log({ onshippingcontactselected: e });
            };

            session.onpaymentauthorized = (e) => {
                setLoading(true);
                PaymentAPIManager.getInstance()
                    .paymentVostroPayByApple({
                        id: sessionId,
                        diningSessionID,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                        appleToken: JSON.stringify(e.payment?.token || {}),
                        reference: refId,
                        gatewayID: gatewayId,
                        cardType: e.payment?.token?.paymentMethod?.network || '',
                    })
                    .then(() => {
                        const result: ApplePayJS.ApplePayPaymentAuthorizationResult = {
                            status: ApplePaySession.STATUS_SUCCESS,
                        };

                        try {
                            session.completePayment(result);
                        } catch (err) {
                            console.log(err);
                        }

                        onDone({
                            paymentElement: PaymentElementEnum.ApplePay,
                            refId,
                        });

                        enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                    })
                    .catch((err: Error) => {
                        onTraceClose?.({
                            error: err,
                            location: 'paymentVostroPayByApple',
                            traceRef,
                            traceStart,
                        });

                        const result: ApplePayJS.ApplePayPaymentAuthorizationResult = {
                            status: ApplePaySession.STATUS_FAILURE,
                        };
                        try {
                            session.completePayment(result);
                        } catch (error) {
                            console.log(error);
                        }

                        const isNetworkError = checkNetworkError(err as AxiosError);
                        if (isNetworkError) {
                            onPending({
                                paymentElement: PaymentElementEnum.ApplePay,
                                refId,
                            });
                        }

                        onFail({
                            paymentElement: PaymentElementEnum.ApplePay,
                            refId,
                            traceId: traceStart?.traceId,
                        });

                        console.log({ onpaymentauthorized: e, err });
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            };

            session.oncancel = (e: any) => {
                setLoading(false);
                console.log({ oncancel: e });
                onUnlockPayment();
            };

            session.begin();
        } catch (e) {
            console.warn({ applePay: e });
        }
    }, [amount, tip, scriptsLoaded, onBeforePayment]);

    const loadScriptHandler = () => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.ApplePay,
            name: t('Apple Pay'),
            icon: <Apple />,
            placement: 'bottom',
        });

        setScriptsLoaded(true);
    };

    return (
        <div className={styles.payButton}>
            <Scripts src="/pg_sdk/apple-pay-sdk.js" onReady={loadScriptHandler} />
            <div className={styles.container} data-area="submit">
                <ApplePayButton
                    onClick={payHandler}
                    theme="dark"
                    disabled={disable || loading}
                    id="vostro-applepay-action-btn"
                    hasPgGroup={hasPgGroup}
                />
            </div>
        </div>
    );
}
