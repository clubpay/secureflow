import React, { useMemo, useRef, useState } from 'react';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Scripts from 'next/script';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import {
    IPayBeforePaymentHandler,
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { GooglePay } from '@clubpay/customer-common-module/src/component/SVG';
import PaymentAPIManager from '../../repository';
import GooglePayCTA from '../GooglePayCTA';
import { IVostroGateway } from '../../repository/type/paymentGateway';

import styles from './index.module.scss';

interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks {
    config: IVostroGateway;
    hasPgGroup: boolean;
}

let beforeFn: (payload: IPayBeforePaymentHandler) => Promise<boolean>;
let vostroTotalAmount = 0;
let vostroTipAmount = 0;

export default function PayVostroGoogle({
    name,
    diningSessionID,
    sessionId,
    amount,
    tip,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    hasPgGroup,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onPending,
    onFail,
    onPgRegister,
    onTraceStart,
    onPgUnregister,
    onTraceClose,
}: IProps) {
    const { t } = useTranslation('common');
    const { lang } = useQlubRouter();
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [loading, setLoading] = useState(false);
    const paymentsClientRef = useRef<google.payments.api.PaymentsClient | null>(null);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const [refId, setRefId] = useState<string>(getRandomString());

    beforeFn = onBeforePayment;
    const totalAmount = sumAmounts(currencyPrecision, amount, tip);
    vostroTotalAmount = totalAmount;
    vostroTipAmount = tip;

    const baseRequest = {
        apiVersion: 2,
        apiVersionMinor: 0,
    };

    const allowedCardAuthMethods = config?.googleAllowedAuthMethods || ['PAN_ONLY', 'CRYPTOGRAM_3DS'];
    const allowedCardNetworks = config?.googleAllowedCardNetworks || [
        'AMEX',
        'DISCOVER',
        'JCB',
        'INTERAC',
        'MASTERCARD',
        'VISA',
    ];

    const tokenizationSpecification = {
        type: 'PAYMENT_GATEWAY',
        parameters: {
            gateway: name,
            gatewayMerchantId: config?.publicKey || '',
        },
    };

    const baseCardPaymentMethod: google.payments.api.IsReadyToPayPaymentMethodSpecification = {
        type: 'CARD',
        parameters: {
            allowedAuthMethods: allowedCardAuthMethods,
            allowedCardNetworks,
        },
    };

    const getGoogleIsReadyToPayRequest = (): google.payments.api.IsReadyToPayRequest => {
        return {
            ...baseRequest,
            allowedPaymentMethods: [baseCardPaymentMethod],
        } as any;
    };

    const getGooglePaymentsClient = () => {
        if (paymentsClientRef.current === null) {
            paymentsClientRef.current = new google.payments.api.PaymentsClient({
                environment: config?.sandbox ? 'TEST' : 'PRODUCTION',
            });
        }
        return paymentsClientRef.current;
    };

    const cardPaymentMethod = { ...baseCardPaymentMethod, tokenizationSpecification };

    const getGoogleTransactionInfo = (): google.payments.api.TransactionInfo => {
        return {
            totalPriceStatus: 'FINAL',
            totalPriceLabel: t('Total'),
            totalPrice: vostroTotalAmount.toFixed(currencyPrecision || 2),
            countryCode: config?.countryCode || 'AU',
            currencyCode: vendor.country?.currencyCode || 'AUD',
        };
    };

    const getGooglePaymentDataRequest = (): google.payments.api.PaymentDataRequest => {
        const paymentDataRequest: any = { ...baseRequest };
        paymentDataRequest.allowedPaymentMethods = [cardPaymentMethod];
        paymentDataRequest.transactionInfo = getGoogleTransactionInfo();
        paymentDataRequest.merchantInfo = {
            merchantId: config?.googleMerchantId || '',
            merchantName: 'qlub',
        };
        return paymentDataRequest;
    };

    const onGooglePaymentButtonClicked = async () => {
        if (disable || loading) {
            return;
        }

        setLoading(true);
        beforeFn({
            gatewayId,
            paymentElement: PaymentElementEnum.GooglePay,
            tip,
        }).then((ok) => {
            if (!ok) {
                setLoading(false);
                return;
            }

            const paymentDataRequest = getGooglePaymentDataRequest();
            paymentDataRequest.transactionInfo = getGooglePaymentDataRequest().transactionInfo;

            const paymentsClient = getGooglePaymentsClient();
            paymentsClient
                .loadPaymentData(paymentDataRequest)
                .then((paymentData) => {
                    setRefId(getRandomString());
                    PaymentAPIManager.getInstance()
                        .paymentVostroPayByGoogle({
                            id: sessionId,
                            diningSessionID,
                            tipAmount: vostroTipAmount.toFixed(currencyPrecision || 2),
                            googleToken: paymentData.paymentMethodData.tokenizationData.token,
                            reference: refId,
                            gatewayID: gatewayId,
                            cardType: paymentData.paymentMethodData.info?.cardNetwork || '',
                        })
                        .then(() => {
                            onDone({
                                paymentElement: PaymentElementEnum.GooglePay,
                                refId,
                            });

                            enqueueSnackbar(t('Payment successful'), { variant: 'success' });
                        })
                        .catch((err: Error) => {
                            onTraceClose?.({
                                error: err,
                                location: 'paymentVostroPayByGoogle',
                                traceRef,
                                traceStart,
                            });

                            const isNetworkError = checkNetworkError(err as AxiosError);
                            if (isNetworkError) {
                                onPending({
                                    paymentElement: PaymentElementEnum.GooglePay,
                                    refId,
                                    traceId: traceStart?.traceId,
                                });
                            }

                            onFail({
                                paymentElement: PaymentElementEnum.GooglePay,
                                refId,
                                traceId: traceStart?.traceId,
                            });
                        })
                        .finally(() => {
                            setLoading(false);
                        });
                })
                .catch((err) => {
                    console.error(err);
                    setLoading(false);
                    onUnlockPayment();
                });
        });
    };

    const addGooglePayButton = () => {
        const paymentsClient = getGooglePaymentsClient();
        const button = paymentsClient.createButton({
            onClick: onGooglePaymentButtonClicked,
            allowedPaymentMethods: [baseCardPaymentMethod],
            buttonSizeMode: 'fill',
            buttonType: 'pay',
            buttonLocale: lang || 'en',
        });
        document.querySelector('#vostro-google-pay')?.appendChild(button);
    };

    const loadScriptHandler = () => {
        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.ApplePay,
                refId,
            },
        });

        const paymentsClient = getGooglePaymentsClient();
        paymentsClient
            .isReadyToPay(getGoogleIsReadyToPayRequest())
            .then((response) => {
                if (response.result) {
                    onPgRegister?.({
                        pgId: gatewayId,
                        elem: PaymentElementEnum.GooglePay,
                        icon: <GooglePay />,
                        name: t('Google Pay'),
                        placement: 'bottom',
                    });
                    addGooglePayButton();
                }
            })
            .catch((err) => {
                onTraceClose?.({
                    error: err,
                    location: 'paymentsClient.isReadyToPay',
                    traceRef,
                    traceStart,
                });

                onPgUnregister?.({
                    pgId: gatewayId,
                    elem: PaymentElementEnum.GooglePay,
                });
            });
    };

    return (
        <div className={styles.payButton}>
            <Scripts src="https://pay.google.com/gp/p/js/pay.js" onReady={loadScriptHandler} />
            <GooglePayCTA id="vostro-google-pay" loading={loading} hasPgGroup={hasPgGroup} />
        </div>
    );
}
