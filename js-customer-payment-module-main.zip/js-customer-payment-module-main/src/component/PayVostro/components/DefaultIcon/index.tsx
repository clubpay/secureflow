import {
    AmericanExpressLogoIcon,
    MasterCardLogoIcon,
    VisaLogoIcon,
} from '@clubpay/customer-common-module/src/component/SVG';

const DefaultIcons = () => {
    return (
        <>
            <VisaLogoIcon />
            <MasterCardLogoIcon />
            <AmericanExpressLogoIcon />
        </>
    );
};

export default DefaultIcons;
