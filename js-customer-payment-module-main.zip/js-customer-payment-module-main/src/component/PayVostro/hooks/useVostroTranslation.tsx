import { useMemo } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';

export const useVostroTranslation = () => {
    const { t } = useTranslation('common');

    const labels = useMemo(
        () => ({
            cardHolderName: t('Cardholder name'),
            newCard: t('New card'),
            cvv: t('CVV'),
            cardNumber: t('Card Number'),
            expirationDate: t('Expiration Date'),
            saveCard: t('Save card'),
            securePayment: t('100% Secure payments powered by Qlub_'),
        }),
        [t],
    );

    const errorMessages = useMemo(
        () => ({
            integration_key: {
                configuration: t('Invalid integration key'),
                system: t('System error occurred, please retry'),
            },
            cvv: {
                invalid: t('Invalid CVV code'),
                required: t('CVV is required'),
                blank: t('CVV code must not be empty'),
            },
            number: {
                invalid: t('Invalid card number'),
                required: t('Card number is required'),
                blank: t('Card number must not be empty'),
            },
            card_holder: {
                blank: t('Card holder must not be empty'),
                invalid: t('Invalid cardholder name'),
                required: t('Card holder name is required'),
            },
            expirationDate: {
                invalid: t('Invalid expiration date'),
                required: t('Expiration date is required'),
            },
            month: {
                blank: t('Expiration month must not be empty'),
                invalid: t('Invalid expiration month'),
            },
            year: {
                blank: t('Expiration year must not be empty'),
                invalid: t('Invalid expiration year'),
                expired: t('Card expired'),
            },
        }),
        [t],
    );

    // export the types in the hook
    return { labels, errorMessages };
};
