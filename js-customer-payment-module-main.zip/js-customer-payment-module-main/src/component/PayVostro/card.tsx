import React, { useEffect, useMemo, useRef, useState } from 'react';
import Scripts from 'next/script';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { CreditCard } from '@mui/icons-material';
import { TextField, FormHelperText, Box } from '@mui/material';
import classNames from 'classnames';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { CVVIcon, CardIcon } from '@clubpay/customer-common-module/src/component/SVG';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { expirationDateFormat } from '@qlub-dev/qlub-kit';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import PaymentWrapper from '../PaymentWrapper';
import PayButtonElement from '../PayButtonElement';
import PaymentAPIManager from '../../repository';
import { PaymentJs } from './vostrolib';
import { useVostroTranslation } from './hooks/useVostroTranslation';

import styles from './index.module.scss';

export interface IProps extends IPGProps {
    config: any;
}

export interface ICardModel {
    card_holder: string;
    exp_date: string;
}

const inputStyle = {
    border: 'none',
    outline: 0,
    boxShadow: 'none',
    height: '100%',
    fontSize: '17px',
    padding: '16px 0 16px 14px',
    fontWeight: 400,
    letterSpacing: '0.5px',
    textRendering: 'geometricPrecision',
    direction: 'ltr',
};

const CardElement = ({
    name,
    enableButton,
    diningSessionID,
    sessionId,
    amount,
    tip,
    currencyPrecision,
    disable,
    gatewayId,
    config,
    vendor,
    pgSelectedElem,
    pgSelectedId,
    updateTimestamp,
    onDone,
    onFail,
    onPgRegister,
    onUnlockPayment,
    onBeforePayment,
    onTraceStart,
    onTraceClose,
}: IProps) => {
    const { errorMessages } = useVostroTranslation();
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const { t } = useTranslation('common');
    const [formValues, setFormValues] = useState<ICardModel>({
        card_holder: '',
        exp_date: '',
    });
    const [loading, setLoading] = useState(false);
    const vostroRef = useRef<PaymentJs | undefined>(undefined);
    const [isCardNumberFocused, setIsCardNumberFocused] = useState(false);
    const [isCvvFocused, setIsCvvFocused] = useState(false);
    const [showExpDateError, setShowExpDateError] = useState(false);
    const [errorMap, setErrorMap] = useState<{ [key: string]: string }>({});
    const { hasPgGroup } = vendor.paymentGatewayList;
    const { lang } = useQlubRouter();
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const [refId, setRefId] = useState<string>(getRandomString());

    const submitHandler = async (transactionToken: string) => {
        setRefId(getRandomString());

        PaymentAPIManager.getInstance()
            .payVostroPayment({
                diningSessionID,
                id: sessionId,
                transactionToken,
                reference: refId,
                tipAmount: tip.toFixed(currencyPrecision || 0),
                gatewayID: gatewayId,
                amount: amount.toFixed(currencyPrecision || 0),
                currency: vendor.country.currencyCode,
            })
            .then((res) => {
                if (res.data.redirectUrl) {
                    window.location.href = res.data.redirectUrl;
                    return;
                }
                if (res.data.success) {
                    onDone({
                        paymentElement: PaymentElementEnum.CardPay,
                        refId,
                    });
                } else {
                    onTraceClose?.({
                        error: res.data,
                        location: 'payVostroPayment - res.data.success is false',
                        traceRef,
                        traceStart,
                    });

                    onFail({
                        paymentElement: PaymentElementEnum.CardPay,
                        refId,
                        traceId: traceStart?.traceId,
                    });
                }
            })
            .catch((err) => {
                onTraceClose?.({
                    error: err,
                    location: 'payVostroPayment',
                    traceRef,
                    traceStart,
                });

                onFail({
                    paymentElement: PaymentElementEnum.CardPay,
                    refId,
                    traceId: traceStart?.traceId,
                });
            })
            .finally(() => {
                setLoading(false);
            });
    };

    const handleSubmit = () => {
        if (!vostroRef.current || loading) {
            return;
        }
        setLoading(true);
        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.CardPay,
                refId,
            },
        });

        onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.CardPay,
            tip,
        })
            .then((ok) => {
                if (!ok) {
                    setLoading(false);
                    onUnlockPayment();
                    return;
                }

                const cloned = { ...formValues } as any;
                const [month, year] = cloned.exp_date.split('/');
                cloned.month = Number(month);
                cloned.year = Number(year);
                cloned.year = cloned.year > 100 ? cloned.year : cloned.year + 2000;
                setShowExpDateError(false);

                vostroRef.current?.tokenize(
                    cloned, // additional data, MUST include card_holder (or first_name & last_name), month and year
                    (transactionToken: any) => {
                        // success callback function
                        submitHandler(transactionToken);
                    },
                    (errors: any[]) => {
                        // check if the error is related to the expiration month or year
                        const expDateError = errors.find(
                            (err) => err.attribute === 'month' || err.attribute === 'year',
                        );
                        if (expDateError) {
                            setShowExpDateError(true);
                        }
                        setLoading(false);
                        const otherErrors: string[] = [];
                        setErrorMap(
                            errors.reduce((a, err) => {
                                const attr = err.attribute;
                                const [type, key] = err.key.split('.');
                                console.log(type);
                                // @ts-ignore
                                const msg = errorMessages?.[attr]?.[key];
                                if (msg) {
                                    a[attr] = msg;
                                    if (!['number', 'cvv', 'year', 'month'].includes(attr)) {
                                        otherErrors.push(msg);
                                    }
                                }
                                return a;
                            }, {}),
                        );
                        if (otherErrors.length > 0) {
                            enqueueSnackbar(otherErrors.join('\n'));
                        }
                    },
                );
            })
            .catch(() => {
                setLoading(false);
            });
    };

    const buttonElement = useMemo(() => {
        return (
            <PayButtonElement
                disabled={disable}
                size="large"
                variant="contained"
                fullWidth
                onClick={handleSubmit}
                loading={loading}
                showConfirmText={!hasPgGroup}
            />
        );
    }, [disable, loading, updateTimestamp, formValues, tip, amount]);

    const initHandler = () => {
        const pgJs: PaymentJs = new window.PaymentJs();
        if (pgJs) {
            if (!pgJs.initialized) {
                pgJs.init(config.publicIntegrationKey, 'vostro_number_div', 'vostro_cvv_div', (payment: any) => {
                    pgJs.setRequireCardHolder(false);
                    payment.setNumberStyle(inputStyle);
                    payment.setCvvStyle(inputStyle);

                    payment.numberOn('input', () => {
                        setErrorMap((prev) => ({ ...prev, number: '' }));
                    });

                    payment.cvvOn('input', () => {
                        setErrorMap((prev) => ({ ...prev, cvv: '' }));
                    });

                    payment.numberOn('focus', () => {
                        setIsCardNumberFocused(true);
                    });

                    payment.numberOn('blur', () => {
                        setIsCardNumberFocused(false);
                    });

                    payment.cvvOn('focus', () => {
                        setIsCvvFocused(true);
                    });

                    payment.cvvOn('blur', () => {
                        setIsCvvFocused(false);
                    });

                    payment.setNumberPlaceholder(t('Card Number'));
                    payment.setCvvPlaceholder(t('CVV'));

                    const frames = document.querySelectorAll('#vostro_number_div iframe, #vostro_cvv_div iframe');
                    frames.forEach((frame) => {
                        frame.setAttribute('style', 'border-radius: 8px; border: none');
                    });
                });
            }
            vostroRef.current = pgJs;
        }
    };

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.CardPay,
            icon: <CreditCard />,
            name: t('Card'),
            buttonElement,
        });
    }, [buttonElement]);

    const getHint = (elemName: string) => {
        return errorMap[elemName] || null;
    };

    const handleExpiryDateChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const { formatted } = expirationDateFormat(event.target.value, 2);
        setShowExpDateError(false);

        setFormValues((prev) => ({ ...prev, exp_date: formatted }));
        setErrorMap((prev) => ({ ...prev, month: '', year: '' }));
        console.log(event);
    };

    useEffect(() => {
        if (!vostroRef.current || !vostroRef.current?.initialized) {
            return;
        }
        vostroRef.current?.setNumberPlaceholder(t('Card Number'));
        vostroRef.current?.setCvvPlaceholder(t('CVV'));
        if (lang === 'ar') {
            vostroRef.current?.setNumberStyle({ ...inputStyle, direction: 'rtl' });
            vostroRef.current?.setCvvStyle({ ...inputStyle, direction: 'rtl' });
        } else {
            vostroRef.current?.setNumberStyle(inputStyle);
            vostroRef.current?.setCvvStyle(inputStyle);
        }
    }, [lang, t]);

    const scriptUrl = config.sandbox
        ? 'https://test-gateway.tillpayments.com/js/integrated/payment.1.3.min.js'
        : 'https://gateway.tillpayments.com/js/integrated/payment.1.3.min.js';

    return (
        <>
            <Scripts data-main="payment-js" src={scriptUrl} onReady={initHandler} />
            <PaymentWrapper
                hasPgGroup={hasPgGroup}
                visible={pgSelectedId === gatewayId && pgSelectedElem === PaymentElementEnum.CardPay}
            >
                <Box className={styles.container}>
                    <Box component="form" id="vostro_payment_form" method="POST" className={styles.formContainer}>
                        <Box className={styles.numberDivContainer}>
                            <Box className={styles.numberDivInnerContainer}>
                                <div className={styles.numberDivInput}>
                                    <div
                                        id="vostro_number_div"
                                        className={classNames(styles.externalInput, {
                                            [styles.focused]: isCardNumberFocused,
                                            [styles.errorInput]: errorMap.number,
                                        })}
                                    />
                                    <CardIcon className={classNames({ [styles.rtl]: lang === 'ar' })} />
                                </div>
                                <FormHelperText className={styles.error}>{getHint('number')}</FormHelperText>
                            </Box>
                        </Box>
                        <Box className={styles.cvvDivContainer}>
                            <Box className={styles.cvvDivInnerContainer}>
                                <Box className={styles.cvvDiv}>
                                    <div className={styles.cvvDivInput}>
                                        <div
                                            id="vostro_cvv_div"
                                            className={classNames(styles.externalInput, {
                                                [styles.focused]: isCvvFocused,
                                            })}
                                        />
                                        <CVVIcon className={classNames({ [styles.rtl]: lang === 'ar' })} />
                                    </div>
                                    <FormHelperText className={styles.error}>{getHint('cvv')}</FormHelperText>
                                </Box>
                            </Box>
                            <Box className={styles.expDateContainer}>
                                <Box className={styles.expDateDiv}>
                                    <TextField
                                        value={formValues.exp_date}
                                        fullWidth
                                        type="text"
                                        id="vostro_exp_date"
                                        name="exp_date"
                                        className={styles.internalInput}
                                        placeholder={t('MM/YY')}
                                        onChange={handleExpiryDateChange}
                                    />
                                    {showExpDateError && (
                                        <FormHelperText className={styles.error}>
                                            {getHint('month') || getHint('year')}
                                        </FormHelperText>
                                    )}
                                </Box>
                            </Box>
                        </Box>
                    </Box>
                </Box>
                {enableButton && !hasPgGroup && <div className={styles.buttonContainer}>{buttonElement}</div>}
            </PaymentWrapper>
        </>
    );
};

export default CardElement;
