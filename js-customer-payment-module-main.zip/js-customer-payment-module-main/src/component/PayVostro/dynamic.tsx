import React, { useEffect, useState } from 'react';
import { isSafari } from '@clubpay/customer-common-module/src/utility/mobile_check';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { applePayJsAvailable } from '../ApplePayButton/utils/handlers';
import PayVostroCard from './card';
import PaymentWrapper from '../PaymentWrapper';
import PayVostroApple from './applepay';
import PayVostroGoogle from './googlepay';
import { IVostroGateway } from '../../repository/type/paymentGateway';

import styles from './index.module.scss';

export interface IProps extends IPGProps {
    config: IVostroGateway;
}

export default function PayVostro({
    name,
    diningSessionID,
    sessionId,
    jwt,
    url,
    amount,
    tip,
    currencyPrecision,
    config,
    disable,
    enableButton,
    gatewayId,
    vendor,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onPending,
    onOverlayClick,
    onIndicator,
    onLoad,
    onPgRegister,
    pgSelectedElem,
    pgSelectedId,
    updateTimestamp,
    onTraceStart,
    isPgElemVisible,
    onTraceClose,
}: IProps) {
    const [hasApplePay, setHasApplePay] = useState(false);
    const [hasGooglePay, setHasGooglePay] = useState(false);
    const { hasPgGroup } = vendor.paymentGatewayList;

    useEffect(() => {
        applePayJsAvailable().then((enable) => {
            setHasApplePay(enable);
        });

        setHasGooglePay(!isSafari());
    }, [url.cc, url.slug, url.id]);

    return (
        <div className={styles.form}>
            {config?.hideApplePay !== true && hasApplePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.ApplePay)}>
                    <PayVostroApple
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        vendor={vendor}
                        updateTimestamp={updateTimestamp}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        onTraceStart={onTraceStart}
                        hasPgGroup={hasPgGroup}
                        onTraceClose={onTraceClose}
                    />
                </PaymentWrapper>
            )}
            {config?.hideGooglePay !== true && hasGooglePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.GooglePay)}>
                    <PayVostroGoogle
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        vendor={vendor}
                        updateTimestamp={updateTimestamp}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        onTraceStart={onTraceStart}
                        hasPgGroup={hasPgGroup}
                        onTraceClose={onTraceClose}
                    />
                </PaymentWrapper>
            )}
            {config?.hideCardPay !== true && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}>
                    <PayVostroCard
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        vendor={vendor}
                        enableButton={enableButton}
                        updateTimestamp={updateTimestamp}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onOverlayClick={onOverlayClick}
                        onIndicator={onIndicator}
                        onLoad={onLoad}
                        onPgRegister={onPgRegister}
                        onTraceStart={onTraceStart}
                        pgSelectedId={pgSelectedId}
                        pgSelectedElem={pgSelectedElem}
                        onTraceClose={onTraceClose}
                    />
                </PaymentWrapper>
            )}
        </div>
    );
}
