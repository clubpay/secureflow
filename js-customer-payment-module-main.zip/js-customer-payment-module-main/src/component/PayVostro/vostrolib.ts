import { ICardModel } from './card';

export declare class PaymentJs {
    static ref: string;

    static transactionToken: string;

    constructor();

    initialized: boolean;

    init(apiKey: string, numberDivId: string, cvvDivId: string, callback: (payment: PaymentJs) => void): void;

    tokenize(data: ICardModel, success: (token: string, cardData: any) => void, error: (errors: any[]) => void): void;

    setNumberStyle(style: any): void;

    setCvvStyle(style: any): void;

    numberOn(event: string, callback: (data: any) => void): void;

    cvvOn(event: string, callback: (data: any) => void): void;

    setNumberPlaceholder(title: string): void;

    setCvvPlaceholder(title: string): void;

    setRequireCardHolder(enable: boolean): void;
}

declare global {
    interface Window {
        PaymentJs: typeof PaymentJs;
    }
}

export {};
