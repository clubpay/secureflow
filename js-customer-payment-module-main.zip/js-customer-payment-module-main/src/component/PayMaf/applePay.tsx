import { useEffect, useMemo, useRef, useState } from 'react';
import { MafpayApplePayButton } from '@qlub-dev/maf-weblib-react';
import { IPGCallbackRes, useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { Apple } from '@mui/icons-material';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { Skeleton } from '@mui/material';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import PaymentTerms from '@clubpay/customer-common-module/src/component/PaymentTerms';
import { ShippingContact } from '../../repository/type/maf';
import { usePaymentError } from '../../hook/paymentError';
import PaymentAPIManager from '../../repository';

import styles from './index.module.scss';

export interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks {
    refId: string;
    onRefreshRef: () => void;
    hasPgGroup: boolean;
    onLoading: (loading: boolean) => void;
    onLock: (loading: boolean) => void;
}

const AppleButton = ({
    currencyPrecision,
    diningSessionID,
    sessionId,
    amount,
    tip,
    name,
    gatewayId,
    vendor,
    refId,
    config,
    hasPgGroup,
    onBeforePayment,
    onUnlockPayment,
    onRefreshRef,
    onPgRegister,
    onTraceStart,
    onPgUnregister,
    onTraceClose,
    onLoading,
    onLock,
}: IProps) => {
    const { lang } = useQlubRouter();
    const [loading, setLoading] = useState(false);
    const [lock, setLock] = useState(false);
    const [refreshCount, setRefreshCount] = useState(0);
    const [applePayToken, setApplePayToken] = useState<string>('');
    const { showError } = usePaymentError();
    const { getCallbackUrl } = useConfirmCallback();
    const totalAmount = sumAmounts(currencyPrecision, amount, tip);
    const buttonRef = useRef<HTMLMafpayApplePayButtonElement | null>(null);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const shippingContactRef = useRef<ShippingContact | undefined>(undefined);
    const [showSkeleton, setShowSkeleton] = useState(false);
    const redirection = useRef<IPGCallbackRes>({
        fail: '',
        success: '',
        pending: '',
    });

    useEffect(() => {
        onLoading(loading);
    }, [loading]);

    useEffect(() => {
        onLock(lock);
    }, [lock]);

    const getApplePayToken = () => {
        setLoading(true);
        setShowSkeleton(true);

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.CardPay,
                refId,
            },
        });

        redirection.current = getCallbackUrl({
            ref: refId,
            method: name,
            paymentElement: PaymentElementEnum.ApplePay,
            dsi: diningSessionID,
            amount: totalAmount,
            currencySymbol: vendor.country.currencySymbol,
            traceId: traceStart?.traceId,
            lang,
        });

        PaymentAPIManager.getInstance()
            .generateTokenMaf({
                diningSessionID,
                cardToken: '',
                failureURL: redirection.current.fail,
                customerEmail: 'qlub@qlub.io',
                gatewayID: gatewayId,
                reference: refId,
                successURL: redirection.current.success,
                id: sessionId,
                tipAmount: tip.toFixed(currencyPrecision || 0),
            })
            .then((res) => {
                if (res.data.responseCode === '000' && res.data.responseMessage === 'Success') {
                    onPgRegister?.({
                        pgId: gatewayId,
                        elem: PaymentElementEnum.ApplePay,
                        name: 'Apple Pay',
                        placement: 'bottom',
                        icon: <Apple />,
                    });
                    setApplePayToken(res.data.token);
                }
            })
            .catch((err) => {
                const errData = err?.response?.data || err || {};

                if (errData.code === 412 && errData.items === 'PAYMENT_REFERENCE_CONFLICTS_TRANSACTION') {
                    onRefreshRef();
                    showError(errData || {});
                } else if (refreshCount < 3) {
                    setRefreshCount((o) => o + 1);
                    onRefreshRef();
                }
                onUnlockPayment();
            })
            .finally(() => {
                setLoading(false);
            });
    };

    useEffect(() => {
        if (!refId) {
            return;
        }
        getApplePayToken();
    }, [refId]);

    const checkBeforePaymentHandler = async () => {
        setLock(true);
        // get onBeforePayments value and return
        return onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.ApplePay,
            tip,
        })
            .then((res) => {
                if (!res) {
                    setLock(false);
                }
                return res;
            })
            .catch((err) => {
                setLock(false);
                throw err;
            });
    };

    const completeApplePayHandler = () => {
        PaymentAPIManager.getInstance()
            .verifyMaf({
                diningSessionID,
                reference: refId,
                gatewayID: gatewayId,
                id: sessionId,
                shippingContact: shippingContactRef.current,
            })
            .then((res) => {
                if (res.data.success) {
                    window.location.assign(redirection.current.pending);
                } else {
                    onTraceClose?.({
                        error: res.data,
                        location: 'verifyMaf',
                        traceRef,
                        traceStart,
                    });

                    window.location.assign(redirection.current.fail);
                }
            })
            .catch((err) => {
                const errData = err?.response?.data || err || {};
                showError(errData || err?.message);
            })
            .finally(() => {
                setLock(false);
            });
    };

    const applePayErrorHandler = (e: any) => {
        setLock(false);
        onTraceClose?.({
            error: e.detail || e,
            errorString: JSON.stringify(e.detail || e),
            location: 'applePayErrorHandler',
            traceRef,
            traceStart,
        });

        console.log(JSON.stringify(e), 'APPLEPAYERROR');

        onPgUnregister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.ApplePay,
        });
    };

    return (
        <>
            {hasPgGroup && <PaymentTerms />}
            {showSkeleton && <Skeleton height={76} width="100%" />}
            {applePayToken && !loading && (
                <div data-area="submit">
                    <MafpayApplePayButton
                        ref={buttonRef}
                        style={{
                            width: '100%',
                            marginTop: hasPgGroup ? '16px' : '0',
                            height: '60px',
                            display: showSkeleton ? 'none' : 'block',
                        }}
                        buttonType="pay"
                        beforePayment={checkBeforePaymentHandler}
                        qlubConfig={{
                            applePayBillingDetails: config?.applePayBillingDetails,
                            applePayShippingDetails: config?.applePayShippingDetails,
                            experimental: {
                                applepaySDKVersion: 5,
                            },
                        }}
                        token={config?.sandbox ? 'sandbox' : applePayToken}
                        className={styles.applePayButton}
                        id="appleButton"
                        onOnPaymentAuthorized={(e) => {
                            const shippingContactTemp = e.detail.shippingContact;
                            shippingContactRef.current = shippingContactTemp;
                            console.log(e.detail.shippingContact, 'shippingContact');
                            console.log(e.detail, 'e.detail');
                        }}
                        checkoutLanguage={lang as any}
                        onApplePayCompleted={() => completeApplePayHandler()}
                        onApplePayError={applePayErrorHandler}
                        onApplePayClosed={(e) => {
                            setLock(false);
                            onUnlockPayment();
                            onTraceClose?.({
                                error: e,
                                location: 'onApplePayClosed',
                                traceRef,
                                traceStart,
                            });
                        }}
                        onLoadingEvent={(event) => {
                            console.log(event.detail);
                            if (!event.detail.isLoading) {
                                const el = document.getElementById('appleButton');
                                if (el && el.shadowRoot && !loading && applePayToken) {
                                    setShowSkeleton(false);
                                    const firstChild = el.shadowRoot.children[0];
                                    if (firstChild) {
                                        firstChild.innerHTML +=
                                            ' apple-pay-button {--apple-pay-button-width: 100% !important; }';
                                    }
                                }
                            } else {
                                setShowSkeleton(true);
                            }
                        }}
                    />
                </div>
            )}
        </>
    );
};

export default AppleButton;
