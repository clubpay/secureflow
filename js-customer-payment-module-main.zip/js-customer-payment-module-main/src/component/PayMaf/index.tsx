import dynamic from 'next/dynamic';
import { Box, CircularProgress } from '@mui/material';
import { IProps } from './dynamic';

const PayMaf = dynamic<IProps>(() => import('./dynamic'), {
    loading: () => (
        <Box
            sx={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
            }}
        >
            <CircularProgress size={24} />
        </Box>
    ),
    ssr: false,
});

export default PayMaf;
