/*
 * Creation Time: {today.year} - {today.month} - {today.day}
 */

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Grid } from '@mui/material';
import {
    MafpayCardCvc,
    MafpayCardExpiry,
    MafpayCardNumber,
    MafpayCardSubmit,
    MafpayThreedsComponent,
} from '@qlub-dev/maf-weblib-react';
import { CreditCard, VerifiedUserOutlined } from '@mui/icons-material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import PaymentTerms from '@clubpay/customer-common-module/src/component/PaymentTerms';
import { PayMafSubmitEvent } from './types';
import PayButtonElement from '../PayButtonElement';
import PaymentAPIManager from '../../repository';
import { usePaymentError } from '../../hook/paymentError';
import { IMafGatewayConfig } from '../../repository/type/paymentGateway';

import styles from './index.module.scss';

export interface ICardFormProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks {
    config: IMafGatewayConfig;
    refId: string;
    onRefreshRef: () => void;
    onLoading: (loading: boolean) => void;
}

const CardForm = ({
    diningSessionID,
    sessionId,
    amount,
    tip,
    currencyPrecision,
    disable,
    gatewayId,
    config,
    vendor,
    refId,
    updateTimestamp,
    name,
    onBeforePayment,
    onRefreshRef,
    onPgRegister,
    onDone,
    onFail,
    onPending,
    onTraceStart,
    onTraceClose,
    onLoading,
}: ICardFormProps) => {
    const { lang } = useQlubRouter();
    const { t } = useTranslation('common');
    const { getCallbackUrl } = useConfirmCallback();
    const [loading, setLoading] = useState(false);
    const [threeDsAuthId, setThreeDsAuthId] = useState('');
    const { showError } = usePaymentError();
    const formRef = React.useRef<HTMLFormElement>(null);
    const buttonRef = React.useRef<HTMLMafpayCardSubmitElement | null>(null);
    const { hasPgGroup } = vendor.paymentGatewayList;
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    const newRef = `${refId}c`;

    const totalAmount = sumAmounts(currencyPrecision, amount, tip);
    const mafURL = config?.sandbox
        ? 'https://payment.sandbox.mafpayments.com/tokenize'
        : 'https://payment.mafpayments.com/tokenize';
    const pgConfig = {
        tokenizev2: 'true',
        merchantId: config?.merchantID,
        apiKey: config?.apiKey,
        command: 'tokenize',
    };

    const returnUrl = getCallbackUrl({
        ref: newRef,
        method: name,
        paymentElement: PaymentElementEnum.CardPay,
        dsi: diningSessionID,
        amount: totalAmount,
        currencySymbol: vendor.country.currencySymbol,
        traceId: traceStart?.traceId,
        lang,
    });

    useEffect(() => {
        onLoading(loading);
    }, [loading]);

    const doneSubmitHandler = (event: CustomEvent<PayMafSubmitEvent>) => {
        if (threeDsAuthId && loading) {
            return;
        }

        if (event.detail.responseCode !== '000' && event.detail.responseCode !== '700') {
            showError(event.detail.responseMessage || '');
            setLoading(false);
            return;
        }

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.CardPay,
                refId: newRef,
            },
        });

        onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.CardPay,
            tip,
        })
            .then((ok) => {
                if (!ok) {
                    setLoading(false);
                    return;
                }

                const successURL = returnUrl.success;
                const failureURL = returnUrl.fail;

                PaymentAPIManager.getInstance()
                    .payMafPayment({
                        diningSessionID,
                        id: sessionId,
                        reference: newRef,
                        cardToken: event.detail.cardToken,
                        customerEmail: '',
                        failureURL,
                        successURL,
                        gatewayID: gatewayId,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                    })
                    .then((res) => {
                        if (res.data.responseCode === '000' || res.data.responseCode === '700') {
                            if (res.data.threeDsAuthId) {
                                setThreeDsAuthId(res.data.threeDsAuthId);
                            } else {
                                processCompleteHandler({
                                    detail: {
                                        responseCode: res.data.responseCode,
                                    },
                                } as CustomEvent);
                            }
                        } else {
                            showError();
                            onRefreshRef();
                            setLoading(false);
                        }
                    })
                    .catch((err) => {
                        const errData = err?.response?.data || err || {};
                        showError(errData);
                        onRefreshRef();
                    });
            })
            .catch(() => {
                setLoading(false);
            });
    };

    const processCompleteHandler = (event: CustomEvent) => {
        switch (event.detail.responseCode) {
            case '000':
                onDone?.({
                    paymentElement: PaymentElementEnum.CardPay,
                    refId: newRef,
                });

                break;

            case '700':
                onPending?.({
                    paymentElement: PaymentElementEnum.CardPay,
                    refId: newRef,
                });

                break;

            case '600':
            case '602':
            default:
                onTraceClose?.({
                    error: event,
                    location: 'paymentCheckoutPayByToken',
                    traceRef,
                    traceStart,
                });

                onFail?.({
                    paymentElement: PaymentElementEnum.CardPay,
                    refId: newRef,
                    traceId: traceStart?.traceId,
                });

                break;
        }
    };

    // the mafs button should be in the form, that's why I need to use the ref
    const handlePay = () => {
        if (formRef.current) {
            buttonRef.current?.querySelector('button')?.click();
        }
    };

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.CardPay,
            name: t('Card'),
            icon: <CreditCard />,
            buttonElement: (
                <PayButtonElement
                    disabled={disable || loading}
                    size="large"
                    variant="contained"
                    fullWidth
                    onClick={handlePay}
                    loading={loading}
                />
            ),
        });
    }, [tip, disable, loading, updateTimestamp]);

    useEffect(() => {
        document.querySelector('.mafpay-default-card-submit')?.classList.toggle('disabled', disable || loading);
        if (document.querySelector('.mafpay-default-card-submit')) {
            // @ts-ignore
            document.querySelector('.mafpay-default-card-submit').innerHTML = t('Pay Now');
        }
    }, [disable, loading, lang]);

    const tokenizationCompleteHandler = (event: CustomEvent) => {
        console.log(event);
    };

    const dir = document.querySelector('body')?.getAttribute('dir');

    return (
        <form method="POST" className={styles.form} ref={formRef} action={mafURL}>
            <div className={styles.paymentForm}>
                {Object.keys(pgConfig).map((key) => (
                    <input key={key} type="hidden" name={key} value={pgConfig[key as keyof typeof pgConfig]} />
                ))}
                <Grid container spacing={1}>
                    <Grid item xs={12}>
                        <label htmlFor="cardNumber">{t('Card Number')}</label>
                        <MafpayCardNumber className={dir === 'rtl' ? styles.cardNumber : undefined} dir="ltr" />
                    </Grid>
                    <Grid item xs={6}>
                        <label htmlFor="cardExpiry">{t('Validity')}</label>
                        <MafpayCardExpiry defaultStyle />
                    </Grid>
                    <Grid item xs={6}>
                        <label htmlFor="cardCvc">{t('CVV')}</label>
                        <MafpayCardCvc masked={false} defaultStyle />
                    </Grid>
                </Grid>
            </div>
            <div className={styles.secureWrapper}>
                <div className={styles.secureIcon}>
                    <VerifiedUserOutlined />
                </div>
                <div className={styles.secureText}>{t('100% Secure payments powered by Qlub_')}</div>
            </div>
            {!hasPgGroup && <PaymentTerms />}

            <MafpayCardSubmit
                style={{ display: hasPgGroup ? 'none' : 'block' }}
                defaultLoading={disable || loading}
                label={t('Pay Now')}
                defaultStyle
                threeDsAuthId={threeDsAuthId}
                onTokenizationComplete={tokenizationCompleteHandler}
                onDoneSubmit={doneSubmitHandler}
                ref={buttonRef}
                onClick={() => setLoading(true)}
                onError={() => setLoading(false)}
            />

            {threeDsAuthId && (
                <MafpayThreedsComponent onProcessComplete={processCompleteHandler} threedsauthid={threeDsAuthId} />
            )}
        </form>
    );
};

export default CardForm;
