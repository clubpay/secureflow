/*
 * Creation Time: {today.year} - {today.month} - {today.day}
 */

export interface PayMafSubmitEvent {
    responseMessage: string;
    responseCode: string;
    cardToken: string;
    cardBin: string;
    status: string;
    cardVerificationRef: string;
    threeDsAuthId: string;
    threeDsAccessToken: string;
    threeDsVersion: string;
    verifyCard: string;
    merchantId: string;
    apiKey: string;
    command: string;
    expiryMonth: string;
    expiryYear: string;
    cardBrand: string;
    cardType: string;
    cardMaskedNumber: string;
}
