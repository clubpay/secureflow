/*
 * Creation Time: {today.year} - {today.month} - {today.day}
 */

import React, { useEffect, useRef, useState } from 'react';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { isSafari } from '@clubpay/customer-common-module/src/utility/mobile_check';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { defineCustomElements } from '@qlub-dev/weblib';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import Loading from '@qlub-dev/qlub-kit/dist/components/Loading';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IMafGatewayConfig } from '../../repository/type/paymentGateway';
import PaymentWrapper from '../PaymentWrapper';
import GoogleButton from './googlePay';
import CardForm from './cardForm';
import MafAppleButton from './applePay';
import { applePayJsAvailable } from '../ApplePayButton/utils/handlers';

import '@qlub-dev/weblib/dist/mafpay/mafpay.css';
import styles from './index.module.scss';

export interface IProps extends IPGProps {
    config: IMafGatewayConfig;
}

const PayMaf = ({
    name,
    diningSessionID,
    sessionId,
    jwt,
    url,
    amount,
    tip,
    currencyPrecision,
    config,
    gatewayId,
    vendor,
    disable,
    enableButton,
    updateTimestamp,
    onOverlayClick,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onIndicator,
    onLoad,
    onPending,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onPgUnregister,
    onTraceClose,
    onLoading,
}: IProps) => {
    const { lang } = useQlubRouter();
    const [refId, setRefId] = useState<string>(getRandomString());
    const [hasApplePay, setHasApplePay] = useState(false);
    const [hasGooglePay, setHasGooglePay] = useState(false);
    const [loadingList, setLoadingList] = useState<string[]>([]);
    const [lock, setLock] = useState(false);
    const lockRef = useRef(false);
    const hasUpdateInLoading = useRef(false);
    const { hasPgGroup } = vendor.paymentGatewayList;
    const { login, isLogin } = useAuth();

    useEffect(() => {
        if (!isLogin) {
            login({ guest: true });
        }
    }, [isLogin]);

    useEffect(() => {
        window.MafPay = {
            ...window.MafPay,
            lang: lang === 'ar' ? 'ar' : 'en',
            defaultStyle: true,
            env: config?.sandbox ? 'sandbox' : 'production',
        };
    }, []);

    useEffect(() => {
        // maf just supports en and ar
        window.MafPay.setLanguage(lang === 'ar' ? 'ar' : 'en');
        // custom elements are not updating when parent component is updated

        defineCustomElements();
    }, [lang]);

    useEffect(() => {
        onLoading?.(loadingList.length > 0);
    }, [loadingList]);

    const refreshRefHandler = () => {
        if (loadingList.length > 0) {
            hasUpdateInLoading.current = true;
            return;
        }

        if (lock || lockRef.current) {
            return;
        }

        setRefId(getRandomString());
    };

    const totalAmount = sumAmounts(currencyPrecision, amount, tip);

    useEffect(() => {
        // in the case total amount is zero, when someone else paid the bill and we
        // get the live update from socket
        if (!totalAmount) {
            return;
        }

        refreshRefHandler();
    }, [totalAmount]);

    useEffect(() => {
        applePayJsAvailable().then((enable) => {
            setHasApplePay(enable);
        });

        if (!isSafari()) {
            setHasGooglePay(true);
        }
    }, [url.cc, url.slug, url.id]);

    const loadingChangeHandler = (elem: string) => (val: boolean) => {
        const clone = [...loadingList];
        const idx = clone.indexOf(elem);
        if (val) {
            if (idx === -1) {
                clone.push(elem);
            }
        } else if (idx > -1) {
            clone.splice(idx, 1);
        }
        setLoadingList(clone);
        if (hasUpdateInLoading.current && !val) {
            hasUpdateInLoading.current = false;
            refreshRefHandler();
        }
    };

    const lockChangeHandler = (val: boolean) => {
        setLock(val);
        lockRef.current = val;
    };

    return (
        <div className={styles.mafpayWrapper}>
            {Boolean(hasPgGroup && loadingList.length > 0 && isPgElemVisible?.(PaymentElementEnum.CardPay)) && (
                <Loading color="outlined" />
            )}
            {config?.hideApplePay !== true && hasApplePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.ApplePay)}>
                    <MafAppleButton
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        vendor={vendor}
                        currencyPrecision={currencyPrecision}
                        amount={amount}
                        tip={tip}
                        refId={refId}
                        gatewayId={gatewayId}
                        disable={disable}
                        onRefreshRef={refreshRefHandler}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        config={config}
                        onPgRegister={onPgRegister}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        onPgUnregister={onPgUnregister}
                        hasPgGroup={hasPgGroup}
                        onTraceClose={onTraceClose}
                        onLoading={loadingChangeHandler('apple')}
                        onLock={lockChangeHandler}
                    />
                </PaymentWrapper>
            )}
            {config?.hideGooglePay !== true && hasGooglePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.GooglePay)}>
                    <GoogleButton
                        hasPgGroup={hasPgGroup}
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        currencyPrecision={currencyPrecision}
                        amount={amount}
                        tip={tip}
                        refId={refId}
                        gatewayId={gatewayId}
                        disable={disable}
                        config={config}
                        vendor={vendor}
                        onRefreshRef={refreshRefHandler}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        onIndicator={onIndicator}
                        onLoad={onLoad}
                        enableButton={enableButton}
                        onOverlayClick={onOverlayClick}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        onPgUnregister={onPgUnregister}
                        onTraceClose={onTraceClose}
                        onLoading={loadingChangeHandler('google')}
                        onLock={lockChangeHandler}
                    />
                </PaymentWrapper>
            )}
            {config?.hideCardPay !== true && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}>
                    <CardForm
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        currencyPrecision={currencyPrecision}
                        disable={disable}
                        config={config}
                        vendor={vendor}
                        amount={amount}
                        tip={tip}
                        refId={refId}
                        gatewayId={gatewayId}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onRefreshRef={refreshRefHandler}
                        onPgRegister={onPgRegister}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        onTraceClose={onTraceClose}
                        onLoading={loadingChangeHandler('card')}
                    />
                </PaymentWrapper>
            )}
            {lock && <div className={styles.lockOverlay} />}
        </div>
    );
};

export default PayMaf;
