/*
 * Creation Time: {today.year} - {today.month} - {today.day}
 */

declare global {
    interface Window {
        MafPay: {
            setLanguage: (lang: string) => void;
            lang: string;
            defaultStyle: boolean;
            env: 'sandbox' | 'production';
        };
    }
}

export {};
