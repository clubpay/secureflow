import { useEffect, useMemo, useRef, useState } from 'react';
import { MafpayGooglePayButton } from '@qlub-dev/maf-weblib-react';
import { IPGCallbackRes, useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import Loading from '@qlub-dev/qlub-kit/dist/components/Loading';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import {
    IPGBaseProps,
    IPGHooks,
    IPGProps,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { GooglePay } from '@clubpay/customer-common-module/src/component/SVG';
import PaymentTerms from '@clubpay/customer-common-module/src/component/PaymentTerms';
import { IMafGatewayConfig } from '../../repository/type/paymentGateway';
import { usePaymentError } from '../../hook/paymentError';
import PaymentAPIManager from '../../repository';

export interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks, IPGProps {
    refId: string;
    config: IMafGatewayConfig;
    hasPgGroup: boolean;
    onRefreshRef: () => void;
    onLoading: (loading: boolean) => void;
    onLock: (loading: boolean) => void;
}

const GoogleButton = ({
    currencyPrecision,
    diningSessionID,
    sessionId,
    amount,
    tip,
    gatewayId,
    refId,
    config,
    vendor,
    name,
    hasPgGroup,
    onBeforePayment,
    onUnlockPayment,
    onRefreshRef,
    onPending,
    onFail,
    onPgRegister,
    onTraceStart,
    onPgUnregister,
    onTraceClose,
    onLoading,
    onLock,
}: IProps) => {
    const { lang } = useQlubRouter();
    const [loading, setLoading] = useState(false);
    const [lock, setLock] = useState(false);
    const [googlePayToken, setGooglePayToken] = useState<string>('');
    const { showError } = usePaymentError();
    const { getCallbackUrl } = useConfirmCallback();
    const totalAmount = sumAmounts(currencyPrecision, amount, tip);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const redirection = useRef<IPGCallbackRes>({
        fail: '',
        success: '',
        pending: '',
    });

    useEffect(() => {
        onLoading(loading);
    }, [loading]);

    useEffect(() => {
        onLock(lock);
    }, [lock]);

    const getGooglePayToken = () => {
        if (loading) {
            return;
        }
        setLoading(true);

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.GooglePay,
                refId,
            },
        });

        redirection.current = getCallbackUrl({
            ref: refId,
            method: name,
            paymentElement: PaymentElementEnum.GooglePay,
            dsi: diningSessionID,
            amount: totalAmount,
            currencySymbol: vendor.country.currencySymbol,
            traceId: traceStart?.traceId,
            lang,
        });

        PaymentAPIManager.getInstance()
            .generateTokenMaf({
                diningSessionID,
                cardToken: '',
                failureURL: redirection.current.fail,
                customerEmail: 'qlub@qlub.io',
                gatewayID: gatewayId,
                reference: refId,
                successURL: redirection.current.success,
                id: sessionId,
                tipAmount: tip.toFixed(currencyPrecision || 0),
            })
            .then((res) => {
                if (res.data.responseCode === '000' && res.data.responseMessage === 'Success') {
                    setGooglePayToken(res.data.token);
                    onPgRegister?.({
                        pgId: gatewayId,
                        elem: PaymentElementEnum.GooglePay,
                        name: 'Google Pay',
                        icon: <GooglePay />,
                        placement: 'bottom',
                    });
                }
            })
            .catch((err) => {
                const errData = err?.response?.data || err || {};

                if (errData.code === 412 && errData.items === 'PAYMENT_REFERENCE_CONFLICTS_TRANSACTION') {
                    onRefreshRef();
                    showError(errData || {});
                }
            })
            .finally(() => {
                setLoading(false);
            });
    };

    useEffect(() => {
        if (!refId) {
            return;
        }

        getGooglePayToken();
    }, [refId]);

    const completeGooglePayHandler = () => {
        if (loading) {
            return;
        }
        setLoading(true);

        PaymentAPIManager.getInstance()
            .verifyMaf({
                diningSessionID,
                reference: refId,
                gatewayID: gatewayId,
                id: sessionId,
            })
            .then((res) => {
                if (res.data.success) {
                    onPending({
                        paymentElement: PaymentElementEnum.GooglePay,
                        refId,
                    });
                } else {
                    onTraceClose?.({
                        error: res,
                        location: 'paymentCheckoutPayByToken',
                        traceRef,
                        traceStart,
                    });

                    onFail({
                        paymentElement: PaymentElementEnum.GooglePay,
                        refId,
                        traceId: traceStart?.traceId,
                    });
                }
            })
            .catch((err) => {
                const errData = err?.response?.data || err || {};
                showError(errData || err?.message);
                onUnlockPayment();
            })
            .finally(() => {
                setLoading(false);
            });
    };

    const errorHandler = (e: any) => {
        setLock(false);
        console.log({ mafError: e });
        setGooglePayToken('');
    };

    const googlePayErrorHandler = (e: any) => {
        setLock(false);
        console.log({ googlePayError: e });

        onTraceClose?.({
            error: e,
            location: 'googlePayErrorHandler',
            traceRef,
            traceStart,
        });

        onPgUnregister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.GooglePay,
        });
    };

    // Please don't refactor without running it.
    const setButtonStyle = () => {
        const iframe = document.querySelector('.mafpay-google-pay-iframe') as HTMLIFrameElement;
        if (!iframe) {
            return;
        }

        const innerDoc = iframe.contentDocument ? iframe.contentDocument : iframe.contentWindow?.document;
        if (!innerDoc) {
            return;
        }

        const cssLink = document.createElement('style');

        cssLink.innerHTML = `
          button.gpay-card-info-container {
          width: 100% !important;
          border-radius: 40px;
          min-height: 40px !important;
          height: 40px !important;
        }`;

        innerDoc.head.appendChild(cssLink);
    };

    const checkBeforePaymentHandler = async () => {
        setLock(true);
        return onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.GooglePay,
            tip,
        })
            .then((res) => {
                if (!res) {
                    setLock(false);
                }
                return res;
            })
            .catch((err) => {
                setLock(false);
                throw err;
            });
    };

    if (loading) {
        return <Loading color="outlined" />;
    }

    if (googlePayToken && !loading) {
        return (
            <>
                {hasPgGroup && <PaymentTerms />}
                <div data-area="submit">
                    <MafpayGooglePayButton
                        beforePayment={checkBeforePaymentHandler}
                        token={googlePayToken}
                        style={{ width: '100%', marginTop: hasPgGroup ? '16px' : '0' }}
                        merchantId={config?.googleMerchantId || 'BCR2DN4TYD76RI2J'}
                        id="google-pay-button"
                        // buttonType="pay"
                        enableButtonLoading
                        enableProcessingLoading
                        onLoadingEvent={(event) => {
                            if (!event.detail.isLoading) {
                                setButtonStyle();
                            }
                        }}
                        lang={lang as any}
                        onError={errorHandler}
                        onGooglePayCompleted={completeGooglePayHandler}
                        onGooglePayError={googlePayErrorHandler}
                        onGooglePayClose={(e) => {
                            setLock(false);
                            onUnlockPayment();
                            onTraceClose?.({
                                error: e,
                                location: 'onGooglePayClose',
                                traceRef,
                                traceStart,
                            });
                        }}
                    />
                </div>
            </>
        );
    }

    return null;
};

export default GoogleButton;
