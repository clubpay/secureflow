/*
 * Creation Time: March 16 - 2023
 * Created By: yasincelebi
 * Name: useTappTranslation.tsx
 * Copyright 2023 customer-web-app
 */

import { useMemo } from 'react';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { IErrMap } from './types';

const useTappTranslation = () => {
    const { t } = useTranslation('common');
    const errMap: IErrMap = useMemo(
        () => ({
            card_holder_required: t('Cardholder Name is required'),
            card_number_required: t('Card Number is required'),
            error_card_holder_short: t('Cardholder Name is too short. Minimum 3 characters'),
            error_currency_not_supported: t('Currency is not supported'),
            error_invalid_card: t('Invalid Card Number'),
            error_invalid_card_characters: t('Invalid Card Number'),
            error_invalid_expiry_characters: t('Invalid Expiry Date'),
            error_invalid_cvv_characters: t('Invalid CVV'),
            expiry_date_past: t("Your card's expiration date is in the past."),
            expiry_date_required: t('Expiry Date is required'),
            expiry_month_required: t('Expiry Month is required'),
            expiry_year_required: t('Expiry Year is required'),
        }),
        [t],
    );

    const labels = useMemo(
        () => ({
            cardNumber: t('Card Number'),
            expirationDate: t('MM/YY'),
            cvv: t('CVV'),
            cardHolder: t('Cardholder Name'),
            actionButton: t('Pay'),
        }),
        [t],
    );

    return { errMap, labels };
};

export default useTappTranslation;
