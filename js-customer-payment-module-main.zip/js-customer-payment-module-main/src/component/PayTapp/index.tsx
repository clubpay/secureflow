/*
 * Creation Time: March 14 - 2023
 * Created By: yasincelebi
 * Name: index.tsx
 * Copyright 2023 customer-web-app
 */

import dynamic from 'next/dynamic';
import { Box, CircularProgress } from '@mui/material';
// TODO: Remove any
const PayTapp = dynamic<any>(() => import('./dynamic'), {
    loading: () => (
        <Box
            sx={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
            }}
        >
            <CircularProgress size={24} />
        </Box>
    ),
    ssr: false,
});

export default PayTapp;
