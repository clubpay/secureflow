/*
 * Creation Time: March 16 - 2023
 * Created By: yasincelebi
 * Name: card.tsx
 * Copyright 2023 customer-web-app
 */

import Head from 'next/head';
import Scripts from 'next/script';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { Box, useTheme } from '@mui/material';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { CreditCard } from '@mui/icons-material';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { isObject } from 'lodash';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { ICardData, IErrorObj, IOptions, Token } from './types';
import PaymentAPIManager from '../../repository';
import { useEventListener } from './useEventListener';
import useTappTranslation from './useTappTranslation';
import { ITappGatewayConfig } from '../../repository/type/paymentGateway';
import PayButtonElement from '../PayButtonElement';

import styles from './index.module.scss';

export interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks {
    refId: string;
    onRefreshRef: () => void;
    config: ITappGatewayConfig;
}

const CardPayment = ({
    name,
    config,
    disable,
    gatewayId,
    tip,
    refId,
    vendor,
    amount,
    updateTimestamp,
    diningSessionID,
    sessionId,
    currencyPrecision,
    onBeforePayment,
    onDone,
    onFail,
    onRefreshRef,
    onPgRegister,
    onTraceStart,
    onTraceClose,
}: IProps) => {
    const { t } = useTranslation('common');
    const { lang } = useQlubRouter();
    const [loading, setLoading] = useState(false);
    const [scriptsLoaded, setScriptsLoaded] = useState(false);
    const [helperText, setHelperText] = useState<IErrorObj | string>('');
    const { errMap, labels } = useTappTranslation();
    const theme = useTheme();
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const { getCallbackUrl } = useConfirmCallback();
    const { hasPgGroup } = vendor.paymentGatewayList;
    const [buttonDisabled, setButtonDisabled] = useState(true);
    const [cardData, setCardData] = useState<ICardData | null>(null);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    // Why are we using window listener?
    useEventListener({ type: 'message', element: window, listener: formInterceptor });

    function formInterceptor(evt: Event) {
        const { data } = evt as MessageEvent;

        const errorObj: IErrorObj = data?.error || data?.error_interactive;
        if (errorObj) {
            errorHandler(errorObj);
        }

        if (data?.valid && data?.BIN !== false && isObject(data?.BIN) && data?.valid?.key === 'valid_card') {
            setCardData(data?.BIN);
        }

        if (data?.status === 'success') {
            setButtonDisabled(false);
            setHelperText('');
        } else if (data?.status === 'invalid') {
            setButtonDisabled(true);
        }
    }

    console.log(cardData);

    const errorHandler = (err: IErrorObj) => {
        setHelperText(errMap[err.key] || err?.message || t('Something went wrong'));
    };

    function convertRemToPixels(rem: string) {
        const removeRemAndSpaces = Number(rem.replace('rem', '').trim());
        return `${(removeRemAndSpaces * theme.typography.htmlFontSize).toString()}px`;
    }

    const handleFormSuccess = (response: Token) => {
        setLoading(true);
        const totalAmount = sumAmounts(currencyPrecision, amount, tip);

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.CardPay,
                refId,
            },
        });

        onBeforePayment({ gatewayId, tip, paymentElement: PaymentElementEnum.CardPay })
            .then((ok) => {
                if (!ok) {
                    setLoading(false);
                    return;
                }

                if (!response?.id) {
                    enqueueSnackbar(t('Something went wrong'), { variant: 'error' });
                    setLoading(false);
                    return;
                }

                const returnUrl = getCallbackUrl({
                    ref: refId,
                    method: name,
                    paymentElement: PaymentElementEnum.ApplePay,
                    dsi: diningSessionID,
                    amount: totalAmount,
                    currencySymbol: vendor.country.currencySymbol,
                    lang,
                    traceId: traceStart?.traceId,
                });

                PaymentAPIManager.getInstance()
                    .payTappPayment({
                        id: sessionId,
                        diningSessionID,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                        cardToken: response.id,
                        failureUrl: returnUrl.fail,
                        successUrl: returnUrl.success,
                        reference: refId,
                        gatewayID: gatewayId,
                        cardBrand: cardData?.card_brand || '',
                        billingCountry: cardData?.country || '',
                        cardScheme: cardData?.card_scheme || '',
                    })
                    .then((res) => {
                        if (res.data.needVerification) {
                            if (!res.data.redirectUrl) {
                                enqueueSnackbar(t('Something went wrong'), { variant: 'error' });
                                return;
                            }
                            window.location.href = res.data.redirectUrl;
                        } else {
                            onDone({
                                paymentElement: PaymentElementEnum.CardPay,
                                refId,
                                traceId: traceStart?.traceId,
                            });
                        }
                    })
                    .catch((err: any) => {
                        onTraceClose?.({
                            error: err,
                            location: 'payTappPayment',
                            traceRef,
                            traceStart,
                        });

                        const errData = err?.response?.data || err || {};

                        if (errData.code === 412 && errData.items === 'PAYMENT_REFERENCE_CONFLICTS_TRANSACTION') {
                            onRefreshRef();
                        } else {
                            onFail({
                                paymentElement: PaymentElementEnum.CardPay,
                                refId,
                                traceId: traceStart?.traceId,
                            });
                        }
                    });
            })
            .catch(() => {
                setLoading(false);
            });
    };
    const options: IOptions = useMemo(
        () => ({
            containerID: 'tapp-frame-container',
            gateway: {
                publicKey: config.publicKey,
                language: lang === 'ar' ? 'ar' : 'en',
                supportedCurrencies: 'all',
                supportedPaymentMethods: 'all',
                notifications: 'msg',
                callback: handleFormSuccess,
                labels,
                style: {
                    base: {
                        fontSmoothing: 'antialiased',
                        ...theme.qlub.typography.body_md,
                        fontSize: convertRemToPixels(theme.qlub.typography.body_md.fontSize),
                        color: theme.qlub.palette.onSurfaceColors.highEmphasis,
                        lineHeight: '1.5',
                        '::placeholder': {
                            color: theme.qlub.palette.onSurfaceColors.disabled,
                            ...theme.qlub.typography.body_md,
                            fontSize: convertRemToPixels(theme.qlub.typography.body_md.fontSize),
                        },
                    },
                    invalid: {
                        color: theme.qlub.palette.danger.main,
                        iconColor: theme.qlub.palette.danger.transparent,
                    },
                },
            },
            token: true,
        }),
        [lang, t, updateTimestamp, amount],
    );
    useEffect(() => {
        if (!scriptsLoaded) return;
        setHelperText('');

        window.goSell?.config({ containerID: 'tapp-frame-container' });

        window.goSell?.goSellElements(options);
    }, [lang, refId]);

    useEffect(() => {
        if (!scriptsLoaded) return;
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.CardPay,
            name: t('Card'),
            icon: <CreditCard />,
            buttonElement,
        });
        window.goSell?.goSellElements(options);
    }, [tip, disable, loading, updateTimestamp, scriptsLoaded, buttonDisabled]);

    const handleLoad = () => {
        setScriptsLoaded(true);
        window.goSell?.goSellElements(options);
    };

    const handleSubmit = () => {
        setHelperText('');
        window.goSell?.submit();
    };

    const buttonElement = useMemo(
        () => (
            <PayButtonElement
                variant="contained"
                sx={{ mt: 2 }}
                size="large"
                fullWidth
                loading={loading}
                disabled={disable || loading || buttonDisabled}
                onClick={handleSubmit}
                showConfirmText={!hasPgGroup}
            />
        ),
        [loading, disable, buttonDisabled, updateTimestamp],
    );

    return (
        <>
            <Head>
                <link href="https://goSellJSLib.b-cdn.net/v2.0.0/css/gosell.css" rel="stylesheet" />
            </Head>
            <Scripts src="https://goSellJSLib.b-cdn.net/v2.0.0/js/gosell.js" onReady={handleLoad} />
            <div id="tapp-frame-container" />
            <div id="msg" style={{ display: 'none' }} />
            <div className={styles.error}>{helperText.toString()}</div>
            {!hasPgGroup && <Box className={styles.submit}>{buttonElement}</Box>}
        </>
    );
};

export default CardPayment;
