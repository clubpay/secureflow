import { useState, useEffect } from 'react';

interface ScriptLoadOptions {
    module?: boolean;
    in?: 'head' | 'body';
}

type ScriptStatus = 'loading' | 'done' | 'error';

const SCRIPTS_LOADED: Record<string, Promise<boolean>> = {};

export function loadScript(src: string, options?: ScriptLoadOptions): Promise<boolean> {
    const isScriptLoaded = SCRIPTS_LOADED[src];

    if (isScriptLoaded) {
        return isScriptLoaded;
    }

    const isAlreadyInDom = (): boolean => {
        const scriptElements = Array.from(document.getElementsByTagName('script'));
        return scriptElements.some((script) => script.src === src);
    };

    if (isAlreadyInDom()) {
        if (SCRIPTS_LOADED.hasOwnProperty(src)) {
            return SCRIPTS_LOADED[src];
        }
        SCRIPTS_LOADED[src] = new Promise((resolve) => {
            resolve(true);
        });
        return SCRIPTS_LOADED[src];
    }

    const promise = new Promise<boolean>((resolve, reject) => {
        const script = document.createElement('script');
        if (options?.module) {
            script.type = 'module';
        } else {
            script.type = 'text/javascript';
        }
        script.src = src;
        script.onload = (): void => {
            resolve(true);
        };
        script.onerror = (): void => {
            reject(new Error(`Failed to load script: ${src}`));
        };
        if (options?.in === 'head') {
            document.head.appendChild(script);
        } else {
            document.body.appendChild(script);
        }
    });

    SCRIPTS_LOADED[src] = promise;

    return promise;
}

export function useLoadScript(urls: string[], options?: ScriptLoadOptions): ScriptStatus {
    const [status, setStatus] = useState<ScriptStatus>('loading');
    const stringifiedOptions = JSON.stringify(options);
    const stringifiedUrls = JSON.stringify(urls);

    useEffect(() => {
        async function loadScripts(): Promise<void> {
            try {
                setStatus('loading');
                const a = await Promise.all(urls.map((url) => loadScript(url, options)));
                console.log(a);
                setStatus('done');
            } catch (error) {
                setStatus('error');
            }
        }

        loadScripts().catch(() => {
            setStatus('error');
        });
    }, [stringifiedOptions, stringifiedUrls]);

    return status;
}
