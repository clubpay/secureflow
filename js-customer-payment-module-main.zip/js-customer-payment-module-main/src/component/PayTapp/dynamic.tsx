/*
 * Creation Time: March 14 - 2023
 * Created By: yasincelebi
 * Name: dynamic.tsx
 * Copyright 2023 customer-web-app
 */

import React, { useEffect, useState } from 'react';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import CardPayment from './card';
import { applePayJsAvailable } from '../ApplePayButton/utils/handlers';
import TappApplePay from './applepay';
import PaymentWrapper from '../PaymentWrapper';
import { ITappGatewayConfig } from '../../repository/type/paymentGateway';

export interface IProps extends IPGProps {
    config: ITappGatewayConfig;
}

const PayTapp = ({
    name,
    config,
    disable,
    onBeforePayment,
    gatewayId,
    tip,
    vendor,
    amount,
    url,
    diningSessionID,
    sessionId,
    jwt,
    currencyPrecision,
    updateTimestamp,
    onDone,
    onFail,
    onUnlockPayment,
    onPending,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onTraceClose,
}: IProps) => {
    const [reference, setReference] = useState(getRandomString());
    const [hasApplePay, setHasApplePay] = useState(false);
    const { hasPgGroup } = vendor.paymentGatewayList;
    const { login, isLogin } = useAuth();

    useEffect(() => {
        if (!isLogin) {
            login({ guest: true });
        }
    }, [isLogin]);

    useEffect(() => {
        applePayJsAvailable().then((enable) => {
            setHasApplePay(enable);
        });
    }, [url.cc, url.slug, url.id]);

    return (
        <>
            {config?.hideApplePay !== true && hasApplePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.ApplePay)}>
                    <TappApplePay
                        name={name}
                        url={url}
                        currencyPrecision={currencyPrecision}
                        amount={amount}
                        tip={tip}
                        gatewayId={gatewayId}
                        disable={disable}
                        config={config}
                        vendor={vendor}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        updateTimestamp={updateTimestamp}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        onTraceStart={onTraceStart}
                        hasPgGroup={hasPgGroup}
                        onTraceClose={onTraceClose}
                    />
                </PaymentWrapper>
            )}
            {config?.hideCardPay !== true && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}>
                    <CardPayment
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        onBeforePayment={onBeforePayment}
                        currencyPrecision={currencyPrecision}
                        refId={reference}
                        onUnlockPayment={onUnlockPayment}
                        tip={tip}
                        gatewayId={gatewayId}
                        vendor={vendor}
                        amount={amount}
                        updateTimestamp={updateTimestamp}
                        onDone={onDone}
                        onFail={onFail}
                        config={config}
                        disable={disable}
                        url={url}
                        onRefreshRef={() => setReference(getRandomString())}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        onTraceStart={onTraceStart}
                        onTraceClose={onTraceClose}
                    />
                </PaymentWrapper>
            )}
        </>
    );
};

export default PayTapp;
