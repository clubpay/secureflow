declare global {
    interface Window {
        goSell?: {
            config: (options: { containerID: string }) => any;
            goSellElements: (options: IOptions) => void;
            submit: () => void;
        };
    }
}

export interface ILabel {
    cardNumber: string;
    expirationDate: string;
    cvv: string;
    cardHolder: string;
    actionButton: string;
}

export interface IStyle {
    base: {
        color: string;
        lineHeight: string;
        fontFamily: string;
        fontSmoothing: string;
        fontSize: string;
        '::placeholder': {
            color: string;
            fontSize: string;
        };
    };
    invalid: {
        color: string;
        iconColor: string;
    };
}

export interface IOptions {
    containerID: string;
    gateway: {
        publicKey: string;
        language: string;
        supportedCurrencies: string;
        supportedPaymentMethods: string;
        notifications: string;
        labels: ILabel;
        callback: (res: Token) => void;
        style: IStyle;
    };
    token: boolean;
}

export interface Token {
    id: string;
    created: number;
    object: string;
    live_mode: boolean;
    type: string;
    used: boolean;
    card: {
        id: string;
        object: string;
        address: Record<string, unknown>;
        funding: string;
        fingerprint: string;
        brand: string;
        scheme: string;
        name: string;
        exp_month: number;
        exp_year: number;
        last_four: string;
        first_six: string;
    };
}

export interface IErrorObj {
    key:
        | 'card_holder_required'
        | 'card_number_required'
        | 'error_card_holder_short'
        | 'error_currency_not_supported'
        | 'error_invalid_card'
        | 'error_invalid_card_characters'
        | 'error_invalid_expiry_characters'
        | 'error_invalid_cvv_characters'
        | 'expiry_date_past'
        | 'expiry_date_required'
        | 'expiry_month_required'
        | 'expiry_year_required';
    message: string;
}

export interface IErrMap {
    card_holder_required: string;
    card_number_required: string;
    error_card_holder_short: string;
    error_currency_not_supported: string;
    error_invalid_card: string;
    error_invalid_card_characters: string;
    error_invalid_expiry_characters: string;
    error_invalid_cvv_characters: string;
    expiry_date_past: string;
    expiry_date_required: string;
    expiry_month_required: string;
    expiry_year_required: string;
}

export interface ICardData {
    bin: string;
    bank: string;
    card_brand: string;
    card_type: string;
    card_category: string;
    card_scheme: string;
    country: string;
    address_required: boolean;
    api_version: string;
    issuer_id: string;
    brand: string;
}

export {};
