import React from 'react';
import { Alert } from '@mui/material';
import CurrencyExchangeIcon from '@mui/icons-material/CurrencyExchange';
import { Typography } from '@qlub-dev/qlub-kit';
import { SnackbarContent, SnackbarKey, SnackbarMessage, useSnackbar } from 'notistack';

interface ExchangeAlertProps {
    id?: SnackbarKey;
    message?: SnackbarMessage;
}

const ExchangeAlert = React.forwardRef<HTMLDivElement, ExchangeAlertProps>((props, ref) => {
    const { id, message, ...other } = props;
    const { closeSnackbar } = useSnackbar();

    return (
        <SnackbarContent ref={ref} role="alert" {...other}>
            <Alert
                variant="filled"
                severity="warning"
                icon={<CurrencyExchangeIcon fontSize="small" />}
                sx={{ borderRadius: 2, py: 1.5, width: '100%' }}
                onClose={() => closeSnackbar(id)}
            >
                <Typography typo="caption_overline">{message}</Typography>
            </Alert>
        </SnackbarContent>
    );
});

export default ExchangeAlert;
