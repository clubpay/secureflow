/*
 * Creation Time: January 2 - 2023
 * Created By: yasincelebi
 * Name: index.tsx
 * Copyright 2023 customer-web-app
 */
import { GooglePayDark } from '@clubpay/customer-common-module/src/component/SVG';
import { interpolateT, useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import styles from './index.module.scss';

export interface IGooglePayButtonProps {
    onClick: () => void;
}
const GooglePayButton = ({ onClick }: IGooglePayButtonProps) => {
    const { t } = useTranslation('common');
    return (
        <button onClick={onClick} className={styles.googlepay} type="button" aria-label="Pay">
            {interpolateT(t('Checkout with  <icon>'), { icon: <GooglePayDark /> })}
        </button>
    );
};

export default GooglePayButton;
