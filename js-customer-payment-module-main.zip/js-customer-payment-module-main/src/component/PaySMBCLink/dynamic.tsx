/*
    Creation Time: 2021 - Dec - 13
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { CustomerContainer } from '@qlub-dev/qlub-kit';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useConfirmCallback, usePaymentTimeout } from '@clubpay/customer-common-module/src/hook/payment';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { CreditCard } from '@mui/icons-material';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { ISMBCGateway } from '../../repository/type/paymentGateway';
import PayButtonElement from '../PayButtonElement';
import PaymentWrapper from '../PaymentWrapper';
import PaymentAPIManager from '../../repository';

import styles from './index.module.scss';

export interface IProps extends IPGProps {
    config: ISMBCGateway;
}

export default function PaySMBCLink({
    diningSessionID,
    sessionId,
    amount,
    tip,
    currencyPrecision,
    disable,
    config,
    vendor,
    gatewayId,
    updateTimestamp,
    name,
    onBeforePayment,
    onFail,
    onIndicator,
    onLoad,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onTraceClose,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);
    const { timeoutDone } = usePaymentTimeout({
        indicatorTimeout: config?.indicatorTimeout || 0,
        fallbackTimeout: config?.fallbackTimeout || 0,
        indicatorCallback: onIndicator,
        fallbackCallback: onLoad,
    });
    const { getCallbackUrl } = useConfirmCallback();
    const { hasPgGroup } = vendor.paymentGatewayList;
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const { lang } = useQlubRouter();

    const buttonElement = useMemo(
        () => (
            <PayButtonElement
                variant="contained"
                size="large"
                disabled={disable || loading || success}
                onClick={submitHandler}
                fullWidth
                id="smbc-link-action-btn"
                loading={loading}
                showConfirmText={!hasPgGroup}
            />
        ),
        [tip, disable, loading, success, updateTimestamp],
    );

    useEffect(() => {
        timeoutDone();
        onPgRegister?.({
            pgId: gatewayId,
            name: 'Link',
            icon: <CreditCard />,
            elem: PaymentElementEnum.CardPay,
            placement: 'bottom',
            buttonElement,
        });
    }, [disable, loading, buttonElement, updateTimestamp]);

    const submitHandler = () => {
        if (loading) {
            return;
        }

        const refId = getRandomString();
        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.LinkPay,
                refId,
            },
        });

        onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.LinkPay,
            tip,
        })
            .then((ok) => {
                if (!ok) {
                    return;
                }

                setLoading(true);

                const total = sumAmounts(currencyPrecision, amount, tip);

                const returnUrl = getCallbackUrl({
                    ref: refId,
                    method: name,
                    paymentElement: PaymentElementEnum.LinkPay,
                    tip,
                    dsi: diningSessionID,
                    sid: sessionId,
                    amount: total.toFixed(currencyPrecision || 0),
                    currencySymbol: vendor.country.currencySymbol,
                    traceId: traceStart?.traceId,
                    lang,
                });

                PaymentAPIManager.getInstance()
                    .paymentSMBCGenerateLink({
                        id: sessionId,
                        reference: refId,
                        diningSessionID,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                        gatewayID: gatewayId,
                        successUrl: returnUrl.success,
                        failureUrl: returnUrl.fail,
                    })
                    .then((res) => {
                        setSuccess(true);

                        window.location.href = res.data.link;
                        enqueueSnackbar(t('Redirecting to SMBC gateway'), { variant: 'success' });
                    })
                    .catch((err) => {
                        onTraceClose?.({
                            error: err,
                            location: 'paymentSMBCGenerateLink',
                            traceRef,
                            traceStart,
                        });

                        onFail({
                            paymentElement: PaymentElementEnum.CardPay,
                            refId,
                            traceId: traceStart?.traceId,
                        });
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            })
            .catch(() => {
                setLoading(false);
            });
    };

    return (
        <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.LinkPay)}>
            <div className={styles.form}>
                <CustomerContainer centered className={styles.submit}>
                    {!hasPgGroup && buttonElement}
                </CustomerContainer>
            </div>
        </PaymentWrapper>
    );
}
