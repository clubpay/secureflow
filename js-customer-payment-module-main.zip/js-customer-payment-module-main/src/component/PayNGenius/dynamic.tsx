import React, { useEffect, useState } from 'react';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { isSafari } from '@clubpay/customer-common-module/src/utility/mobile_check';
import { INGeniusGateway } from '../../repository/type/paymentGateway';
import { applePayJsAvailable } from '../ApplePayButton/utils/handlers';
import PaymentWrapper from '../PaymentWrapper';
import ApplePay from './components/ApplePay';
import Card from './components/Card';

export interface IProps extends IPGProps {
    config: INGeniusGateway;
}

export default function PayNGenius({
    name,
    diningSessionID,
    sessionId,
    url,
    amount,
    tip,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    hasSplitPayment,
    exchange,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onPending,
    onPgRegister,
    onPgUnregister,
    onTraceStart,
    isPgElemVisible,
    onTraceClose,
    onExchangeChange,
}: IProps) {
    const [hasApplePay, setHasApplePay] = useState(false);
    const [hasGooglePay, setHasGooglePay] = useState(false);
    const { hasPgGroup } = vendor.paymentGatewayList;
    const { login, isLogin } = useAuth();
    useEffect(() => {
        if (!isLogin) {
            login({ guest: true });
        }
    }, [isLogin]);

    useEffect(() => {
        applePayJsAvailable().then((enable) => {
            setHasApplePay(enable);
        });

        setHasGooglePay(!isSafari());
    }, [url.cc, url.slug, url.id]);

    return (
        <div>
            {!config?.hideApplePay && hasApplePay && !hasGooglePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.ApplePay)}>
                    <ApplePay
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        vendor={vendor}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        hasPgGroup={hasPgGroup}
                        hasSplitPayment={hasSplitPayment}
                        exchange={exchange}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onPending={onPending}
                        onFail={onFail}
                        onPgRegister={onPgRegister}
                        onPgUnregister={onPgUnregister}
                        onTraceStart={onTraceStart}
                        onTraceClose={onTraceClose}
                        onExchangeChange={onExchangeChange}
                    />
                </PaymentWrapper>
            )}

            {!config?.hideCardPay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}>
                    <Card
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        vendor={vendor}
                        hasPgGroup={hasPgGroup}
                        hasSplitPayment={hasSplitPayment}
                        exchange={exchange}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        onPgUnregister={onPgUnregister}
                        onTraceStart={onTraceStart}
                        onTraceClose={onTraceClose}
                        onExchangeChange={onExchangeChange}
                    />
                </PaymentWrapper>
            )}
        </div>
    );
}
