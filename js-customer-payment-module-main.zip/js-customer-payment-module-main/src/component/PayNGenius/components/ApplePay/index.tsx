import React, { useState } from 'react';
import Scripts from 'next/script';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { Apple } from '@mui/icons-material';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import {
    IPGBaseProps,
    IPGExchangeProps,
    IPGHooks,
    IPGSplitProps,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { Span } from '@sentry/nextjs/types/client';
import { useExchangeInteruption } from '../../../../hook/useExchangeInteruption';
import { getPaymentExchangeDecision } from '../../../../utility/exchange';
import { INGeniusGateway } from '../../../../repository/type/paymentGateway';
import { disableApplePayBilling, getApplePayShippingBillingConfig } from '../../../../utility/shipping_info';
import { ApplePayButton } from '../../../ApplePayButton';
import PaymentAPIManager from '../../../../repository';
import { INGeniusPayByApplePayPayload } from '../../../../repository/type/nGenius';
import { useSentry } from '../../../../hook/useSentry';

interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks, IPGSplitProps, IPGExchangeProps {
    config: INGeniusGateway;
    hasPgGroup: boolean;
}

export default function ApplePay({
    diningSessionID,
    sessionId,
    amount,
    tip,
    url,
    name,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    hasPgGroup,
    exchange,
    hasSplitPayment,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onPending,
    onFail,
    onPgRegister,
    onPgUnregister,
    onExchangeChange,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [loading, setLoading] = useState(false);

    const totalAmount = exchange?.isApplied ? exchange.total : sumAmounts(currencyPrecision, amount, tip);

    const { triggerInteruption } = useExchangeInteruption({
        pgConfig: config,
        restaurantConfig: vendor.config,
        diningSessionId: diningSessionID,
        pgName: name,
        pgId: gatewayId,
        paymentMethod: PaymentElementEnum.ApplePay,
        restaurantName: url.slug,
        onExchangeChange,
        onPgUnregister,
    });

    const { startTrace, captureException } = useSentry({
        paymentMethod: PaymentElementEnum.ApplePay,
        pgName: name,
        dineSessionId: diningSessionID,
    });

    const payHandler = () => {
        if (!ApplePaySession) {
            return;
        }

        setLoading(true);

        const request: ApplePayJS.ApplePayPaymentRequest = {
            countryCode: (config?.countryCode || vendor.country.code).toLocaleUpperCase(),
            currencyCode: (exchange?.isApplied ? exchange.currencyCode : vendor.country.currencyCode)?.toUpperCase(),
            merchantCapabilities: config?.merchantCapabilities || ['supports3DS'],
            supportedNetworks: config?.supportedNetworksList || ['visa', 'masterCard', 'amex', 'discover'],
            total: {
                label: 'Qlub_',
                type: 'final',
                amount: totalAmount.toFixed(currencyPrecision || 0),
            },
            ...getApplePayShippingBillingConfig(config),
        };

        const refId = getRandomString();

        try {
            const session: ApplePaySession = new ApplePaySession(config?.appleSDKVersion || 3, request);
            session.begin();

            session.onvalidatemerchant = async (e) => {
                startTrace('validate', async (span: Span) => {
                    try {
                        const initialResponse = await onBeforePayment({
                            gatewayId,
                            paymentElement: PaymentElementEnum.ApplePay,
                            tip,
                        });

                        if (!initialResponse) {
                            setLoading(false);
                            onUnlockPayment();
                            session?.abort();
                            return;
                        }

                        const validationResponse = await PaymentAPIManager.getInstance().payNGeniusValidateApplePay({
                            applePayUrl: e.validationURL,
                            diningSessionID,
                            gatewayID: gatewayId,
                        });

                        session.completeMerchantValidation(JSON.parse(validationResponse.data.jsonData));
                    } catch (error) {
                        setLoading(false);
                        onUnlockPayment();
                        session?.abort();
                        captureException(error);
                    } finally {
                        span?.finish();
                    }
                });
            };

            session.onpaymentmethodselected = () => {
                const update: ApplePayJS.ApplePayPaymentMethodUpdate = {
                    newTotal: {
                        label: 'Qlub_',
                        type: 'final',
                        amount: totalAmount.toFixed(currencyPrecision || 0),
                    },
                };
                session.completePaymentMethodSelection(update);
            };

            session.onpaymentauthorized = async (e) => {
                startTrace('pay', async (span: Span) => {
                    try {
                        const requestPayload: INGeniusPayByApplePayPayload = {
                            id: sessionId,
                            diningSessionID,
                            tipAmount: tip.toFixed(currencyPrecision || 0),
                            appleToken: JSON.stringify(e.payment?.token),
                            shippingContact: e.payment?.shippingContact,
                            billingContact: e.payment?.billingContact,
                            reference: refId,
                            gatewayID: gatewayId,
                            cardType: e.payment?.token?.paymentMethod?.network || '',
                            hostname: window.location.hostname,
                            isSplitPayment: !!hasSplitPayment,
                            exchangeDecision: getPaymentExchangeDecision(exchange),
                        };

                        const response = await PaymentAPIManager.getInstance().payNGeniusPayByApple(requestPayload);

                        /**
                         *  handle when detect a international card
                         */
                        if (response.data.exchangeData) {
                            onUnlockPayment();
                            session.completePayment({ status: ApplePaySession.STATUS_FAILURE });
                            triggerInteruption(response.data.exchangeData);
                            setLoading(false);
                            return;
                        }

                        /** to avoid throwing error when backend taking
                         *  long time to complete the payment
                         */
                        try {
                            session.completePayment(ApplePaySession.STATUS_SUCCESS);
                            // eslint-disable-next-line no-empty
                        } catch (error) {
                            captureException(error);
                        }

                        onDone({
                            paymentElement: PaymentElementEnum.ApplePay,
                            refId,
                            meta: {
                                isExchangeInterrupted: Boolean(exchange),
                                isExchangeUsed: Boolean(exchange?.isApplied),
                            },
                        });

                        enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                    } catch (error) {
                        setLoading(false);
                        captureException(error);
                        session.completePayment(ApplePaySession.STATUS_FAILURE);
                        const isNetworkError = checkNetworkError(error as AxiosError);
                        if (isNetworkError) {
                            onPending({
                                paymentElement: PaymentElementEnum.ApplePay,
                                refId,
                            });
                        }

                        onFail({
                            paymentElement: PaymentElementEnum.ApplePay,
                            refId,
                            meta: {
                                isExchangeInterrupted: Boolean(exchange),
                                isExchangeUsed: Boolean(exchange?.isApplied),
                            },
                        });
                    } finally {
                        span?.finish();
                    }
                });
            };

            session.oncancel = () => {
                setLoading(false);
                disableApplePayBilling();
                onUnlockPayment();

                onPushEvent('applepay_cancel', {
                    pg_name: name,
                    restaurant_name: url.slug,
                    opsMode: vendor?.opsMode,
                    diningSessionId: diningSessionID,
                });
            };
        } catch (error) {
            setLoading(false);
            captureException(error);
        }
    };

    const loadScriptHandler = () => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.ApplePay,
            name: 'Apple Pay',
            icon: <Apple />,
            placement: 'bottom',
        });
    };

    return (
        <div>
            <Scripts src="/pg_sdk/apple-pay-sdk.js" onReady={loadScriptHandler} />
            <div data-area="submit">
                <ApplePayButton
                    onClick={payHandler}
                    theme="dark"
                    disabled={disable || loading}
                    id="ngenius-applepay-action-btn"
                    hasPgGroup={hasPgGroup}
                />
            </div>
        </div>
    );
}
