import React from 'react';
import { Skeleton } from '@mui/material';
import styles from './index.module.scss';

const CardSkeleton = () => {
    return (
        <div>
            <Skeleton height="64px" width="100%" />
            <div className={styles.row}>
                <Skeleton height="64px" className={styles.expire} />
                <Skeleton height="64px" className={styles.cvv} />
            </div>
            <Skeleton height="64px" width="100%" />
        </div>
    );
};

export default CardSkeleton;
