export const style = {
    main: {
        overflow: 'hidden',
    },
    base: {
        fontUrl: 'https://fonts.googleapis.com/css?family=Roboto&display=swap',
        fontFamily: 'Roboto',
        padding: '0px',
    },
    input: {
        borderWidth: '2px',
        borderColor: '#E5E5E5',
        borderStyle: 'solid',
        borderRadius: '6px',
        padding: '10px 10px',
    },
};
