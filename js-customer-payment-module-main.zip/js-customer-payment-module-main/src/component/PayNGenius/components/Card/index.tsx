/* eslint-disable no-throw-literal */
import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import {
    IPGBaseProps,
    IPGExchangeProps,
    IPGHooks,
    IPGSplitProps,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { CreditCard } from '@mui/icons-material';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import classNames from 'classnames';
import { Span } from '@sentry/nextjs/types/client';
import { usePgEvent } from '../../../../hook/usePgEvent';
import { useExchangeInteruption } from '../../../../hook/useExchangeInteruption';
import { getPaymentExchangeDecision } from '../../../../utility/exchange';
import { style } from './styles';
import PayButtonElement from '../../../PayButtonElement';
import PaymentAPIManager from '../../../../repository';
import { INGeniusGateway } from '../../../../repository/type/paymentGateway';
import styles from './index.module.scss';
import { PaymentStatus } from '../../../../repository/type/nGenius';
import { use3dsMount } from '../../hooks/use-3ds-mount';
import { useScript } from '../../hooks/use-script';
import LoadingDialog from '../../../LoadingDialog';
import CardSkeleton from '../CardSkeleton';
import { useSentry } from '../../../../hook/useSentry';

interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks, IPGExchangeProps, IPGSplitProps {
    config: INGeniusGateway;
    hasPgGroup: boolean;
}

export default function Card({
    url,
    diningSessionID,
    sessionId,
    amount,
    tip,
    name,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    hasPgGroup,
    exchange,
    hasSplitPayment,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onPending,
    onPgRegister,
    onPgUnregister,
    onExchangeChange,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar, actionButton } = snackBar();
    const [loading, setLoading] = useState(false);
    const [isCardDetailsValid, setIsCardDetailsValid] = useState(false);
    const containerRef = useRef(null);

    const { startTrace, infoLog, errorLog, captureException } = useSentry({
        paymentMethod: PaymentElementEnum.CardPay,
        pgName: name,
        dineSessionId: diningSessionID,
    });

    const { getCallbackUrl } = useConfirmCallback();

    const { sendEvent } = usePgEvent({
        pgName: `${name}_${PaymentElementEnum.CardPay}`.toLowerCase(),
        diningSessionId: diningSessionID,
        restaurantName: url?.slug,
    });

    const mountCardInput = () => {
        window.NI?.mountCardInput('ngenius-container', {
            apiKey: config.hostedSessionApiKey,
            outletRef: config.outlet_ref,
            style,
            onChangeValidStatus: (e) => {
                setIsCardDetailsValid(e.isCVVValid && e.isExpiryValid && e.isNameValid && e.isPanValid);
            },
            onSuccess: () => setLoadingSdk(false),
        });
    };

    const { triggerInteruption } = useExchangeInteruption({
        pgConfig: config,
        restaurantConfig: vendor.config,
        diningSessionId: diningSessionID,
        pgName: name,
        pgId: gatewayId,
        paymentMethod: PaymentElementEnum.CardPay,
        restaurantName: url.slug,
        onExchangeChange,
        onPgUnregister,
    });

    const { is3dsMounted, reset3dsMounted, threeDsContainerRef } = use3dsMount();

    const { loadingSdk, setLoadingSdk, load } = useScript({
        onLoad: mountCardInput,
        containerRef,
        sandbox: config.sandbox,
    });

    const handlePay = async () => {
        startTrace('pay', async (span: Span) => {
            const refId = getRandomString();
            let paymentResponse: any;
            let ngeniusResponse: any;
            try {
                const tipCheckResponse = await onBeforePayment({
                    checkTipOnly: true,
                    gatewayId,
                    paymentElement: PaymentElementEnum.CardPay,
                    tip,
                });

                if (!tipCheckResponse) {
                    infoLog('Tip check Fail');
                    return;
                }
                infoLog('Tip check Success');

                if (!isCardDetailsValid) {
                    triggerSnackBar(
                        t('The card information is incorrect, Please check the details and retry'),
                        {
                            variant: 'error',
                            action: actionButton,
                        },
                        true,
                    );
                    infoLog('Card validation Fail');
                    return;
                }

                reset3dsMounted();

                infoLog('Reset 3ds mount');

                setLoading(true);

                const returnUrl = getCallbackUrl({
                    ref: refId,
                    method: name,
                    paymentElement: PaymentElementEnum.CardPay,
                    dsi: diningSessionID,
                    amount: sumAmounts(currencyPrecision, amount, tip),
                    currencySymbol: vendor.country.currencySymbol,
                    is3ds: true,
                });

                const initialResponse = await onBeforePayment({
                    gatewayId,
                    paymentElement: PaymentElementEnum.CardPay,
                    tip,
                });

                if (!initialResponse) {
                    infoLog('onBefore api Fail');
                    setLoading(false);
                    return;
                }
                infoLog('onBefore api Success');

                let nGeniusSessionId: string | undefined;

                /** handle token expiration */

                try {
                    infoLog('Generate session Start');
                    const sessionResponse = await window.NI?.generateSessionId();
                    nGeniusSessionId = sessionResponse?.session_id;
                    infoLog('Generate session Success');
                } catch (_) {
                    infoLog('Generate session Fail');

                    triggerSnackBar(
                        t('The payment did not proceed Please try again'),
                        {
                            variant: 'error',
                            action: actionButton,
                        },
                        true,
                    );
                    setLoading(false);
                    onUnlockPayment();
                    sendEvent('payment_initialized', {
                        status: 'failed',
                        error: 'ngenius_token_expired',
                        forex_ui: vendor?.config?.forexUI ?? 'v1',
                    });
                    load();
                    return;
                }

                paymentResponse = await PaymentAPIManager.getInstance().payNGeniusPayByCard({
                    id: sessionId,
                    reference: refId,
                    gatewayID: gatewayId,
                    diningSessionID,
                    tipAmount: tip.toFixed(currencyPrecision || 0),
                    sessionId: nGeniusSessionId,
                    successUrl: returnUrl.success,
                    failureUrl: returnUrl.fail,
                    isSplitPayment: Boolean(hasSplitPayment),
                    exchangeDecision: getPaymentExchangeDecision(exchange),
                });

                span?.setData('payment_response', paymentResponse);
                span?.setTag('qlub.order_reference', paymentResponse.data?.orderReference);

                /**
                 *  handle when detect a international card
                 */
                if (paymentResponse.data.exchangeData) {
                    infoLog('Forex handle start');
                    onUnlockPayment();
                    triggerInteruption(paymentResponse.data.exchangeData);
                    setLoading(false);
                    return;
                }

                infoLog('Handle payment response Start');

                ngeniusResponse = await window.NI?.handlePaymentResponse(paymentResponse.data, {
                    mountId: 'ngenius-3ds',
                });

                span?.setData('ngenius_response', ngeniusResponse);
                infoLog('Handle payment response Success');

                if (
                    !(
                        ngeniusResponse?.status === PaymentStatus.AUTHORISED ||
                        ngeniusResponse?.status === PaymentStatus.CAPTURED
                    )
                ) {
                    onPending({
                        paymentElement: PaymentElementEnum.CardPay,
                        refId,
                    });
                    captureException(ngeniusResponse);
                    return;
                }

                infoLog('Capture api Start');

                await PaymentAPIManager.getInstance().payNGeniusCapture({
                    id: sessionId,
                    reference: refId,
                    gatewayID: gatewayId,
                    diningSessionID,
                    tipAmount: tip.toFixed(currencyPrecision || 0),
                    sessionId: nGeniusSessionId,
                    paymentURL: paymentResponse.data._links.self.href,
                    exchangeDecision: getPaymentExchangeDecision(exchange),
                });

                infoLog('Capture api Success');

                onDone({
                    paymentElement: PaymentElementEnum.CardPay,
                    refId,
                    is3ds: is3dsMounted.current,
                    meta: {
                        isExchangeInterrupted: Boolean(exchange),
                        isExchangeUsed: Boolean(exchange?.isApplied),
                    },
                });
                setLoading(false);

                infoLog('Payment flow Success');
            } catch (error: any) {
                errorLog('Payment flow Fail');
                captureException(error);

                setLoading(false);
                onUnlockPayment();

                const isNetworkError = checkNetworkError(error as AxiosError);
                if (isNetworkError) {
                    infoLog('Network Fail');
                    onPending({
                        paymentElement: PaymentElementEnum.CardPay,
                        refId,
                    });
                }

                onFail({
                    paymentElement: PaymentElementEnum.CardPay,
                    refId,
                    is3ds: is3dsMounted.current,
                    meta: {
                        isExchangeInterrupted: Boolean(exchange),
                        isExchangeUsed: Boolean(exchange?.isApplied),
                    },
                });
            } finally {
                span?.setTag('qlub.ngenius_status', ngeniusResponse?.status ?? PaymentStatus.UNDECIDED);
                span?.finish();
            }
        });
    };

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.CardPay,
            name: t('Card'),
            icon: <CreditCard />,
            buttonElement: (
                <PayButtonElement
                    variant="contained"
                    fullWidth
                    loading={loading}
                    disabled={disable || loading || loadingSdk}
                    onClick={handlePay}
                />
            ),
        });
    }, [isCardDetailsValid, loading, loadingSdk, disable, tip, amount]);

    return (
        <div ref={containerRef}>
            <LoadingDialog open={loading} />
            <div
                id="ngenius-container"
                className={classNames(styles.container, { [styles.containerHide]: loadingSdk })}
            />
            {loadingSdk && <CardSkeleton />}

            {createPortal(
                <div id="ngenius-3ds" ref={threeDsContainerRef} className={styles.iframeContainer} />,
                document.body,
            )}
            {!hasPgGroup && (
                <PayButtonElement
                    variant="contained"
                    fullWidth
                    onClick={handlePay}
                    loading={loading}
                    disabled={disable || loading || loadingSdk}
                    showConfirmText
                />
            )}
        </div>
    );
}
