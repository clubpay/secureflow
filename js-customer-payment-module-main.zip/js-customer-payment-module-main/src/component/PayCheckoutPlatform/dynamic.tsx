/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useEffect, useState } from 'react';
import { isSafari } from '@clubpay/customer-common-module/src/utility/mobile_check';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { applePayJsAvailable } from '../ApplePayButton/utils/handlers';
import PayCheckoutPlatformApple from './applepay';
import PayCheckoutPlatformGoogle from './googlepay';
import PayCheckoutPlatformIframe from './iframe';
import PaymentWrapper from '../PaymentWrapper';
import { ICheckoutPlatformGateway } from '../../repository/type/paymentGateway';

import styles from './index.module.scss';

export interface IProps extends IPGProps {
    config: ICheckoutPlatformGateway;
}

export default function PayCheckoutPlatform({
    name,
    diningSessionID,
    sessionId,
    jwt,
    url,
    amount,
    tip,
    currencyPrecision,
    config,
    disable,
    enableButton,
    gatewayId,
    vendor,
    updateTimestamp,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onPending,
    onOverlayClick,
    onIndicator,
    onLoad,
    onPgRegister,
    onTraceStart,
    isPgElemVisible,
    onPgUnregister,
    onTraceClose,
}: IProps) {
    const [hasApplePay, setHasApplePay] = useState(false);
    const [hasGooglePay, setHasGooglePay] = useState(false);
    const { hasPgGroup } = vendor.paymentGatewayList;

    useEffect(() => {
        applePayJsAvailable().then((enable) => {
            setHasApplePay(enable);
        });

        setHasGooglePay(!isSafari());
    }, [url.cc, url.slug, url.id]);

    return (
        <div className={styles.form}>
            {config?.hideApplePay !== true && hasApplePay && !hasGooglePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.ApplePay)}>
                    <PayCheckoutPlatformApple
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        vendor={vendor}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        onPgUnregister={onPgUnregister}
                        hasPgGroup={hasPgGroup}
                        onTraceClose={onTraceClose}
                    />
                </PaymentWrapper>
            )}
            {config?.hideGooglePay !== true && hasGooglePay && !hasApplePay && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.GooglePay)}>
                    <PayCheckoutPlatformGoogle
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        vendor={vendor}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        onPgUnregister={onPgUnregister}
                        hasPgGroup={hasPgGroup}
                        onTraceClose={onTraceClose}
                    />
                </PaymentWrapper>
            )}
            {config?.hideCardPay !== true && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}>
                    <PayCheckoutPlatformIframe
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        vendor={vendor}
                        enableButton={enableButton}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onOverlayClick={onOverlayClick}
                        onIndicator={onIndicator}
                        onLoad={onLoad}
                        onPgRegister={onPgRegister}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        onTraceClose={onTraceClose}
                    />
                </PaymentWrapper>
            )}
        </div>
    );
}
