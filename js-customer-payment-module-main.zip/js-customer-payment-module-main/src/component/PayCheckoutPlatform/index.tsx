/*
    Creation Time: 2022 - Aug - 30
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import dynamic from 'next/dynamic';
import { Box, CircularProgress } from '@mui/material';
import type { IProps } from './dynamic';

const PayCheckoutPlatform = dynamic<IProps>(() => import('./dynamic'), {
    loading: () => (
        <Box
            sx={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
            }}
        >
            <CircularProgress size={24} />
        </Box>
    ),
    ssr: false,
});

export default PayCheckoutPlatform;
