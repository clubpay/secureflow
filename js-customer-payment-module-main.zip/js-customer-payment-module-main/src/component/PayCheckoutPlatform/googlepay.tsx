/*
    Creation Time: 2022 - July - 19
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useMemo, useRef, useState } from 'react';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import Scripts from 'next/script';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import {
    IPayBeforePaymentHandler,
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { GooglePay } from '@clubpay/customer-common-module/src/component/SVG';
import GooglePayCTA from '../GooglePayCTA';
import { ICheckoutPlatformGateway } from '../../repository/type/paymentGateway';
import PaymentAPIManager from '../../repository';

import styles from './index.module.scss';

interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks {
    config: ICheckoutPlatformGateway;
    hasPgGroup: boolean;
}

let beforeFn: (payload: IPayBeforePaymentHandler) => Promise<boolean>;
let checkoutTotalAmount = 0;
let checkoutTipAmount = 0;

export default function PayCheckoutPlatformGoogle({
    diningSessionID,
    sessionId,
    amount,
    tip,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    name,
    hasPgGroup,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onPending,
    onPgRegister,
    onTraceStart,
    onPgUnregister,
    onTraceClose,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [loading, setLoading] = useState(false);
    const paymentsClientRef = useRef<google.payments.api.PaymentsClient | null>(null);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    beforeFn = onBeforePayment;
    const totalAmount = sumAmounts(currencyPrecision, amount, tip);
    checkoutTotalAmount = totalAmount;
    checkoutTipAmount = tip;

    const baseRequest = {
        apiVersion: 2,
        apiVersionMinor: 0,
    };

    const tokenizationSpecification = {
        type: 'PAYMENT_GATEWAY',
        parameters: {
            gateway: 'checkoutltd',
            gatewayMerchantId: config?.publicKey || '',
        },
    };

    const baseCardPaymentMethod: google.payments.api.IsReadyToPayPaymentMethodSpecification = {
        type: 'CARD',
        parameters: {
            allowedAuthMethods: config?.googleAllowedAuthMethods || ['PAN_ONLY', 'CRYPTOGRAM_3DS'],
            allowedCardNetworks: config?.googleAllowedCardNetworks || ['MASTERCARD', 'VISA'],
        },
    };

    const getGoogleIsReadyToPayRequest = (): google.payments.api.IsReadyToPayRequest => {
        return { ...baseRequest, allowedPaymentMethods: [baseCardPaymentMethod] } as any;
    };

    const getGooglePaymentsClient = () => {
        if (paymentsClientRef.current === null) {
            paymentsClientRef.current = new google.payments.api.PaymentsClient({
                environment: config?.sandbox ? 'TEST' : 'PRODUCTION',
            });
        }
        return paymentsClientRef.current;
    };

    const cardPaymentMethod = { ...baseCardPaymentMethod, tokenizationSpecification };

    const getGoogleTransactionInfo = (): google.payments.api.TransactionInfo => {
        return {
            totalPriceStatus: 'FINAL',
            totalPrice: checkoutTotalAmount.toFixed(currencyPrecision || 0),
            countryCode: config?.countryCode || vendor.country.code || 'AE',
            currencyCode: vendor.country.currencyCode?.toUpperCase() || '',
        };
    };

    const getGooglePaymentDataRequest = (): google.payments.api.PaymentDataRequest => {
        const paymentDataRequest: any = { ...baseRequest };
        paymentDataRequest.allowedPaymentMethods = [cardPaymentMethod];
        paymentDataRequest.transactionInfo = getGoogleTransactionInfo();
        paymentDataRequest.merchantInfo = {
            merchantId: config?.googleMerchantId || '',
            merchantName: 'qlub',
        };
        return paymentDataRequest;
    };

    /**
     * Show Google Pay payment sheet when Google Pay payment button is clicked
     */
    const onGooglePaymentButtonClicked = () => {
        if (disable || loading) {
            return;
        }

        setLoading(true);
        const refId = getRandomString();
        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.GooglePay,
                refId,
            },
        });

        beforeFn({
            gatewayId,
            paymentElement: PaymentElementEnum.GooglePay,
            tip,
        }).then((ok) => {
            if (!ok) {
                setLoading(false);
                return;
            }

            const paymentDataRequest = getGooglePaymentDataRequest();
            paymentDataRequest.transactionInfo = getGoogleTransactionInfo();

            const paymentsClient = getGooglePaymentsClient();
            paymentsClient
                .loadPaymentData(paymentDataRequest)
                .then((paymentData: any) => {
                    // handle the response
                    PaymentAPIManager.getInstance()
                        .paymentCheckoutPlatformPayByGoogle({
                            id: sessionId,
                            diningSessionID,
                            tipAmount: checkoutTipAmount.toFixed(currencyPrecision || 0),
                            googleToken: paymentData.paymentMethodData.tokenizationData.token,
                            reference: refId,
                            gatewayID: gatewayId,
                            cardType: paymentData.paymentMethodData.info?.cardNetwork || '',
                        })
                        .then(() => {
                            onDone({
                                paymentElement: PaymentElementEnum.GooglePay,
                                refId,
                                traceId: traceStart?.traceId,
                            });

                            enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                        })
                        .catch((error: Error | AxiosError) => {
                            onTraceClose?.({
                                error,
                                location: 'paymentCheckoutPlatformPayByGoogle',
                                traceRef,
                                traceStart,
                            });

                            if (checkNetworkError(error as AxiosError)) {
                                onPending({
                                    paymentElement: PaymentElementEnum.GooglePay,
                                    refId,
                                    traceId: traceStart?.traceId,
                                });
                            } else {
                                onFail({
                                    paymentElement: PaymentElementEnum.GooglePay,
                                    refId,
                                    traceId: traceStart?.traceId,
                                });
                            }
                        })
                        .finally(() => {
                            setLoading(false);
                        });
                })
                .catch((err) => {
                    // show error in developer console for debugging
                    console.error(err);
                    setLoading(false);
                    onUnlockPayment();
                });
        });
    };

    const addGooglePayButton = () => {
        const paymentsClient = getGooglePaymentsClient();
        const button = paymentsClient.createButton({
            onClick: onGooglePaymentButtonClicked,
            allowedPaymentMethods: [baseCardPaymentMethod],
            buttonSizeMode: 'fill',
            buttonType: 'pay',
        });
        document.querySelector('#checkout-platform-google-pay')?.appendChild(button);
    };

    const loadScriptHandler = () => {
        const paymentsClient = getGooglePaymentsClient();
        paymentsClient
            .isReadyToPay(getGoogleIsReadyToPayRequest())
            .then((response) => {
                if (response.result) {
                    onPgRegister?.({
                        pgId: gatewayId,
                        elem: PaymentElementEnum.GooglePay,
                        name: 'Google Pay',
                        icon: <GooglePay />,
                        placement: 'bottom',
                    });
                    addGooglePayButton();
                }
            })
            .catch((err) => {
                // show error in developer console for debugging
                onTraceClose?.({
                    error: err,
                    location: 'paymentsClient.isReadyToPay',
                    traceRef,
                    traceStart,
                });

                onPgUnregister?.({
                    pgId: gatewayId,
                    elem: PaymentElementEnum.GooglePay,
                });
            });
    };

    return (
        <div className={styles.payButton}>
            <Scripts src="https://pay.google.com/gp/p/js/pay.js" onReady={loadScriptHandler} />
            <GooglePayCTA id="checkout-platform-google-pay" loading={loading} hasPgGroup={hasPgGroup} />
        </div>
    );
}
