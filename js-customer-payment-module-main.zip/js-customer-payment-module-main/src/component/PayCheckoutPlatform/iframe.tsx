/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useEffect, useMemo, useRef, useState } from 'react';
import Scripts from 'next/script';
import getConfig from 'next/config';
import { CardNumber, Cvv, ExpiryDate, Frames as CheckoutFrames } from 'frames-react';
import { Box, Grid } from '@mui/material';
import { CustomerContainer, CustomerGrid } from '@qlub-dev/qlub-kit';
import { CreditCard, VerifiedUserOutlined } from '@mui/icons-material';
import {
    FrameCardBinChangedEvent,
    FrameCardTokenizationFailedEvent,
    FrameCardTokenizedEvent,
    FramePaymentMethodChangedEvent,
    FrameValidationChangedEvent,
} from 'frames-react/types/types';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { useConfirmCallback, usePaymentTimeout } from '@clubpay/customer-common-module/src/hook/payment';
import { detectRTLFromLang } from '@clubpay/customer-common-module/src/utility/k_lang';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { ICheckoutPlatformGateway } from '../../repository/type/paymentGateway';
import { isCheckoutError, useCheckoutErrors } from '../../hook/checkoutErrors';
import PayButtonElement from '../PayButtonElement';
import { isCardMada } from '../../utility/payment_checkout';
import PaymentAPIManager from '../../repository';
import americanExpressLogo from '../../asset/image/american-express.svg';
import masterCardLogo from '../../asset/image/mastercard.svg';
import visaLogo from '../../asset/image/visa.svg';

import styles from './index.module.scss';

const { publicRuntimeConfig } = getConfig();
const pubKey = process?.env?.NEXT_PUBLIC_CHECKOUT_PUB_KEY || '';

interface IProps extends IPGProps {
    config: ICheckoutPlatformGateway;
}

let checkoutTotalAmount = 0;
let checkoutTipAmount = 0;
let isMada = false;

export default function PayCheckoutPlatformIframe({
    diningSessionID,
    sessionId,
    amount,
    tip,
    name,
    currencyPrecision,
    config,
    disable,
    enableButton,
    gatewayId,
    vendor,
    updateTimestamp,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onPending,
    onOverlayClick,
    onIndicator,
    onLoad,
    onPgRegister,
    onTraceStart,
    onTraceClose,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [cardType, setCardType] = useState('');
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);
    const [scriptsLoaded, setScriptsLoaded] = useState(false);
    const { lang } = useQlubRouter();
    const { timeoutDone } = usePaymentTimeout({
        indicatorTimeout: config?.indicatorTimeout || 0,
        fallbackTimeout: config?.fallbackTimeout || 0,
        indicatorCallback: onIndicator,
        fallbackCallback: onLoad,
    });
    const [frameValidation, setFrameValidation] = useState({
        'card-number': { element: 'card-number', isValid: false, isEmpty: false },
        'expiry-date': { element: 'expiry-date', isValid: false, isEmpty: false },
        cvv: { element: 'cvv', isValid: false, isEmpty: false },
    });
    const { getCallbackUrl } = useConfirmCallback();
    const [componentKey, setComponentKey] = useState(getRandomString());
    const isRtl = useMemo(() => detectRTLFromLang(lang || ''), [lang]);
    const { hasPgGroup } = vendor.paymentGatewayList;
    const buttonRef = useRef<HTMLButtonElement | null>(null);
    const { setErrorType } = useCheckoutErrors();
    const [ref, setRef] = useState(getRandomString());
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);

    const cardNumberChangeHandler = (e: FramePaymentMethodChangedEvent) => {
        setCardType(e.paymentMethod);
    };
    const cardBinChangeHandler = (e: FrameCardBinChangedEvent) => {
        isMada = isCardMada(e.bin);
    };
    const checkoutCardErrorHandler = () => {
        setErrorType(frameValidation);
    };
    const submitHandler = () => {
        const newRef = getRandomString();
        setRef(newRef);

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.CardPay,
                refId: newRef,
            },
        });

        setLoading(true);
        onBeforePayment({
            gatewayId,
            paymentElement: PaymentElementEnum.CardPay,
            tip,
        })
            .then((ok) => {
                if (!ok) {
                    setLoading(false);
                    return;
                }
                checkoutTotalAmount = sumAmounts(currencyPrecision, amount, tip);
                checkoutTipAmount = tip;

                if (CheckoutFrames.isCardValid()) {
                    CheckoutFrames.submitCard();
                } else {
                    checkoutCardErrorHandler();
                    onUnlockPayment();
                    setLoading(false);
                }
            })
            .catch(() => {
                setLoading(false);
            });
    };

    const cardTokenizeHandler = (e: FrameCardTokenizedEvent) => {
        const amountStr = checkoutTotalAmount.toFixed(currencyPrecision || 0);
        const returnUrl = getCallbackUrl({
            ref,
            method: name,
            paymentElement: PaymentElementEnum.CardPay,
            dsi: diningSessionID,
            amount: amountStr,
            currencySymbol: vendor.country.currencySymbol,
            traceId: traceStart?.traceId,
            lang,
        });
        PaymentAPIManager.getInstance()
            .paymentCheckoutPlatformPayByToken({
                id: sessionId,
                reference: ref,
                diningSessionID,
                cardToken: e.token,
                tipAmount: checkoutTipAmount.toFixed(currencyPrecision || 0),
                successUrl: returnUrl.success,
                failureUrl: returnUrl.fail,
                gatewayID: gatewayId,
                cardType: isMada ? 'mada' : '',
            })
            .then((res) => {
                setSuccess(true);
                if (res.data.needVerification) {
                    if (!res.data.redirectUrl) {
                        setErrorType(frameValidation, 'otp');
                    }

                    window.location.href = res.data.redirectUrl;
                } else {
                    onDone({
                        paymentElement: PaymentElementEnum.CardPay,
                        refId: ref,
                        traceId: traceStart?.traceId,
                    });

                    enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                }
            })
            .catch((err) => {
                onTraceClose?.({
                    error: err,
                    location: 'paymentCheckoutPlatformPayByToken',
                    traceRef,
                    traceStart,
                });

                const isNetworkError = checkNetworkError(err as AxiosError);
                const match = isCheckoutError(err?.response?.data?.message);
                if (match) {
                    setErrorType(frameValidation, err?.response?.data?.message);

                    setComponentKey(getRandomString());

                    onUnlockPayment();
                } else if (isNetworkError) {
                    onPending({
                        paymentElement: PaymentElementEnum.CardPay,
                        refId: ref,
                        traceId: traceStart?.traceId,
                    });
                } else {
                    onFail({
                        paymentElement: PaymentElementEnum.CardPay,
                        refId: ref,
                        traceId: traceStart?.traceId,
                    });
                }
            })
            .finally(() => {
                setLoading(false);
            });
    };

    const cardTokenizeFailedHandler = (e: FrameCardTokenizationFailedEvent) => {
        enqueueSnackbar(`${e.errorCode} ${e.message}`, { variant: 'error' });
        setLoading(false);
    };

    const buttonElement = useMemo(() => {
        return (
            <PayButtonElement
                variant="contained"
                size="large"
                disabled={disable || loading || success}
                onClick={submitHandler}
                fullWidth
                id="checkout-action-btn"
                loading={loading}
                ref={buttonRef}
                showConfirmText={!hasPgGroup}
            />
        );
    }, [tip, disable, loading, success, lang, updateTimestamp, JSON.stringify(frameValidation)]);

    const loadScriptHandler = () => {
        onPgRegister?.({
            pgId: gatewayId,
            name: t('Card'),
            icon: <CreditCard />,
            elem: PaymentElementEnum.CardPay,
            buttonElement,
        });
        setScriptsLoaded(true);
        timeoutDone();
        onUnlockPayment();
    };

    const frameValidationChangeHandler = (e: FrameValidationChangedEvent) => {
        setFrameValidation((prevState) => ({ ...prevState, [e.element]: { ...e } }));
    };

    useEffect(() => {
        setComponentKey(getRandomString());
    }, [lang]);

    useEffect(() => {
        if (!scriptsLoaded) {
            return;
        }
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.CardPay,
            name: t('Card'),
            icon: <CreditCard />,
            buttonElement,
        });
    }, [lang, buttonElement, updateTimestamp, scriptsLoaded, componentKey]);

    return (
        <>
            <Scripts src="https://cdn.checkout.com/js/framesv2.min.js" onReady={loadScriptHandler} />
            {scriptsLoaded && (
                <CheckoutFrames
                    key={componentKey}
                    config={{
                        publicKey: config?.publicKey || publicRuntimeConfig.checkoutPublicKey || pubKey,
                        localization: {
                            cardNumberPlaceholder: t('Card Number'),
                            expiryMonthPlaceholder: t('MM'),
                            expiryYearPlaceholder: t('YY'),
                            cvvPlaceholder: t('CVV'),
                        },
                        style: {
                            base: {
                                fontSize: '18px',
                            },
                        },
                        modes: isRtl ? ['right_to_left'] : undefined,
                    }}
                    paymentMethodChanged={cardNumberChangeHandler}
                    cardBinChanged={cardBinChangeHandler}
                    cardTokenized={(e) => cardTokenizeHandler(e)}
                    cardTokenizationFailed={cardTokenizeFailedHandler}
                    frameValidationChanged={frameValidationChangeHandler}
                >
                    <CustomerContainer padding="1rem 0.5rem 3rem" className={styles.cardContainer}>
                        {!enableButton && <div className={styles.cardOverlay} onClick={onOverlayClick} />}
                        <CustomerGrid spacing={1}>
                            <Grid item xs={7}>
                                <CardNumber className={styles.cardNumber} />
                            </Grid>
                            <Grid item xs={3}>
                                <ExpiryDate className={styles.expiryDate} />
                            </Grid>
                            <Grid item xs={2}>
                                <Cvv className={styles.cvv} />
                            </Grid>
                        </CustomerGrid>
                        <Grid item xs={12}>
                            <div className={styles.cards}>
                                <img
                                    src={visaLogo.src}
                                    alt="visa"
                                    className={cardType === 'Visa' ? styles.selected : undefined}
                                />
                                <img
                                    src={masterCardLogo.src}
                                    alt="master card"
                                    className={cardType === 'Mastercard' ? styles.selected : undefined}
                                />
                                <img
                                    src={americanExpressLogo.src}
                                    alt="american express"
                                    className={cardType === 'American Express' ? styles.selected : undefined}
                                />
                            </div>
                        </Grid>
                        <div className={styles.secureWrapper}>
                            <div className={styles.secureIcon}>
                                <VerifiedUserOutlined />
                            </div>
                            <div className={styles.secureText}>
                                {vendor.config.hideLogo
                                    ? t('100% Secure payments')
                                    : t('100% Secure payments powered by Qlub_')}
                            </div>
                        </div>
                    </CustomerContainer>
                    {enableButton && !hasPgGroup && <Box className={styles.submit}>{buttonElement}</Box>}
                </CheckoutFrames>
            )}
        </>
    );
}
