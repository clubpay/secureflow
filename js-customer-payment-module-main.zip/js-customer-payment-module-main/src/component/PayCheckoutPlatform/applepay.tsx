/*
    Creation Time: 2021 - Sep - 26
    Created by:  (hamidrezakk)
    Maintainers:
       1.  HamidrezaKK (hamidrezakks@gmail.com)
    Auditor: HamidrezaKK
    Copyright Qlub_ 2022
*/

import React, { useCallback, useMemo, useRef, useState } from 'react';
import Scripts from 'next/script';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { sumAmounts } from '@clubpay/customer-common-module/src/utility/k_math';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { Apple } from '@mui/icons-material';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError, AxiosError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { ICheckoutPlatformGateway } from '../../repository/type/paymentGateway';
import { ApplePayButton } from '../ApplePayButton';
import PaymentAPIManager from '../../repository';

import styles from './index.module.scss';

interface IProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks {
    config: ICheckoutPlatformGateway;
    hasPgGroup: boolean;
}

export default function PayCheckoutPlatformApple({
    diningSessionID,
    sessionId,
    amount,
    tip,
    name,
    currencyPrecision,
    config,
    disable,
    gatewayId,
    vendor,
    hasPgGroup,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onPending,
    onPgRegister,
    onTraceStart,
    onTraceClose,
}: IProps) {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar } = snackBar();
    const [loading, setLoading] = useState(false);
    const [scriptsLoaded, setScriptsLoaded] = useState(false);
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const totalAmount = sumAmounts(currencyPrecision, amount, tip);

    const payHandler = useCallback(() => {
        if (!ApplePaySession) {
            return;
        }

        // Define ApplePayPaymentRequest
        const request: ApplePayJS.ApplePayPaymentRequest = {
            countryCode: config?.countryCode || vendor.country.code || 'AE',
            currencyCode: vendor.country.currencyCode?.toUpperCase() || '',
            merchantCapabilities: (config?.merchantCapabilitiesList as any) ||
                (config?.merchantCapabilities as any) || ['supports3DS'],
            supportedNetworks: (config?.supportedNetworksList as any) ||
                (config?.supportedNetworks as any) || ['visa', 'masterCard', 'amex', 'discover'],
            total: {
                label: 'Qlub_',
                type: 'final',
                amount: totalAmount.toFixed(currencyPrecision || 0),
            },
        };

        console.log({ request });

        const refId = getRandomString();
        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.ApplePay,
                refId,
            },
        });

        try {
            // Create ApplePaySession
            const session: ApplePaySession = new ApplePaySession(config?.appleSDKVersion || 3, request);

            session.onvalidatemerchant = (e) => {
                console.log({ onvalidatemerchant: e });
                // Call your own server to request a new merchant session.
                onBeforePayment({
                    gatewayId,
                    paymentElement: PaymentElementEnum.ApplePay,
                    tip,
                })
                    .then((ok) => {
                        if (!ok) {
                            return;
                        }
                        setLoading(true);
                        PaymentAPIManager.getInstance()
                            .paymentCheckoutPlatformValidateApplePaySession({
                                diningSessionID,
                                applePayUrl: e.validationURL,
                                gatewayID: gatewayId,
                                hostname: window.location.hostname,
                            })
                            .then((res) => {
                                console.log({ res }, JSON.parse(res.data.jsonData));
                                session.completeMerchantValidation(JSON.parse(res.data.jsonData));
                            })
                            .catch(() => {
                                try {
                                    session?.abort();
                                } catch (err) {
                                    console.log(err);
                                }
                                onUnlockPayment();
                            })
                            .finally(() => {
                                setLoading(false);
                            });
                    })
                    .catch(() => {
                        setLoading(false);
                    });
            };

            session.onpaymentmethodselected = (e) => {
                // Define ApplePayPaymentMethodUpdate based on the selected payment method.
                // No updates or errors are needed, pass an empty object.
                const update: ApplePayJS.ApplePayPaymentMethodUpdate = {
                    newTotal: {
                        label: 'Qlub_',
                        type: 'final',
                        amount: totalAmount.toFixed(currencyPrecision || 0),
                    },
                };
                session.completePaymentMethodSelection(update);
                console.log({ onpaymentmethodselected: e });
            };

            session.onshippingmethodselected = (e) => {
                // Define ApplePayShippingMethodUpdate based on the selected shipping method.
                // No updates or errors are needed, pass an empty object.
                const update: any = {};
                session.completeShippingMethodSelection(update);
                console.log({ onshippingmethodselected: e });
            };

            session.onshippingcontactselected = (e) => {
                // Define ApplePayShippingContactUpdate based on the selected shipping contact.
                const update: any = {};
                session.completeShippingContactSelection(update);
                console.log({ onshippingcontactselected: e });
            };

            session.onpaymentauthorized = (e) => {
                setLoading(true);

                PaymentAPIManager.getInstance()
                    .paymentCheckoutPlatformPayByApple({
                        id: sessionId,
                        diningSessionID,
                        tipAmount: tip.toFixed(currencyPrecision || 0),
                        appleToken: JSON.stringify(e.payment?.token || {}),
                        reference: refId,
                        gatewayID: gatewayId,
                        cardType: e.payment?.token?.paymentMethod?.network || '',
                        hostname: window.location.hostname,
                    })
                    .then(() => {
                        const result: ApplePayJS.ApplePayPaymentAuthorizationResult = {
                            status: ApplePaySession.STATUS_SUCCESS,
                        };
                        try {
                            session.completePayment(result);
                        } catch (err) {
                            console.log(err);
                        }

                        onDone({
                            paymentElement: PaymentElementEnum.ApplePay,
                            refId,
                            traceId: traceStart?.traceId,
                        });

                        enqueueSnackbar(t('Successfully Paid!'), { variant: 'success' });
                    })
                    .catch((err: Error | AxiosError) => {
                        onTraceClose?.({
                            error: err,
                            location: 'paymentCheckoutPlatformPayByApple',
                            traceRef,
                            traceStart,
                        });

                        // Define ApplePayPaymentAuthorizationResult
                        const result: ApplePayJS.ApplePayPaymentAuthorizationResult = {
                            status: ApplePaySession.STATUS_FAILURE,
                        };
                        try {
                            session.completePayment(result);
                        } catch (error) {
                            console.log(error);
                        }

                        if (checkNetworkError(err as AxiosError)) {
                            onPending({
                                paymentElement: PaymentElementEnum.ApplePay,
                                refId,
                                traceId: traceStart?.traceId,
                            });
                        } else {
                            onFail({
                                paymentElement: PaymentElementEnum.ApplePay,
                                refId,
                                traceId: traceStart?.traceId,
                            });
                        }

                        console.log({ onpaymentauthorized: e, err });
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            };

            session.oncancel = (e: any) => {
                // Payment cancelled by WebKit
                setLoading(false);
                console.log({ oncancel: e });
            };

            session.begin();
        } catch (e) {
            console.warn({ applePay: e });
            onUnlockPayment();
        }
    }, [amount, tip, scriptsLoaded, onBeforePayment]);

    const loadScriptHandler = () => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.ApplePay,
            name: 'Apple Pay',
            icon: <Apple />,
            placement: 'bottom',
        });
        setScriptsLoaded(true);
    };

    return (
        <div className={styles.payButton}>
            <Scripts src="/pg_sdk/apple-pay-sdk.js" onReady={loadScriptHandler} />
            <div className={styles.container} data-area="submit">
                <ApplePayButton
                    onClick={payHandler}
                    theme="dark"
                    disabled={disable || loading}
                    id="checkout-applepay-action-btn"
                    hasPgGroup={hasPgGroup}
                />
            </div>
        </div>
    );
}
