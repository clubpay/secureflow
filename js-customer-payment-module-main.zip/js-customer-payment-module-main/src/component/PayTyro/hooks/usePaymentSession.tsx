import { ITyroGateway } from '../../../repository/type/paymentGateway';

interface PaymentSessionConfig {
    session: string;
    fields: any;
    frameEmbeddingMitigation: string[];
    callbacks: any;
    interaction: any;
    locale: string;
}

const usePaymentSession = (qlubConfig: ITyroGateway) => {
    const generateScriptUrlWithEnv = () => {
        const env = (qlubConfig?.env?.toUpperCase() as 'PROD' | 'TEST') || 'PROD';
        const params = {
            debug: qlubConfig?.env?.toUpperCase() === 'TEST' ? 'true' : 'false',
        };

        const sdkUrl =
            process.env.NEXT_PUBLIC_TYRO_SDK_URL ||
            (env === 'PROD'
                ? 'https://tyro.gateway.mastercard.com/form/version/81/merchant/'
                : 'https://test-tyro.mtf.gateway.mastercard.com/form/version/81/merchant/');

        const url = new URL(`${qlubConfig.merchantId}/session.js`, sdkUrl);
        url.search = new URLSearchParams(params).toString();

        return url.toString();
    };

    const generateSession = async (config: PaymentSessionConfig) => {
        const scriptSrc = generateScriptUrlWithEnv();

        const loadScript = () => {
            return new Promise((resolve, reject) => {
                const existingScript = document.querySelector(`script[src*="${scriptSrc}"]`);
                if (existingScript) {
                    existingScript.remove();
                    window.PaymentSession = undefined;
                }

                const scriptElement = document.createElement('script');
                scriptElement.src = scriptSrc;
                scriptElement.onload = resolve;
                scriptElement.onerror = reject;
                document.body.appendChild(scriptElement);
            });
        };

        // PaymentSession object not available yet, wait for the script to load
        return loadScript()
            .then(() => {
                if (window.PaymentSession && typeof window.PaymentSession.configure === 'function') {
                    window.PaymentSession.configure(config);
                } else {
                    console.error('PaymentSession object is not available after script loading.');
                }
            })
            .catch((error) => {
                console.error('Failed to load PaymentSession script:', error);
            });
    };

    return { generateSession };
};

export default usePaymentSession;
