import { CustomerContainer, CustomerDrawer, CustomerGrid } from '@qlub-dev/qlub-kit';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Box, Grid, Skeleton } from '@mui/material';
import { useConfirmCallback } from '@clubpay/customer-common-module/src/hook/payment';
import { getRandomString } from '@clubpay/customer-common-module/src/utility/random';
import { useQlubRouter } from '@clubpay/customer-common-module/src/hook/router';
import { IStartSpanResponse } from '@clubpay/customer-common-module/src/hook/useSentryTrace';
import { checkNetworkError } from '@clubpay/customer-common-module/src/utility/checkNetworkError';
import { CreditCard } from '@mui/icons-material';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { parseJSON } from '@clubpay/customer-common-module/src/utility/k_json';
import { LOCK_OVERLAY_Z_INDEX } from '@clubpay/customer-common-module/src/const';
import {
    IPGBaseProps,
    IPGHooks,
    IPGStateCallbacks,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { FormSessionResponse, ResponseStatus } from '../../types';
import useTyroError from '../../hooks/useTyroError';
import { usePaymentError } from '../../../../hook/paymentError';
import usePaymentSession from '../../hooks/usePaymentSession';
import { useEventListener } from '../../hooks/useEventListener';
import { ITyroGateway } from '../../../../repository/type/paymentGateway';
import PaymentAPIManager from '../../../../repository';
import Input from './Input';
import PayButtonElement from '../../../PayButtonElement';

import styles from './index.module.scss';
import { getCardNetworkIcons } from '../../../../utility/payment';

export interface ICardFormProps extends IPGBaseProps, IPGHooks, IPGStateCallbacks {
    tyroSessionId: string;
    setTyroSessionId: (sessionId: string) => void;
    config: ITyroGateway;
}

const Card = ({
    disable,
    diningSessionID,
    sessionId,
    gatewayId,
    tip,
    config,
    name,
    currencyPrecision,
    amount,
    vendor,
    onTraceStart,
    tyroSessionId,
    setTyroSessionId,
    onDone,
    onFail,
    onPending,
    updateTimestamp,
    onBeforePayment,
    onTraceClose,
    onPgRegister,
    onUnlockPayment,
}: ICardFormProps) => {
    const [loading, setLoading] = useState(false);
    const { lang } = useQlubRouter();
    const { handleError, showError, errorTranslations } = useTyroError();
    const traceStart = useMemo(() => onTraceStart?.(gatewayId), []);
    const { showError: showPaymentError } = usePaymentError();
    const traceRef = useRef<IStartSpanResponse | undefined>(undefined);
    const { t } = useTranslation('common');
    const [iframeHtml, setIframeHtml] = useState<string | undefined>(undefined);
    const [open3DS, setOpen3DS] = useState(false);
    const [refId, setRefId] = useState<string>(getRandomString());
    const [showInputs, setShowInputs] = useState(false);
    const [containerKey, setContainerKey] = useState(1);
    const { hasPgGroup } = vendor.paymentGatewayList;

    const onBeforeRef = useRef(onBeforePayment);
    const tipRef = useRef(tip);

    const { getCallbackUrl } = useConfirmCallback();

    useEventListener({ type: 'message', element: window, listener: handle3DSResponse });

    function handle3DSResponse(event: Event) {
        const { data } = event as MessageEvent;
        if (!data) {
            return;
        }
        const threeDsData = parseJSON(data) as { result: string };
        if (!threeDsData || !threeDsData.result) {
            return;
        }

        const { result } = threeDsData;

        setOpen3DS(false);
        setIframeHtml(undefined);

        if (result !== 'SUCCESS') {
            onFail({
                paymentElement: PaymentElementEnum.CardPay,
                refId,
                traceId: traceStart?.traceId,
            });
            return;
        }

        PaymentAPIManager.getInstance()
            .payTyroAuthorize({ tyroSessionId })
            .then((response) => {
                switch (response.data.status) {
                    case 'success':
                        onDone({
                            paymentElement: PaymentElementEnum.CardPay,
                            refId,
                            traceId: traceStart?.traceId,
                        });
                        break;
                    case 'pending':
                    default:
                        onPending({
                            paymentElement: PaymentElementEnum.CardPay,
                            refId,
                            traceId: traceStart?.traceId,
                        });
                        break;
                }
            })
            .catch(() => {
                onFail({
                    paymentElement: PaymentElementEnum.CardPay,
                    refId,
                    traceId: traceStart?.traceId,
                });
            });
    }

    const { generateSession } = usePaymentSession(config);

    const getSession = async () => {
        setContainerKey((o) => o + 1);
        setShowInputs(false);
        await generateSession({
            session: tyroSessionId,
            fields: {
                card: {
                    number: '#card-number',
                    securityCode: '#security-code',
                    expiryMonth: '#expiry-month',
                    expiryYear: '#expiry-year',
                },
            },
            frameEmbeddingMitigation: ['javascript', 'x-frame-options', 'csp'],
            locale: lang || 'en',
            callbacks: {
                initialized() {
                    handleEvents();
                    setShowInputs(true);
                },
                formSessionUpdate(response: FormSessionResponse) {
                    if (response?.status === ResponseStatus.OK) {
                        const { session } = response;
                        setTyroSessionId(session.id);
                        if (!response.sourceOfFunds.provided.card.securityCode) {
                            showError(errorTranslations.ERROR_IN_FIELDS.securityCode!.missing);
                            setLoading(false);
                            return;
                        }

                        makeQlubPayment({
                            cardBrand: response.sourceOfFunds.provided.card.scheme,
                            sessId: session.id,
                        });
                    } else {
                        setLoading(false);
                        handleError(response);
                    }
                },
            },
            interaction: {
                displayControl: {
                    formatCard: 'EMBOSSED',
                    invalidFieldCharacters: 'REJECT',
                },
            },
        });
    };

    useEffect(() => {
        getSession();
    }, [tyroSessionId]);

    useEffect(() => {
        onPgRegister?.({
            pgId: gatewayId,
            elem: PaymentElementEnum.CardPay,
            name: t('Card'),
            icon: <CreditCard />,
            buttonElement: buttonElement(),
        });
    }, [disable, loading, updateTimestamp, tip, amount]);

    const buttonElement = () => {
        return (
            <PayButtonElement
                variant="contained"
                size="large"
                disabled={disable || loading}
                onClick={() => pay()}
                fullWidth
                id="tyro-action-btn"
                loading={loading}
                showConfirmText={!hasPgGroup}
            />
        );
    };

    const makeQlubPayment = ({ cardBrand, sessId }: { cardBrand: string; sessId: string }) => {
        const ref = getRandomString();
        setRefId(ref);

        traceRef.current = traceStart?.startSpan({
            dataName: name,
            span: {
                element: PaymentElementEnum.CardPay,
                refId: ref,
            },
        });

        const returnUrl = getCallbackUrl({
            ref,
            method: name,
            paymentElement: PaymentElementEnum.CardPay,
            dsi: diningSessionID,
            amount,
            currencySymbol: vendor.country.currencySymbol,
            traceId: traceStart?.traceId,
            lang,
        });

        onBeforeRef
            .current({
                gatewayId,
                paymentElement: PaymentElementEnum.ApplePay,
                tip: tipRef.current,
            })
            .then((ok) => {
                if (!ok) {
                    setLoading(false);
                    return;
                }

                PaymentAPIManager.getInstance()
                    .payTyroPay({
                        id: sessionId,
                        diningSessionID,
                        cardBrand,
                        billingCountry: vendor.country.code,
                        failureUrl: returnUrl.fail,
                        gatewayID: gatewayId,
                        tyroSessionId: sessId,
                        reference: ref,
                        successUrl: returnUrl.success,
                        tipAmount: tipRef.current.toFixed(currencyPrecision || 0),
                    })
                    .then((res) => {
                        if (res.data.needVerification) {
                            if (!res.data.redirectUrl && !res.data.redirectHtml) {
                                showPaymentError();
                                setLoading(false);
                                return;
                            }

                            if (res.data.redirectHtml) {
                                setIframeHtml(res.data.redirectHtml);
                                setOpen3DS(true);
                            } else if (res.data.redirectUrl) {
                                window.location.href = res.data.redirectUrl;
                            } else {
                                showPaymentError();
                                setLoading(false);
                            }
                        } else {
                            onDone({
                                paymentElement: PaymentElementEnum.CardPay,
                                refId: ref,
                                traceId: traceStart?.traceId,
                            });
                        }
                    })
                    .catch((err) => {
                        onTraceClose?.({
                            error: err,
                            location: 'paymentTyroPayByCard',
                            traceRef,
                            traceStart,
                        });

                        const isNetworkError = checkNetworkError(err);

                        if (isNetworkError) {
                            onPending({
                                paymentElement: PaymentElementEnum.CardPay,
                                refId: ref,
                                traceId: traceStart?.traceId,
                            });
                        } else {
                            onFail({
                                paymentElement: PaymentElementEnum.CardPay,
                                refId: ref,
                                traceId: traceStart?.traceId,
                            });
                        }
                    })
                    .finally(() => {
                        setLoading(false);
                    });
            });
    };

    const pay = () => {
        setLoading(true);
        window.PaymentSession?.updateSessionFromForm('card');
    };

    const handleEvents = () => {
        window.PaymentSession?.setFocusStyle(
            ['card.number', 'card.securityCode', 'card.expiryYear', 'card.expiryMonth'],
            {
                outline: '0',
                borderColor: 'hsla(210, 96%, 45%, 50%)',
                boxShadow:
                    '0px 1px 1px rgba(0, 0, 0, 0.03), 0px 3px 6px rgba(0, 0, 0, 0.02), 0 0 0 3px hsla(210, 96%, 45%, 25%), 0 1px 1px 0 rgba(0, 0, 0, 0.08)',
            },
        );
    };

    useEffect(() => {
        if (!open3DS || !iframeHtml) return;

        const script = document.getElementById('authenticate-payer-script') as HTMLScriptElement;
        if (script) {
            // eslint-disable-next-line no-eval
            eval(script.text);
        }
    }, [open3DS, iframeHtml]);

    useEffect(() => {
        onBeforeRef.current = onBeforePayment;
        tipRef.current = tip;
    }, [amount, tip]);

    return (
        <>
            <CustomerContainer className={styles.formContainer}>
                <CustomerGrid key={containerKey} container spacing={1} sx={{ display: showInputs ? 'flex' : 'none' }}>
                    <Grid item xs={12}>
                        <Input
                            title="card number"
                            id="card-number"
                            ariaLabel="enter your card number"
                            placeholder="1234 1234 1234 1234"
                            label={t('Card Number')}
                        />

                        <div className={styles.cardIcons}>
                            {getCardNetworkIcons(config.supportedNetworksList ?? config.supportedNetworks)}
                        </div>
                    </Grid>
                    <Grid item xs={6}>
                        <Input
                            title="expiry month"
                            id="expiry-month"
                            ariaLabel="enter expiry month"
                            placeholder="MM"
                            label={t('Expiry Month')}
                        />
                    </Grid>
                    <Grid item xs={6}>
                        <Input
                            title="expiry year"
                            id="expiry-year"
                            ariaLabel="enter expiry year"
                            placeholder="YY"
                            label={t('Expiry Year')}
                        />
                    </Grid>
                    <Grid item xs={12}>
                        <Input
                            title="security code"
                            id="security-code"
                            ariaLabel="enter security code"
                            placeholder="123"
                            label={t('Security Code')}
                        />
                    </Grid>
                </CustomerGrid>
                {!showInputs && (
                    <>
                        <Skeleton height="64px" width="100%" />
                        <Box display="flex" gap={1}>
                            <Skeleton height="64px" width="50%" />
                            <Skeleton height="64px" width="50%" />
                        </Box>
                        <Skeleton height="64px" width="100%" />
                    </>
                )}
            </CustomerContainer>
            {open3DS && iframeHtml && (
                <CustomerDrawer
                    disablePortal
                    open={open3DS}
                    sx={{ zIndex: LOCK_OVERLAY_Z_INDEX + 1 }}
                    onClose={() => {
                        setOpen3DS(false);
                        onUnlockPayment();
                    }}
                    classes={{
                        root: '3ds-modal',
                    }}
                    headerTitle="3D Secure"
                >
                    <div>
                        <div id="3ds-modal" className={styles.modal} dangerouslySetInnerHTML={{ __html: iframeHtml }} />
                    </div>
                </CustomerDrawer>
            )}
            {!hasPgGroup && buttonElement()}
        </>
    );
};
export default Card;
