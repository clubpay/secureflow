/* eslint-disable no-empty */
import React, { useEffect, useState } from 'react';
import { IPGProps, PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { useAuth } from '@clubpay/customer-common-module/src/context/auth';
import { isSafari } from '@clubpay/customer-common-module/src/utility/mobile_check';
import PaymentAPIManager from '../../repository';
import Card from './components/Card';
import PaymentWrapper from '../PaymentWrapper';
import { applePayJsAvailable } from '../ApplePayButton/utils/handlers';
import { ITyroGateway } from '../../repository/type/paymentGateway';
import GooglePay from './components/GooglePay';
import ApplePay from './components/ApplePay';

export interface IProps extends IPGProps {
    config: ITyroGateway;
}

const PayMashreq = ({
    amount,
    disable,
    diningSessionID,
    sessionId,
    jwt,
    gatewayId,
    config,
    vendor,
    tip,
    currencyPrecision,
    onBeforePayment,
    onUnlockPayment,
    onDone,
    onFail,
    onPending,
    onTraceStart,
    onTraceClose,
    name,
    onPgRegister,
    url,
    isPgElemVisible,
    updateTimestamp,
    onPgUnregister,
}: IProps) => {
    const [tyroSessionId, setTyroSessionId] = useState('');
    const { hasPgGroup } = vendor.paymentGatewayList;

    const [hasApplePay, setHasApplePay] = useState(false);
    const [hasGooglePay, setHasGooglePay] = useState(false);

    const { login, isLogin } = useAuth();
    useEffect(() => {
        if (!isLogin) {
            login({ guest: true });
        }
    }, [isLogin]);

    useEffect(() => {
        applePayJsAvailable().then((enable) => {
            setHasApplePay(enable);
        });
        setHasGooglePay(!isSafari());
    }, [url.cc, url.slug, url.id]);

    useEffect(() => {
        const generateSession = async () => {
            try {
                const response = await PaymentAPIManager.getInstance().generateSessionTyro({
                    diningSessionID,
                    gatewayID: gatewayId,
                });
                setTyroSessionId(response.data.sessionId);
            } catch (_) {}
        };

        generateSession();
    }, []);

    return (
        <div>
            {config?.hideApplePay !== true && hasApplePay && tyroSessionId && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.ApplePay)}>
                    <ApplePay
                        tyroSessionId={tyroSessionId}
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        vendor={vendor}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        onPgUnregister={onPgUnregister}
                        hasPgGroup={hasPgGroup}
                    />
                </PaymentWrapper>
            )}

            {config?.hideGooglePay !== true && hasGooglePay && tyroSessionId && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.GooglePay)}>
                    <GooglePay
                        name={name}
                        diningSessionID={diningSessionID}
                        sessionId={sessionId}
                        jwt={jwt}
                        url={url}
                        amount={amount}
                        tip={tip}
                        currencyPrecision={currencyPrecision}
                        config={config}
                        gatewayId={gatewayId}
                        disable={disable}
                        vendor={vendor}
                        tyroSessionId={tyroSessionId}
                        onBeforePayment={onBeforePayment}
                        onUnlockPayment={onUnlockPayment}
                        onDone={onDone}
                        onFail={onFail}
                        onPending={onPending}
                        onPgRegister={onPgRegister}
                        updateTimestamp={updateTimestamp}
                        onTraceStart={onTraceStart}
                        hasPgGroup={hasPgGroup}
                        onPgUnregister={onPgUnregister}
                        onTraceClose={onTraceClose}
                    />
                </PaymentWrapper>
            )}
            {config?.hideCardPay !== true && (
                <PaymentWrapper hasPgGroup={hasPgGroup} visible={isPgElemVisible?.(PaymentElementEnum.CardPay)}>
                    {tyroSessionId && (
                        <Card
                            tyroSessionId={tyroSessionId}
                            disable={disable}
                            config={config}
                            vendor={vendor}
                            amount={amount}
                            tip={tip}
                            gatewayId={gatewayId}
                            diningSessionID={diningSessionID}
                            sessionId={sessionId}
                            jwt={jwt}
                            onBeforePayment={onBeforePayment}
                            currencyPrecision={currencyPrecision}
                            name={name}
                            url={url}
                            onPending={onPending}
                            onPgRegister={onPgRegister}
                            onTraceStart={onTraceStart}
                            onTraceClose={onTraceClose}
                            onFail={onFail}
                            onDone={onDone}
                            onUnlockPayment={onUnlockPayment}
                            setTyroSessionId={setTyroSessionId}
                        />
                    )}
                </PaymentWrapper>
            )}
        </div>
    );
};

export default PayMashreq;
