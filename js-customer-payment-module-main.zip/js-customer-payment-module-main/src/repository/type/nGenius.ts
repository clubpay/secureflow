import { PaymentExchangeDecision } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IExchangeData } from '@clubpay/customer-common-module/src/repository/vendor';
import { CSSProperties } from 'react';

export enum PaymentStatus {
    AUTHORISED = 'AUTHORISED',
    CAPTURED = 'CAPTURED',
    ERROR = 'ERROR',
    FAILED = 'FAILED',
    PURCHASED = 'PURCHASED',
    THREE_DS_FAILURE = '3DS_FAILURE',
    THREE_DS_SUCCESS = '3DS_SUCCESS',
    UNDECIDED = 'UNDECIDED', // this is custom status, not related to sdk status
}

type ValidatEvent = {
    isCVVValid: boolean;
    isExpiryValid: boolean;
    isNameValid: boolean;
    isPanValid: boolean;
};

type Options = {
    style?: {
        main?: CSSProperties;
        base?: CSSProperties & { fontUrl?: string };
        input?: CSSProperties & { fontUrl?: string };
        invalid?: CSSProperties & { fontUrl?: string };
    };
    apiKey: string;
    hostedSessionApiKey?: string;
    outletRef: string;
    onSuccess?: () => void;
    onFail?: () => void;
    onChangeValidStatus?: (e: ValidatEvent) => void;
};

declare global {
    interface Window {
        NI?: {
            generateSessionId: () => Promise<{ session_id: string }>;
            mountCardInput: (mountPoint: string, options: Options) => void;
            handlePaymentResponse: (
                paymentResponse: any,
                options: {
                    mountId: string;
                    style?: CSSProperties;
                },
            ) => Promise<{ status: PaymentStatus; error: string }>;
        };
    }
}

export interface INGeniusPayByApplePayPayload {
    appleToken: string;
    shippingContact?: ApplePayJS.ApplePayPaymentContact;
    billingContact?: ApplePayJS.ApplePayPaymentContact;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
    hostname: string;
    isSplitPayment: boolean;
    exchangeDecision: PaymentExchangeDecision;
}

export interface INGeniusValidateApplePayPayload {
    applePayUrl: string;
    diningSessionID: string;
    gatewayID: string;
}

export interface INGeniusDetails {
    cardApproved: boolean;
    needVerification: boolean;
    redirectUrl: string;
    paidAmount: string;
    exchangeData: IExchangeData;
}

export interface INGeniusPayByCardPayload {
    id: string;
    diningSessionID: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    sessionId?: string;
    successUrl: string;
    failureUrl: string;
    isSplitPayment: boolean;
    exchangeDecision: PaymentExchangeDecision;
}

export interface INGeniusPayByCardResponse {
    _id: string;
    _links: {
        self: {
            href: string;
        };
        'cnp:3ds': {
            href: string;
        };
        curies: {
            name: string;
            href: string;
            templated: boolean;
        }[];
    };
    reference: string;
    paymentMethod: {
        expiry: string;
        cardholderName: string;
        name: string;
        cardType: string;
        cardCategory: string;
        issuingCountry: string;
        pan: string;
        cvv: string;
    };
    state: string;
    amount: {
        currencyCode: string;
        value: number;
    };
    updateDateTime: string;
    outletId: string;
    orderReference: string;
    authenticationCode: string;
    originIp: string;
    '3ds': {
        acsUrl: string;
        acsPaReq: string;
        acsMd: string;
        summaryText: string;
    };
    exchangeData: IExchangeData;
}

export interface INGeniusCapturePayload {
    id: string;
    diningSessionID: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    sessionId?: string;
    paymentURL: string;
    exchangeDecision: PaymentExchangeDecision;
}
export interface INGeniusCaptureResponse {
    Success: boolean;
    ReturnUrl: string;
}
