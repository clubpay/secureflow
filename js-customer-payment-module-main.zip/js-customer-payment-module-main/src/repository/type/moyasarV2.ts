export interface IMoyasarV2PayByApplePayload {
    appleToken: string;
    shippingContact?: ApplePayJS.ApplePayPaymentContact;
    billingContact?: ApplePayJS.ApplePayPaymentContact;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
    hostname: string;
}

export interface IMoyasarV2ValidateApplePayload {
    validation_url: string;
    display_name: string;
    domain_name: string;
    publishable_api_key?: string;
}

export interface IMoyasarV2Details {
    cardApproved: boolean;
    needVerification: boolean;
    redirectUrl: string;
    paidAmount: string;
}
