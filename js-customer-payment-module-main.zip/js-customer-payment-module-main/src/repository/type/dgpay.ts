export interface IDGPayGet3DSSessionPayload {
    successUrl: string;
    failureUrl: string;
    diningSessionID: string;
    id: string;
    orderID: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
}

export interface IDGPayGet3DSSessionResponse {
    threeDSessionID: string;
    billAmount: string;
    totalAmount: string;
}
