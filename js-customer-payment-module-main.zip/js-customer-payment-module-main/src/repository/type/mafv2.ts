/*
 * Creation Time: June 19 - 2023
 * Created By: yasincelebi
 * Name: mafv2.ts
 * Copyright 2023 customer-web-app
 */

import ApplePayPaymentContact = ApplePayJS.ApplePayPaymentContact;

export interface IMafV2PaymentPayload {
    diningSessionID: string;
    gatewayID: string;
    id: string;
    reference: string;
    tipAmount: string;
    cardToken: string;
    successURL: string;
    failureURL: string;
    customerEmail: string;
    cardBin: string;
    cardBrand: string;
}

export interface IMafV2PaymentResponse {
    responseMessage: string;
    responseCode: string;
    threeDsAuthId: string;
    orderReference: string;
    transactionReference: string;
    currencyCode: string;
    billAmount: string;
    tipAmount: string;
    amount: string;
}

export interface IGenerateApplePayTokenMafV2Payload {
    cardToken?: string;
    diningSessionID?: string;
    gatewayID?: string;
    id?: string;
    reference?: string;
    tipAmount?: string;
    customerEmail?: string;
    successURL?: string;
    failureURL?: string;
}

export interface IGenerateTokenMafV2Payload {
    cardToken?: string;
    diningSessionID?: string;
    gatewayID?: string;
    id?: string;
    reference?: string;
    tipAmount?: string;
    customerEmail?: string;
    successURL?: string;
    failureURL?: string;
}

export interface IVerifyMafV2Payload {
    diningSessionID: string;
    gatewayID: string;
    reference: string;
    id: string;
    shippingContact?: ShippingContact;
}

export interface ShippingContact {
    emailAddress: string;
    familyName: string;
    givenName: string;
    phoneNumber: string;
    countryCode: string;
    country: string;
    addressLines: string[];
}

export interface IVerifyMafV2Response {
    success: boolean;
}

export interface IMafV2ValidateApplePaySessionPayload {
    applePayUrl: string;
    diningSessionID: string;
    gatewayID: string;
}

export interface IMafV2ValidateApplePaySessionResponse {
    jsonData: string;
}

export interface IMafV2PayByApplePayload {
    appleToken: string;
    shippingContact?: ApplePayPaymentContact;
    billingContact?: ApplePayPaymentContact;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
}

export interface IMafV2ApplePayDetails {
    cardApproved: boolean;
    needVerification: boolean;
    redirectUrl: string;
    paidAmount: string;
    responseCode: string;
}

export interface IMafV2PayByGooglePayload {
    googleToken: string;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType?: string;
}

export interface IMafV2PayByGooglePayResponse {
    result: boolean;
    responseCode: string;
}
