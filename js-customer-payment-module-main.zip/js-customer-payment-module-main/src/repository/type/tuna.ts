export interface ITunaPaySessionPayload {
    gatewayID: string;
    diningSessionID: string;
    reference: string;
    id: string;
}

export interface ITunaPaySessionResponse {
    sessionToken: string;
    code: number;
    customerID: string;
    customerEmail: string;
}

export interface ITunaPixPaymentResponseITunaCardPaymentResponse {
    billAmount: string;
    success: boolean;
    tipAmount: string;
    totalAmount: string;
}

export interface ITunaPaymentItem {
    amount: string;
    detailUniqueId: string;
    productDescription: string;
    qty: string;
}

export interface ITunaPaymentMethod {
    amount: string;
    billingInfoDocument: string;
    billingInfoDocumentType: string;
    cardBrandName: string;
    cardExpirationMonth: number;
    cardExpirationYear: number;
    cardHolderName: string;
    cardToken: string;
    cardTokenSingleUse: number;
    installments: number;
    paymentMethodType: string;
    saveCard: boolean;
    tokenProvider: string;
}

export interface ITunaCardPaymentPayload {
    diningSessionID: string;
    cardToken: string;
    cardHolderName: string;
    cardBrand: string;
    cardExpireMonth: number;
    cardExpiryYear: number;
    gatewayID: string;
    id: string;
    method: string;
    reference: string;
    tipAmount: string;
    sessionToken: string;
    tokenSingleUse: boolean;
    cardBin: string;
}

export interface ITunaPixPaymentPayload {
    diningSessionID: string;
    method: string;
    tipAmount: string;
    gatewayID: string;
    id: string;
    reference: string;
    sessionToken: string;
}

export interface ITunaPixPaymentResponse {
    billAmount: string;
    expiration: number;
    methodID: number;
    methodKey: string;
    methodType: string;
    operationId: string;
    paymentKey: string;
    qrContent: string;
    qrImage: string;
    status: string;
    success: boolean;
    tipAmount: string;
    totalAmount: string;
}

export interface ITunaVerifyPixPayload {
    diningSessionID: string;
    gatewayID: string;
    id: string;
    reference: string;
}

export interface ITunaVerifyPixResponse {
    billAmount: string;
    success: boolean;
    tipAmount: string;
    totalAmount: string;
}

export interface ITunaPayByGooglePayload {
    sessionToken: string;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    googleToken: string;
    method: string;
}

export interface ITunaPayByGoogleResponse {
    billAmount: string;
    success: boolean;
    tipAmount: string;
    totalAmount: string;
}

export interface ITunaValidateApplePayPayload {
    applePayUrl: string;
    diningSessionID: string;
    gatewayID: string;
}
export interface ITunaPayByApplePayPayload {
    appleToken: string;
    shippingContact?: ApplePayJS.ApplePayPaymentContact;
    billingContact?: ApplePayJS.ApplePayPaymentContact;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
    hostname: string;
    method: string;
    sessionToken: string;
}
export interface ITunaPayByAppleResponse {
    cardApproved: boolean;
    needVerification: boolean;
    redirectUrl: string;
    paidAmount: string;
}
