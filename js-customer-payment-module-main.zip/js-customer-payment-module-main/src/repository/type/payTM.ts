export interface IPayTMLegacyInitiateTransactionPayload {
    callbackUrl: string;
    diningSessionID: string;
    id: string;
    orderID: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
}

export interface IPayTMInitiateTransactionPayload {
    successUrl: string;
    failureUrl: string;
    diningSessionID: string;
    id: string;
    orderID: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
}

export interface IPayTMInitiateTransactionResponse {
    orderID: string;
    token: string;
}

export interface IPayTMVerifyTransactionPayload {
    diningSessionID: string;
    id: string;
    orderID: string;
    reference: string;
    txnType: string;
    gatewayID: string;
}

export interface IPayTMVerifyTransactionResponse {
    redirectUrl: string;
    success: boolean;
}
