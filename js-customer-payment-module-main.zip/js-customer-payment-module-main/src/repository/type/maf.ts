export interface IMafPaymentPayload {
    diningSessionID: string;
    gatewayID: string;
    id: string;
    reference: string;
    tipAmount: string;
    cardToken: string;
    successURL: string;
    failureURL: string;
    customerEmail: string;
}

export interface IMafPaymentResponse {
    responseMessage: string;
    responseCode: string;
    threeDsAuthId: string;
    orderReference: string;
    transactionReference: string;
    currencyCode: string;
    billAmount: string;
    tipAmount: string;
    amount: string;
}

export interface IGenerateApplePayTokenMafPayload {
    cardToken?: string;
    diningSessionID?: string;
    gatewayID?: string;
    id?: string;
    reference?: string;
    tipAmount?: string;
    customerEmail?: string;
    successURL?: string;
    failureURL?: string;
}

export interface IGenerateTokenMafPayload {
    cardToken?: string;
    diningSessionID?: string;
    gatewayID?: string;
    id?: string;
    reference?: string;
    tipAmount?: string;
    customerEmail?: string;
    successURL?: string;
    failureURL?: string;
}

export interface IVerifyMafPayload {
    diningSessionID: string;
    gatewayID: string;
    reference: string;
    id: string;
    shippingContact?: ShippingContact;
}

export interface ShippingContact {
    emailAddress: string;
    familyName: string;
    givenName: string;
    phoneNumber: string;
    countryCode: string;
    country: string;
    addressLines: string[];
}

export interface IVerifyMafResponse {
    success: boolean;
}
