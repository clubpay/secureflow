import ApplePayPaymentContact = ApplePayJS.ApplePayPaymentContact;

export interface IGenerateSessionTyroPayload {
    diningSessionID: string;
    gatewayID: string;
}

export interface IGenerateSessionTyroResponse {
    sessionId: string;
}

export interface ITyroPayPayload {
    billingCountry: string;
    cardBrand: string;
    diningSessionID: string;
    failureUrl: string;
    gatewayID: string;
    id: string;
    tyroSessionId: string;
    reference: string;
    successUrl: string;
    tipAmount: string;
}

export interface ITyroPayResponse {
    needVerification: boolean;
    redirectUrl: string;
    redirectHtml: string;
}

export interface ITyroPayByGooglePayload {
    googleToken: string;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
    successUrl: string;
    failureUrl: string;
    tyroSessionId: string;
}

export interface ITyroPayByApplePayload {
    appleToken: string;
    shippingContact?: ApplePayPaymentContact;
    billingContact?: ApplePayPaymentContact;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
    hostname: string;
    tyroSessionId: string;
}

export interface ITyroPayByGoogleResponse {
    needVerification: boolean;
    redirectUrl: string;
}
export interface ITyroPayByAppleResponse {
    needVerification: boolean;
    redirectUrl: string;
}

export interface ITyroValidateApplePayPayload {
    applePayUrl: string;
    diningSessionID: string;
    gatewayID: string;
    hostname: string;
}

export interface ITyroAuthorizePayload {
    tyroSessionId: string;
}

export interface ITyroAuthorizeResponse {
    status: 'pending' | 'success' | 'fail';
}
