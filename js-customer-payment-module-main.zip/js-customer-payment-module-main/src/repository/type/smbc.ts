export interface ISMBCLinkRequestPayload {
    diningSessionID: string;
    failureUrl: string;
    gatewayID: string;
    id: string;
    reference: string;
    successUrl: string;
    tipAmount: string;
}

export interface ISMBCLinkRequestResponse {
    link: string;
}
