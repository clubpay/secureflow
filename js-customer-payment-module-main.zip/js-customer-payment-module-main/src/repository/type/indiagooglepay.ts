export interface IGooglePayIndiaPayload {
    diningSessionID: string;
    reference: string;
    tipAmount: string;
    billAmount: string;
    gatewayID: string;
    id: string;
    paymentResponse: string;
}

export interface IGooglePayIndiaResponse {
    result: boolean;
}
