export interface IStripeCreatePaymentIntentPayload {
    gatewayID: string;
    id: string;
    diningSessionID: string;
    reference: string;
    automaticPaymentMethodParams: boolean;
}

export interface IStripePaymentIntentResponse {
    clientSecret: string;
    intentID: string;
}

export interface IStripePayPayload {
    intentID: string;
    diningSessionID: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    id: string;
    shippingContact?: {
        payerName?: string;
        payerEmail?: string;
        payerPhone?: string;
    };
}

export interface IStripePayResponse {
    intentID: string;
    diningSessionID: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    id: string;
}

export interface IStripeVerifyPayload {
    id: string;
    diningSessionID: string;
    gatewayID: string;
    intentID: string;
    reference: string;
    success: boolean;
    billAmount: string;
    tipAmount: string;
}

export interface IStripeVerifyResponse {
    redirectURL: string;
    success: boolean;
}
