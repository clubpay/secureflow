export interface IMasterPassTurkPayload {
    diningSessionID?: string;
    gatewayID?: number;
    id?: string;
    reference?: string;
}

export interface IMasterPassTurkResponse {
    approvalCode?: string;
    maskedAccountNo?: string;
}

export interface ITokenResponse {
    JWTToken: string;
    refresh: string;
}

export interface IResendSMSPayload {
    smsID: string;
    reCaptcha: string;
}

export interface IResendSMSResponse {
    success: boolean;
}

export interface IMasterPassGenerateTokenPayload {
    gatewayID?: string;
    verbose: boolean;
    reference: string;
    forRegisterCard?: boolean;
    computeReturnURL?: boolean;
    diningSessionID?: string;
    id?: string;
    failURL?: string;
    successURL?: string;
    tipAmount?: string;
}

export interface IMasterPassGenerateTokenResponse {
    dumpTokenInput: Record<string, any>;
    token: string;
    customerID: string;
    customerPhone: string;
    computedCallbackURL?: string;
    orderID?: string;
    computedCallbackRelativeURL?: string;
}

export interface IAuthenticatePayload {
    phone: string;
    reCaptcha: string;
}

export interface IAuthenticateResponse {
    otpID: string;
    phone: string;
    smsID: string;
}

export interface IMasterPassCommitPayload {
    diningSessionID?: string;
    gatewayID?: number;
    id?: string;
    reference?: string;
}

export interface IMasterPassCommitResponse {
    approvalCode?: string;
    maskedAccountNo?: string;
}

export interface IMasterPassGenerateReferenceResponse {
    reference: string;
}

export interface IUnlinkAccountPayload {
    token: string;
    reference: string;
    gatewayID: string;
    smsLanguage: string;
    sendSMS: boolean;
}

export interface IUnlinkAccountResponse {
    responseDatetime: string;
    retrievalReferenceNo: string;
}

export interface IValidateTokenPayload {
    JWTToken: string | null;
}

export interface IValidateTokenResponse {
    validated: boolean;
}

export interface ITokenRefreshPayload {
    refresh: string;
}
