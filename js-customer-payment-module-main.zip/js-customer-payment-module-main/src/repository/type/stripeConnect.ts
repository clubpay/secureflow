export interface IStripeConnectCreatePaymentIntentPayload {
    gatewayID: string;
    id: string;
    diningSessionID: string;
    reference: string;
    automaticPaymentMethodParams: boolean;
}

export interface IStripeConnectPaymentIntentResponse {
    clientSecret: string;
    intentID: string;
}

export interface IStripeConnectPayPayload {
    intentID: string;
    diningSessionID: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    id: string;
    shippingContact?: {
        payerName?: string;
        payerEmail?: string;
        payerPhone?: string;
    };
    cardBrand?: string;
    issuerCountry?: string | null;
    paymentMethod?: string;
    funding?: string;
}

export interface IStripeConnectPayResponse {
    intentID: string;
    diningSessionID: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    id: string;
}

export interface IStripeConnectVerifyPayload {
    id: string;
    diningSessionID: string;
    gatewayID: string;
    intentID: string;
    reference: string;
    success: boolean;
    billAmount: string;
    tipAmount: string;
    paymentMethod?: string;
}

export interface IStripeConnectVerifyResponse {
    redirectURL: string;
    success: boolean;
}
