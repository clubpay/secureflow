export interface IMoyasarSyncPayload {
    diningSessionID: string;

    id: string;
    reference: string;

    paymentId: string;

    intentID: string;
}

export interface IMoyasarSyncResponse {
    result: boolean;
}

export interface IVerifyMoyasarPaymentPayload {
    diningSessionID: string;
    gatewayID: string;
    reference: string;
}

export interface IVerifyMoyasarPaymentResponse {
    redirectURL: string;
    success: boolean;
}

export interface IMoyasarIntentPayload {
    diningSessionID: string;
    gatewayID: string;
    id: string;
    reference: string;
    tipAmount: string;
    statementDescriptor?: string;
}

export interface IMoyasarIntentResponse {
    billAmount: string;
    intentID: string;
    tipAmount: string;
    totalAmount: string;
}

export interface IMoyasarPayPayload {
    diningSessionID: string;
    id: string;
    reference: string;
    paymentId: string;
    intentID: string;
    statementDescriptor?: string;
    paymentMethod: string;
}

export interface IMoyasarPayResponse {
    result: boolean;

    [key: string]: any;
}

export interface IMoyasarUpdatePayload {
    diningSessionID: string;
    id: string;
    intentID: string;
    tipAmount: string;
    statementDescriptor?: string;
}

export interface IMoyasarUpdateResponse {
    result: boolean;

    [key: string]: any;
}
