/*
 * Creation Time: March 16 - 2023
 * Created By: yasincelebi
 * Name: tapp.ts
 * Copyright 2023 customer-web-app
 */

import ApplePayPaymentContact = ApplePayJS.ApplePayPaymentContact;

export interface ITappPaymentPayload {
    cardToken: string;
    diningSessionID: string;
    failureUrl: string;
    gatewayID: string;
    id: string;
    reference: string;
    successUrl: string;
    tipAmount: string;
    billingCountry: string;
    cardBrand: string;
    cardScheme: string;
}

export interface ITappPaymentResponse {
    needVerification: boolean;
    redirectUrl: string;
}

export interface ITappValidateApplePaySessionPayload {
    applePayUrl: string;
    diningSessionID: string;
    gatewayID: string;
    hostname: string;
}

export interface ITappValidateApplePaySessionResponse {
    jsonData: string;
}

export interface ITappPayByApplePayload {
    appleToken: string;
    shippingContact?: ApplePayPaymentContact;
    billingContact?: ApplePayPaymentContact;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
    hostname: string;
}

export interface ITappApplePayDetails {
    cardApproved: boolean;
    needVerification: boolean;
    redirectUrl: string;
    paidAmount: string;
}
