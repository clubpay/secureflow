import { PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import CardAuthMethod = google.payments.api.CardAuthMethod;
import CardNetwork = google.payments.api.CardNetwork;

interface IPaymentFallback {
    priority?: number;
    indicatorTimeout?: number;
    fallbackTimeout?: number;
}

export interface IPaymentSelector {
    pgOrder?: number;
    pgGroup?: boolean;
    pgElemOrder?: PaymentElementEnum[];
    pgDefaultSelectedElem?: PaymentElementEnum[];
    pgDefaultSelected?: boolean;
}

interface IPaymentBaseConfig extends IPaymentFallback, IPaymentSelector {
    hideApplePay?: boolean;
    hideGooglePay?: boolean;
    hideCardPay?: boolean;
    order?: number;
}

export interface ICheckoutGateway extends IPaymentBaseConfig {
    appleSDKVersion: number;
    publicKey: string;
    countryCode: string;
    merchantCapabilitiesList?: Array<string>;
    merchantCapabilities?: Array<string>;
    supportedNetworksList?: Array<string>;
    preferredNetworks?: Array<string>;
    supportedNetworks?: Array<string>;
    googleAllowedCardNetworks?: Array<any>;
    googleAllowedAuthMethods?: Array<any>;
    googleSDKVersion?: number;
    googleMerchantId?: string;
    hideGooglePay?: boolean;
    sandbox: boolean;
    applePayBillingDetails?: boolean;
    applePayShippingDetails?: boolean;
    disableSavedCard?: boolean;
    enableStcPay?: boolean;
    saveStcPayPhoneNumber: boolean;
    applepayRetryingTimeout?: number;
}

export interface ICheckoutPlatformGateway extends IPaymentBaseConfig {
    appleSDKVersion: number;
    publicKey: string;
    countryCode: string;
    merchantCapabilitiesList?: Array<string>;
    merchantCapabilities?: Array<string>;
    supportedNetworksList?: Array<string>;
    supportedNetworks?: Array<string>;
    googleAllowedCardNetworks?: Array<any>;
    googleAllowedAuthMethods?: Array<any>;
    googleSDKVersion?: number;
    googleMerchantId?: string;
    hideGooglePay?: boolean;
    sandbox: boolean;
}

export interface IPayTMLegacyGateway extends IPaymentBaseConfig {
    mid: string;
    label: string;
    sandbox: boolean;
}

export interface IPayTMGateway extends IPaymentBaseConfig {
    mid: string;
    label: string;
    sandbox: boolean;
}

export interface IStripeGateway extends IPaymentBaseConfig {
    publishableKey: string;
    secretKey: string;
    countryCode: string;
    step: number;
    hideButtonElement: boolean;
    hideCardElement: boolean;
    applePayBillingDetails?: boolean;
    applePayShippingDetails?: boolean;
}

export interface IStripeConnectGateway extends IPaymentBaseConfig {
    publishableKey: string;
    secretKey: string;
    countryCode: string;
    step: number;
    hideButtonElement: boolean;
    hideCardElement: boolean;
    applePayBillingDetails?: boolean;
    applePayShippingDetails?: boolean;
}

export interface ISMBCGateway extends IPaymentBaseConfig {
    shopID: string;
    shopPass: string;
    pubKey: string;
    pubKeyHash: string;
    configID: string;
    sandbox: boolean;
}

export interface IDGPayGateway extends IPaymentBaseConfig {
    sandbox?: boolean;
    countryCode?: string;
}

export interface ITunaGateway extends IPaymentBaseConfig {
    sandbox?: boolean;
    supportMealVoucher?: boolean;
    googleMerchantId: string;
    googleAllowedAuthMethods: CardAuthMethod[];
    googleAllowedCardNetworks: CardNetwork[];
    countryCode?: string;
    merchantID?: string;
    disableGooglePay?: boolean;
    merchantCapabilities?: Array<string>;
    supportedNetworksList?: Array<string>;
    supportedNetworks?: Array<string>;
    applePayBillingDetails?: boolean;
    applePayShippingDetails?: boolean;
    appleSDKVersion?: number;
}

export interface IMafGatewayConfig extends IPaymentBaseConfig {
    sandbox?: boolean;
    merchantID: string;
    apiKey: string;
    hideGooglePay?: boolean;
    googleMerchantId?: string;
    applePayBillingDetails?: boolean;
    applePayShippingDetails?: boolean;
    appleSDKVersion: number;
    merchantCapabilitiesList?: Array<string>;
    merchantCapabilities?: Array<string>;
    countryCode: string;
    supportedNetworksList?: Array<string>;
    supportedNetworks?: Array<string>;
    publicKey?: string;
    googleAllowedAuthMethods: CardAuthMethod[];
    googleAllowedCardNetworks: CardNetwork[];
    gateway?: string;
    gatewayMerchantId?: string;
}

export interface IIndiaGooglePayConfig extends IPaymentBaseConfig {
    businessCatCode: string;
    googleMerchantID: string;
    merchantName: string;
    vpa: string;
    priority: number;
}

export interface ITappGatewayConfig extends IPaymentBaseConfig {
    publicKey: string;
    countryCode: string;
    appleSDKVersion: number;
    merchantCapabilitiesList?: Array<string>;
    merchantCapabilities?: Array<string>;
    supportedNetworksList?: Array<string>;
    supportedNetworks?: Array<string>;
    applePayBillingDetails?: boolean;
    applePayShippingDetails?: boolean;
}

export interface IVostroGateway extends IPaymentBaseConfig {
    publicKey: string;
    publicIntegrationKey: string;
    countryCode: string;
    appleSDKVersion: number;
    merchantCapabilitiesList?: Array<string>;
    merchantCapabilities?: Array<string>;
    supportedNetworksList?: Array<string>;
    supportedNetworks?: Array<string>;
    sandbox: boolean;
    googleAllowedCardNetworks?: Array<any>;
    googleAllowedAuthMethods?: Array<any>;
    googleSDKVersion?: number;
    googleMerchantId?: string;
    hideGooglePay?: boolean;
}

export interface IAdyenGateway extends IPaymentBaseConfig {
    appleSDKVersion: number;
    publicKey: string;
    countryCode: string;
    merchantCapabilitiesList?: Array<string>;
    merchantCapabilities?: Array<string>;
    supportedNetworksList?: Array<string>;
    supportedNetworks?: Array<string>;
    googleAllowedCardNetworks?: Array<any>;
    googleAllowedAuthMethods?: Array<any>;
    googleSDKVersion?: number;
    googleMerchantId?: string;
    hideGooglePay?: boolean;
    sandbox: boolean;
    applePayBillingDetails?: boolean;
    applePayShippingDetails?: boolean;
    disableSavedCard?: boolean;
    clientKey?: string;
    paymentMethodResponse?: any;
    environment?: string;
    analytics?: any;
    hasHolderName?: boolean;
    merchantAccount?: string;
}

export interface IMasterpassGateway extends IPaymentBaseConfig {
    env: 'test' | 'uat' | 'prod';
    clientId: string;
    bankICA?: string;
}

export interface IMashreqGateway extends IPaymentBaseConfig {
    merchantId: string;
    appleSDKVersion: number;
    countryCode: string;
    merchantCapabilitiesList?: Array<string>;
    merchantCapabilities?: Array<string>;
    supportedNetworksList?: Array<string>;
    supportedNetworks?: Array<string>;
    applePayBillingDetails?: boolean;
    applePayShippingDetails?: boolean;
    env: 'prod' | 'test';
}

export interface IMoyasarV2Gateway extends IPaymentBaseConfig {
    appleSDKVersion?: number;
    publishableKey?: string;
    countryCode: string;
    domain: string;
    merchantCapabilities?: Array<string>;
    supportedNetworksList?: Array<string>;
    supportedNetworks?: Array<string>;
    applePayBillingDetails?: boolean;
    applePayShippingDetails?: boolean;
}

export interface INGeniusGateway extends IPaymentBaseConfig {
    appleSDKVersion?: number;
    countryCode: string;
    domain: string;
    merchantCapabilities?: Array<string>;
    supportedNetworksList?: Array<string>;
    supportedNetworks?: Array<string>;
    applePayBillingDetails?: boolean;
    applePayShippingDetails?: boolean;
    hostedSessionApiKey: string;
    outlet_ref: string;
    sandbox: boolean;
}

declare global {
    interface Window {
        clarity: (...args: any) => void;
    }
}

export interface ITyroGateway extends IPaymentBaseConfig {
    merchantId: string;
    appleSDKVersion: number;
    countryCode: string;
    merchantCapabilitiesList?: Array<string>;
    merchantCapabilities?: Array<string>;
    supportedNetworksList?: Array<string>;
    supportedNetworks?: Array<string>;
    googleAllowedCardNetworks?: Array<any>;
    googleAllowedAuthMethods?: Array<any>;
    applePayBillingDetails?: boolean;
    applePayShippingDetails?: boolean;
    googleMerchantId?: string;
    env: 'prod' | 'test';
}
