import { IExchangeData } from '@clubpay/customer-common-module/src/repository/vendor';
import { PaymentExchangeDecision } from '@clubpay/customer-common-module/src/repository/common/payment/type';

import ApplePayPaymentContact = ApplePayJS.ApplePayPaymentContact;

export interface ICheckoutDetails {
    cardApproved: boolean;
    needVerification: boolean;
    redirectUrl: string;
    paidAmount: string;
    exchangeData: IExchangeData;
    routingApplied: boolean;
}

export interface ICheckoutPayByApplePayload {
    appleToken: string;
    shippingContact?: ApplePayPaymentContact;
    billingContact?: ApplePayPaymentContact;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
    hostname: string;
    isSplitPayment: boolean;
    exchangeDecision: PaymentExchangeDecision;
    successUrl: string;
    failureUrl: string;
}

export interface ICheckoutPayByGooglePayload {
    googleToken: string;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
    successUrl: string;
    failureUrl: string;
}

export interface ICheckoutValidateApplePaySessionPayload {
    applePayUrl: string;
    diningSessionID: string;
    gatewayID: string;
    hostname: string;
}

export interface ICheckoutValidateApplePaySessionResponse {
    jsonData: string;
}

export interface ICheckoutVerifyPaymentPayload {
    diningSessionID: string;
    reference: string;
    sessionID: string;
    success: boolean;
    gatewayID: string;
}

export interface ICheckoutVerifyResponse {
    redirectUrl: string;
    success: boolean;
}

export interface ICheckoutPayByCardPayload {
    cvv: string;
    diningSessionID: string;
    expiryMonth: number;
    expiryYear: number;
    failureUrl: string;
    id: string;
    name: string;
    number: string;
    reference: string;
    successUrl: string;
    tipAmount: string;
}

export interface ICheckoutPayByTokenPayload {
    cardToken?: string;
    diningSessionID: string;
    failureUrl: string;
    id: string;
    reference: string;
    successUrl: string;
    tipAmount: string;
    gatewayID: string;
    cardType?: string;
    saveCard: boolean;
    issuerCountry?: string;
    scheme?: string;
    isSplitPayment: boolean;
    exchangeDecision: PaymentExchangeDecision;
}

export interface ICheckoutPayBySTCPayPayload {
    id: string;
    tipAmount: string;
    diningSessionID: string;
    reference: string;
    gatewayID: string;
    success_url: string;
    failure_url: string;
    customer: {
        email: string;
        name: string;
        phone: {
            number: string;
            countryCode: string;
        };
    };
}

export interface ICheckoutPayBySTCPayCapturePayload {
    id: string;
    tipAmount: string;
    diningSessionID: string;
    reference: string;
    gatewayID: string;
    paymentId: string;
    processing: {
        otp_value: string;
    };
}

export interface ICheckoutPayByTokenResponse {
    cardApproved: boolean;
    needVerification: boolean;
    paidAmount: string;
    redirectUrl: string;
    exchangeData: IExchangeData;
    routingApplied: boolean;
}

export interface ICheckoutPayBySTCPayResponse {
    id: string;
    status: string;
    reference: string;
    isPending: boolean;
    customer: {
        id: string;
        email: string;
        name: string;
        phone: {
            countryCode: string;
            number: string;
        };
    };
}

export interface ICheckoutPayBySTCPayCaptureResponse {
    action_id: string;
}

export interface ICheckoutSavedCardDetailsResponse {
    bin: string;
    isMada: boolean;
    last4: string;
    scheme: string;
    sourceId: string;
}

export interface ICheckoutPayWithSavedCardPayload {
    diningSessionID: string;
    failureUrl: string;
    gatewayID: string;
    id: string;
    isMada: boolean;
    reference: string;
    sourceId: string;
    successUrl: string;
    tipAmount: string;
    isSplitPayment: boolean;
    exchangeDecision: PaymentExchangeDecision;
}

export interface ICheckoutPayWithSavedCardResponse {
    cardApproved: boolean;
    needVerification: boolean;
    paidAmount: string;
    redirectUrl: string;
    exchangeData: IExchangeData;
    routingApplied: boolean;
}

export interface ICheckoutUnsaveCardResponse {
    result: boolean;
}
