export interface ICheckoutPlatformDetails {
    cardApproved: boolean;
    needVerification: boolean;
    redirectUrl: string;
    paidAmount: string;
}

export interface ICheckoutPlatformPayByApplePayload {
    appleToken: string;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
    hostname: string;
}

export interface ICheckoutPlatformPayByGooglePayload {
    googleToken: string;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
}

export interface ICheckoutPlatformValidateApplePaySessionPayload {
    applePayUrl: string;
    diningSessionID: string;
    gatewayID: string;
    hostname: string;
}

export interface ICheckoutPlatformValidateApplePaySessionResponse {
    jsonData: string;
}

export interface ICheckoutPlatformPayByTokenPayload {
    cardToken: string;
    diningSessionID: string;
    failureUrl: string;
    id: string;
    reference: string;
    successUrl: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
}

export interface ICheckoutPlatformPayByTokenResponse {
    cardApproved: boolean;
    needVerification: boolean;
    paidAmount: string;
    redirectUrl: string;
}
