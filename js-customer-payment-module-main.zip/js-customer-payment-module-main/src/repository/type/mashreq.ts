/*
 * Creation Time: May 31 - 2023
 * Created By: yasincelebi
 * Name: mashreq.ts
 * Copyright 2023 customer-web-app
 */

import ApplePayPaymentContact = ApplePayJS.ApplePayPaymentContact;

export interface IGenerateSessionMashreqPayload {
    diningSessionID: string;
    gatewayID: string;
}

export interface IGenerateSessionMashreqResponse {
    sessionId: string;
}

export interface IPayMashreqPayload {
    billingCountry: string;
    cardBrand: string;
    diningSessionID: string;
    failureUrl: string;
    gatewayID: string;
    id: string;
    mashreqSessionId: string;
    reference: string;
    successUrl: string;
    tipAmount: string;
}

export interface IMashreqPayResponse {
    needVerification: boolean;
    redirectUrl: string;
    redirectHtml: string;
}

export interface IMashreqValidateApplePaySessionPayload {
    applePayUrl: string;
    diningSessionID: string;
    gatewayID: string;
    hostname: string;
}

export interface IMashreqValidateApplePaySessionResponse {
    jsonData: string;
}

export interface IMashreqPayByApplePayload {
    appleToken: string;
    shippingContact?: ApplePayPaymentContact;
    billingContact?: ApplePayPaymentContact;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
    hostname: string;
    mashreqSessionId: string;
}

export interface IMashreqDetails {
    needVerification: boolean;
    redirectUrl: string;
}

export interface IMashreqAuthorizePayload {
    mashreqSessionId: string;
}

export interface IMashreqAuthorizeResponse {
    status: 'pending' | 'success' | 'fail';
}
