export interface IAdyenDetails {
    cardApproved: boolean;
    needVerification: boolean;
    redirectUrl: string;
    paidAmount: string;
}

export interface IAdyenCreateSessionPayload {
    reference: string;
    returnUrl: string;
    id: string;
    tipAmount: string;
    diningSessionID: string;
    gatewayId: string;
}

export interface IAdyenCreateSessionResponse {
    [key: string]: any;
}

export interface IAdyenGetMethodListPayload {
    [key: string]: any;
}

export interface IAdyenGetMethodListResponse {
    [key: string]: any;
}

export interface IAdyenAdvancedPaymentsPayload {
    returnUrl?: string;
    reference: string;
    tipAmount: string;
    diningSessionID: string;
    gatewayID: string;
    id: string;
    paymentMethod: any;
    shippingContact?: ApplePayJS.ApplePayPaymentContact;
    billingContact?: ApplePayJS.ApplePayPaymentContact;
    hostname?: string;
}
export interface IAdyenAdvancedPaymentsResponse {
    [key: string]: any;
}

export interface IAdyenRiskData {
    clientData: string;
}

export interface IAdyenPaymentMethod {
    type: string;
    holderName: string;
    encryptedCardNumber: string;
    encryptedExpiryMonth: string;
    encryptedExpiryYear: string;
    encryptedSecurityCode: string;
    brand: string;
    checkoutAttemptId: string;
}

export interface IAdyenBrowserInfo {
    acceptHeader: string;
    colorDepth: number;
    language: string;
    javaEnabled: boolean;
    screenHeight: number;
    screenWidth: number;
    userAgent: string;
    timeZoneOffset: number;
}

export interface IAdyenPaymentData {
    riskData: IAdyenRiskData;
    paymentMethod: IAdyenPaymentMethod;
    browserInfo: IAdyenBrowserInfo;
    origin: string;
    clientStateDataIndicator: boolean;
}

export interface IAdyenPaymentRequest {
    data: IAdyenPaymentData;
    isValid: boolean;
}
export interface IAdyenValidateApplePayPayload {
    applePayUrl: string;
    diningSessionID: string;
    gatewayID: string;
}
