export interface IVostroPayByDebitPayload {
    amount: string;
    currency: string;
    diningSessionID: string;
    gatewayID: string;
    id: string;
    reference: string;
    tipAmount: string;
    transactionToken: string;
}

export interface IVostroPayByDebitResponse {
    errors: IVostroError[];
    paymentMethod: string;
    purchaseId: string;
    redirectUrl: string;
    returnType: string;
    success: boolean;
    uuid: string;
}

export interface IVostroError {
    code: string | number;
    description: string;
    extra: Record<string, string>;
    items: string;
}

// export interface IVostroError {
//     adapterCode: string;
//     adapterMessage: string;
//     errorCode: number;
//     errorMessage: string;
// }

export interface IVostroValidateApplePaySessionPayload {
    applePayUrl: string;
    diningSessionID: string;
    gatewayID: string;
}

export interface IVostroValidateApplePaySessionResponse {
    jsonData: string;
}

export interface IVostroPayByApplePayload {
    appleToken: string;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
}

export interface IVostroPayDetails {
    cardApproved: boolean;
    needVerification: boolean;
    redirectUrl: string;
    paidAmount: string;
}

export interface IVostroPayByGooglePayload {
    googleToken: string;
    diningSessionID: string;
    id: string;
    reference: string;
    tipAmount: string;
    gatewayID: string;
    cardType: string;
}
