export interface IPaypayRegisterPayload {
    diningSessionID: string;
    tipAmount: string;
    gatewayID: string;
    id: string;
    reference: string;
    orderID: string;
    successUrl: string;
    failureUrl: string;
}

export interface IPaypayRegisterResponse {
    accessID: string;
    accessPass: string;
    orderID: string;
    startLimitDate: string;
    startURL: string;
    token: string;
}
