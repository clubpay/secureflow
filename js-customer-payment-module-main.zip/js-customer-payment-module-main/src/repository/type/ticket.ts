export interface ITicketPGGenerateLinkPayload {
    diningSessionID: string;
    gatewayID: string;
    id: string;
    reference: string;
    tipAmount: string;
    successURL: string;
    failureURL: string;
}

export interface ITicketPGGenerateLinkResponse {
    paymentURL: string;
}
