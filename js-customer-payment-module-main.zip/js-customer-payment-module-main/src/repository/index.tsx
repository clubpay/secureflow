import axiosInstance from '@clubpay/customer-common-module/src/repository/axios';
import axiosRetry from 'axios-retry';
import {
    IMafV2ApplePayDetails,
    IMafV2PayByApplePayload,
    IMafV2PayByGooglePayResponse,
    IMafV2PayByGooglePayload,
    IMafV2PaymentPayload,
    IMafV2PaymentResponse,
    IMafV2ValidateApplePaySessionPayload,
    IMafV2ValidateApplePaySessionResponse,
    IVerifyMafV2Payload,
    IVerifyMafV2Response,
} from './type/mafv2';
import {
    ICheckoutDetails,
    ICheckoutPayByApplePayload,
    ICheckoutPayByGooglePayload,
    ICheckoutPayBySTCPayCapturePayload,
    ICheckoutPayBySTCPayPayload,
    ICheckoutPayBySTCPayResponse,
    ICheckoutPayByTokenPayload,
    ICheckoutPayByTokenResponse,
    ICheckoutPayWithSavedCardPayload,
    ICheckoutPayWithSavedCardResponse,
    ICheckoutSavedCardDetailsResponse,
    ICheckoutUnsaveCardResponse,
    ICheckoutValidateApplePaySessionPayload,
    ICheckoutValidateApplePaySessionResponse,
} from './type/checkout';
import {
    ICheckoutPlatformDetails,
    ICheckoutPlatformPayByApplePayload,
    ICheckoutPlatformPayByGooglePayload,
    ICheckoutPlatformPayByTokenPayload,
    ICheckoutPlatformPayByTokenResponse,
    ICheckoutPlatformValidateApplePaySessionPayload,
    ICheckoutPlatformValidateApplePaySessionResponse,
} from './type/checkoutPlatform';
import {
    IPayTMInitiateTransactionPayload,
    IPayTMInitiateTransactionResponse,
    IPayTMLegacyInitiateTransactionPayload,
    IPayTMVerifyTransactionPayload,
    IPayTMVerifyTransactionResponse,
} from './type/payTM';
import { ISMBCLinkRequestPayload, ISMBCLinkRequestResponse } from './type/smbc';
import { ITicketPGGenerateLinkPayload, ITicketPGGenerateLinkResponse } from './type/ticket';
import {
    IStripeCreatePaymentIntentPayload,
    IStripePaymentIntentResponse,
    IStripePayPayload,
    IStripePayResponse,
    IStripeVerifyPayload,
    IStripeVerifyResponse,
} from './type/stripe';
import {
    IStripeConnectCreatePaymentIntentPayload,
    IStripeConnectPaymentIntentResponse,
    IStripeConnectPayPayload,
    IStripeConnectPayResponse,
    IStripeConnectVerifyPayload,
    IStripeConnectVerifyResponse,
} from './type/stripeConnect';
import { IDGPayGet3DSSessionPayload, IDGPayGet3DSSessionResponse } from './type/dgpay';
import {
    ITunaCardPaymentPayload,
    ITunaPayByApplePayPayload,
    ITunaPayByAppleResponse,
    ITunaPayByGooglePayload,
    ITunaPayByGoogleResponse,
    ITunaPaySessionPayload,
    ITunaPaySessionResponse,
    ITunaPixPaymentPayload,
    ITunaPixPaymentResponse,
    ITunaValidateApplePayPayload,
    ITunaVerifyPixPayload,
    ITunaVerifyPixResponse,
} from './type/tuna';
import {
    IMasterPassCommitPayload,
    IMasterPassCommitResponse,
    IMasterPassGenerateReferenceResponse,
    IMasterPassGenerateTokenPayload,
    IMasterPassGenerateTokenResponse,
    IUnlinkAccountPayload,
    IUnlinkAccountResponse,
} from './type/masterpass';
import { IPaypayRegisterPayload, IPaypayRegisterResponse } from './type/paypay';
import {
    IMoyasarIntentPayload,
    IMoyasarIntentResponse,
    IMoyasarPayPayload,
    IMoyasarPayResponse,
    IMoyasarUpdatePayload,
    IMoyasarUpdateResponse,
    IVerifyMoyasarPaymentPayload,
    IVerifyMoyasarPaymentResponse,
} from './type/moyasar';
import {
    IGenerateTokenMafPayload,
    IMafPaymentPayload,
    IMafPaymentResponse,
    IVerifyMafPayload,
    IVerifyMafResponse,
} from './type/maf';
import { IGooglePayIndiaPayload, IGooglePayIndiaResponse } from './type/indiagooglepay';
import {
    ITappApplePayDetails,
    ITappPayByApplePayload,
    ITappPaymentPayload,
    ITappPaymentResponse,
    ITappValidateApplePaySessionPayload,
    ITappValidateApplePaySessionResponse,
} from './type/tapp';
import {
    IVostroPayByApplePayload,
    IVostroPayByDebitPayload,
    IVostroPayByDebitResponse,
    IVostroPayByGooglePayload,
    IVostroPayDetails,
    IVostroValidateApplePaySessionPayload,
    IVostroValidateApplePaySessionResponse,
} from './type/vostro';
import {
    IGenerateSessionMashreqPayload,
    IGenerateSessionMashreqResponse,
    IMashreqAuthorizePayload,
    IMashreqAuthorizeResponse,
    IMashreqDetails,
    IMashreqPayByApplePayload,
    IMashreqPayResponse,
    IMashreqValidateApplePaySessionPayload,
    IMashreqValidateApplePaySessionResponse,
    IPayMashreqPayload,
} from './type/mashreq';
import {
    IAdyenAdvancedPaymentsPayload,
    IAdyenAdvancedPaymentsResponse,
    IAdyenCreateSessionPayload,
    IAdyenCreateSessionResponse,
    IAdyenGetMethodListPayload,
    IAdyenGetMethodListResponse,
    IAdyenValidateApplePayPayload,
} from './type/adyen';
import { apiEndpoints } from './const';
import { IMoyasarV2PayByApplePayload, IMoyasarV2ValidateApplePayload, IMoyasarV2Details } from './type/moyasarV2';
import {
    INGeniusCapturePayload,
    INGeniusCaptureResponse,
    INGeniusDetails,
    INGeniusPayByApplePayPayload,
    INGeniusPayByCardPayload,
    INGeniusPayByCardResponse,
    INGeniusValidateApplePayPayload,
} from './type/nGenius';
import {
    IGenerateSessionTyroPayload,
    IGenerateSessionTyroResponse,
    ITyroAuthorizePayload,
    ITyroAuthorizeResponse,
    ITyroPayByApplePayload,
    ITyroPayByAppleResponse,
    ITyroPayByGooglePayload,
    ITyroPayByGoogleResponse,
    ITyroPayPayload,
    ITyroPayResponse,
    ITyroValidateApplePayPayload,
} from './type/tyro';

export default class PaymentAPIManager {
    private static instance: PaymentAPIManager;

    public static getInstance() {
        if (!this.instance) {
            this.instance = new PaymentAPIManager();
        }

        return this.instance;
    }

    // PG Checkout
    public paymentCheckoutPayByApple = (payload: ICheckoutPayByApplePayload) => {
        return axiosInstance.Post<ICheckoutDetails, ICheckoutPayByApplePayload>(
            apiEndpoints.payment.checkoutGateway.applePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentCheckoutPayByGoogle = (payload: ICheckoutPayByGooglePayload) => {
        return axiosInstance.Post<ICheckoutDetails, ICheckoutPayByGooglePayload>(
            apiEndpoints.payment.checkoutGateway.googlePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentCheckoutValidateApplePaySession = (payload: ICheckoutValidateApplePaySessionPayload) => {
        return axiosInstance.Post<ICheckoutValidateApplePaySessionResponse, ICheckoutValidateApplePaySessionPayload>(
            apiEndpoints.payment.checkoutGateway.applePayValidate,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentCheckoutPayByToken = (payload: ICheckoutPayByTokenPayload) => {
        return axiosInstance.Post<ICheckoutPayByTokenResponse, ICheckoutPayByTokenPayload>(
            apiEndpoints.payment.checkoutGateway.token,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentCheckoutPayBySTCPay = (payload: ICheckoutPayBySTCPayPayload) => {
        return axiosInstance.Post<ICheckoutPayBySTCPayResponse, ICheckoutPayBySTCPayPayload>(
            apiEndpoints.payment.checkoutGateway.stcPay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentCheckoutPayBySTCPayCapture = (payload: ICheckoutPayBySTCPayCapturePayload) => {
        return axiosInstance.Post<ICheckoutPayBySTCPayResponse, ICheckoutPayBySTCPayCapturePayload>(
            apiEndpoints.payment.checkoutGateway.stcPayCapture,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    // PG Checkout Platform
    public paymentCheckoutPlatformPayByApple = (payload: ICheckoutPlatformPayByApplePayload) => {
        return axiosInstance.Post<ICheckoutPlatformDetails, ICheckoutPlatformPayByApplePayload>(
            apiEndpoints.payment.checkoutPlatformGateway.applePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentCheckoutPlatformPayByGoogle = (payload: ICheckoutPlatformPayByGooglePayload) => {
        return axiosInstance.Post<ICheckoutPlatformDetails, ICheckoutPlatformPayByGooglePayload>(
            apiEndpoints.payment.checkoutPlatformGateway.googlePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentCheckoutPlatformValidateApplePaySession = (
        payload: ICheckoutPlatformValidateApplePaySessionPayload,
    ) => {
        return axiosInstance.Post<
            ICheckoutPlatformValidateApplePaySessionResponse,
            ICheckoutPlatformValidateApplePaySessionPayload
        >(apiEndpoints.payment.checkoutPlatformGateway.applePayValidate, payload, {
            'axios-retry': {
                retries: 3,
            },
            timeout: 45000,
        });
    };

    public paymentCheckoutPlatformPayByToken = (payload: ICheckoutPlatformPayByTokenPayload) => {
        return axiosInstance.Post<ICheckoutPlatformPayByTokenResponse, ICheckoutPlatformPayByTokenPayload>(
            apiEndpoints.payment.checkoutPlatformGateway.token,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    // PG PayTM Legacy
    public paymentPayTMLegacyInitiateTransaction = (payload: IPayTMLegacyInitiateTransactionPayload) => {
        return axiosInstance.Post<IPayTMInitiateTransactionResponse, IPayTMLegacyInitiateTransactionPayload>(
            apiEndpoints.payment.payTMLegacyGateway.initiate,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentPayTMLegacyVerifyTransaction = (payload: IPayTMVerifyTransactionPayload) => {
        return axiosInstance.Get<IPayTMVerifyTransactionResponse, IPayTMVerifyTransactionPayload>(
            `${apiEndpoints.payment.payTMLegacyGateway.verify}/${payload.diningSessionID}/${payload.orderID}/${payload.gatewayID}`,
            {
                params: {
                    reference: payload.reference,
                    id: payload.id,
                    txnType: payload.txnType,
                },
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    // PG PayTM
    public paymentPayTMInitiateTransaction = (payload: IPayTMInitiateTransactionPayload) => {
        return axiosInstance.Post<IPayTMInitiateTransactionResponse, IPayTMInitiateTransactionPayload>(
            apiEndpoints.payment.payTMGateway.initiate,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentPayTMVerifyTransaction = (payload: IPayTMVerifyTransactionPayload) => {
        return axiosInstance.Get<IPayTMVerifyTransactionResponse, IPayTMVerifyTransactionPayload>(
            `${apiEndpoints.payment.payTMGateway.verify}/${payload.diningSessionID}/${payload.orderID}/${payload.gatewayID}`,
            {
                params: {
                    reference: payload.reference,
                    id: payload.id,
                    txnType: payload.txnType,
                },
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    // PG SMBC Link
    public paymentSMBCGenerateLink = (payload: ISMBCLinkRequestPayload) => {
        return axiosInstance.Post<ISMBCLinkRequestResponse, ISMBCLinkRequestPayload>(
            `${apiEndpoints.payment.smbc.generateLink}`,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payTicketGenerateLink = (payload: ITicketPGGenerateLinkPayload) => {
        return axiosInstance.Post<ITicketPGGenerateLinkResponse, ITicketPGGenerateLinkPayload>(
            apiEndpoints.payment.ticket.generateLink,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentStripeCreatePaymentIntent = (payload: IStripeCreatePaymentIntentPayload) => {
        return axiosInstance.Post<IStripePaymentIntentResponse, IStripeCreatePaymentIntentPayload>(
            `${apiEndpoints.payment.stripe.createPaymentIntent}`,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    // PG Stripe
    public paymentStripePay = (payload: IStripePayPayload) => {
        return axiosInstance.Post<IStripePayResponse, IStripePayPayload>(
            `${apiEndpoints.payment.stripe.pay}`,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentStripeVerify = (payload: IStripeVerifyPayload) => {
        return axiosInstance.Post<IStripeVerifyResponse, IStripeVerifyPayload>(
            `${apiEndpoints.payment.stripe.verify}`,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentStripeConnectCreatePaymentIntent = (payload: IStripeConnectCreatePaymentIntentPayload) => {
        return axiosInstance.Post<IStripeConnectPaymentIntentResponse, IStripeConnectCreatePaymentIntentPayload>(
            `${apiEndpoints.payment.stripeConnect.createPaymentIntent}`,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    // PG Stripe Connect
    public paymentStripeConnectPay = (payload: IStripeConnectPayPayload) => {
        return axiosInstance.Post<IStripeConnectPayResponse, IStripeConnectPayPayload>(
            `${apiEndpoints.payment.stripeConnect.pay}`,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentStripeConnectVerify = (payload: IStripeConnectVerifyPayload) => {
        return axiosInstance.Post<IStripeConnectVerifyResponse, IStripeConnectVerifyPayload>(
            `${apiEndpoints.payment.stripeConnect.verify}`,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    // PG DGPay
    public paymentDGPaySession = (payload: IDGPayGet3DSSessionPayload) => {
        return axiosInstance.Post<IDGPayGet3DSSessionResponse, IDGPayGet3DSSessionPayload>(
            apiEndpoints.payment.dgpay.session,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    /** tuna */
    public paymentTunaSession = (payload: ITunaPaySessionPayload) => {
        return axiosInstance.Post<ITunaPaySessionResponse, ITunaPaySessionPayload>(
            apiEndpoints.payment.tuna.session,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public tunaCardPayment = (payload: ITunaCardPaymentPayload) => {
        return axiosInstance.Post<ITunaPixPaymentResponse, ITunaCardPaymentPayload>(
            apiEndpoints.payment.tuna.cardPayment,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public tunaPixPayment = (payload: ITunaPixPaymentPayload) => {
        return axiosInstance.Post<ITunaPixPaymentResponse, ITunaPixPaymentPayload>(
            apiEndpoints.payment.tuna.pixPayment,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public tunaVerifyPix = (payload: ITunaVerifyPixPayload) => {
        return axiosInstance.Post<ITunaVerifyPixResponse, ITunaVerifyPixPayload>(
            apiEndpoints.payment.tuna.verifyPix,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payTunaValidateApplePay = (payload: ITunaValidateApplePayPayload) => {
        return axiosInstance.Post<any, ITunaValidateApplePayPayload>(
            apiEndpoints.payment.tuna.applePayValidate,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payTunaPayByApple = (payload: ITunaPayByApplePayPayload) => {
        return axiosInstance.Post<ITunaPayByAppleResponse, ITunaPayByApplePayPayload>(
            apiEndpoints.payment.tuna.applePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public masterPassCommit = (payload: IMasterPassCommitPayload) => {
        return axiosInstance.Post<IMasterPassCommitResponse, IMasterPassCommitPayload>(
            apiEndpoints.payment.masterpass.commit,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public masterPassGenerateToken = (payload: IMasterPassGenerateTokenPayload) => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        return axiosInstance.Post<IMasterPassGenerateTokenResponse, IMasterPassGenerateTokenPayload>(
            apiEndpoints.payment.masterpass.generateToken,
            payload,
            {
                'axios-retry': {
                    retries: 1,
                },
                timeout: 10000,
            },
        );
    };

    public masterPassDirectGenerateToken = (payload: IMasterPassGenerateTokenPayload) => {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        return axiosInstance.Post<IMasterPassGenerateTokenResponse, IMasterPassGenerateTokenPayload>(
            apiEndpoints.payment.masterpasDirect.generateToken,
            payload,
            {
                'axios-retry': {
                    retries: 1,
                },
                timeout: 10000,
            },
        );
    };

    public masterpassGenerateReference = () => {
        return axiosInstance.Get<IMasterPassGenerateReferenceResponse>(
            apiEndpoints.payment.masterpass.generateReference,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 10000,
            },
        );
    };

    public unlinkMasterpass = (payload: IUnlinkAccountPayload) => {
        return axiosInstance.Post<IUnlinkAccountResponse, IUnlinkAccountPayload>(
            apiEndpoints.payment.masterpass.unlink,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 10000,
            },
        );
    };

    public payPayRegister = (payload: IPaypayRegisterPayload) => {
        return axiosInstance.Post<IPaypayRegisterResponse, IPaypayRegisterPayload>(
            apiEndpoints.payment.payPay.register,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payMoyasarPayment = (payload: IMoyasarPayPayload) => {
        return axiosInstance.Post<IMoyasarPayResponse, IMoyasarPayPayload>(apiEndpoints.payment.moyasar.pay, payload, {
            'axios-retry': {
                retries: 3,
            },
            timeout: 45000,
        });
    };

    public payMoyasarCreateIntent = (payload: IMoyasarIntentPayload) => {
        return axiosInstance.Post<IMoyasarIntentResponse, IMoyasarIntentPayload>(
            apiEndpoints.payment.moyasar.createIntent,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                    retryCondition: (err: any) => {
                        return Promise.resolve(
                            axiosRetry.isNetworkOrIdempotentRequestError(err) ||
                                (err?.response?.data?.code === 404 &&
                                    err?.response?.data?.items === 'INVALID_PARTICIPANT_ID'),
                        );
                    },
                    retryDelay: (retryCount) => {
                        return retryCount * 1000;
                    },
                },
                timeout: 45000,
            },
        );
    };

    public payMoyasarUpdateIntent = (payload: IMoyasarUpdatePayload) => {
        return axiosInstance.Post<IMoyasarUpdateResponse, IMoyasarUpdatePayload>(
            apiEndpoints.payment.moyasar.updateIntent,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payMoyasarVerify = (payload: IVerifyMoyasarPaymentPayload) => {
        return axiosInstance.Get<IVerifyMoyasarPaymentPayload, IVerifyMoyasarPaymentResponse>(
            `${apiEndpoints.payment.moyasar.verify}/${payload.diningSessionID}/${payload.gatewayID}`,
            {
                params: {
                    reference: payload.reference,
                },
                timeout: 45000,
            },
        );
    };

    public payMoyasarV2PayByApple = (payload: IMoyasarV2PayByApplePayload) => {
        return axiosInstance.Post<IMoyasarV2Details, IMoyasarV2PayByApplePayload>(
            apiEndpoints.payment.moyasarV2.applePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payMoyasarV2ValidateApplePay = (payload: IMoyasarV2ValidateApplePayload) => {
        return axiosInstance.Post<any, IMoyasarV2ValidateApplePayload>(
            apiEndpoints.payment.moyasarV2.applePayValidate,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentTunaPayByGoogle = (payload: ITunaPayByGooglePayload) => {
        return axiosInstance.Post<ITunaPayByGoogleResponse, ITunaPayByGooglePayload>(
            apiEndpoints.payment.tuna.googlePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payMafPayment = (payload: IMafPaymentPayload) => {
        return axiosInstance.Post<IMafPaymentResponse, IMafPaymentPayload>(apiEndpoints.payment.maf.payment, payload, {
            'axios-retry': {
                retries: 3,
            },
            timeout: 45000,
        });
    };

    public generateTokenMaf = (payload: IGenerateTokenMafPayload) => {
        return axiosInstance.Post<any, IGenerateTokenMafPayload>(apiEndpoints.payment.maf.generateToken, payload, {
            'axios-retry': {
                retries: 3,
            },
            timeout: 45000,
        });
    };

    public verifyMaf = (payload: IVerifyMafPayload) => {
        return axiosInstance.Post<IVerifyMafResponse, IVerifyMafPayload>(apiEndpoints.payment.maf.verify, payload, {
            'axios-retry': {
                retries: 3,
            },
            timeout: 45000,
        });
    };

    public payMafPaymentV2 = (payload: IMafV2PaymentPayload) => {
        return axiosInstance.Post<IMafV2PaymentResponse, IMafV2PaymentPayload>(
            apiEndpoints.payment.mafv2.payment,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentMafV2PayByGoogle = (payload: IMafV2PayByGooglePayload) => {
        return axiosInstance.Post<IMafV2PayByGooglePayResponse, IMafV2PayByGooglePayload>(
            apiEndpoints.payment.mafv2.googlePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public verifyMafV2 = (payload: IVerifyMafV2Payload) => {
        return axiosInstance.Post<IVerifyMafV2Response, IVerifyMafV2Payload>(
            apiEndpoints.payment.mafv2.verify,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentMafV2ValidateApplePaySession = (payload: IMafV2ValidateApplePaySessionPayload) => {
        return axiosInstance.Post<IMafV2ValidateApplePaySessionResponse, IMafV2ValidateApplePaySessionPayload>(
            apiEndpoints.payment.mafv2.applePayValidate,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentMafV2PayByApple = (payload: IMafV2PayByApplePayload) => {
        return axiosInstance.Post<IMafV2ApplePayDetails, IMafV2PayByApplePayload>(
            apiEndpoints.payment.mafv2.applePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public googlePayIndiaSync = (payload: IGooglePayIndiaPayload) => {
        return axiosInstance.Post<IGooglePayIndiaResponse, IGooglePayIndiaPayload>(
            apiEndpoints.payment.googlePayIndia.sync,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payTappPayment = (payload: ITappPaymentPayload) => {
        return axiosInstance.Post<ITappPaymentResponse, ITappPaymentPayload>(
            apiEndpoints.payment.tapp.payment,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentTappValidateApplePaySession = (payload: ITappValidateApplePaySessionPayload) => {
        return axiosInstance.Post<ITappValidateApplePaySessionResponse, ITappValidateApplePaySessionPayload>(
            apiEndpoints.payment.tapp.applePayValidate,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentTappPayByApple = (payload: ITappPayByApplePayload) => {
        return axiosInstance.Post<ITappApplePayDetails, ITappPayByApplePayload>(
            apiEndpoints.payment.tapp.applePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    // Vostro
    public payVostroPayment = (payload: IVostroPayByDebitPayload) => {
        return axiosInstance.Post<IVostroPayByDebitResponse, IVostroPayByDebitPayload>(
            apiEndpoints.payment.vostro.debit,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 30000,
            },
        );
    };

    public paymentVostroValidateApplePaySession = (payload: IVostroValidateApplePaySessionPayload) => {
        return axiosInstance.Post<IVostroValidateApplePaySessionResponse, IVostroValidateApplePaySessionPayload>(
            apiEndpoints.payment.tapp.applePayValidate,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentVostroPayByApple = (payload: IVostroPayByApplePayload) => {
        return axiosInstance.Post<IVostroPayDetails, IVostroPayByApplePayload>(
            apiEndpoints.payment.tapp.applePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentVostroPayByGoogle = (payload: IVostroPayByGooglePayload) => {
        return axiosInstance.Post<IVostroPayDetails, IVostroPayByGooglePayload>(
            apiEndpoints.payment.checkoutGateway.googlePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentCheckoutSavedCardDetails = () => {
        return axiosInstance.Get<ICheckoutSavedCardDetailsResponse>(
            apiEndpoints.payment.checkoutGateway.savedCardDetails,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentCheckoutPayWithSavedCard = (payload: ICheckoutPayWithSavedCardPayload) => {
        return axiosInstance.Post<ICheckoutPayWithSavedCardResponse, ICheckoutPayWithSavedCardPayload>(
            apiEndpoints.payment.checkoutGateway.sourceIdPay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentCheckoutUnsaveCard = () => {
        return axiosInstance.Post<ICheckoutUnsaveCardResponse>(
            apiEndpoints.payment.checkoutGateway.unsaveCard,
            undefined,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public generateSessionMashreq = (payload: IGenerateSessionMashreqPayload) => {
        return axiosInstance.Post<IGenerateSessionMashreqResponse, IGenerateSessionMashreqPayload>(
            apiEndpoints.payment.mashreq.generateSession,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentMashreqPay = (payload: IPayMashreqPayload) => {
        return axiosInstance.Post<IMashreqPayResponse, IPayMashreqPayload>(apiEndpoints.payment.mashreq.pay, payload, {
            'axios-retry': {
                retries: 3,
            },
            timeout: 45000,
        });
    };

    public paymentMashreqAuthorize = (payload: IMashreqAuthorizePayload) => {
        return axiosInstance.Get<IMashreqAuthorizeResponse>(
            `${apiEndpoints.payment.mashreq.authorize}/${payload.mashreqSessionId}`,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentMashreqValidateApplePaySession = (payload: IMashreqValidateApplePaySessionPayload) => {
        return axiosInstance.Post<IMashreqValidateApplePaySessionResponse, IMashreqValidateApplePaySessionPayload>(
            apiEndpoints.payment.mashreq.applePayValidate,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentMashreqPayByApple = (payload: IMashreqPayByApplePayload) => {
        return axiosInstance.Post<IMashreqDetails, IMashreqPayByApplePayload>(
            apiEndpoints.payment.mashreq.applePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public paymentAdyenCreateSession = (payload: IAdyenCreateSessionPayload) => {
        console.log('paymentAdyenCreateSession', { payload });
        return axiosInstance.Post<IAdyenCreateSessionResponse, IAdyenCreateSessionPayload>(
            apiEndpoints.payment.adyen.createSession,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payAdyenPaymentMethodList = (payload: IAdyenGetMethodListPayload) => {
        console.log('payAdyenPaymentMethodList PAYLOAD BOYLE', payload);
        return axiosInstance.Get<IAdyenGetMethodListResponse, IAdyenGetMethodListPayload>(
            `${apiEndpoints.payment.adyen.paymentMethodList}/${payload.gatewayId}`,
            {
                params: payload.params,
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payAdyenAdvancedPayments = (payload: IAdyenAdvancedPaymentsPayload) => {
        return axiosInstance.Post<IAdyenAdvancedPaymentsResponse, IAdyenAdvancedPaymentsPayload>(
            apiEndpoints.payment.adyen.advancedPayments,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payAdyenValidateApplePay = (payload: IAdyenValidateApplePayPayload) => {
        return axiosInstance.Post<any, IAdyenValidateApplePayPayload>(
            apiEndpoints.payment.adyen.applePayValidate,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    /** n-genius  */
    public payNGeniusValidateApplePay = (payload: INGeniusValidateApplePayPayload) => {
        return axiosInstance.Post<any, INGeniusValidateApplePayPayload>(
            apiEndpoints.payment.nGenius.applePayValidate,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payNGeniusPayByApple = (payload: INGeniusPayByApplePayPayload) => {
        return axiosInstance.Post<INGeniusDetails, INGeniusPayByApplePayPayload>(
            apiEndpoints.payment.nGenius.applePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payNGeniusPayByCard = (payload: INGeniusPayByCardPayload) => {
        return axiosInstance.Post<INGeniusPayByCardResponse, INGeniusPayByCardPayload>(
            apiEndpoints.payment.nGenius.card,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payNGeniusCapture = (payload: INGeniusCapturePayload) => {
        return axiosInstance.Post<INGeniusCaptureResponse, INGeniusCapturePayload>(
            apiEndpoints.payment.nGenius.capture,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    /** tyro */

    public generateSessionTyro = (payload: IGenerateSessionTyroPayload) => {
        return axiosInstance.Post<IGenerateSessionTyroResponse, IGenerateSessionTyroPayload>(
            apiEndpoints.payment.tyro.generateSession,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payTyroPay = (payload: ITyroPayPayload) => {
        return axiosInstance.Post<ITyroPayResponse, ITyroPayPayload>(apiEndpoints.payment.tyro.pay, payload, {
            'axios-retry': {
                retries: 3,
            },
            timeout: 45000,
        });
    };

    public payTyroAuthorize = (payload: ITyroAuthorizePayload) => {
        return axiosInstance.Get<ITyroAuthorizeResponse>(
            `${apiEndpoints.payment.tyro.authorize}/${payload.tyroSessionId}`,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payTyroPayByGoogle = (payload: ITyroPayByGooglePayload) => {
        return axiosInstance.Post<ITyroPayByGoogleResponse, ITyroPayByGooglePayload>(
            apiEndpoints.payment.tyro.googlePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payTyroValidateApplePay = (payload: ITyroValidateApplePayPayload) => {
        return axiosInstance.Post<any, ITyroValidateApplePayPayload>(
            apiEndpoints.payment.tyro.applePayValidate,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };

    public payTyroPayByApple = (payload: ITyroPayByApplePayload) => {
        return axiosInstance.Post<ITyroPayByAppleResponse, ITyroPayByApplePayload>(
            apiEndpoints.payment.tyro.applePay,
            payload,
            {
                'axios-retry': {
                    retries: 3,
                },
                timeout: 45000,
            },
        );
    };
}

export * from './const';
