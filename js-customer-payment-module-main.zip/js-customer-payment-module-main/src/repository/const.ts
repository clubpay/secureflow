export const apiEndpoints = {
    payment: {
        checkoutGateway: {
            applePay: `/checkout-gateway/apple-pay`,
            googlePay: `/checkout-gateway/google-pay`,
            applePayValidate: `/checkout-gateway/apple-pay/validate`,
            paymentVerify: `/checkout-gateway/verify`,
            card: `/checkout-gateway/card`,
            token: `/checkout-gateway/token`,
            savedCardDetails: '/checkout-gateway/saved-card-details',
            sourceIdPay: '/checkout-gateway/source-id-pay',
            unsaveCard: '/checkout-gateway/unsave-card',
            stcPay: '/checkout-gateway/stc-pay-request',
            stcPayCapture: '/checkout-gateway/stc-pay-capture',
        },
        checkoutPlatformGateway: {
            applePay: `/checkout-platform-gateway/apple-pay`,
            googlePay: `/checkout-platform-gateway/google-pay`,
            applePayValidate: `/checkout-platform-gateway/apple-pay/validate`,
            token: `/checkout-platform-gateway/token`,
        },
        payTMLegacyGateway: {
            initiate: `/paytm-legacy-gateway/initiate`,
            verify: `/paytm-legacy-gateway/verify`,
        },
        payTMGateway: {
            initiate: `/paytm-gateway/initiate`,
            verify: `/paytm-gateway/verify`,
        },
        smbc: {
            generateLink: `/smbc/generate-link`,
        },
        stripe: {
            createPaymentIntent: `/stripe-gateway/create-payment-intent`,
            pay: `/stripe-gateway/pay`,
            verify: `/stripe-gateway/verify`,
        },
        stripeConnect: {
            createPaymentIntent: `/stripe-connect-gateway/create-payment-intent`,
            pay: `/stripe-connect-gateway/pay`,
            verify: `/stripe-connect-gateway/verify`,
        },
        dgpay: {
            session: `/dgpay-gateway/threedpayment`,
        },
        tuna: {
            session: `/tuna-gateway/new-session`,
            cardPayment: `/tuna-gateway/card`,
            pixPayment: `/tuna-gateway/pix`,
            verifyPix: `/tuna-gateway/verify-pix`,
            googlePay: `/tuna-gateway/googlepay`,
            applePayValidate: '/tuna-gateway/apple-pay/validate',
            applePay: '/tuna-gateway/apple-pay',
        },
        masterpass: {
            commit: `/masterpass-turkiye/commit`,
            generateToken: `/masterpass-turkiye/generate-token`,
            generateReference: `/masterpass-turkiye/gen-reference`,
            unlink: `/masterpass-turkiye/unlink`,
        },
        masterpasDirect: {
            commit: `/masterpassdirect-turkiye/commit`,
            generateToken: `/masterpassdirect-turkiye/generate-token`,
            generateReference: `/masterpassdirect-turkiye/gen-reference`,
            unlink: `/masterpassdirect-turkiye/unlink`,
        },
        payPay: {
            register: `/paypay-gateway/threedpayment`,
            exec: `/paypay-gateway/inquiry`,
        },
        moyasar: {
            pay: '/moyasar-gateway/pay',
            verify: '/moyasar-gateway/verify',
            createIntent: '/moyasar-gateway/create-intent',
            updateIntent: '/moyasar-gateway/update-intent',
        },

        moyasarV2: {
            applePayValidate: 'https://api.moyasar.com/v1/applepay/initiate',
            applePay: '/moyasarv2-gateway/apple-pay',
        },
        maf: {
            payment: '/maf-gateway/payment',
            generateToken: '/maf-gateway/generate-token',
            verify: '/maf-gateway/verify',
        },
        mafv2: {
            payment: '/maf-gateway-v2/payment',
            verify: '/maf-gateway-v2/verify',
            applePayValidate: '/maf-gateway-v2/apple-pay/validate',
            applePay: '/maf-gateway-v2/apple-pay',
            googlePay: '/maf-gateway-v2/google-pay',
        },
        ticket: {
            generateLink: '/ticket-gateway/generate-link',
        },
        googlePayIndia: {
            sync: '/google-pay-gateway/sync',
        },
        vostro: {
            debit: `/vostro-gateway/debit`,
            applePayValidate: '/vostro-gateway/apple-pay/validate',
            applePay: '/vostro-gateway/apple-pay',
        },
        tapp: {
            payment: '/tap-gateway/token',
            applePayValidate: '/tap-gateway/apple-pay/validate',
            applePay: '/tap-gateway/apple-pay',
        },
        mashreq: {
            generateSession: '/mashreq-gateway/generate-session',
            pay: '/mashreq-gateway/pay',
            applePay: `/mashreq-gateway/apple-pay`,
            applePayValidate: `/mashreq-gateway/apple-pay/validate`,
            authorize: '/mashreq-gateway/pay-with-authorization',
        },
        adyen: {
            createSession: `/adyen-gateway/payment-session`,
            card: `adyen-gateway/card-payment`,
            applePay: `/adyen-gateway/apple-pay`,
            advancedPayments: `/adyen-gateway/pay`,
            applePayValidate: `/adyen-gateway/apple-pay/validate`,
            paymentMethodList: `/adyen-gateway/payment-method-list`,
            paymentDetails: `/adyen-gateway/payment-details`,
        },

        nGenius: {
            card: `/ngenius-gateway/card-pay`,
            applePayValidate: '/ngenius-gateway/apple-pay/validate',
            applePay: '/ngenius-gateway/apple-pay',
            capture: '/ngenius-gateway/capture',
        },

        tyro: {
            generateSession: '/tyro-gateway/generate-session',
            applePay: `/tyro-gateway/apple-pay`,
            googlePay: `/tyro-gateway/google-pay`,
            applePayValidate: `/tyro-gateway/apple-pay/validate`,
            pay: '/tyro-gateway/pay',
            authorize: '/tyro-gateway/pay-with-authorization',
        },
    },
};
