import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';

const incompleteFormErrs = ['incomplete_number', 'incomplete_expiry', 'incomplete_cvc', 'incomplete_zip'];

export const usePaymentError = () => {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar, actionButton } = snackBar();

    const showError = (err?: any, message?: any) => {
        if (err && err.code) {
            if (incompleteFormErrs.indexOf(err.code) > -1) {
                enqueueSnackbar(t('The card information is incorrect, Please check the details and retry'), {
                    variant: 'warning',
                    action: actionButton,
                });

                return;
            }

            if (err.code === 416 && err.items === 'PAYMENT_AMOUNT_IS_ZERO') {
                enqueueSnackbar(t('You are trying to pay for a bill that is already paid for'), {
                    variant: 'error',
                    action: actionButton,
                });

                return;
            }

            if (err.code === 416 && err.items === 'PAYMENT_AMOUNT_IS_TOO_LARGE') {
                enqueueSnackbar(t('You’re paying too much'), {
                    variant: 'warning',
                    action: actionButton,
                });

                return;
            }
        }

        if (message) {
            enqueueSnackbar(message, {
                variant: 'error',
                action: actionButton,
                autoHideDuration: 30000,
            });
            return;
        }

        enqueueSnackbar(t('The payment did not proceed Please try again'), {
            variant: 'error',
            action: actionButton,
            autoHideDuration: 30000,
        });
    };

    return { showError };
};
