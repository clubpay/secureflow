import { PaymentElementEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import * as Sentry from '@sentry/nextjs';
import { useVendor } from '@clubpay/customer-common-module/src/context/vendor';
import { generatePaymentTraceId } from '../utility/payment';

type Args = {
    pgName: string;
    paymentMethod: PaymentElementEnum;
    dineSessionId: string;
};

export const useSentry = ({ pgName, paymentMethod, dineSessionId }: Args) => {
    const { vendor } = useVendor();

    const paymentTrace = vendor?.config?.paymentTrace || vendor?.country?.config?.paymentTrace;
    const paymentTraceException =
        vendor?.config?.paymentTraceException || vendor?.country?.config?.paymentTraceException;

    const startTrace = (action: string, callback: any) => {
        if (paymentTrace) {
            Sentry.startSpan({ name: `${pgName}-${paymentMethod}`, op: 'payment' }, callback);
            const span = Sentry.getActiveSpan();
            span?.setTag('qlub.payment_trace_id', generatePaymentTraceId());
            span?.setTag('qlub.payment_gateway', pgName);
            span?.setTag('qlub.payment_method', paymentMethod);
            span?.setTag('qlub.dine_session_id', dineSessionId);
            span?.setTag('qlub.action', action);
        } else {
            callback();
        }
    };

    const captureException = (e: any) => {
        if (paymentTraceException) Sentry?.captureException(e);
    };

    const infoLog = (message: string, data?: any) => {
        if (paymentTrace) {
            Sentry.addBreadcrumb({
                category: `${pgName}-${paymentMethod}`,
                message,
                level: 'info',
                data,
            });
        }
    };

    const errorLog = (message: string, data?: any) => {
        if (paymentTrace) {
            Sentry.addBreadcrumb({
                category: `${pgName}-${paymentMethod}`,
                message,
                level: 'error',
                data,
            });
        }
    };

    return {
        startTrace,
        captureException,
        infoLog,
        errorLog,
    };
};
