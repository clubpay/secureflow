import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';
import { IExchangeData, IRestaurantConfig } from '@clubpay/customer-common-module/src/repository/vendor';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import {
    IPGDisable,
    IPGExchange,
    PaymentElementEnum,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { getExchangeInterruptionMessage } from '../utility/exchange';
import ExchangeAlert from '../component/ExchangeAlert';

type Parameters = {
    pgConfig?: any;
    restaurantConfig: IRestaurantConfig;
    diningSessionId: string;
    pgName: string;
    pgId: string;
    paymentMethod: PaymentElementEnum;
    restaurantName?: string;
    onExchangeChange?: (payload: Omit<IPGExchange, 'tip'>) => void;
    onPgUnregister?: (payload: IPGDisable) => void;
};

export const useExchangeInteruption = ({
    pgConfig,
    restaurantConfig,
    diningSessionId,
    pgName,
    pgId,
    paymentMethod,
    restaurantName,
    onExchangeChange,
    onPgUnregister,
}: Parameters) => {
    const { triggerSnackBar } = snackBar();
    const { t } = useTranslation('common');

    const triggerInteruption = (exchangeData: IExchangeData, isRoutingApplied?: boolean) => {
        const { newCurrencyCode, exchangeRate, unsupportedCurrency } = exchangeData;

        /** update exchange rate in the customer app
         * if unsupported currency, keep vendor currency as default selected
         */

        onExchangeChange?.({
            currencyCode: newCurrencyCode,
            isApplied: !unsupportedCurrency,
            total: 0,
            ratio: Number(exchangeRate),
            paymentMethod,
            isRoutingApplied,
        });

        if (pgConfig.forexPgReallocationSupportedPaymentMethods?.includes(paymentMethod) && !isRoutingApplied) {
            onPgUnregister?.({
                pgId,
                elem: paymentMethod,
                force: true,
            });
        }

        const toastMessage = unsupportedCurrency
            ? t('Please retry payment')
            : t(getExchangeInterruptionMessage(restaurantConfig), {
                  currencyCode: newCurrencyCode?.toUpperCase(),
              });

        triggerSnackBar(toastMessage, {
            content: (key, message) => <ExchangeAlert id={key} message={message} />,
        });

        onPushEvent('payment_interrupted', {
            pg_name: pgName,
            restaurant_name: restaurantName,
            diningSessionId,
            forex_ui: restaurantConfig.forexUI ?? 'v1',
        });

        if (window.clarity) window.clarity('set', 'isExchangeInterrupted', 'true');
    };

    return { triggerInteruption };
};
