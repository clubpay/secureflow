import { pickBy, size, some } from 'lodash';
import { useTranslation } from '@clubpay/customer-common-module/src/hook/translations';
import { snackBar } from '@clubpay/customer-common-module/src/hook/snackBar';

interface QlubCheckoutErrorMessages extends Record<string, string> {
    20005: string;
    20059: string;
    20082: string;
    20151: string;
    20153: string;
    20154: string;
    20179: string;
    20182: string;
    20183: string;
}

export const isCheckoutError = (message?: string) => {
    return Boolean(message?.replace(/(\[.+])/g, ''));
};

export const useCheckoutErrorExtract = () => {
    const { t } = useTranslation('common');
    const getErrorMessage = (message?: string) => {
        if (!message) {
            return;
        }
        const extractedError = message?.replace(/(\[.+])/g, '');

        const errorCodeMatch = message?.match(/\[(\d+)\]/); // match error code in message

        const errorCode = errorCodeMatch ? errorCodeMatch[1] : null; // extract error code or set to null
        if (!errorCode) {
            return extractedError;
        }

        const qlubCheckoutErrorMessages: QlubCheckoutErrorMessages = {
            '20005': t(
                'The payment has been declined by your bank. Please try a different card or contact your bank for further support.',
            ),
            '20151': t(
                'The payment has been declined due to failed 3DS authentication. Please try again with the same card, or use a different card.',
            ),
            '20059': t(
                'The payment has been declined by your bank. Please try a different card or contact your bank for further support.',
            ),
            '20153': t(
                'The payment failed due to a technical issue. Please try again with the same card, or use a different card.',
            ),
            '20154': t(
                'The payment declined by the bank. Please try again with the same card, or use a different card.',
            ),
            '20179': t(
                'The payment has been declined by your bank. Please try a different card or contact your bank for further support.',
            ),
            '20182': t(
                'The payment has been declined by your bank. Please try a different card or contact your bank for further support.',
            ),
            '20183': t(
                'The payment has been declined by your bank. Please try a different card or contact your bank for further support.',
            ),
            '20082': t(
                'The payment failed, please check your card details and try again with the same or another card.',
            ),
        };

        return qlubCheckoutErrorMessages[errorCode] || extractedError;
    };

    return { getErrorMessage };
};

interface frameData {
    element: string;
    isValid: boolean;
    isEmpty: boolean;
}

interface CardData {
    ['card-number']: frameData;
    ['expiry-date']: frameData;
    cvv: frameData;
}

interface checkoutError {
    type: 'card-number' | 'expiry-date' | 'cvv' | 'otp' | 'multiple-frame' | 'generic';
}

export const useCheckoutErrors = () => {
    const { t } = useTranslation('common');
    const { triggerSnackBar: enqueueSnackbar, actionButton } = snackBar();
    const { getErrorMessage } = useCheckoutErrorExtract();
    const errorTypes = {
        'multiple-frame': t('Card information is invalid. Please check the details and retry.'),
        'card-number': t('Card number is invalid. Please check the details and retry.'),
        'expiry-date': t('Expiry date is invalid. Please check the details and retry.'),
        cvv: t('CVV is invalid. Please check the details and retry.'),
        otp: t('OTP is invalid. Please check the details and retry.'),
        generic: t('Payment did not proceed. Please check the details and retry.'),
    };

    const showError = (msg: checkoutError['type'], force?: boolean) => {
        enqueueSnackbar(force ? msg : errorTypes[msg], {
            variant: 'warning',
            action: actionButton,
        });
    };

    const setErrorType = (cardData: CardData, errorMsg?: string) => {
        if (errorMsg !== undefined) {
            const errorMessage = getErrorMessage(errorMsg);
            if (errorMessage) {
                enqueueSnackbar(errorMessage || errorMsg, {
                    variant: 'warning',
                    action: actionButton,
                });
                return;
            }
        }

        const notValidCounter = size(
            pickBy(cardData, (obj: any) => {
                return !obj.isValid;
            }),
        );

        const hasAnyError = some(cardData, (obj: any) => {
            return !obj.isValid;
        });

        if (notValidCounter >= 2 && hasAnyError) {
            showError('multiple-frame');
            return;
        }

        // get errors keys
        const error = Object.keys(cardData).find((key) => !cardData[key as keyof CardData].isValid);
        console.log({ error });

        if (error) {
            showError(error as checkoutError['type']);
            return;
        }

        showError('generic');
    };

    return { setErrorType };
};
