import { useCallback } from 'react';
import { onPushEvent } from '@clubpay/customer-common-module/src/lib/gtm';

interface Props {
    pgName: string;
    restaurantName: string;
    diningSessionId: string;
}

export const usePgEvent = ({ pgName, restaurantName, diningSessionId }: Props) => {
    const sendEvent = useCallback((eventName: string, params?: Record<string, unknown>) => {
        onPushEvent(eventName, { page_name: pgName, restaurant_name: restaurantName, diningSessionId, ...params });
    }, []);

    return { sendEvent };
};
