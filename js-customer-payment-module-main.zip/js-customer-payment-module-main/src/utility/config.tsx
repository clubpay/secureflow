import { IConfig } from '@clubpay/customer-common-module/src/repository/config';
import { IRestaurantConfig } from '@clubpay/customer-common-module/src/repository/vendor';

export const getConfig = (
    vendorConfig: IRestaurantConfig | undefined,
    countryConfig: IConfig | null,
    key?: keyof IRestaurantConfig | keyof IConfig,
) => {
    if (
        vendorConfig?.[key as keyof IRestaurantConfig] === null ||
        vendorConfig?.[key as keyof IRestaurantConfig] === undefined ||
        vendorConfig?.[key as keyof IRestaurantConfig] === ''
    ) {
        return countryConfig?.[key as keyof IConfig];
    }
    return vendorConfig?.[key as keyof IRestaurantConfig];
};
