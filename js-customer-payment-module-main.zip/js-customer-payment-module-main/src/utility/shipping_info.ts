import { qlubSessionStorage } from '@clubpay/customer-common-module/src/service/storage/sessionStorage';
import { PaymentTypeEnum } from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IStripeGateway, ITappGatewayConfig } from '../repository/type/paymentGateway';

export const disableApplePayBilling = () => {
    qlubSessionStorage.set('qlub.payment.apple.disable_billing', 'true');
};

export const getApplePayShippingBillingConfig: any = (
    config: IStripeGateway | ITappGatewayConfig,
    paymentGateway: PaymentTypeEnum,
) => {
    const isCanceled = qlubSessionStorage.get('qlub.payment.apple.disable_billing');
    if (isCanceled) return {};

    if (paymentGateway === PaymentTypeEnum.Stripe || paymentGateway === PaymentTypeEnum.StripeConnect) {
        const stripeConfig = {
            requestPayerName: false,
            requestPayerEmail: false,
            requestPayerPhone: false,
        };

        if (config.applePayShippingDetails) {
            stripeConfig.requestPayerName = true;
            stripeConfig.requestPayerEmail = true;
            stripeConfig.requestPayerPhone = true;
        }
        if (config.applePayBillingDetails) {
            stripeConfig.requestPayerName = true;
            stripeConfig.requestPayerEmail = true;
            stripeConfig.requestPayerPhone = true;
        }

        return stripeConfig;
    }

    if (paymentGateway === PaymentTypeEnum.Tapp) {
        const tappConfig: Pick<
            ApplePayJS.ApplePayPaymentRequest,
            'requiredShippingContactFields' | 'requiredBillingContactFields'
        > = {};

        if (config.applePayShippingDetails) {
            tappConfig.requiredShippingContactFields = ['phone', 'email', 'name'];
        }
        if (config.applePayBillingDetails) {
            tappConfig.requiredBillingContactFields = ['phone', 'email', 'name'];
        }

        return tappConfig;
    }

    const defaultConfig: Pick<
        ApplePayJS.ApplePayPaymentRequest,
        'requiredShippingContactFields' | 'requiredBillingContactFields'
    > = {};

    if (config.applePayShippingDetails) {
        defaultConfig.requiredShippingContactFields = ['phone', 'email', 'name'];
    }
    if (config.applePayBillingDetails) {
        defaultConfig.requiredBillingContactFields = ['phone', 'email', 'name'];
    }

    return defaultConfig;
};
