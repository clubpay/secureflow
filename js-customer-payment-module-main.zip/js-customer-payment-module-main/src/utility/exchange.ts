import {
    IPGExchange,
    PaymentExchangeDecision,
} from '@clubpay/customer-common-module/src/repository/common/payment/type';
import { IRestaurantConfig } from '@clubpay/customer-common-module/src/repository/vendor';
import Router from 'next/router';

export const getPaymentExchangeDecision = (exchange?: IPGExchange) => {
    if (!exchange) {
        return PaymentExchangeDecision.ExchangeUndecided;
    }
    if (exchange.isApplied) {
        return PaymentExchangeDecision.UseForeignCurrency;
    }
    return PaymentExchangeDecision.UseLocalCurrency;
};

export const getExchangeInterruptionMessage = (config: IRestaurantConfig) => {
    const defaultMessage = 'Please retry payment, you will be charged in {{currencyCode}}';
    if (config.exchangeInterruptionMessage) {
        const lang = Router.query.lang || 'en';
        const locale = JSON.parse(config?.exchangeInterruptionMessage).find((item: any) => item.locale === lang);
        return locale?.value || defaultMessage;
    }
    return defaultMessage;
};
