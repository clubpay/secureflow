import { v4 as uuidv4 } from 'uuid';
import { Visa, Mastercard, Amex, JCB, UnionPay, Discover, Mada } from '../asset/icon';

export const generatePaymentTraceId = () => {
    let paymentTraceId = sessionStorage.getItem('payment_trace_id');
    if (paymentTraceId) return paymentTraceId;

    paymentTraceId = uuidv4();
    sessionStorage.setItem('payment_trace_id', paymentTraceId);

    return paymentTraceId;
};

export const getCardNetworkIcons = (supportNetworksList: string[] = []) => {
    const icons: any[] = [];

    if (supportNetworksList.length === 0)
        return [<Visa />, <Mastercard />, <Amex />, <JCB />, <UnionPay />, <Discover />];

    if (supportNetworksList?.includes('visa')) {
        icons.push(<Visa />);
    }
    if (supportNetworksList?.includes('masterCard')) {
        icons.push(<Mastercard />);
    }
    if (supportNetworksList?.includes('amex')) {
        icons.push(<Amex />);
    }
    if (supportNetworksList?.includes('jcb')) {
        icons.push(<JCB />);
    }
    if (supportNetworksList?.includes('unionPay') || supportNetworksList?.includes('chinaUnionPay')) {
        icons.push(<UnionPay />);
    }
    if (supportNetworksList?.includes('discover')) {
        icons.push(<Discover />);
    }
    if (supportNetworksList?.includes('mada')) {
        icons.push(<Mada />);
    }
    return icons;
};
