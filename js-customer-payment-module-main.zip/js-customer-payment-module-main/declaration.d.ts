/// <reference types="styled-jsx" />
declare module "*.css";
declare module "*.scss";
declare module "*.svg";
