## [1.14.3](https://github.com/clubpay/js-customer-payment-module/compare/v1.14.2...v1.14.3) (2025-01-22)


### Bug Fixes

* fix translation package ([#258](https://github.com/clubpay/js-customer-payment-module/issues/258)) ([f7a5c7a](https://github.com/clubpay/js-customer-payment-module/commit/f7a5c7aa69e9a90b375281eb9229aeebfdce65e0))

## [1.14.2](https://github.com/clubpay/js-customer-payment-module/compare/v1.14.1...v1.14.2) (2025-01-13)


### Bug Fixes

* fix stripe pay now button ([#257](https://github.com/clubpay/js-customer-payment-module/issues/257)) ([8f4daef](https://github.com/clubpay/js-customer-payment-module/commit/8f4daef451507ba56755c4669db6cec489d80bba))

## [1.14.1](https://github.com/clubpay/js-customer-payment-module/compare/v1.14.0...v1.14.1) (2024-11-26)


### Bug Fixes

* remove post install script ([#256](https://github.com/clubpay/js-customer-payment-module/issues/256)) ([55ec7db](https://github.com/clubpay/js-customer-payment-module/commit/55ec7db8eb77e1bd47eb69c6aeb41ec671e968d2))

# [1.14.0](https://github.com/clubpay/js-customer-payment-module/compare/v1.13.5...v1.14.0) (2024-10-02)


### Features

* paym 821 nextjs update ([#255](https://github.com/clubpay/js-customer-payment-module/issues/255)) ([b4d4fb5](https://github.com/clubpay/js-customer-payment-module/commit/b4d4fb5dfeaa9b16f67b2ca04ec59bc48c087cab))

## [1.13.5](https://github.com/clubpay/js-customer-payment-module/compare/v1.13.4...v1.13.5) (2024-09-12)


### Bug Fixes

* paym 1157 update ticketpay logo ([#254](https://github.com/clubpay/js-customer-payment-module/issues/254)) ([62b1978](https://github.com/clubpay/js-customer-payment-module/commit/62b197837fc4dcc26667888ffdefc5fe07499f62))

## [1.13.4](https://github.com/clubpay/js-customer-payment-module/compare/v1.13.3...v1.13.4) (2024-08-26)


### Bug Fixes

* paym 1168 tyro add brands ([#253](https://github.com/clubpay/js-customer-payment-module/issues/253)) ([6799c52](https://github.com/clubpay/js-customer-payment-module/commit/6799c52b410c9fc9dd61d0018ade1d0ad71392d4))

## [1.13.3](https://github.com/clubpay/js-customer-payment-module/compare/v1.13.2...v1.13.3) (2024-08-22)


### Bug Fixes

* paym-1070 adyen network issue ([#248](https://github.com/clubpay/js-customer-payment-module/issues/248)) ([02f1d3e](https://github.com/clubpay/js-customer-payment-module/commit/02f1d3eb876dc3751db8f96d75bea95049181572))

## [1.13.2](https://github.com/clubpay/js-customer-payment-module/compare/v1.13.1...v1.13.2) (2024-08-13)


### Bug Fixes

* paym 952 new phone input ([#250](https://github.com/clubpay/js-customer-payment-module/issues/250)) ([3823a5a](https://github.com/clubpay/js-customer-payment-module/commit/3823a5adb462bda14859a146737ac52efee43fe4))

## [1.13.1](https://github.com/clubpay/js-customer-payment-module/compare/v1.13.0...v1.13.1) (2024-08-08)


### Bug Fixes

* fix ngenius 3ds ui issue ([#252](https://github.com/clubpay/js-customer-payment-module/issues/252)) ([3258554](https://github.com/clubpay/js-customer-payment-module/commit/32585546f8d967fe1bf07467a71a62be53cf218c))

# [1.13.0](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.19...v1.13.0) (2024-07-29)


### Features

* paym 1064 forex new design ([#251](https://github.com/clubpay/js-customer-payment-module/issues/251)) ([f7e5304](https://github.com/clubpay/js-customer-payment-module/commit/f7e530406f535d0a229e58940f22fe70c1008d57))

## [1.12.19](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.18...v1.12.19) (2024-07-11)


### Bug Fixes

* paym 1084 fix element loading ([#249](https://github.com/clubpay/js-customer-payment-module/issues/249)) ([8b476fe](https://github.com/clubpay/js-customer-payment-module/commit/8b476fee647f0c8e27b7016d94a11d97f85ecaa1))

## [1.12.18](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.17...v1.12.18) (2024-06-26)


### Bug Fixes

* update tyro prod sdk url ([#247](https://github.com/clubpay/js-customer-payment-module/issues/247)) ([0b8ffd8](https://github.com/clubpay/js-customer-payment-module/commit/0b8ffd8afaef913f56c3e40f6d5977cc70ee0adb))

## [1.12.17](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.16...v1.12.17) (2024-06-24)


### Bug Fixes

* add sentry config ([#243](https://github.com/clubpay/js-customer-payment-module/issues/243)) ([80abae2](https://github.com/clubpay/js-customer-payment-module/commit/80abae2fdff2886b40bdcf8bebc661120d7f5d13))
* paym 1051 sentry config ([#246](https://github.com/clubpay/js-customer-payment-module/issues/246)) ([6846273](https://github.com/clubpay/js-customer-payment-module/commit/6846273589b2f1fce9ad9bfd8d5d457c2f267909))
* paym 1057 add product type ([#244](https://github.com/clubpay/js-customer-payment-module/issues/244)) ([650760b](https://github.com/clubpay/js-customer-payment-module/commit/650760b3b6cfdad9d6e3e5e7baed440d2b688914))


### Reverts

* Revert "fix: paym 1057 add product type (#244)" (#245) ([5f5d6b4](https://github.com/clubpay/js-customer-payment-module/commit/5f5d6b4f633558bfe969941d2ebb903b15a9adef)), closes [#244](https://github.com/clubpay/js-customer-payment-module/issues/244) [#245](https://github.com/clubpay/js-customer-payment-module/issues/245)

## [1.12.16](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.15...v1.12.16) (2024-06-14)


### Bug Fixes

* remove unwanted logs ([#241](https://github.com/clubpay/js-customer-payment-module/issues/241)) ([9fbd392](https://github.com/clubpay/js-customer-payment-module/commit/9fbd392b5b4da985868c721ce9f77b615cb17eaa))
* remove unwanted logs ([#242](https://github.com/clubpay/js-customer-payment-module/issues/242)) ([306a008](https://github.com/clubpay/js-customer-payment-module/commit/306a00876f861cd3812d5641f766fe2455a1bd28))

## [1.12.15](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.14...v1.12.15) (2024-06-13)


### Bug Fixes

* paym 1028 refactor sentry logs ([#240](https://github.com/clubpay/js-customer-payment-module/issues/240)) ([3cb9f53](https://github.com/clubpay/js-customer-payment-module/commit/3cb9f5389b89c6bd4550a357b22251b27a4b0ada))

## [1.12.14](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.13...v1.12.14) (2024-06-03)


### Bug Fixes

* paym 975 support routing with forex ([#237](https://github.com/clubpay/js-customer-payment-module/issues/237)) ([e37cf55](https://github.com/clubpay/js-customer-payment-module/commit/e37cf551f92a88547abdfd94ccf1f3c04f9a19c4))

## [1.12.13](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.12...v1.12.13) (2024-05-29)


### Bug Fixes

* update sentry logs ([#236](https://github.com/clubpay/js-customer-payment-module/issues/236)) ([10f5835](https://github.com/clubpay/js-customer-payment-module/commit/10f58357b0add4b13fd394f90cba030dd6014d9f))

## [1.12.12](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.11...v1.12.12) (2024-05-29)


### Bug Fixes

* paym-972 update ngenius frontend logic ([#235](https://github.com/clubpay/js-customer-payment-module/issues/235)) ([73b0887](https://github.com/clubpay/js-customer-payment-module/commit/73b088776055f7df21bf34ebd8f77175845997a4))

## [1.12.11](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.10...v1.12.11) (2024-05-27)


### Bug Fixes

* update sentry logs ([#234](https://github.com/clubpay/js-customer-payment-module/issues/234)) ([ed47ebc](https://github.com/clubpay/js-customer-payment-module/commit/ed47ebc9d8d18fc52c40511a4cb6d2888ea5e270))

## [1.12.10](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.9...v1.12.10) (2024-05-22)


### Bug Fixes

* update sentry logs ([#233](https://github.com/clubpay/js-customer-payment-module/issues/233)) ([32d57e1](https://github.com/clubpay/js-customer-payment-module/commit/32d57e1ab7814be2334989fddca99459d69dba40))

## [1.12.9](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.8...v1.12.9) (2024-05-20)


### Bug Fixes

* update sentry logs ([#232](https://github.com/clubpay/js-customer-payment-module/issues/232)) ([01e3a02](https://github.com/clubpay/js-customer-payment-module/commit/01e3a02277fe7f6790134ae6fae85f38b61de759))

## [1.12.8](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.7...v1.12.8) (2024-05-20)


### Bug Fixes

* paym 939 add card type to checkout ([#231](https://github.com/clubpay/js-customer-payment-module/issues/231)) ([9b8c573](https://github.com/clubpay/js-customer-payment-module/commit/9b8c5736ab09ed8aafea0caf1a364e74f725eeb1))

## [1.12.7](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.6...v1.12.7) (2024-05-09)


### Bug Fixes

* add additional data to sentry ([#230](https://github.com/clubpay/js-customer-payment-module/issues/230)) ([6c8f90d](https://github.com/clubpay/js-customer-payment-module/commit/6c8f90dc9a0273233ed8d9c166e2022b791c5e31))

## [1.12.6](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.5...v1.12.6) (2024-05-06)


### Bug Fixes

* fix path ([#229](https://github.com/clubpay/js-customer-payment-module/issues/229)) ([3416819](https://github.com/clubpay/js-customer-payment-module/commit/3416819fe517e9d7cb4a518e17276db2e12b7d40))

## [1.12.5](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.4...v1.12.5) (2024-05-06)


### Bug Fixes

* paym 917 update ngenius ([#228](https://github.com/clubpay/js-customer-payment-module/issues/228)) ([7dfb899](https://github.com/clubpay/js-customer-payment-module/commit/7dfb899e377f997b1846ed0b8e2cd7f62f4791b7))

## [1.12.4](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.3...v1.12.4) (2024-04-25)


### Bug Fixes

* paym 892 add google event to 3ds ([#227](https://github.com/clubpay/js-customer-payment-module/issues/227)) ([02f6b6f](https://github.com/clubpay/js-customer-payment-module/commit/02f6b6f4304f65af9b7285b3a9f1668b4e208b82))

## [1.12.3](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.2...v1.12.3) (2024-04-17)


### Bug Fixes

* release 6.56.0 ([#224](https://github.com/clubpay/js-customer-payment-module/issues/224)) ([02d4946](https://github.com/clubpay/js-customer-payment-module/commit/02d49461977ceae67242202687abfbc9a1dc2889))

## [1.12.2](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.1...v1.12.2) (2024-04-04)


### Bug Fixes

* paym-874 adyen environment issue ([#222](https://github.com/clubpay/js-customer-payment-module/issues/222)) ([d131fa3](https://github.com/clubpay/js-customer-payment-module/commit/d131fa3db1763e812d05cd4223c675ec055d1ab1))

## [1.12.1](https://github.com/clubpay/js-customer-payment-module/compare/v1.12.0...v1.12.1) (2024-04-03)


### Bug Fixes

* paym 875 forex update ([#221](https://github.com/clubpay/js-customer-payment-module/issues/221)) ([4c08754](https://github.com/clubpay/js-customer-payment-module/commit/4c08754b247a076efc01d0376d9036f91384d0fe))

# [1.12.0](https://github.com/clubpay/js-customer-payment-module/compare/v1.11.1...v1.12.0) (2024-03-27)


### Features

* tyro and applepay retry ([#219](https://github.com/clubpay/js-customer-payment-module/issues/219)) ([7ef8a60](https://github.com/clubpay/js-customer-payment-module/commit/7ef8a6012188293fe5f8852eb38d7bd723a77f70))

## [1.11.1](https://github.com/clubpay/js-customer-payment-module/compare/v1.11.0...v1.11.1) (2024-03-25)


### Bug Fixes

* common module updated ([7b698f6](https://github.com/clubpay/js-customer-payment-module/commit/7b698f6c2b33e79272738c1d5a83058e7a3de4bb))

# [1.11.0](https://github.com/clubpay/js-customer-payment-module/compare/v1.10.1...v1.11.0) (2024-03-19)


### Features

* paym-825 pg reallocation ([#214](https://github.com/clubpay/js-customer-payment-module/issues/214)) ([052d9c5](https://github.com/clubpay/js-customer-payment-module/commit/052d9c584459d6199b9669a22eaa25d926c6ae3b))

## [1.10.1](https://github.com/clubpay/js-customer-payment-module/compare/v1.10.0...v1.10.1) (2024-03-07)


### Bug Fixes

* release 6.4x.0 ([#213](https://github.com/clubpay/js-customer-payment-module/issues/213)) ([15f6bb8](https://github.com/clubpay/js-customer-payment-module/commit/15f6bb8c789caa53c6b90f8048ba8722fc880ff6))

# [1.10.0](https://github.com/clubpay/js-customer-payment-module/compare/v1.9.2...v1.10.0) (2024-02-26)


### Features

* adyen release ([#210](https://github.com/clubpay/js-customer-payment-module/issues/210)) ([2f30ba3](https://github.com/clubpay/js-customer-payment-module/commit/2f30ba30dd725d62ce42fa5a8a0c51ad15c26eb2))

## [1.9.2](https://github.com/clubpay/js-customer-payment-module/compare/v1.9.1...v1.9.2) (2024-02-15)


### Bug Fixes

* release 6.36.0 ([#198](https://github.com/clubpay/js-customer-payment-module/issues/198)) ([9b2e909](https://github.com/clubpay/js-customer-payment-module/commit/9b2e9095044ce49f708d12e749037758e24cca08))

## [1.9.1](https://github.com/clubpay/js-customer-payment-module/compare/v1.9.0...v1.9.1) (2024-02-05)


### Bug Fixes

* add pending status ([#191](https://github.com/clubpay/js-customer-payment-module/issues/191)) ([404c154](https://github.com/clubpay/js-customer-payment-module/commit/404c1544571af0fa9aebf0a7e8358e3a3a6d3bcd))

# [1.9.0](https://github.com/clubpay/js-customer-payment-module/compare/v1.8.2...v1.9.0) (2024-01-29)
# [1.10.0-alpha.6](https://github.com/clubpay/js-customer-payment-module/compare/v1.10.0-alpha.5...v1.10.0-alpha.6) (2024-02-16)


### Features

* testing googlepay adyen ([ee86c5a](https://github.com/clubpay/js-customer-payment-module/commit/ee86c5ae6ae57547d682bd9a0dd6bbd5208fcaa2))

# [1.10.0-alpha.5](https://github.com/clubpay/js-customer-payment-module/compare/v1.10.0-alpha.4...v1.10.0-alpha.5) (2024-02-15)


### Features

* added googlepay ([afd63f1](https://github.com/clubpay/js-customer-payment-module/commit/afd63f15d5b540689c4804072a5bd33b55972395))

# [1.10.0-alpha.4](https://github.com/clubpay/js-customer-payment-module/compare/v1.10.0-alpha.3...v1.10.0-alpha.4) (2024-02-15)


### Bug Fixes

* add pending ([3e62f4e](https://github.com/clubpay/js-customer-payment-module/commit/3e62f4e5c71a264029e3c91b896492b1386ec4ec))
* add pending ([b8ce919](https://github.com/clubpay/js-customer-payment-module/commit/b8ce9197bf464208fdc9b141371545232d1750fe))

# [1.10.0-alpha.3](https://github.com/clubpay/js-customer-payment-module/compare/v1.10.0-alpha.2...v1.10.0-alpha.3) (2024-02-15)


### Bug Fixes

* change attribute ([0ac006b](https://github.com/clubpay/js-customer-payment-module/commit/0ac006bd27b1f7c3a16f63424976e43fde4fa53e))

# [1.10.0-alpha.2](https://github.com/clubpay/js-customer-payment-module/compare/v1.10.0-alpha.1...v1.10.0-alpha.2) (2024-02-15)


### Bug Fixes

* update type ([6176ec0](https://github.com/clubpay/js-customer-payment-module/commit/6176ec008bc3a6aacc794af75aef9aeb05268ee0))

# [1.10.0-alpha.1](https://github.com/clubpay/js-customer-payment-module/compare/v1.9.1...v1.10.0-alpha.1) (2024-02-15)


### Bug Fixes

* a null check ([6a89152](https://github.com/clubpay/js-customer-payment-module/commit/6a89152e0f01bf4fab152a47430b38bfdfd2bfea))
* added fail error log ([6f011e7](https://github.com/clubpay/js-customer-payment-module/commit/6f011e71c4a013c2d93a514546abc4399b188661))
* added Masterpass direct to the ([8b94263](https://github.com/clubpay/js-customer-payment-module/commit/8b942630bc4bbe0dcbb6b908bbb5f773a61f29ff))
* added new logs ([6355543](https://github.com/clubpay/js-customer-payment-module/commit/635554306818fe6ba74d78971d85cb3eac54be17))
* added onunlock hook where needed ([04bf2d4](https://github.com/clubpay/js-customer-payment-module/commit/04bf2d46ddb3e604b0d56b5daa0cfc18b09e1da3))
* added type to error ([c9e0ba9](https://github.com/clubpay/js-customer-payment-module/commit/c9e0ba92f2d6a673492e4c7e1ffac7cc123315fd))
* applepay component ref nullcheck ([bc067a5](https://github.com/clubpay/js-customer-payment-module/commit/bc067a5f7c669e57eeb23dd16ffb3e10b29f4a18))
* attempt to pass the build ([dc16104](https://github.com/clubpay/js-customer-payment-module/commit/dc161041b040f067e8e37ba932cc16a9f5a191e7))
* **c:** applepay button fix ([3629008](https://github.com/clubpay/js-customer-payment-module/commit/36290087211086389d04d5bcfe61d19d26611cad))
* change the iterator variable ([982bd6b](https://github.com/clubpay/js-customer-payment-module/commit/982bd6bb650741db025625e414d677aa3ceb0913))
* changed component name ([1688e90](https://github.com/clubpay/js-customer-payment-module/commit/1688e90ec52abd533d34da2a7d8ff0f2efdfea6d))
* changed due to adjust advanced impl ([292255c](https://github.com/clubpay/js-customer-payment-module/commit/292255c382501626ff2fac77a95d830851a8834d))
* changed error handling to only log err ([253fde4](https://github.com/clubpay/js-customer-payment-module/commit/253fde4045dbf292a150097ace9fc3cba273e1e5))
* changed logic ([e28e855](https://github.com/clubpay/js-customer-payment-module/commit/e28e8553d635eaad76cbee97982be5de50eb327e))
* changed payment method response type ([ee145a7](https://github.com/clubpay/js-customer-payment-module/commit/ee145a7d299226e7a25cad26c688ffa58416d1b8))
* changed switch case aproach ([41b26d6](https://github.com/clubpay/js-customer-payment-module/commit/41b26d606925ebd42e7e8b00ff3184f1ea668f97))
* changed the flow ([937d9c3](https://github.com/clubpay/js-customer-payment-module/commit/937d9c3eabfe7ae512a8c1bb46269c445c038376))
* changed the redirect ([a7e9d9f](https://github.com/clubpay/js-customer-payment-module/commit/a7e9d9f20907f2eec6b8549d11f91a6d4c480345))
* changed the way of importing paapi manager ([3d2c16f](https://github.com/clubpay/js-customer-payment-module/commit/3d2c16fb6bdcd5627b4379bcb3989d32d8b5c548))
* changed the way to get payment method response ([7a9da37](https://github.com/clubpay/js-customer-payment-module/commit/7a9da37578087c2d6ba14d4e1e3d4e6f1458265a))
* deployment issues ([87b14f5](https://github.com/clubpay/js-customer-payment-module/commit/87b14f5056294fc50e82075de9062a16f177ab90))
* fix moyasar crash ([1edfbd2](https://github.com/clubpay/js-customer-payment-module/commit/1edfbd2c67c6b9b23fb508313db13869a149cbd2))
* fix moyasar v1 config ([a9aab7c](https://github.com/clubpay/js-customer-payment-module/commit/a9aab7c89a185377d059e04540feb163beae4e66))
* fix moyasar v1 crash ([9a9a624](https://github.com/clubpay/js-customer-payment-module/commit/9a9a624bd26be6be559c867c214073cc4b2c24f0))
* fix path ([b35c794](https://github.com/clubpay/js-customer-payment-module/commit/b35c7947986dec40581e5c9168b31a0a7417a2b0))
* fix status check ([ecffad5](https://github.com/clubpay/js-customer-payment-module/commit/ecffad52f1e5c7a0710d4767802d7bd5b9be29e5))
* fixed applepay button style ([88a87da](https://github.com/clubpay/js-customer-payment-module/commit/88a87daf04f37e82643e2ef52a849f439e249ec3))
* fixed common module version ([35e6e02](https://github.com/clubpay/js-customer-payment-module/commit/35e6e02fe6537b6571329389fc9f14765981f109))
* fixed import way compatible with customer app ([3c12b2e](https://github.com/clubpay/js-customer-payment-module/commit/3c12b2ed062402e4dd853da87c440d4dd4accdd2))
* fixed possible undefined value to pass deploy ([9f3a55c](https://github.com/clubpay/js-customer-payment-module/commit/9f3a55c3676b84a2809fd6482c0d2e94f1b8807a))
* fixed styles ([c1fca09](https://github.com/clubpay/js-customer-payment-module/commit/c1fca09e6afbbc3cd45f70b42abdfc3c2fd2a265))
* fixed the common modules version number ([722725a](https://github.com/clubpay/js-customer-payment-module/commit/722725a63b41ef4eaa08b9d93b783e6ca103af3a))
* fixed the typo ([905ba2a](https://github.com/clubpay/js-customer-payment-module/commit/905ba2ac831a7ff2088852d19f5612325b8e7606))
* fixed the typo on the class name ([28758e8](https://github.com/clubpay/js-customer-payment-module/commit/28758e8e5aa45984095b5eb47f9421e840144629))
* init adyen new implementatio ([0df7053](https://github.com/clubpay/js-customer-payment-module/commit/0df70538da91aa678660b768244df2828adc79cd))
* logged card button freeze reasons ([fc084e4](https://github.com/clubpay/js-customer-payment-module/commit/fc084e4d98cc12a21ef3d3d6116a7f44e67a8ec0))
* multi pg issue index.tsx ([4e1b3bc](https://github.com/clubpay/js-customer-payment-module/commit/4e1b3bccb6b4f32055799d0b99e3096233a3f3a8))
* new approach on style ([ef9d3d7](https://github.com/clubpay/js-customer-payment-module/commit/ef9d3d785227070bab6eb01def061ebcca5d5d43))
* null check ([95fbbeb](https://github.com/clubpay/js-customer-payment-module/commit/95fbbebc9da368e01a018a779a7d262da1e4797d))
* refactored form field component ([d06a3ee](https://github.com/clubpay/js-customer-payment-module/commit/d06a3ee0519b449f0a0ab36b513650ebb3e594f8))
* refactored the result code handling based on be changes ([790fb82](https://github.com/clubpay/js-customer-payment-module/commit/790fb82bb176649303171d58b5688d750e63830e))
* removed multimple import of validate response ([0fb9241](https://github.com/clubpay/js-customer-payment-module/commit/0fb9241fd526c58120d0566f7aa4ae0a8571c8a1))
* removed unnecessary repeated file ([54044a5](https://github.com/clubpay/js-customer-payment-module/commit/54044a5d8edddfa7fd1ff80a46aef54ba876c0af))
* reverted the test ([d60ce7e](https://github.com/clubpay/js-customer-payment-module/commit/d60ce7ec511c25838e49b885fcb4129a693063ed))
* reverted unnecessary code ([44244fc](https://github.com/clubpay/js-customer-payment-module/commit/44244fc4a2acc4b57e0d64217ca6159edae93f05))
* specify type ([62d63ce](https://github.com/clubpay/js-customer-payment-module/commit/62d63ce86e9324dc27a72330b865442bac2029bf))
* style ([3b0389b](https://github.com/clubpay/js-customer-payment-module/commit/3b0389b1c79264c755466aaafba96c1c66eb3590))
* style fix ([e7f02c2](https://github.com/clubpay/js-customer-payment-module/commit/e7f02c2e9f4242531abfe1328cfaa3979416ee65))
* to be able to pass the deploy ([765d059](https://github.com/clubpay/js-customer-payment-module/commit/765d059628ff3ca36641bb3192fcf6967060deea))
* tried to fix the build error ([5a98917](https://github.com/clubpay/js-customer-payment-module/commit/5a98917140ffb88193df96252090d7a4b88539e0))
* tried to pass no node error ([ecb7416](https://github.com/clubpay/js-customer-payment-module/commit/ecb74160a66e339162341786b50e068cb2be5464))
* tried to stabilize refid ([0b1e47d](https://github.com/clubpay/js-customer-payment-module/commit/0b1e47d9a067835c4c4d219ce36e83e586376026))
* trying to change the payload to get methods ([470ca4b](https://github.com/clubpay/js-customer-payment-module/commit/470ca4bf393a42fb8de8c6e95cc3a34afcac23bc))
* trying to get method list ([a4605df](https://github.com/clubpay/js-customer-payment-module/commit/a4605dfc2db422b8f02560b5e638085b11769511))
* trying to see the config ([3600ee3](https://github.com/clubpay/js-customer-payment-module/commit/3600ee328b3b1b5cbbed386a1e4e5aed15362ae8))
* trying to step over from the customer app error ([269bd78](https://github.com/clubpay/js-customer-payment-module/commit/269bd78db14d6028f9b7bddd439f0e62d7f2aa95))
* update name ([730817a](https://github.com/clubpay/js-customer-payment-module/commit/730817a59079f9d168a421bb92ef30ae65eab91b))
* update package ([24cd56e](https://github.com/clubpay/js-customer-payment-module/commit/24cd56e099231a33eb8785671f6f02133bda640b))
* updated the common module ([0f4e8f1](https://github.com/clubpay/js-customer-payment-module/commit/0f4e8f1bb75981aee60778f95933b5eb47971816))


### Features

* add applepay ([bfa1e95](https://github.com/clubpay/js-customer-payment-module/commit/bfa1e9540c32943da62327d415a67054c5eb862c))
* add style for button ([824f2b3](https://github.com/clubpay/js-customer-payment-module/commit/824f2b3d0c4d6b257b9ba786a2ac78d2addd4793))
* added a function to remove special chars ([0de98b4](https://github.com/clubpay/js-customer-payment-module/commit/0de98b42917e573afebd736f2ee7a029b0acd3b5))
* added a function to remove special chars ([e8a496f](https://github.com/clubpay/js-customer-payment-module/commit/e8a496f309e2cc759b93bdaa54fe1e8a6a0bd01a))
* added advanced flow logic ([c536372](https://github.com/clubpay/js-customer-payment-module/commit/c536372885752b6daeb420071acbc8ebd05dcee7))
* added applepay ([8cda284](https://github.com/clubpay/js-customer-payment-module/commit/8cda284f7f216b44093621601154ce3b8a89ec5c))
* added config ([c0680ae](https://github.com/clubpay/js-customer-payment-module/commit/c0680ae827695f87ba289676f3ce9bc144c1bbdc))
* added default case for redirecting ([73af8fa](https://github.com/clubpay/js-customer-payment-module/commit/73af8faaeb1a9c3a412ac7282164b706ac401c80))
* added fix ([a2c6a94](https://github.com/clubpay/js-customer-payment-module/commit/a2c6a94e1a24d516af8bb044066fa185dd028b6f))
* added flow changes ([9e18bfc](https://github.com/clubpay/js-customer-payment-module/commit/9e18bfc1458c487bfe1d389fe4680365d0c75c11))
* added masterpass direct ([e55cbcb](https://github.com/clubpay/js-customer-payment-module/commit/e55cbcb1e5d2d659eb946821e9dd3c06fb188e3e))
* added maximum char limit to ref str ([4316811](https://github.com/clubpay/js-customer-payment-module/commit/4316811ab0d331f3c91221b154cffed944333eb0))
* added missing advanced payments service ([9822df3](https://github.com/clubpay/js-customer-payment-module/commit/9822df3985603782efe00a60ce489769401121f0))
* added missing endpoint ([e351cbf](https://github.com/clubpay/js-customer-payment-module/commit/e351cbff504bbca32e50c2d85ec83e74e80b8d0f))
* added missing endpoints ([7980f5b](https://github.com/clubpay/js-customer-payment-module/commit/7980f5bb4e66aa2d6ea8d259f8b5cad9aaf15308))
* added missing types ([bf1a3cc](https://github.com/clubpay/js-customer-payment-module/commit/bf1a3cc882c61db0c31c8ebe22fa7f00976fc8ee))
* added needed fields to adyen config ([baa5253](https://github.com/clubpay/js-customer-payment-module/commit/baa5253e9add5544c1f6857810157441d6762d8c))
* added needed type ([4b44e10](https://github.com/clubpay/js-customer-payment-module/commit/4b44e10594e11f908bd70cb4f741537a09bad939))
* added new configuration ([dd9149e](https://github.com/clubpay/js-customer-payment-module/commit/dd9149e6acff833f30d3b9583728b1928abd9d79))
* added new endpoint ([b3c2346](https://github.com/clubpay/js-customer-payment-module/commit/b3c2346c8383c9a3175cf2bca4fdb8cb4726b9d2))
* added new function ([5ae7632](https://github.com/clubpay/js-customer-payment-module/commit/5ae76326806780c0bffe03f21fb5c2b5023e2567))
* added new styles ([0b96a01](https://github.com/clubpay/js-customer-payment-module/commit/0b96a014cd2a8d2c916817852fc620791b5a2d3e))
* added new type ([5bf590a](https://github.com/clubpay/js-customer-payment-module/commit/5bf590af6d1d651492ed3028ec3fd23f13d534c7))
* added onpending ([acfa8db](https://github.com/clubpay/js-customer-payment-module/commit/acfa8dbbf645d348802f22894f4023928259a854))
* added result codes ([7c10f00](https://github.com/clubpay/js-customer-payment-module/commit/7c10f00b49cb50046b151b3fb0fdda1fdbb1cd33))
* added some logs ([4d797da](https://github.com/clubpay/js-customer-payment-module/commit/4d797dad1c4ed4cd05b53ee9d68da2999fcc924f))
* added some logs to see configuration object ([02aa6ec](https://github.com/clubpay/js-customer-payment-module/commit/02aa6ec477bc793ae0c2422308084a7ddd65f5fe))
* added some other log ([7fbb0fa](https://github.com/clubpay/js-customer-payment-module/commit/7fbb0fae67f0f1f21f70629e3e34ce6165f893fe))
* added something to check ([988ae47](https://github.com/clubpay/js-customer-payment-module/commit/988ae47f45f4affc84d827fffa93eb88501bb57d))
* added the paymentmethod statically to test ([ac2b258](https://github.com/clubpay/js-customer-payment-module/commit/ac2b258463eba491eeafe5b64e7c2eba4dbfa73f))
* adyen advanced implementation ([3c939ce](https://github.com/clubpay/js-customer-payment-module/commit/3c939ce385f48cbc3e364d2ad4a0e9d749fdb682))
* applepay added ([274c2ba](https://github.com/clubpay/js-customer-payment-module/commit/274c2ba0b65cb4ce530dca5d862168730997ad9f))
* applepay work ([9e9e196](https://github.com/clubpay/js-customer-payment-module/commit/9e9e1965970e8266017248b3283988b247389c74))
* changed applepay button css ([bf3fd7d](https://github.com/clubpay/js-customer-payment-module/commit/bf3fd7d64b2a453f649eb61f2cc4c96fc015f06e))
* changed dynamic files useeffect ([b270757](https://github.com/clubpay/js-customer-payment-module/commit/b2707574a3d6f90355eddb99688a0e94b4363d10))
* changed flow ([ab52d2e](https://github.com/clubpay/js-customer-payment-module/commit/ab52d2efe5aac1df938add74f5e3854cd44e3cc8))
* changed login check ([7121044](https://github.com/clubpay/js-customer-payment-module/commit/7121044adbb418f131814b1cd1c7648a591e1b02))
* changed payload ([d5e3da7](https://github.com/clubpay/js-customer-payment-module/commit/d5e3da769c6802422f56b78fee3da5060ccd58d0))
* changed style ([1a0a642](https://github.com/clubpay/js-customer-payment-module/commit/1a0a642e605aa08eb95b781f53dd5f50fce73b0c))
* changed the api path ([884c670](https://github.com/clubpay/js-customer-payment-module/commit/884c6702e69a232048a1f54d6ce8b6dc20766dbc))
* changed the flow to advanced ([2325979](https://github.com/clubpay/js-customer-payment-module/commit/2325979746db267cf6c048a14553d4241239f195))
* changed the flow to test ([6e10e57](https://github.com/clubpay/js-customer-payment-module/commit/6e10e57e274a45f225201d36e478376bbfd8f1be))
* changed the logic of adding the style ([92fd277](https://github.com/clubpay/js-customer-payment-module/commit/92fd27775fa0a18e3258fe53db4a4c82c4b8c480))
* changed the logic of checking class name ([6e76a31](https://github.com/clubpay/js-customer-payment-module/commit/6e76a31711d97bcf6cc58a18af723be1c3277ca7))
* changed the method flow ([d305502](https://github.com/clubpay/js-customer-payment-module/commit/d3055026f5a450cffc1e2ecbe7027606d23981c5))
* changed the payload ([c31bd6e](https://github.com/clubpay/js-customer-payment-module/commit/c31bd6ec920eb92688e1d59cd48bd8f074ff07b5))
* changed the query parameter ([6168198](https://github.com/clubpay/js-customer-payment-module/commit/6168198b8ef4f75981137df068dd6fada9e9ea8c))
* changed the succes resultcode ([fb28cf2](https://github.com/clubpay/js-customer-payment-module/commit/fb28cf2e09a9e15b3911a5ec73945a06745fc50d))
* changed the way of getting the methods ([9169a61](https://github.com/clubpay/js-customer-payment-module/commit/9169a618cd95324a4bbee8f231fe4dc3344e83dc))
* changed the way of importing ([877793c](https://github.com/clubpay/js-customer-payment-module/commit/877793ca1bd3c58a05dd56980a2c2ef8d2e38af3))
* changed the way of importing adyen card component ([7f36c25](https://github.com/clubpay/js-customer-payment-module/commit/7f36c25e11f7fd24fa016188e123939d357ea10e))
* changed the way of makind the request ([7cf5aae](https://github.com/clubpay/js-customer-payment-module/commit/7cf5aae58c6fea35d0ad6640d7a86f8950b73d3f))
* changed the way of sending gatewayid ([64163a1](https://github.com/clubpay/js-customer-payment-module/commit/64163a127f45a6c4b2db172957e0daaabb32eadc))
* changed thw way of adding methods ([f769e1c](https://github.com/clubpay/js-customer-payment-module/commit/f769e1c5b070661604749093626743a928b742b0))
* check the applepay session ([ca6f92a](https://github.com/clubpay/js-customer-payment-module/commit/ca6f92affb6b73bf6e55170519a9354b882eb1a4))
* corrected payment method response ([0c87a2f](https://github.com/clubpay/js-customer-payment-module/commit/0c87a2f0c7cf2256aa579160110f609e1161ccfc))
* debugged ([9ff7ea2](https://github.com/clubpay/js-customer-payment-module/commit/9ff7ea2e49fab2507cf5a13d29691f767e54009a))
* debugging ([1681672](https://github.com/clubpay/js-customer-payment-module/commit/16816728955edc7815d5db65d97de8859257453f))
* find the reason of the endless loop ([046e5c1](https://github.com/clubpay/js-customer-payment-module/commit/046e5c17325f2c6b8cb821b492eedae75e21e46c))
* fix ([26a89a8](https://github.com/clubpay/js-customer-payment-module/commit/26a89a896e5de927b86eb3866f4fa17bfe85f357))
* fix the button freeze bug ([dd55a15](https://github.com/clubpay/js-customer-payment-module/commit/dd55a15d85341656fd3efe5273aea3f1b41dfbf2))
* fix the style ([34cdeec](https://github.com/clubpay/js-customer-payment-module/commit/34cdeec55feccd76c754757730e0afd74afb3f50))
* fixed customer web app build type errros ([e74ab4e](https://github.com/clubpay/js-customer-payment-module/commit/e74ab4e9b7502488660a5536968e6a8f7a06d4c6))
* fixed customer web app compile errors ([e2d0e6b](https://github.com/clubpay/js-customer-payment-module/commit/e2d0e6b5b5d2928f7ad5e82289765e6381751ead))
* fixed deployment error on the customer web app ([1f29233](https://github.com/clubpay/js-customer-payment-module/commit/1f292334e0210a59e76f22b9f2c39118950c3a22))
* fixed payment method list ([33ccfbb](https://github.com/clubpay/js-customer-payment-module/commit/33ccfbb71d7ac9a06ed3508bf652629684bb1d91))
* fixed redirection ([ee51e15](https://github.com/clubpay/js-customer-payment-module/commit/ee51e154b4854510c51ef524bfdaa4fb1c847c5b))
* fixed request error ([c42f1a2](https://github.com/clubpay/js-customer-payment-module/commit/c42f1a2b64485a3bf4c2f274422795f33655c588))
* fixed type error ([388fdce](https://github.com/clubpay/js-customer-payment-module/commit/388fdced5f6b0caf2af0ab43a3860eb823083678))
* going on ([e6e74de](https://github.com/clubpay/js-customer-payment-module/commit/e6e74ded079ecbf39173e2bc1541ac73262fde9a))
* googlepay ([3ae5cc1](https://github.com/clubpay/js-customer-payment-module/commit/3ae5cc15d9790090df62b430c077ae4323552ccb))
* got available methods ([e4e6b1a](https://github.com/clubpay/js-customer-payment-module/commit/e4e6b1a78a5a9f769d4a360d92387afd8fda14dd))
* implemented advenced card payment endpoint ([4e6b535](https://github.com/clubpay/js-customer-payment-module/commit/4e6b5351f85257452ac60e11854216dd323766d1))
* imported react into card file to pass the cwa error ([e65369b](https://github.com/clubpay/js-customer-payment-module/commit/e65369bdad605b4ad54a0ecd276c1ae1d13e953d))
* log some tests ([2a97278](https://github.com/clubpay/js-customer-payment-module/commit/2a972786ff9f1dc428bc3d804a8a112855046944))
* logged the config ([b186327](https://github.com/clubpay/js-customer-payment-module/commit/b186327805c36753d20dcb27c259706f3806d546))
* logged the state data to observe it ([cb27bf7](https://github.com/clubpay/js-customer-payment-module/commit/cb27bf741eb47a3be66146f115a1850a14cebec1))
* manipulated the id to test ([9bd97bb](https://github.com/clubpay/js-customer-payment-module/commit/9bd97bb6f684801a210cec1f887d020250795a22))
* merge applepay code inrto advanced card payment ([e78c000](https://github.com/clubpay/js-customer-payment-module/commit/e78c000c009536d60e3d479b015e37f289c69eed))
* merged applepay and advanced ([5b21088](https://github.com/clubpay/js-customer-payment-module/commit/5b2108829167dd9a32811c660d895d422acf7ad2))
* merged applepay into advanced card payment ([afaae72](https://github.com/clubpay/js-customer-payment-module/commit/afaae72cdad415d5f3a9ebc55b4d365fb7758e84))
* new module ([be79bbe](https://github.com/clubpay/js-customer-payment-module/commit/be79bbe44c526a326aed9cc92825926326eef38b))
* new styles ([9344e56](https://github.com/clubpay/js-customer-payment-module/commit/9344e56bff03f0bc52f23bedfae814c502f8c77f))
* observe the state ([9c17bcf](https://github.com/clubpay/js-customer-payment-module/commit/9c17bcfd761f30aba76efe4229c0c34f2b154537))
* put get method list to work ([4a1a1af](https://github.com/clubpay/js-customer-payment-module/commit/4a1a1af5aecddc8fd57900b1f50f2aeccbdeaf2e))
* put some logs ([33dd5dd](https://github.com/clubpay/js-customer-payment-module/commit/33dd5dd18bd0a836560cfee74850670c684a8690))
* refactored ([5fd7d8b](https://github.com/clubpay/js-customer-payment-module/commit/5fd7d8be902088ce32a7cecb80543d36836a2ac7))
* refactored get payment method list ([e38c91c](https://github.com/clubpay/js-customer-payment-module/commit/e38c91c46df3daac260306b4ae8fd334ab7fe848))
* refactored handle pay function ([8119e75](https://github.com/clubpay/js-customer-payment-module/commit/8119e7592fd7fc192f8df7a97d47e19d7ebb8949))
* remove old implementation ([7851eab](https://github.com/clubpay/js-customer-payment-module/commit/7851eab185983c16326a93b79d2ba92ca41aebbb))
* removed billing namew ([e715f1f](https://github.com/clubpay/js-customer-payment-module/commit/e715f1f91b9ede021d11cc6ea142c579c4508ab1))
* removed unnecessary log and tried to see the payment method ([c927e3d](https://github.com/clubpay/js-customer-payment-module/commit/c927e3d1c39043b1e8a88d3f80c8ac89d65decde))
* revderted back ([ede2679](https://github.com/clubpay/js-customer-payment-module/commit/ede26799b23e94e2012c4fc460b523947fd37841))
* reverted the experiment ([9fcd2e1](https://github.com/clubpay/js-customer-payment-module/commit/9fcd2e110c3803b52c14303b5c28e3020cc3a4da))
* reverted the test ([75e6cbc](https://github.com/clubpay/js-customer-payment-module/commit/75e6cbc24004676fc4b7cc5caffc40a432131239))
* style issue is fixed ([8d27805](https://github.com/clubpay/js-customer-payment-module/commit/8d2780593132f1d2df1109fc286bdc1a2ffbdec7))
* test ([6369e0a](https://github.com/clubpay/js-customer-payment-module/commit/6369e0a76071891b441e12e939849b444fe91096))
* to see some logs ([806a62d](https://github.com/clubpay/js-customer-payment-module/commit/806a62dc6499f48578f934a57adbd6c3d62bbab6))
* tried a new approach ([ee6f22b](https://github.com/clubpay/js-customer-payment-module/commit/ee6f22b797557bc0647be25fe653ee022402c4ee))
* tried some fixes ([c0875e7](https://github.com/clubpay/js-customer-payment-module/commit/c0875e7e1f9c1c2fd05a4075352095f7771675ac))
* tried style the applepay button ([35632e1](https://github.com/clubpay/js-customer-payment-module/commit/35632e11f867c791d4b2da798b1f59ca2c5d3f4d))
* tried to add style to applepay button ([c7e9f7c](https://github.com/clubpay/js-customer-payment-module/commit/c7e9f7ca392fb911f95687fd6cb41300764923c4))
* tried to fix style issue ([eb4299f](https://github.com/clubpay/js-customer-payment-module/commit/eb4299f06dd81f26d3ca033f9b32e302af74e488))
* tried to fix the applepay ([b1812b5](https://github.com/clubpay/js-customer-payment-module/commit/b1812b56178d63874e661d5fc8948784a9e9c520))
* tried to pass the infinite loop ([0762f8c](https://github.com/clubpay/js-customer-payment-module/commit/0762f8ca60ec4b9127f3389ab730fa7b37475540))
* tried to use dummy paymentethod data ([ebb15fc](https://github.com/clubpay/js-customer-payment-module/commit/ebb15fc401dbd438df548bf6bcf78394aa62eca9))
* try to check the final result ([d852dba](https://github.com/clubpay/js-customer-payment-module/commit/d852dbadb077967886a6100e22aad4c7f8af78f6))
* trying to debug the error ([b29f884](https://github.com/clubpay/js-customer-payment-module/commit/b29f8849494cdb9e0ac77c5fe3f6dfcc92e6c230))
* trying to get correct payload for methods ([3f07231](https://github.com/clubpay/js-customer-payment-module/commit/3f07231e567e5bda7416737cd6d8a3036165cba3))
* trying to get the state of the method ([c015e18](https://github.com/clubpay/js-customer-payment-module/commit/c015e184b31dd5e7bb60d1451be3eb236247478d))
* trying to see the log ([8bd7a9e](https://github.com/clubpay/js-customer-payment-module/commit/8bd7a9e92114e605762cc06ad0afa0af78e87c6e))
* uncommented card element to test ([e5d849d](https://github.com/clubpay/js-customer-payment-module/commit/e5d849d4e371866f3f9877161bca2024bed8a021))
* updated the switch case ([aeabf66](https://github.com/clubpay/js-customer-payment-module/commit/aeabf66526296fe8fdb444b7c5d1084167dadcdf))
* uppercased currency added new logs ([e1fe431](https://github.com/clubpay/js-customer-payment-module/commit/e1fe43148c8d4e15b47f484c744364d1878cc658))

# [1.6.0-alpha.142](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.141...v1.6.0-alpha.142) (2024-02-14)


### Bug Fixes

* changed switch case aproach ([41b26d6](https://github.com/clubpay/js-customer-payment-module/commit/41b26d606925ebd42e7e8b00ff3184f1ea668f97))

# [1.6.0-alpha.141](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.140...v1.6.0-alpha.141) (2024-02-13)


### Bug Fixes

* tried to stabilize refid ([0b1e47d](https://github.com/clubpay/js-customer-payment-module/commit/0b1e47d9a067835c4c4d219ce36e83e586376026))

# [1.6.0-alpha.140](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.139...v1.6.0-alpha.140) (2024-02-13)


### Bug Fixes

* multi pg issue index.tsx ([4e1b3bc](https://github.com/clubpay/js-customer-payment-module/commit/4e1b3bccb6b4f32055799d0b99e3096233a3f3a8))

# [1.6.0-alpha.139](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.138...v1.6.0-alpha.139) (2024-02-07)


### Features

* applepay work ([9e9e196](https://github.com/clubpay/js-customer-payment-module/commit/9e9e1965970e8266017248b3283988b247389c74))

# [1.6.0-alpha.138](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.137...v1.6.0-alpha.138) (2024-02-06)


### Features

* fix the button freeze bug ([dd55a15](https://github.com/clubpay/js-customer-payment-module/commit/dd55a15d85341656fd3efe5273aea3f1b41dfbf2))

# [1.6.0-alpha.137](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.136...v1.6.0-alpha.137) (2024-02-01)


### Bug Fixes

* added new logs ([6355543](https://github.com/clubpay/js-customer-payment-module/commit/635554306818fe6ba74d78971d85cb3eac54be17))

# [1.6.0-alpha.136](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.135...v1.6.0-alpha.136) (2024-02-01)


### Features

* added some logs ([4d797da](https://github.com/clubpay/js-customer-payment-module/commit/4d797dad1c4ed4cd05b53ee9d68da2999fcc924f))

# [1.6.0-alpha.135](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.134...v1.6.0-alpha.135) (2024-02-01)


### Bug Fixes

* logged card button freeze reasons ([fc084e4](https://github.com/clubpay/js-customer-payment-module/commit/fc084e4d98cc12a21ef3d3d6116a7f44e67a8ec0))

# [1.6.0-alpha.134](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.133...v1.6.0-alpha.134) (2024-01-31)


### Features

* style issue is fixed ([8d27805](https://github.com/clubpay/js-customer-payment-module/commit/8d2780593132f1d2df1109fc286bdc1a2ffbdec7))

# [1.6.0-alpha.133](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.132...v1.6.0-alpha.133) (2024-01-31)


### Bug Fixes

* new approach on style ([ef9d3d7](https://github.com/clubpay/js-customer-payment-module/commit/ef9d3d785227070bab6eb01def061ebcca5d5d43))

# [1.6.0-alpha.132](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.131...v1.6.0-alpha.132) (2024-01-31)


### Bug Fixes

* style ([3b0389b](https://github.com/clubpay/js-customer-payment-module/commit/3b0389b1c79264c755466aaafba96c1c66eb3590))

# [1.6.0-alpha.131](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.130...v1.6.0-alpha.131) (2024-01-31)


### Bug Fixes

* fixed the typo on the class name ([28758e8](https://github.com/clubpay/js-customer-payment-module/commit/28758e8e5aa45984095b5eb47f9421e840144629))

# [1.6.0-alpha.130](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.129...v1.6.0-alpha.130) (2024-01-31)


### Features

* changed the logic of adding the style ([92fd277](https://github.com/clubpay/js-customer-payment-module/commit/92fd27775fa0a18e3258fe53db4a4c82c4b8c480))

# [1.6.0-alpha.129](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.128...v1.6.0-alpha.129) (2024-01-31)


### Features

* tried to fix style issue ([eb4299f](https://github.com/clubpay/js-customer-payment-module/commit/eb4299f06dd81f26d3ca033f9b32e302af74e488))

# [1.6.0-alpha.128](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.127...v1.6.0-alpha.128) (2024-01-30)


### Bug Fixes

* fixed the typo ([905ba2a](https://github.com/clubpay/js-customer-payment-module/commit/905ba2ac831a7ff2088852d19f5612325b8e7606))

# [1.6.0-alpha.127](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.126...v1.6.0-alpha.127) (2024-01-30)


### Features

* added new function ([5ae7632](https://github.com/clubpay/js-customer-payment-module/commit/5ae76326806780c0bffe03f21fb5c2b5023e2567))
* added onpending ([acfa8db](https://github.com/clubpay/js-customer-payment-module/commit/acfa8dbbf645d348802f22894f4023928259a854))
* changed the logic of checking class name ([6e76a31](https://github.com/clubpay/js-customer-payment-module/commit/6e76a31711d97bcf6cc58a18af723be1c3277ca7))

# [1.6.0-alpha.126](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.125...v1.6.0-alpha.126) (2024-01-30)


### Features

* new styles ([9344e56](https://github.com/clubpay/js-customer-payment-module/commit/9344e56bff03f0bc52f23bedfae814c502f8c77f))

# [1.6.0-alpha.125](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.124...v1.6.0-alpha.125) (2024-01-30)


### Bug Fixes

* fixed styles ([c1fca09](https://github.com/clubpay/js-customer-payment-module/commit/c1fca09e6afbbc3cd45f70b42abdfc3c2fd2a265))

# [1.6.0-alpha.124](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.123...v1.6.0-alpha.124) (2024-01-30)


### Features

* fix ([26a89a8](https://github.com/clubpay/js-customer-payment-module/commit/26a89a896e5de927b86eb3866f4fa17bfe85f357))

# [1.6.0-alpha.123](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.122...v1.6.0-alpha.123) (2024-01-29)


### Bug Fixes

* style fix ([e7f02c2](https://github.com/clubpay/js-customer-payment-module/commit/e7f02c2e9f4242531abfe1328cfaa3979416ee65))

# [1.6.0-alpha.122](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.121...v1.6.0-alpha.122) (2024-01-26)


### Features

* test ([6369e0a](https://github.com/clubpay/js-customer-payment-module/commit/6369e0a76071891b441e12e939849b444fe91096))

# [1.6.0-alpha.121](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.120...v1.6.0-alpha.121) (2024-01-26)


### Bug Fixes

* reverted unnecessary code ([44244fc](https://github.com/clubpay/js-customer-payment-module/commit/44244fc4a2acc4b57e0d64217ca6159edae93f05))


### Features

* tried to add style to applepay button ([c7e9f7c](https://github.com/clubpay/js-customer-payment-module/commit/c7e9f7ca392fb911f95687fd6cb41300764923c4))

# [1.6.0-alpha.120](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.119...v1.6.0-alpha.120) (2024-01-25)


### Bug Fixes

* fix status check ([ecffad5](https://github.com/clubpay/js-customer-payment-module/commit/ecffad52f1e5c7a0710d4767802d7bd5b9be29e5))


### Features

* added maximum char limit to ref str ([4316811](https://github.com/clubpay/js-customer-payment-module/commit/4316811ab0d331f3c91221b154cffed944333eb0))

# [1.6.0-alpha.119](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.118...v1.6.0-alpha.119) (2024-01-17)


### Features

* logged the config ([b186327](https://github.com/clubpay/js-customer-payment-module/commit/b186327805c36753d20dcb27c259706f3806d546))

# [1.6.0-alpha.118](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.117...v1.6.0-alpha.118) (2024-01-17)


### Bug Fixes

* **c:** applepay button fix ([3629008](https://github.com/clubpay/js-customer-payment-module/commit/36290087211086389d04d5bcfe61d19d26611cad))

# [1.6.0-alpha.117](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.116...v1.6.0-alpha.117) (2024-01-17)


### Features

* removed billing namew ([e715f1f](https://github.com/clubpay/js-customer-payment-module/commit/e715f1f91b9ede021d11cc6ea142c579c4508ab1))

# [1.6.0-alpha.116](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.115...v1.6.0-alpha.116) (2024-01-16)


### Features

* added config ([c0680ae](https://github.com/clubpay/js-customer-payment-module/commit/c0680ae827695f87ba289676f3ce9bc144c1bbdc))

# [1.6.0-alpha.115](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.114...v1.6.0-alpha.115) (2024-01-16)


### Features

* added new configuration ([dd9149e](https://github.com/clubpay/js-customer-payment-module/commit/dd9149e6acff833f30d3b9583728b1928abd9d79))
* added new type ([5bf590a](https://github.com/clubpay/js-customer-payment-module/commit/5bf590af6d1d651492ed3028ec3fd23f13d534c7))

# [1.6.0-alpha.114](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.113...v1.6.0-alpha.114) (2024-01-16)


### Features

* new module ([be79bbe](https://github.com/clubpay/js-customer-payment-module/commit/be79bbe44c526a326aed9cc92825926326eef38b))

# [1.6.0-alpha.113](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.112...v1.6.0-alpha.113) (2024-01-16)


### Features

* tried a new approach ([ee6f22b](https://github.com/clubpay/js-customer-payment-module/commit/ee6f22b797557bc0647be25fe653ee022402c4ee))

# [1.6.0-alpha.112](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.111...v1.6.0-alpha.112) (2024-01-16)


### Features

* added new styles ([0b96a01](https://github.com/clubpay/js-customer-payment-module/commit/0b96a014cd2a8d2c916817852fc620791b5a2d3e))

# [1.6.0-alpha.111](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.110...v1.6.0-alpha.111) (2024-01-16)


### Features

* tried style the applepay button ([35632e1](https://github.com/clubpay/js-customer-payment-module/commit/35632e11f867c791d4b2da798b1f59ca2c5d3f4d))

# [1.6.0-alpha.110](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.109...v1.6.0-alpha.110) (2024-01-16)


### Features

* changed style ([1a0a642](https://github.com/clubpay/js-customer-payment-module/commit/1a0a642e605aa08eb95b781f53dd5f50fce73b0c))

# [1.6.0-alpha.109](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.108...v1.6.0-alpha.109) (2024-01-16)


### Features

* fix the style ([34cdeec](https://github.com/clubpay/js-customer-payment-module/commit/34cdeec55feccd76c754757730e0afd74afb3f50))

# [1.6.0-alpha.108](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.107...v1.6.0-alpha.108) (2024-01-15)


### Features

* changed applepay button css ([bf3fd7d](https://github.com/clubpay/js-customer-payment-module/commit/bf3fd7d64b2a453f649eb61f2cc4c96fc015f06e))

# [1.6.0-alpha.107](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.106...v1.6.0-alpha.107) (2024-01-15)


### Bug Fixes

* fixed applepay button style ([88a87da](https://github.com/clubpay/js-customer-payment-module/commit/88a87daf04f37e82643e2ef52a849f439e249ec3))

# [1.6.0-alpha.106](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.105...v1.6.0-alpha.106) (2024-01-15)


### Features

* added applepay ([8cda284](https://github.com/clubpay/js-customer-payment-module/commit/8cda284f7f216b44093621601154ce3b8a89ec5c))
* merge applepay code inrto advanced card payment ([e78c000](https://github.com/clubpay/js-customer-payment-module/commit/e78c000c009536d60e3d479b015e37f289c69eed))
* merged applepay and advanced ([5b21088](https://github.com/clubpay/js-customer-payment-module/commit/5b2108829167dd9a32811c660d895d422acf7ad2))
* merged applepay into advanced card payment ([afaae72](https://github.com/clubpay/js-customer-payment-module/commit/afaae72cdad415d5f3a9ebc55b4d365fb7758e84))

# [1.6.0-alpha.105](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.104...v1.6.0-alpha.105) (2024-01-12)


### Features

* updated the switch case ([aeabf66](https://github.com/clubpay/js-customer-payment-module/commit/aeabf66526296fe8fdb444b7c5d1084167dadcdf))

# [1.6.0-alpha.104](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.103...v1.6.0-alpha.104) (2024-01-11)


### Features

* added result codes ([7c10f00](https://github.com/clubpay/js-customer-payment-module/commit/7c10f00b49cb50046b151b3fb0fdda1fdbb1cd33))

# [1.6.0-alpha.103](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.102...v1.6.0-alpha.103) (2024-01-09)


### Bug Fixes

* change the iterator variable ([982bd6b](https://github.com/clubpay/js-customer-payment-module/commit/982bd6bb650741db025625e414d677aa3ceb0913))

# [1.6.0-alpha.102](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.101...v1.6.0-alpha.102) (2024-01-09)


### Features

* changed the succes resultcode ([fb28cf2](https://github.com/clubpay/js-customer-payment-module/commit/fb28cf2e09a9e15b3911a5ec73945a06745fc50d))

# [1.6.0-alpha.101](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.100...v1.6.0-alpha.101) (2024-01-09)


### Features

* added default case for redirecting ([73af8fa](https://github.com/clubpay/js-customer-payment-module/commit/73af8faaeb1a9c3a412ac7282164b706ac401c80))

# [1.6.0-alpha.100](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.99...v1.6.0-alpha.100) (2024-01-08)


### Bug Fixes

* changed the redirect ([a7e9d9f](https://github.com/clubpay/js-customer-payment-module/commit/a7e9d9f20907f2eec6b8549d11f91a6d4c480345))

# [1.6.0-alpha.99](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.98...v1.6.0-alpha.99) (2024-01-08)


### Bug Fixes

* refactored the result code handling based on be changes ([790fb82](https://github.com/clubpay/js-customer-payment-module/commit/790fb82bb176649303171d58b5688d750e63830e))

# [1.6.0-alpha.98](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.97...v1.6.0-alpha.98) (2024-01-05)


### Features

* try to check the final result ([d852dba](https://github.com/clubpay/js-customer-payment-module/commit/d852dbadb077967886a6100e22aad4c7f8af78f6))

# [1.6.0-alpha.97](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.96...v1.6.0-alpha.97) (2024-01-03)


### Bug Fixes

* reverted the test ([d60ce7e](https://github.com/clubpay/js-customer-payment-module/commit/d60ce7ec511c25838e49b885fcb4129a693063ed))

# [1.6.0-alpha.96](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.95...v1.6.0-alpha.96) (2024-01-03)


### Features

* added the paymentmethod statically to test ([ac2b258](https://github.com/clubpay/js-customer-payment-module/commit/ac2b258463eba491eeafe5b64e7c2eba4dbfa73f))

# [1.6.0-alpha.95](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.94...v1.6.0-alpha.95) (2024-01-03)


### Features

* reverted the experiment ([9fcd2e1](https://github.com/clubpay/js-customer-payment-module/commit/9fcd2e110c3803b52c14303b5c28e3020cc3a4da))

# [1.6.0-alpha.94](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.93...v1.6.0-alpha.94) (2024-01-03)


### Features

* tried to use dummy paymentethod data ([ebb15fc](https://github.com/clubpay/js-customer-payment-module/commit/ebb15fc401dbd438df548bf6bcf78394aa62eca9))

# [1.6.0-alpha.93](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.92...v1.6.0-alpha.93) (2023-12-27)


### Features

* added some logs to see configuration object ([02aa6ec](https://github.com/clubpay/js-customer-payment-module/commit/02aa6ec477bc793ae0c2422308084a7ddd65f5fe))

# [1.6.0-alpha.92](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.91...v1.6.0-alpha.92) (2023-12-27)


### Bug Fixes

* fix path ([b35c794](https://github.com/clubpay/js-customer-payment-module/commit/b35c7947986dec40581e5c9168b31a0a7417a2b0))
* update name ([730817a](https://github.com/clubpay/js-customer-payment-module/commit/730817a59079f9d168a421bb92ef30ae65eab91b))


### Features

* refactored handle pay function ([8119e75](https://github.com/clubpay/js-customer-payment-module/commit/8119e7592fd7fc192f8df7a97d47e19d7ebb8949))

# [1.6.0-alpha.91](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.90...v1.6.0-alpha.91) (2023-12-26)


### Features

* changed the way of importing adyen card component ([7f36c25](https://github.com/clubpay/js-customer-payment-module/commit/7f36c25e11f7fd24fa016188e123939d357ea10e))

# [1.6.0-alpha.90](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.89...v1.6.0-alpha.90) (2023-12-26)


### Features

* imported react into card file to pass the cwa error ([e65369b](https://github.com/clubpay/js-customer-payment-module/commit/e65369bdad605b4ad54a0ecd276c1ae1d13e953d))

# [1.6.0-alpha.89](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.88...v1.6.0-alpha.89) (2023-12-26)


### Bug Fixes

* trying to step over from the customer app error ([269bd78](https://github.com/clubpay/js-customer-payment-module/commit/269bd78db14d6028f9b7bddd439f0e62d7f2aa95))

# [1.6.0-alpha.88](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.87...v1.6.0-alpha.88) (2023-12-26)


### Features

* changed the way of importing ([877793c](https://github.com/clubpay/js-customer-payment-module/commit/877793ca1bd3c58a05dd56980a2c2ef8d2e38af3))

# [1.6.0-alpha.87](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.86...v1.6.0-alpha.87) (2023-12-26)


### Bug Fixes

* changed component name ([1688e90](https://github.com/clubpay/js-customer-payment-module/commit/1688e90ec52abd533d34da2a7d8ff0f2efdfea6d))

# [1.6.0-alpha.86](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.85...v1.6.0-alpha.86) (2023-12-26)


### Bug Fixes

* fixed import way compatible with customer app ([3c12b2e](https://github.com/clubpay/js-customer-payment-module/commit/3c12b2ed062402e4dd853da87c440d4dd4accdd2))

# [1.6.0-alpha.85](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.84...v1.6.0-alpha.85) (2023-12-26)


### Features

* refactored get payment method list ([e38c91c](https://github.com/clubpay/js-customer-payment-module/commit/e38c91c46df3daac260306b4ae8fd334ab7fe848))

# [1.6.0-alpha.84](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.83...v1.6.0-alpha.84) (2023-12-26)


### Features

* fixed deployment error on the customer web app ([1f29233](https://github.com/clubpay/js-customer-payment-module/commit/1f292334e0210a59e76f22b9f2c39118950c3a22))

# [1.6.0-alpha.83](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.82...v1.6.0-alpha.83) (2023-12-26)


### Features

* fixed type error ([388fdce](https://github.com/clubpay/js-customer-payment-module/commit/388fdced5f6b0caf2af0ab43a3860eb823083678))

# [1.6.0-alpha.82](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.81...v1.6.0-alpha.82) (2023-12-26)


### Features

* fixed customer web app build type errros ([e74ab4e](https://github.com/clubpay/js-customer-payment-module/commit/e74ab4e9b7502488660a5536968e6a8f7a06d4c6))

# [1.6.0-alpha.81](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.80...v1.6.0-alpha.81) (2023-12-26)


### Features

* fixed customer web app compile errors ([e2d0e6b](https://github.com/clubpay/js-customer-payment-module/commit/e2d0e6b5b5d2928f7ad5e82289765e6381751ead))

# [1.6.0-alpha.80](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.79...v1.6.0-alpha.80) (2023-12-25)


### Bug Fixes

* added fail error log ([6f011e7](https://github.com/clubpay/js-customer-payment-module/commit/6f011e71c4a013c2d93a514546abc4399b188661))

# [1.6.0-alpha.79](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.78...v1.6.0-alpha.79) (2023-12-25)


### Features

* fixed redirection ([ee51e15](https://github.com/clubpay/js-customer-payment-module/commit/ee51e154b4854510c51ef524bfdaa4fb1c847c5b))

# [1.6.0-alpha.78](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.77...v1.6.0-alpha.78) (2023-12-25)


### Features

* removed unnecessary log and tried to see the payment method ([c927e3d](https://github.com/clubpay/js-customer-payment-module/commit/c927e3d1c39043b1e8a88d3f80c8ac89d65decde))

# [1.6.0-alpha.77](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.76...v1.6.0-alpha.77) (2023-12-25)


### Features

* trying to see the log ([8bd7a9e](https://github.com/clubpay/js-customer-payment-module/commit/8bd7a9e92114e605762cc06ad0afa0af78e87c6e))

# [1.6.0-alpha.76](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.75...v1.6.0-alpha.76) (2023-12-25)


### Features

* trying to get the state of the method ([c015e18](https://github.com/clubpay/js-customer-payment-module/commit/c015e184b31dd5e7bb60d1451be3eb236247478d))

# [1.6.0-alpha.75](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.74...v1.6.0-alpha.75) (2023-12-25)


### Features

* debugged ([9ff7ea2](https://github.com/clubpay/js-customer-payment-module/commit/9ff7ea2e49fab2507cf5a13d29691f767e54009a))
* logged the state data to observe it ([cb27bf7](https://github.com/clubpay/js-customer-payment-module/commit/cb27bf741eb47a3be66146f115a1850a14cebec1))

# [1.6.0-alpha.74](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.73...v1.6.0-alpha.74) (2023-12-22)


### Features

* changed dynamic files useeffect ([b270757](https://github.com/clubpay/js-customer-payment-module/commit/b2707574a3d6f90355eddb99688a0e94b4363d10))

# [1.6.0-alpha.73](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.72...v1.6.0-alpha.73) (2023-12-22)


### Features

* trying to debug the error ([b29f884](https://github.com/clubpay/js-customer-payment-module/commit/b29f8849494cdb9e0ac77c5fe3f6dfcc92e6c230))

# [1.6.0-alpha.72](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.71...v1.6.0-alpha.72) (2023-12-22)


### Features

* added some other log ([7fbb0fa](https://github.com/clubpay/js-customer-payment-module/commit/7fbb0fae67f0f1f21f70629e3e34ce6165f893fe))
* changed the way of makind the request ([7cf5aae](https://github.com/clubpay/js-customer-payment-module/commit/7cf5aae58c6fea35d0ad6640d7a86f8950b73d3f))
* put some logs ([33dd5dd](https://github.com/clubpay/js-customer-payment-module/commit/33dd5dd18bd0a836560cfee74850670c684a8690))

# [1.6.0-alpha.71](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.70...v1.6.0-alpha.71) (2023-12-22)


### Features

* revderted back ([ede2679](https://github.com/clubpay/js-customer-payment-module/commit/ede26799b23e94e2012c4fc460b523947fd37841))

# [1.6.0-alpha.70](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.69...v1.6.0-alpha.70) (2023-12-22)


### Bug Fixes

* changed the flow ([937d9c3](https://github.com/clubpay/js-customer-payment-module/commit/937d9c3eabfe7ae512a8c1bb46269c445c038376))

# [1.6.0-alpha.69](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.68...v1.6.0-alpha.69) (2023-12-22)


### Bug Fixes

* changed logic ([e28e855](https://github.com/clubpay/js-customer-payment-module/commit/e28e8553d635eaad76cbee97982be5de50eb327e))

# [1.6.0-alpha.68](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.67...v1.6.0-alpha.68) (2023-12-22)


### Bug Fixes

* changed the way to get payment method response ([7a9da37](https://github.com/clubpay/js-customer-payment-module/commit/7a9da37578087c2d6ba14d4e1e3d4e6f1458265a))

# [1.6.0-alpha.67](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.66...v1.6.0-alpha.67) (2023-12-21)


### Features

* changed the method flow ([d305502](https://github.com/clubpay/js-customer-payment-module/commit/d3055026f5a450cffc1e2ecbe7027606d23981c5))

# [1.6.0-alpha.66](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.65...v1.6.0-alpha.66) (2023-12-21)


### Features

* changed thw way of adding methods ([f769e1c](https://github.com/clubpay/js-customer-payment-module/commit/f769e1c5b070661604749093626743a928b742b0))

# [1.6.0-alpha.65](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.64...v1.6.0-alpha.65) (2023-12-21)


### Features

* changed the way of getting the methods ([9169a61](https://github.com/clubpay/js-customer-payment-module/commit/9169a618cd95324a4bbee8f231fe4dc3344e83dc))

# [1.6.0-alpha.64](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.63...v1.6.0-alpha.64) (2023-12-21)


### Features

* uncommented card element to test ([e5d849d](https://github.com/clubpay/js-customer-payment-module/commit/e5d849d4e371866f3f9877161bca2024bed8a021))

# [1.6.0-alpha.62](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.61...v1.6.0-alpha.62) (2023-12-21)


### Features

* added missing advanced payments service ([9822df3](https://github.com/clubpay/js-customer-payment-module/commit/9822df3985603782efe00a60ce489769401121f0))
* added missing endpoint ([e351cbf](https://github.com/clubpay/js-customer-payment-module/commit/e351cbff504bbca32e50c2d85ec83e74e80b8d0f))
* added missing types ([bf1a3cc](https://github.com/clubpay/js-customer-payment-module/commit/bf1a3cc882c61db0c31c8ebe22fa7f00976fc8ee))
* implemented advenced card payment endpoint ([4e6b535](https://github.com/clubpay/js-customer-payment-module/commit/4e6b5351f85257452ac60e11854216dd323766d1))

# [1.6.0-alpha.61](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.60...v1.6.0-alpha.61) (2023-12-21)


### Bug Fixes

* applepay component ref nullcheck ([bc067a5](https://github.com/clubpay/js-customer-payment-module/commit/bc067a5f7c669e57eeb23dd16ffb3e10b29f4a18))

# [1.6.0-alpha.60](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.59...v1.6.0-alpha.60) (2023-12-20)


### Features

* added flow changes ([9e18bfc](https://github.com/clubpay/js-customer-payment-module/commit/9e18bfc1458c487bfe1d389fe4680365d0c75c11))

# [1.6.0-alpha.59](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.58...v1.6.0-alpha.59) (2023-12-15)


### Features

* uppercased currency added new logs ([e1fe431](https://github.com/clubpay/js-customer-payment-module/commit/e1fe43148c8d4e15b47f484c744364d1878cc658))

# [1.6.0-alpha.58](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.57...v1.6.0-alpha.58) (2023-12-15)


### Features

* fixed payment method list ([33ccfbb](https://github.com/clubpay/js-customer-payment-module/commit/33ccfbb71d7ac9a06ed3508bf652629684bb1d91))

# [1.6.0-alpha.57](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.56...v1.6.0-alpha.57) (2023-12-15)


### Features

* find the reason of the endless loop ([046e5c1](https://github.com/clubpay/js-customer-payment-module/commit/046e5c17325f2c6b8cb821b492eedae75e21e46c))

# [1.6.0-alpha.56](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.55...v1.6.0-alpha.56) (2023-12-15)


### Features

* changed login check ([7121044](https://github.com/clubpay/js-customer-payment-module/commit/7121044adbb418f131814b1cd1c7648a591e1b02))

# [1.6.0-alpha.55](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.54...v1.6.0-alpha.55) (2023-12-14)


### Features

* tried to pass the infinite loop ([0762f8c](https://github.com/clubpay/js-customer-payment-module/commit/0762f8ca60ec4b9127f3389ab730fa7b37475540))

# [1.6.0-alpha.54](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.53...v1.6.0-alpha.54) (2023-12-14)


### Features

* corrected payment method response ([0c87a2f](https://github.com/clubpay/js-customer-payment-module/commit/0c87a2f0c7cf2256aa579160110f609e1161ccfc))

# [1.6.0-alpha.53](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.52...v1.6.0-alpha.53) (2023-12-14)


### Bug Fixes

* tried to pass no node error ([ecb7416](https://github.com/clubpay/js-customer-payment-module/commit/ecb74160a66e339162341786b50e068cb2be5464))

# [1.6.0-alpha.52](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.51...v1.6.0-alpha.52) (2023-12-14)


### Bug Fixes

* changed payment method response type ([ee145a7](https://github.com/clubpay/js-customer-payment-module/commit/ee145a7d299226e7a25cad26c688ffa58416d1b8))

# [1.6.0-alpha.51](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.50...v1.6.0-alpha.51) (2023-12-14)


### Features

* added fix ([a2c6a94](https://github.com/clubpay/js-customer-payment-module/commit/a2c6a94e1a24d516af8bb044066fa185dd028b6f))
* added needed type ([4b44e10](https://github.com/clubpay/js-customer-payment-module/commit/4b44e10594e11f908bd70cb4f741537a09bad939))

# [1.6.0-alpha.50](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.49...v1.6.0-alpha.50) (2023-12-14)


### Bug Fixes

* specify type ([62d63ce](https://github.com/clubpay/js-customer-payment-module/commit/62d63ce86e9324dc27a72330b865442bac2029bf))

# [1.6.0-alpha.49](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.48...v1.6.0-alpha.49) (2023-12-14)


### Bug Fixes

* null check ([95fbbeb](https://github.com/clubpay/js-customer-payment-module/commit/95fbbebc9da368e01a018a779a7d262da1e4797d))

# [1.6.0-alpha.48](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.47...v1.6.0-alpha.48) (2023-12-14)


### Bug Fixes

* a null check ([6a89152](https://github.com/clubpay/js-customer-payment-module/commit/6a89152e0f01bf4fab152a47430b38bfdfd2bfea))

# [1.6.0-alpha.47](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.46...v1.6.0-alpha.47) (2023-12-14)


### Features

* changed flow ([ab52d2e](https://github.com/clubpay/js-customer-payment-module/commit/ab52d2efe5aac1df938add74f5e3854cd44e3cc8))

# [1.6.0-alpha.46](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.45...v1.6.0-alpha.46) (2023-12-14)


### Features

* remove old implementation ([7851eab](https://github.com/clubpay/js-customer-payment-module/commit/7851eab185983c16326a93b79d2ba92ca41aebbb))

# [1.6.0-alpha.45](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.44...v1.6.0-alpha.45) (2023-12-14)


### Features

* log some tests ([2a97278](https://github.com/clubpay/js-customer-payment-module/commit/2a972786ff9f1dc428bc3d804a8a112855046944))

# [1.6.0-alpha.44](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.43...v1.6.0-alpha.44) (2023-12-13)


### Features

* tried some fixes ([c0875e7](https://github.com/clubpay/js-customer-payment-module/commit/c0875e7e1f9c1c2fd05a4075352095f7771675ac))

# [1.6.0-alpha.43](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.42...v1.6.0-alpha.43) (2023-12-13)


### Features

* changed the flow to test ([6e10e57](https://github.com/clubpay/js-customer-payment-module/commit/6e10e57e274a45f225201d36e478376bbfd8f1be))

# [1.6.0-alpha.42](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.41...v1.6.0-alpha.42) (2023-12-13)


### Features

* added something to check ([988ae47](https://github.com/clubpay/js-customer-payment-module/commit/988ae47f45f4affc84d827fffa93eb88501bb57d))

# [1.6.0-alpha.41](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.40...v1.6.0-alpha.41) (2023-12-13)


### Features

* check the applepay session ([ca6f92a](https://github.com/clubpay/js-customer-payment-module/commit/ca6f92affb6b73bf6e55170519a9354b882eb1a4))

# [1.6.0-alpha.40](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.39...v1.6.0-alpha.40) (2023-12-13)


### Features

* tried to fix the applepay ([b1812b5](https://github.com/clubpay/js-customer-payment-module/commit/b1812b56178d63874e661d5fc8948784a9e9c520))

# [1.6.0-alpha.39](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.38...v1.6.0-alpha.39) (2023-12-13)


### Bug Fixes

* tried to fix the build error ([5a98917](https://github.com/clubpay/js-customer-payment-module/commit/5a98917140ffb88193df96252090d7a4b88539e0))

# [1.6.0-alpha.38](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.37...v1.6.0-alpha.38) (2023-12-13)


### Features

* fixed request error ([c42f1a2](https://github.com/clubpay/js-customer-payment-module/commit/c42f1a2b64485a3bf4c2f274422795f33655c588))

# [1.6.0-alpha.37](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.36...v1.6.0-alpha.37) (2023-12-13)


### Features

* added new endpoint ([b3c2346](https://github.com/clubpay/js-customer-payment-module/commit/b3c2346c8383c9a3175cf2bca4fdb8cb4726b9d2))
* refactored ([5fd7d8b](https://github.com/clubpay/js-customer-payment-module/commit/5fd7d8be902088ce32a7cecb80543d36836a2ac7))

# [1.6.0-alpha.36](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.35...v1.6.0-alpha.36) (2023-12-12)


### Features

* debugging ([1681672](https://github.com/clubpay/js-customer-payment-module/commit/16816728955edc7815d5db65d97de8859257453f))

# [1.6.0-alpha.35](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.34...v1.6.0-alpha.35) (2023-12-12)


### Features

* observe the state ([9c17bcf](https://github.com/clubpay/js-customer-payment-module/commit/9c17bcfd761f30aba76efe4229c0c34f2b154537))

# [1.6.0-alpha.34](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.33...v1.6.0-alpha.34) (2023-12-12)


### Features

* going on ([e6e74de](https://github.com/clubpay/js-customer-payment-module/commit/e6e74ded079ecbf39173e2bc1541ac73262fde9a))

# [1.6.0-alpha.33](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.32...v1.6.0-alpha.33) (2023-12-12)


### Features

* reverted the test ([75e6cbc](https://github.com/clubpay/js-customer-payment-module/commit/75e6cbc24004676fc4b7cc5caffc40a432131239))

# [1.6.0-alpha.32](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.31...v1.6.0-alpha.32) (2023-12-11)


### Bug Fixes

* trying to get method list ([a4605df](https://github.com/clubpay/js-customer-payment-module/commit/a4605dfc2db422b8f02560b5e638085b11769511))

# [1.6.0-alpha.31](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.30...v1.6.0-alpha.31) (2023-12-11)


### Features

* manipulated the id to test ([9bd97bb](https://github.com/clubpay/js-customer-payment-module/commit/9bd97bb6f684801a210cec1f887d020250795a22))

# [1.6.0-alpha.30](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.29...v1.6.0-alpha.30) (2023-12-11)


### Features

* changed payload ([d5e3da7](https://github.com/clubpay/js-customer-payment-module/commit/d5e3da769c6802422f56b78fee3da5060ccd58d0))

# [1.6.0-alpha.29](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.28...v1.6.0-alpha.29) (2023-12-11)


### Features

* changed the payload ([c31bd6e](https://github.com/clubpay/js-customer-payment-module/commit/c31bd6ec920eb92688e1d59cd48bd8f074ff07b5))

# [1.6.0-alpha.28](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.27...v1.6.0-alpha.28) (2023-12-08)


### Bug Fixes

* trying to change the payload to get methods ([470ca4b](https://github.com/clubpay/js-customer-payment-module/commit/470ca4bf393a42fb8de8c6e95cc3a34afcac23bc))

# [1.6.0-alpha.27](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.26...v1.6.0-alpha.27) (2023-12-08)


### Features

* trying to get correct payload for methods ([3f07231](https://github.com/clubpay/js-customer-payment-module/commit/3f07231e567e5bda7416737cd6d8a3036165cba3))

# [1.6.0-alpha.26](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.25...v1.6.0-alpha.26) (2023-12-08)


### Features

* changed the api path ([884c670](https://github.com/clubpay/js-customer-payment-module/commit/884c6702e69a232048a1f54d6ce8b6dc20766dbc))

# [1.6.0-alpha.25](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.24...v1.6.0-alpha.25) (2023-12-08)


### Features

* changed the way of sending gatewayid ([64163a1](https://github.com/clubpay/js-customer-payment-module/commit/64163a127f45a6c4b2db172957e0daaabb32eadc))

# [1.6.0-alpha.24](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.23...v1.6.0-alpha.24) (2023-12-08)


### Features

* changed the query parameter ([6168198](https://github.com/clubpay/js-customer-payment-module/commit/6168198b8ef4f75981137df068dd6fada9e9ea8c))

# [1.6.0-alpha.23](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.22...v1.6.0-alpha.23) (2023-12-08)


### Features

* got available methods ([e4e6b1a](https://github.com/clubpay/js-customer-payment-module/commit/e4e6b1a78a5a9f769d4a360d92387afd8fda14dd))

# [1.6.0-alpha.22](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.21...v1.6.0-alpha.22) (2023-12-08)


### Features

* added needed fields to adyen config ([baa5253](https://github.com/clubpay/js-customer-payment-module/commit/baa5253e9add5544c1f6857810157441d6762d8c))
* put get method list to work ([4a1a1af](https://github.com/clubpay/js-customer-payment-module/commit/4a1a1af5aecddc8fd57900b1f50f2aeccbdeaf2e))

# [1.6.0-alpha.21](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.20...v1.6.0-alpha.21) (2023-12-08)


### Features

* add style for button ([824f2b3](https://github.com/clubpay/js-customer-payment-module/commit/824f2b3d0c4d6b257b9ba786a2ac78d2addd4793))

# [1.6.0-alpha.20](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.19...v1.6.0-alpha.20) (2023-12-07)


### Bug Fixes

* changed due to adjust advanced impl ([292255c](https://github.com/clubpay/js-customer-payment-module/commit/292255c382501626ff2fac77a95d830851a8834d))

# [1.6.0-alpha.19](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.18...v1.6.0-alpha.19) (2023-12-07)


### Bug Fixes

* added type to error ([c9e0ba9](https://github.com/clubpay/js-customer-payment-module/commit/c9e0ba92f2d6a673492e4c7e1ffac7cc123315fd))

# [1.6.0-alpha.18](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.17...v1.6.0-alpha.18) (2023-12-07)


### Bug Fixes

* changed error handling to only log err ([253fde4](https://github.com/clubpay/js-customer-payment-module/commit/253fde4045dbf292a150097ace9fc3cba273e1e5))


### Features

* changed the flow to advanced ([2325979](https://github.com/clubpay/js-customer-payment-module/commit/2325979746db267cf6c048a14553d4241239f195))

# [1.6.0-alpha.17](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.16...v1.6.0-alpha.17) (2023-12-07)


### Features

* added advanced flow logic ([c536372](https://github.com/clubpay/js-customer-payment-module/commit/c536372885752b6daeb420071acbc8ebd05dcee7))

# [1.6.0-alpha.16](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.15...v1.6.0-alpha.16) (2023-12-07)


### Bug Fixes

* trying to see the config ([3600ee3](https://github.com/clubpay/js-customer-payment-module/commit/3600ee328b3b1b5cbbed386a1e4e5aed15362ae8))

# [1.6.0-alpha.15](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.14...v1.6.0-alpha.15) (2023-12-07)


### Bug Fixes

* removed multimple import of validate response ([0fb9241](https://github.com/clubpay/js-customer-payment-module/commit/0fb9241fd526c58120d0566f7aa4ae0a8571c8a1))

# [1.6.0-alpha.14](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.13...v1.6.0-alpha.14) (2023-12-07)


### Bug Fixes

* attempt to pass the build ([dc16104](https://github.com/clubpay/js-customer-payment-module/commit/dc161041b040f067e8e37ba932cc16a9f5a191e7))
* deployment issues ([87b14f5](https://github.com/clubpay/js-customer-payment-module/commit/87b14f5056294fc50e82075de9062a16f177ab90))

# [1.6.0-alpha.13](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.12...v1.6.0-alpha.13) (2023-12-06)


### Bug Fixes

* to be able to pass the deploy ([765d059](https://github.com/clubpay/js-customer-payment-module/commit/765d059628ff3ca36641bb3192fcf6967060deea))

# [1.6.0-alpha.12](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.11...v1.6.0-alpha.12) (2023-12-06)


### Features

* added missing endpoints ([7980f5b](https://github.com/clubpay/js-customer-payment-module/commit/7980f5bb4e66aa2d6ea8d259f8b5cad9aaf15308))

# [1.6.0-alpha.11](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.10...v1.6.0-alpha.11) (2023-12-06)


### Bug Fixes

* fixed possible undefined value to pass deploy ([9f3a55c](https://github.com/clubpay/js-customer-payment-module/commit/9f3a55c3676b84a2809fd6482c0d2e94f1b8807a))

# [1.6.0-alpha.10](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.9...v1.6.0-alpha.10) (2023-12-05)


### Bug Fixes

* combined/paym 362 396 485 ([#56](https://github.com/clubpay/js-customer-payment-module/issues/56)) ([d9add66](https://github.com/clubpay/js-customer-payment-module/commit/d9add66adcf301b2d01a0467b5ea84efaa957b3b))
* common module updated ([6172bef](https://github.com/clubpay/js-customer-payment-module/commit/6172bef62fef90812a6967f18705fb7d7115684c))


### Features

* applepay added ([274c2ba](https://github.com/clubpay/js-customer-payment-module/commit/274c2ba0b65cb4ce530dca5d862168730997ad9f))

## [1.5.3](https://github.com/clubpay/js-customer-payment-module/compare/v1.5.2...v1.5.3) (2023-12-01)


### Bug Fixes

* changed the way of importing paapi manager ([3d2c16f](https://github.com/clubpay/js-customer-payment-module/commit/3d2c16fb6bdcd5627b4379bcb3989d32d8b5c548))
* fixed common module version ([35e6e02](https://github.com/clubpay/js-customer-payment-module/commit/35e6e02fe6537b6571329389fc9f14765981f109))
* updated the common module ([0f4e8f1](https://github.com/clubpay/js-customer-payment-module/commit/0f4e8f1bb75981aee60778f95933b5eb47971816))


### Features

* to see some logs ([806a62d](https://github.com/clubpay/js-customer-payment-module/commit/806a62dc6499f48578f934a57adbd6c3d62bbab6))

# [1.6.0-alpha.8](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.7...v1.6.0-alpha.8) (2023-12-01)
* common module updated ([6172bef](https://github.com/clubpay/js-customer-payment-module/commit/6172bef62fef90812a6967f18705fb7d7115684c))

## [1.5.2](https://github.com/clubpay/js-customer-payment-module/compare/v1.5.1...v1.5.2) (2023-11-29)


### Bug Fixes

* init adyen new implementatio ([0df7053](https://github.com/clubpay/js-customer-payment-module/commit/0df70538da91aa678660b768244df2828adc79cd))
* update package ([24cd56e](https://github.com/clubpay/js-customer-payment-module/commit/24cd56e099231a33eb8785671f6f02133bda640b))


### Features

* adyen advanced implementation ([3c939ce](https://github.com/clubpay/js-customer-payment-module/commit/3c939ce385f48cbc3e364d2ad4a0e9d749fdb682))

# [1.6.0-alpha.7](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.6...v1.6.0-alpha.7) (2023-11-29)


### Bug Fixes

* fix moyasar v1 config ([a9aab7c](https://github.com/clubpay/js-customer-payment-module/commit/a9aab7c89a185377d059e04540feb163beae4e66))

# [1.6.0-alpha.6](https://github.com/clubpay/js-customer-payment-module/compare/v1.6.0-alpha.5...v1.6.0-alpha.6) (2023-11-27)


### Bug Fixes

* added needed hook call ([#53](https://github.com/clubpay/js-customer-payment-module/issues/53)) ([c9dacc7](https://github.com/clubpay/js-customer-payment-module/commit/c9dacc78334d47f4372c54db36d3c18bf39ba2cf))
* fix moyasar crash ([1edfbd2](https://github.com/clubpay/js-customer-payment-module/commit/1edfbd2c67c6b9b23fb508313db13869a149cbd2))
* fix moyasar v1 crash ([9a9a624](https://github.com/clubpay/js-customer-payment-module/commit/9a9a624bd26be6be559c867c214073cc4b2c24f0))


### Features

* added a function to remove special chars ([0de98b4](https://github.com/clubpay/js-customer-payment-module/commit/0de98b42917e573afebd736f2ee7a029b0acd3b5))
* combined/paym 362 396 485 ([#56](https://github.com/clubpay/js-customer-payment-module/issues/56)) ([d9add66](https://github.com/clubpay/js-customer-payment-module/commit/d9add66adcf301b2d01a0467b5ea84efaa957b3b))

## [1.5.1](https://github.com/clubpay/js-customer-payment-module/compare/v1.5.0...v1.5.1) (2023-11-27)


### Bug Fixes

* added needed hook call ([#53](https://github.com/clubpay/js-customer-payment-module/issues/53)) ([c9dacc7](https://github.com/clubpay/js-customer-payment-module/commit/c9dacc78334d47f4372c54db36d3c18bf39ba2cf))

## [1.4.2](https://github.com/clubpay/js-customer-payment-module/compare/v1.4.1...v1.4.2) (2023-11-15)


### Bug Fixes

* more checks on moyasar ([5107004](https://github.com/clubpay/js-customer-payment-module/commit/5107004ef04598d8f6a96325ee41d56fc550f50e))
* paym-527 google analytics ([#34](https://github.com/clubpay/js-customer-payment-module/issues/34)) ([ceffc34](https://github.com/clubpay/js-customer-payment-module/commit/ceffc34b81693d5ca595b461564cd276d0df42a1))
* paym-528 fix pay button issue ([#32](https://github.com/clubpay/js-customer-payment-module/issues/32)) ([e886bba](https://github.com/clubpay/js-customer-payment-module/commit/e886bbaf51ba33a4ac7c27f215fad68ea4af804d))
* paym-529 fix moyasar v2 apple pay ([#33](https://github.com/clubpay/js-customer-payment-module/issues/33)) ([a8b6d01](https://github.com/clubpay/js-customer-payment-module/commit/a8b6d01036a89f8ec2a0348941c28e83097d3b85))

## [1.4.1](https://github.com/clubpay/js-customer-payment-module/compare/v1.4.0...v1.4.1) (2023-11-10)


### Bug Fixes

* paym-503 fix stripe connection issue ([#28](https://github.com/clubpay/js-customer-payment-module/issues/28)) ([1a1de46](https://github.com/clubpay/js-customer-payment-module/commit/1a1de46c275d6433a439c6834dc65e61933f01aa))

# [1.4.0](https://github.com/clubpay/js-customer-payment-module/compare/v1.3.0...v1.4.0) (2023-11-09)


### Features

* PAYM-455 change stripe connect flow ([#10](https://github.com/clubpay/js-customer-payment-module/issues/10)) ([d3e56d4](https://github.com/clubpay/js-customer-payment-module/commit/d3e56d4c1334ca102710b1386fcb082776080200))

# [1.3.0](https://github.com/clubpay/js-customer-payment-module/compare/v1.2.2...v1.3.0) (2023-11-01)


### Features

* add foreign currency checkout card ([#7](https://github.com/clubpay/js-customer-payment-module/issues/7)) ([22b45bd](https://github.com/clubpay/js-customer-payment-module/commit/22b45bdc5325c4f189244f408b0e146772050b92))

## [1.2.2](https://github.com/clubpay/js-customer-payment-module/compare/v1.2.1...v1.2.2) (2023-11-01)


### Bug Fixes

* ci fix reverted ([5ca9a26](https://github.com/clubpay/js-customer-payment-module/commit/5ca9a26154c6e820dcd6cac2ce6e7e35ee93a6af))

## [1.2.1](https://github.com/clubpay/js-customer-payment-module/compare/v1.2.0...v1.2.1) (2023-10-31)


### Bug Fixes

* ci updated ([300ab33](https://github.com/clubpay/js-customer-payment-module/commit/300ab335bb361b25efbc7676cd5f9a1b611c64c5))

# [1.2.0](https://github.com/clubpay/js-customer-payment-module/compare/v1.1.1...v1.2.0) (2023-10-31)


### Bug Fixes

* alpha and dev channels added ([04be507](https://github.com/clubpay/js-customer-payment-module/commit/04be507a54b6bff7de97bc64dd2d7d81a1be52f0))
* **husky installation:** husky installation ([ddb41ac](https://github.com/clubpay/js-customer-payment-module/commit/ddb41ac94895bfbfbc39038275c357340e7a97bd))


### Features

* moyasar v2 applepay ([#6](https://github.com/clubpay/js-customer-payment-module/issues/6)) ([822e199](https://github.com/clubpay/js-customer-payment-module/commit/822e199eea2bfc518786821c81bd1bfa533c766f))

## [1.1.1](https://github.com/clubpay/js-customer-payment-module/compare/v1.1.0...v1.1.1) (2023-10-24)


### Bug Fixes

* another test ([c96676f](https://github.com/clubpay/js-customer-payment-module/commit/c96676fd28529195925a49b32cf0c5f150ff463c))
* icons updated ([bb765eb](https://github.com/clubpay/js-customer-payment-module/commit/bb765eb68d8adfddab504ca57639d795c04bf18d))
* test ([5b11da2](https://github.com/clubpay/js-customer-payment-module/commit/5b11da2993235faba8d3a48787dcb14ea21bf3c5))
* test ([3f672df](https://github.com/clubpay/js-customer-payment-module/commit/3f672dfdcaec6a058ae8d3595cd1e160ca0b5b66))

# [1.1.0](https://github.com/clubpay/js-customer-payment-module/compare/v1.0.4...v1.1.0) (2023-10-24)


### Features

* add custom alert message and google analytic event ([#1](https://github.com/clubpay/js-customer-payment-module/issues/1)) ([092af90](https://github.com/clubpay/js-customer-payment-module/commit/092af901dae6b4877484bf4c7ad0c47aa67e65fb))

## [1.0.4](https://github.com/clubpay/js-customer-payment-module/compare/v1.0.3...v1.0.4) (2023-10-23)


### Bug Fixes

* browserslist ([a55668d](https://github.com/clubpay/js-customer-payment-module/commit/a55668d47c5c043ce6567d0407cc9a78917d2756))

## [1.0.3](https://github.com/clubpay/js-customer-payment-module/compare/v1.0.2...v1.0.3) (2023-10-23)


### Bug Fixes

* browserlist updated ([e369ae7](https://github.com/clubpay/js-customer-payment-module/commit/e369ae72358d24f4ee20f90ffd824144836f81c6))
* common updated ([c409010](https://github.com/clubpay/js-customer-payment-module/commit/c409010d21ab6e0534ac793fccdcf37a00730346))

## [1.0.2](https://github.com/clubpay/js-customer-payment-module/compare/v1.0.1...v1.0.2) (2023-10-23)


### Bug Fixes

* names updated ([8c95674](https://github.com/clubpay/js-customer-payment-module/commit/8c95674cee0036a3d89b693e97f2c67352c8fe21))
* naming updated ([86fc993](https://github.com/clubpay/js-customer-payment-module/commit/86fc9935532607077f8bdd0602c3f7c8d94d8393))

## [1.0.1](https://github.com/clubpay/js-customer-payment-module/compare/v1.0.0...v1.0.1) (2023-10-23)


### Bug Fixes

* adyen registerred ([77e4774](https://github.com/clubpay/js-customer-payment-module/commit/77e47740e5afae1033fcd721f2acbe5322dd8412))
* routes ([35e452c](https://github.com/clubpay/js-customer-payment-module/commit/35e452cf7bc66fcfbc18cf84738f45e3dd0d8893))

# 1.0.0 (2023-10-23)


### Bug Fixes

* creds and repos updated ([45270ac](https://github.com/clubpay/js-customer-payment-module/commit/45270acdfb1b6c64090db59dfee8579e528a734d))
* deps updated ([e880a9a](https://github.com/clubpay/js-customer-payment-module/commit/e880a9a8fd07c98b885777332b9375e577fcbbb5))
* deps updated ([0e6e774](https://github.com/clubpay/js-customer-payment-module/commit/0e6e774963dbaaf98f0719abd62b407e6d04a7bf))
* github action added ([1bb8a07](https://github.com/clubpay/js-customer-payment-module/commit/1bb8a07b2ba24b4b200af3198d2a379c0068b613))
* imports and deps ([03c1a64](https://github.com/clubpay/js-customer-payment-module/commit/03c1a64915b4874aac19294a7283527476d22b4f))
* modules updatefd ([f5d358a](https://github.com/clubpay/js-customer-payment-module/commit/f5d358a652562a24511bc978074fb46a81db5be6))


### Features

* adyen updated ([bf7e5c7](https://github.com/clubpay/js-customer-payment-module/commit/bf7e5c7d0e37847fbe341873b50c558230d7da24))

# [1.1.0](https://github.com/qlub-dev/customer-app-payment-module/compare/v1.0.1...v1.1.0) (2023-10-23)


### Features

* adyen updated ([bf7e5c7](https://github.com/qlub-dev/customer-app-payment-module/commit/bf7e5c7d0e37847fbe341873b50c558230d7da24))

## [1.0.1](https://github.com/qlub-dev/customer-app-payment-module/compare/v1.0.0...v1.0.1) (2023-10-19)


### Bug Fixes

* imports and deps ([03c1a64](https://github.com/qlub-dev/customer-app-payment-module/commit/03c1a64915b4874aac19294a7283527476d22b4f))

# 1.0.0 (2023-10-19)


### Bug Fixes

* deps updated ([0e6e774](https://github.com/qlub-dev/customer-app-payment-module/commit/0e6e774963dbaaf98f0719abd62b407e6d04a7bf))
* github action added ([1bb8a07](https://github.com/qlub-dev/customer-app-payment-module/commit/1bb8a07b2ba24b4b200af3198d2a379c0068b613))
* modules updatefd ([f5d358a](https://github.com/qlub-dev/customer-app-payment-module/commit/f5d358a652562a24511bc978074fb46a81db5be6))
