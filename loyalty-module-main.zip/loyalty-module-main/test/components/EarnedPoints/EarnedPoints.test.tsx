import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, expect, it } from "vitest";
import { default as EarnedPoints } from "@/components/EarnedPoints";
import { testIds } from "../../_ids_";
import { mockLoyaltyProgram } from "../../_mocks_";
import { genericProps } from "../../_mocks_";

afterEach(cleanup);

it("Render with correct amount", () => {
  render(<EarnedPoints amount={300} currencyFormat={genericProps.currencyFormat} program={mockLoyaltyProgram} />);
  expect(screen.getByTestId(testIds.earnedPoints.points).innerText).toBe("+ AED300.00");
});

it("Hide action button when hideAction is true", () => {
  render(
    <EarnedPoints amount={50} currencyFormat={genericProps.currencyFormat} hideAction program={mockLoyaltyProgram} />
  );
  expect(screen.queryByTestId(testIds.earnedPoints.action)).toBeNull();
});
