import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { default as Earn } from "@/components/Earn";
import { ThemeProvider } from "@mui/material/styles";
import { QlubKitTheme } from "@qlub-dev/qlub-kit";
import { testIds } from "../../_ids_";
import { genericProps } from "../../_mocks_";

afterEach(cleanup);

describe("With defaults", () => {
  const defaultTitle = "Collect your loyalty points";
  const defaultDescription = "Enter your mobile number to collect your points";
  const defaultButtonText = "Earn points now";
  it("In english", () => {
    render(<Earn {...genericProps} />);
    expect(screen.getByText(defaultTitle)).toBeDefined();
    expect(screen.getByText(defaultDescription)).toBeDefined();
    expect(screen.getByText(defaultButtonText)).toBeDefined();
  });
});
it("With custom title", () => {
  render(<Earn {...genericProps} ui={{ text: { title: "Custom title" } }} />);
  expect(screen.getByText("Custom title")).toBeDefined();
});
it("With custom description", () => {
  render(<Earn {...genericProps} ui={{ text: { description: "Custom description" } }} />);
  expect(screen.getByText("Custom description")).toBeDefined();
});
it("With custom button text", () => {
  render(<Earn {...genericProps} ui={{ text: { button: "Custom button text" } }} />);
  expect(screen.getByText("Custom button text")).toBeDefined();
});
it("With on input event", () => {
  const onInput = vi.fn();
  render(
    <Earn
      {...genericProps}
      events={{
        onInput
      }}
    />
  );
  const input = screen.getByTestId(testIds.earn.input);
  fireEvent.change(input, { target: { value: "777" } });
  expect(onInput).toHaveBeenCalledWith("777");
});
it("With on earn event", () => {
  const onEarn = vi.fn();
  render(
    <ThemeProvider theme={QlubKitTheme}>
      <Earn
        {...genericProps}
        events={{
          onEarn
        }}
      />
    </ThemeProvider>
  );
  fireEvent.change(screen.getByTestId(testIds.earn.input), { target: { value: "+966552538523" } });
  fireEvent.click(screen.getByTestId(testIds.earn.button));
  expect(onEarn).toHaveBeenCalledWith("966552538523");
});
