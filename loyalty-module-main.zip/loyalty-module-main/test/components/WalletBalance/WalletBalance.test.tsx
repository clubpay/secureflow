import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, beforeAll, expect, it } from "vitest";
import { default as WalletBalance } from "@/components/WalletBalance";
import { useGlobalStore } from "@/store/global";
import { testIds } from "../../_ids_";
import { genericProps, mockLoyaltyProgram } from "../../_mocks_";

beforeAll(() => {
  useGlobalStore.getState().setSelectedProgram(mockLoyaltyProgram);
});

afterEach(cleanup);

it("Render with correct points", () => {
  render(
    <WalletBalance
      name="Paul"
      program={mockLoyaltyProgram}
      balance={50.5}
      currencyFormat={genericProps.currencyFormat}
    />
  );
  expect(screen.getByTestId(testIds.wallet.default.balance.points).innerText).toBe("AED25.25");
});

it("Render with correct wallet name", () => {
  render(
    <WalletBalance
      name="Paul"
      program={mockLoyaltyProgram}
      balance={50.5}
      currencyFormat={genericProps.currencyFormat}
    />
  );
  expect(screen.getByTestId(testIds.wallet.default.balance.walletName).innerText).toBe("Paul wallet");
});
