import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { default as Wallet, WalletType } from "@/components/Wallet";
import { useAuthStore } from "@/store/auth";
import { testIds } from "../../_ids_";
import { genericProps, mockLoyaltyProgram, mockUser } from "../../_mocks_";

afterEach(cleanup);

describe("Render Teaser wallet", () => {
  beforeEach(() => {
    render(<Wallet type={WalletType.Teaser} billAmount={100} {...genericProps} program={mockLoyaltyProgram} />);
  });
  it("Should have title as wallet name", () => {
    expect(screen.getByTestId(testIds.wallet.default.title).innerText).toBe("Paul wallet");
  });
  it("Should have central points as earnable points", () => {
    expect(screen.getByTestId(testIds.wallet.default.centralPoints).innerText?.trim()).toBe("Earn AED500.00");
  });
});

describe("Render Detailed wallet", () => {
  describe("Without expiring points", () => {
    beforeEach(() => {
      useAuthStore.getState().setUser(mockLoyaltyProgram.id, mockUser);
      render(<Wallet type={WalletType.Detailed} billAmount={100} {...genericProps} program={mockLoyaltyProgram} />);
    });
    it("Should have title as wallet balance", () => {
      expect(screen.getByTestId(testIds.wallet.default.title).innerText).toBe("Wallet balance");
    });
    it("Should have central points as balance", () => {
      expect(screen.getByTestId(testIds.wallet.default.centralPoints).innerText?.trim()).toBe("AED225.00");
    });
    it("Should not have login prompt", () => {
      expect(screen.queryByTestId(testIds.wallet.default.loginPrompt)).toBeNull();
    });
    it("Should have redeemed points as --", () => {
      expect(screen.getByTestId(testIds.wallet.default.redeemedPoints).innerText).toBe("--");
    });
    it("Should have wallet name within the detail row", () => {
      expect(screen.getByTestId(testIds.wallet.default.detailRowWalletName).innerText).toBe("Paul wallet");
    });
    it("Should not have expiring points element", () => {
      expect(screen.queryByTestId(testIds.wallet.default.expiringPoints)).toBeNull();
    });
  });
  describe("With expiring points", () => {
    beforeEach(() => {
      useAuthStore.getState().setUser(mockLoyaltyProgram.id, mockUser);
      render(
        <Wallet
          type={WalletType.Detailed}
          billAmount={100}
          {...genericProps}
          program={{
            ...mockLoyaltyProgram,
            config: {
              ...mockLoyaltyProgram.config,
              showExpiryNotificationOnLanding: true
            }
          }}
        />
      );
    });
    it("Should have expiring points element", () => {
      expect(screen.getByTestId(testIds.wallet.default.expiringPoints).innerText).toContain(
        "AED50.00 will expire soon"
      );
    });
    it("Should not have the wallet name within the detail row", () => {
      expect(screen.queryByTestId(testIds.wallet.default.detailRowWalletName)).toBeNull();
    });
  });
});
