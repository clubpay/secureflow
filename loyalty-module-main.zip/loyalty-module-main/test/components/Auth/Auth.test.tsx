import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { default as Trigger } from "@/components/Trigger";
import { useGlobalStore } from "@/store/global";
import { TriggerType } from "@/types";
import { ThemeProvider } from "@mui/material/styles";
import { QlubKitTheme } from "@qlub-dev/qlub-kit";
import { testIds } from "../../_ids_";
import { mobileNumbers, mockLoyaltyProgram, offerTriggerProps } from "../../_mocks_";
import { clickTrigger, enterMobileNumber, isOpen, submitLogin } from "../../_utils_";

const onLogin = vi.fn(async () => {});

const onLoginVerification = vi.fn(async () => {});

const onSheetClose = vi.fn();

beforeAll(() => {
  useGlobalStore.getState().setSelectedProgram(mockLoyaltyProgram);
});

afterEach(() => {
  cleanup();
  onLogin.mockClear();
  onLoginVerification.mockClear();
  onSheetClose.mockClear();
});

beforeEach(async () => {
  render(
    <ThemeProvider theme={QlubKitTheme}>
      <Trigger
        {...offerTriggerProps}
        type={TriggerType.Offer}
        config={{
          ...offerTriggerProps.config,
          events: {
            onLogin,
            onLoginVerification,
            onSheetClose
          }
        }}
      />
    </ThemeProvider>
  );
  await clickTrigger();
  await isOpen(testIds.auth.login.sheet);
});

describe("Login sheet", () => {
  describe("On submit", () => {
    it("Should navigate to otp page", async () => {
      await enterMobileNumber();
      await submitLogin();
      expect(onLogin).toHaveBeenCalledWith(mobileNumbers.sa);
    });
  });
  describe("On back", () => {
    beforeEach(() => {
      fireEvent.click(screen.getByTestId(testIds.auth.login.back));
    });
    // it("Should close sheet", async () => {
    //   await isClosed(testIds.auth.login.sheet);
    // });
    // it("Should call on sheet close", () => {
    //   expect(onSheetClose).toHaveBeenCalled();
    // });
  });
});
// describe("OTP sheet", () => {
//   beforeEach(async () => {
//     await enterMobileNumber();
//     await submitLogin();
//     await isOpen(testIds.auth.otp.sheet);
//   });
//   describe("On submit", () => {
//     it("Should be disabled by default", () => {
//       expect(screen.getByTestId(testIds.auth.otp.button).hasAttribute("disabled")).toBe(true);
//     });
//     describe("", () => {
//       beforeEach(async () => {
//         await enterOTP("1234");
//         await submitOTP();
//       });
//       it("Should call on login verification", () => {
//         expect(onLoginVerification).toHaveBeenCalledWith("1234", mobileNumbers.sa);
//       });
//       it("Should close otp sheet", async () => {
//         await waitForElementToBeRemoved(() => screen.queryByTestId(testIds.auth.otp.sheet));
//       });
//     });
//   });
//   describe("On resend", () => {
//     beforeEach(() => {
//       fireEvent.click(screen.getByTestId(testIds.auth.otp.resend));
//     });
//     it("Should call on login", () => {
//       expect(onLogin).toHaveBeenCalledWith(mobileNumbers.sa);
//     });
//     it("Should initiate timer after resending once", () => {
//       expect(screen.getByTestId(testIds.auth.otp.resend).textContent).toBe("I didn't receive a code(01:00)");
//     });
//   });
//   describe("On back", () => {
//     beforeEach(() => {
//       fireEvent.click(screen.getByTestId(testIds.auth.otp.back));
//     });
//     it("Should close sheet", async () => {
//       await isClosed(testIds.auth.otp.sheet);
//     });
//     it("Should open login sheet", async () => {
//       await isOpen(testIds.auth.login.sheet);
//     });
//     it("Should not call on sheet close", () => {
//       expect(onSheetClose).not.toHaveBeenCalled();
//     });
//   });
// });
