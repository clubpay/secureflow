import { cleanup, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { RedemptionDetails } from "@/components/Redemption";
import { ThemeProvider } from "@mui/material";
import { QlubKitTheme } from "@qlub-dev/qlub-kit";
import { testIds } from "../../_ids_";
import { mockCompletedRedemption, mockLoyaltyProgram, redemptionTriggerProps } from "../../_mocks_";

afterEach(cleanup);

describe("Render when there is a completed redemption", async () => {
  beforeEach(async () => {
    render(
      <ThemeProvider theme={QlubKitTheme}>
        <RedemptionDetails
          {...redemptionTriggerProps}
          bill={redemptionTriggerProps.bill}
          program={mockLoyaltyProgram}
          config={{
            ...redemptionTriggerProps.config,
            redemption: mockCompletedRedemption
          }}
        />
      </ThemeProvider>
    );
  });
  it("Redemption details with points and identifier", async () => {
    const pointElementContent = await waitFor(() => screen.getByTestId(testIds.redemption.details.points).innerText);
    expect(pointElementContent).toContain("100");
    expect(pointElementContent).toContain("Alfaco points");
  });
  it("Redemption details with amount", async () => {
    await waitFor(() =>
      expect(screen.getByTestId(testIds.redemption.details.amount).innerText?.toString()).toBe("-AED10.00")
    );
  });
});
