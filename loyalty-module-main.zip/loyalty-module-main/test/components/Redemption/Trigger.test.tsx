import { cleanup, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { default as Trigger } from "@/components/Trigger";
import { TriggerType } from "@/types";
import { testIds } from "../../_ids_";
import { mockCompletedRedemption, mockLoyaltyProgram, redemptionTriggerProps } from "../../_mocks_";

afterEach(cleanup);

describe("Render when there is a completed redemption", async () => {
  beforeEach(async () => {
    render(
      <Trigger
        {...redemptionTriggerProps}
        type={TriggerType.Redemption}
        program={mockLoyaltyProgram}
        config={{
          ...redemptionTriggerProps.config,
          redemption: mockCompletedRedemption
        }}
      />
    );
  });
  it("No trigger button", async () => {
    await waitFor(() => expect(screen.queryByTestId(testIds.trigger[TriggerType.Redemption])).toBeNull());
  });
});
