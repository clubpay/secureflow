import { RenderResult, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { default as Trigger } from "@/components/Trigger";
import { DialogProvider } from "@/providers/dialog";
import { useAuthStore } from "@/store/auth";
import { LoyaltyService, TriggerType } from "@/types";
import { testIds } from "../../_ids_";
import { mockLoyaltyProgram, mockUser, redemptionTriggerProps } from "../../_mocks_";
import { clickTrigger, isClosed, isOpen } from "../../_utils_";

const onSheetClose = vi.fn(async () => {});

const onRedemption = vi.fn(async () => {});

let view: RenderResult;

beforeEach(async () => {
  useAuthStore.getState().setUser(LoyaltyService.Qlub, mockUser);
  view = render(
    <DialogProvider>
      <Trigger
        {...redemptionTriggerProps}
        type={TriggerType.Redemption}
        program={mockLoyaltyProgram}
        config={{
          ...redemptionTriggerProps.config,
          events: {
            onSheetClose,
            onRedemption
          }
        }}
      />
    </DialogProvider>
  );
  await clickTrigger(TriggerType.Redemption);
});

afterEach(() => {
  cleanup();
  onSheetClose.mockClear();
  onRedemption.mockClear();
});

describe("Render with", () => {
  beforeEach(async () => {
    await isOpen(testIds.redemption.checkout.sheet);
  });
  afterEach(cleanup);
  it("An enabled redeem button by default", async () => {
    await waitFor(() =>
      expect(screen.getByTestId(testIds.redemption.checkout.redeem).hasAttribute("disabled")).toBe(false)
    );
  });
  it("The maximum redeemable points by default as the input", async () => {
    await waitFor(() =>
      expect(screen.getByTestId(testIds.redemption.checkout.input)?.getAttribute("value")).toBe("400")
    );
  });
  describe("A disabled redeem button", () => {
    it("When user enters a point value less than min", async () => {
      const input = await waitFor(() => screen.getByTestId(testIds.redemption.checkout.input));
      fireEvent.change(input, { target: { value: "4" } });
      expect(screen.getByTestId(testIds.redemption.checkout.redeem).hasAttribute("disabled")).toBe(true);
    });
    it("When user enters a point value greater than max", async () => {
      const input = await waitFor(() => screen.getByTestId(testIds.redemption.checkout.input));
      fireEvent.change(input, { target: { value: "401" } });
      expect(screen.getByTestId(testIds.redemption.checkout.redeem).hasAttribute("disabled")).toBe(true);
    });
  });
  it("Your bill as 50.00 AED", async () => {
    await waitFor(() => expect(screen.getByTestId(testIds.redemption.checkout.yourBill)?.innerText).toBe("AED50.00"));
  });
  it("Account balance points as 450.00", async () => {
    await waitFor(() =>
      expect(screen.getByTestId(testIds.redemption.checkout.accountBalancePoints)?.innerText).toBe("450.00")
    );
  });
  it("Account balance worth as 45.00 AED", async () => {
    await waitFor(() =>
      expect(screen.getByTestId(testIds.redemption.checkout.accountBalanceWorth)?.innerText).toBe("AED45.00")
    );
  });
  it("Minimum as 5 points", async () => {
    await waitFor(() =>
      expect(screen.getByTestId(testIds.redemption.checkout.min)?.innerText?.replace(/\s/g, "")).toBe(
        "5Points(AED0.50)"
      )
    );
  });
  it("Maximum as 400 points", async () => {
    await waitFor(() =>
      expect(screen.getByTestId(testIds.redemption.checkout.max)?.innerText?.replace(/\s/g, "")).toBe(
        "400.00Points(AED40.00)"
      )
    );
  });
  it("Redeem amount as 40 AED", async () => {
    await waitFor(() =>
      expect(screen.getByTestId(testIds.redemption.checkout.redeemingAmount)?.innerText).toBe("AED40.00")
    );
  });
  it("Redeem amount as 30 AED on input change", async () => {
    const input = await waitFor(() => screen.getByTestId(testIds.redemption.checkout.input));
    fireEvent.change(input, { target: { value: "300" } });
    await waitFor(() =>
      expect(screen.getByTestId(testIds.redemption.checkout.redeemingAmount)?.innerText).toBe("AED30.00")
    );
  });
  it("Redeem amount as 30.05 AED on input change with decimal", async () => {
    const input = await waitFor(() => screen.getByTestId(testIds.redemption.checkout.input));
    fireEvent.change(input, { target: { value: "300.5" } });
    await waitFor(() =>
      expect(screen.getByTestId(testIds.redemption.checkout.redeemingAmount)?.innerText).toBe("AED30.05")
    );
  });
  it("Redeem amount as 30.00 AED on input change with incomplete decimal", async () => {
    const input = await waitFor(() => screen.getByTestId(testIds.redemption.checkout.input));
    fireEvent.change(input, { target: { value: "300." } });
    await waitFor(() =>
      expect(screen.getByTestId(testIds.redemption.checkout.redeemingAmount)?.innerText).toBe("AED30.00")
    );
  });
});

describe("On back", () => {
  beforeEach(async () => {
    const backButton = await waitFor(() => screen.getByTestId(testIds.redemption.checkout.back));
    fireEvent.click(backButton);
  });
  afterEach(cleanup);
  it("Should close sheet", async () => {
    await isClosed(testIds.redemption.checkout.sheet);
  });
  it("Should call on sheet close", () => {
    expect(onSheetClose).toHaveBeenCalledTimes(1);
  });
});

describe("On redeem", () => {
  beforeEach(async () => {
    const redeemButton = await waitFor(() => screen.getByTestId(testIds.redemption.checkout.redeem));
    fireEvent.click(redeemButton);
  });
  afterEach(cleanup);
  it("Should call on redemption", async () => {
    expect(onRedemption).toHaveBeenCalledTimes(1);
    expect(onRedemption).toHaveBeenCalledWith({
      points: 400,
      maxRedeemablePoints: 400,
      maxRedeemablePointsIgnoringBalance: 400,
      maxRedeemableValue: 40
    });
  });
  it("Should close sheet", async () => {
    await isClosed(testIds.redemption.checkout.sheet);
  });
  describe("With confirmation dialog", () => {
    const onRedemption = vi.fn(async () => {});
    const onRedemptionConfirm = vi.fn(async () => {});
    const onRedemptionCancel = vi.fn(async () => {});
    beforeEach(async () => {
      view.rerender(
        <DialogProvider>
          <Trigger
            {...redemptionTriggerProps}
            type={TriggerType.Redemption}
            config={{
              ...redemptionTriggerProps.config,
              events: {
                onSheetClose,
                onRedemption,
                onRedemptionConfirm,
                onRedemptionCancel
              }
            }}
          />
        </DialogProvider>
      );
      const redeemButton = await waitFor(() => screen.getByTestId(testIds.redemption.checkout.redeem));
      fireEvent.click(redeemButton);
    });
    afterEach(() => {
      cleanup();
      onRedemption.mockClear();
      onRedemptionConfirm.mockClear();
      onRedemptionCancel.mockClear();
    });
    it("Should not call on redemption before confirmation", async () => {
      expect(onRedemption).toHaveBeenCalledTimes(0);
    });
    it("Should call on redemption cancel on cancel", async () => {
      const cancelButton = await waitFor(() => screen.getByTestId(testIds.dialog.cancel));
      fireEvent.click(cancelButton);
      expect(onRedemptionCancel).toHaveBeenCalledTimes(1);
    });
    it("Should call on redemption confirm on proceed", async () => {
      const proceedButton = await waitFor(() => screen.getByTestId(testIds.dialog.proceed));
      fireEvent.click(proceedButton);
      expect(onRedemptionConfirm).toHaveBeenCalledTimes(1);
    });
    it("Should call on redemption on proceed", async () => {
      const proceedButton = await waitFor(() => screen.getByTestId(testIds.dialog.proceed));
      fireEvent.click(proceedButton);
      expect(onRedemption).toHaveBeenCalledTimes(1);
    });
  });
});

describe("On insufficient points", () => {
  const onInsufficientPoints = vi.fn(async () => {});
  beforeEach(async () => {
    useAuthStore.getState().setUser(LoyaltyService.Qlub, {
      ...mockUser,
      accountBalance: {
        monetary: 0,
        nonMonetary: 0
      }
    });
    view.rerender(
      <Trigger
        {...redemptionTriggerProps}
        type={TriggerType.Redemption}
        program={mockLoyaltyProgram}
        config={{
          ...redemptionTriggerProps.config,
          events: {
            onInsufficientPoints
          }
        }}
      />
    );
    await isOpen(testIds.redemption.checkout.sheet);
  });
  afterEach(() => {
    cleanup();
    onInsufficientPoints.mockClear();
  });
  it("Should call on insufficient points", async () => {
    expect(onInsufficientPoints).toHaveBeenCalledTimes(1);
  });
  it("Should show low balance error", async () => {
    await waitFor(() =>
      expect(screen.getByTestId(testIds.redemption.checkout.warningText).innerText).toBe(
        "You don’t have sufficient points to redeem"
      )
    );
  });
  it("Should not show redeem button", async () => {
    await waitFor(() => expect(screen.queryByTestId(testIds.redemption.checkout.redeem)).toBeNull());
  });
});

describe("On a low max than min", () => {
  beforeEach(async () => {
    useAuthStore.getState().setUser(LoyaltyService.Qlub, mockUser);
    view.rerender(
      <Trigger
        {...redemptionTriggerProps}
        type={TriggerType.Redemption}
        program={{
          ...mockLoyaltyProgram,
          config: {
            ...mockLoyaltyProgram.config,
            minPointsPerTransaction: 10,
            maxPointsPerTransaction: 5
          }
        }}
      />
    );
    await isOpen(testIds.redemption.checkout.sheet);
  });
  afterEach(cleanup);
  it("Should show the required minimum redemption warning", async () => {
    await waitFor(() =>
      expect(screen.getByTestId(testIds.redemption.checkout.warningText).innerText).toBe(
        "Minimum redemption allowed is AED 1.00 (10 points)"
      )
    );
  });
  it("Should not show redeem button", async () => {
    await waitFor(() => expect(screen.queryByTestId(testIds.redemption.checkout.redeem)).toBeNull());
  });
});
