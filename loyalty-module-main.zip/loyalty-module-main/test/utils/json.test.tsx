import { cleanup } from "@testing-library/react";
import { afterEach, expect, it } from "vitest";
import { prefixKeys, prefixValues } from "@/utils";

afterEach(cleanup);

it("Should prefix all keys with 'test'", () => {
  expect(prefixKeys({ a: 1, b: 2 }, "test.")).toEqual({ "test.a": 1, "test.b": 2 });
});

it("Should prefix all values with 'test'", () => {
  expect(prefixValues({ a: 1, b: 2 }, "test.")).toEqual({ a: "test.1", b: "test.2" });
});
