import { afterEach, vi } from "vitest";
import * as zustand from "zustand";

export * from "./generic";
export * from "./offer";
export * from "./redemption";

vi.doMock("lottie-react", () => ({
  default: vi.fn()
}));

const stores = new Set<Function>();

const actualCreate = zustand.create;

vi.doMock("zustand", () => ({
  create: vi.fn(() => (createState: any) => {
    const store = actualCreate(createState);
    const initialState = store.getState();
    stores.add(() => store.setState(initialState, true));
    return store;
  })
}));

global.IntersectionObserver = class IntersectionObserver {
  constructor() {}

  disconnect() {
    return null;
  }

  observe() {
    return null;
  }

  takeRecords() {
    return null;
  }

  unobserve() {
    return null;
  }
} as any;

afterEach(() => stores.forEach((resetFn) => resetFn()));
