import { LoyaltyService } from "@/types";
import { genericProps } from "./generic";

export const offerTriggerProps = {
  ...genericProps,
  bill: {
    amount: 100,
    share: 50,
    tax: 10,
    remaining: 100
  },
  config: {
    program: { id: LoyaltyService.Como, type: LoyaltyService.Como } as any,
    auth: {
      user: null,
      attempts: 1,
      maxAttempts: 5
    },
    ui: {
      display_offer_sheet: true
    }
  }
};

export const offerLineItemProps = {
  bill: {
    amount: 50,
    share: 25,
    tax: 5
  },
  currencyFormat: genericProps.currencyFormat
};
