import { LoyaltyService } from "@/types";
import { genericProps } from "./generic";

export const redemptionTriggerProps = {
  ...genericProps,
  config: {
    program: { name: "Alfaco rewards", id: LoyaltyService.Como, type: LoyaltyService.Como } as any,
    auth: {
      user: null,
      attempts: 1,
      maxAttempts: 5
    },
    limits: {
      min: 5,
      max: 500
    },
    conversionRate: 0.1
  },
  bill: {
    amount: 100,
    share: 50,
    remaining: 100,
    tax: 10,
    commission: 0
  }
};
