import { inflateLoyaltyProgram } from "@/transformers";
import { LoyaltyService } from "@/types";

export const mobileNumbers = {
  sa: "966552538523"
};

const mockVendor = {
  config: {},
  country: {}
} as any;

export const genericProps = {
  program: inflateLoyaltyProgram({ id: LoyaltyService.Como, type: LoyaltyService.Como } as any, mockVendor),
  programName: "Paul",
  locale: "en",
  currencyFormat: { cs: "AED", cc: "ae", currencyPrecision: 2, currencyCommaSeparator: "disable" as any },
  country: "ae"
};

export const mockUser = {
  id: "1",
  name: "Akalanka Perera",
  mobile: "+94771234567",
  email: "akalanka@qlub.io",
  accountBalance: {
    monetary: 450,
    nonMonetary: 450
  },
  expiringPoints: 100,
  accountNumber: "1190152117497",
  conversionRate: 1,
  phoneNumber: "+94771234567",
  status: "active",
  createdOn: "2021-08-10T08:00:00.000Z",
  isAuthorized: true
};

export const mockCompletedRedemption = {
  program: "Alfaco",
  points: 100,
  amount: 10,
  pointIdentifier: "Alfaco points",
  completed: true,
  status: "ok",
  confirmation: "123456"
};

export const mockLoyaltyProgram = inflateLoyaltyProgram(
  {
    id: LoyaltyService.Qlub,
    name: "Qlub Loyalty",
    type: LoyaltyService.Qlub,
    config: {
      isEarnEnabled: true,
      isBurnEnabled: true,
      earnPointConversionRate: 10,
      burnPointConversionRate: 2,
      loyaltyBenefits:
        '[{"key":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"Exclusive cashbacks\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]","value":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"Step 1 description\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"unlock unbeatable savings at your favourite restaurants!\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]","image":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"https://stage-qlub-cloud.s3.ap-southeast-1.amazonaws.com/temp/12025/m5ey7rb6gvocq9h3qo_blob\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]"},{"key":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"curated restaurant selection\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]","value":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"Discover handpicked restaurants that cater to every palate\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]","image":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"https://stage-qlub-cloud.s3.ap-southeast-1.amazonaws.com/temp/12025/m5ey72yycbyshbavzx_blob\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]"},{"key":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"Easy-to-use\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]","value":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"Easily explore and access discounts with the discovery page\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]","image":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"https://stage-qlub-cloud.s3.ap-southeast-1.amazonaws.com/temp/12025/m5ey6qv4z0cahawcev_247776.svg\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]"}]',
      howItWorks:
        '[{"key":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"Exclusive cashbacks\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]","value":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"Step 1 description\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"unlock unbeatable savings at your favourite restaurants!\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]","image":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"https://stage-qlub-cloud.s3.ap-southeast-1.amazonaws.com/temp/12025/m5ey7rb6gvocq9h3qo_blob\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]"},{"key":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"curated restaurant selection\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]","value":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"Discover handpicked restaurants that cater to every palate\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]","image":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"https://stage-qlub-cloud.s3.ap-southeast-1.amazonaws.com/temp/12025/m5ey72yycbyshbavzx_blob\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]"},{"key":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"Easy-to-use\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]","value":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"Easily explore and access discounts with the discovery page\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]","image":"[{\\"locale\\":\\"ar\\",\\"value\\":\\"\\"},{\\"locale\\":\\"hk\\",\\"value\\":\\"\\"},{\\"locale\\":\\"ja\\",\\"value\\":\\"\\"},{\\"locale\\":\\"es\\",\\"value\\":\\"\\"},{\\"locale\\":\\"tr\\",\\"value\\":\\"\\"},{\\"locale\\":\\"pt\\",\\"value\\":\\"\\"},{\\"locale\\":\\"en\\",\\"value\\":\\"https://stage-qlub-cloud.s3.ap-southeast-1.amazonaws.com/temp/12025/m5ey6qv4z0cahawcev_247776.svg\\"},{\\"locale\\":\\"zh\\",\\"value\\":\\"\\"}]"}]',
      displayLoyaltyBenefits: true,
      displayName: [
        { locale: "ar", value: "" },
        { locale: "zh", value: "" },
        { locale: "en", value: "Paul" },
        { locale: "de", value: "" },
        { locale: "ja", value: "" },
        { locale: "pt", value: "" },
        { locale: "es", value: "" },
        { locale: "tr", value: "" }
      ]
    }
  } as any,
  mockVendor
);
