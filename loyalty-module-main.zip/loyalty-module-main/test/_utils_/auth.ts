import { fireEvent, screen, waitFor } from "@testing-library/react";
import { isOpen } from ".";
import { testIds } from "../_ids_";
import { mobileNumbers } from "../_mocks_";

export const enterMobileNumber = async () => {
  fireEvent.change(await waitFor(() => screen.getByTestId(testIds.auth.login.input)), {
    target: { value: mobileNumbers.sa }
  });
};

export const submitLogin = async () => {
  fireEvent.click(await waitFor(() => screen.getByTestId(testIds.auth.login.button)));
};

export const enterOTP = async (otp = "1234") => {
  const [digit1, digit2, digit3, digit4] = otp.split("");
  const inputs = await waitFor(() => screen.getByTestId(testIds.auth.otp.container).querySelectorAll("input"));
  fireEvent.change(inputs[0], { target: { value: digit1 } });
  fireEvent.change(inputs[1], { target: { value: digit2 } });
  fireEvent.change(inputs[2], { target: { value: digit3 } });
  fireEvent.change(inputs[3], { target: { value: digit4 } });
};

export const submitOTP = async () => {
  fireEvent.click(await waitFor(() => screen.getByTestId(testIds.auth.otp.button)));
};

export const proceedWithWelcome = async () => {
  fireEvent.click(await waitFor(() => screen.getByTestId(testIds.auth.welcome.button)));
};

export const authenticate = async () => {
  await enterMobileNumber();
  await submitLogin();
  await isOpen(testIds.auth.otp.sheet);
  await enterOTP();
  await submitOTP();
};
