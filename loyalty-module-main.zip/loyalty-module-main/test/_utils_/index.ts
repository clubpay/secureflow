import { fireEvent, screen, waitFor } from "@testing-library/react";
import { expect } from "vitest";
import { TriggerType } from "@/types";
import { testIds } from "../_ids_";

export * from "./auth";

type OpenCloseAttribute = string | (() => HTMLElement | Promise<HTMLElement>);

export const isOpen = (testId: OpenCloseAttribute) => {
  return waitFor(async () =>
    expect(
      (typeof testId === "function" ? await testId() : screen.getByTestId(testId))?.getAttribute("data-open")
    ).toBe("true")
  );
};

export const isClosed = async (testId: OpenCloseAttribute) => {
  expect(typeof testId === "function" ? await testId() : screen.queryByTestId(testId)).toBeNull;
};

export const clickTrigger = async (type = TriggerType.Offer) => {
  fireEvent.click(await waitFor(() => screen.getByTestId(testIds.trigger[type])));
};
