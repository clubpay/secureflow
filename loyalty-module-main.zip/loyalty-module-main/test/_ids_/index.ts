import { testIds as authMobile } from "@/components/Auth/Login";
import { testIds as authOTP } from "@/components/Auth/OTP";
import { testIds as authWelcome } from "@/components/Auth/Welcome";
import { popupTestIds as popup } from "@/components/Common/Popup";
import { testIds as earn } from "@/components/Earn";
import { testIds as earnedPoints } from "@/components/EarnedPoints";
import { testIds as offerDetails } from "@/components/Offers/Details";
import { testIds as offerInventory } from "@/components/Offers/Inventory";
import { testIds as redemptionCheckout } from "@/components/Redemption/Checkout";
import { testIds as redemptionDetails } from "@/components/Redemption/Details";
import { testIds as walletDefault } from "@/components/Wallet/Default";
import { testIds as walletBalance } from "@/components/WalletBalance";
import { dialogTestIds as dialog } from "@/providers/dialog";
import { TriggerType } from "@/types";

export const testIds = {
  earn,
  earnedPoints,
  auth: {
    login: authMobile,
    otp: authOTP,
    welcome: authWelcome
  },
  offers: {
    details: offerDetails,
    inventory: offerInventory
  },
  dialog,
  popup,
  trigger: {
    [TriggerType.Redemption]: `${TriggerType.Redemption}-trigger`,
    [TriggerType.Offer]: `${TriggerType.Offer}-trigger`
  },
  redemption: {
    checkout: redemptionCheckout,
    details: redemptionDetails
  },
  wallet: {
    default: {
      ...walletDefault,
      balance: walletBalance
    }
  }
};
