import { default as tsconfigPaths } from "vite-tsconfig-paths";
import { defineConfig } from "vitest/config";

export default defineConfig({
  plugins: [tsconfigPaths() as any],
  optimizeDeps: {
    include: ["@clubpay/customer-common-module"]
  },
  test: {
    environment: "happy-dom",
    setupFiles: ["./test/_mocks_/index.ts"]
  }
});
