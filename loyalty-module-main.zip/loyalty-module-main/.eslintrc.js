module.exports = {
  env: {
    browser: true,
    node: true,
    es2022: true
  },
  extends: ["plugin:storybook/recommended", "plugin:@typescript-eslint/recommended"],
  ignorePatterns: ["vite.config.ts"],
  parserOptions: {
    ecmaFeatures: {
      jsx: true
    },
    parser: "@typescript-eslint/parser",
    ecmaVersion: "latest",
    sourceType: "module"
  },
  settings: {
    react: {
      version: "18.0"
    }
  },
  plugins: ["@typescript-eslint", "react", "react-hooks"],
  rules: {
    "@typescript-eslint/ban-types": "off",
    "@typescript-eslint/no-explicit-any": "off",
    "@typescript-eslint/ban-ts-comment": "off",
    "no-console": "warn"
  }
};
