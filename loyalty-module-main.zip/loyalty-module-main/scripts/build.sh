rm -rf dist && cp -r src dist

for module in $(find dist -type f -name "*.module.scss"); do
   echo "@import \"@/styles/index.scss\";
   
$(cat $module)" > $module
done

rm -rf dist/stories && bun run --bun tsc-alias