import { sessionLoginKey } from "@/constants/auth";
import { constructPayload } from "@/transformers";
import {
  ILoginResponse,
  IProfileDetails,
  IProfileResponse,
  IRegisterResponse,
  IVerifyResponse,
  LoyaltyService
} from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";
import { IRestaurant } from "@clubpay/customer-common-module/src/repository/vendor";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { qlubSessionStorage } from "@clubpay/customer-common-module/src/service/storage/sessionStorage";
import { default as axiosInstance, clearSession } from "./core";
import { default as endpoints } from "./core/endpoints";
import { constructPath, saveTokens } from "./utils";

export default class AuthAPIManager {
  private static instance: AuthAPIManager;

  public static getInstance() {
    if (!this.instance) {
      this.instance = new AuthAPIManager();
    }
    return this.instance;
  }

  public login = (
    vendor: IRestaurant,
    program: ILoyaltyProgram,
    customer: Partial<IProfileDetails>,
    fresh?: boolean,
    skipOtp?: boolean
  ) => {
    return axiosInstance
      .Post<ILoginResponse>(
        constructPath(endpoints.login, program, vendor),
        constructPayload(customer, { fresh, skipOtp }, vendor)
      )
      .then((res) => {
        if (program.config.apiVersion === 2) {
          if (fresh || program.type === LoyaltyService.Rotana) {
            qlubSessionStorage.set(sessionLoginKey(program.type), "true");
          }
          saveTokens(res.data.tokens);
        }
        return res.data;
      });
  };

  public verify = (
    vendor: IRestaurant,
    program: ILoyaltyProgram,
    customer: Partial<IProfileDetails>,
    otp: string,
    otpId?: string,
    isNewUser: boolean = false
  ) => {
    return axiosInstance
      .Post<IVerifyResponse>(
        constructPath(endpoints.verify, program, vendor),
        constructPayload(customer, { otp, otpId, isNewUser }, vendor)
      )
      .then((res) => {
        if (program.config.apiVersion === 2) {
          qlubSessionStorage.set(sessionLoginKey(program.type), "true");
        }
        return res.data;
      });
  };

  public getProfile = (vendor: IRestaurant, program: ILoyaltyProgram, customer: Partial<IProfileDetails>) => {
    return axiosInstance
      .Post<IProfileResponse>(
        constructPath(endpoints.profile, program, vendor),
        constructPayload(customer, undefined, vendor)
      )
      .then((res) => res.data?.profile);
  };

  public register = (vendor: IRestaurant, program: ILoyaltyProgram, data: Record<string, any>) => {
    return axiosInstance
      .Post<IRegisterResponse>(
        constructPath(endpoints.register, program, vendor),
        constructPayload(data, undefined, vendor)
      )
      .then((res) => res.data?.profile);
  };

  public logout = (vendor: IRestaurant, program: ILoyaltyProgram) => {
    clearSession();
    qlubSessionStorage.remove(sessionLoginKey(program.id));
    return axiosInstance.Post(constructPath(endpoints.logout, program, vendor), {
      id: getSession()
    });
  };
}
