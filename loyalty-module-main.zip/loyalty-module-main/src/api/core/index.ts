import { default as axios } from "axios";
import { hdrLoyaltyAuth, sessionAccessToken, sessionRefreshToken } from "@/constants";
import { authSessionKey } from "@/store/auth";
import { default as axiosInstance } from "@clubpay/customer-common-module/src/repository/axios";
import { qlubLocalStorage } from "@clubpay/customer-common-module/src/service/storage/localStorage";
import { saveTokens } from "../utils";
import { basePrefix, default as endpoints } from "./endpoints";

export const clearSession = () => {
  [sessionAccessToken, sessionRefreshToken].forEach((k) => qlubLocalStorage.remove(k));
};

axiosInstance.axios.interceptors.request.use((config) => {
  if (!(config as any).unauthenticated) {
    config.headers![hdrLoyaltyAuth] = qlubLocalStorage.get(sessionAccessToken) as string;
  }
  return config;
});

axiosInstance.axios.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (
      error?.response?.status === 401 &&
      !error.config.url.includes("refresh-token") &&
      !error.config.__retry &&
      qlubLocalStorage.get(sessionAccessToken) &&
      Object.keys(qlubLocalStorage.getAll()).some((key) => key.startsWith(authSessionKey))
    ) {
      try {
        const pattern = /^\/([^/]+)\/([^/]+)\/([^/]+)\/(.+)$/;
        const match = error.config.url.replace(basePrefix, "").match(pattern);
        const [, countryCode, restaurantUnique, program] = match;
        error.config.__retry = true;
        const response = await axiosInstance.axios.post(
          endpoints.refreshToken
            .replace(":program", program)
            .replace(":countryCode", countryCode)
            .replace(":restaurantUnique", restaurantUnique),
          {
            token: qlubLocalStorage.get(sessionRefreshToken)
          }
        );
        saveTokens(response.data);
        error.config.headers[hdrLoyaltyAuth] = response.data?.accessToken;
        return axios(error.config);
      } catch (refreshError) {
        clearSession();
        for (const key in localStorage) {
          if (key.startsWith(authSessionKey)) {
            qlubLocalStorage.remove(key);
          }
        }
        throw refreshError;
      }
    }
    return Promise.reject(error?.response);
  }
);

export default axiosInstance;
