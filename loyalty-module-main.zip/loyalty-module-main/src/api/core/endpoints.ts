export const basePrefix = "/loyalty";

export const extendedPrefix = `${basePrefix}/:countryCode/:restaurantUnique/:program`;

const endpoints = {
  login: `${extendedPrefix}/auth/login`,
  verify: `${extendedPrefix}/auth/login/verify`,
  logout: `${extendedPrefix}/auth/logout`,
  profile: `${extendedPrefix}/auth/profile`,
  refreshToken: `${extendedPrefix}/auth/refresh-token`,
  redeem: `${extendedPrefix}/points/burn`,
  earn: `${extendedPrefix}/points/earn`,
  getOffers: `${extendedPrefix}/offers`,
  applyOffers: `${extendedPrefix}/offers/apply`,
  getRestaurantLoyaltyPrograms: `${basePrefix}/:countryCode/:restaurantUnique/programs`,
  getCountryLoyaltyProgram: `${basePrefix}/:countryCode/program`,
  getProgramVenues: `${basePrefix}/:countryCode/:restaurantUnique/programs/:programId/venues`,
  getDiscoveryPageResults: `${basePrefix}/programs/:programId/discovery`,
  getTransactions: `${basePrefix}/customer/transactions/:customerId`,
  register: `${extendedPrefix}/auth/register`,
  enrollForSubscription: `${basePrefix}/subscription/:subscriptionId/enroll`,
  cancelSubscription: `${basePrefix}/subscription/:subscriptionId/cancel`,
  getSubscriptionDiscount: `${basePrefix}/subscription/discount`
};

export default endpoints;
