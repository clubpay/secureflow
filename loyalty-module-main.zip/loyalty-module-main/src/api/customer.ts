import { ICustomerTransactionsResponse } from "@/types";
import { default as axiosInstance } from "./core";
import { default as endpoints } from "./core/endpoints";

export default class CustomerAPIManager {
  private static instance: CustomerAPIManager;

  public static getInstance() {
    if (!this.instance) {
      this.instance = new CustomerAPIManager();
    }
    return this.instance;
  }

  public getTransactions = (customerId: string, data?: Record<string, any>) => {
    return axiosInstance
      .Post<ICustomerTransactionsResponse>(endpoints.getTransactions.replace(":customerId", customerId), {
        loyaltyPayload: data
      })
      .then((res) => ({
        count: res.data.count || 0,
        transfers: res.data.transfers || []
      }));
  };
}
