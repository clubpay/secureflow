import { AxiosResponse } from "axios";
import { getInternalProgramType } from "@/transformers";
import { IProgramVenuesResponse, IRestaurantLoyaltyProgramsResponse } from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";
import { default as axiosInstance } from "./core";
import { default as endpoints } from "./core/endpoints";

export default class ProgramAPIManager {
  private static instance: ProgramAPIManager;

  public static getInstance() {
    if (!this.instance) {
      this.instance = new ProgramAPIManager();
    }
    return this.instance;
  }

  public getRestaurantLoyaltyPrograms = (restaurantUnique: string, countryCode: string) => {
    return axiosInstance
      .Get<IRestaurantLoyaltyProgramsResponse>(
        endpoints.getRestaurantLoyaltyPrograms
          .replace(":countryCode", countryCode)
          .replace(":restaurantUnique", restaurantUnique) + "?enabled=true"
      )
      .then((res) => res.data?.programs);
  };

  public getCountryLoyaltyProgram = (countryCode: string) => {
    return axiosInstance
      .Get<ILoyaltyProgram>(endpoints.getCountryLoyaltyProgram.replace(":countryCode", countryCode))
      .then((res) => res.data);
  };

  public getProgramVenues = (
    restaurantUnique: string,
    countryCode: string,
    programId: string,
    search?: string,
    page?: number,
    limit?: number
  ) => {
    return axiosInstance
      .Get<IProgramVenuesResponse>(
        endpoints.getProgramVenues
          .replace(":countryCode", countryCode)
          .replace(":restaurantUnique", restaurantUnique)
          .replace(":programId", programId),
        {
          params: {
            ...(search ? { search } : {}),
            ...(page ? { page } : {}),
            ...(limit ? { limit } : {})
          }
        }
      )
      .then(this.formatVenues);
  };

  public getDiscoveryPageResults = (programId: string, search?: string, page?: number, limit?: number) => {
    return axiosInstance
      .Get<IProgramVenuesResponse>(endpoints.getDiscoveryPageResults.replace(":programId", programId), {
        params: {
          ...(search ? { search } : {}),
          ...(page ? { page } : {}),
          ...(limit ? { limit } : {})
        }
      })
      .then(this.formatVenues);
  };

  public formatVenues(response: AxiosResponse<IProgramVenuesResponse, any>) {
    const raw = response.data.rows || [];
    const formatted = raw.map((venue) => ({
      ...venue,
      internalProgramType: getInternalProgramType(
        !!venue.subscription?.options?.isActive,
        venue.config.isEarnEnabled || venue.config.isBurnEnabled
      )
    }));
    return {
      rows: formatted,
      count: response.data.count || 0
    };
  }
}
