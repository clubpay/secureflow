import { IGetLoyaltySubscriptionDiscountResponse } from "@/types";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { default as axiosInstance } from "./core";
import { default as endpoints } from "./core/endpoints";

export default class SubscriptionAPIManager {
  private static instance: SubscriptionAPIManager;

  public static getInstance() {
    if (!this.instance) {
      this.instance = new SubscriptionAPIManager();
    }
    return this.instance;
  }

  public enroll = (subscriptionId: number, dsi: string) => {
    return axiosInstance
      .Post<any>(endpoints.enrollForSubscription.replace(":subscriptionId", subscriptionId.toString()), {
        id: getSession(),
        dineSessionID: dsi
      })
      .then((res) => res.data);
  };

  public cancel = (subscriptionId: number, dsi: string) => {
    return axiosInstance
      .Post<any>(endpoints.cancelSubscription.replace(":subscriptionId", subscriptionId.toString()), {
        id: getSession(),
        dineSessionID: dsi
      })
      .then((res) => res.data);
  };

  public clean = (subscriptionId: number, data: Record<string, any>) => {
    return axiosInstance
      .Post<any>(endpoints.cancelSubscription.replace(":subscriptionId", subscriptionId.toString()), {
        ...data,
        isSubscribed: true
      })
      .then((res) => res.data);
  };

  public getDiscount = (dsi: string) => {
    return axiosInstance
      .Get<IGetLoyaltySubscriptionDiscountResponse>(endpoints.getSubscriptionDiscount, {
        params: {
          id: getSession(),
          dineSessionID: dsi
        }
      })
      .then((res) => res.data);
  };
}
