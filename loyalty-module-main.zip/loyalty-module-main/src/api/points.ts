import { constructPayload } from "@/transformers";
import { IEarnResponse, IProfileDetails, IRedeemRequest, IRedeemResponse } from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";
import { IRestaurant } from "@clubpay/customer-common-module/src/repository/vendor";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { default as axiosInstance } from "./core";
import { default as endpoints } from "./core/endpoints";
import { constructPath } from "./utils";

export default class PointAPIManager {
  private static instance: PointAPIManager;

  public static getInstance() {
    if (!this.instance) {
      this.instance = new PointAPIManager();
    }
    return this.instance;
  }

  public burn = (
    vendor: IRestaurant,
    program: ILoyaltyProgram,
    payload: IRedeemRequest,
    customer: Partial<IProfileDetails>
  ) => {
    return axiosInstance
      .Post<IRedeemResponse>(
        constructPath(endpoints.redeem, program, vendor),
        constructPayload(customer, payload, vendor)
      )
      .then((res) => res.data);
  };

  public earn = (dsi: string, vendor: IRestaurant, program: ILoyaltyProgram, mobile: string) => {
    return axiosInstance
      .Post<IEarnResponse>(
        constructPath(endpoints.earn, program, vendor),
        {
          id: getSession(),
          dineSessionID: dsi,
          loyaltyPayload: {
            customer: {
              mobile,
              phone: mobile
            },
            restaurant: {
              name: vendor?.name
            }
          }
        },
        { unauthenticated: true } as any
      )
      .then((res) => res.data);
  };
}
