import AuthAPIManager from "./auth";
import CustomerAPIManager from "./customer";
import OfferAPIManager from "./offer";
import PointAPIManager from "./points";
import ProgramAPIManager from "./program";
import SubscriptionAPIManager from "./subscription";

export default class APIManager {
  public auth = AuthAPIManager.getInstance();

  public offer = OfferAPIManager.getInstance();

  public points = PointAPIManager.getInstance();

  public program = ProgramAPIManager.getInstance();

  public customer = CustomerAPIManager.getInstance();

  public subscription = SubscriptionAPIManager.getInstance();

  private static instance: APIManager;

  public static getInstance() {
    if (!this.instance) {
      this.instance = new APIManager();
    }
    return this.instance;
  }
}
