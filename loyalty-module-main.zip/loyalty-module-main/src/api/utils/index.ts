import { sessionAccessToken, sessionRefreshToken } from "@/constants";
import { LoyaltyService } from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";
import { IRestaurant } from "@clubpay/customer-common-module/src/repository/vendor";
import { qlubLocalStorage } from "@clubpay/customer-common-module/src/service/storage/localStorage";

export const saveTokens = (tokens: any) => {
  qlubLocalStorage.set(sessionAccessToken, tokens?.accessToken);
  qlubLocalStorage.set(sessionRefreshToken, tokens?.refreshToken);
};

const constructProgram = (program: ILoyaltyProgram) => {
  if (program.id === LoyaltyService.Como) {
    return `${program.id}V2`;
  }
  return program.id;
};

export const constructPath = (endpoint: string, program: ILoyaltyProgram, vendor: IRestaurant) => {
  const p =
    endpoint
      .replace(":program", constructProgram(program))
      .replace(":countryCode", vendor.country.code)
      .replace(":restaurantUnique", vendor.unique) +
    `?version=${program.config.apiVersion}` +
    `&type=${program.type}`;
  return p;
};
