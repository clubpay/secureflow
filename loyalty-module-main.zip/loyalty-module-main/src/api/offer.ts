import { constructPayload } from "@/transformers";
import { IGetOffersResponse, IPaymentDetailsResponse, IProfileDetails } from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";
import { IRestaurant } from "@clubpay/customer-common-module/src/repository/vendor";
import { default as axiosInstance } from "./core";
import { default as endpoints } from "./core/endpoints";
import { constructPath } from "./utils";

export default class OfferAPIManager {
  private static instance: OfferAPIManager;

  public static getInstance() {
    if (!this.instance) {
      this.instance = new OfferAPIManager();
    }
    return this.instance;
  }

  public getAll = (vendor: IRestaurant, program: ILoyaltyProgram, customer: Partial<IProfileDetails>) => {
    return axiosInstance
      .Post<IGetOffersResponse>(
        constructPath(endpoints.getOffers, program, vendor),
        constructPayload(customer, undefined, vendor)
      )
      .then((res) => res.data);
  };

  public apply = (
    vendor: IRestaurant,
    program: ILoyaltyProgram,
    offers: string[],
    customer: Partial<IProfileDetails>
  ) => {
    return axiosInstance
      .Post<IPaymentDetailsResponse>(
        constructPath(endpoints.applyOffers, program, vendor),
        constructPayload(customer, { offers }, vendor)
      )
      .then((res) => res.data);
  };
}
