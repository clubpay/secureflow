import { KeyValue } from "@/types";
import { insertJSX, replaceKeys } from "@/utils";
import ar from "./ar.json";
import es from "./es.json";
import hk from "./hk.json";
import ja from "./ja.json";
import ko from "./ko.json";
import pt from "./pt.json";
import ru from "./ru.json";
import tr from "./tr.json";
import zh from "./zh.json";

let loadedTranslations: KeyValue = {};

const browserLanguage = typeof window !== "undefined" ? navigator.language.split("-")[0] : "en";

let loadedLocale = browserLanguage;

export const translations = {
  ar,
  es,
  ja,
  pt,
  tr,
  zh,
  hk,
  ko,
  ru
};

export const load = async (locale?: string): Promise<string> => {
  locale ??= browserLanguage;
  // @ts-ignore
  loadedTranslations = translations[locale] ?? {};
  loadedLocale = locale;
  return locale;
};

export const t = (key: string, replacements?: Record<string, any>): any => {
  const lang = new URLSearchParams(window.location.search).get("lang") || loadedLocale;
  if (loadedLocale !== lang) load(lang);
  if (Object.keys(loadedTranslations).length > 0) key = loadedTranslations[key] ?? key;
  if (replacements) {
    if (Object.values(replacements).some((value) => typeof value === "object")) {
      return insertJSX(key, replacements);
    }
    return replaceKeys(key, replacements);
  }
  return key;
};

load();
