import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { default as Trigger } from "@/components/Trigger";
import { useAuthStore } from "@/store/auth";
import { IRedemptionOptions, LoyaltyService } from "@/types";
import { mockLoyaltyProgram, mockUser } from "../../../../../test/_mocks_";

const meta: Meta<typeof Trigger> = {
  title: "Sheets/Rotana/Redemption",
  component: Trigger,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;

type Story = StoryObj<typeof Trigger>;

const getCommonProps = (props: IRedemptionOptions) => ({
  bill: {
    amount: props.bill?.amount ?? 100,
    share: props.bill?.share ?? 50,
    tax: props.bill?.tax ?? 10
  },
  meta: {
    restaurantLogoUrl:
      props.meta?.restaurantLogoUrl ?? "https://i.ibb.co/ZX9T8X7/285372235-587ca6d8-71e2-4b7b-bd19-3e2e06fc3f9c.png",
    restaurantLogoAvatarUrl: props.meta?.restaurantLogoAvatarUrl ?? "https://i.ibb.co/LRfVNPV/image-51.png"
  }
});

export const Default: Story = {
  render: (props: any) => {
    const setUser = useAuthStore((state) => state.setUser);
    const [redeemed, setRedeemed] = useState<boolean>(false);
    const [points, setPoints] = useState<number | undefined>(undefined);
    return (
      <Trigger
        {...props}
        {...getCommonProps(props)}
        program={mockLoyaltyProgram}
        config={{
          redemption: {
            amount: props.config?.redemption?.amount,
            points: props.config?.redemption?.points ?? points,
            pointIdentifier: props.config?.redemption?.pointIdentifier ?? "Rotana",
            completed: props.config?.redemption?.completed ?? redeemed
          },
          events: {
            onLogin: async () => {
              setUser(LoyaltyService.Rotana, mockUser);
            },
            onRedemption: async ({ points }) => {
              setRedeemed(true);
              if (points) setPoints(points);
            }
          },
          conversionRate: props.config?.conversionRate ?? 3
        }}
      />
    );
  }
};

export const WithOffers: Story = {
  render: (props: any) => {
    const setUser = useAuthStore((state) => state.setUser);
    const [redeemed, setRedeemed] = useState<boolean>(false);
    const [points, setPoints] = useState<number | undefined>(undefined);
    return (
      <Trigger
        {...props}
        {...getCommonProps(props)}
        program={mockLoyaltyProgram}
        config={{
          redemption: {
            amount: props.config?.redemption?.amount,
            points: props.config?.redemption?.points ?? points,
            pointIdentifier: props.config?.redemption?.pointIdentifier ?? "Rotana",
            completed: props.config?.redemption?.completed ?? redeemed
          },
          events: {
            onLogin: async () => {
              setUser(LoyaltyService.Rotana, mockUser);
            },
            onRedemption: async ({ points }) => {
              setRedeemed(true);
              if (points) setPoints(points);
            }
          },
          conversionRate: props.config?.conversionRate ?? 3
        }}
      />
    );
  }
};
