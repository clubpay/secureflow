import { useEffect } from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { default as Trigger } from "@/components/Trigger";
import WalletFunctionSheet from "@/components/WalletFunctions";
import { useWalletStore } from "@/store/wallet";
import { LoyaltyService } from "@/types";
import { mockLoyaltyProgram } from "../../../../../test/_mocks_";

const meta: Meta<typeof Trigger> = {
  title: "Sheets/Qlub/Wallet Functions",
  component: Trigger,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;

type Story = StoryObj<typeof Trigger>;

export const Legacy: Story = {
  render: () => {
    useEffect(() => {
      useWalletStore.getState().openFunctionSheet(true);
    }, []);
    return (
      <WalletFunctionSheet program={{ ...mockLoyaltyProgram, id: LoyaltyService.Qlub, type: LoyaltyService.Qlub }} />
    );
  }
};

export const Latest: Story = {
  render: () => {
    useEffect(() => {
      useWalletStore.getState().openFunctionSheet(true);
    }, []);
    return (
      <WalletFunctionSheet
        program={{
          ...mockLoyaltyProgram,
          config: {
            ...mockLoyaltyProgram.config,
            displayLoyaltyBenefits: true
          },
          id: LoyaltyService.Qlub,
          type: LoyaltyService.Qlub
        }}
      />
    );
  }
};
