import type { Meta, StoryObj } from "@storybook/react";
import { default as Trigger } from "@/components/Trigger";
import { useAuthStore } from "@/store/auth";
import { IRedemptionOptions, LoyaltyService } from "@/types";
import { mockLoyaltyProgram, mockUser } from "../../../../../test/_mocks_";

const meta: Meta<typeof Trigger> = {
  title: "Sheets/Qlub/Login",
  component: Trigger,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;

type Story = StoryObj<typeof Trigger>;

const getCommonProps = (props: IRedemptionOptions) => ({
  meta: {
    restaurantLogoUrl: props.meta?.restaurantLogoUrl ?? "https://i.ibb.co/HPgmTyN/Layer-1.png",
    restaurantLogoAvatarUrl: props.meta?.restaurantLogoAvatarUrl ?? "https://i.ibb.co/HPgmTyN/Layer-1.png"
  }
});

export const Default: Story = {
  render: (props: any) => {
    const setUser = useAuthStore((state) => state.setUser);
    return (
      <Trigger
        {...props}
        {...getCommonProps(props)}
        config={{
          events: {
            onLogin: async () => {
              return { isNewUser: true };
            },
            onLoginVerification: async () => {
              setUser(mockLoyaltyProgram.id, mockUser);
              return true;
            }
          },
          conversionRate: props.config?.conversionRate ?? 5
        }}
        program={{ ...mockLoyaltyProgram, id: LoyaltyService.Qlub, type: LoyaltyService.Qlub }}
      />
    );
  }
};
