import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { default as Trigger } from "@/components/Trigger";
import { useAuthStore } from "@/store/auth";
import { IRedemptionOptions, LoyaltyService } from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";

const meta: Meta<typeof Trigger> = {
  title: "Sheets/Como/Redemption",
  component: Trigger,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;

type Story = StoryObj<typeof Trigger>;

const getCommonProps = (props: IRedemptionOptions) => ({
  bill: {
    amount: props.bill?.amount ?? 100,
    share: props.bill?.share ?? 50,
    tax: props.bill?.tax ?? 10
  },
  meta: {
    restaurantLogoUrl:
      props.meta?.restaurantLogoUrl ?? "https://i.ibb.co/ZX9T8X7/285372235-587ca6d8-71e2-4b7b-bd19-3e2e06fc3f9c.png",
    restaurantLogoAvatarUrl: props.meta?.restaurantLogoAvatarUrl ?? "https://i.ibb.co/LRfVNPV/image-51.png"
  }
});

const constructDefaultUser = () => ({
  id: "1",
  name: "Akalanka Perera",
  phoneNumber: "+94771234567",
  email: "akalanka@qlub.io",
  accountBalance: {
    monetary: 4.5,
    nonMonetary: 4.5
  },
  conversionRate: 1,
  accountNumber: "1190152117497",
  status: "active",
  createdOn: new Date().toISOString()
});

export const Alfaco: Story = {
  render: (props: any) => {
    const setUser = useAuthStore((state) => state.setUser);
    const [redeemed, setRedeemed] = useState<boolean>(false);
    const [points, setPoints] = useState<number | undefined>(undefined);
    return (
      <Trigger
        {...props}
        {...getCommonProps(props)}
        program={{ id: LoyaltyService.Como, type: LoyaltyService.Como } as ILoyaltyProgram}
        config={{
          redemption: {
            amount: props.config?.redemption?.amount,
            points: props.config?.redemption?.points ?? points,
            pointIdentifier: props.config?.redemption?.pointIdentifier ?? "Alfaco",
            completed: props.config?.redemption?.completed ?? redeemed
          },
          events: {
            onLogin: async () => {
              return { isNewUser: true };
            },
            onLoginVerification: async () => {
              setUser(LoyaltyService.Como, constructDefaultUser());
              return true;
            },
            onRedemption: async ({ points }) => {
              setRedeemed(true);
              if (points) setPoints(points);
            }
          },
          conversionRate: props.config?.conversionRate ?? 5,
          ui: {
            ...props.config?.ui
          }
        }}
      />
    );
  }
};

export const LowBalance: Story = {
  render: (props: any) => {
    const setUser = useAuthStore((state) => state.setUser);
    const [redeemed, setRedeemed] = useState<boolean>(false);
    const [points, setPoints] = useState<number>(5);
    return (
      <Trigger
        {...props}
        {...getCommonProps(props)}
        program={{ id: LoyaltyService.Como, type: LoyaltyService.Como } as ILoyaltyProgram}
        config={{
          redemption: {
            amount: props.config?.redemption?.amount ?? 20,
            points: props.config?.redemption?.points ?? points,
            pointIdentifier: props.config?.redemption?.pointIdentifier ?? "Alfaco",
            completed: props.config?.redemption?.completed ?? redeemed
          },
          events: {
            onLoginVerification: async () => {
              setUser(LoyaltyService.Como, {
                ...constructDefaultUser(),
                accountBalance: {
                  nonMonetary: 0,
                  monetary: 0
                }
              });
              return true;
            },
            onRedemption: async ({ points }) => {
              setRedeemed(true);
              if (points) setPoints(points);
            }
          },
          conversionRate: props.config?.conversionRate ?? 5
        }}
      />
    );
  }
};

export const LowMinimum: Story = {
  render: (props: any) => {
    const setUser = useAuthStore((state) => state.setUser);
    const [redeemed, setRedeemed] = useState<boolean>(false);
    const [points, setPoints] = useState<number>(5);
    return (
      <Trigger
        {...props}
        {...getCommonProps(props)}
        program={{ id: LoyaltyService.Como, type: LoyaltyService.Como } as ILoyaltyProgram}
        config={{
          redemption: {
            amount: props.config?.redemption?.amount ?? 20,
            points: props.config?.redemption?.points ?? points,
            pointIdentifier: props.config?.redemption?.pointIdentifier ?? "Alfaco",
            completed: props.config?.redemption?.completed ?? redeemed
          },
          events: {
            onLoginVerification: async () => {
              setUser(LoyaltyService.Como, {
                ...constructDefaultUser(),
                accountBalance: {
                  monetary: 500,
                  nonMonetary: 500
                }
              });
              return true;
            },
            onRedemption: async ({ points }) => {
              setRedeemed(true);
              if (points) setPoints(points);
            }
          },
          conversionRate: props.config?.conversionRate ?? 5
        }}
      />
    );
  }
};

export const WithConfirmation: Story = {
  render: (props: any) => {
    const setUser = useAuthStore((state) => state.setUser);
    const [redeemed, setRedeemed] = useState<boolean>(false);
    const [points, setPoints] = useState<number | undefined>(undefined);
    return (
      <Trigger
        {...props}
        {...getCommonProps(props)}
        program={
          {
            id: LoyaltyService.Como,
            type: LoyaltyService.Como,
            config: {
              redemptionConfirmationPopup: true
            }
          } as ILoyaltyProgram
        }
        config={{
          redemption: {
            amount: props.config?.redemption?.amount,
            points: props.config?.redemption?.points ?? points,
            pointIdentifier: props.config?.redemption?.pointIdentifier ?? "Alfaco",
            completed: props.config?.redemption?.completed ?? redeemed
          },
          events: {
            onLoginVerification: async () => {
              setUser(LoyaltyService.Como, constructDefaultUser());
              return true;
            },
            onRedemption: async ({ points }) => {
              setRedeemed(true);
              if (points) setPoints(points);
            }
          },
          conversionRate: props.config?.conversionRate ?? 5
        }}
      />
    );
  }
};

export const WithRegistration: Story = {
  render: (props: any) => {
    const setUser = useAuthStore((state) => state.setUser);
    const [redeemed, setRedeemed] = useState<boolean>(false);
    const [points, setPoints] = useState<number | undefined>(undefined);
    return (
      <Trigger
        {...props}
        {...getCommonProps(props)}
        program={
          {
            id: LoyaltyService.Como,
            type: LoyaltyService.Como,
            config: {
              registrationFields: ["firstName", "lastName", "email", "birthday", "gender"],
              enableRegistrationFlow: true
            }
          } as ILoyaltyProgram
        }
        config={{
          redemption: {
            amount: props.config?.redemption?.amount,
            points: props.config?.redemption?.points ?? points,
            pointIdentifier: props.config?.redemption?.pointIdentifier ?? "Alfaco",
            completed: props.config?.redemption?.completed ?? redeemed
          },
          events: {
            onLogin: async () => {
              return {
                isNewUser: true
              };
            },
            onLoginVerification: async () => {
              return true;
            },
            onRegister: async () => {
              setUser(LoyaltyService.Como, constructDefaultUser());
            },
            onRedemption: async ({ points }) => {
              setRedeemed(true);
              if (points) setPoints(points);
            }
          },
          conversionRate: props.config?.conversionRate ?? 5
        }}
      />
    );
  }
};
