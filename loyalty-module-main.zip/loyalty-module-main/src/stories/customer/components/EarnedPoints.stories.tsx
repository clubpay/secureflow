import type { Meta, StoryObj } from "@storybook/react";
import { default as EarnedPoints } from "@/components/EarnedPoints";
import { mockLoyaltyProgram } from "../../../../test/_mocks_";

const meta: Meta<typeof EarnedPoints> = {
  title: "Components/Customer/Earned Points",
  component: EarnedPoints,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;

type Story = StoryObj<typeof EarnedPoints>;

export const WithActionButton: Story = {
  render: (props) => {
    return (
      <div style={{ minWidth: "40vw" }}>
        <EarnedPoints
          {...props}
          program={mockLoyaltyProgram}
          amount={props.amount ?? 300}
          currencyFormat={{
            cc: props.currencyFormat?.cc ?? "ae",
            cs: props.currencyFormat?.cs ?? "AED",
            currencyPrecision: props.currencyFormat?.currencyPrecision ?? 2,
            currencyCommaSeparator: props.currencyFormat?.currencyCommaSeparator ?? "disable"
          }}
        />
      </div>
    );
  }
};

export const WithoutActionButton: Story = {
  render: (props) => {
    return (
      <div style={{ minWidth: "40vw" }}>
        <EarnedPoints {...props} program={mockLoyaltyProgram} amount={props.amount ?? 300} hideAction />
      </div>
    );
  }
};
