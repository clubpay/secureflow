import type { Meta, StoryObj } from "@storybook/react";
import { VenueCard } from "@/components/Venue";

const meta: Meta<typeof VenueCard> = {
  title: "Components/Customer/Venue",
  component: VenueCard,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;

type Story = StoryObj<typeof VenueCard>;

export const Default: Story = {
  render: () => {
    return (
      <div style={{ width: "600px" }}>
        <VenueCard
          venue={{
            name: "Venue Name",
            email: "a@gmail.com",
            logoBigUrl: "https://via.placeholder.com/150",
            logoSmallUrl: "https://via.placeholder.com/150",
            title: "Venue Title",
            address1: "Address 1",
            address2: "Address 2",
            city: "City",
            photoUrl: "https://via.placeholder.com/150",
            earnEnabled: true,
            burnEnabled: true,
            code: "VENUE_CODE",
            reviewRating: 4.5,
            country: {
              code: "ae"
            },
            currency: {
              precision: 2,
              symbol: "AED"
            },
            config: {
              isEarnEnabled: true,
              isBurnEnabled: true,
              earnPointConversionRate: 1,
              burnPointConversionRate: 1,
              minPointsPerTransaction: 1,
              maxPointsPerTransaction: 100,
              redeemableBillPercentage: 50,
              pointExpiryDuration: 1
            },
            googlePlaceId: "ChIJXanMdwBpXj4RH-ZfWpcf6kg"
          }}
          locale="en"
          getLocaleText={(key) => key}
        />
      </div>
    );
  }
};
