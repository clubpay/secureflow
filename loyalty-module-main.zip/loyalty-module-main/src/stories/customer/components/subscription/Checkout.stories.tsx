import { Meta } from "@storybook/react";
import { SubscriptionPrompt } from "@/components/Subscription/Checkout";
import { genericProps, mockLoyaltyProgram } from "../../../../../test/_mocks_";

const meta: Meta = {
  title: "Components/Customer/Subscription/Checkout",
  component: SubscriptionPrompt,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;

export const Default = {
  render: () => {
    return <SubscriptionPrompt program={mockLoyaltyProgram} currencyFormat={genericProps.currencyFormat} />;
  }
};
