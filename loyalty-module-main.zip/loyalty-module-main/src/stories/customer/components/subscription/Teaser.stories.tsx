import { Meta } from "@storybook/react";
import { default as SubscriptionTeaser } from "@/components/Wallet/Discount";
import { genericProps, mockLoyaltyProgram } from "../../../../../test/_mocks_";

const meta: Meta = {
  title: "Components/Customer/Subscription/Teaser",
  component: SubscriptionTeaser,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;

export const Default = {
  render: () => {
    return (
      <SubscriptionTeaser program={mockLoyaltyProgram} billAmount={100} currencyFormat={genericProps.currencyFormat} />
    );
  }
};
