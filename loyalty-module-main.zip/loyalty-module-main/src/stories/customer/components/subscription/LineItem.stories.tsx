import { Meta } from "@storybook/react";
import SubscriptionLineItem from "@/components/Subscription/LineItem";
import { genericProps } from "../../../../../test/_mocks_";

const meta: Meta = {
  title: "Components/Customer/Subscription/LineItem",
  component: SubscriptionLineItem,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;

export const Default = {
  render: () => {
    return <SubscriptionLineItem value={100} currencyFormat={genericProps.currencyFormat} />;
  }
};
