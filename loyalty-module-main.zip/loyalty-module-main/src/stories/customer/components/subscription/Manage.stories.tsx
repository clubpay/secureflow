import { Meta } from "@storybook/react";
import ManageSubscription from "@/drivers/customer/Subscription/Manage";

const meta: Meta = {
  title: "Components/Customer/Subscription/Manage",
  component: ManageSubscription,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;

export const Default = {
  render: () => {
    return <ManageSubscription />;
  }
};
