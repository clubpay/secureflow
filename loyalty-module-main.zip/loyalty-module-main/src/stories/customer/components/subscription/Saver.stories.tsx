import { Meta } from "@storybook/react";
import SubscriptionSavings from "@/components/Subscription/Savings";
import { genericProps } from "../../../../../test/_mocks_";

const meta: Meta = {
  title: "Components/Customer/Subscription/Saver",
  component: SubscriptionSavings,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;

export const Default = {
  render: () => {
    return <SubscriptionSavings savings={100} currencyFormat={genericProps.currencyFormat} />;
  }
};
