import type { Meta, StoryObj } from "@storybook/react";
import { default as Wallet, WalletType } from "@/components/Wallet";
import { mockLoyaltyProgram } from "../../../../test/_mocks_";

const meta: Meta<typeof Wallet> = {
  title: "Components/Customer/Wallet",
  component: Wallet,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;

type Story = StoryObj<typeof Wallet>;

export const Teaser: Story = {
  render: (props) => {
    return (
      <Wallet
        {...props}
        type={props.type || WalletType.Teaser}
        billAmount={props.billAmount ?? 100}
        currencyFormat={{
          cc: props.currencyFormat?.cc ?? "ae",
          cs: props.currencyFormat?.cs ?? "AED",
          currencyPrecision: props.currencyFormat?.currencyPrecision ?? 2,
          currencyCommaSeparator: props.currencyFormat?.currencyCommaSeparator ?? "disable"
        }}
        program={mockLoyaltyProgram}
      />
    );
  }
};

export const Detailed: Story = {
  render: (props) => {
    return (
      <Wallet
        {...props}
        type={props.type || WalletType.Detailed}
        program={mockLoyaltyProgram}
        billAmount={props.billAmount ?? 100}
        loading={true}
        currencyFormat={{
          cc: props.currencyFormat?.cc ?? "ae",
          cs: props.currencyFormat?.cs ?? "AED",
          currencyPrecision: props.currencyFormat?.currencyPrecision ?? 2,
          currencyCommaSeparator: props.currencyFormat?.currencyCommaSeparator ?? "disable"
        }}
      />
    );
  }
};

export const DetailedWithoutRedemption: Story = {
  render: (props) => {
    return (
      <Wallet
        {...props}
        type={props.type || WalletType.Detailed}
        program={mockLoyaltyProgram}
        billAmount={props.billAmount ?? 100}
        currencyFormat={{
          cc: props.currencyFormat?.cc ?? "ae",
          cs: props.currencyFormat?.cs ?? "AED",
          currencyPrecision: props.currencyFormat?.currencyPrecision ?? 2,
          currencyCommaSeparator: props.currencyFormat?.currencyCommaSeparator ?? "disable"
        }}
      />
    );
  }
};
export const DetailedWithExpiry: Story = {
  render: (props) => {
    return (
      <Wallet
        {...props}
        type={props.type || WalletType.Detailed}
        program={mockLoyaltyProgram}
        billAmount={props.billAmount ?? 100}
        currencyFormat={{
          cc: props.currencyFormat?.cc ?? "ae",
          cs: props.currencyFormat?.cs ?? "AED",
          currencyPrecision: props.currencyFormat?.currencyPrecision ?? 2,
          currencyCommaSeparator: props.currencyFormat?.currencyCommaSeparator ?? "disable"
        }}
      />
    );
  }
};

export const TeaserWithLinkedSheet: Story = {
  render: (props) => {
    return (
      <>
        <Wallet
          {...props}
          type={props.type || WalletType.Detailed}
          program={mockLoyaltyProgram}
          billAmount={props.billAmount ?? 100}
          currencyFormat={{
            cc: props.currencyFormat?.cc ?? "ae",
            cs: props.currencyFormat?.cs ?? "AED",
            currencyPrecision: props.currencyFormat?.currencyPrecision ?? 2,
            currencyCommaSeparator: props.currencyFormat?.currencyCommaSeparator ?? "disable"
          }}
        />
      </>
    );
  }
};
