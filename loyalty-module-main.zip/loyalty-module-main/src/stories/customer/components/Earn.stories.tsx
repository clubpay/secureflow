import type { Meta, StoryObj } from "@storybook/react";
import { default as Earn } from "@/components/Earn";
import { mockLoyaltyProgram } from "../../../../test/_mocks_";

const meta: Meta<typeof Earn> = {
  title: "Components/Customer/Earn",
  component: Earn,
  parameters: {
    layout: "fullscreen"
  },
  tags: ["autodocs"]
};

export default meta;

type Story = StoryObj<typeof Earn>;

export const Default: Story = {
  render: (props) => {
    return (
      <div style={{ padding: 15 }}>
        <Earn {...props} program={mockLoyaltyProgram} />
      </div>
    );
  }
};

export const WithPopup: Story = {
  render: (props) => {
    return (
      <div style={{ padding: 15 }}>
        <Earn
          {...props}
          ui={{
            ...props.ui,
            enablePopup: true
          }}
          meta={{
            restaurantLogoUrl:
              props.meta?.restaurantLogoUrl ??
              "https://i.ibb.co/ZX9T8X7/285372235-587ca6d8-71e2-4b7b-bd19-3e2e06fc3f9c.png",
            restaurantLogoAvatarUrl: props.meta?.restaurantLogoAvatarUrl ?? "https://i.ibb.co/LRfVNPV/image-51.png"
          }}
        />
      </div>
    );
  }
};
