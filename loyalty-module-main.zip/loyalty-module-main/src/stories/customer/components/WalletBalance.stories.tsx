import type { Meta, StoryObj } from "@storybook/react";
import { default as WalletBalance } from "@/components/WalletBalance";
import { mockLoyaltyProgram } from "../../../../test/_mocks_";

const meta: Meta<typeof WalletBalance> = {
  title: "Components/Customer/Wallet Balance",
  component: WalletBalance,
  parameters: {
    layout: "centered"
  },
  tags: ["autodocs"]
};

export default meta;

type Story = StoryObj<typeof WalletBalance>;

export const Default: Story = {
  render: (props) => {
    return <WalletBalance {...props} program={mockLoyaltyProgram} balance={props.balance ?? 500} />;
  }
};
