export const disableArgTypes = (keys: string[]) => {
  return keys.reduce((acc: Record<string, any>, key) => {
    acc[key] = { table: { disable: true } };
    return acc;
  }, {});
};
