import { useCallback, useEffect } from "react";
import { RefetchOptions, useQuery } from "@tanstack/react-query";
import { default as debounce } from "lodash/debounce";
import { CUID } from "@/constants";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useGlobalStore } from "@/store/global";
import { useOfferStore } from "@/store/offer";
import { IOffer } from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";
import { constructAppliedOfferPopupArgs, translateCombinedOfferName } from "@/utils";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { useAnalytics } from "./analytics";
import { useAPI } from "./api";
import { genericSnackbarOptions } from "./snackbar";

interface IOfferHookProps {
  program: ILoyaltyProgram;
  onRefresh?: () => Promise<void> | void;
}

let isManuallyRefetching = false;

export const useOffers = ({ program, onRefresh }: IOfferHookProps) => {
  const customerID = new URLSearchParams(window.location.search).get(CUID) as any;

  const { vendor = { config: {} } as any } = useVendor();

  const { loyalty } = useAPI();

  const openCongratulationPopup = useGlobalStore().popup.openPopup;

  const user = useAuthStore((state) => state.user[program.id]);

  const welcomeSheetOpen = useAuthStore((state) => state.welcomeSheetOpen[program.id]);

  const congratulated = useOfferStore((state) => state.congratulated[program.id]);

  const setCongratulated = useOfferStore((state) => state.setCongratulated);

  const combinedOfferName = useOfferStore((state) => state.combinedOfferName[program.id]);

  const setAlertedNoOffers = useOfferStore((state) => state.setAlertedNoOffers);

  const setCombinedOfferName = useOfferStore((state) => state.setCombinedOfferName);

  const openOfferSheet = useOfferStore((state) => state.openSheet);

  const analytics = useAnalytics();

  const queryResult = useQuery({
    queryKey: ["loyalty-program-offers", program.id, user?.phoneNumber],
    queryFn: () => {
      if (!program.config.isDiscountEnabled || (program.config.disableAutomatedOfferFetch && !isManuallyRefetching))
        return [] as IOffer[];
      return loyalty.offer.getAll(vendor, program, { id: customerID ?? user?.id }).then(async (res) => {
        if (res.offers.find((o) => o.autoApplicable && o.applied)) {
          await onRefresh?.();
        }
        if (isManuallyRefetching) {
          if (program.config.automatedLogin && !res?.offers?.length) {
            setAlertedNoOffers(program.id, true);
          } else if (res?.offers?.length) {
            openOfferSheet(program.id, true);
          }
        }
        setCombinedOfferName(program.id, res.combinedOfferName);
        return res.offers as IOffer[];
      });
    },
    staleTime: 0
  });

  const congratulate = useCallback(
    debounce((offers: IOffer[], isWelcomeSheetOpen: boolean, combinedOfferName?: string) => {
      if (offers?.length) {
        if (!isWelcomeSheetOpen) {
          if (combinedOfferName) {
            openCongratulationPopup(
              constructAppliedOfferPopupArgs({ name: translateCombinedOfferName(combinedOfferName) })
            );
          } else {
            const firstAutoApplicableOffer = offers.find((offer) => offer.autoApplicable && offer.applied);
            if (firstAutoApplicableOffer) {
              openCongratulationPopup(constructAppliedOfferPopupArgs(firstAutoApplicableOffer));
            } else {
              openOfferSheet(program.id, true);
            }
          }
          setCongratulated(program.id, true);
        }
      }
    }, 1),
    []
  );

  useEffect(() => {
    if (!queryResult.isLoading && user?.isAuthorized && program.config?.isDiscountEnabled) {
      const appliedNonAutoApplicableOffers = [];
      const autoApplicableOffers = [];
      for (const offer of (queryResult.data as IOffer[]) ?? []) {
        if (offer.autoApplicable && offer.applied) {
          autoApplicableOffers.push(offer);
        } else if (offer.applied) {
          appliedNonAutoApplicableOffers.push(offer);
        }
      }
      if (autoApplicableOffers.length) {
        analytics.offers.autoApplicableOffersAvailable(program, autoApplicableOffers);
      } else {
        analytics.offers.noAutoApplicableOffers(program);
      }
      if (appliedNonAutoApplicableOffers.length) {
        analytics.offers.manuallyAppliedOffers(program, appliedNonAutoApplicableOffers);
      } else {
        analytics.offers.noManuallyApplicableOffers(program);
      }
    }
  }, [queryResult.data, queryResult.isLoading, user?.isAuthorized]);

  useEffect(() => {
    if (!congratulated) congratulate((queryResult.data as IOffer[]) ?? [], welcomeSheetOpen, combinedOfferName);
  }, [queryResult.data, welcomeSheetOpen, congratulated]);

  const handleRefetch = async (options?: RefetchOptions & { manual?: boolean }) => {
    if (options?.manual) isManuallyRefetching = true;
    await queryResult.refetch(options);
    isManuallyRefetching = false;
  };

  const applyOffer = async (offer: IOffer) => {
    const offerIds: string[] = [offer.id];
    try {
      const res = await loyalty.offer.apply(vendor, program, offerIds, {
        id: customerID || user?.id,
        phoneNumber: user?.phoneNumber ?? ""
      });
      await onRefresh?.();
      return res;
    } catch (err) {
      window.snackbar?.enqueue?.(t("Something went wrong. Please try again"), {
        variant: "error",
        ...genericSnackbarOptions
      });
      throw err;
    }
  };

  return {
    ...queryResult,
    refetch: handleRefetch,
    applyOffer
  };
};

export default useOffers;
