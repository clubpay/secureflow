import React, { useEffect, useState } from "react";

const useVisibility = (ref: React.RefObject<HTMLElement>, onVisible?: () => void) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (!ref.current) return;
    const observer = new IntersectionObserver(([entry]) => {
      setIsVisible(entry.isIntersecting);
    });
    observer.observe(ref.current!);
    return () => observer.disconnect();
  }, [ref]);

  useEffect(() => {
    if (isVisible) {
      onVisible?.();
    }
  }, [isVisible, onVisible]);

  return isVisible;
};

export default useVisibility;
