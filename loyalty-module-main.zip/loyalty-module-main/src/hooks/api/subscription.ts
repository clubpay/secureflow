import { useQuery } from "@tanstack/react-query";
import { default as APIManager } from "@/api";
import { useGlobalStore } from "@/store/global";
import { ILoyaltyProgram, InternalProgramType } from "@/types/entities/program";

export const useGetLoyaltySubscriptionDiscount = (program?: ILoyaltyProgram<any>) => {
  const paymentDetails = useGlobalStore((state) => state.paymentDetails);
  const query = useQuery({
    queryKey: ["subscription-discount", paymentDetails?.diningSessionID],
    queryFn: () => {
      if (!paymentDetails.diningSessionID || program?.internalProgramType !== InternalProgramType.IN_SUB_DISCOUNT) {
        return { discountValue: 0 } as any;
      }
      return APIManager.getInstance().subscription.getDiscount(paymentDetails.diningSessionID);
    }
  });
  return query?.data?.discountValue ?? 0;
};
