import { useQuery } from "@tanstack/react-query";
import { default as APIManager } from "@/api";
import { CUID } from "@/constants";
import { useAuthStore } from "@/store/auth";
import { formatProfile } from "@/transformers";
import { ILoyaltyProgram } from "@/types/entities/program";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";

export const useProfile = (program?: ILoyaltyProgram) => {
  const { vendor } = useVendor();

  const { isAuthorizedUser } = useAuth();

  const user = useAuthStore((state) => state.user[program?.id as any]);

  const queryKey = ["loyalty-program-profile", program?.id, isAuthorizedUser];

  const queryResult = useQuery({
    queryKey: queryKey,
    queryFn: () => {
      if (!program?.id || !vendor?.unique) return null;
      return APIManager.getInstance()
        .auth.getProfile(vendor, program, {
          id: new URLSearchParams(window.location.search).get(CUID) as any,
          phoneNumber: user?.phoneNumber
        })
        .then((profile) => {
          const formattedProfile = formatProfile(profile);
          useAuthStore.getState().setUser(program?.id, formattedProfile);
          return formattedProfile;
        });
    },
    staleTime: 5000,
    retry(failureCount, response: any) {
      if (response?.status === 401 || response?.status === 403 || response?.status === 405) return false;
      return failureCount < 3;
    }
  });

  return { ...queryResult, profile: user };
};

export const useLoyaltyProfile = useProfile;
