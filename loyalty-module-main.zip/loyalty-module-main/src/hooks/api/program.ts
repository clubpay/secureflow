import { UseQueryResult, useInfiniteQuery, useQuery } from "@tanstack/react-query";
import { default as APIManager } from "@/api";
import { inflateLoyaltyProgram } from "@/transformers";
import { IVenue, LoyaltyService } from "@/types";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { IRestaurant } from "@clubpay/customer-common-module/src/repository/vendor";

export const useGetRestaurantLoyaltyPrograms = (vendor?: IRestaurant) => {
  const { vendor: currentVendor } = useVendor();
  vendor ??= currentVendor;
  return useQuery({
    queryKey: ["restaurant-programs", vendor?.unique, vendor?.country?.code],
    queryFn: () => {
      if (!vendor?.unique || !vendor?.country?.code) return [];
      return APIManager.getInstance().program.getRestaurantLoyaltyPrograms(vendor?.unique, vendor?.country?.code);
    },
    staleTime: Infinity
  });
};

export const useLoyaltyProgram = <T = Record<string, any>>(programId: string, vendor?: IRestaurant) => {
  const { vendor: currentVendor } = useVendor();
  vendor ??= currentVendor;
  const { data: programs } = useGetRestaurantLoyaltyPrograms();
  const program = programs?.find((program) => program.id === programId || program.type === programId);
  if (!program) return undefined;
  return inflateLoyaltyProgram(program, vendor ?? ({ config: {} } as any)) as ILoyaltyProgram<T>;
};

/** Used to retrieve the first currently enabled loyalty program of type Qlub. Should not be used for external loyalty providers.*/
export const useEnabledLoyaltyProgram = (): UseQueryResult<any[], Error> & {
  program: ILoyaltyProgram<IQlubConfig> | undefined;
} => {
  const { vendor } = useVendor();
  const result = useGetRestaurantLoyaltyPrograms();
  const program = (result.data as any)?.find(
    (program: ILoyaltyProgram<IQlubConfig>) =>
      program.enabled &&
      (program.config.isEarnEnabled ||
        program.config.isBurnEnabled ||
        program.config?.isDiscountEnabled ||
        (program?.subscription?.options?.isActive && program?.subscription?.options?.activateWelcomeDiscount)) &&
      program.type === LoyaltyService.Qlub
  );
  return {
    ...result,
    program: program
      ? (inflateLoyaltyProgram(program, vendor ?? ({ config: {} } as any)) as ILoyaltyProgram<IQlubConfig>)
      : undefined
  };
};

export const useGetCountryLoyaltyProgram = (countryCode: string) => {
  return useQuery({
    queryKey: ["country-program", countryCode],
    queryFn: () => {
      if (!countryCode) return null;
      return APIManager.getInstance().program.getCountryLoyaltyProgram(countryCode);
    },
    retry(failureCount, response: any) {
      if (response?.status >= 400 && response?.status < 500) return false;
      return failureCount < 3;
    }
  });
};

export const useGetProgramVenues = (programId?: string, search?: string) => {
  const { vendor } = useVendor();
  return useInfiniteQuery({
    queryKey: ["program-venues", programId, search],
    queryFn: ({ pageParam = 1 }) => {
      if (!programId) return { count: 0, rows: [] as IVenue[] };
      if (!vendor?.unique && !vendor?.country?.code) {
        return APIManager.getInstance().program.getDiscoveryPageResults(programId, search, pageParam, 10);
      }
      return APIManager.getInstance().program.getProgramVenues(
        vendor?.unique,
        vendor?.country?.code,
        programId,
        search,
        pageParam,
        10
      );
    },
    getNextPageParam: (lastPage, allPages) =>
      lastPage.count <= allPages.length * 10 ? undefined : allPages.length + 1,
    initialPageParam: 1,
    enabled: !!programId,
    staleTime: 30 * 1000
  });
};
