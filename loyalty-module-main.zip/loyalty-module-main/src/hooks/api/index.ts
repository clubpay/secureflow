import { default as APIManager } from "@/api";
import { IExternalAPI } from "@/types";

export * from "./program";
export * from "./profile";
export * from "./customer";
export * from "./subscription";

export const useAPI = (externalApis?: IExternalAPI) => {
  return {
    bill: externalApis?.bill,
    loyalty: APIManager.getInstance()
  };
};

export default useAPI;
