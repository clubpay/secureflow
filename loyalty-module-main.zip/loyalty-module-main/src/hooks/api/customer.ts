import { useInfiniteQuery } from "@tanstack/react-query";
import { default as APIManager } from "@/api";
import { ITransaction } from "@/types";

export const useCustomerTransactions = (customerId?: string, params?: Record<string, any>) => {
  return useInfiniteQuery({
    queryKey: ["customer-transactions", customerId, ...Object.values(params ?? {})],
    queryFn: ({ pageParam = 1 }) => {
      if (!customerId && !params?.programId) return { count: 0, transfers: [] as ITransaction[] };
      return APIManager.getInstance().customer.getTransactions(customerId!, {
        ...params,
        pageSize: 10,
        page: pageParam
      });
    },
    getNextPageParam: (lastPage, allPages) =>
      lastPage.count <= allPages.length * 10 ? undefined : allPages.length + 1,
    initialPageParam: 1,
    enabled: !!customerId
  });
};
