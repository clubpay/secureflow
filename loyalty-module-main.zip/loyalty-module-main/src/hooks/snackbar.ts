import { useEffect } from "react";
import { ISnackBar } from "@/types/plugins";

declare global {
  interface Window {
    snackbar: ISnackBar;
  }
}

const useSnackbar = (snackbar?: ISnackBar) => {
  useEffect(() => {
    if (window.snackbar && !window.snackbar._isNative) return;
    snackbar ??= {
      _isNative: true,
      enqueue: (...args) => window.alert(args?.[0]),
      close: () => {}
    };
    window.snackbar = snackbar;
  }, [snackbar]);
};

export const genericSnackbarOptions = {
  autoHideDuration: 5000,
  style: { marginBottom: "40%" },
  persist: false
};

export default useSnackbar;
