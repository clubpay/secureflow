import { useEffect, useMemo } from "react";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useCheckoutStore } from "@/store/checkout";
import { IRedemptionOptions } from "@/types";
import { RedeemableAdditives } from "@clubpay/customer-common-module/src/repository/vendor";

const useRedemptionCalculations = ({ bill, currencyFormat, config, program }: IRedemptionOptions) => {
  const { setPoints, setMaxRedeemablePoints, setMaxRedeemablePointsIgnoringBalance, setInsufficientBalanceRecorded } =
    useCheckoutStore();

  const user = useAuthStore((state) => state.user[program.id]);

  const insufficientBalanceRecorded = useCheckoutStore((state) => state.insufficientBalanceRecorded[program.id]);

  const accountBalance = useMemo(() => {
    return user?.accountBalance
      ? Number(user?.accountBalance?.nonMonetary?.toFixed(currencyFormat.currencyPrecision))
      : 0;
  }, [user?.accountBalance]);

  const shareValue = useMemo(() => {
    let tax = 0;
    if (bill!.payments!.regular! <= bill!.tax) tax = bill!.tax - bill!.payments!.regular!;
    if (program.config.redeemableAdditives?.includes(RedeemableAdditives.Tax)) {
      return bill!.share - bill!.shareCommission!;
    }
    return bill!.share - bill!.shareCommission! - tax;
  }, [bill?.share, bill?.shareCommission, bill?.tax, bill?.payments?.regular, program.config.redeemableAdditives]);

  const sharePoints = useMemo(() => {
    const points = shareValue! / config.conversionRate!;
    if (program.config.redeemableBillPercentage) {
      return (points * program.config.redeemableBillPercentage) / 100;
    }
    return points;
  }, [shareValue, config?.conversionRate]);

  const loyaltyBaseBillValue = useMemo(() => {
    const value =
      bill.amount -
      bill.commission -
      (program.config.redeemableAdditives?.includes(RedeemableAdditives.Tax) ? 0 : bill.tax);
    return value;
  }, [bill?.amount, bill?.commission, bill?.tax, program.config.redeemableAdditives]);

  const loyaltyBillValue = useMemo(() => {
    let value = loyaltyBaseBillValue;
    if (program.config.redeemableBillPercentage) {
      value = (value * program.config.redeemableBillPercentage) / 100;
    }
    return value;
  }, [loyaltyBaseBillValue, program.config.redeemableBillPercentage]);

  const remainingLoyaltyBillValue = useMemo(() => {
    let value = loyaltyBillValue - bill.payments!.loyalty!;
    if (value < 0) value = 0;
    return value;
  }, [loyaltyBillValue, bill.payments?.loyalty]);

  const remainingLoyaltyBillPoints = useMemo(() => {
    return remainingLoyaltyBillValue / config.conversionRate!;
  }, [remainingLoyaltyBillValue, config.conversionRate]);

  const min = useMemo(() => {
    const minCandidates = [program.config.minPointsPerTransaction ?? 0];
    if (program.config.minimumRedeemableBillPercentage) {
      minCandidates.push(
        ((loyaltyBaseBillValue / config.conversionRate!) * program.config.minimumRedeemableBillPercentage) / 100
      );
    }
    let result = Number(Math.max(...minCandidates).toFixed(currencyFormat.currencyPrecision));
    if (program.config.redeemablePointStep) {
      result = Math.ceil(result / program.config.redeemablePointStep) * program.config.redeemablePointStep;
    }
    return result;
  }, [
    program.config.minPointsPerTransaction,
    program.config.minimumRedeemableBillPercentage,
    program.config.redeemablePointStep,
    loyaltyBaseBillValue
  ]);

  const max = useMemo(() => {
    const maxCandidates = [accountBalance, remainingLoyaltyBillPoints, sharePoints];
    if (program.config.maxPointsPerTransaction) {
      maxCandidates.push(program.config.maxPointsPerTransaction);
    }
    const smallest = Math.min(...maxCandidates);
    let maxVal = Number(smallest.toFixed(currencyFormat.currencyPrecision));
    if (program.config.disableFractionalRedemption) maxVal = Math.floor(maxVal);
    if (program.config.redeemablePointStep && smallest !== accountBalance) {
      maxVal = Math.floor(maxVal / program.config.redeemablePointStep) * program.config.redeemablePointStep;
    }
    return maxVal;
  }, [
    program.config.maxPointsPerTransaction,
    program.config.disableFractionalRedemption,
    accountBalance,
    sharePoints,
    remainingLoyaltyBillPoints
  ]);

  const maxIgnoringBalance = useMemo(() => {
    const maxCandidates = [remainingLoyaltyBillPoints, sharePoints];
    if (program.config.maxPointsPerTransaction) {
      maxCandidates.push(program.config.maxPointsPerTransaction);
    }
    let max = Number(Math.min(...maxCandidates).toFixed(currencyFormat.currencyPrecision));
    if (program.config.disableFractionalRedemption) max = Math.floor(max);
    if (program.config.redeemablePointStep) {
      max = Math.floor(max / program.config.redeemablePointStep) * program.config.redeemablePointStep;
    }
    return max;
  }, [
    program.config.maxPointsPerTransaction,
    program.config.disableFractionalRedemption,
    sharePoints,
    remainingLoyaltyBillPoints
  ]);

  useEffect(() => {
    setMaxRedeemablePoints(program.id, max);
  }, [max]);

  useEffect(() => {
    setMaxRedeemablePointsIgnoringBalance(program.id, maxIgnoringBalance);
  }, [maxIgnoringBalance]);

  const lowBalance = accountBalance === 0 || accountBalance < min;

  const cannotRedeem = max < min || remainingLoyaltyBillValue === 0;

  const points = config.redemption?.points || max;

  useEffect(() => {
    setPoints(program.id, config.redemption?.points || max);
  }, [config.redemption?.points, max]);

  useEffect(() => {
    if (user?.phoneNumber && lowBalance === true && !insufficientBalanceRecorded) {
      config.events?.onInsufficientPoints?.();
      setInsufficientBalanceRecorded(program.id, true);
    }
  }, [user?.phoneNumber, insufficientBalanceRecorded, lowBalance]);

  const cannotRedeemErrorMessage = lowBalance
    ? t("You don’t have sufficient points to redeem")
    : remainingLoyaltyBillValue === 0
    ? t("Max redeemable amount used")
    : t("Minimum redemption allowed is {{currency}} {{amount}} ({{points}} points)", {
        currency: currencyFormat.cs,
        amount: (min * config.conversionRate!).toFixed(currencyFormat.currencyPrecision),
        points: min
      });

  return {
    accountBalance,
    sharePoints,
    min,
    max,
    maxIgnoringBalance,
    lowBalance,
    cannotRedeem,
    remainingLoyaltyBillValue,
    remainingLoyaltyBillPoints,
    points,
    cannotRedeemErrorMessage
  };
};

export default useRedemptionCalculations;
