import { useEffect, useRef, useState } from "react";

function useDebounce(value: any, delay: number = 1000) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  const timerRef = useRef<any>(null);

  useEffect(() => {
    clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
  }, [value, delay]);

  return debouncedValue;
}

export default useDebounce;
