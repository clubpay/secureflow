import { useMutation } from "@tanstack/react-query";

const useSyncMutation = <A, B, C = void, D = unknown>(...args: Parameters<typeof useMutation<A, B, C, D>>) => {
  const mutationResults = useMutation<A, B, C, D>(...args);
  return {
    ...mutationResults,
    mutate: (...params: Parameters<typeof mutationResults.mutate>) => {
      if (!mutationResults.isPending) {
        mutationResults.mutate(...params);
      }
    }
  };
};

export default useSyncMutation;
