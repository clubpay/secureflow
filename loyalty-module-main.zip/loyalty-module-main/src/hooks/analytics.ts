import { useCallback, useMemo } from "react";
import { inflateLoyaltyProgram } from "@/transformers";
import { IOffer, IQlubProfile, LoyaltyService } from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";
import { getAutoApplicableOfferKey, getManualApplicableOfferKey } from "@/utils";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { useQlubRouter } from "@clubpay/customer-common-module/src/hook/router";
import { onPushEvent } from "@clubpay/customer-common-module/src/lib/gtm";
import { getDiningSession } from "@clubpay/customer-common-module/src/service/session/dsi";

const hardcodeLoyaltyProgramFor = [LoyaltyService.Tickit];

export const useAnalytics = () => {
  const { vendor } = useVendor();
  const {
    url: { slug, ...url },
    query,
    lang = vendor?.country?.languageCode
  } = useQlubRouter();

  const dsi = useMemo(() => {
    return getDiningSession({ ...url, slug })?.id;
  }, [url, slug]);

  const commonAttributes = useCallback(
    (program: ILoyaltyProgram) => {
      return {
        restaurant_name: slug,
        loyalty_program_name: hardcodeLoyaltyProgramFor.includes(program.type as LoyaltyService)
          ? program.type
          : program.config.readableDisplayName,
        diningSessionId: dsi,
        pg_name: query.method,
        country: vendor?.country.code,
        language: lang
      };
    },
    [slug, dsi, query?.method]
  );

  const legacyAttributes = useMemo(
    () => ({
      opsMode: vendor?.opsMode || "",
      restaurant_name: slug,
      country_code: vendor?.country.code || "",
      pg_name: query?.method
    }),
    [vendor?.opsMode, vendor?.country.code, slug, query?.method]
  );

  const earn = {
    rendered: (program: ILoyaltyProgram) => {
      onPushEvent(`${program.type}_widget_shown`, commonAttributes(program));
    },
    submit: (program: ILoyaltyProgram) => {
      onPushEvent(`${program.type}_widget_submit`, commonAttributes(program));
    },
    legacy: {
      tapEarnPointsBtn: (mobile: string, status: string) => {
        onPushEvent("tap_on_earn_point_button", {
          ...legacyAttributes,
          entered_phone: mobile,
          status
        });
      },
      enterPhoneNumber: (mobile: string) => {
        mobile && onPushEvent("enter_phone_number", legacyAttributes);
      }
    }
  };

  const auth = {
    login(program: ILoyaltyProgram) {
      if (program?.type === LoyaltyService.Qlub) {
        if (program.config?.useToggle) {
          onPushEvent(`loyalty_tap_login_continue_toggle`, commonAttributes(program));
        } else {
          onPushEvent(`loyalty_tap_login_continue`, commonAttributes(program));
        }
      } else {
        onPushEvent(`${program.type}_loyalty_click_login`, commonAttributes(program));
      }
    },
    submitOTP(program: ILoyaltyProgram) {
      if (program?.type === LoyaltyService.Qlub) {
        if (program.config?.useToggle) {
          onPushEvent(`loyalty_tap_otp_continue_toggle`, commonAttributes(program));
        } else {
          onPushEvent(`loyalty_tap_otp_continue`, commonAttributes(program));
        }
      } else {
        onPushEvent(`${program.type}_loyalty_click_otp_submit`, commonAttributes(program));
      }
    },
    welcomeImpression(program: ILoyaltyProgram) {
      program?.type === LoyaltyService.Qlub &&
        onPushEvent(`loyalty_impression_welcome_page_wallet`, commonAttributes(program), undefined, true, true);
    }
  };

  const redemption = {
    impression(program: ILoyaltyProgram) {
      if (program?.type === LoyaltyService.Qlub) {
        if (program.config?.useToggle) {
          onPushEvent(`loyalty_impression_redeem_toggle`, commonAttributes(program), undefined, true, true);
        } else {
          onPushEvent(`loyalty_impression_redeem_cta_wallet`, commonAttributes(program), undefined, true, true);
        }
      }
    },
    walletImpression(program: ILoyaltyProgram) {
      program?.type === LoyaltyService.Qlub &&
        onPushEvent(`loyalty_impression_wallet_page_wallet`, commonAttributes(program), undefined, true, true);
    },
    clickCTA(program: ILoyaltyProgram) {
      if (program?.type === LoyaltyService.Qlub) {
        if (program.config?.useToggle) {
          onPushEvent(`loyalty_tap_redeem_toggle`, commonAttributes(program));
        } else {
          onPushEvent(`loyalty_tap_redeem_cta_wallet`, commonAttributes(program));
        }
      }
    },
    fullEligibleFullRedemption(program: ILoyaltyProgram) {
      onPushEvent(`${program.type}_loyalty_redemption_full_eligible_full_redemption`, commonAttributes(program));
    },
    fullEligiblePartialRedemption(program: ILoyaltyProgram) {
      onPushEvent(`${program.type}_loyalty_redemption_full_eligible_partial_redemption`, commonAttributes(program));
    },
    partialEligibleFullRedemption(program: ILoyaltyProgram) {
      onPushEvent(`${program.type}_loyalty_redemption_partial_eligible_full_redemption`, commonAttributes(program));
    },
    partialEligiblePartialRedemption(program: ILoyaltyProgram) {
      onPushEvent(`${program.type}_loyalty_redemption_partial_eligible_partial_redemption`, commonAttributes(program));
    },
    click(program: ILoyaltyProgram) {
      program?.type === LoyaltyService.Qlub && onPushEvent(`loyalty_tap_redeem_on_wallet`, commonAttributes(program));
    },
    confirm(program: ILoyaltyProgram) {
      if (program?.type === LoyaltyService.Qlub) {
        if (program.config?.useToggle) {
          onPushEvent(`loyalty_tap_proceed_on_toggle`, commonAttributes(program));
        } else {
          onPushEvent(`loyalty_tap_proceed_on_wallet`, commonAttributes(program));
        }
      } else {
        onPushEvent(`${program.type}_loyalty_click_confirm_redeem_yes`, commonAttributes(program));
      }
    },
    cancel(program: ILoyaltyProgram) {
      onPushEvent(`${program.type}_loyalty_click_confirm_redeem_no`, commonAttributes(program));
    },
    insufficientPoints(program: ILoyaltyProgram) {
      onPushEvent(
        `${program.type}_loyalty_redemption_insufficient_points`,
        commonAttributes(program),
        undefined,
        true,
        true
      );
    },
    redeem(program: ILoyaltyProgram, fullEligibility: boolean, fullRedemption: boolean) {
      if (fullEligibility && fullRedemption) return this.fullEligibleFullRedemption(program);
      if (fullEligibility && !fullRedemption) return this.fullEligiblePartialRedemption(program);
      if (!fullEligibility && fullRedemption) return this.partialEligibleFullRedemption(program);
      return this.partialEligiblePartialRedemption(program);
    },
    success(program: ILoyaltyProgram) {
      if (program?.type === LoyaltyService.Qlub) {
        if (program.config?.useToggle) {
          onPushEvent(`loyalty_redeem_success_toggle`, commonAttributes(program));
        } else {
          onPushEvent(`loyalty_redeem_success_wallet`, commonAttributes(program));
        }
      }
    }
  };

  const general = {
    serviceEnabled(program: ILoyaltyProgram) {
      onPushEvent(`${program.type}_enabled`, commonAttributes(program));
    },
    checkAndFireServiceEnabled() {
      if (vendor?.config?.tickitEnabled)
        this.serviceEnabled(
          inflateLoyaltyProgram({ id: LoyaltyService.Tickit, type: LoyaltyService.Tickit } as any, vendor)
        );
      if (vendor?.config?.comoV2Enabled)
        this.serviceEnabled(
          inflateLoyaltyProgram({ id: LoyaltyService.Como, type: LoyaltyService.Como } as any, vendor)
        );
    },
    closeSheet(program: ILoyaltyProgram) {
      onPushEvent(`${program.type}_loyalty_close_sheet`, commonAttributes(program));
    },
    clickEarnAndRedeem(program: ILoyaltyProgram) {
      program?.type !== LoyaltyService.Qlub &&
        onPushEvent(`${program.type}_loyalty_click_earn_and_redeem`, commonAttributes(program));
    }
  };

  const offers = {
    noAutoApplicableOffers(program: ILoyaltyProgram) {
      onPushEvent(`${program.type} loyalty | no ${getAutoApplicableOfferKey(program)} available`, {
        ...commonAttributes(program),
        [`${getAutoApplicableOfferKey(program)}_name`]: `No ${getAutoApplicableOfferKey(program)}`
      });
    },
    autoApplicableOffersAvailable(program: ILoyaltyProgram, offers: IOffer[]) {
      onPushEvent(`${program.type} loyalty | ${getAutoApplicableOfferKey(program)} available`, {
        ...commonAttributes(program),
        [`${getAutoApplicableOfferKey(program)}_names`]: offers.map((offer) => offer.name).join(" | ")
      });
    },
    noManuallyApplicableOffers(program: ILoyaltyProgram) {
      onPushEvent(`${program.type} loyalty | no ${getManualApplicableOfferKey(program)} applied`, {
        ...commonAttributes(program),
        [`${getManualApplicableOfferKey(program)}_names`]: `No ${getManualApplicableOfferKey(program)}`
      });
    },
    manuallyAppliedOffers(program: ILoyaltyProgram, offers: IOffer[] = []) {
      onPushEvent(`${program.type} loyalty | ${getManualApplicableOfferKey(program)} applied`, {
        ...commonAttributes(program),
        [`no of ${getManualApplicableOfferKey(program)}s`]: offers.length,
        [`${getManualApplicableOfferKey(program)}_names`]: offers.map((offer) => offer.name).join(" | ")
      });
    }
  };

  const subscription = {
    viewSubscription(program: ILoyaltyProgram) {
      onPushEvent("viewSubscription", {
        ...commonAttributes(program),
        subscription_value: (program.subscription?.subscriptionAmount.fixed.amount || 0) / 100,
        subscription_currency: program.subscription?.subscriptionAmount.fixed.currency
      });
    },
    clickOnSubscription(program: ILoyaltyProgram) {
      onPushEvent("clickOnSubscription", {
        ...commonAttributes(program),
        subscription_value: (program.subscription?.subscriptionAmount.fixed.amount || 0) / 100,
        subscription_currency: program.subscription?.subscriptionAmount.fixed.currency
      });
    },
    welcomeDiscountApplied(program: ILoyaltyProgram, profile?: IQlubProfile) {
      onPushEvent("welcomeDiscountApplied", {
        ...commonAttributes(program),
        subscription_value: (program.subscription?.subscriptionAmount.fixed.amount || 0) / 100,
        subscription_currency: program.subscription?.subscriptionAmount.fixed.currency,
        welcome_discount_value: program.subscription?.meta.welcomeDiscountValue,
        ...(profile
          ? {
              first_time_subscriber: !profile.subscriptions.some(
                (sub) => sub.subscriptionID === program.subscription?.subscriptionID
              )
            }
          : {})
      });
    },
    clickOnUnsubscribe(program: ILoyaltyProgram) {
      onPushEvent("clickOnUnsubscribe", {
        ...commonAttributes(program),
        subscription_value: (program.subscription?.subscriptionAmount.fixed.amount || 0) / 100,
        subscription_currency: program.subscription?.subscriptionAmount.fixed.currency
      });
    }
  };

  return {
    auth,
    redemption,
    earn,
    general,
    offers,
    subscription
  };
};

export default useAnalytics;
