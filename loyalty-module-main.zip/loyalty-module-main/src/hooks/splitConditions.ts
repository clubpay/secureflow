import { useGlobalStore } from "@/store/global";
import { useSubscriptionStore } from "@/store/subscription";
import { useEnabledLoyaltyProgram } from "./api";
import { LoyaltyService } from "@/types";

function useLoyaltySplitConditions() {
  const optedForSubscription = useSubscriptionStore((state) => state.optedForSubscription);
  const paymentDetails = useGlobalStore((state) => state.paymentDetails);
  const applicableDiscount = paymentDetails?.billNumber?.qlubLoyaltyDiscount;

  const { program } = useEnabledLoyaltyProgram();

  if (program?.type !== LoyaltyService.Qlub) return true;

  if ((optedForSubscription || applicableDiscount) && Number(paymentDetails?.bill?.remaining ?? "0") > 0) return false;

  return true;
}

export default useLoyaltySplitConditions;
