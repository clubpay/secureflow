import { useGlobalStore } from "@/store/global";
import { IDiscount } from "@/types";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { checkAndReturnDiscountIfApplicable } from "@/utils/discounts";

export function useDiscount(program?: ILoyaltyProgram<IQlubConfig>) {
  const paymentDetails = useGlobalStore((state) => state.paymentDetails);
  const billTotal = Number(paymentDetails.bill?.total ?? "0.00");

  if (!program?.subscription) return undefined;

  let discount: IDiscount | undefined;

  if (program.config.isDiscountEnabled) {
    discount = checkAndReturnDiscountIfApplicable(program.discounts?.find((discount) => discount.enabled), billTotal);
  }
  return discount;
}
