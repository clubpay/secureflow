import { useEffect, useRef } from "react";
import { isRunningTests } from "@/constants";

const useSkipFirstRender = (callback: () => any, dependencies: any[] = []) => {
  const firstRenderRef = useRef(true);
  useEffect(() => {
    if (firstRenderRef.current && !isRunningTests) {
      firstRenderRef.current = false;
    } else {
      callback();
    }
  }, dependencies);
};

export default useSkipFirstRender;
