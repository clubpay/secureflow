import { useSubscriptionStore } from "@/store/subscription";
import { useEnabledLoyaltyProgram } from "./api";

export function useSubscriptionCost() {
  const { program } = useEnabledLoyaltyProgram();
  const optedForSubscription = useSubscriptionStore((state) => state.optedForSubscription);
  if (!optedForSubscription) return 0;
  return program?.subscription?.subscriptionAmount?.fixed?.amount || 0;
}
