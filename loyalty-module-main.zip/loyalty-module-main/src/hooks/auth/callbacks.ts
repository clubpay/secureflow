import { useEffect } from "react";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useGlobalStore } from "@/store/global";
import { InternalProgramType } from "@/types/entities/program";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { default as useAPI, useEnabledLoyaltyProgram, useProfile } from "../api";

const useLoyaltyLoginCallbacks = () => {
  const { program } = useEnabledLoyaltyProgram();

  const { setIsNewUser, openWelcomeSheet } = useAuthStore();

  const { profile } = useProfile(program);

  const { loyalty } = useAPI();

  const { vendor } = useVendor();

  const { locale } = useGlobalStore();

  const { setLoginCallbacks } = useAuth();

  useEffect(() => {
    if (program?.id) {
      setLoginCallbacks({
        preLogin: async (mobile: string) => {
          try {
            const res = await loyalty.auth.login(
              vendor as any,
              program,
              {
                phoneNumber: mobile
              },
              false,
              true
            );
            setIsNewUser(program.id, res.isNewUser);
            if (!res.isNewUser && (profile?.accountBalance?.nonMonetary ?? 0) > 0) {
              return new Promise((resolve) => {
                window.openDialog?.(
                  t(
                    "The mobile number you entered is already registered with us. would you like to proceed and add your wallet balance to this profile?"
                  ),
                  () => {
                    window.closeDialog();
                    resolve(true);
                  },
                  () => resolve(false)
                );
              });
            }
            return true;
          } catch (error) {
            return true;
          }
        },
        postOTPVerification: async () => {
          const isNewUser = useAuthStore.getState().isNewUser[program?.id ?? ""];
          if (isNewUser && program.internalProgramType !== InternalProgramType.IN_SUB_DISCOUNT) {
            setTimeout(() => {
              openWelcomeSheet(program.id, true);
            }, 0);
          }
        }
      });
    } else {
      setLoginCallbacks({
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        preLogin: async (_: string) => true,
        postOTPVerification: async () => {}
      });
    }
  }, [program?.id, locale, profile?.accountBalance]);
};

export default useLoyaltyLoginCallbacks;
