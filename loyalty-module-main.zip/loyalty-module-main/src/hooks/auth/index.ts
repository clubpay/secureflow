import { useEffect, useState } from "react";
import { CUID, sessionLoginKey } from "@/constants";
import { default as useAnalytics } from "@/hooks/analytics";
import { default as useAPI, useProfile } from "@/hooks/api";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useGlobalStore } from "@/store/global";
import { formatProfile } from "@/transformers";
import { hasDiscounts, hasQlubLoyaltyDiscounts } from "@/transformers/bill";
import { IProfileDetails, Locales, LoyaltyService } from "@/types";
import { ILoyaltyProgram, InternalProgramType } from "@/types/entities/program";
import { getLocaleText } from "@clubpay/customer-common-module/src/component/MultiLocale";
import * as events from "@clubpay/customer-common-module/src/const/events";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";

const automatedLoginAttempted: Record<string, boolean> = {};

const useAuthComponentProps = (p?: ILoyaltyProgram) => {
  const customerID = new URLSearchParams(window.location.search).get(CUID) as any;

  const [otpId, setOtpId] = useState<string | undefined>();

  const { storeAuthToken } = useAuth();

  const { selectedProgram, paymentDetails, locale } = useGlobalStore();

  const program = p ?? selectedProgram ?? ({ config: {} } as any);

  const {
    profile,
    refetch: refetchProfile,
    error: profileFetchError,
    isLoading: isProfileLoading
  } = useProfile(program);

  const loginPromptEnabled = useAuthStore((state) => state.loginPromptEnabled[program.id]);

  const isMobileNumberValid = useAuthStore((state) => state.isMobileNumberValid[program.id]);

  const loginSheetPrompted = useAuthStore((state) => state.loginSheetPrompted[program.id]);

  const loginVerificationCallback = useAuthStore((state) => state.loginVerificationCallback[program.id]);

  const { setUser, setLoginPromptEnabled, openLoginSheet, setLoginSheetPrompted, setAutomatedLoginInProgress } =
    useAuthStore();

  const { vendor = { config: {}, country: {} } as any, currencyFormat } = useVendor();

  const { loyalty } = useAPI();

  const analytics = useAnalytics();

  const loginPromptInvokator = (force?: boolean) => {
    if (
      vendor &&
      program.config.enableLoginPrompt &&
      !profile &&
      !isProfileLoading &&
      !isMobileNumberValid &&
      (!loginSheetPrompted || force)
    ) {
      setLoginPromptEnabled(program.id, true);
      setLoginSheetPrompted(program.id, true);
      openLoginSheet(program.id, true);
    }
  };

  useEffect(() => {
    loginPromptInvokator();
    const forceOpenPrompt = () => loginPromptInvokator(true);
    document.addEventListener(events.pullToRefresh, forceOpenPrompt);
    return () => {
      document.removeEventListener(events.pullToRefresh, forceOpenPrompt);
    };
  }, [vendor, program.config?.enableLoginPrompt, profile?.id, isProfileLoading, loginSheetPrompted]);

  useEffect(() => {
    if (
      program?.id &&
      paymentDetails?.diningSessionID &&
      !automatedLoginAttempted[program.id] &&
      ((!sessionStorage.getItem(sessionLoginKey(program.id)) && program.config.apiVersion === 2) ||
        (program.config.automatedLogin &&
          customerID &&
          (profileFetchError || (profile?.id && profile.id !== customerID))))
    ) {
      automatedLoginAttempted[program.id] = true;
      setAutomatedLoginInProgress(program.id, true);
      onLogin({ phoneNumber: profile?.phoneNumber }, true, true).finally(() => {
        setAutomatedLoginInProgress(program.id, false);
      });
    }
  }, [profileFetchError, program?.id, profile?.id, paymentDetails?.diningSessionID]);

  const onLogin = async (user: Partial<IProfileDetails>, trailingCall?: boolean, fresh: boolean = false) => {
    if (!trailingCall) analytics.auth.login(program);
    const skipOtp =
      (loginPromptEnabled && !program.config.enableLoginVerificationPrompt) ||
      (program.type === LoyaltyService.Qlub &&
        !trailingCall &&
        program.internalProgramType !== InternalProgramType.IN_SUB_DISCOUNT);
    const loginCall = (skipOtp: boolean) => {
      return loyalty.auth.login(
        vendor,
        program,
        {
          id: customerID,
          phoneNumber: user?.phoneNumber
        },
        fresh,
        skipOtp
      );
    };
    return loginCall(skipOtp).then(async (res) => {
      const next = async (res: any) => {
        if (res.otpId) setOtpId(res.otpId);
        if (res.tokens?.accessToken && program.config.apiVersion === 3) {
          storeAuthToken({ access: res.tokens?.accessToken, refresh: res.tokens?.refreshToken }, true);
          if (res.profile?.id) {
            setUser(program.id, formatProfile(res.profile));
          } else {
            if (user?.isAuthorized) await refetchProfile();
          }
        }
      };
      if (skipOtp) {
        if (loginPromptEnabled) {
          if (res.isNewUser) {
            await loginCall(false);
          }
          return res;
        }
        if (!res.isNewUser && profile!.accountBalance.nonMonetary > 0) {
          res = await new Promise((resolve, reject) => {
            window.openDialog(
              t(
                "The mobile number you entered is already registered with us. would you like to proceed and add your wallet balance to this profile?"
              ),
              async () => {
                window.closeDialog();
                const newRes = await loginCall(false);
                await next(newRes);
                resolve(newRes);
              },
              () => reject(new Error("proceed_denied"))
            );
          });
        } else {
          res = await loginCall(false);
          await next(res);
        }
      } else {
        await next(res);
      }
      return res;
    });
  };

  const onLoginVerification = async (otp: string, user: Partial<IProfileDetails>) => {
    analytics.auth.submitOTP(program);
    const isNewUser = useAuthStore.getState().isNewUser[program.id];
    await loyalty.auth
      .verify(vendor, program, { phoneNumber: user.phoneNumber }, otp, otpId, isNewUser)
      .then(async (res) => {
        if (!(isNewUser && program.config?.enableRegistrationFlow && program.type !== LoyaltyService.Qlub)) {
          if (program.config.apiVersion === 3) {
            storeAuthToken({ access: res.tokens?.accessToken, refresh: res.tokens?.refreshToken });
          }
          await refetchProfile();
        }
      });
    setTimeout(() => {
      loginVerificationCallback?.();
    }, 0);
    return true;
  };

  const onRegister = async (data: Record<string, any>) => {
    return loyalty.auth.register(vendor, program, data).then(async (res) => {
      await refetchProfile();
      return res;
    });
  };

  const onLogout = async () => {
    setUser(program.id, undefined);
    loyalty.auth.logout(vendor, program);
  };

  const onSheetClose = () => {
    analytics.general.closeSheet(program);
    if (loginPromptEnabled) {
      setLoginPromptEnabled(program.id, false);
    }
  };

  const onWelcomeSheetOpen = () => analytics.auth.welcomeImpression(program);

  return {
    country: vendor.country.code,
    currencyFormat,
    meta: {
      restaurantLogoUrl: program.config?.logo ?? vendor.config.loyaltyProgramLogoUrl ?? vendor.logoBigUrl,
      restaurantLogoAvatarUrl: program.config?.logo ?? vendor.config.loyaltyProgramLogoUrl ?? vendor.logoSmallUrl
    },
    bill: {
      amount: paymentDetails.billNumber?.total,
      commission: paymentDetails.billNumber?.commission,
      share: paymentDetails.billNumber?.yourShare,
      shareCommission: paymentDetails.billNumber?.yourCommission,
      tax: paymentDetails.billLoyalty?.tax,
      remaining: paymentDetails.billNumber?.payableAmount,
      payments: {
        regular: paymentDetails.billNumber?.paid - paymentDetails.billLoyalty?.paid,
        loyalty: paymentDetails.billLoyalty?.paid
      },
      hasDiscounts: hasDiscounts(paymentDetails.bill, paymentDetails._orderItems),
      hasLoyaltyDiscounts: hasQlubLoyaltyDiscounts(paymentDetails.bill)
    },
    program,
    config: {
      dsi: paymentDetails.diningSessionID,
      redemption: {
        amount: Number(paymentDetails?.yourSplitSettings?.loyalty?.amount) || 0,
        points: Number(paymentDetails?.yourSplitSettings?.loyalty?.points) || 0,
        pointIdentifier: getLocaleText(
          program.config?.pointIdentifier ?? vendor.config.loyaltyPointIdentifier ?? "",
          locale,
          Locales.English
        ),
        completed: paymentDetails.yourSplitSettings?.loyalty?.status === "ok"
      },
      events: {
        onLogin,
        onLoginVerification,
        onWelcomeSheetOpen,
        onRegister,
        onSheetClose,
        onLogout
      }
    }
  };
};

export default useAuthComponentProps;
