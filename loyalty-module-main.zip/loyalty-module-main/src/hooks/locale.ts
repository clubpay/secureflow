import { useEffect, useState } from "react";
import { load } from "@/locales";
import { useGlobalStore } from "@/store/global";

const rtlLocales = ["ar"];

const useLocale = (locale?: string) => {
  const { locale: currentLocale, setLocale } = useGlobalStore();

  const [isRTL, setIsRTL] = useState(false);

  useEffect(() => {
    load(locale).then((l) => {
      setLocale(l);
      setIsRTL(rtlLocales.includes(l));
    });
  }, [locale]);

  return { locale: currentLocale, isRTL };
};

export default useLocale;
