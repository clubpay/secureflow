import { useEffect, useMemo } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { osName } from "react-device-detect";
import { default as LoginBanner } from "@/components/Banners/Login";
import { default as Popup } from "@/components/Common/Popup";
import { default as ContactUsWhatsAppButton } from "@/components/ContactUs";
import { default as SubscriptionHamburger } from "@/components/Subscription/Hamburger";
import { WalletType } from "@/components/Wallet";
import { default as WalletFunctionSheet } from "@/components/WalletFunctions";
import { Android, IOS } from "@/constants/common";
import { default as LoyaltyAuth } from "@/drivers/customer/Auth/dynamic";
import { default as Wallet } from "@/drivers/customer/Wallet";
import { useLocale, useSnackbar } from "@/hooks";
import { useEnabledLoyaltyProgram, useProfile } from "@/hooks/api";
import { default as useLoyaltyLoginCallbacks } from "@/hooks/auth/callbacks";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useGlobalStore } from "@/store/global";
import { inflateQlubProfile } from "@/transformers";
import { InternalProgramType } from "@/types/entities/program";
import { pullToRefresh } from "@clubpay/customer-common-module/src/const/events";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";
import { useConfigContext } from "@clubpay/customer-common-module/src/context/config";
import { useLayout } from "@clubpay/customer-common-module/src/context/layout";
import { IMenuItem } from "@clubpay/customer-common-module/src/context/layout/types";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { useQlubRouter } from "@clubpay/customer-common-module/src/hook/router";
import { snackBar } from "@clubpay/customer-common-module/src/hook/snackBar";
import { default as DialogProvider } from "./dialog";
import { queryClient } from "./query";

export * from "./dialog";

function LoyaltySubProvider({ children }: { children: React.ReactNode }) {
  const { setMenuItems, setWidgets, closeDrawer, setLoyaltyProgram } = useLayout();
  const { setForceEnableLogin, setLoginWidgets, profile: qlubProfile, isAuthorizedUser } = useAuth();
  const { triggerSnackBar, closeSnackbar } = snackBar();
  const { program, refetch } = useEnabledLoyaltyProgram();
  const { profile } = useProfile(program);
  const { config } = useConfigContext();
  const { vendor, currencyFormat } = useVendor();
  const { getRouterParam, lang = vendor?.config?.defaultLang, routerPush } = useQlubRouter();

  const locale = useGlobalStore((state) => state.locale);

  const qlubUser = useAuthStore((state) => state.qlubUser);

  useLoyaltyLoginCallbacks();

  useLocale(lang);

  useSnackbar({
    enqueue: triggerSnackBar,
    close: closeSnackbar
  });

  useEffect(() => {
    if (program) {
      useGlobalStore.getState().setSelectedProgram(program);
    }
  }, [program?.id]);

  useEffect(() => {
    if (qlubProfile?.id) {
      useAuthStore.getState().setQlubUser(inflateQlubProfile(qlubProfile as any));
    }
  }, [qlubProfile?.id, qlubProfile?.subscriptions?.length, isAuthorizedUser]);

  const isSubscribed = program?.subscription && qlubUser?.hasSubscription?.(program.subscription);

  const loyaltyMenuItems = useMemo(() => {
    const menuItems: IMenuItem[] = [
      ...(isSubscribed
        ? [
            {
              href: getRouterParam("/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/subscription"),
              title: <SubscriptionHamburger program={program} />,
              keepOnRouteChange: true
            }
          ]
        : []),
      {
        href: getRouterParam("/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/loyalty/venues", {
          utm_source: "app",
          utm_medium: "hamburger_menu"
        }),
        title:
          program?.internalProgramType === InternalProgramType.IN_SUB_DISCOUNT
            ? t("Explore qlub+ Venues")
            : t("Loyalty restaurants"),
        keepOnRouteChange: true
      },
      ...(program?.internalProgramType === InternalProgramType.IN_EARN_BURN
        ? [
            {
              href: getRouterParam("/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/loyalty/transactions"),
              title: t("Loyalty transactions"),
              keepOnRouteChange: true
            }
          ]
        : [])
    ];
    if (profile?.isAuthorized) {
      if (config?.contactUsWhatsAppNumber) {
        const message = `${t("Hi, I'm at")} ${vendor?.name} ${t("and I'm reaching out because")}`;
        menuItems.push({
          href: `https://wa.me/${config?.contactUsWhatsAppNumber}?text=${message}`,
          title: <ContactUsWhatsAppButton />,
          keepOnRouteChange: true
        });
      }
      if (program?.internalProgramType === InternalProgramType.IN_EARN_BURN) {
        setWidgets(
          <>
            <Wallet type={WalletType.Detailed} />
          </>
        );
      }
    }
    return menuItems;
  }, [program, profile?.isAuthorized, lang, vendor?.name, config?.contactUsWhatsAppNumber, isSubscribed]);

  useEffect(() => {
    if (program) {
      setForceEnableLogin(true);
      setMenuItems(loyaltyMenuItems);
      if (program.config.localizedLoginBanner)
        setLoginWidgets(<LoginBanner banner={program.config.localizedLoginBanner} />);
      setLoyaltyProgram(program);
    }
  }, [program, loyaltyMenuItems, locale]);

  useEffect(() => {
    const handler = () => refetch();
    document.addEventListener(pullToRefresh, handler);
    return () => {
      document.removeEventListener(pullToRefresh, handler);
    };
  }, []);

  return (
    <>
      {children}
      <WalletFunctionSheet
        program={program}
        onActionClick={() => {
          let url: string = "";
          if (program?.config?.showQlubAppDownloadLink) {
            if (osName === IOS) {
              url = program.config.qlubAppAppStoreURL ?? url;
            } else if (osName === Android) {
              url = program.config.qlubAppPlayStoreURL ?? url;
            }
            window.location.href = url;
          } else {
            routerPush("/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/loyalty/venues", {
              utm_source: "app",
              utm_medium: "how_it_works_drawer"
            });
          }
          closeDrawer();
        }}
        currencyFormat={currencyFormat}
      />
    </>
  );
}

export function LoyaltyProvider({ children }: { children: React.ReactNode }) {
  return (
    <QueryClientProvider client={queryClient}>
      <DialogProvider>
        <LoyaltySubProvider>{children}</LoyaltySubProvider>
        <LoyaltyAuth />
        <Popup />
      </DialogProvider>
    </QueryClientProvider>
  );
}

export default LoyaltyProvider;
