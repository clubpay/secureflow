import { createContext, useContext, useEffect, useState } from "react";
import { default as Button } from "@/components/Common/Core/Button";
import { t } from "@/locales";
import { Modal } from "@qlub-dev/qlub-kit";
import { default as defaultStyles } from "./dialog.module.scss";

export const dialogTestIds = {
  proceed: "dialog-proceed",
  cancel: "dialog-cancel"
};

interface IOpenArgs {
  proceedText?: string;
  secondaryText?: string;
}

declare global {
  interface Window {
    openDialog: (
      text: string,
      proceedHandler: () => void,
      cancelHandler?: () => void,
      showLoader?: boolean,
      args?: IOpenArgs
    ) => void;
    closeDialog: () => void;
  }
}

interface IDialogContext {
  open: (
    text: string,
    proceedHandler: () => void,
    cancelHandler?: () => void,
    showLoader?: boolean,
    args?: IOpenArgs
  ) => void;
  close: () => void;
}

const DialogContext = createContext<IDialogContext>({} as IDialogContext);

export const DialogProvider = ({ children }: { children: React.ReactNode }) => {
  const [state, updateState] = useState({
    open: false,
    text: "",
    secondaryText: "",
    proceedText: "",
    cancelHandler: () => {},
    proceedHandler: () => {},
    showLoader: false
  });
  const [loading, setLoading] = useState(false);

  const openDialog = (
    text: string,
    proceedHandler: () => void,
    cancelHandler?: () => void,
    showLoader: boolean = false,
    args?: IOpenArgs
  ) => {
    updateState({
      open: true,
      text,
      secondaryText: args?.secondaryText ?? "",
      proceedText: args?.proceedText ?? "",
      proceedHandler,
      cancelHandler: cancelHandler ?? (() => {}),
      showLoader
    });
  };

  const close = () => updateState({ ...state, open: false, showLoader: false });

  useEffect(() => {
    window.openDialog = openDialog;
    window.closeDialog = close;
  }, [state]);

  const onProceed = async () => {
    if (state.showLoader) {
      setLoading(true);
    }
    await state.proceedHandler();
    if (state.showLoader) {
      setLoading(false);
    }
  };

  return (
    <DialogContext.Provider value={{ open: openDialog, close }}>
      <Modal
        open={state.open}
        openHandler={() => {}}
        closeHandler={() => {
          state.cancelHandler();
          close();
        }}
        sx={{
          zIndex: "1301 !important"
        }}
      >
        <div className={defaultStyles["modal-content"]}>
          <div className={defaultStyles["modal-titles"]}>
            <span className={defaultStyles["modal-title"]}>{state.text}</span>
            {state.secondaryText && <span className={defaultStyles["modal-subtitle"]}>{state.secondaryText}</span>}
          </div>
          <div className={defaultStyles["modal-footer"]}>
            <Button
              variant="containedLight"
              onClick={() => {
                state.cancelHandler();
                close();
              }}
              data-testid={dialogTestIds.cancel}
            >
              {t("Cancel")}
            </Button>
            <Button loading={loading} onClick={onProceed} data-testid={dialogTestIds.proceed}>
              {state.proceedText || t("Proceed")}
            </Button>
          </div>
        </div>
      </Modal>
      {children}
    </DialogContext.Provider>
  );
};

export default DialogProvider;

export const useDialog = () => useContext(DialogContext);
