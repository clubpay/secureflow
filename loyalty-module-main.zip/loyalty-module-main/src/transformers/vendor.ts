import { serviceVendorConfigKeys } from "@/constants";
import { LoyaltyService } from "@/types";
import { IRestaurant } from "@clubpay/customer-common-module/src/repository/vendor";

export const extractEnabledService = (vendor?: IRestaurant) => {
  return Object.entries(serviceVendorConfigKeys).find(([, value]) => (vendor?.config as any)?.[value])?.[0] as
    | LoyaltyService
    | undefined;
};
