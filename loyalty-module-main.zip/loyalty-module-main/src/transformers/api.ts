import { useGlobalStore } from "@/store/global";
import { AdditiveCategoryEnum, IPaymentDetailsOrderItems, IProfileDetails } from "@/types";
import { IRestaurant } from "@clubpay/customer-common-module/src/repository/vendor";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";

export const transformItems = (items: IPaymentDetailsOrderItems[]) => {
  return items.map(({ item }) => ({
    id: item.id || item.sig || "-",
    name: item.title,
    quantity: item.qty || "1",
    price: Number(item.secondAltValue || item.value).toFixed(2)
  }));
};

export const constructPayload = (customer: Partial<IProfileDetails>, extras = {}, vendor?: IRestaurant) => {
  const details = useGlobalStore.getState().paymentDetails;
  const billAmount = Number(details.billNumber?.yourShare)?.toFixed(2);
  const payload = {
    id: getSession(),
    dineSessionID: details.diningSessionID,
    loyaltyPayload: {
      customer: {
        id: customer.id,
        uuid: customer.id,
        mobile: customer.phoneNumber,
        phone: customer.phoneNumber,
        firstName: customer.firstName,
        lastName: customer.lastName,
        email: customer.email,
        gender: customer.gender,
        birthday: customer.birthday
      },
      bill: {
        id: details.bill?.id,
        total: details.bill?.total,
        subtotal: details.bill?.subTotal,
        commission: details.bill?.additives
          ?.reduce((acc, { value, category }) => {
            if (category === AdditiveCategoryEnum.Commision) {
              return acc + Number(value);
            }
            return acc;
          }, 0)
          ?.toFixed(2),
        tax: Number(details.billLoyalty?.tax ?? 0).toFixed(2),
        type: "dineIn",
        items: transformItems(details._orderItems ?? []),
        personCount: details.bill?.covers
      },
      payment: {
        currency: vendor?.country?.currencySymbol ?? details?.currency,
        billAmount,
        tipAmount: "0.00",
        totalAmount: billAmount,
        timestamp: details.bill?.updatedAt ? new Date(details.bill?.updatedAt).toISOString() : new Date().toISOString()
      },
      restaurant: {
        name: vendor?.name
      },
      ...extras
    }
  };
  payload.loyaltyPayload.payment.totalAmount = (
    Number(billAmount) + Number(payload.loyaltyPayload.payment.tipAmount)
  ).toFixed(2);
  return payload;
};
