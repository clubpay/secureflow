import dayjs from "dayjs";
import { IProfileDetails, IQlubProfile } from "@/types";
import { ISubscriptionSchema } from "@clubpay/customer-common-module/src/repository/common/subscription/type";

export const formatProfile = (profile: IProfileDetails) => {
  profile.name = profile.name ?? "Anonymous";
  profile.accountNumber = profile.phoneNumber;
  profile.conversionRate =
    profile.accountBalance.nonMonetary === 0 || profile.accountBalance.nonMonetary === undefined
      ? 1
      : +(profile.accountBalance.monetary / profile.accountBalance.nonMonetary)?.toFixed(2);
  profile.isAuthorized = !!(profile.email || profile.phoneNumber) || profile.status === "Live"; // We check status for rotana
  profile.accountBalance ??= { monetary: 0, nonMonetary: 0 };
  profile.accountBalance.nonMonetary ??= 0;
  profile.accountBalance.monetary ??= 0;
  profile.pointsSpent ??= 0;
  profile.pointsEarned ??= 0;
  return profile;
};

export const inflateQlubProfile = (profile: IQlubProfile) => {
  profile.hasSubscription = (subscription: ISubscriptionSchema) => {
    return profile.subscriptions.some(
      (sub) =>
        sub.subscriptionID === subscription.subscriptionID &&
        (sub.status === "active" || (sub.status === "suspended" && dayjs(sub.renewalDate).isAfter(dayjs())))
    );
  };
  return profile;
};
