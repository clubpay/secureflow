import { ILoyaltyProgram } from "@/types/entities/program";
import { IRestaurant } from "@clubpay/customer-common-module/src/repository/vendor";

export const inflateTickitConfigurations = (program: ILoyaltyProgram, vendor: IRestaurant) => {
  program.config.earnWidgetTitle = vendor?.config?.tickitBannerTitle;
  program.config.earnWidgetDescription = vendor?.config?.tickitBannerDescription;
  program.config.apiVersion = 2;
};
