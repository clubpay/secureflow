import { t } from "@/locales";
import { useGlobalStore } from "@/store/global";
import { Locales } from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";
import { getLocaleText } from "@clubpay/customer-common-module/src/component/MultiLocale";
import { IRestaurant } from "@clubpay/customer-common-module/src/repository/vendor";

export const inflateLegacyComoConfigurations = (program: ILoyaltyProgram, vendor: IRestaurant) => {
  const locale = useGlobalStore.getState().locale;
  program.config.readableDisplayName =
    getLocaleText(vendor.config.loyaltyProgramName ?? "", locale, Locales.English) || program.name;
  program.config.readablePointIdentifier =
    getLocaleText(vendor.config.loyaltyPointIdentifier ?? "", locale, Locales.English) || t("Points");
  program.config.logo = vendor.config.loyaltyProgramLogoUrl ?? vendor.logoBigUrl;
  program.config.freezeRegionalLogin = vendor.config.comoV2FreezeRegionalLogin;
  program.config.forceMobileInputLTR = true;
  program.config.enableRegistrationFlow = vendor.config.comoV2EnableRegistrationFlow;
  program.config.registrationFields = vendor.config.comoV2RegistrationFields;
  program.config.requiredRegistrationFields = vendor.config.comoV2RequiredRegistrationFields;
  program.config.registrationTermsLink = vendor.config.comoV2RegistrationTermsLink;
  program.config.displayEarnNote = vendor.config.comoV2DisplayEarnNote;
  program.config.enableLoginPrompt = vendor.config.comoV2EnableLoginPrompt;
  program.config.enableLoginVerificationPrompt = vendor.config.comoV2EnableLoginVerificationPrompt;
  program.config.maxPointsPerTransaction = vendor.config.comoV2MaxRedeemablePoints;
  program.config.minPointsPerTransaction = vendor.config.comoV2MinRedeemablePoints;
  program.config.redeemableAdditives = vendor.config.comoV2RedeemableAdditives;
  program.config.earnWidgetPopup = true;
  program.config.earnWidgetTitle = program.config.isLegacy
    ? vendor?.config?.comoBannerTitle
    : vendor?.config?.comoV2BannerTitle;
  program.config.earnWidgetDescription = program.config.isLegacy
    ? vendor?.config?.comoBannerDescription
    : vendor?.config?.comoV2BannerDescription;
  program.config.apiVersion = 2;
};

export const inflateComoConfigurations = (program: ILoyaltyProgram) => {
  const locale = useGlobalStore.getState().locale;
  program.config.readableDisplayName =
    getLocaleText(program.config.displayName ?? "", locale, Locales.English) || program.name;
  program.config.readablePointIdentifier =
    getLocaleText(program.config.pointIdentifier ?? "", locale, Locales.English) || t("Points");
  program.config.forceMobileInputLTR = true;
  program.config.displayOfferSelectorSheet = true;
  program.config.hideOfferTrigger = true;
  program.config.earnWidgetPopup = true;
  program.config.apiVersion = 3;
};
