import { useGlobalStore } from "@/store/global";
import { Locales } from "@/types";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { getLocaleText } from "@clubpay/customer-common-module/src/component/MultiLocale";

export const inflateQlubConfigurations = (program: ILoyaltyProgram<IQlubConfig>) => {
  const locale = useGlobalStore.getState().locale;
  program.config.earnPointConversionRate ??= 1;
  program.config.burnPointConversionRate ??= 1;
  program.config.readableDiscountTeaserText =
    getLocaleText(program.config.discountTeaserText ?? "", locale, Locales.English) ||
    program.config.discountTeaserText;
  program.config.readableDiscountTeaserValue =
    getLocaleText(program.config.discountTeaserValue ?? "", locale, Locales.English) ||
    program.config.discountTeaserValue;
  if (program.config.subscriptionCompletionPrompt) {
    program.config.readableSubscriptionCompletionPrompt = getLocaleText(
      program.config.subscriptionCompletionPrompt,
      locale,
      Locales.English
    );
  }
  if (program.config.loyaltyBenefits && typeof program.config.loyaltyBenefits === "string") {
    program.config.loyaltyBenefits = JSON.parse(program.config.loyaltyBenefits as any);
  }
  if (program.config.howItWorks && typeof program.config.howItWorks === "string") {
    program.config.howItWorks = JSON.parse(program.config.howItWorks as any);
  }
  if (program.config.cancelSubscriptionReasons && typeof program.config.cancelSubscriptionReasons === "string") {
    program.config.cancelSubscriptionReasons = JSON.parse(program.config.cancelSubscriptionReasons as any);
  }
  program.config.apiVersion = 3;
};
