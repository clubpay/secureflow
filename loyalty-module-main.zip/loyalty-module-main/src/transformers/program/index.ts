import { t } from "@/locales";
import { useGlobalStore } from "@/store/global";
import { Locales, LoyaltyService } from "@/types";
import { ILoyaltyProgram, InternalProgramType } from "@/types/entities/program";
import { getLocaleText } from "@clubpay/customer-common-module/src/component/MultiLocale";
import { IRestaurant, RedeemableAdditives } from "@clubpay/customer-common-module/src/repository/vendor";
import { inflateComoConfigurations, inflateLegacyComoConfigurations } from "./como";
import { inflateQlubConfigurations } from "./qlub";
import { inflateRotanaConfigurations } from "./rotana";
import { inflateTickitConfigurations } from "./tickit";

export const getInternalProgramType = (subscriptionFlowEnabled: boolean, earnBurnFlowEnabled: boolean) => {
  if (subscriptionFlowEnabled && earnBurnFlowEnabled) {
    return InternalProgramType.IN_NONE;
  } else if (subscriptionFlowEnabled) {
    return InternalProgramType.IN_SUB_DISCOUNT;
  } else if (earnBurnFlowEnabled) {
    return InternalProgramType.IN_EARN_BURN;
  }
  return InternalProgramType.IN_NONE;
};

export const inflateLoyaltyProgram = (
  program: ILoyaltyProgram,
  vendor: IRestaurant,
  legacy: boolean = false
): ILoyaltyProgram<any> => {
  const locale = useGlobalStore.getState().locale;
  program.config ??= {} as any;
  program.config.redemptionConfirmationPopup ??= true;
  program.config.isLegacy = legacy;
  if (program.config.loginBanner) {
    program.config.localizedLoginBanner = getLocaleText(program.config.loginBanner, locale, Locales.English);
  }
  if (program.type === LoyaltyService.Como) {
    if (program.name) {
      // This is a check to see if the program is a v3 program
      inflateComoConfigurations(program);
    } else {
      inflateLegacyComoConfigurations(program, vendor);
    }
  } else {
    program.config.readableDisplayName =
      getLocaleText(program.config.displayName ?? "", locale, Locales.English) || program.name;
    program.config.readablePointIdentifier =
      getLocaleText(program.config.pointIdentifier ?? "", locale, Locales.English) || t("Points");
    program.config.forceMobileInputLTR = true;
    program.config.redeemableAdditives = [RedeemableAdditives.Tax];
    if (program.type === LoyaltyService.Rotana) {
      inflateRotanaConfigurations(program);
    }
    if (program.type === LoyaltyService.Tickit) {
      inflateTickitConfigurations(program, vendor);
    }
    if (program.type === LoyaltyService.Qlub) {
      inflateQlubConfigurations(program as any);
      const earnBurnFlowEnabled = program.config.isEarnEnabled || program.config.isBurnEnabled;
      program.internalProgramType = getInternalProgramType(
        !!program.subscription?.options?.isActive && !!vendor.paymentGateways?.find((pg) => pg.name === "checkout"),
        earnBurnFlowEnabled
      );
    }
  }
  return program;
};
