import { ILoyaltyProgram } from "@/types/entities/program";

export const inflateRotanaConfigurations = (program: ILoyaltyProgram) => {
  program.config.disableAutomatedOfferFetch = true;
  program.config.automatedLogin = true;
  program.config.disregardStepForFullRedemption = true;
  program.config.disableFractionalRedemption = true;
  program.config.redeemablePointStep = 2500;
  program.config.limitSingleLoyaltyDiscount = true;
  program.config.limitSingleRedemptionPerCustomer = true;
  program.config.apiVersion = 3;
};
