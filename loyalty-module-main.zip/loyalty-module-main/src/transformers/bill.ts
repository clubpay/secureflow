import { AdditiveCategoryEnum, IPaymentDetailsBill, IPaymentDetailsOrderItems, IPaymentPartyUI } from "@/types";

export const extractBillTax = (bill: IPaymentDetailsBill): number => {
  return Number(
    bill?.tax ??
      bill?.additives
        ?.reduce((acc, item) => {
          if (item.category === "tax") {
            if (item.valueType === "fixed") {
              acc += Number(item.value ?? "0");
            } else {
              acc += (Number(item.value ?? "0") / 100) * Number(bill?.total);
            }
          }
          return acc;
        }, 0)
        ?.toFixed(2) ??
      0
  );
};

export const extractLoyaltyPaidAmount = (parties: IPaymentPartyUI[] = []): number => {
  return parties.reduce((acc, party) => {
    if (party.loyalty?.status === "ok") {
      acc += Number(party.loyalty?.amount ?? 0);
    }
    return acc;
  }, 0);
};

export const hasDiscounts = (bill?: IPaymentDetailsBill, orderItems?: IPaymentDetailsOrderItems[]): boolean => {
  return (
    !!bill?.additives?.find((item) => item.category === AdditiveCategoryEnum.Discount) ||
    !!orderItems?.find((item) => item?.items?.find((item: any) => item?.category === AdditiveCategoryEnum.Discount)) ||
    (Number(bill?.qlubDiscount) || 0) > 0
  );
};

export const hasQlubLoyaltyDiscounts = (bill?: IPaymentDetailsBill): boolean => {
  return !!bill?.additives?.find((item) => item.key.includes("qlub_loyalty_discount"));
};
