import { default as dayjs } from "dayjs";
import { t } from "@/locales";
import { ISubscriptionSchema } from "@clubpay/customer-common-module/src/repository/common/subscription/type";

export const getSubscriptionPeriod = (subscription: ISubscriptionSchema): string => {
  return t(subscription.subscriptionInterval.toString());
};

export const getSubscriptionPeriodAsNoun = (subscription: ISubscriptionSchema): string => {
  return t(
    subscription.subscriptionInterval.toString() === "daily"
      ? "day"
      : subscription.subscriptionInterval.toString().replace(/ly$/, "")
  );
};

export const getSubscriptionFreeMonthPeriod = (subscription: ISubscriptionSchema): string => {
  if (!subscription.options?.subscriptionFreeMonths) return "";
  if (subscription.options.subscriptionFreeMonths === 1) return t("month");
  return `${subscription.options.subscriptionFreeMonths} ${t("months")}`;
};

export const getTrialExpiringDate = (createdAt: string, freeMonths: number = 0) => {
  let trialExpiringDate = dayjs(createdAt);

  if (trialExpiringDate.date() > 27) {
    trialExpiringDate = trialExpiringDate.add(freeMonths + 1, "month").set("date", 1);
  } else {
    trialExpiringDate = trialExpiringDate.add(freeMonths, "month").add(1, "day");
  }

  return trialExpiringDate;
};
