import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";

export const getCashbackValue = (
  billAmount?: number,
  commission?: number,
  earnPointConversionRate?: number,
  burnPointConversionRate?: number,
  currencyFormat?: CurrencyFormat
) => {
  return (
    (((billAmount ?? 0) - (commission ?? 0)) * (earnPointConversionRate ?? 1)) /
    (burnPointConversionRate ?? 1)
  ).toFixed(currencyFormat?.currencyPrecision ?? 2);
};

export const getEarnPercentage = (program: ILoyaltyProgram<IQlubConfig>) => {
  return `${(
    ((program?.config?.earnPointConversionRate ?? 0) / (program?.config?.burnPointConversionRate ?? 1)) *
    100
  ).toFixed(2)}%`;
};

export const getBurnPercentage = (config: IQlubConfig) => {
  if (config?.redeemableBillPercentage) {
    return `${config?.redeemableBillPercentage}%`;
  }
  return `100%`;
};
