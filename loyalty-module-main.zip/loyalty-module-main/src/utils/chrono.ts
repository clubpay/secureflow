import { default as startCase } from "lodash/startCase";
import { ISchedule, IScheduleDate } from "@/types";
import { currentTimeInTimezone } from "./date";

export const checkIfInSchedule = (schedule?: ISchedule, timezone?: string) => {
  if (!schedule || Object.keys(schedule).length === 0) return true;
  const now = currentTimeInTimezone(timezone);
  for (const day of Object.keys(schedule)) {
    const scheduleDate = schedule[day as keyof ISchedule] as IScheduleDate;
    if (startCase(day) === now.format("dddd")) {
      if (!scheduleDate.enabled) return false;
      if (scheduleDate.times) {
        for (const time of scheduleDate.times) {
          if (!time.start || !time.end) continue;
          const [fromHour, fromMinute] = time.start.split(":");
          const [toHour, toMinute] = time.end.split(":");
          if (
            now.isAfter(now.clone().hour(Number(fromHour)).minute(Number(fromMinute)).second(0).millisecond(0)) &&
            now.isBefore(now.clone().hour(Number(toHour)).minute(Number(toMinute)).second(0).millisecond(0))
          )
            return true;
        }
        return false;
      }
    }
  }
  return true;
};
