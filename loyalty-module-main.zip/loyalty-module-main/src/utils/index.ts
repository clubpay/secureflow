export * from "./chrono";
export * from "./date";
export * from "./json";
export * from "./offers";
export * from "./points";
export * from "./rendering";
export * from "./store";
export * from "./string";
export * from "./query";
export * from "./redemption";

export function toFixedHalfUp(num: number, digits: number): string {
  const factor = 10 ** digits;
  return (Math.round(num * factor) / factor).toFixed(digits);
}
