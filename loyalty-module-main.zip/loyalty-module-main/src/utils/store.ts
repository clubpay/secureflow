import { LoyaltyService } from "..";

export const serviceDefaults = (value: any, pickFrom?: Record<string, any>) =>
  Object.values(LoyaltyService).reduce((acc, key) => {
    // @ts-ignore
    acc[key] = typeof value === "function" && pickFrom ? value(pickFrom[key]) : value;
    return acc;
  }, {});
