const mapAlternate = (array: any[], fn1: Function, fn2: Function, thisArg?: any) => {
  let fn = fn1;
  const output = [];
  for (let i = 0; i < array.length; i++) {
    output[i] = fn.call(thisArg, array[i], i, array);
    fn = fn === fn1 ? fn2 : fn1;
  }
  return output;
};

export const insertJSX = (str: string, data: Record<string, any>) => {
  const parts = str.split(/\{\{|\}\}/g);
  return mapAlternate(
    parts,
    (part: string) => <span>{part}</span>,
    (part: string) => data[part]
  );
};
