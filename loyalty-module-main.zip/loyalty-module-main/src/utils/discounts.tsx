import { DiscountValueType, IDiscount } from "@/types";
import { Price } from "@qlub-dev/qlub-kit";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";

export const checkAndReturnDiscountIfApplicable = (discount?: IDiscount, billAmount?: number) => {
  if (!discount) return;
  if (!billAmount || (!discount.maximumBillAmount && !discount.minimumBillAmount)) return discount;
  if (discount.minimumBillAmount && billAmount < discount.minimumBillAmount) return;
  if (discount.maximumBillAmount && billAmount > discount.maximumBillAmount) return;
  return discount;
};

export const getBaseDiscountAmountText = (discount: IDiscount, currencyFormat: CurrencyFormat) => {
  if (discount.valueType === DiscountValueType.PERCENTAGE) {
    return `${discount.amount}%`;
  }
  return <Price value={discount.amount.toString()} currencyFormat={currencyFormat} />;
};
