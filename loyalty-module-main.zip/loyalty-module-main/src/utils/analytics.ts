import { IAppliedDiscount, LoyaltyService } from "@/types";

export function getPaymentSuccessLoyaltyEventArgs(discounts?: IAppliedDiscount[]) {
  const discount = discounts?.[0];

  if (!discount || discount.type !== LoyaltyService.Qlub) {
    return {};
  }

  if (discount.discountType === "Welcome") {
    return {
      isWelcomeDiscount: true,
      welcomeDiscountValue: discount.amount,
      isGeneralDiscount: false,
      generalDiscountValue: 0
    };
  }

  if (discount.discountType === "General") {
    return {
      isWelcomeDiscount: false,
      welcomeDiscountValue: 0,
      isGeneralDiscount: true,
      generalDiscountValue: discount.amount
    };
  }

  return {};
}
