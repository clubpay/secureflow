export const replaceKeys = (str: string, data: Record<string, any>) => {
  return Object.entries(data).reduce((acc: string, [key, value]) => acc.replaceAll(`{{${key}}}`, value), str);
};
