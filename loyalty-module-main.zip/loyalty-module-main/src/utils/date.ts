import dayjs from "dayjs";
import "dayjs/locale/ja";
import "dayjs/locale/pt";
import tz from "dayjs/plugin/timezone";
import utc from "dayjs/plugin/utc";

export const secondsToMSS = (seconds: number) => {
  return new Date(seconds * 1000).toISOString().substring(14, 19);
};

export const currentTimeInTimezone = (timezone?: string) => {
  dayjs.extend(utc);
  dayjs.extend(tz);
  if (timezone) {
    return dayjs().tz(timezone);
  }
  return dayjs();
};
