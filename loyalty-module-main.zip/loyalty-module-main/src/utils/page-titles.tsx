import { useEnabledLoyaltyProgram } from "@/hooks/api";
import { t } from "@/locales";
import { InternalProgramType } from "@/types/entities/program";

export const useLoyaltyPageTitles = () => {
  const { program } = useEnabledLoyaltyProgram();
  return {
    loyalty_restaurants:
      program?.internalProgramType === InternalProgramType.IN_SUB_DISCOUNT
        ? t("Explore qlub+ Venues")
        : t("Loyalty restaurants"),
    loyalty_transactions: t("Loyalty transactions"),
    manage_subscription: t("Manage subscription")
  };
};
