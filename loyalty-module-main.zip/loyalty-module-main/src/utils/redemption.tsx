import { t } from "@/locales";
import { LoyaltyService } from "@/types";
import { Price } from "@qlub-dev/qlub-kit";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";

export const getRedemptionPopupSecondaryText = (
  service: LoyaltyService,
  points: number,
  config: any,
  currencyFormat: CurrencyFormat
) => {
  if (service !== LoyaltyService.Qlub) return "";
  return t("{{amount}} will be deducted from your account now", {
    amount: (
      <Price
        sx={{
          "display": "inline-flex",
          "alignItems": "baseline",
          "gap": "2px",
          "fontSize": "inherit",
          "&>span": { fontSize: "inherit" }
        }}
        value={(Number(points) * config.conversionRate!).toString()}
        currencyFormat={currencyFormat}
      />
    )
  });
};

export const getRedemptionPopupProceedText = (service: LoyaltyService) => {
  return [LoyaltyService.Qlub].includes(service) ? t("Redeem") : undefined;
};
