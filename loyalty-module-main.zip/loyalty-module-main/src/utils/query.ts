import { CUID } from "@/constants";

export const getLoyaltyRedirectionArgs = () => {
  return {
    [CUID]: new URLSearchParams(window.location.search).get(CUID)
  };
};
