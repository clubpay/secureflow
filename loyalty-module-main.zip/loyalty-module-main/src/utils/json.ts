import { KeyValue } from "@/types";

export const prefixKeys = (object: KeyValue, prefix: string) => {
  return Object.keys(object).reduce((acc: KeyValue, key) => {
    acc[`${prefix}${key}`] = object[key];
    return acc;
  }, {});
};

export const prefixValues = (object: KeyValue, prefix: string) => {
  return Object.keys(object).reduce((acc: KeyValue, key) => {
    acc[key] = `${prefix}${object[key]}`;
    return acc;
  }, {});
};
