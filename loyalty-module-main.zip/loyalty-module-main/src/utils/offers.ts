import { t } from "@/locales";
import { ILoyaltyProgram } from "@/types/entities/program";
import { IOffer, LoyaltyService } from "..";

export const getOfferValue = (offer: IOffer, billAmount?: number) => {
  if (!offer.value) return 0;
  if (offer.percentage) {
    return billAmount ? Number(((billAmount * offer.value) / 100).toFixed(2)) : 0;
  }
  return offer.value;
};

export const constructAppliedOfferPopupArgs = (offer: Partial<IOffer>) => {
  return {
    title: t("Congratulations!"),
    subtitle: t("{{offerName}} applied", {
      offerName: offer.name
    }),
    autoCloseDuration: 6000
  };
};

export const translateCombinedOfferName = (combinedOfferName: string) => {
  const result = {
    template: "",
    tier: "",
    value: 0,
    secondaryValue: 0
  };

  const tierMatch = combinedOfferName.match(/^(Exclusive|Select Gold|Select Platinum|Select|\w+)/);
  if (tierMatch) {
    result.tier = tierMatch[0];
  }

  const valueMatches = [...combinedOfferName.matchAll(/(\d+)%/g)].map((match) => parseInt(match[1], 10));

  let template = combinedOfferName.replace(result.tier, "{{tier}}");

  if (valueMatches.length === 1) {
    template = template.replace(/(\d+)%/, "{{value}}");
    result.value = valueMatches[0];
  } else if (valueMatches.length === 2) {
    template = template.replace(/(\d+)%/, "{{value}}").replace(/(\d+)%/, "{{secondaryValue}}");
    result.value = valueMatches[0];
    result.secondaryValue = valueMatches[1];
  }

  result.template = template.trim();
  return t(result.template, {
    tier: t(result.tier),
    value: `${result.value}%`,
    secondaryValue: `${result.secondaryValue}%`
  });
};

export const getAutoApplicableOfferKey = (program: ILoyaltyProgram) => {
  return program.type === LoyaltyService.Como ? "deal" : "offer";
};

export const getManualApplicableOfferKey = (program: ILoyaltyProgram) => {
  return program.type === LoyaltyService.Como ? "gift" : "offer";
};
