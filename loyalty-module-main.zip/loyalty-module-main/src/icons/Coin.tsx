export default (props: React.SVGProps<SVGSVGElement>) => {
  return (
    <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path
        d="M12.7905 19.8945L14.448 18.2355V24.8685"
        stroke="#616475"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12.7949 24.873H16.1009"
        stroke="#616475"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M14.448 31.5C19.9421 31.5 24.396 27.0461 24.396 21.552C24.396 16.0579 19.9421 11.604 14.448 11.604C8.95387 11.604 4.5 16.0579 4.5 21.552C4.5 27.0461 8.95387 31.5 14.448 31.5Z"
        stroke="#616475"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M14.52 7.41453C18.4035 3.52953 24.702 3.53103 28.587 7.41453C32.472 11.298 32.472 17.5965 28.587 21.4815"
        stroke="#616475"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
