export default (props: React.SVGProps<SVGSVGElement>) => {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path d="M2.25 6.75H15.75" stroke="#616475" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M7.1775 9.75H5.25" stroke="#616475" strokeLinecap="round" strokeLinejoin="round" />
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M13.5 14.25H4.5C3.25725 14.25 2.25 13.2428 2.25 12V6C2.25 4.75725 3.25725 3.75 4.5 3.75H13.5C14.7428 3.75 15.75 4.75725 15.75 6V12C15.75 13.2428 14.7428 14.25 13.5 14.25Z"
        stroke="#616475"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
