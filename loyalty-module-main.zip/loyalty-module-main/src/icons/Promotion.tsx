import { SVGProps } from "react";

const Promotion = (props: SVGProps<SVGSVGElement>) => (
  <svg width={20} height={20} viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <g clipPath="url(#clip0_631_31079)">
      <path
        d="m2.913 11.22.995 1.303.215 1.623c.12.9.827 1.608 1.727 1.728l1.627.217 1.302.995c.721.551 1.72.551 2.441 0l1.303-.995h-.001l1.623-.215a2.01 2.01 0 0 0 1.728-1.727l.217-1.627.996-1.302c.55-.721.55-1.72 0-2.441l-.994-1.303-.215-1.623a2.01 2.01 0 0 0-1.727-1.728l-1.627-.217-1.303-.995a2.01 2.01 0 0 0-2.44 0l-1.304.995h.002l-1.624.216a2.01 2.01 0 0 0-1.728 1.727l-.218 1.626-.995 1.303a2.01 2.01 0 0 0 0 2.44m5.337.53 3.5-3.5"
        stroke="currentColor"
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx={11.666} cy={11.666} r={0.833} fill="currentColor" />
      <circle cx={8.333} cy={8.333} r={0.833} fill="currentColor" />
    </g>
    <defs>
      <clipPath id="clip0_631_31079">
        <path fill="#fff" d="M0 0h20v20H0z" />
      </clipPath>
    </defs>
  </svg>
);

export default Promotion;
