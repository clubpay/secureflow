export default (props: React.SVGProps<SVGSVGElement>) => {
  return (
    <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path
        d="M18.0015 14.0625V12.75"
        stroke="#616475"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M18.0015 21.9375V23.25"
        stroke="#616475"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15.7245 21C16.065 21.5565 16.6455 21.942 17.346 21.942H18.003H18.7845C19.803 21.942 20.6265 21.117 20.6265 20.1C20.6265 19.254 20.0505 18.5175 19.2315 18.3105L16.7715 17.6925C15.954 17.487 15.3765 16.749 15.3765 15.903C15.3765 14.8845 16.2015 14.061 17.2185 14.061H18H18.657C19.3575 14.061 19.9365 14.4435 20.277 14.9985"
        stroke="#616475"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M29.706 27.3195V27.3195C25.9485 26.568 22.0725 26.661 18.3555 27.5895L18 27.6795C14.049 28.6665 9.9285 28.7655 5.9355 27.966L5.706 27.9195C5.004 27.78 4.5 27.1635 4.5 26.4495V10.191C4.5 9.24447 5.3655 8.53497 6.294 8.71947V8.71947C10.0515 9.47097 13.9275 9.37797 17.6445 8.44947L18.354 8.27247C22.071 7.34397 25.9485 7.25097 29.7045 8.00247L30.2925 8.11947C30.996 8.26047 31.5 8.87547 31.5 9.59097V25.8495C31.5 26.796 30.6345 27.5055 29.706 27.3195V27.3195Z"
        stroke="#616475"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
