export default (props: React.SVGProps<SVGSVGElement>) => {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M9 15.75V15.75C5.27175 15.75 2.25 12.7283 2.25 9V9C2.25 5.27175 5.27175 2.25 9 2.25V2.25C12.7283 2.25 15.75 5.27175 15.75 9V9C15.75 12.7283 12.7283 15.75 9 15.75Z"
        stroke="#616475"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M10.1932 5.74426C10.8523 6.40327 10.8523 7.47173 10.1932 8.13074C9.53423 8.78975 8.46577 8.78975 7.80676 8.13074C7.14775 7.47173 7.14775 6.40327 7.80676 5.74426C8.46577 5.08525 9.53423 5.08525 10.1932 5.74426"
        stroke="#616475"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12.2408 12.4058C12.075 11.364 11.1795 10.566 10.092 10.566H7.90803C6.81978 10.566 5.92503 11.364 5.75928 12.4058"
        stroke="#616475"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
