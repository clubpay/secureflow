export default (props: React.SVGProps<SVGSVGElement>) => {
  return (
    <svg width={45} height={45} fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <rect width={45} height={45} rx={22.5} fill="#FFC21C" />
      <path
        d="m22.535 16.35-2.16.189-3.398-4.678a2.523 2.523 0 0 1 1.092-3.844c.239-.102.488-.165.736-.194.088-.01.176-.014.268-.014 1.892 0 3.423 1.407 3.423 3.144l.034 5.396h.005Z"
        fill="#7D00D4"
      />
      <path
        d="m22.535 16.35-2.16.189-3.398-4.678a2.523 2.523 0 0 1 1.092-3.844c.239-.102.488-.165.736-.194.088-.01.176-.014.268-.014 1.892 0 3.423 1.407 3.423 3.144l.034 5.396h.005Z"
        fill="#fff"
        fillOpacity={0.28}
      />
      <path
        d="m22.535 16.35 2.092.189 3.398-4.678a2.523 2.523 0 0 0-1.092-3.844 2.665 2.665 0 0 0-.736-.194c-.088-.01-.18-.01-.269-.01-1.891 0-3.422 1.408-3.422 3.145l.034 5.396-.005-.005Z"
        fill="#7D00D4"
      />
      <path d="M9 16.733h18.712v20.459H12.554c-1.96 0-3.554-1.587-3.554-3.538V16.733Z" fill="#fff" />
      <path
        d="M9 16.733h18.712v20.459H12.554c-1.96 0-3.554-1.587-3.554-3.538V16.733Z"
        fill="#7D00D4"
        fillOpacity={0.08}
      />
      <path
        d="M9 16.733h18.712v20.459H12.554c-1.96 0-3.554-1.587-3.554-3.538V16.733Z"
        fill="url(#a)"
        fillOpacity={0.85}
      />
      <path d="M32.193 37.192h-5.046v-20.46L36 16.54v16.858a3.798 3.798 0 0 1-3.807 3.79v.005Z" fill="#fff" />
      <path
        d="M32.193 37.192h-5.046v-20.46L36 16.54v16.858a3.798 3.798 0 0 1-3.807 3.79v.005Z"
        fill="#7D00D4"
        fillOpacity={0.12}
      />
      <path d="M32.193 37.192h-5.046v-20.46L36 16.54v16.858a3.798 3.798 0 0 1-3.807 3.79v.005Z" fill="#fff" />
      <path
        d="M32.193 37.192h-5.046v-20.46L36 16.54v16.858a3.798 3.798 0 0 1-3.807 3.79v.005Z"
        fill="url(#b)"
        fillOpacity={0.36}
      />
      <path
        d="M19.935 16.733h-3.808v20.459h3.808v-20.46ZM32.715 37.192h-2.692V16.67l2.692-.059v20.58Z"
        fill="#7D00D4"
      />
      <defs>
        <linearGradient id="a" x1={18.5} y1={37.691} x2={18.5} y2={16.191} gradientUnits="userSpaceOnUse">
          <stop stopColor="#7D00D4" />
          <stop offset={1} stopColor="#7D00D4" stopOpacity={0} />
        </linearGradient>
        <linearGradient id="b" x1={31.573} y1={16.539} x2={31.573} y2={37.192} gradientUnits="userSpaceOnUse">
          <stop stopColor="#7D00D4" />
          <stop offset={1} stopColor="#7D00D4" />
        </linearGradient>
      </defs>
    </svg>
  );
};
