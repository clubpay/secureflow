export default (props: React.SVGProps<SVGSVGElement>) => {
  return (
    <svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <g clip-path="url(#clip0_3016_34454)">
        <path
          d="M8.91202 14.4305L3.57869 12.6527C3.3132 12.5642 3.08229 12.3945 2.91867 12.1674C2.75504 11.9404 2.66699 11.6677 2.66699 11.3878V3.83431C2.66699 3.62304 2.7172 3.41479 2.81347 3.22673C2.90974 3.03867 3.04932 2.87618 3.22071 2.75265C3.39211 2.62912 3.5904 2.54809 3.79925 2.51623C4.0081 2.48436 4.22154 2.50259 4.42197 2.5694L9.7553 4.34717C10.0208 4.43567 10.2517 4.60545 10.4153 4.83247C10.5789 5.05949 10.667 5.33224 10.667 5.61209V13.1656C10.667 13.3769 10.6168 13.5851 10.5205 13.7732C10.4242 13.9612 10.2847 14.1237 10.1133 14.2473C9.94188 14.3708 9.74359 14.4518 9.53473 14.4837C9.32588 14.5155 9.11245 14.4973 8.91202 14.4305Z"
          stroke="white"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path d="M4.66699 6.5L8.66699 7.83333" stroke="white" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M4.66699 9.1665L8.66699 10.4998" stroke="white" stroke-linecap="round" stroke-linejoin="round" />
        <path
          d="M4 2.5H12C12.3536 2.5 12.6928 2.64048 12.9428 2.89052C13.1929 3.14057 13.3333 3.47971 13.3333 3.83333V11.1667C13.3333 11.5203 13.1929 11.8594 12.9428 12.1095C12.6928 12.3595 12.3536 12.5 12 12.5H10.6667"
          stroke="white"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </g>
      <defs>
        <clipPath id="clip0_3016_34454">
          <rect width="16" height="16" fill="white" transform="translate(0 0.5)" />
        </clipPath>
      </defs>
    </svg>
  );
};
