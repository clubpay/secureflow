export default (props: React.SVGProps<SVGSVGElement>) => {
  return (
    <svg width="19" height="18" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <circle cx="9.5" cy="9" r="7.5" fill="#00A789" />
      <path
        d="M12.5 7L8.375 10.75L6.5 9.04545"
        stroke="white"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
