import { default as startCase } from "lodash/startCase";
import { default as IOSSwitch } from "@/components/Common/Core/IOSSwitch";
import { default as Price } from "@/components/Common/Price";
import { t } from "@/locales";
import { IBill, IRedemptionOptions } from "@/types";
import { Box, useTheme } from "@mui/material";
import { Divider } from "@qlub-dev/qlub-kit";
import defaultStyles from "./details.common.module.scss";

export const testIds = {
  amount: "redemption-amount",
  points: "redemption-points"
};

export interface RedemptionDetailProps extends Omit<IRedemptionOptions, "bill"> {
  bill?: IBill;
}

const RedemptionDetailsDefault: React.FC<RedemptionDetailProps> = ({
  currencyFormat,
  config,
  meta
}: RedemptionDetailProps) => {
  return (
    <>
      <div className={defaultStyles.root}>
        <div className={defaultStyles.info}>
          <span>{t("You redeemed")}</span>
          {defaultStyles.logo && meta?.restaurantLogoAvatarUrl ? (
            <img className={defaultStyles.logo} src={meta?.restaurantLogoAvatarUrl} alt="logo" />
          ) : (
            <div />
          )}
        </div>
        <div className={defaultStyles.amount}>
          <span data-testid={testIds.points}>
            {config.redemption?.points}&nbsp;{config.redemption?.pointIdentifier}
          </span>
          <span data-testid={testIds.amount} className={defaultStyles.value}>
            -
            <Price value={config.redemption?.amount?.toString()} currencyFormat={currencyFormat} />
          </span>
        </div>
      </div>
      <Box className={defaultStyles.divider}>
        <Divider type="fullWidth" />
      </Box>
    </>
  );
};

const RedemptionDetailsToggle: React.FC<RedemptionDetailProps> = ({
  currencyFormat,
  config,
  program
}: RedemptionDetailProps) => {
  const theme = useTheme();

  return (
    <>
      <div className={defaultStyles["toggle-root"]}>
        <div className={defaultStyles["wallet-info"]}>
          <span style={{ color: theme.palette.primary.main }}>{program.config.readableDisplayName}</span>
          <span>{startCase(t("wallet"))}</span>
        </div>
        <div className={defaultStyles["redeem-amount"]}>
          <div>
            <span data-testid={testIds.amount}>
              <Price value={config.redemption?.amount?.toString()} currencyFormat={currencyFormat} />
            </span>
            <span>{t("Redeem")}</span>
          </div>
          <IOSSwitch checked />
        </div>
      </div>
      <Box className={defaultStyles.divider}>
        <Divider type="fullWidth" />
      </Box>
    </>
  );
};

const RedemptionDetailsCommon: React.FC<RedemptionDetailProps> = (props: RedemptionDetailProps) => {
  if (props.program.config.useToggle) return <RedemptionDetailsToggle {...props} />;
  return <RedemptionDetailsDefault {...props} />;
};

export default RedemptionDetailsCommon;
