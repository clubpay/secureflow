import { Suspense, lazy } from "react";
import { LazyComponentInventory } from "@/types";
import { RedemptionDetailProps } from "./Common";

export { testIds } from "./Common";

const Inventory: LazyComponentInventory = {
  default: lazy(() => import("./Common"))
};

interface BaseComponentProps extends Omit<RedemptionDetailProps, "config"> {
  config: Partial<RedemptionDetailProps["config"]>;
}

const BaseComponent: React.FC<BaseComponentProps> = (props) => {
  const Component: React.FC<any> = Inventory[props.program.type!] || Inventory.default;
  switch (props.program.type) {
    default:
      return <Component {...props} />;
  }
};

const RedemptionDetails = (props: BaseComponentProps) => {
  return (
    <Suspense fallback={null}>
      <BaseComponent {...props} />
    </Suspense>
  );
};

export default RedemptionDetails;
