import { useEffect, useState } from "react";
import { default as classNames } from "classnames";
import { default as startCase } from "lodash/startCase";
import { default as BottomSheet } from "@/components/Common/Core/BottomSheet";
import { default as Button } from "@/components/Common/Core/Button";
import { default as EarnNote } from "@/components/Common/EarnNote";
import { default as Price } from "@/components/Common/Price";
import { useRedemptionCalculations } from "@/hooks";
import { genericSnackbarOptions } from "@/hooks/snackbar";
import { Coin, CoinGrid, CreditCard, Dollar, User, Warning } from "@/icons";
import { t } from "@/locales";
import { useDialog } from "@/providers/dialog";
import { useAuthStore } from "@/store/auth";
import { useCheckoutStore } from "@/store/checkout";
import { useGlobalStore } from "@/store/global";
import { IRedemptionOptions, LoyaltyService } from "@/types";
import { getRedemptionPopupProceedText, getRedemptionPopupSecondaryText } from "@/utils";
import { OutlinedInput } from "@mui/material";
import { default as defaultStyles } from "./checkout.common.module.scss";

export const testIds = {
  redeem: "checkout-redeem-btn",
  input: "checkout-redeem-input",
  back: "checkout-back",
  sheet: "checkout-sheet",
  proceedToPay: "checkout-proceed-to-pay",
  accountBalanceWorth: "checkout-account-balance-worth",
  accountBalancePoints: "checkout-account-balance-points",
  yourBill: "checkout-your-bill",
  warningText: "checkout-warning-text",
  redeemingAmount: "checkout-redeeming-amount",
  min: "checkout-min",
  max: "checkout-max"
};

const Checkout: React.FC<IRedemptionOptions> = ({ config, program, ...props }: IRedemptionOptions) => {
  const openSheet = useCheckoutStore((state) => state.openSheet);

  const sheetOpen = useCheckoutStore((state) => state.sheetOpen[program.id]);

  useEffect(() => {
    if (sheetOpen) {
      config.events?.onWalletOpen?.();
    }
  }, [sheetOpen]);

  const onBackHandler = () => {
    openSheet(program.id, false);
    config.events?.onSheetClose?.();
  };

  return (
    <BottomSheet
      open={sheetOpen}
      headerImgUrl={props.meta?.restaurantLogoUrl}
      className={defaultStyles.content}
      onBackHandler={onBackHandler}
      backButtonProps={{ "data-testid": testIds.back }}
      data-testid={testIds.sheet}
    >
      <Content config={config} program={program} {...props} />
    </BottomSheet>
  );
};

const Content: React.FC<IRedemptionOptions> = ({ bill, currencyFormat, config, program }: IRedemptionOptions) => {
  const [loading, setLoading] = useState(false);

  const openPopup = useGlobalStore().popup.openPopup;

  const { accountBalance, min, max, maxIgnoringBalance, lowBalance, cannotRedeem, cannotRedeemErrorMessage } =
    useRedemptionCalculations({ bill, currencyFormat, config, program });

  const { openSheet, setPoints } = useCheckoutStore();

  const user = useAuthStore((state) => state.user[program.id]);

  const points = useCheckoutStore((state) => state.points[program.id]) ?? max;

  const error = useCheckoutStore((state) => state.error[program.id]);

  const { open: openDialog, close: closeDialog } = useDialog();

  const redeem = () => {
    const next = () => {
      openSheet(program.id, false);
      openPopup({
        title: t("Congratulations!"),
        subtitle: t("You have redeemed {{points}} Points and saved {{amount}}", {
          points,
          amount: (
            <Price
              sx={{
                "display": "inline-flex",
                "alignItems": "baseline",
                "gap": "2px",
                "fontSize": "inherit",
                "&>span": { fontSize: "inherit" }
              }}
              value={(points * config.conversionRate!).toString()}
              currencyFormat={currencyFormat}
            />
          )
        }),
        autoCloseDuration: 5000
      });
    };
    if (config.events?.onRedemption) {
      setLoading(true);
      config.events
        ?.onRedemption?.({
          points: Number(points),
          maxRedeemablePoints: max,
          maxRedeemablePointsIgnoringBalance: maxIgnoringBalance,
          maxRedeemableValue: Number((max * config.conversionRate!).toFixed(currencyFormat.currencyPrecision))
        })
        ?.then(next)
        .catch((err) => {
          if (!["cannot_redeem_at_this_time", "lock_failed", "bill_is_updated"].includes(err.message)) {
            window.snackbar?.enqueue?.(t("Redemption failed"), {
              variant: "error",
              ...genericSnackbarOptions
            });
          }
          throw err;
        })
        .finally(() => setLoading(false));
    } else {
      next();
    }
  };

  const onRedeem = () => {
    config.events?.onRedemptionClick?.();
    if (program.config.redemptionConfirmationPopup) {
      openDialog(
        t("Do you want to proceed with the redemption?"),
        () => {
          closeDialog();
          setTimeout(redeem, 0);
          config.events?.onRedemptionConfirm?.();
        },
        () => {
          config.events?.onRedemptionCancel?.();
        },
        false,
        {
          secondaryText: getRedemptionPopupSecondaryText(program.type, points, config, currencyFormat),
          proceedText: getRedemptionPopupProceedText(program.type)
        }
      );
    } else {
      redeem();
    }
  };

  const onRedeemAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const maxDecimals = currencyFormat!.currencyPrecision!;
    const decimalRegex = new RegExp(`^(\\d+)(\\.\\d{0,${maxDecimals}})?$`);
    const endsWithDotRegex = /^(\d+)\.$/;
    const val = e.target.value;
    if (val === "" || decimalRegex.test(val) || endsWithDotRegex.test(val)) {
      setPoints(program.id, program.config.disableFractionalRedemption ? Number(e.target.value) : e.target.value);
    }
  };

  const handleBlur = () => {
    const val = points.toString();
    if (val.endsWith(".")) {
      const newVal = val.slice(0, -1);
      setPoints(program.id, Number(newVal));
    }
    if (program.config.redeemablePointStep && (program.config.disregardStepForFullRedemption ? points !== max : true)) {
      const remainder = points % program.config.redeemablePointStep!;
      if (remainder > 0) {
        setPoints(program.id, points - remainder);
      }
    }
  };

  const onBackHandler = () => {
    openSheet(program.id, false);
    config.events?.onSheetClose?.();
  };

  return (
    <>
      <div className={defaultStyles.header} style={{ paddingTop: !error ? "22px" : "0px" }}>
        {error && (
          <div className={defaultStyles.error}>
            <Warning />
            <span>{error}</span>
          </div>
        )}
        <div className={defaultStyles["account-info-wrapper"]}>
          <div className={defaultStyles["account-info"]}>
            <div className={defaultStyles["amount-info"]}>
              <div className={defaultStyles["amount-container"]}>
                <div className={defaultStyles["amount-col"]}>
                  <span data-testid={testIds.accountBalancePoints}>
                    {accountBalance.toFixed(currencyFormat.currencyPrecision)}
                  </span>
                  <span>{t("Points")}</span>
                </div>
                <Coin />
              </div>
              <div className={defaultStyles["amount-container"]}>
                <div className={defaultStyles["amount-col"]}>
                  <span data-testid={testIds.accountBalanceWorth}>
                    <Price
                      value={(accountBalance * config.conversionRate! || 0).toString()}
                      currencyFormat={currencyFormat}
                    />
                  </span>
                  <span>{t("Worth")}</span>
                </div>
                <Dollar />
              </div>
            </div>
            <div className={defaultStyles["personal-info"]}>
              <div className={classNames(defaultStyles["name"], user?.tier && defaultStyles["center"])}>
                <User />
                <span>{user?.name}</span>
              </div>
              {user?.tier && (
                <div className={classNames(defaultStyles["tier"])}>
                  <CoinGrid />
                  <span>{startCase(user?.tier?.toLowerCase())}</span>
                </div>
              )}
              <div className={classNames(defaultStyles["account-number"], user?.tier && defaultStyles["center"])}>
                <CreditCard />
                <span>{user?.accountNumber || "N/A"}</span>
              </div>
            </div>
          </div>
        </div>
        <div className={defaultStyles["bill-info"]}>
          <span>{t("Your bill")}</span>
          <span data-testid={testIds.yourBill}>
            <Price value={bill?.share?.toString()} currencyFormat={currencyFormat} />
          </span>
        </div>
        {(lowBalance || cannotRedeem) && (
          <div className={defaultStyles["insufficient-balance"]}>
            <span data-testid={testIds.warningText}>{cannotRedeemErrorMessage}</span>
          </div>
        )}
        {!lowBalance && !cannotRedeem && (
          <div className={defaultStyles["input-section"]}>
            <div className={defaultStyles.info}>
              <span>{t("You are redeeming")}</span>
              <span data-testid={testIds.redeemingAmount}>
                <Price value={(points * config.conversionRate!)?.toString()} currencyFormat={currencyFormat} />
              </span>
            </div>
            <div className={defaultStyles["input-wrapper"]}>
              <OutlinedInput
                className={defaultStyles.input}
                placeholder={t("Points")}
                value={points}
                onChange={onRedeemAmountChange}
                inputProps={{
                  "inputMode": "decimal",
                  "data-testid": testIds.input
                }}
                onBlur={handleBlur}
              />
              <span className={defaultStyles["input-label"]}>{t("Points")}</span>
            </div>
            <div className={defaultStyles.limits}>
              {min > 0 ? (
                <span style={{ textAlign: "start" }}>
                  {t("Min")}:&nbsp;
                  <span className={defaultStyles["point-value"]} data-testid={testIds.min}>
                    {min} {t("Points")}&nbsp;
                    <Price
                      value={(min * config.conversionRate!).toString()}
                      currencyFormat={currencyFormat}
                      leading="("
                      trailing=")"
                    />
                  </span>
                </span>
              ) : (
                <div />
              )}
              {max ? (
                <span style={{ textAlign: "end" }}>
                  {t("Max")}:&nbsp;
                  <span className={defaultStyles["point-value"]} data-testid={testIds.max}>
                    {max.toFixed(currencyFormat.currencyPrecision)} {t("Points")}&nbsp;
                    <Price
                      value={(max * config.conversionRate!).toString()}
                      currencyFormat={currencyFormat}
                      leading="("
                      trailing=")"
                    />
                  </span>
                </span>
              ) : (
                <div />
              )}
            </div>
          </div>
        )}
      </div>
      <div className={defaultStyles.footer}>
        {!lowBalance && !cannotRedeem ? (
          <>
            {program.config.displayEarnNote ? (
              <EarnNote program={program} style={{ marginLeft: 0, marginBottom: 0 }} />
            ) : (
              <span>{t("You will earn points after payment")}</span>
            )}
            <Button
              onClick={onRedeem}
              disabled={points < min || points > max || !points}
              loading={loading}
              data-testid={testIds.redeem}
            >
              {t("Redeem")}
            </Button>
            {program.type === LoyaltyService.Como && (
              <>
                <span>{t("OR")}</span>
                <Button
                  onClick={onBackHandler}
                  variant="outlined"
                  style={{ color: "black", fontWeight: 500 }}
                  data-testid={testIds.proceedToPay}
                >
                  {t("Proceed to Pay")}
                </Button>
              </>
            )}
          </>
        ) : (
          <Button onClick={onBackHandler} data-testid={testIds.proceedToPay}>
            {t("Proceed to Pay")}
          </Button>
        )}
      </div>
    </>
  );
};

export default Checkout;
