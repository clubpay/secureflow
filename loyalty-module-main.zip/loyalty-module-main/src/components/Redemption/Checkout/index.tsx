import { lazy } from "react";
import { IRedemptionOptions, LazyComponentInventory } from "@/types";

export { testIds } from "./Common";

const Inventory: LazyComponentInventory = {
  default: lazy(() => import("./Common"))
};

const Checkout: React.FC<IRedemptionOptions> = (props) => {
  const Component: React.FC<any> = Inventory[props!.program.type!] || Inventory.default;
  switch (props?.program.type) {
    default:
      return <Component {...props} />;
  }
};

export default Checkout;
