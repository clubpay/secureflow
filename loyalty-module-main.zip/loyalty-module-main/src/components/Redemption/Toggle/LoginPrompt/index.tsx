import { default as Price } from "@/components/Common/Price";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { IRedemptionOptions } from "@/types";
import { getCashbackValue } from "@/utils";
import defaultStyles from "./login.prompt.module.scss";

const LoginPrompt: React.FC<IRedemptionOptions> = ({ bill, currencyFormat, program }: IRedemptionOptions) => {
  const openLoginSheet = useAuthStore((state) => state.openLoginSheet);
  const onLoginClick = () => openLoginSheet(program.id, true);
  return (
    <div className={defaultStyles.root}>
      <div className={defaultStyles.wallet}>
        <span>{program.config.readableDisplayName}</span>
        <span>{t("wallet")}</span>
      </div>
      <span className={defaultStyles.prompt}>
        {t("{{login}} to earn {{amount}} on this bill", {
          login: (
            <span className={defaultStyles.login} onClick={onLoginClick}>
              {t("Login")}
            </span>
          ),
          amount: (
            <span className={defaultStyles.price}>
              {
                <Price
                  value={getCashbackValue(
                    bill?.amount,
                    bill?.commission,
                    program.config.earnPointConversionRate,
                    program.config.burnPointConversionRate,
                    currencyFormat
                  )?.toString()}
                  currencyFormat={currencyFormat}
                />
              }
            </span>
          )
        })}
      </span>
    </div>
  );
};

export default LoginPrompt;
