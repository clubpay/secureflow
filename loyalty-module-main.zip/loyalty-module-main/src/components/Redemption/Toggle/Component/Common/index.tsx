import { forwardRef, useEffect, useState } from "react";
import { default as startCase } from "lodash/startCase";
import { default as CannotRedeem } from "@/components/Common/CannotRedeem";
import { default as IOSSwitch } from "@/components/Common/Core/IOSSwitch";
import { default as Price } from "@/components/Common/Price";
import { useRedemptionCalculations } from "@/hooks";
import { genericSnackbarOptions } from "@/hooks/snackbar";
import { t } from "@/locales";
import { useDialog } from "@/providers/dialog";
import { useAuthStore } from "@/store/auth";
import { useCheckoutStore } from "@/store/checkout";
import { useGlobalStore } from "@/store/global";
import { IRedemptionOptions } from "@/types";
import { getRedemptionPopupProceedText, getRedemptionPopupSecondaryText } from "@/utils";
import { default as Collapse } from "@mui/material/Collapse";
import { default as defaultStyles } from "./toggle.common.module.scss";

export const testIds = {
  redeem: "checkout-redeem-btn",
  input: "checkout-redeem-input",
  back: "checkout-back",
  sheet: "checkout-sheet",
  proceedToPay: "checkout-proceed-to-pay",
  accountBalanceWorth: "checkout-account-balance-worth",
  accountBalancePoints: "checkout-account-balance-points",
  yourBill: "checkout-your-bill",
  warningText: "checkout-warning-text",
  redeemingAmount: "checkout-redeeming-amount"
};

const Toggle = forwardRef<HTMLDivElement, IRedemptionOptions>(({ bill, currencyFormat, config, program }, ref) => {
  const openPopup = useGlobalStore().popup.openPopup;

  const [toggled, setToggled] = useState(false);

  const { max, maxIgnoringBalance, lowBalance, cannotRedeem, cannotRedeemErrorMessage } = useRedemptionCalculations({
    bill,
    currencyFormat,
    config,
    program
  });

  const openLoginSheet = useAuthStore((state) => state.openLoginSheet);

  const setLoginVerificationCallback = useAuthStore((state) => state.setLoginVerificationCallback);

  const setSelectedProgram = useGlobalStore((state) => state.setSelectedProgram);

  const { open: openDialog, close: closeDialog } = useDialog();

  const user = useAuthStore((state) => state.user[program.id]);

  const points = useCheckoutStore((state) => state.points[program.id]) ?? max;

  useEffect(() => {
    if (config?.redemption?.completed) {
      setToggled(true);
    }
  }, [config?.redemption?.completed]);

  const redeem = async () => {
    const next = () => {
      openPopup({
        title: t("Congratulations!"),
        subtitle: t("You have redeemed {{amount}}", {
          amount: (
            <Price
              sx={{
                "display": "inline-flex",
                "alignItems": "baseline",
                "gap": "2px",
                "fontSize": "inherit",
                "&>span": { fontSize: "inherit" }
              }}
              value={(Number(points) * config.conversionRate!).toString()}
              currencyFormat={currencyFormat}
            />
          )
        }),
        autoCloseDuration: 5000
      });
    };
    if (Number(points) >= max) {
      if (config.events?.onRedemption) {
        await config.events
          ?.onRedemption?.({
            points: Number(points),
            maxRedeemablePoints: max,
            maxRedeemablePointsIgnoringBalance: maxIgnoringBalance,
            maxRedeemableValue: Number((max * config.conversionRate!).toFixed(currencyFormat.currencyPrecision))
          })
          ?.then(next)
          .catch((err) => {
            setToggled(false);
            if (!["cannot_redeem_at_this_time", "lock_failed", "bill_is_updated"].includes(err.message)) {
              window.snackbar?.enqueue?.(t("Redemption failed"), {
                variant: "error",
                ...genericSnackbarOptions
              });
            }
            throw err;
          });
      } else {
        next();
      }
    } else {
      setToggled(false);
    }
  };

  const onToggle = (_: React.ChangeEvent<HTMLInputElement>, value: boolean) => {
    setToggled(value);
    if (value) {
      config.events?.onTriggerClick?.();
      const next = async () => {
        if (user?.isAuthorized) {
          await redeem();
        } else {
          setTimeout(() => {
            setSelectedProgram(program);
            openLoginSheet(program.id, true);
            setLoginVerificationCallback(program.id, async () => {
              await redeem();
            });
            setToggled(false);
          }, 0);
        }
      };
      if (program.config.redemptionConfirmationPopup) {
        openDialog(
          t("Do you want to proceed with the redemption?"),
          async () => {
            await next().catch(() => {});
            setTimeout(() => {
              closeDialog();
            }, 0);
            config.events?.onRedemptionConfirm?.();
          },
          () => {
            config.events?.onRedemptionCancel?.();
            setToggled(false);
          },
          true,
          {
            secondaryText: getRedemptionPopupSecondaryText(program.type, points, config, currencyFormat),
            proceedText: getRedemptionPopupProceedText(program.type)
          }
        );
      } else {
        next();
      }
    }
  };

  const disableRedemption = bill?.hasDiscounts && program.config.disableRedemptionIfDiscountAvailable;

  if (disableRedemption) {
    return <CannotRedeem message={t("Cashback is not available as there is a discount on the bill")} />;
  }

  const worth = max * config.conversionRate!;

  return (
    <div ref={ref} className={defaultStyles.root}>
      <div>
        <div className={defaultStyles["wallet-info"]}>
          <span>{program.config.readableDisplayName}</span>
          <span>{startCase(t("wallet"))}</span>
        </div>
        <div className={defaultStyles["wallet-balance"]}>
          <div>
            <span data-testid={testIds.redeemingAmount}>
              <Price value={worth?.toString()} currencyFormat={currencyFormat} />
            </span>
            <span>{t("Redeem")}</span>
          </div>
          <IOSSwitch
            checked={toggled}
            disabled={
              (user?.isAuthorized
                ? lowBalance || cannotRedeem
                : lowBalance && (user?.accountBalance.nonMonetary ?? 0) > 0) || worth === 0
            }
            onChange={onToggle}
          />
        </div>
      </div>
      <div className={defaultStyles["error-container"]}>
        <Collapse
          in={
            (user?.isAuthorized || (user?.accountBalance.nonMonetary ?? 0) > 0) &&
            bill.share > 0 &&
            (lowBalance || cannotRedeem)
          }
        >
          <div className={defaultStyles.error}>
            <span>{cannotRedeemErrorMessage}</span>
          </div>
        </Collapse>
      </div>
    </div>
  );
});

export default Toggle;
