import { lazy, useRef } from "react";
import { useVisibility } from "@/hooks";
import { IRedemptionOptions, LazyComponentInventory } from "@/types";

export { testIds } from "./Common";

const Inventory: LazyComponentInventory = {
  default: lazy(() => import("./Common"))
};

const Toggle: React.FC<IRedemptionOptions> = (props) => {
  const ref = useRef<HTMLButtonElement>(null);

  useVisibility(ref, () => {
    props.config?.events?.onRedemptionTriggerVisible?.();
  });

  const Component: React.FC<any> = Inventory[props.program.type!] || Inventory.default;
  switch (props.program.type) {
    default:
      return <Component ref={ref} {...props} />;
  }
};

export default Toggle;
