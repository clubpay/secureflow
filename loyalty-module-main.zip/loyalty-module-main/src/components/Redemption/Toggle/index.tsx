import { Suspense } from "react";
import { defaults } from "@/constants";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { ITriggerOptions } from "@/types";
import { default as ToggleComponent } from "./Component";
import LoginPrompt from "./LoginPrompt";

const Toggle: React.FC<ITriggerOptions> = (props: any) => {
  const user = useAuthStore((state) => state.user[props.program.id]);

  if (!user?.isAuthorized && (user?.accountBalance.nonMonetary ?? 0) <= 0) return <LoginPrompt {...props} />;

  return (
    <Suspense fallback={null}>
      {!props.config.redemption?.completed && (
        <ToggleComponent
          {...(props as any)}
          currencyFormat={{
            ...props.currencyFormat,
            cs: props.currencyFormat?.cs ?? defaults.currency.symbol,
            currencyPrecision: props.currencyFormat?.currencyPrecision ?? defaults.currency.precision
          }}
          country={props.country ?? defaults.country}
          bill={{
            amount: props.bill?.amount ?? 0,
            commission: props.bill?.commission ?? 0,
            share: props.bill?.share ?? 0,
            shareCommission: props.bill?.shareCommission ?? 0,
            tax: props.bill?.tax ?? 0,
            remaining: props.bill?.remaining,
            payments: {
              regular: props.bill?.payments?.regular ?? 0,
              loyalty: props.bill?.payments?.loyalty ?? 0
            },
            hasDiscounts: props.bill?.hasDiscounts ?? false,
            hasLoyaltyDiscounts: props.bill?.hasLoyaltyDiscounts ?? false
          }}
          config={{
            ...props.config,
            conversionRate: user?.conversionRate ?? 1,
            redemption: {
              ...props.config?.redemption,
              pointIdentifier: props.config?.redemption?.pointIdentifier ?? t("loyalty")
            },
            limits: {
              ...props.config?.limits,
              min: props.config?.limits?.min ?? 0
            },
            redeemableAdditives: props.config?.redeemableAdditives ?? []
          }}
          data-testid={`redemption-toggle`}
        />
      )}
    </Suspense>
  );
};

export default Toggle;
