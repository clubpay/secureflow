import classNames from "classnames";
import { Chip } from "@mui/material";
import styles from "./twincard.module.scss";

interface ICardElement {
  title: string;
  value: number;
  label?: {
    text: string;
    variant?: "success" | "error" | "warning" | "info";
  };
}

interface IProps extends React.HTMLAttributes<HTMLDivElement> {
  precision?: number;
  e1: ICardElement;
  e2: ICardElement;
}

const TwinCard = ({ e1, e2, precision }: IProps) => {
  const e1LabelColor = e1.label?.variant ?? "success";
  const e2LabelColor = e2.label?.variant ?? "error";

  return (
    <div className={styles.root}>
      <div>
        <span className={styles.title}>{e1.title}</span>
        <div>
          <span className={styles.value}>{Number(e1.value.toFixed(precision ?? 0)).toLocaleString()}</span>
          {e1.label && (
            <Chip
              label={e1.label?.text}
              color={e1LabelColor}
              size="small"
              className={classNames(e1LabelColor === "success" && styles.success)}
            />
          )}
        </div>
      </div>
      <div>
        <span className={styles.title}>{e2.title}</span>
        <div>
          <span className={styles.value}>{Number(e2.value.toFixed(precision ?? 0)).toLocaleString()}</span>
          {e2.label && (
            <Chip
              label={e2.label?.text}
              color={e2LabelColor}
              size="small"
              className={classNames(e2LabelColor === "success" && styles.success)}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default TwinCard;
