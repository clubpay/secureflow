import styles from "./card.module.scss";

interface IProps extends React.HTMLAttributes<HTMLDivElement> {
  title: string;
  subtitle?: string;
  value: number;
  precision?: number;
  icon?: React.ReactNode;
}

const Card = ({ title, subtitle, value, precision, icon }: IProps) => {
  return (
    <div className={styles.root}>
      <div className={styles["data-container"]}>
        <span className={styles.title}>{title}</span>
        {subtitle && <span className={styles.subtitle}>{subtitle}</span>}
        <span className={styles.value}>{Number(value.toFixed(precision ?? 0)).toLocaleString()}</span>
      </div>
      {icon && <div className={styles.icon}>{icon}</div>}
    </div>
  );
};

export default Card;
