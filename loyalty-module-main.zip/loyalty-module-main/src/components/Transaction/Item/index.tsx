import { default as dayjs } from "dayjs";
import { default as Price } from "@/components/Common/Price";
import { t } from "@/locales";
import { ITransaction } from "@/types";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { default as styles } from "./transaction.item.module.scss";

interface IProps extends React.HTMLAttributes<HTMLDivElement> {
  transaction: ITransaction;
  showExpiry?: boolean;
}

const TransactionCard = ({ transaction, showExpiry = false }: IProps) => {
  const expired =
    showExpiry &&
    transaction.details.meta?.expiresAt &&
    new Date() >
      dayjs(new Date(transaction.details.meta?.expiresAt))
        .add(1, "day")
        .toDate();
  const { currencyFormat } = useVendor();
  return (
    <div className={styles.root}>
      <div>
        <span>{t(["loyalty-earn", "loyalty-move"].includes(transaction.details.type) ? "Earned" : "Redeemed")}</span>
        <span
          className={
            styles[
              expired
                ? "expired"
                : ["loyalty-earn", "loyalty-move"].includes(transaction.details.type)
                ? "earned"
                : "redeemed"
            ]
          }
        >
          {["loyalty-earn", "loyalty-move"].includes(transaction.details.type) ? "+" : "-"}{" "}
          <Price
            value={Math.abs((transaction.details?.info?.amount ?? 0) / 100).toString()}
            currencyFormat={currencyFormat}
          />
        </span>
      </div>
      <div>
        <span>
          {transaction.details.type === "loyalty-move"
            ? t("Enrollment balance")
            : transaction.details.meta?.restaurantName}
        </span>
        <span>{dayjs(new Date(transaction.createdAt * 1000)).format("DD MMM YYYY")}</span>
      </div>
      {showExpiry && transaction.details.meta?.expiresAt && (
        <div className={styles.expiry}>
          {t(expired ? "These points expired at {{expiryDate}}" : "These points will expire on {{expiryDate}}", {
            expiryDate: dayjs(new Date(transaction.details.meta?.expiresAt))
              .add(1, "day")
              .format("DD MMM YYYY")
          })}
        </div>
      )}
    </div>
  );
};

export default TransactionCard;
