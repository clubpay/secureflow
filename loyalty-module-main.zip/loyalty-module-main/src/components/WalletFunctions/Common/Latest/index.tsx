import { osName } from "react-device-detect";
import { default as Benefit } from "@/components/Benefit";
import { default as BottomSheet } from "@/components/Common/Core/BottomSheet";
import { default as Button } from "@/components/Common/Core/Button";
import { Android, IOS } from "@/constants/common";
import { Arrow, QlubPlus } from "@/icons";
import { t } from "@/locales";
import { useWalletStore } from "@/store/wallet";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { Typography } from "@qlub-dev/qlub-kit";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";
import { default as defaultStyles } from "./wallet.functions.latest.module.scss";

export const testIds = {
  button: "wallet-function-action-btn",
  sheet: "wallet-function-sheet"
};

interface IProps {
  program?: ILoyaltyProgram<IQlubConfig>;
  onActionClick?: () => void | Promise<void>;
  currencyFormat: CurrencyFormat;
}

const LatestWalletFunctionSheet: React.FC<IProps> = ({ program, onActionClick }: IProps) => {
  const functionSheetOpen = useWalletStore((state) => state.functionSheetOpen);
  const openFunctionSheet = useWalletStore((state) => state.openFunctionSheet);
  const showQlubAppDownloadLink =
    program?.config?.showQlubAppDownloadLink &&
    ((osName === IOS && program?.config?.qlubAppAppStoreURL) ||
      (osName === Android && program?.config?.qlubAppPlayStoreURL));
  return (
    <BottomSheet
      open={functionSheetOpen}
      title={t("How It Works")}
      className={defaultStyles.content}
      headerClassName={defaultStyles.header}
      baseClasses={{ paper: defaultStyles.paper, root: defaultStyles.root }}
      data-testid={testIds.sheet}
      onCloseHandler={() => openFunctionSheet(false)}
    >
      <div className={defaultStyles.options}>
        <div className={defaultStyles.benefits}>
          <Typography fontWeight={600} typo="title_md">
            {t("Easy to use loyalty")}
          </Typography>
          <div className={defaultStyles.container}>
            {program?.config?.howItWorks?.map((benefit, index) => (
              <Benefit
                key={index}
                index={index + 1}
                title={benefit.key}
                description={benefit.value}
                image={benefit.image}
                last={index === program.config.howItWorks!.length - 1}
              />
            ))}
          </div>
        </div>
      </div>
      <Button
        onClick={() => {
          onActionClick?.();
          openFunctionSheet(false);
        }}
        data-testid={testIds.button}
        className={defaultStyles.action}
      >
        {showQlubAppDownloadLink ? (
          <>
            {t("Download")}
            <QlubPlus />
          </>
        ) : (
          <>
            {t("Explore qlub+ Venues")}
            <Arrow className={defaultStyles.svg} />
          </>
        )}
      </Button>
    </BottomSheet>
  );
};

export default LatestWalletFunctionSheet;
