import { osName } from "react-device-detect";
import { default as BottomSheet } from "@/components/Common/Core/BottomSheet";
import { default as Button } from "@/components/Common/Core/Button";
import { Android, IOS } from "@/constants/common";
import { Arrow, QlubPlus } from "@/icons";
import { t } from "@/locales";
import { useWalletStore } from "@/store/wallet";
import { ILoyaltyProgram } from "@/types/entities/program";
import { default as defaultStyles } from "./wallet.functions.legacy.module.scss";

export const testIds = {
  button: "legacy-wallet-function-action-btn",
  sheet: "legacy-wallet-function-sheet"
};

interface IProps {
  program?: ILoyaltyProgram;
  onActionClick?: () => void | Promise<void>;
}

const LegacyWalletFunctionSheet: React.FC<IProps> = ({ program, onActionClick }: IProps) => {
  const functionSheetOpen = useWalletStore((state) => state.functionSheetOpen);
  const openFunctionSheet = useWalletStore((state) => state.openFunctionSheet);
  const showQlubAppDownloadLink =
    program?.config?.showQlubAppDownloadLink &&
    ((osName === IOS && program?.config?.qlubAppAppStoreURL) ||
      (osName === Android && program?.config?.qlubAppPlayStoreURL));
  return (
    <BottomSheet
      open={functionSheetOpen}
      title={t("How {{program}} wallet works", { program: program?.config?.readableDisplayName })}
      className={defaultStyles.content}
      headerClassName={defaultStyles.header}
      baseClasses={{ paper: defaultStyles.paper, root: defaultStyles.root }}
      data-testid={testIds.sheet}
      onCloseHandler={() => openFunctionSheet(false)}
    >
      <div className={defaultStyles.options}>
        <div className={defaultStyles.option}>
          <div>
            <span>{t("Earn")}</span>
            <span>{t("every time you pay through qlub")}</span>
          </div>
          <span className={defaultStyles.emoji}>✌️</span>
        </div>
        <div className={defaultStyles.option}>
          <div>
            <span>{t("Redeem")}</span>
            <span>{t("at any of the Loyalty restaurants below")}</span>
          </div>
          <span className={defaultStyles.emoji}>🎉</span>
        </div>
      </div>
      <Button
        onClick={() => {
          onActionClick?.();
          openFunctionSheet(false);
        }}
        data-testid={testIds.button}
        className={defaultStyles.action}
      >
        {showQlubAppDownloadLink ? (
          <>
            {t("Download")}
            <QlubPlus />
          </>
        ) : (
          <>
            {t("Discover")}
            <Arrow />
          </>
        )}
      </Button>
    </BottomSheet>
  );
};

export default LegacyWalletFunctionSheet;
