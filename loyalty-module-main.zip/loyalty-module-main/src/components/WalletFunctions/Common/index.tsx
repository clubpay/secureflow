import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";
import LatestWalletFunctionSheet from "./Latest";
import LegacyWalletFunctionSheet from "./Legacy";

export const testIds = {
  button: "wallet-function-action-btn",
  sheet: "wallet-function-sheet"
};

interface IProps {
  program: ILoyaltyProgram<IQlubConfig>;
  onActionClick?: () => void | Promise<void>;
  currencyFormat: CurrencyFormat;
}

const WalletFunctionSheet: React.FC<IProps> = ({ program, ...props }: IProps) => {
  if (program?.config?.displayLoyaltyBenefits) {
    return <LatestWalletFunctionSheet program={program} {...props} />;
  }
  return <LegacyWalletFunctionSheet program={program} {...props} />;
};

export default WalletFunctionSheet;
