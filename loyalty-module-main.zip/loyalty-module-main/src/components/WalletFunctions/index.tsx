import { lazy } from "react";
import { LazyComponentInventory } from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";

const Inventory: LazyComponentInventory = {
  default: lazy(() => import("./Common"))
};
interface IProps {
  program?: ILoyaltyProgram;
  onActionClick?: () => void | Promise<void>;
  currencyFormat?: CurrencyFormat;
}

const WalletFunctionSheet: React.FC<IProps> = (props) => {
  const Component: React.FC<any> = props.program?.type
    ? Inventory[props.program.type] || Inventory.default
    : Inventory.default;

  return <Component {...props} />;
};

export default WalletFunctionSheet;
