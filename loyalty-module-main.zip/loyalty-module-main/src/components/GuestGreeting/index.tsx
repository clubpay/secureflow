import { default as dynamic } from "next/dynamic";
import { default as congratulationAnimation } from "@/assets/animations/congratulation.json";
import { default as Button } from "@/components/Common/Core/Button";
import { Cross, Party } from "@/icons";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useEarnStore } from "@/store/earn";
import { useGlobalStore } from "@/store/global";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { Dialog, DialogContent } from "@mui/material";
import { Price } from "@qlub-dev/qlub-kit";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";
import { default as defaultStyles } from "./styles.module.scss";

const Lottie = dynamic(() => import("lottie-react"), { ssr: false });

export const GuestGreetingPopup = ({
  program,
  amount,
  currencyFormat
}: {
  program: ILoyaltyProgram<IQlubConfig>;
  amount: number;
  currencyFormat: CurrencyFormat;
}) => {
  const open = useEarnStore((state) => state.guestGreetingPopupOpen);
  const onOpenChange = useEarnStore((state) => state.toggleGuestGreetingPopup);
  const openLoginSheet = useAuthStore((state) => state.openLoginSheet);
  const setSelectedProgram = useGlobalStore((state) => state.setSelectedProgram);

  const closePopup = () => onOpenChange(false);

  const onLoginClick = () => {
    setSelectedProgram(program);
    openLoginSheet(program.id, true);
    closePopup();
  };

  return (
    <Dialog
      open={open}
      onClose={closePopup}
      sx={{
        "& .MuiDialog-container": {
          "& .MuiPaper-root": {
            width: "100%",
            maxWidth: "350px",
            borderRadius: "24px",
            overflowX: "hidden"
          }
        }
      }}
      data-testid="popup-guest-greeting"
      data-open={open}
    >
      <DialogContent>
        <div className={defaultStyles.close} onClick={closePopup}>
          <Cross />
        </div>
        <div className={defaultStyles.content}>
          <div className={defaultStyles.icon}>
            <Party width={28} height={28} />
          </div>
          <h6 className={defaultStyles.title}>{t("Congratulations!")}</h6>
          <p className={defaultStyles.subtitle}>
            {t("You have earned {{amount}}", {
              amount: (
                <Price
                  sx={{
                    "display": "inline-flex",
                    "alignItems": "baseline",
                    "gap": "2px",
                    "fontSize": "inherit",
                    "&>span": { fontSize: "inherit" }
                  }}
                  value={amount.toString()}
                  currencyFormat={currencyFormat}
                />
              )
            })}
          </p>
          <Button data-testid="popup-guest-greeting-button" className={defaultStyles.action} onClick={onLoginClick}>
            {t("Secure your earned points? {{login}}", {
              login: <span style={{ textDecoration: "underline" }}>{t("login")}</span>
            })}
          </Button>
        </div>
        <div className={defaultStyles.animation}>
          <Lottie animationData={congratulationAnimation} loop={false} />
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default GuestGreetingPopup;
