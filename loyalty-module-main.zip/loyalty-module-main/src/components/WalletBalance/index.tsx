import { default as Price } from "@/components/Common/Price";
import { t } from "@/locales";
import { IGenericOptions } from "@/types";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { Skeleton } from "@mui/material";
import { default as styles } from "./wallet.balance.module.scss";

export const testIds = {
  points: "wallet-balance-points",
  walletName: "wallet-name"
};

export interface IProps extends Partial<Pick<IGenericOptions, "currencyFormat">> {
  name?: string;
  program: ILoyaltyProgram<IQlubConfig>;
  balance: number;
}

const WalletBalance = ({ name, program, balance, currencyFormat }: IProps) => {
  return (
    <div className={styles.root}>
      <span className={styles.balance} data-testid={testIds.points}>
        <Price
          value={(balance / program.config.burnPointConversionRate!).toString()}
          currencyFormat={currencyFormat!}
        />
      </span>
      <span className={styles.program} data-testid={testIds.walletName}>
        {name ? (
          <>
            {name} <span>{t("wallet")}</span>
          </>
        ) : (
          <Skeleton variant="rounded" width={100} height={12} sx={{ mt: 0.75 }} />
        )}
      </span>
    </div>
  );
};

export default WalletBalance;
