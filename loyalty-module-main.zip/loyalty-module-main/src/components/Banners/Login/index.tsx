import { default as defaultStyles } from "./banner.module.scss";

export interface IProps {
  banner?: string;
}

const Banner: React.FC<IProps> = (props) => {
  if (!props.banner) return null;
  return (
    <div className={defaultStyles.root}>
      <img className={defaultStyles.banner} src={props.banner} alt="loyalty banner" />
    </div>
  );
};

export default Banner;
