import { default as classNames } from "classnames";
import { useGlobalStore } from "@/store/global";
import { Locales } from "@/types";
import { getLocaleText } from "@clubpay/customer-common-module/src/component/MultiLocale";
import { Typography } from "@qlub-dev/qlub-kit";
import { default as defaultStyles } from "./styles.module.scss";

function Benefit({
  index,
  title,
  description,
  image,
  last
}: {
  index: number;
  title: string;
  description: string;
  image?: string;
  last?: boolean;
}): JSX.Element {
  const locale = useGlobalStore((state) => state.locale);

  if (image) {
    return (
      <div
        className={classNames(defaultStyles["benefit-with-image"], {
          [defaultStyles.last]: last,
          [defaultStyles.first]: index === 1
        })}
      >
        <img
          className={defaultStyles.image}
          src={getLocaleText(image, locale, Locales.English)}
          alt={`benefit-image-${index + 1}`}
        />
        <div className={defaultStyles.content}>
          <span className={defaultStyles.title}>{getLocaleText(title, locale, Locales.English)}</span>
          <span className={defaultStyles.subtitle}>{getLocaleText(description, locale, Locales.English)}</span>
        </div>
      </div>
    );
  }

  return (
    <div className={defaultStyles.benefit}>
      <div className={defaultStyles.ranking}>{String(index).padStart(2, "0")}</div>
      <div className={defaultStyles.content}>
        <Typography typo="title_sm" fontWeight={600}>
          {getLocaleText(title, locale, Locales.English)}
        </Typography>
        <Typography typo="caption_overline">{getLocaleText(description, locale, Locales.English)}</Typography>
      </div>
    </div>
  );
}

export default Benefit;
