import { useCallback, useEffect, useState } from "react";
import { default as classNames } from "classnames";
import { default as Button } from "@/components/Common/Core/Button";
import { isRunningTests } from "@/constants";
import { genericSnackbarOptions } from "@/hooks/snackbar";
import { Cross, Loyalty } from "@/icons";
import { t } from "@/locales";
import { useEarnStore } from "@/store/earn";
import { useGlobalStore } from "@/store/global";
import { IGenericOptions, IQlubMetaData } from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";
import { default as PhoneInput } from "@clubpay/customer-common-module/src/component/PhoneInputV2";
import { qlubSessionStorage } from "@clubpay/customer-common-module/src/service/storage/sessionStorage";
import { Dialog, DialogContent } from "@mui/material";
import defaultStyles from "./earn.module.scss";

export const testIds = {
  button: "earn-btn",
  input: "earn-phone-input"
};

export interface IProps extends IGenericOptions, React.HTMLAttributes<HTMLElement> {
  keys?: string[];
  events?: {
    onEarn?: (mobile: string) => Promise<any>;
    onInput?: (mobile: string) => Promise<any>;
  };
  program: ILoyaltyProgram;
  ui?: {
    text?: {
      title?: string;
      description?: string;
      button?: string;
      toast?: {
        alreadyEarned?: string;
        success?: string;
      };
    };
    enablePopup?: boolean;
  };
  meta?: IQlubMetaData;
}

const sessionEarnKey = "qlub.loyalty.points.earned";

const getSessionEarnKey = (service: string, keys: string[]) => {
  return `${sessionEarnKey}.${service}${keys.length ? `.${keys.join(".")}` : ""}`;
};

const getPointsEarned = (service: string, keys: string[]) => {
  if (typeof window === "undefined") return false;
  return qlubSessionStorage.get(getSessionEarnKey(service, keys)) === "true";
};

const Earn: React.FC<IProps> = ({ keys = [], events, country = "ae", program, ui, meta, ...props }: IProps) => {
  const [loading, setLoading] = useState(false);
  const [mobileNumber, setMobileNumber] = useState("");
  const [popupOpen, setPopupOpen] = useState(false);
  const [valid, setValid] = useState(isRunningTests);

  const { pointsEarned, setPointsEarned } = useEarnStore((state) => state);

  const { locale } = useGlobalStore();

  useEffect(() => {
    const _pointsEarned = getPointsEarned(program.id, keys);
    setPointsEarned(program.id, _pointsEarned);
    setPopupOpen(ui?.enablePopup ? ui?.enablePopup && !_pointsEarned : false);
  }, [program.id]);

  const onSubmit = () => {
    if (pointsEarned[program.id]) {
      window.snackbar?.enqueue?.(
        ui?.text?.toast?.alreadyEarned ?? t("You have already earned points for this transaction"),
        {
          variant: "warning",
          ...genericSnackbarOptions
        }
      );
      return;
    }
    const next = () => {
      window.snackbar?.enqueue?.(
        ui?.text?.toast?.success ?? t("Request submitted. Points will be added to your account soon"),
        genericSnackbarOptions
      );
      qlubSessionStorage.set(getSessionEarnKey(program.id, keys), "true");
      setPointsEarned(program.id, true);
      if (popupOpen) setPopupOpen(false);
    };
    if (events?.onEarn) {
      setLoading(true);
      events
        .onEarn?.(mobileNumber)
        ?.then(next)
        .finally(() => setLoading(false));
    } else {
      next();
    }
  };

  const onChange = (value: any) => {
    const phone = value?.phone?.replace("+", "");
    if (phone) setMobileNumber(phone);
    events?.onInput?.(phone);
  };

  const PhoneNumberInput = useCallback(() => {
    return (
      <div className={defaultStyles.inputWrapper}>
        <PhoneInput
          placeholder={t("Phone Number")}
          countrySearchLabel={t("Search for your country")}
          lang={locale}
          defaultCountry={country}
          onChange={onChange}
          value={undefined as any}
          freezeCountryCode={program.config?.freezeRegionalLogin}
          forceLTR={program.config?.forceMobileInputLTR}
          hideErrorForCountryCode
          errorText={t("Please enter a valid mobile number")}
          inputProps={{
            "data-testid": testIds.input
          }}
          validation={{
            enable: !isRunningTests,
            callbackFn: setValid
          }}
        />
      </div>
    );
  }, [locale, country]);

  const ActionButton = useCallback(
    ({ text, disabled }: any) => {
      return (
        <div className={defaultStyles.buttonWrapper}>
          <Button data-testid={testIds.button} onClick={onSubmit} loading={loading} disabled={disabled || !valid}>
            {ui?.text?.button ?? text ?? t("Earn points now")}
          </Button>
        </div>
      );
    },
    [loading, mobileNumber, valid]
  );

  const onClose = () => {
    setMobileNumber("");
    setPopupOpen(false);
  };

  return (
    <>
      {(!ui?.enablePopup || (ui?.enablePopup && !pointsEarned[program.id])) && (
        <div className={classNames(defaultStyles.container, props.className)} style={props.style}>
          <div className={defaultStyles.title}>{ui?.text?.title || t("Collect your loyalty points")}</div>
          <div className={defaultStyles.subtitleWrapper}>
            <div className={defaultStyles.icon}>
              <Loyalty />
            </div>
            <div className={defaultStyles.subtitleTextWrapper}>
              <div className={defaultStyles.subtitle}>
                {ui?.text?.description || t("Enter your mobile number to collect your points")}
              </div>
            </div>
          </div>
          <PhoneNumberInput />
          <ActionButton disabled={popupOpen} />
        </div>
      )}
      {ui?.enablePopup && (
        <Dialog
          open={popupOpen}
          onClose={onClose}
          PaperProps={{ style: { borderRadius: "24px" } }}
          style={{ zIndex: 1200 }}
          fullWidth
        >
          <DialogContent classes={{ root: defaultStyles["modal-container"] }}>
            <div className={defaultStyles.close} onClick={onClose}>
              <Cross />
            </div>
            {meta?.restaurantLogoUrl && <img src={meta.restaurantLogoUrl} alt="logo" className={defaultStyles.logo} />}
            <div>
              <div className={defaultStyles.title}>
                {program.config.readableDisplayName || t("Collect your loyalty points")}
              </div>
              <div className={defaultStyles.subtitle}>
                {ui?.text?.description || t("Enter your mobile number to collect your points")}
              </div>
            </div>
            <PhoneNumberInput />
            <ActionButton text={t("Submit")} />
          </DialogContent>
        </Dialog>
      )}
    </>
  );
};

export default Earn;
