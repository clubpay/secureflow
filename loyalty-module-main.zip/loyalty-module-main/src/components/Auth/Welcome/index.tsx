import { useEffect } from "react";
import { default as BottomSheet } from "@/components/Common/Core/BottomSheet";
import { default as Button } from "@/components/Common/Core/Button";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useGlobalStore } from "@/store/global";
import { IAuthOptions, LoyaltyService } from "@/types";
import { default as defaultStyles } from "./welcome.module.scss";

export const testIds = {
  back: "auth-welcome-back",
  button: "auth-welcome-btn",
  sheet: "auth-welcome-sheet"
};

const WelcomeSheet: React.FC<IAuthOptions> = (props: IAuthOptions) => {
  const { selectedProgram } = useGlobalStore();

  const welcomeSheetOpen = useAuthStore((state) => state.welcomeSheetOpen[selectedProgram.id]);

  const openWelcomeSheet = useAuthStore((state) => state.openWelcomeSheet);

  useEffect(() => {
    if (welcomeSheetOpen) {
      props.config.events?.onWelcomeSheetOpen?.();
    }
  }, [welcomeSheetOpen]);

  const onBackHandler = () => {
    openWelcomeSheet(selectedProgram.id, false);
    props.config.events?.onSheetClose?.();
  };

  return (
    <BottomSheet
      open={!!welcomeSheetOpen}
      className={defaultStyles.content}
      onBackHandler={onBackHandler}
      backButtonProps={{ "data-testid": testIds.back }}
      data-testid={testIds.sheet}
    >
      <Content {...props} />
    </BottomSheet>
  );
};

const Content: React.FC<IAuthOptions> = (props: IAuthOptions) => {
  const openWelcomeSheet = useAuthStore((state) => state.openWelcomeSheet);

  const setLoginPromptEnabled = useAuthStore((state) => state.setLoginPromptEnabled);

  const { selectedProgram } = useGlobalStore();

  const onContinue = async () => {
    if (props.config.events?.onWelcome) {
      await props.config.events.onWelcome();
    }
    openWelcomeSheet(selectedProgram.id, false);
    setLoginPromptEnabled(selectedProgram.id, false);
  };

  return (
    <>
      <div className={defaultStyles.entry}>
        <div className={defaultStyles.innerContent}>
          {props.meta?.restaurantLogoUrl ? <img src={props.meta?.restaurantLogoUrl} alt="logo" /> : <div />}
          <span>
            {t(
              selectedProgram.type === LoyaltyService.Qlub
                ? "Welcome to {{loyaltyProgram}}"
                : "Welcome to the {{loyaltyProgram}} App",
              {
                loyaltyProgram: selectedProgram.config.readableDisplayName
              }
            )}
          </span>
          <span>{t("You will earn points after payment")}</span>
        </div>
      </div>
      <div className={defaultStyles.end}>
        <Button data-testid={testIds.button} onClick={onContinue}>
          {t("Continue")}
        </Button>
      </div>
    </>
  );
};

export default WelcomeSheet;
