import { useEffect, useState } from "react";
import { osName } from "react-device-detect";
import { default as BottomSheet } from "@/components/Common/Core/BottomSheet";
import { default as Button } from "@/components/Common/Core/Button";
import { default as EarnNote } from "@/components/Common/EarnNote";
import { Android, IOS } from "@/constants/common";
import { QlubPlus } from "@/icons";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useCheckoutStore } from "@/store/checkout";
import { useGlobalStore } from "@/store/global";
import { IAuthOptions, LoyaltyService, PopupVariant } from "@/types";
import { InternalProgramType } from "@/types/entities/program";
import { secondsToMSS } from "@/utils";
import { default as OtpInputV2 } from "@qlub-dev/qlub-kit/dist/components/OtpInput/OtpV2";
import { default as defaultStyles } from "./otp.module.scss";

export const testIds = {
  back: "auth-otp-back",
  container: "auth-otp-input-container",
  button: "auth-otp-btn",
  resend: "auth-otp-resend",
  sheet: "auth-otp-sheet"
};

const OTPSheet: React.FC<IAuthOptions> = (props: IAuthOptions) => {
  const { openLoginSheet, openVerificationSheet, setOTP, setIsMobileNumberValid, setMobileNumber } = useAuthStore();

  const { selectedProgram } = useGlobalStore();

  const loginPromptEnabled = useAuthStore((state) => state.loginPromptEnabled[selectedProgram.id]);

  const verificationSheetOpen = useAuthStore((state) => state.verificationSheetOpen[selectedProgram.id]);
  const isCompact = useAuthStore((state) => state.isCompact[selectedProgram.id]);
  const loginMeta = useAuthStore((state) => state.loginMeta[selectedProgram.id]);

  const onSkip = () => {
    setOTP(selectedProgram.id, "");
    openVerificationSheet(selectedProgram.id, false);
    if (loginPromptEnabled || selectedProgram.config.enableLoginVerificationPrompt) {
      setMobileNumber(selectedProgram.id, "");
      setIsMobileNumberValid(selectedProgram.id, false);
    }
    if (selectedProgram.config.apiVersion === 2) {
      props?.config?.events?.onLogout?.();
    }
  };

  const onBackHandler = () => {
    onSkip();
    openLoginSheet(selectedProgram.id, true, isCompact, loginMeta);
  };

  return (
    <BottomSheet
      open={verificationSheetOpen}
      headerImgUrl={props.meta?.restaurantLogoUrl}
      className={defaultStyles.content}
      onBackHandler={onBackHandler}
      backButtonProps={{ "data-testid": testIds.back }}
      data-testid={testIds.sheet}
    >
      <Content {...props} onSkip={onSkip} />
    </BottomSheet>
  );
};

const Content: React.FC<IAuthOptions & { onSkip: () => void }> = (props) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [interval, setIntervalInstance] = useState<any>(null);

  const { selectedProgram } = useGlobalStore();
  const openPopup = useGlobalStore().popup.openPopup;

  const [timer, setTimer] = useState(60);

  const [attempts, setAttempts] = useState(1);

  const openCheckoutSheet = useCheckoutStore((state) => state.openSheet);

  const { openVerificationSheet, setOTP, openWelcomeSheet, openRegistrationSheet } = useAuthStore();

  const loginPromptEnabled = useAuthStore((state) => state.loginPromptEnabled[selectedProgram.id]);

  const verificationSheetOpen = useAuthStore((state) => state.verificationSheetOpen[selectedProgram.id]);

  const mobileNumber = useAuthStore((state) => state.mobileNumber[selectedProgram.id]);

  const otp = useAuthStore((state) => state.otp[selectedProgram.id]);

  const isNewUser = useAuthStore((state) => state.isNewUser[selectedProgram.id]);

  const isCompact = useAuthStore((state) => state.isCompact[selectedProgram.id]);

  const attemptsExceeded = attempts >= 5;

  const canRetry = timer <= 0 && !attemptsExceeded;

  const initCountdown = () => {
    if (timer !== 60) setTimer(60);
    const interval = setInterval(() => setTimer((prev) => prev - 1), 1000);
    setIntervalInstance(interval);
    return () => clearInterval(interval);
  };

  useEffect(() => {
    if (timer <= 0) clearInterval(interval);
  }, [timer, interval]);

  useEffect(() => {
    if (verificationSheetOpen) {
      setError(false);
      return initCountdown();
    }
  }, [verificationSheetOpen]);

  const onClickTimer = () => {
    if (canRetry) {
      initCountdown();
      setAttempts((prev) => prev + 1);
      props.config.events?.onLogin?.({ phoneNumber: mobileNumber }, true);
    }
  };

  const onDownloadClick = () => {
    let url: string = "";
    if (osName === IOS) {
      url = selectedProgram.config.qlubPlusAppStoreSecurePointsURL ?? url;
    } else if (osName === Android) {
      url = selectedProgram.config.qlubPlusPlayStoreSecurePointsURL ?? url;
    }
    window.location.href = url;
  };

  const displayPopup = () => {
    if (osName === IOS || osName === Android) {
      openPopup({
        title: t(isNewUser ? "Welcome to Qlub+" : "Thank you for logging in"),
        subtitle: t("Explore restaurants where you can redeem points"),
        buttonText: (
          <span className={defaultStyles.download}>
            {t("Download")}
            <QlubPlus />
          </span>
        ),
        variant: PopupVariant.Congratulations,
        actionClickHandler: onDownloadClick
      });
    }
  };

  const onContinue = () => {
    const next = () => {
      setOTP(selectedProgram.id, "");
      openVerificationSheet(selectedProgram.id, false);
      if (isCompact) displayPopup();
      if (
        !loginPromptEnabled &&
        !selectedProgram.config.displayOfferSelectorSheet &&
        !selectedProgram.config.isDiscountEnabled
      ) {
        openCheckoutSheet?.(selectedProgram.id, true);
      }
    };
    if (props.config?.events?.onLoginVerification) {
      setLoading(true);
      props.config?.events
        ?.onLoginVerification(otp, { phoneNumber: mobileNumber })
        ?.then(async () => {
          setError(false);
          if (!isNewUser) {
            next();
          } else {
            openVerificationSheet(selectedProgram.id, false);
            if (isCompact) displayPopup();
            if (!selectedProgram.config.useToggle) {
              if (selectedProgram.type === LoyaltyService.Como && selectedProgram.config.enableRegistrationFlow) {
                setOTP(selectedProgram.id, "");
                openRegistrationSheet(selectedProgram.id, true);
              } else {
                if (selectedProgram.internalProgramType !== InternalProgramType.IN_SUB_DISCOUNT)
                  openWelcomeSheet(selectedProgram.id, true);
              }
            }
          }
        })
        .catch(() => setError(true))
        .finally(() => setLoading(false));
    } else {
      next();
    }
  };

  const otpCharacters = selectedProgram.type === LoyaltyService.Qlub ? 5 : 4;

  return (
    <>
      <div data-testid={testIds.container} className={defaultStyles.entry}>
        <span>
          {t("Enter {{digitCount}}-digit code", {
            digitCount: otpCharacters
          })}
        </span>
        <span className={defaultStyles["target-number"]}>
          {t("The {{digitCount}} digit code is sent to {{mobileNumber}}", {
            mobileNumber: <span dir="ltr">{`+${mobileNumber}`}</span>,
            digitCount: otpCharacters
          })}
        </span>
        <OtpInputV2
          onChange={(value: string) => setOTP(selectedProgram.id, value)}
          error=""
          label=""
          numInputs={otpCharacters}
          inputStyle={defaultStyles.otp}
          containerStyle={defaultStyles["otp-container"]}
          inputType="tel"
          value={otp}
        />
        {error && <span className={defaultStyles["error"]}>{t("Please enter a valid code")}</span>}
        <div
          data-testid={testIds.resend}
          className={`${defaultStyles.timer} ${canRetry && defaultStyles["timer-clickable"]}`}
          onClick={onClickTimer}
        >
          {timer > 0 ? (
            <>
              <span>{t("I didn't receive a code")}</span>
              <span>({secondsToMSS(timer)})</span>
            </>
          ) : (
            <span>{t(attemptsExceeded ? "You have exceeded the maximum number of attempts" : "Resend code")}</span>
          )}
        </div>
      </div>
      <div>
        {selectedProgram.config.displayEarnNote && <EarnNote program={selectedProgram} />}
        {loginPromptEnabled ? (
          <div className={defaultStyles["actions"]}>
            <Button
              className={defaultStyles["skip"]}
              onClick={() => {
                props.config.events?.onSheetClose?.();
                props.onSkip();
              }}
            >
              {t("Skip")}
            </Button>
            <Button
              data-testid={testIds.button}
              disabled={attemptsExceeded || otp?.length !== otpCharacters}
              onClick={onContinue}
              loading={loading}
            >
              {t("Proceed")}
            </Button>
          </div>
        ) : (
          <Button
            data-testid={testIds.button}
            disabled={attemptsExceeded || otp?.length !== otpCharacters}
            onClick={onContinue}
            loading={loading}
          >
            {t("Continue")}
          </Button>
        )}
      </div>
    </>
  );
};

export default OTPSheet;
