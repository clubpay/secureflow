import { Dispatch, SetStateAction } from "react";
import { sessionCollectedNumber, sessionCollectedNumberValidity } from "@/constants";
import { useAuthStore } from "@/store/auth";
import { useEarnStore } from "@/store/earn";
import { useGlobalStore } from "@/store/global";
import { IAuthOptions, LoyaltyService } from "@/types";
import { qlubSessionStorage } from "@clubpay/customer-common-module/src/service/storage/sessionStorage";
import { default as Compact } from "./Compact";
import { default as Default } from "./Default";

export const testIds = {
  back: "auth-login-back",
  button: "auth-login-btn",
  input: "auth-login-phone-input",
  sheet: "auth-login-sheet"
};

const LoginSheet: React.FC<IAuthOptions> = (props: IAuthOptions) => {
  const {
    openLoginSheet,
    openVerificationSheet,
    setMobileNumber,
    setIsNewUser,
    setLoginPromptEnabled,
    setIsMobileNumberValid
  } = useAuthStore();

  const { setPointsEarned } = useEarnStore((state) => state);

  const { selectedProgram } = useGlobalStore();

  const isCompact = useAuthStore((state) => state.isCompact[selectedProgram.id]);
  const loginPromptEnabled = useAuthStore((state) => state.loginPromptEnabled[selectedProgram.id]);
  const mobileNumber = useAuthStore((state) => state.mobileNumber[selectedProgram.id]);

  const onBack = () => {
    openLoginSheet(selectedProgram.id, false, false);
    if (loginPromptEnabled || selectedProgram.config.enableLoginVerificationPrompt) {
      setMobileNumber(selectedProgram.id, "");
      setIsMobileNumberValid(selectedProgram.id, false);
    }
    props.config.events?.onSheetClose?.();
  };

  const onContinue = (setError: Dispatch<SetStateAction<boolean>>, setLoading: Dispatch<SetStateAction<boolean>>) => {
    const next = () => {
      openLoginSheet(selectedProgram.id, false);
      openVerificationSheet(selectedProgram.id, true);
    };
    if (props.config.events?.onLogin) {
      setLoading(true);
      props.config.events
        ?.onLogin({ phoneNumber: mobileNumber })
        ?.then((res) => {
          setError(false);
          setIsNewUser(selectedProgram.id, !!res?.isNewUser);
          if (loginPromptEnabled) {
            if (res?.isNewUser || selectedProgram.config.enableLoginVerificationPrompt) {
              next();
            } else {
              qlubSessionStorage.set(`${sessionCollectedNumber}.${selectedProgram.id}`, mobileNumber);
              qlubSessionStorage.set(`${sessionCollectedNumberValidity}.${selectedProgram.id}`, "valid");
              if (selectedProgram.type === LoyaltyService.Como) {
                setPointsEarned(selectedProgram.id, true);
                qlubSessionStorage.set(
                  `qlub.loyalty.points.earned.${selectedProgram.id}${props.config.dsi ? `.${props.config.dsi}` : ""}`,
                  "true"
                );
              }
              setLoginPromptEnabled(selectedProgram.id, false);
              openLoginSheet(selectedProgram.id, false);
            }
          } else {
            next();
          }
        })
        .catch((err) => {
          if (err?.message !== "proceed_denied") {
            setError(true);
          }
        })
        .finally(() => setLoading(false));
    } else {
      next();
    }
  };

  if (isCompact) {
    return <Compact {...props} onBack={onBack} onContinue={onContinue} />;
  }
  return <Default {...props} onBack={onBack} onContinue={onContinue} />;
};

export default LoginSheet;
