import { useCallback, useState } from "react";
import { default as LoginBanner } from "@/components/Banners/Login";
import { default as BottomSheet } from "@/components/Common/Core/BottomSheet";
import { default as Button } from "@/components/Common/Core/Button";
import { default as EarnNote } from "@/components/Common/EarnNote";
import { default as Terms } from "@/components/Common/T&C/Terms";
import { default as SubscriptionRenewal } from "@/components/Subscription/Renewal";
import { default as SubscribeNow } from "@/components/Subscription/SubscribeNow";
import { isRunningTests } from "@/constants";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useGlobalStore } from "@/store/global";
import { IAuthContentOptions, LoyaltyService } from "@/types";
import { default as PhoneInput } from "@clubpay/customer-common-module/src/component/PhoneInputV2";
import { testIds } from "..";
import { default as defaultStyles } from "./login.module.scss";

const LoginSheet: React.FC<IAuthContentOptions> = (props: IAuthContentOptions) => {
  const { selectedProgram } = useGlobalStore();

  const loginSheetOpen = useAuthStore((state) => state.loginSheetOpen[selectedProgram?.id]);

  return (
    <BottomSheet
      open={loginSheetOpen}
      headerImgUrl={props.meta?.restaurantLogoUrl}
      className={defaultStyles.content}
      onBackHandler={props.onBack}
      backButtonProps={{ "data-testid": testIds.back }}
      data-testid={testIds.sheet}
    >
      <Content {...props} />
    </BottomSheet>
  );
};

const Content: React.FC<IAuthContentOptions> = (props) => {
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(false);

  const { setMobileNumber, setIsMobileNumberValid } = useAuthStore();

  const { locale, selectedProgram } = useGlobalStore();
  const loginPromptEnabled = useAuthStore((state) => state.loginPromptEnabled[selectedProgram.id]);
  const mobileNumber = useAuthStore((state) => state.mobileNumber[selectedProgram.id]);
  const isMobileNumberValid = useAuthStore((state) => state.isMobileNumberValid[selectedProgram.id]);
  const isAgreedOnTerms = useAuthStore((state) => state.isAgreedOnTerms[selectedProgram.id]);

  const onChange = useCallback((value: any) => {
    setError(false);
    setMobileNumber(selectedProgram.id, value.phone.replace("+", ""));
  }, []);

  const onContinue = () => props.onContinue(setError, setLoading);

  const shouldDisable = !isMobileNumberValid || (selectedProgram.type === LoyaltyService.Qlub && !isAgreedOnTerms);

  return (
    <>
      <div className={defaultStyles.top}>
        <LoginBanner banner={selectedProgram.config?.localizedLoginBanner} />
        <SubscribeNow program={selectedProgram as any} currencyFormat={props.currencyFormat} />
        <SubscriptionRenewal program={selectedProgram as any} currencyFormat={props.currencyFormat} />
        <div className={defaultStyles.entry}>
          <span>
            {loginPromptEnabled && selectedProgram.config.readableDisplayName
              ? t("Enter your mobile number to earn {{loyaltyProgramName}}", {
                  loyaltyProgramName: selectedProgram.config.readableDisplayName
                })
              : t("Enter your mobile number to login or register")}
          </span>
          <PhoneInput
            placeholder={t("Phone Number")}
            countrySearchLabel={t("Search for your country")}
            lang={locale}
            defaultCountry={props.country ?? "ae"}
            onChange={onChange}
            value={selectedProgram.type === LoyaltyService.Como ? mobileNumber : (undefined as any)}
            errorText={error && t("Please enter a valid mobile number")}
            freezeCountryCode={selectedProgram.config.freezeRegionalLogin}
            forceLTR={selectedProgram.config.forceMobileInputLTR}
            hideErrorForCountryCode
            inputProps={{
              "data-testid": testIds.input,
              "onPaste": selectedProgram.config.freezeRegionalLogin ? (e) => e.preventDefault() : undefined
            }}
            validation={{
              enable: !isRunningTests,
              callbackFn: (isValid) => setIsMobileNumberValid(selectedProgram.id, isValid, false)
            }}
          />
        </div>
      </div>
      <div>
        {selectedProgram.type === LoyaltyService.Qlub && (
          <Terms program={selectedProgram} events={props.config.events} />
        )}
        {selectedProgram.config.showEarnNote && <EarnNote program={selectedProgram} />}
        {loginPromptEnabled ? (
          <div className={defaultStyles["actions"]}>
            <Button className={defaultStyles["skip"]} onClick={props.onBack}>
              {t("Skip")}
            </Button>
            <Button data-testid={testIds.button} onClick={onContinue} disabled={shouldDisable} loading={loading}>
              {t("Proceed")}
            </Button>
          </div>
        ) : (
          <Button data-testid={testIds.button} onClick={onContinue} disabled={shouldDisable} loading={loading}>
            {t("Continue")}
          </Button>
        )}
      </div>
    </>
  );
};

export default LoginSheet;
