import { useCallback, useState } from "react";
import { default as Button } from "@/components/Common/Core/Button";
import { isRunningTests } from "@/constants";
import { Cross, QlubPlus } from "@/icons";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useGlobalStore } from "@/store/global";
import { IAuthContentOptions, LoyaltyService } from "@/types";
import { default as PhoneInput } from "@clubpay/customer-common-module/src/component/PhoneInputV2";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { Dialog, DialogContent } from "@mui/material";
import { Price } from "@qlub-dev/qlub-kit";
import { testIds } from "..";
import { default as defaultStyles } from "./login.module.scss";

export const LoginPopup = (props: IAuthContentOptions) => {
  const { locale, selectedProgram } = useGlobalStore();

  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(false);

  const open = useAuthStore((state) => state.loginSheetOpen[selectedProgram?.id]);
  const { currencyFormat } = useVendor();

  const { setMobileNumber, setIsMobileNumberValid } = useAuthStore();
  const mobileNumber = useAuthStore((state) => state.mobileNumber[selectedProgram.id]);
  const isMobileNumberValid = useAuthStore((state) => state.isMobileNumberValid[selectedProgram.id]);
  const loginMeta = useAuthStore((state) => state.loginMeta[selectedProgram.id]);

  const onChange = useCallback((value: any) => {
    setError(false);
    setMobileNumber(selectedProgram.id, value.phone.replace("+", ""));
  }, []);

  const onContinue = () => props.onContinue(setError, setLoading);

  return (
    <Dialog
      open={open}
      onClose={props.onBack}
      sx={{
        "& .MuiDialog-container": {
          "& .MuiPaper-root": {
            width: "100%",
            maxWidth: "350px",
            borderRadius: "24px",
            overflowX: "hidden"
          }
        }
      }}
      data-testid={testIds.sheet}
      data-open={open}
    >
      <DialogContent>
        <div className={defaultStyles.close} data-testid={testIds.back} onClick={props.onBack}>
          <Cross />
        </div>
        <div className={defaultStyles.content}>
          <QlubPlus width={96} height={28} className={defaultStyles.logo} />
          <p className={defaultStyles.subtitle}>
            {t("Sign in or register with your mobile number to get {{amount}} cashback added to your account.", {
              amount: (
                <Price
                  sx={{
                    "display": "inline-flex",
                    "alignItems": "baseline",
                    "gap": "2px",
                    "fontSize": "inherit",
                    "&>span": { fontSize: "inherit" }
                  }}
                  value={loginMeta?.amount}
                  currencyFormat={currencyFormat}
                />
              )
            })}
          </p>
          <PhoneInput
            placeholder={t("Phone Number")}
            countrySearchLabel={t("Search for your country")}
            lang={locale}
            defaultCountry={props.country ?? "ae"}
            onChange={onChange}
            value={selectedProgram.type === LoyaltyService.Como ? mobileNumber : (undefined as any)}
            errorText={error && t("Please enter a valid mobile number")}
            freezeCountryCode={selectedProgram.config.freezeRegionalLogin}
            inputProps={{
              "data-testid": testIds.input,
              "onPaste": selectedProgram.config.freezeRegionalLogin ? (e) => e.preventDefault() : undefined
            }}
            validation={{
              enable: !isRunningTests,
              callbackFn: (isValid) => setIsMobileNumberValid(selectedProgram.id, isValid, false)
            }}
          />
          <Button
            data-testid={testIds.button}
            className={defaultStyles.action}
            onClick={onContinue}
            disabled={!isMobileNumberValid}
            loading={loading}
          >
            {t("Proceed")}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default LoginPopup;
