import { useMemo } from "react";
import { Controller, SubmitHandler, useForm } from "react-hook-form";
import { default as dayjs } from "dayjs";
import { parsePhoneNumber } from "libphonenumber-js";
import { default as camelCase } from "lodash/camelCase";
import { z } from "zod";
import { default as BottomSheet } from "@/components/Common/Core/BottomSheet";
import { default as Button } from "@/components/Common/Core/Button";
import { default as CountrySelector } from "@/components/Common/Core/CountrySelector";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useGlobalStore } from "@/store/global";
import { IAuthOptions } from "@/types";
import { zodResolver } from "@hookform/resolvers/zod";
import { MenuItem, TextField, Typography } from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { default as countries } from "@qlub-dev/qlub-kit/dist/components/PhoneInput/data/rawCountries";
import { default as defaultStyles } from "./registration.module.scss";

export const testIds = {
  back: "auth-register-back",
  button: "auth-register-btn",
  sheet: "auth-register-sheet"
};

const RegistrationSheet: React.FC<IAuthOptions> = (props: IAuthOptions) => {
  const { selectedProgram } = useGlobalStore();
  const { openRegistrationSheet, setMobileNumber, setIsMobileNumberValid } = useAuthStore();
  const loginPromptEnabled = useAuthStore((state) => state.loginPromptEnabled[selectedProgram.id]);
  const registrationSheetOpen = useAuthStore((state) => state.registrationSheetOpen[selectedProgram.id]);

  const onBackHandler = () => {
    openRegistrationSheet(selectedProgram.id, false);
    if (loginPromptEnabled || selectedProgram.config?.enableLoginVerificationPrompt) {
      setMobileNumber(selectedProgram.id, "");
      setIsMobileNumberValid(selectedProgram.id, false);
      props?.config?.events?.onLogout?.();
    }
    props.config.events?.onSheetClose?.();
  };
  return (
    <BottomSheet
      open={registrationSheetOpen}
      headerImgUrl={props.meta?.restaurantLogoUrl}
      className={defaultStyles.content}
      onBackHandler={onBackHandler}
      backButtonProps={{ "data-testid": testIds.back }}
      data-testid={testIds.sheet}
    >
      <Content {...props} onSkip={onBackHandler} />
    </BottomSheet>
  );
};

function Content(props: IAuthOptions & { onSkip: () => void }): JSX.Element {
  const { selectedProgram } = useGlobalStore();
  const { openRegistrationSheet, openWelcomeSheet } = useAuthStore();
  const loginPromptEnabled = useAuthStore((state) => state.loginPromptEnabled[selectedProgram.id]);
  const mobileNumber = useAuthStore((state) => state.mobileNumber[selectedProgram.id]);

  const requiredFields = useMemo(
    () => selectedProgram.config.requiredRegistrationFields?.map((value) => camelCase(value)) ?? [],
    [selectedProgram.config.requiredRegistrationFields]
  );

  const fields = useMemo(
    () =>
      selectedProgram.config.registrationFields?.length
        ? selectedProgram.config.registrationFields?.map((value) => camelCase(value))
        : ["firstName", "lastName", "email", "gender", "birthday", "country"],
    [selectedProgram.config.registrationFields]
  );

  const createSchema = () => {
    const schema: Record<string, any> = {};
    fields.forEach((field) => {
      schema[field] = requiredFields.includes(field) ? z.string().min(1) : z.string().optional();
    });
    schema["email"] = requiredFields.includes("email")
      ? z.string().email()
      : z.string().email().optional().or(z.literal(""));
    return schema as {
      firstName: z.ZodString;
      lastName: z.ZodString;
      email: z.ZodString;
      gender: z.ZodString;
      birthday: z.ZodString;
      country: z.ZodString;
    };
  };

  const FormSchema = z.object(createSchema());

  const country = useMemo(() => {
    if (!mobileNumber) return "Afghanistan";
    try {
      return (
        (countries.find(
          (country: any) =>
            country?.[2] ===
            parsePhoneNumber(mobileNumber.startsWith("+") ? mobileNumber : "+" + mobileNumber).country?.toLowerCase()
        )?.[0] as string | undefined) ?? ("Afghanistan" as string)
      );
    } catch {
      return "Afghanistan";
    }
  }, [mobileNumber]);

  const { control, handleSubmit, formState } = useForm<z.infer<typeof FormSchema>>({
    resolver: zodResolver(FormSchema as any),
    defaultValues: {
      ...fields.reduce((acc, field) => ({ ...acc, [field]: "" }), {}),
      ...(fields.includes("country") ? { country } : {})
    },
    mode: "onBlur"
  });

  const next = () => {
    openRegistrationSheet(selectedProgram.id, false);
    openWelcomeSheet(selectedProgram.id, true);
  };

  const onSubmit: SubmitHandler<z.infer<typeof FormSchema>> = (data) => {
    return new Promise<void>((resolve, reject) => {
      if (props.config.events?.onRegister) {
        props.config.events
          ?.onRegister({
            ...data,
            ...(data.birthday ? { birthday: dayjs(data.birthday).format("DD.MM.YYYY") } : {}),
            phoneNumber: mobileNumber
          })
          ?.then(() => {
            window.snackbar.enqueue(t("Successfully registered"), {
              variant: "success",
              autoHideDuration: 5000,
              persist: false
            });
            next();
            resolve();
          })
          .catch((err) => {
            window.snackbar.enqueue(
              t(err?.data?.items ?? err?.data?.message ?? err?.message ?? "Something went wrong"),
              {
                variant: "error",
                autoHideDuration: 5000,
                persist: false
              }
            );
            reject();
          });
      } else {
        next();
        resolve();
      }
    });
  };

  const primaryAction = (
    <Button
      type="submit"
      loading={formState.isSubmitting}
      disabled={formState.isSubmitting || !formState.isValid}
      data-testid={testIds.button}
    >
      {t("Sign up")}
    </Button>
  );

  return (
    <form onSubmit={handleSubmit(onSubmit)} className={defaultStyles.form}>
      <div className={defaultStyles.entry}>
        <Typography fontWeight={500} variant="body1">
          {t("Enter the Information")}
        </Typography>
        {fields.includes("firstName") && (
          <Controller
            name="firstName"
            control={control}
            render={({ field }) => (
              <div className={defaultStyles.itemWrapper}>
                <Typography variant="body2">
                  {t("First Name")}
                  {requiredFields.includes("firstName") ? " *" : ""}
                </Typography>
                <TextField placeholder={t("First Name")} {...field} />
              </div>
            )}
          />
        )}
        {fields.includes("lastName") && (
          <Controller
            name="lastName"
            control={control}
            render={({ field }) => (
              <div className={defaultStyles.itemWrapper}>
                <Typography variant="body2">
                  {t("Last Name")}
                  {requiredFields.includes("lastName") ? " *" : ""}
                </Typography>
                <TextField placeholder={t("Last Name")} {...field} />
              </div>
            )}
          />
        )}
        {fields.includes("email") && (
          <Controller
            name="email"
            control={control}
            render={({ field }) => (
              <div className={defaultStyles.itemWrapper}>
                <Typography variant="body2">
                  {t("Email")}
                  {requiredFields.includes("email") ? " *" : ""}
                </Typography>
                <TextField
                  placeholder={t("Email")}
                  type="email"
                  {...field}
                  error={!!formState.errors.email?.message}
                  helperText={formState.errors.email?.message ? t("Invalid email") : undefined}
                />
              </div>
            )}
          />
        )}
        {fields.includes("gender") && (
          <Controller
            name="gender"
            control={control}
            render={({ field }) => (
              <div className={defaultStyles.itemWrapper}>
                <Typography variant="body2">
                  {t("Gender")}
                  {requiredFields.includes("gender") ? " *" : ""}
                </Typography>
                <TextField select {...field}>
                  <MenuItem value="male">{t("Male")}</MenuItem>
                  <MenuItem value="female">{t("Female")}</MenuItem>
                </TextField>
              </div>
            )}
          />
        )}
        {fields.includes("birthday") && (
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <Controller
              name="birthday"
              control={control}
              render={({ field }) => (
                <div className={defaultStyles.itemWrapper}>
                  <Typography variant="body2">
                    {t("Birthday")}
                    {requiredFields.includes("birthday") ? " *" : ""}
                  </Typography>
                  <DatePicker
                    value={field.value ? dayjs(new Date(field.value)) : undefined}
                    onChange={(e) => field.onChange(e?.format("YYYY-MM-DD"))}
                    maxDate={dayjs()}
                    slotProps={{
                      calendarHeader: {
                        className: defaultStyles.calendarHeader
                      }
                    }}
                  />
                </div>
              )}
            />
          </LocalizationProvider>
        )}
        {fields.includes("country") && (
          <Controller
            name="country"
            control={control}
            render={({ field }) => (
              <div className={defaultStyles.itemWrapper}>
                <Typography variant="body2">
                  {t("Address Country")}
                  {requiredFields.includes("country") ? " *" : ""}
                </Typography>
                <CountrySelector {...field} />
              </div>
            )}
          />
        )}
      </div>
      <div className={defaultStyles.bottom}>
        <Typography variant="caption" lineHeight="1rem" color="GrayText">
          {t("By clicking on Sign up you agree to the {{terms}}, and I consent to receive communications", {
            terms: selectedProgram.config?.registrationTermsLink ? (
              <a href={selectedProgram.config.registrationTermsLink} target="_blank" className={defaultStyles.terms}>
                {t("Terms & Conditions")}
              </a>
            ) : (
              <span className={defaultStyles.terms}>{t("Terms & Conditions")}</span>
            )
          })}
        </Typography>

        {loginPromptEnabled ? (
          <div className={defaultStyles["actions"]}>
            <Button className={defaultStyles["skip"]} onClick={props.onSkip}>
              {t("Skip")}
            </Button>
            {primaryAction}
          </div>
        ) : (
          primaryAction
        )}
      </div>
    </form>
  );
}

export default RegistrationSheet;
