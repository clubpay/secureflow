import WhatsAppLogo from "@/icons/WhatsAppLogo";
import { t } from "../../locales";
import { default as defaultStyles } from "./styles.module.scss";

function index() {
  return (
    <span className={defaultStyles.container}>
      <span>{t("Contact Us")}</span>
      <WhatsAppLogo width={30} height={30} />
    </span>
  );
}

export default index;
