import { useSubscriptionStore } from "@/store/subscription";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { Info } from "@mui/icons-material";
import defaultStyles from "./completion.prompt.module.scss";

interface SubscriptionCompletionPromptProps extends React.HTMLAttributes<HTMLDivElement> {
  program: ILoyaltyProgram<IQlubConfig>;
}

const SubscriptionCompletionPrompt = ({ program, ...props }: SubscriptionCompletionPromptProps) => {
  const optedForSubscription = useSubscriptionStore((state) => state.optedForSubscription);
  if (!optedForSubscription) return null;
  return (
    <div className={defaultStyles["root"]} {...props}>
      <Info width={20} height={20} />
      <span>{program.config.readableSubscriptionCompletionPrompt}</span>
    </div>
  );
};

export default SubscriptionCompletionPrompt;
