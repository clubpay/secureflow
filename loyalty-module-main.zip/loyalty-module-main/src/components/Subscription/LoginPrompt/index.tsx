import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { ILoyaltyProgram, InternalProgramType } from "@/types/entities/program";
import * as events from "@clubpay/customer-common-module/src/const/events";
import { Typography } from "@qlub-dev/qlub-kit";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";
import styles from "./styles.module.scss";

interface ISubscriptionLoginPromptProps extends React.HtmlHTMLAttributes<HTMLDivElement> {
  program: ILoyaltyProgram;
  currencyFormat: CurrencyFormat;
}

function SubscriptionLoginPrompt({ program, ...props }: ISubscriptionLoginPromptProps) {
  const openLoginSheet = useAuthStore((state) => state.openLoginSheet);
  const setLoginVerificationCallback = useAuthStore((state) => state.setLoginVerificationCallback);

  if (program.internalProgramType !== InternalProgramType.IN_SUB_DISCOUNT) {
    return null;
  }

  const onAlreadyAMemberClick = () => {
    openLoginSheet(program.id, true);
    setLoginVerificationCallback(program.id, async () => {
      document.dispatchEvent(new CustomEvent(events.login));
    });
  };

  return (
    <span className={styles["root"]} {...props} role="button" onClick={onAlreadyAMemberClick}>
      <Typography typo="caption_overline_medium" className={styles["already-a-member"]} component="span">
        {t("Already a qlub+ member?")}
      </Typography>
      <Typography typo="caption_overline_medium" component="span">
        {t("Log in and enjoy savings up to {{percentage}}!", {
          percentage: program.config.readableDiscountTeaserValue
        })}
      </Typography>
    </span>
  );
}

export default SubscriptionLoginPrompt;
