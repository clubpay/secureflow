import { forwardRef, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { default as APIManager } from "@/api";
import Button from "@/components/Common/Core/Button";
import { t } from "@/locales";
import { useGlobalStore } from "@/store/global";
import { Locales } from "@/types";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { getLocaleText } from "@clubpay/customer-common-module/src/component/MultiLocale";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";
import { ICustomerSubscription } from "@clubpay/customer-common-module/src/repository/common/subscription/type";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormGroup from "@mui/material/FormGroup";
import { Typography } from "@qlub-dev/qlub-kit";
import styles from "./styles.module.scss";

interface IProps {
  program: ILoyaltyProgram<IQlubConfig>;
  subscription: ICustomerSubscription;
  setIsFinal: (value: boolean) => void;
}

const CancelSubscription = forwardRef<HTMLDivElement, IProps>((props, ref) => {
  const { refetchProfile } = useAuth();

  const locale = useGlobalStore((state) => state.locale);
  const [selectedReason, setSelectedReason] = useState<number | null>(null);
  const reasons = props.program.config.cancelSubscriptionReasons || [];

  const api = APIManager.getInstance();

  const cancelMutation = useMutation({
    mutationFn: async (subscriptionID: number) => {
      const reason = reasons[selectedReason!]?.value;
      const result = await api.subscription.clean(subscriptionID, {
        cancellationReason: reason ? getLocaleText(reason, Locales.English, Locales.English) : "",
        currency: props.subscription.currency
      });
      props.setIsFinal(false);
      await refetchProfile();
      window.snackbar.enqueue(t("Subscription is successfully cancelled"), {
        variant: "success",
        autoHideDuration: 5000,
        persist: false
      });
      return result;
    },
    onError: () => {
      window.snackbar.enqueue(t("Something went wrong. Please try again"), {
        variant: "error",
        autoHideDuration: 5000,
        persist: false
      });
    }
  });

  function handleReasonChange(event: React.ChangeEvent<HTMLInputElement>, index: number) {
    if (event.target.checked) setSelectedReason(index);
    else setSelectedReason(null);
  }

  function handleCancelSubscription() {
    cancelMutation.mutate(props.subscription.subscriptionID);
  }

  return (
    <div className={styles.root} ref={ref} {...props}>
      <div className={styles["inner-container"]}>
        <Typography fontWeight={600} typo="title_md">
          {t("Sorry to hear that, what is the reason for cancellation?")}
        </Typography>
        <FormGroup>
          {reasons.map((reason, index) => (
            <FormControlLabel
              control={<Checkbox checked={index === selectedReason} onChange={(e) => handleReasonChange(e, index)} />}
              label={getLocaleText(reason.value, locale, Locales.English)}
              key={index}
            />
          ))}
        </FormGroup>
      </div>
      <div className={styles.bottom}>
        <Button
          loading={cancelMutation.isPending}
          disabled={(!!reasons.length && selectedReason === null) || cancelMutation.isPending}
          onClick={handleCancelSubscription}
        >
          {t("Confirm cancellation")}
        </Button>
      </div>
    </div>
  );
});

export default CancelSubscription;
