import { Typography } from "@qlub-dev/qlub-kit";
import styles from "./styles.module.scss";

function Info({ children, ...props }: React.HtmlHTMLAttributes<HTMLDivElement>) {
  return (
    <div className={styles["root"]} {...props}>
      <Typography typo="body_sm">{children}</Typography>
    </div>
  );
}

export default Info;
