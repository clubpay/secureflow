import { t } from "@/locales";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import styles from "./styles.module.scss";

interface IProps {
  program: ILoyaltyProgram<IQlubConfig>;
}

function Hamburger({ program }: IProps): JSX.Element {
  return (
    <span className={styles.container}>
      {program.config.logo && (
        <span className={styles.icon}>
          <img src={program.config.logo} alt="logo" />
        </span>
      )}
      {t("Manage subscription")}
    </span>
  );
}

export default Hamburger;
