import { forwardRef, useState } from "react";
import { default as dayjs } from "dayjs";
import "dayjs/locale/ar";
import "dayjs/locale/es";
import "dayjs/locale/ja";
import "dayjs/locale/ko";
import "dayjs/locale/pt";
import "dayjs/locale/tr";
import "dayjs/locale/zh";
import "dayjs/locale/zh-hk";
import background from "@/assets/vectors/subscription-bg.svg";
import Benefit from "@/components/Benefit";
import Button from "@/components/Common/Core/Button";
import Price from "@/components/Common/Price";
import CancelSubscription from "@/components/Subscription/Cancel";
import Info from "@/components/Subscription/Info";
import { QlubPlus } from "@/icons";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { getTrialExpiringDate } from "@/utils/subscriptions";
import { ICustomerSubscription } from "@clubpay/customer-common-module/src/repository/common/subscription/type";
import { Typography } from "@qlub-dev/qlub-kit";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";
import styles from "./styles.module.scss";

interface IProps {
  program: ILoyaltyProgram<IQlubConfig>;
  subscription: ICustomerSubscription;
  currencyFormat: CurrencyFormat;
  lang: string;
  isTemporarilySuspended: boolean;
}

const ManageSubscription = forwardRef<HTMLDivElement, IProps>(
  ({ program, subscription, isTemporarilySuspended, currencyFormat, lang, ...props }, ref) => {
    const [isFinal, setIsFinal] = useState(false);
    const profile = useAuthStore((state) => state.user[program.id]);

    const trialExpiringDate = getTrialExpiringDate(subscription?.createdAt, subscription?.freeMonths);

    const isTrialExist = trialExpiringDate.isAfter(dayjs());

    function handleCancelSubscription() {
      setIsFinal(true);
    }

    if (isFinal) return <CancelSubscription program={program} subscription={subscription} setIsFinal={setIsFinal} />;

    return (
      <div className={styles.root} ref={ref} {...props}>
        <div className={styles["inner-container"]}>
          <div className={styles.banners}>
            <div className={styles.savings}>
              <img src={background.src} />
              <QlubPlus color="#fff" />
              <div>
                <Typography typo="caption_overline">
                  {t("You've saved a total of {{value}}", {
                    value: (
                      <Price
                        sx={{ fontSize: "1.5rem" }}
                        value={profile?.discountSavings?.toString()}
                        currencyFormat={currencyFormat}
                      />
                    )
                  })}
                </Typography>
                {subscription?.createdAt && (
                  <Typography typo="caption_overline">
                    {t("since {{date}}", {
                      date: (
                        <span>
                          {dayjs(subscription.createdAt).locale(lang.replace("hk", "zh-hk")).format("Do MMM YYYY")}
                        </span>
                      )
                    })}
                  </Typography>
                )}
              </div>
            </div>
            {subscription.status === "suspended" ? (
              <Info>
                {t(
                  dayjs(subscription.renewalDate).isBefore(dayjs())
                    ? "Your subscription has been cancelled"
                    : "Your subscription has been cancelled, but you will retain access until {{date}}",
                  {
                    date: (
                      <span className={styles.price}>
                        {dayjs(subscription?.renewalDate)
                          .locale(lang.replace("hk", "zh-hk"))
                          .format("Do MMM YYYY")}
                      </span>
                    )
                  }
                )}
              </Info>
            ) : (
              <Info>
                {t("Your subscription renews on {{date}}", {
                  date: (
                    <span className={styles.price}>
                      {dayjs(subscription?.renewalDate)
                        .locale(lang.replace("hk", "zh-hk"))
                        .format("Do MMM YYYY")}
                    </span>
                  )
                })}
                <br />
                <Typography typo="caption_overline">
                  {t("Next billing amount is {{value}}", {
                    value: (
                      <span className={styles.price}>
                        <Price value={subscription?.amount?.toString()} currencyFormat={currencyFormat} />
                      </span>
                    )
                  })}
                </Typography>
              </Info>
            )}
          </div>
          <div className={styles.benefits}>
            <Typography fontWeight={600} typo="title_md">
              {t("Subscription benefits")}
            </Typography>
            <div className={styles.container}>
              {program?.config?.loyaltyBenefits?.map((benefit, index) => (
                <Benefit key={index} index={index + 1} title={benefit.key} description={benefit.value} />
              ))}
            </div>
          </div>
        </div>
        {!isTemporarilySuspended && (
          <div className={styles.bottom}>
            {isTrialExist ? (
              <div className={styles.info}>
                <Typography align="center" typo="caption_overline">
                  {t("You may cancel your subscription after {{date}}", {
                    date: (
                      <span className={styles.price}>
                        {trialExpiringDate.locale(lang.replace("hk", "zh-hk")).format("Do MMM YYYY")}
                      </span>
                    )
                  })}
                </Typography>
              </div>
            ) : (
              <Button variant="outlined" onClick={handleCancelSubscription}>
                {t("Cancel subscription")}
              </Button>
            )}
          </div>
        )}
      </div>
    );
  }
);

export default ManageSubscription;
