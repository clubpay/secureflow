import { forwardRef } from "react";
import { default as Price } from "@/components/Common/Price";
import { Gift, QlubPlus } from "@/icons";
import { t } from "@/locales";
import { useGlobalStore } from "@/store/global";
import { Typography } from "@qlub-dev/qlub-kit";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";
import styles from "./styles.module.scss";

interface ISubscribtionPromptProps {
  currencyFormat: CurrencyFormat;
}

const SubscribtionPrompt = forwardRef<HTMLDivElement, ISubscribtionPromptProps>(({ currencyFormat, ...props }, ref) => {
  const paymentDetails = useGlobalStore((state) => state.paymentDetails);
  const applicableDiscount = paymentDetails?.billNumber?.qlubLoyaltyDiscount;

  if (!applicableDiscount) return <></>;

  return (
    <div ref={ref} className={styles.root} {...props}>
      <div className={styles["sub-container"]}>
        <div className={styles["top-container"]}>
          <span>
            {t("You save {{value}} on this bill", {
              value: (
                <span className={styles.price}>
                  <Price value={applicableDiscount.toString()} currencyFormat={currencyFormat} />
                </span>
              )
            })}
          </span>
          <div className={styles["logo-wrapper"]}>
            <QlubPlus height={12} width={30} color="#fff" />
          </div>
        </div>
        <div className={styles["bottom-container"]}>
          <Gift />
          <Typography className={styles.text}>{t("Pay the bill to apply the discount")}</Typography>
        </div>
      </div>
    </div>
  );
});

export default SubscribtionPrompt;
