import { forwardRef } from "react";
import { default as Price } from "@/components/Common/Price";
import { useGetLoyaltySubscriptionDiscount } from "@/hooks/api";
import { QlubPlus } from "@/icons";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useSubscriptionStore } from "@/store/subscription";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { getSubscriptionFreeMonthPeriod, getSubscriptionPeriodAsNoun } from "@/utils/subscriptions";
import { Checkbox } from "@mui/material";
import { Typography } from "@qlub-dev/qlub-kit";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";
import { default as SubscriptionLoginPrompt } from "../../LoginPrompt";
import { default as SubscriptionRenewal } from "../../Renewal";
import styles from "./styles.module.scss";

interface ISubscribtionPromptProps {
  program: ILoyaltyProgram<IQlubConfig>;
  currencyFormat: CurrencyFormat;
  disabled?: boolean;
  onSubscriptionChange?: (optedForSubscription: boolean) => void;
}

const SubscribtionPrompt = forwardRef<HTMLDivElement, ISubscribtionPromptProps>(
  ({ program, currencyFormat, disabled, onSubscriptionChange, ...props }, ref) => {
    const optedForSubscription = useSubscriptionStore((state) => state.optedForSubscription);
    const user = useAuthStore((state) => state.user[program.id]);
    const discountValue = useGetLoyaltySubscriptionDiscount(program);

    return (
      <div ref={ref} className={styles.root} {...props}>
        <div className={styles["sub-container"]}>
          <div className={styles["top-container"]}>
            <div className={styles["title-container"]}>
              <Checkbox
                className={styles.checkbox}
                disabled={disabled}
                checked={optedForSubscription}
                onChange={(_, checked) => {
                  onSubscriptionChange?.(checked);
                }}
              />
              {program.subscription?.options?.activateWelcomeDiscount && discountValue ? (
                <Typography typo="price">
                  {t("Subscribe now and save {{value}} on this bill", {
                    value: (
                      <span className={styles.price}>
                        <Price value={discountValue?.toString()} currencyFormat={currencyFormat} />
                      </span>
                    )
                  })}
                </Typography>
              ) : (
                <Typography typo="price">{t("Subscribe now")}</Typography>
              )}
            </div>
            <div className={styles["logo-wrapper"]}>
              <QlubPlus height={12} width={30} color="#fff" />
            </div>
          </div>
          <div className={styles["bottom-container"]}>
            {!optedForSubscription && (
              <Typography className={styles.text}>
                {t(
                  false &&
                    program.subscription!.options?.subscriptionFreeMonths &&
                    program.config.showSubscriptionFreeMonths
                    ? "{{price}}/{{period}} | Try free for the first {{freeMonthPeriod}} on qlub+!"
                    : "{{price}}/{{period}}",
                  {
                    price: (
                      <Price
                        value={(program.subscription!.subscriptionAmount.fixed.amount / 100).toString()}
                        currencyFormat={currencyFormat}
                      />
                    ),
                    period: getSubscriptionPeriodAsNoun(program.subscription!),
                    freeMonthPeriod: getSubscriptionFreeMonthPeriod(program.subscription!)
                  }
                )}
              </Typography>
            )}
            {/* <Gift /> */}
            {optedForSubscription && (
              <Typography className={styles.text}>
                {t(
                  program.subscription?.options?.activateWelcomeDiscount
                    ? "Pay the bill to apply the discount and start subscription"
                    : "Pay the bill to start subscription"
                )}
              </Typography>
            )}
          </div>
        </div>
        {user?.isAuthorized ? (
          optedForSubscription && <SubscriptionRenewal program={program} currencyFormat={currencyFormat} />
        ) : (
          <SubscriptionLoginPrompt program={program} currencyFormat={currencyFormat} />
        )}
      </div>
    );
  }
);

export default SubscribtionPrompt;
