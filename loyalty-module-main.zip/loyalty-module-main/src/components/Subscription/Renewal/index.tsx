import { default as dayjs } from "dayjs";
import { default as Price } from "@/components/Common/Price";
import { t } from "@/locales";
import { ILoyaltyProgram, IQlubConfig, InternalProgramType } from "@/types/entities/program";
import { getSubscriptionPeriod } from "@/utils/subscriptions";
import { Typography } from "@qlub-dev/qlub-kit";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";
import styles from "./styles.module.scss";

interface ISubscriptionRenewalProps extends React.HtmlHTMLAttributes<HTMLDivElement> {
  program?: ILoyaltyProgram<IQlubConfig>;
  currencyFormat: CurrencyFormat;
}

function SubscriptionRenewal({ program, currencyFormat, ...props }: ISubscriptionRenewalProps) {
  if (program?.internalProgramType !== InternalProgramType.IN_SUB_DISCOUNT) return null;
  return (
    <div className={styles["root"]} {...props}>
      <Typography typo="caption_overline_medium">
        {t(
          "A {{period}} charge of {{amount}} will be applied starting on {{date}} for your subscription. You may cancel anytime after the first month",
          {
            period: getSubscriptionPeriod(program.subscription!),
            amount: (
              <span className={styles.price}>
                {
                  <Price
                    value={(program.subscription!.subscriptionAmount.fixed.amount / 100).toString()}
                    currencyFormat={currencyFormat}
                  />
                }
              </span>
            ),
            date: (
              <span className={styles["renewal-date"]}>
                {dayjs(dayjs().date() > 27 ? dayjs().add(1, "month").set("date", 1) : dayjs().add(1, "day"))
                  .add(program.subscription!.options?.subscriptionFreeMonths ?? 0, "month")
                  .format("DD-MMM-YYYY")}
              </span>
            )
          }
        )}
      </Typography>
    </div>
  );
}

export default SubscriptionRenewal;
