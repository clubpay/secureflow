import { default as Price } from "@/components/Common/Price";
import Info from "@/components/Subscription/Info";
import { useGetLoyaltySubscriptionDiscount } from "@/hooks/api";
import { t } from "@/locales";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";
import styles from "./styles.module.scss";

interface ISubscribeNowProps extends React.HtmlHTMLAttributes<HTMLDivElement> {
  program?: ILoyaltyProgram<IQlubConfig>;
  currencyFormat: CurrencyFormat;
}

function SubscribeNow({ program, currencyFormat, ...props }: ISubscribeNowProps) {
  const discountValue = useGetLoyaltySubscriptionDiscount(program);
  if (!program?.subscription?.options?.activateWelcomeDiscount || !discountValue) return null;
  return (
    <Info {...props}>
      {t("Subscribe now and save {{value}} on this bill", {
        value: (
          <span className={styles.price}>
            <Price value={discountValue.toString()} currencyFormat={currencyFormat} />
          </span>
        )
      })}
    </Info>
  );
}

export default SubscribeNow;
