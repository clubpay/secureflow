import { forwardRef } from "react";
import { default as Price } from "@/components/Common/Price";
import { Promotion } from "@/icons";
import { Typography } from "@qlub-dev/qlub-kit";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";
import styles from "./styles.module.scss";

interface ILineItemProps extends React.HTMLAttributes<HTMLDivElement> {
  value: number;
  currencyFormat: CurrencyFormat;
  color?: string;
  label?: string;
}

const LineItem = forwardRef<HTMLDivElement, ILineItemProps>(
  ({ value, currencyFormat, color, label, ...props }, ref) => {
    return (
      <div className={styles.root} ref={ref} {...props}>
        <div className={styles["left-wrapper"]}>
          <Promotion color={color} />
          <Typography typo="caption_overline" fontWeight={600} style={{ color }}>
            {label}
          </Typography>
        </div>
        <div className={styles["right-wrapper"]} style={{ color }}>
          <Typography typo="body_sm" fontWeight={500}>
            <Price
              value={Math.abs(value).toString()}
              currencyFormat={currencyFormat}
              sx={{
                "fontSize": "14px",
                "fontWeight": 500,
                "&>span": { fontSize: "10px", fontWeight: 600 }
              }}
              leading={value < 0 ? "-" : ""}
            />
          </Typography>
        </div>
      </div>
    );
  }
);

export default LineItem;
