import { QlubPlus } from "@/icons";
import { t } from "@/locales";
import styles from "./styles.module.scss";

interface IProps {
  inherit?: boolean;
}

function DiscoverVenues({ inherit }: IProps): JSX.Element {
  return (
    <span className={styles.container}>
      <QlubPlus color={inherit ? "inherit" : "#7d00d4"} />
      {t("venues")}
    </span>
  );
}

export default DiscoverVenues;
