import { forwardRef, useEffect } from "react";
import classNames from "classnames";
import { default as Price } from "@/components/Common/Price";
import { QlubPlus } from "@/icons";
import { t } from "@/locales";
import { useGlobalStore } from "@/store/global";
import { useSubscriptionStore } from "@/store/subscription";
import { PopupVariant } from "@/types";
import { Typography } from "@qlub-dev/qlub-kit";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";
import styles from "./styles.module.scss";

interface ISavingsProps extends React.HtmlHTMLAttributes<HTMLDivElement> {
  savings: number;
  currencyFormat: CurrencyFormat;
  onDiscoverClick?: () => void;
}

const Savings = forwardRef<HTMLDivElement, ISavingsProps>(
  ({ savings, currencyFormat, onDiscoverClick, ...props }, ref) => {
    const openPopup = useGlobalStore().popup.openPopup;

    const savingsPopupDisplayed = useSubscriptionStore((state) => state.savingsPopupDisplayed);
    const setSavingsPopupDisplayed = useSubscriptionStore((state) => state.setSavingsPopupDisplayed);

    const savingsText = t("You've saved {{amount}} on this bill", {
      amount: (
        <span className={styles.price}>
          <Price value={savings.toString()} currencyFormat={currencyFormat} />
        </span>
      )
    });

    useEffect(() => {
      if (savings && !savingsPopupDisplayed) {
        openPopup({
          title: t("Congratulations!"),
          subtitle: savingsText,
          buttonText: t("Explore qlub+ Venues"),
          variant: PopupVariant.Congratulations,
          buttonArrow: true,
          autoCloseDuration: 5000,
          actionClickHandler: onDiscoverClick
        });
        setSavingsPopupDisplayed(true);
      }
    }, [savings, savingsPopupDisplayed]);

    return (
      <div ref={ref} {...props} className={classNames(styles.root, props.className)}>
        <div className={styles["logo-wrapper"]}>
          <QlubPlus height={16} width={36} color="#fff" />
        </div>
        <div className={styles["content"]}>
          <Typography typo="body_sm" fontWeight={600}>
            {savingsText}
          </Typography>
          <Typography className={styles.description}>{t("Enjoy more savings with every qlub+ payment")}</Typography>
        </div>
      </div>
    );
  }
);

export default Savings;
