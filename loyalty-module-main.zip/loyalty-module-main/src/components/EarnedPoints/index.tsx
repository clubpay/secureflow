import classNames from "classnames";
import { default as Price } from "@/components/Common/Price";
import { default as Star } from "@/icons/Star";
import { t } from "@/locales";
import { useWalletStore } from "@/store/wallet";
import { IGenericOptions } from "@/types";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";
import { default as OutlinedButton } from "../Common/Core/OutlinedButton";
import { default as styles } from "./earned.points.module.scss";

export const testIds = {
  points: "earned-points",
  action: "earned-points-action"
};

export interface IProps extends IGenericOptions {
  currencyFormat: CurrencyFormat;
  program: ILoyaltyProgram<IQlubConfig>;
  amount: number;
  hideAction?: boolean;
  className?: string;
  style?: React.CSSProperties;
}

const EarnedPoints = ({ amount, currencyFormat, hideAction, className, style }: IProps) => {
  const openFunctionSheet = useWalletStore((state) => state.openFunctionSheet);
  return (
    <>
      <div className={classNames(styles.root, className)} style={style}>
        <div>
          <Star />
          {t("Earned")}:
          <span className={styles.program} data-testid={testIds.points}>
            + <Price value={amount.toString()} currencyFormat={currencyFormat} />
          </span>
        </div>
        {!hideAction && (
          <OutlinedButton onClick={() => openFunctionSheet(true)} className={styles.cta} data-testid={testIds.action}>
            {t("How It Works")}
          </OutlinedButton>
        )}
      </div>
    </>
  );
};

export default EarnedPoints;
