import { useEffect, useRef, useState } from "react";
import { default as Chip } from "@/components/Common/Chip";
import { default as Image } from "@/components/Common/Core/Image";
import { defaults } from "@/constants";
import { t } from "@/locales";
import { IVenue } from "@/types";
import { InternalProgramType } from "@/types/entities/program";
import { getBurnPercentage } from "@/utils";
import { getBaseDiscountAmountText } from "@/utils/discounts";
import { default as VenueDetails } from "../Details";
import { default as styles } from "./venue.card.module.scss";

interface IProps extends React.HTMLAttributes<HTMLDivElement> {
  venue: IVenue;
  getLocaleText: (key: string, lang: string, defaultLang: string) => string;
  locale: string;
}

const VenueCard = ({ venue, getLocaleText, locale }: IProps) => {
  const redemptionChipRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [scheduleChipWidth, setScheduleChipWidth] = useState("auto");
  const burnPermittedScheduleText = getLocaleText(venue.config?.burnPermittedScheduleText ?? "", locale, locale);

  useEffect(() => {
    if (containerRef.current && burnPermittedScheduleText) {
      setScheduleChipWidth(
        containerRef?.current?.clientWidth - (redemptionChipRef?.current?.clientWidth ?? 0) - 34 + "px"
      );
    }
  }, [redemptionChipRef, containerRef, burnPermittedScheduleText]);

  return (
    <div className={styles.root}>
      <div ref={containerRef} className={styles["image-container"]}>
        <Image src={venue.photoUrl} />
        {venue.internalProgramType !== InternalProgramType.IN_NONE &&
          (venue.internalProgramType === InternalProgramType.IN_SUB_DISCOUNT ? (
            venue.discounts &&
            venue.discounts.length > 0 && (
              <Chip
                label={t("Save {{value}} on the bill", {
                  value: getBaseDiscountAmountText(venue.discounts[0], {
                    cc: venue.currency?.symbol,
                    cs: venue.currency?.symbol,
                    currencyPrecision: venue.currency?.precision ?? defaults.currency.precision,
                    currencyCommaSeparator: "disable"
                  })
                })}
                className={styles["burn-chip"]}
              />
            )
          ) : (
            <>
              {venue.burnEnabled && (
                <Chip
                  ref={redemptionChipRef}
                  label={t("Redeem up to {{percentage}}", {
                    percentage: getBurnPercentage(venue.config)
                  })}
                  className={styles["burn-chip"]}
                />
              )}
              {burnPermittedScheduleText && (
                <Chip
                  label={burnPermittedScheduleText}
                  className={styles["schedule-chip"]}
                  sx={{
                    height: "auto !important",
                    width: "auto !important",
                    maxWidth: scheduleChipWidth
                  }}
                />
              )}
            </>
          ))}
      </div>
      <VenueDetails venue={venue} />
    </div>
  );
};

export default VenueCard;
