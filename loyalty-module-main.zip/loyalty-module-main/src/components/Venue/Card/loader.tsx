import { Skeleton } from "@mui/material";
import { default as VenueDetailsLoader } from "../Details/loader";
import { default as styles } from "./venue.card.module.scss";

const Loader = () => {
  return (
    <div className={styles.root}>
      <Skeleton
        variant="rounded"
        width="100%"
        sx={{ aspectRatio: 11 / 5, borderRadius: "8px !important", height: "unset" }}
      />
      <VenueDetailsLoader />
    </div>
  );
};

export default Loader;
