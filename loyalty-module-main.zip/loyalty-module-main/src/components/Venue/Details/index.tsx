import Link from "next/link";
import { default as Chip } from "@/components/Common/Chip";
import { Map, Menu } from "@/icons";
import { t } from "@/locales";
import { IVenue } from "@/types";
import { getTableLessMenuLink } from "@clubpay/customer-common-module/src/utility/menuLink";
// import { Star } from "@mui/icons-material";
import { default as styles } from "./venue.details.module.scss";

interface IProps extends React.HTMLAttributes<HTMLDivElement> {
  venue: IVenue;
}

const VenueDetails = ({ venue }: IProps) => {
  return (
    <div className={styles.root}>
      <span className={styles.name}>{venue.title}</span>
      <div className={styles.address}>
        {/* <Star /> {venue.reviewRating?.toFixed(1)} •  */}
        {venue.address1 ? venue.address1 + ", " : ""} {venue.address2 ? venue.address2 + ", " : ""} {venue.city}
      </div>
      <div className={styles.links}>
        {venue.directionsUrl && (
          <a href={venue.directionsUrl} target="_blank">
            <Chip label={t("Map")} variant="black" icon={<Map />} sx={{ cursor: "pointer" }} />
          </a>
        )}
        {!venue.hideViewMenuButton && (
          <Link
            legacyBehavior
            href={getTableLessMenuLink({ cc: venue.country.code, slug: venue.code }, venue.orderMode as any)}
            passHref
          >
            <a
              onClick={(e) => {
                const href = e.currentTarget?.getAttribute("href");
                if (href) {
                  e.preventDefault();
                  window.location.href = href;
                }
              }}
            >
              <Chip label={t("Menu")} variant="black" icon={<Menu />} sx={{ cursor: "pointer" }} />
            </a>
          </Link>
        )}
      </div>
    </div>
  );
};

export default VenueDetails;
