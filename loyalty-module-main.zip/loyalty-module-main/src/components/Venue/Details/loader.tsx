import { Skeleton } from "@mui/material";
import { default as styles } from "./venue.details.module.scss";

const Loader = () => {
  return (
    <div className={styles.loaderRoot}>
      <Skeleton variant="rounded" width="100%" height="22px" sx={{ borderRadius: "6px !important" }} />
      <Skeleton variant="rounded" width="100%" height="17px" sx={{ borderRadius: "4px !important" }} />
    </div>
  );
};

export default Loader;
