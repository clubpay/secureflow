import { Info } from "@mui/icons-material";
import defaultStyles from "./cannotRedeem.module.scss";

interface CannotRedeemProps extends React.HTMLAttributes<HTMLDivElement> {
  message: string;
}

const CannotRedeem = ({ message, ...props }: CannotRedeemProps) => {
  return (
    <div className={defaultStyles["root"]} {...props}>
      <Info width={20} height={20} />
      <span>{message}</span>
    </div>
  );
};

export default CannotRedeem;
