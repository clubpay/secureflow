import { default as classNames } from "classnames";
import { default as dynamic } from "next/dynamic";
import { default as congratulationAnimation } from "@/assets/animations/congratulation.json";
import { default as successAnimation } from "@/assets/animations/success.json";
import { Arrow, Cross, Party } from "@/icons";
import { useGlobalStore } from "@/store/global";
import { PopupVariant } from "@/types";
import { Dialog, DialogContent } from "@mui/material";
import { default as Button } from "../Core/Button";
import { default as defaultStyles } from "./popup.module.scss";

const Lottie = dynamic(() => import("lottie-react"), { ssr: false });

const animations: Record<PopupVariant, any> = {
  [PopupVariant.Success]: successAnimation,
  [PopupVariant.Congratulations]: congratulationAnimation,
  [PopupVariant.Error]: null,
  [PopupVariant.Warning]: null,
  [PopupVariant.Info]: null
};

const animationClasses: Record<PopupVariant, string | null> = {
  [PopupVariant.Success]: null,
  [PopupVariant.Congratulations]: defaultStyles["animation-congratulations"],
  [PopupVariant.Error]: null,
  [PopupVariant.Warning]: null,
  [PopupVariant.Info]: null
};

const icons: Record<PopupVariant, any> = {
  [PopupVariant.Success]: null,
  [PopupVariant.Congratulations]: Party,
  [PopupVariant.Error]: null,
  [PopupVariant.Warning]: null,
  [PopupVariant.Info]: null
};

export const popupTestIds = {
  [PopupVariant.Success]: "popup-success",
  [PopupVariant.Congratulations]: "popup-congratulations",
  [PopupVariant.Error]: "popup-error",
  [PopupVariant.Warning]: "popup-warning",
  [PopupVariant.Info]: "popup-info"
};

export const Popup = () => {
  const { open, title, subtitle, buttonText, buttonArrow, variant, actionClickHandler, closePopup } =
    useGlobalStore().popup;
  const onActionClick = () => {
    closePopup();
    actionClickHandler?.();
  };
  return (
    <Dialog
      open={!!open}
      onClose={closePopup}
      sx={{
        "& .MuiDialog-container": {
          "& .MuiPaper-root": {
            width: "100%",
            maxWidth: "350px",
            borderRadius: "24px",
            overflow: "hidden"
          }
        }
      }}
      data-testid={popupTestIds[variant]}
      data-open={!!open}
    >
      <DialogContent>
        <div className={defaultStyles.close} onClick={closePopup}>
          <Cross />
        </div>
        <div className={defaultStyles.content}>
          <Lottie
            animationData={animations[variant] as any}
            loop={true}
            className={classNames(defaultStyles.animation, animationClasses[variant])}
          />
          {icons[variant] && <div className={defaultStyles.icon}>{icons[variant]({ width: 28, height: 28 })}</div>}
          <span className={defaultStyles.title}>{title}</span>
          {subtitle && <span className={defaultStyles.subtitle}>{subtitle}</span>}
          {buttonText && (
            <Button onClick={onActionClick} variant="contained" color="primary" className={defaultStyles.button}>
              {buttonText}
              {buttonArrow && <Arrow className={defaultStyles.svg} />}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default Popup;
