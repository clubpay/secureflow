import { MouseEvent, useState } from "react";
import { MoreVertRounded } from "@mui/icons-material";
import { IconButton, Menu, MenuItem, SvgIconTypeMap, Typography } from "@mui/material";
import { OverridableComponent } from "@mui/material/OverridableComponent";

interface IOptions {
  icon?: OverridableComponent<SvgIconTypeMap<unknown, "svg">>;
  text: string;
  action: () => void;
  disabled?: boolean;
}

interface IKebabMenuProps {
  options: IOptions[];
}

const KebabMenu = ({ options }: IKebabMenuProps) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  const handleClick = (e: MouseEvent<HTMLElement>) => setAnchorEl(e.currentTarget);
  const handleClose = () => setAnchorEl(null);

  return (
    <>
      <IconButton onClick={handleClick}>
        <MoreVertRounded />
      </IconButton>
      <Menu
        id="long-menu"
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right"
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right"
        }}
        elevation={0}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        PaperProps={{
          style: {
            minWidth: "252px",
            boxShadow: "0px 3px 14px 0px rgba(0, 0, 0, 0.08)",
            borderRadius: "8px"
          }
        }}
      >
        {options.map(({ text, action, icon: Icon, disabled }) => (
          <MenuItem
            sx={{ marginY: "8px", paddingY: "10px" }}
            key={text}
            onClick={() => {
              handleClose();
              action();
            }}
            disabled={!!disabled}
          >
            {Icon && <Icon fontSize="small" color="action" sx={{ marginRight: "12px" }} />}
            <Typography fontSize="14px" fontWeight="500">
              {text}
            </Typography>
          </MenuItem>
        ))}
      </Menu>
    </>
  );
};

export default KebabMenu;
