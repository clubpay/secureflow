import { Button as QlubKitButton } from "@qlub-dev/qlub-kit";
import { IButtonProps } from "@qlub-dev/qlub-kit/dist/components/Button";
import defaultStyles from "./button.module.scss";

const Button: React.FC<IButtonProps> = ({ children, className = "", loading, ...props }) => {
  className += ` ${defaultStyles.base}`;
  if (loading) className += ` ${defaultStyles.loading}`;
  return (
    <QlubKitButton {...props} loading={loading} variant={props.variant ?? "contained"} className={className}>
      {children}
    </QlubKitButton>
  );
};

export default Button;
