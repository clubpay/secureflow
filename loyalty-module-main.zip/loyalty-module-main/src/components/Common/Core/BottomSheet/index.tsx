import classNames from "classnames";
import { Drawer, DrawerClasses } from "@mui/material";
import { BackArrow, Cross } from "../../../../icons";
import { default as defaultStyles } from "./bottomsheet.module.scss";

interface BottomSheetProps extends React.HTMLAttributes<HTMLElement> {
  open: boolean;
  onBackHandler?: () => void;
  onCloseHandler?: () => void;
  headerImgUrl?: string;
  headerIconComponent?: React.ReactNode;
  title?: string;
  backButtonProps?: Record<string, any>;
  closeButtonProps?: Record<string, any>;
  baseClasses?: Partial<DrawerClasses>;
  headerClassName?: string;
}

const BottomSheet = ({
  children,
  open,
  onBackHandler,
  onCloseHandler,
  headerImgUrl,
  headerIconComponent,
  title,
  backButtonProps,
  closeButtonProps,
  className,
  baseClasses,
  headerClassName,
  ...props
}: BottomSheetProps) => {
  return (
    <Drawer
      open={open}
      onClose={onCloseHandler ?? onBackHandler}
      classes={{ paper: defaultStyles.paper, root: defaultStyles.root, ...baseClasses }}
      anchor="bottom"
      data-open={open}
      {...props}
    >
      <div className={classNames(defaultStyles.header, headerClassName)}>
        {onBackHandler && (
          <div className={defaultStyles["back-container"]}>
            <div className={defaultStyles.icon} onClick={onBackHandler} {...backButtonProps}>
              <BackArrow />
            </div>
          </div>
        )}
        {headerImgUrl || headerIconComponent ? (
          headerImgUrl ? (
            <div className={defaultStyles["image-container"]}>
              <img src={headerImgUrl} alt="logo" />
            </div>
          ) : (
            headerIconComponent
          )
        ) : (
          title && (
            <div className={defaultStyles["middle-container"]}>
              <span className={defaultStyles.title}>{title}</span>
            </div>
          )
        )}
        {onCloseHandler && (
          <div className={defaultStyles["close-container"]}>
            <div className={defaultStyles.icon} onClick={onCloseHandler} {...closeButtonProps}>
              <Cross />
            </div>
          </div>
        )}
      </div>
      <div className={`${defaultStyles.content} ${className}`}>{children}</div>
    </Drawer>
  );
};

export default BottomSheet;
