import { default as Qlub } from "@/icons/Qlub";
import { default as styles } from "./image.module.scss";

const Image = (props: React.ImgHTMLAttributes<HTMLImageElement>) => {
  if (props.src) {
    return <img className={styles.root} {...props} />;
  }
  return (
    <div className={styles["placeholder-root"]} {...props}>
      <Qlub />
    </div>
  );
};

export default Image;
