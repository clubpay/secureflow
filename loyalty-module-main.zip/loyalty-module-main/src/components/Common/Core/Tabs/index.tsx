import React, { useState } from "react";
import TabContext from "@mui/lab/TabContext";
import TabPanel from "@mui/lab/TabPanel";
import Tab from "@mui/material/Tab";
import MUITabs from "@mui/material/Tabs";
import styles from "./tabs.module.scss";

interface ITab {
  label: string;
  content: React.ReactNode;
}

interface IProps {
  data: ITab[];
}

const tabPanelClasses = { root: styles.tabPanelRoot };

const Tabs = ({ data }: IProps) => {
  const [selectedValue, setSelectedValue] = useState("0");

  const onTabChange = (_: any, newValue: number) => setSelectedValue(newValue.toString());

  return (
    <TabContext value={selectedValue.toString()}>
      <MUITabs
        onChange={onTabChange}
        value={selectedValue.toString()}
        classes={{ root: styles.tabs, flexContainer: styles.tabFlexContainer }}
        variant="fullWidth"
      >
        {data.map((tab, index) => (
          <Tab key={index} value={index.toString()} label={tab.label} classes={{ root: styles.tabRoot }} />
        ))}
      </MUITabs>
      {data.map((tab, index) => (
        <TabPanel key={index} value={index.toString()} classes={tabPanelClasses}>
          {tab.content}
        </TabPanel>
      ))}
    </TabContext>
  );
};

export default Tabs;
