import { Box, CircularProgress } from "@mui/material";

const DynamicLoader = () => {
  return (
    <Box
      sx={{
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }}
    >
      <CircularProgress size={24} />
    </Box>
  );
};

export default DynamicLoader;
