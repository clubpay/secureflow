import { forwardRef } from "react";
import { MenuItem, TextField, TextFieldProps } from "@mui/material";
import countries from "@qlub-dev/qlub-kit/dist/components/PhoneInput/data/rawCountries";

const CountrySelector = forwardRef<HTMLDivElement, TextFieldProps>(function CountrySelector(
  props: TextFieldProps,
  ref
): JSX.Element {
  return (
    <TextField select ref={ref} {...props}>
      {countries.map((country: (string | number | string[])[]) => (
        <MenuItem key={country[0] as string} value={country[0]}>
          {country[0]}
        </MenuItem>
      ))}
    </TextField>
  );
});

export default CountrySelector;
