import { Search as SearchIcon } from "@mui/icons-material";
import { InputAdornment, TextField, TextFieldProps } from "@mui/material";
import { default as styles } from "./search.module.scss";

const Search = (props: TextFieldProps) => {
  return (
    <TextField
      variant={props.variant ?? "outlined"}
      {...props}
      fullWidth={props.fullWidth ?? true}
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            <SearchIcon />
          </InputAdornment>
        ),
        className: styles["input-wrapper"],
        ...props.InputProps
      }}
      inputProps={{
        className: styles.input,
        ...props.inputProps
      }}
    />
  );
};

export default Search;
