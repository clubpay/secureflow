import styles from "./outlined.button.module.scss";

interface IProps extends React.HTMLAttributes<HTMLButtonElement> {
  arrow?: boolean;
}

const OutlinedButton = ({ children, onClick, arrow = true, ...props }: IProps) => {
  let className = styles.root;
  if (props.className) className += ` ${props.className}`;
  return (
    <button onClick={onClick} {...props} className={className}>
      {children}
      {arrow && <span>▾</span>}
    </button>
  );
};

export default OutlinedButton;
