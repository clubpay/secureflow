import ReactDataTable, { TableProps } from "react-data-table-component";

function DataTable<T>(props: TableProps<T>) {
  return (
    <ReactDataTable
      {...props}
      customStyles={{
        headCells: {
          style: {
            fontSize: "14px",
            fontWeight: 600,
            color: "#1A1C23",
            justifyContent: "center"
          }
        },
        headRow: {
          style: {
            backgroundColor: "#EBECF2",
            borderRadius: "0.5rem",
            border: "none",
            marginBottom: "0.75rem"
          }
        },
        cells: {
          style: {
            fontSize: "14px",
            fontWeight: 500,
            padding: "12px 8px",
            justifyContent: "center"
          }
        },
        rows: {
          style: {
            borderBottom: "none !important"
          }
        },
        ...props.customStyles
      }}
      persistTableHead={props.persistTableHead ?? true}
    />
  );
}

export default DataTable;
