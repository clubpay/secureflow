import { forwardRef } from "react";
import classNames from "classnames";
import { Chip as MUIChip, ChipProps as MUIChipProps } from "@mui/material";
import { default as styles } from "./chip.module.scss";

type ChipVariant = "primary" | "success" | "black" | Pick<MUIChipProps, "variant">;

interface ChipProps extends Omit<MUIChipProps, "variant"> {
  variant?: ChipVariant;
}

const Chip = forwardRef<HTMLDivElement, ChipProps>(({ variant = "primary", ...props }, ref) => {
  return (
    <MUIChip
      ref={ref}
      variant={variant as any}
      {...props}
      className={classNames(
        styles.root,
        variant === "primary" && styles.primary,
        variant === "success" && styles.success,
        variant === "black" && styles.black,
        props.className
      )}
    />
  );
});

export default Chip;
