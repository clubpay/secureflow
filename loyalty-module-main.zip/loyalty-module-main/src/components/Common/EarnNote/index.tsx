import { t } from "@/locales";
import { ILoyaltyProgram } from "@/types/entities/program";
import { default as defaultStyles } from "./note.module.scss";

interface IEarnNote extends React.HTMLAttributes<HTMLDivElement> {
  program?: ILoyaltyProgram;
}

const EarnNote: React.FC<IEarnNote> = ({ program, ...props }: IEarnNote) => {
  return (
    <div className={defaultStyles.root} {...props}>
      <p>
        <b>{t("Note")}</b>:{" "}
        {t("To earn {{loyaltyProgram}} points, please inform the staff before making a payment", {
          loyaltyProgram: program?.config.readableDisplayName
        })}
      </p>
    </div>
  );
};

export default EarnNote;
