import { useEffect } from "react";
import { useAuthStore } from "@/store/auth";
import { IEvents } from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";
import { default as UserConsent } from "@clubpay/customer-common-module/src/component/Consent/UserConsent";
import { ConsentType } from "@clubpay/customer-common-module/src/component/Consent/types";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { default as styles } from "./terms.module.scss";

const Terms = ({ program, events }: { program: ILoyaltyProgram; events?: IEvents }) => {
  const { openLoginSheet, toggleAgreedOnTerms } = useAuthStore();
  const { vendor } = useVendor();

  const isAgreedOnTerms = useAuthStore((state) => state.isAgreedOnTerms[program.id]);

  const modalCloseHandler = () => {
    openLoginSheet(program.id, false);
    events?.onSheetClose?.();
  };

  useEffect(() => {
    if (vendor?.country?.code === "ae") toggleAgreedOnTerms(program.id, true);
  }, []);

  return (
    <UserConsent
      consentBoxProps={{
        hasConsented: isAgreedOnTerms,
        handleClick: () => toggleAgreedOnTerms(program.id, !isAgreedOnTerms),
        className: styles.root
      }}
      messageFactoryProps={{
        type: ConsentType.Privacy,
        messageProps: {
          modalCloseHandler
        }
      }}
    />
  );
};

export default Terms;
