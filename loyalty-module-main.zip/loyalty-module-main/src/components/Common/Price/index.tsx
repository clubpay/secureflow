import { Price as Format } from "@qlub-dev/qlub-kit";
import { IProps } from "@qlub-dev/qlub-kit/dist/components/Format";

function Price(props: IProps) {
  return (
    <Format
      {...props}
      sx={{
        "display": "inline-flex",
        "alignItems": "baseline",
        "gap": "2px",
        "fontWeight": 600,
        "&>span": { fontWeight: 600 },
        ...props.sx
      }}
    />
  );
}

export default Price;
