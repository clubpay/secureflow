import { default as Price } from "@/components/Common/Price";
import { default as HowItWorks } from "@/components/Wallet/HowItWorks";
import { useGetLoyaltySubscriptionDiscount } from "@/hooks/api";
import { useDiscount } from "@/hooks/discount";
import { QlubPlus } from "@/icons";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useGlobalStore } from "@/store/global";
import { useWalletStore } from "@/store/wallet";
import { IGenericOptions } from "@/types";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { getBaseDiscountAmountText } from "@/utils/discounts";
import { Skeleton } from "@mui/material";
import { Typography } from "@qlub-dev/qlub-kit";
import { default as styles } from "./discount.module.scss";

export enum WalletType {
  Teaser = "teaser",
  Detailed = "detailed"
}

export interface IProps extends IGenericOptions, React.HTMLAttributes<HTMLDivElement> {
  program: ILoyaltyProgram<IQlubConfig>;
  billAmount?: number;
  loading?: boolean;
}

const Wallet = ({ program, loading, billAmount, currencyFormat }: IProps) => {
  const openFunctionSheet = useWalletStore((state) => state.openFunctionSheet);
  const qlubUser = useAuthStore((state) => state.qlubUser);
  const discount = useDiscount(program);
  const discountValue = useGetLoyaltySubscriptionDiscount(program);
  const paymentDetails = useGlobalStore((state) => state.paymentDetails);
  const applicableDiscount = paymentDetails?.billNumber?.qlubLoyaltyDiscount;

  if (!program.subscription) return <></>;

  const isSubscribed = qlubUser?.hasSubscription(program.subscription);

  if (isSubscribed && !applicableDiscount) return <></>;

  return (
    <div className={styles.root} onClick={() => openFunctionSheet(true)}>
      <div className={styles["detail-header"]}>
        <div className={styles["top-row"]}>
          <QlubPlus height={20} width={48} color="#fff" />
          <HowItWorks onClick={openFunctionSheet} />
        </div>
        {loading ? (
          <Skeleton width={120} height={35} />
        ) : (
          program.config.readableDiscountTeaserText && (
            <Typography typo="body_sm">
              {t(
                !isSubscribed
                  ? program.config.readableDiscountTeaserText
                  : billAmount
                  ? "Save {{value}} on this bill"
                  : "Save up to {{value}} on this bill",
                {
                  value: (
                    <span className={styles["discount-teaser-value"]}>
                      {!isSubscribed ? (
                        program.config.readableDiscountTeaserValue
                      ) : billAmount ? (
                        <Price value={discountValue.toString()} currencyFormat={currencyFormat} />
                      ) : (
                        getBaseDiscountAmountText(discount!, currencyFormat)
                      )}
                    </span>
                  )
                }
              )}
            </Typography>
          )
        )}
      </div>
      <div className={styles["teaser-row"]}>
        <Typography fontWeight={600} typo="caption_overline">
          {!isSubscribed
            ? t(
                discountValue
                  ? "Subscribe and save up to {{value}} on this meal"
                  : "Subscribe and save up on your next meal",
                {
                  value: <Price value={discountValue.toString()} currencyFormat={currencyFormat} />
                }
              )
            : t("Pay with qlub to apply the discount")}
        </Typography>
      </div>
    </div>
  );
};

export default Wallet;
