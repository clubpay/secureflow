import { lazy } from "react";
import { useAuthStore } from "@/store/auth";
import { IGenericOptions, LazyComponentInventory } from "@/types";
import { ILoyaltyProgram, InternalProgramType } from "@/types/entities/program";

export enum WalletType {
  Teaser = "teaser",
  Detailed = "detailed"
}

export interface IProps extends IGenericOptions, React.HTMLAttributes<HTMLDivElement> {
  type?: WalletType;
  program: ILoyaltyProgram;
  billAmount?: number;
  loading?: boolean;
}

const Inventory: LazyComponentInventory = {
  default: lazy(() => import("./Default")),
  discount: lazy(() => import("./Discount"))
};

const Wallet = ({ ...props }: IProps) => {
  const user = useAuthStore((state) => state.user[props.program.id]);
  if (props.program.internalProgramType === InternalProgramType.IN_NONE) {
    return <></>;
  }
  if (props.program.internalProgramType === InternalProgramType.IN_SUB_DISCOUNT) {
    return <Inventory.discount {...props} />;
  }
  if ((user?.accountBalance.nonMonetary ?? 0) > 0 || (user?.pointsSpent ?? 0) > 0) {
    props.type = WalletType.Detailed;
  }
  return <Inventory.default {...props} />;
};

export default Wallet;
