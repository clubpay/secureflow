import { useCallback, useRef } from "react";
import { default as Price } from "@/components/Common/Price";
import { default as HowItWorks } from "@/components/Wallet/HowItWorks";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useGlobalStore } from "@/store/global";
import { useWalletStore } from "@/store/wallet";
import { IGenericOptions, Locales } from "@/types";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { Skeleton } from "@mui/material";
import { default as styles } from "./default.module.scss";

export const testIds = {
  title: "wallet-title",
  loginPrompt: "wallet-login-prompt",
  redeemedPoints: "wallet-redeemed-points",
  centralPoints: "wallet-central-points",
  detailRowWalletName: "wallet-detail-row-wallet-name",
  expiringPoints: "wallet-expiring-points"
};

export enum WalletType {
  Teaser = "teaser",
  Detailed = "detailed"
}

export interface IProps extends IGenericOptions, React.HTMLAttributes<HTMLDivElement> {
  type: WalletType;
  program: ILoyaltyProgram<IQlubConfig>;
  billAmount?: number;
  loading?: boolean;
}

const Wallet = ({ type, currencyFormat, program, billAmount, loading, ...props }: IProps) => {
  const detailHeaderRef = useRef<HTMLDivElement>(null);
  const walletInfoRef = useRef<HTMLDivElement>(null);

  const { locale } = useGlobalStore();

  const openFunctionSheet = useWalletStore((state) => state.openFunctionSheet);

  const user = useAuthStore((state) => state.user[program.id]);

  const earnablePoints = billAmount ? billAmount * program?.config?.earnPointConversionRate : 0;

  const expiringPoints =
    program?.config?.showExpiryNotificationOnLanding && user?.expiringPoints ? user.expiringPoints : 0;

  const centralPoints = (type === WalletType.Teaser ? earnablePoints : user?.accountBalance.nonMonetary ?? 0)?.toFixed(
    2
  );

  const isContentOverflowing = useCallback(() => {
    if (detailHeaderRef.current && walletInfoRef.current) {
      return walletInfoRef.current.offsetWidth + 106 > detailHeaderRef.current.offsetWidth;
    }
    return true;
  }, [detailHeaderRef, walletInfoRef]);

  return (
    <>
      <div className={styles.root} {...props}>
        <div ref={detailHeaderRef} className={styles["detail-header"]}>
          <div>
            <div>
              {type === WalletType.Teaser ? (
                <span ref={walletInfoRef} className={styles.program} data-testid={testIds.title}>
                  {program.config.readableDisplayName} <span>{t("wallet")}</span>
                </span>
              ) : (
                <span
                  ref={walletInfoRef}
                  className={styles.program}
                  style={{ fontWeight: 400 }}
                  data-testid={testIds.title}
                >
                  {t("Wallet balance")}
                </span>
              )}
              <HowItWorks onClick={openFunctionSheet} calculateOverflow={isContentOverflowing} />
            </div>
            {loading ? (
              <Skeleton width={120} height={35} />
            ) : (
              <span data-testid={testIds.centralPoints} className={styles.earnPoints}>
                {type === WalletType.Teaser && earnablePoints === 0 ? (
                  t("{{percentage}} cashback from {{program}}", {
                    percentage: `${(
                      (program?.config?.earnPointConversionRate / program?.config?.burnPointConversionRate) *
                      100
                    ).toFixed(0)}%`,
                    program: program.config.readableDisplayName
                  })
                ) : (
                  <>
                    {type === WalletType.Teaser && `${t(locale === Locales.Arabic ? "I get" : "Earn")} `}
                    <Price
                      value={(+(centralPoints ?? 0) / program?.config?.burnPointConversionRate).toString()}
                      currencyFormat={currencyFormat}
                    />
                  </>
                )}
              </span>
            )}
          </div>
        </div>
        {type === WalletType.Teaser && (
          <div className={styles["teaser-row"]}>
            <span>{t("Pay with qlub to earn cash back!")}</span>
          </div>
        )}
        {type === WalletType.Detailed && (
          <div className={styles["detail-row"]}>
            <span>{t("Lifetime savings")}</span>
            <div>
              {user?.pointsSpent ? (
                <span data-testid={testIds.redeemedPoints}>
                  <Price
                    value={(user.pointsSpent! / program?.config?.burnPointConversionRate)?.toString()}
                    currencyFormat={currencyFormat}
                  />
                </span>
              ) : (
                <span data-testid={testIds.redeemedPoints}>--</span>
              )}
              {!expiringPoints && (
                <span className={styles.programName} data-testid={testIds.detailRowWalletName}>
                  {program.config.readableDisplayName} <span>{t("wallet")}</span>
                </span>
              )}
            </div>
          </div>
        )}
        {type === WalletType.Detailed && (expiringPoints ?? 0) > 0 && (
          <div className={styles["expiry-row"]}>
            <span data-testid={testIds.expiringPoints}>
              <Price
                value={((expiringPoints ?? 0) / program?.config?.burnPointConversionRate)?.toString()}
                currencyFormat={currencyFormat}
              />{" "}
              <span>{t("will expire soon")}</span>
            </span>
            <span className={styles.program}>
              {program.config.readableDisplayName} <span>{t("wallet")}</span>
            </span>
          </div>
        )}
      </div>
    </>
  );
};

export default Wallet;
