import { useEffect, useRef, useState } from "react";
import { default as OutlinedButton } from "@/components/Common/Core/OutlinedButton";
import { t } from "@/locales";
import { InfoOutlined } from "@mui/icons-material";

export const testIds = {
  howItWorks: "wallet-how-it-works-action"
};

function HowItWorks({
  onClick,
  calculateOverflow
}: {
  onClick: (arg: boolean) => void;
  calculateOverflow?: () => boolean;
}): JSX.Element {
  const [isOverflowing, setIsOverflowing] = useState(calculateOverflow?.() ?? false);
  const detailHeaderRef = useRef<HTMLDivElement>(null);
  const walletInfoRef = useRef<HTMLDivElement>(null);

  const isContentOverflowing = () => {
    if (calculateOverflow) setIsOverflowing(calculateOverflow());
  };

  useEffect(() => {
    if (!calculateOverflow) return;
    window.addEventListener("resize", isContentOverflowing);

    return () => {
      window.removeEventListener("resize", isContentOverflowing);
    };
  }, [detailHeaderRef, walletInfoRef, isContentOverflowing]);

  useEffect(() => {
    isContentOverflowing();
  }, []);

  return (
    <div>
      <OutlinedButton
        data-testid={testIds.howItWorks}
        style={{
          marginTop: 0,
          ...(isOverflowing ? { padding: "4px", borderRadius: "1rem", borderColor: "transparent" } : {})
        }}
        arrow={false}
        onClick={() => onClick(true)}
      >
        {isOverflowing ? <InfoOutlined fontSize="small" /> : t("How It Works")}
      </OutlinedButton>
    </div>
  );
}

export default HowItWorks;
