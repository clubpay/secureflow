import { default as useLocale } from "@/hooks/locale";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { default as defaultStyles } from "./prompt.module.scss";

export interface IProps extends React.HTMLAttributes<HTMLElement> {
  locale?: string;
  serviceID: string;
  logoUrl?: string;
}

const EarnPrompt: React.FC<IProps> = ({ serviceID, logoUrl, ...props }: IProps) => {
  const user = useAuthStore((state) => state.user[serviceID]);
  const mobileNumber = useAuthStore((state) => state.mobileNumber[serviceID]);
  const isMobileNumberValid = useAuthStore((state) => state.isMobileNumberValid[serviceID]);

  useLocale(props.locale);

  if (!user?.phoneNumber && !isMobileNumberValid) {
    return null;
  }

  return (
    <div className={defaultStyles.base}>
      <span>
        {t("You will earn points on the mobile number ending in {{last4Digits}}", {
          last4Digits: (user?.phoneNumber ?? mobileNumber)?.slice(-4)
        })}
      </span>
      {logoUrl && <img src={logoUrl} alt="logo" />}
    </div>
  );
};

export default EarnPrompt;
