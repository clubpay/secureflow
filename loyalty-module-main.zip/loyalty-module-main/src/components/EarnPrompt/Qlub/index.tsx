import { t } from "@/locales";
import { IGenericOptions } from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";
import { getCashbackValue } from "@/utils";
import { Price, Trivia } from "@qlub-dev/qlub-kit";
import styles from "./prompt.module.scss";

interface IProps extends Pick<IGenericOptions, "currencyFormat"> {
  program: ILoyaltyProgram;
  billAmount?: number;
  billCommission?: number;
  onLogin: () => void;
}

function EarnPrompt({ program, billAmount = 0, billCommission = 0, onLogin, currencyFormat }: IProps) {
  return (
    <Trivia
      disableIcon
      message={
        <span className={styles.messageContainer}>
          {" "}
          <button type="button" onClick={onLogin} className={styles.loginButton}>
            {t("Login")}
          </button>{" "}
          {billAmount ? (
            <span>
              {t("to Earn {{discountAmount}} on this bill.", {
                discountAmount: (
                  <span className={styles.message}>
                    <Price
                      value={getCashbackValue(
                        billAmount,
                        billCommission,
                        program.config.earnPointConversionRate,
                        program.config.burnPointConversionRate,
                        currencyFormat
                      )}
                      currencyFormat={currencyFormat}
                    />
                  </span>
                )
              })}
            </span>
          ) : (
            <span>
              {t("to get {{cashbackPercentage}} cashback from {{program}}.", {
                cashbackPercentage: (
                  <span className={styles.message}>{`${(
                    ((program.config.earnPointConversionRate ?? 0) / (program.config.burnPointConversionRate ?? 1)) *
                    100
                  ).toFixed(0)}%`}</span>
                ),
                program: program.config.readableDisplayName
              })}
            </span>
          )}
        </span>
      }
      triviaOverrides={{
        borderRadius: "16px",
        width: "100%",
        maxWidth: "530px",
        backgroundColor: "#7D00D414",
        marginTop: "-16px"
      }}
    />
  );
}

export default EarnPrompt;
