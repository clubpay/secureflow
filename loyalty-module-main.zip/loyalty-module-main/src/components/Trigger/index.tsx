import { Suspense, useMemo } from "react";
import { defaults } from "@/constants";
import { ITriggerOptions, TriggerType } from "@/types";
import { default as OfferTrigger } from "./Offers";
import { default as RedemptionTrigger } from "./Redemption";

const Trigger: React.FC<ITriggerOptions> = ({ type = TriggerType.Redemption, ...props }) => {
  const TriggerComponent = useMemo(() => {
    if (type === TriggerType.Offer) return OfferTrigger;
    return RedemptionTrigger;
  }, [type]);

  return (
    <Suspense fallback={null}>
      <TriggerComponent
        {...(props as any)}
        data-testid={`${type}-trigger`}
        currencyFormat={{
          ...props.currencyFormat,
          cs: props.currencyFormat?.cs ?? defaults.currency.symbol,
          currencyFormat: props.currencyFormat?.currencyPrecision ?? defaults.currency.precision
        }}
        country={props.country ?? defaults.country}
      />
    </Suspense>
  );
};

export default Trigger;
