import { forwardRef } from "react";
import { default as classNames } from "classnames";
import { t } from "@/locales";
import { ILoyaltyProgram, IRotanaConfig } from "@/types/entities/program";
import { default as Loading } from "@qlub-dev/qlub-kit/dist/components/Loading";
import { default as defaultStyles } from "./rotana.module.scss";

interface Props extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  program?: ILoyaltyProgram<IRotanaConfig>;
  loading?: boolean;
}

const TriggerRotana = forwardRef<HTMLButtonElement, Props>(
  ({ className = "", program, loading, disabled, ...props }, ref) => {
    if (loading) className += ` ${defaultStyles.loading}`;
    return (
      <button ref={ref} {...props} disabled={disabled} className={classNames(defaultStyles.base, className)}>
        <span style={{ fontWeight: 500 }}>{t("Redeem points")}</span>
        {program?.config.logo && <img src={program.config.logo} alt="logo" />}
        {loading && (
          <div className={defaultStyles.loader}>
            <Loading color="contained" />
          </div>
        )}
      </button>
    );
  }
);

export default TriggerRotana;
