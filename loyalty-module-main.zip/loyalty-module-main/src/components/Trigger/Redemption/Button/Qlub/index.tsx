import { forwardRef } from "react";
import { default as classNames } from "classnames";
import { default as CannotRedeem } from "@/components/Common/CannotRedeem";
import { useRedemptionCalculations } from "@/hooks";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { IRedemptionOptions } from "@/types";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { getCashbackValue } from "@/utils";
import { Price } from "@qlub-dev/qlub-kit";
import { default as Loading } from "@qlub-dev/qlub-kit/dist/components/Loading";
import defaultStyles from "./qlub.module.scss";

interface Props extends IRedemptionOptions, React.ButtonHTMLAttributes<HTMLButtonElement> {
  program: ILoyaltyProgram<IQlubConfig>;
  loading?: boolean;
}

const TriggerQlub = forwardRef<HTMLButtonElement, Props>(({ className = "", program, loading, ...props }, ref) => {
  const { min, max, lowBalance, cannotRedeem, cannotRedeemErrorMessage } = useRedemptionCalculations({
    program,
    bill: props.bill,
    currencyFormat: props.currencyFormat,
    config: props.config
  });
  const user = useAuthStore((state) => state.user[program.id]);
  const text = (() => {
    if (program?.config?.isBurnEnabled && user?.accountBalance?.nonMonetary && user.accountBalance.nonMonetary >= min) {
      return t("Redeem up to {{value}}", {
        value: (
          <Price
            sx={{
              "display": "inline-flex",
              "alignItems": "baseline",
              "gap": "2px",
              "fontSize": "inherit",
              "&>span": { fontSize: "inherit" }
            }}
            value={(max / (program.config.burnPointConversionRate ?? 1))?.toString()}
            currencyFormat={props.currencyFormat}
          />
        )
      });
    }
    if (program?.config?.isBurnEnabled && user?.isAuthorized && lowBalance) {
      return t("Redeem points");
    }
    if (program?.config?.isEarnEnabled && user?.accountBalance.nonMonetary === 0) {
      return t("Earn {{value}}", {
        value: (
          <Price
            sx={{
              "display": "inline-flex",
              "alignItems": "baseline",
              "gap": "2px",
              "fontSize": "inherit",
              "&>span": { fontSize: "inherit" }
            }}
            value={getCashbackValue(
              props.bill?.amount,
              props?.bill?.commission,
              program.config.earnPointConversionRate,
              program.config.burnPointConversionRate,
              props.currencyFormat
            )}
            currencyFormat={props.currencyFormat}
          />
        )
      });
    }
    return t("Redeem & Earn Points");
  })();
  const disabled = user?.isAuthorized && (lowBalance || cannotRedeem);
  if (loading) className += ` ${defaultStyles.loading}`;
  return (
    <>
      <button
        ref={ref}
        {...props}
        className={classNames(defaultStyles.base, disabled && defaultStyles.disabled, className)}
        disabled={disabled}
      >
        <span style={{ fontWeight: 500 }}>{text}</span>
        {program.config.logo && <img src={program.config.logo} alt="logo" />}
        {loading && (
          <div className={defaultStyles.loader}>
            <Loading color="contained" />
          </div>
        )}
      </button>
      {disabled && <CannotRedeem message={cannotRedeemErrorMessage} />}
    </>
  );
});

export default TriggerQlub;
