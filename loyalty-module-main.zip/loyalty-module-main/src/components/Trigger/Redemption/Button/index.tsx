import { lazy, useRef } from "react";
import { useVisibility } from "@/hooks";
import { IRedemptionOptions, LazyComponentInventory, LoyaltyService } from "@/types";

const Inventory: LazyComponentInventory = {
  default: lazy(() => import("./Common")),
  [LoyaltyService.Rotana]: lazy(() => import("./Rotana")),
  [LoyaltyService.Qlub]: lazy(() => import("./Qlub"))
};

interface TriggerProps extends IRedemptionOptions, React.HTMLAttributes<HTMLButtonElement> {
  loading?: boolean;
  disabled?: boolean;
}

const Trigger: React.FC<TriggerProps> = (props) => {
  const ref = useRef<HTMLButtonElement>(null);

  useVisibility(ref, () => {
    props.config?.events?.onRedemptionTriggerVisible?.();
  });

  if (!props.program) return null;

  const Component: React.FC<any> = Inventory[props.program.type!] || Inventory.default;

  return <Component ref={ref} {...props} program={props.program} />;
};

export default Trigger;
