import { forwardRef } from "react";
import { default as classNames } from "classnames";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { ILoyaltyProgram } from "@/types/entities/program";
import Loading from "@qlub-dev/qlub-kit/dist/components/Loading";
import defaultStyles from "./common.module.scss";

interface Props extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  program: ILoyaltyProgram;
  loading?: boolean;
}

const TriggerCommon = forwardRef<HTMLButtonElement, Props>(({ className = "", program, loading, ...props }, ref) => {
  const user = useAuthStore((state) => state.user[program.id]);
  const mobileNumber = useAuthStore((state) => state.mobileNumber[program.id]);
  const isMobileNumberValid = useAuthStore((state) => state.isMobileNumberValid[program.id]);
  if (loading) className += ` ${defaultStyles.loading}`;
  return (
    <button
      ref={ref}
      {...props}
      className={classNames(defaultStyles.base, className, !user?.isAuthorized && "small-text")}
    >
      <div>
        {user?.isAuthorized || (mobileNumber && isMobileNumberValid) ? (
          <span style={{ fontWeight: 500 }}>
            {t(program.config.isDiscountEnabled ? "Apply gifts & Redeem points" : "Redeem your points")}
          </span>
        ) : (
          <>
            <span>
              {t("Login to {{loyaltyProgram}}", {
                loyaltyProgram: program.config.readableDisplayName
              })}
            </span>
            <span className={classNames(!user?.isAuthorized && "small-text")}>
              {program.config.isDiscountEnabled
                ? t("Apply deals, gifts and redeem points")
                : t("Earn and redeem {{loyaltyProgram}} points", {
                    loyaltyProgram: program.config.readableDisplayName
                  })}
            </span>
          </>
        )}
      </div>
      {program.config.logo && <img src={program.config.logo} alt="logo" />}
      {loading && (
        <div className={defaultStyles.loader}>
          <Loading color="contained" />
        </div>
      )}
    </button>
  );
});

export default TriggerCommon;
