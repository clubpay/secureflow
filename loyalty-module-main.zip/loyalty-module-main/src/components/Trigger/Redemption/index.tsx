import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { IRedemptionOptions } from "@/types";
import { default as Driver } from "./Driver";

const RedemptionTrigger: React.FC<IRedemptionOptions> = (props) => {
  const user = useAuthStore((state) => state.user[props.program.id]);
  return (
    <>
      <Driver
        {...props}
        bill={{
          amount: props.bill?.amount ?? 0,
          commission: props.bill?.commission ?? 0,
          share: props.bill?.share ?? 0,
          shareCommission: props.bill?.shareCommission ?? 0,
          tax: props.bill?.tax ?? 0,
          remaining: props.bill?.remaining,
          payments: {
            regular: props.bill?.payments?.regular ?? 0,
            loyalty: props.bill?.payments?.loyalty ?? 0
          },
          hasDiscounts: props.bill?.hasDiscounts ?? false,
          hasLoyaltyDiscounts: props.bill?.hasLoyaltyDiscounts ?? false
        }}
        config={{
          ...props.config,
          conversionRate: user?.conversionRate ?? 1,
          redemption: {
            ...props.config?.redemption,
            pointIdentifier: props.config?.redemption?.pointIdentifier ?? t("loyalty")
          }
        }}
      />
    </>
  );
};

export default RedemptionTrigger;
