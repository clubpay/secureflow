import { useState } from "react";
import { default as CannotRedeem } from "@/components/Common/CannotRedeem";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useCheckoutStore } from "@/store/checkout";
import { useGlobalStore } from "@/store/global";
import { useOfferStore } from "@/store/offer";
import { IRedemptionOptions } from "@/types";
import { Box } from "@mui/material";
import { default as Divider } from "@qlub-dev/qlub-kit/dist/components/Divider";
import { CheckoutSheet } from "../../../Redemption";
import { default as TriggerButton } from "../Button";

const Driver: React.FC<IRedemptionOptions> = (props) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  const user = useAuthStore((state) => state.user[props.program.id]);

  const openLoginSheet = useAuthStore((state) => state.openLoginSheet);

  const openCheckoutSheet = useCheckoutStore((state) => state.openSheet);

  const openOfferSelectorSheet = useOfferStore((state) => state.openSelectorSheet);

  const setSelectedProgram = useGlobalStore((state) => state.setSelectedProgram);

  const onTriggerClick = async () => {
    setSelectedProgram(props.program);
    setLoading(true);
    await props.config.events?.onTriggerClick?.();
    const next = () => {
      if (props.program.config.displayOfferSelectorSheet && props.program.config.isDiscountEnabled) {
        openOfferSelectorSheet(props.program.id, true);
      } else {
        openCheckoutSheet(props.program.id, true);
      }
    };
    if (!user?.isAuthorized) {
      if (props.program.config.automatedLogin) {
        if (props.config.events?.onLogin) {
          props.config.events
            ?.onLogin({ phoneNumber: user?.phoneNumber })
            ?.then(() => {
              setLoading(false);
              next();
            })
            .catch(() => {
              setLoading(false);
              setError(true);
            });
        } else {
          setLoading(false);
          next();
        }
      } else {
        setLoading(false);
        openLoginSheet(props.program.id, true);
      }
    } else {
      setLoading(false);
      next();
    }
  };

  const disableRedemption = props.bill?.hasDiscounts && props.program.config.disableRedemptionIfDiscountAvailable;

  return (
    <>
      {!props.config.redemption?.completed && (
        <>
          {props.config.ui?.enableTriggerTopDivider && (
            <Box position="relative" sx={{ pb: 2 }}>
              <Divider sx={{ width: "calc(100% + 3rem)", marginLeft: "-1.5rem" }} type="fullWidth" />
            </Box>
          )}
          {disableRedemption ? (
            <CannotRedeem message={t("Cashback is not available as there is a discount on the bill")} />
          ) : (
            <TriggerButton {...props} onClick={onTriggerClick} loading={loading} disabled={error} />
          )}
        </>
      )}
      {!disableRedemption && <CheckoutSheet {...props} />}
    </>
  );
};

export default Driver;
