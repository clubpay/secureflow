import { IOfferOptions } from "@/types";
import { default as Driver } from "./Driver";

interface IOfferDriverProps extends IOfferOptions {
  render?: boolean;
}

const OfferTrigger: React.FC<IOfferDriverProps> = ({ render = true, ...props }) => {
  return (
    <>
      <Driver {...props} render={render} />
    </>
  );
};

export default OfferTrigger;
