import { useState } from "react";
import { default as OfferDetails } from "@/components/Offers/Details";
import { default as OfferInventory } from "@/components/Offers/Inventory";
import { default as OfferSelector } from "@/components/Offers/Selector";
import useOffers from "@/hooks/offers";
import { useAuthStore } from "@/store/auth";
import { useGlobalStore } from "@/store/global";
import { useOfferStore } from "@/store/offer";
import { IOfferOptions } from "@/types";
import { default as TriggerButton } from "../Button";
import { useProfile } from "@/hooks/api";

interface IOfferDriverProps extends IOfferOptions {
  render?: boolean;
}

const Driver: React.FC<IOfferDriverProps> = ({ render, ...props }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  const setSelectedProgram = useGlobalStore((state) => state.setSelectedProgram);

  const user = useAuthStore((state) => state.user[props.program.id]);

  const openLoginSheet = useAuthStore((state) => state.openLoginSheet);

  const congratulated = useOfferStore((state) => state.congratulated[props.program.id]);

  const {
    data: offers,
    isLoading: isFetchingOffers,
    refetch: fetchOffers
  } = useOffers({ program: props.program, onRefresh: props.config?.events?.onRefresh });

  const { isLoading: isProfileLoading } = useProfile(props.program);

  const alertedNoOffers = useOfferStore((state) => state.alertedNoOffers[props.program.id]);

  const automatedLoginInProgress = useAuthStore((state) => state.automatedLoginInProgress[props.program.id]);

  const paymentDetails = useGlobalStore((state) => state.paymentDetails);

  if (!render || (congratulated && offers?.every((o) => o.applied && o.autoApplicable))) return null;

  const onTriggerClick = async () => {
    setLoading(true);
    await props.config.events?.onTriggerClick?.();
    if (!user) {
      if (props.program.config.automatedLogin) {
        const next = () => setLoading(false);
        if (props.config.events?.onLogin) {
          await props.config.events
            ?.onLogin({ phoneNumber: "" })
            .then(next)
            .catch(() => {
              setLoading(false);
              setError(true);
            });
        } else {
          next();
        }
      } else {
        setLoading(false);
        setSelectedProgram(props.program);
        openLoginSheet(props.program.id, true);
      }
    } else {
      await fetchOffers({ manual: true });
      setLoading(false);
    }
  };

  return (
    <>
      {!props.program.config.hideOfferTrigger && (
        <TriggerButton
          {...props}
          onClick={onTriggerClick}
          loading={loading || isProfileLoading || automatedLoginInProgress || isFetchingOffers || !paymentDetails?.diningSessionID}
          displayNoOfferWarning={alertedNoOffers}
          disabled={error}
        />
      )}
      <OfferInventory {...props} />
      <OfferDetails {...props} />
      <OfferSelector {...props} />
    </>
  );
};

export default Driver;
