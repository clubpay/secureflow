import classNames from "classnames";
import { Warning } from "@/icons";
import { t } from "@/locales";
import { ILoyaltyProgram, IRotanaConfig } from "@/types/entities/program";
import Loading from "@qlub-dev/qlub-kit/dist/components/Loading";
import defaultStyles from "./rotana.module.scss";

interface Props extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  program: ILoyaltyProgram<IRotanaConfig>;
  loading?: boolean;
  displayNoOfferWarning?: boolean;
  disabled?: boolean;
}

const TriggerRotana: React.FC<Props> = ({
  className = "",
  program,
  loading,
  displayNoOfferWarning,
  disabled,
  ...props
}) => {
  if (loading) className += ` ${defaultStyles.loading}`;
  return (
    <div style={{ width: "100%" }}>
      <button {...props} disabled={disabled} className={`${defaultStyles.base} ${className}`}>
        <span>{t("Apply Discount")}</span>
        {program.config.logo && <img src={program.config.logo} alt="logo" />}
        {loading && (
          <div className={defaultStyles.loader}>
            <Loading color="contained" />
          </div>
        )}
      </button>
      <div className={classNames(defaultStyles.error, !displayNoOfferWarning && "hidden")}>
        <Warning height={16} width={16} />
        <span>{t("Discount not available")}</span>
      </div>
    </div>
  );
};

export default TriggerRotana;
