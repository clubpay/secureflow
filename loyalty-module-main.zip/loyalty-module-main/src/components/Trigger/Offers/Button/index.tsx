import { lazy } from "react";
import { IOfferOptions, LazyComponentInventory, LoyaltyService } from "@/types";

const Inventory: LazyComponentInventory = {
  default: lazy(() => import("./Common")),
  [LoyaltyService.Rotana]: lazy(() => import("./Rotana"))
};

interface TriggerProps extends IOfferOptions, React.HTMLAttributes<HTMLButtonElement> {
  loading?: boolean;
  displayNoOfferWarning?: boolean;
  disabled?: boolean;
}

const Trigger: React.FC<TriggerProps> = (props) => {
  const Component: React.FC<any> = Inventory[props.program.type!] || Inventory.default;
  switch (props.program.type) {
    default:
      return <Component {...props} program={props.program} />;
  }
};

export default Trigger;
