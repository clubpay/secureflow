import { t } from "@/locales";
import { ILoyaltyProgram } from "@/types/entities/program";
import Loading from "@qlub-dev/qlub-kit/dist/components/Loading";
import defaultStyles from "./common.module.scss";

interface Props extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  program: ILoyaltyProgram;
  loading?: boolean;
}

const TriggerCommon: React.FC<Props> = ({ className = "", program, loading, ...props }) => {
  if (loading) className += ` ${defaultStyles.loading}`;
  return (
    <button {...props} className={`${defaultStyles.base} ${className}`}>
      <span>{t("Apply Deals & Gifts")}</span>
      {program.config.logo && <img src={program.config.logo} alt="logo" />}
      {loading && (
        <div className={defaultStyles.loader}>
          <Loading color="contained" />
        </div>
      )}
    </button>
  );
};

export default TriggerCommon;
