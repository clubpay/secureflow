import { default as BottomSheet } from "@/components/Common/Core/BottomSheet";
import Button from "@/components/Common/Core/Button";
import useOffers from "@/hooks/offers";
import { t } from "@/locales";
import { useCheckoutStore } from "@/store/checkout";
import { useOfferStore } from "@/store/offer";
import { IOfferOptions } from "@/types";
import { default as defaultStyles } from "./selector.common.module.scss";

export const testIds = {
  sheet: "offer-selector-sheet"
};

const OfferSelector: React.FC<IOfferOptions> = ({ program, ...props }: IOfferOptions) => {
  const { openSheet: openCheckoutSheet } = useCheckoutStore();

  const openOfferSheet = useOfferStore((state) => state.openSheet);

  const openSelectorSheet = useOfferStore((state) => state.openSelectorSheet);

  const sheetOpen = useOfferStore((state) => state.selectorSheetOpen[program.id]);

  const {
    isLoading,
    isFetching,
    refetch: fetchOffers
  } = useOffers({
    program: program,
    onRefresh: props.config?.events?.onRefresh
  });

  const onApply = async () => {
    await fetchOffers().then(() => {
      openSelectorSheet(program.id, false);
      openOfferSheet(program.id, true);
    });
  };

  const onRedeem = () => {
    openSelectorSheet(program.id, false);
    openCheckoutSheet(program.id, true);
  };

  return (
    <BottomSheet
      open={sheetOpen}
      headerImgUrl={props.meta?.restaurantLogoUrl}
      className={defaultStyles.content}
      headerClassName={defaultStyles.bottomSheetHeader}
      baseClasses={{ paper: defaultStyles.paper, root: defaultStyles.root }}
      onCloseHandler={() => {
        openSelectorSheet(program.id, false);
      }}
      data-testid={testIds.sheet}
    >
      <Button className={defaultStyles.btn} onClick={onApply} loading={isLoading || isFetching}>
        {t("Apply gifts")}
      </Button>
      <Button className={defaultStyles.btn} onClick={onRedeem}>
        {t("Redeem points")}
      </Button>
    </BottomSheet>
  );
};

export default OfferSelector;
