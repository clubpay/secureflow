import { useEffect, useState } from "react";
import { default as BottomSheet } from "@/components/Common/Core/BottomSheet";
import { default as Button } from "@/components/Common/Core/Button";
import useOffers from "@/hooks/offers";
import { Offer } from "@/icons";
import { t } from "@/locales";
import { useGlobalStore } from "@/store/global";
import { useOfferStore } from "@/store/offer";
import { IOfferOptions } from "@/types";
import { constructAppliedOfferPopupArgs } from "@/utils";
import { default as defaultStyles } from "./offer.details.common.module.scss";

export const testIds = {
  applyBtn: "offer-detail-apply-btn",
  back: "offer-detail-back",
  sheet: "offer-detail-sheet",
  offerName: "offer-detail-name",
  offerDescription: "offer-detail-description"
};

const OfferDetails: React.FC<IOfferOptions> = ({ config, program, ...props }: IOfferOptions) => {
  const [loading, setLoading] = useState(false);

  const openCongratulationPopup = useGlobalStore().popup.openPopup;

  const { openDetailSheet, openSheet } = useOfferStore();

  const { refetch: refetchOffers, applyOffer } = useOffers({ program, onRefresh: config?.events?.onRefresh });

  const detailSheetOpen = useOfferStore((state) => state.detailSheetOpen[program.id]);

  const selectedOffer = useOfferStore((state) => state.selectedOffer?.[program.id]);

  useEffect(() => {
    return () => openSheet(program.id, false);
  }, []);

  const onApply = async () => {
    if (selectedOffer) {
      const next = async () => {
        openDetailSheet(program.id, false);
        openCongratulationPopup(constructAppliedOfferPopupArgs(selectedOffer));
        await refetchOffers();
      };
      setLoading(true);
      await applyOffer(selectedOffer)
        .then(next)
        .catch(() => {});
      setLoading(false);
    }
  };

  return (
    <BottomSheet
      open={detailSheetOpen}
      headerImgUrl={props.meta?.restaurantLogoUrl}
      className={defaultStyles.content}
      onBackHandler={() => {
        openDetailSheet(program.id, false);
        openSheet(program.id, true);
      }}
      backButtonProps={{ "data-testid": testIds.back }}
      data-testid={testIds.sheet}
    >
      <div className={defaultStyles.content}>
        <div className={defaultStyles["offer-img"]}>
          <Offer />
        </div>
        <div className={defaultStyles["offer-details"]}>
          <span className={defaultStyles["offer-name"]} data-testid={testIds.offerName}>
            {selectedOffer?.name}
          </span>
          {selectedOffer?.description && (
            <span className={defaultStyles["offer-description"]} data-testid={testIds.offerDescription}>
              {selectedOffer.description}
            </span>
          )}
        </div>
      </div>
      <div className={defaultStyles.footer}>
        <Button
          disabled={
            selectedOffer?.applied || loading || (props.bill?.remaining ?? 0) <= 0 || (props.bill?.share ?? 0) <= 0
          }
          loading={loading}
          onClick={onApply}
          data-testid={testIds.applyBtn}
        >
          {t("Apply")}
        </Button>
      </div>
    </BottomSheet>
  );
};

export default OfferDetails;
