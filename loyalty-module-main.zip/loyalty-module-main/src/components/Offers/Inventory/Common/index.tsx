import { Fragment, useCallback, useEffect, useMemo, useState } from "react";
import { default as BottomSheet } from "@/components/Common/Core/BottomSheet";
import { default as Button } from "@/components/Common/Core/Button";
import { useOffers } from "@/hooks/offers";
import { Offer } from "@/icons";
import { t } from "@/locales";
import { useGlobalStore } from "@/store/global";
import { useOfferStore } from "@/store/offer";
import { IOffer, IOfferOptions } from "@/types";
import { constructAppliedOfferPopupArgs, getManualApplicableOfferKey } from "@/utils";
import { Divider } from "@mui/material";
import { default as defaultStyles } from "./inventory.common.module.scss";

export const testIds = {
  applyBtn: "offer-inventory-item-apply-btn",
  detailBtn: "offer-inventory-item-details-btn",
  back: "offer-inventory-back",
  list: "offer-inventory-list",
  item: "offer-inventory-item",
  empty: "offer-inventory-empty",
  sheet: "offer-inventory-sheet"
};

interface IOfferInventoryItemProps {
  offer: IOffer;
  disabled: boolean;
  onViewDetails: (offer: IOffer) => void;
  onApply: (offer: IOffer) => Promise<any>;
}

const OfferInventoryItem = ({ offer, disabled, onViewDetails, onApply }: IOfferInventoryItemProps) => {
  const [loading, setLoading] = useState(false);

  const onLocalApply = useCallback(async () => {
    setLoading(true);
    await onApply?.(offer).catch(() => {});
    setLoading(false);
  }, []);

  return (
    <div className={defaultStyles["inventory-item"]} data-testid={testIds.item}>
      <div className={defaultStyles["offer-img"]}>
        <Offer />
      </div>
      <div className={defaultStyles["offer-details"]}>
        <div>
          <span className={defaultStyles["offer-name"]}>{offer.name}</span>
          {offer.description && <span className={defaultStyles["offer-description"]}>{offer.description}</span>}
        </div>
        <div className={defaultStyles["offer-actions"]}>
          <Button
            disabled={offer.applied || disabled}
            loading={loading}
            onClick={onLocalApply}
            data-testid={testIds.applyBtn}
          >
            {t("Apply")}
          </Button>
          <Button variant="containedLight" onClick={() => onViewDetails(offer)} data-testid={testIds.detailBtn}>
            {t("View Details")}
          </Button>
        </div>
      </div>
    </div>
  );
};

const OfferInventory: React.FC<IOfferOptions> = ({ config, program, ...props }: IOfferOptions) => {
  const [loading, setLoading] = useState(false);

  const openCongratulationPopup = useGlobalStore().popup.openPopup;

  const { openSheet, openDetailSheet, setSelectedOffer } = useOfferStore();

  const {
    data: offers,
    refetch: refetchOffers,
    applyOffer
  } = useOffers({ program: program, onRefresh: config?.events?.onRefresh });

  const nonAutoApplicableOffers = useMemo(() => offers?.filter((offer) => !offer.autoApplicable), [offers]);

  const sheetOpen = useOfferStore((state) => state.sheetOpen[program.id]);

  useEffect(() => {
    return () => openSheet(program.id, false);
  }, []);

  const onViewDetails = useCallback((offer: IOffer) => {
    openSheet(program.id, false);
    openDetailSheet(program.id, true);
    setSelectedOffer(program.id, offer);
  }, []);

  const onApply = async (offer: IOffer) => {
    const next = async () => {
      openSheet(program.id, false);
      openCongratulationPopup(constructAppliedOfferPopupArgs(offer));
      await refetchOffers();
    };
    setLoading(true);
    await applyOffer(offer)
      .then(next)
      .catch(() => {});
    setLoading(false);
  };

  return (
    <BottomSheet
      open={sheetOpen}
      headerImgUrl={props.meta?.restaurantLogoUrl}
      className={defaultStyles.content}
      onBackHandler={() => {
        openSheet(program.id, false);
        config.events?.onSheetClose?.();
      }}
      backButtonProps={{ "data-testid": testIds.back }}
      data-testid={testIds.sheet}
    >
      <div data-testid={testIds.list} className={defaultStyles.content}>
        {nonAutoApplicableOffers?.map((offer) => (
          <Fragment key={offer.id}>
            <OfferInventoryItem
              offer={offer}
              disabled={loading || (props.bill?.remaining ?? 0) <= 0 || (props.bill?.share ?? 0) <= 0}
              onViewDetails={onViewDetails}
              onApply={onApply}
            />
            <Divider className={defaultStyles.divider} />
          </Fragment>
        ))}
        {!nonAutoApplicableOffers?.length && (
          <div className={defaultStyles.empty} data-testid={testIds.empty}>
            <div className={defaultStyles["offer-empty-img"]}>
              <Offer />
            </div>
            <span>{t(`No ${getManualApplicableOfferKey(program)}s available`)}</span>
          </div>
        )}
      </div>
    </BottomSheet>
  );
};

export default OfferInventory;
