import { lazy } from "react";
import { IOfferOptions, LazyComponentInventory } from "@/types";

export { testIds } from "./Common";

const Inventory: LazyComponentInventory = {
  default: lazy(() => import("./Common"))
};

const OfferInventory: React.FC<IOfferOptions> = (props) => {
  const Component: React.FC<any> = Inventory[props!.program.type!] || Inventory.default;
  switch (props?.program.type) {
    default:
      return <Component {...props} />;
  }
};

export default OfferInventory;
