import { default as WalletBalanceUI } from "@/components/WalletBalance";
import { useEnabledLoyaltyProgram, useProfile } from "@/hooks/api";
import { useGlobalStore } from "@/store/global";
import { InternalProgramType } from "@/types/entities/program";
import { getLocaleText } from "@clubpay/customer-common-module/src/component/MultiLocale";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";

const WalletBalance = () => {
  const { currencyFormat } = useVendor();

  const { locale } = useGlobalStore();

  const { program } = useEnabledLoyaltyProgram();

  const { profile } = useProfile(program);

  if (
    !profile ||
    !profile.isAuthorized ||
    !program ||
    program.internalProgramType === InternalProgramType.IN_SUB_DISCOUNT
  )
    return <></>;

  return (
    <WalletBalanceUI
      name={getLocaleText(program.config.displayName ?? "", locale, "en") || program.name}
      program={program}
      balance={profile.accountBalance.nonMonetary}
      currencyFormat={currencyFormat}
    />
  );
};

export default WalletBalance;
