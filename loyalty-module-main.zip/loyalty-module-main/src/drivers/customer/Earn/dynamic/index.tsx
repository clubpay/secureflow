import { IDriverProps } from "@/types/drivers";
import { default as EarnCentral } from "./central";
import { IUseProgramsProps, default as usePrograms } from "./programs";

export interface IProps extends IUseProgramsProps, IDriverProps, React.HTMLAttributes<HTMLElement> {}

export const Earn = ({ gatewayVendor, gatewayPaymentMethod, earnings, redemptions, ...props }: IProps) => {
  const programs = usePrograms({ gatewayVendor, gatewayPaymentMethod, earnings, redemptions });
  return (
    <>
      {programs.map((program) => (
        <EarnCentral key={program.id} program={program} {...props} />
      ))}
    </>
  );
};

export default Earn;
