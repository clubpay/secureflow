import { useEffect } from "react";
import { default as Earn } from "@/components/Earn";
import { default as useAnalytics } from "@/hooks/analytics";
import { default as useAPI, useProfile } from "@/hooks/api";
import { t } from "@/locales";
import { Locales } from "@/types";
import { IDriverProps } from "@/types/drivers";
import { ILoyaltyProgram } from "@/types/entities/program";
import { getLocaleText } from "@clubpay/customer-common-module/src/component/MultiLocale";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { useQlubRouter } from "@clubpay/customer-common-module/src/hook/router";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { getError } from "@clubpay/customer-common-module/src/utility/k_error";

export interface IEarnProps extends IDriverProps, React.HTMLAttributes<HTMLElement> {
  program: ILoyaltyProgram;
}

const EarnCentral = ({ program, api, className, style }: IEarnProps) => {
  const { vendor, currencyFormat } = useVendor();

  const { bill, loyalty } = useAPI(api);

  const { data: profile, isLoading: isProfileLoading } = useProfile(program);

  const analytics = useAnalytics();

  const {
    query: { dsi, sid, ref },
    lang = vendor?.config?.defaultLang
  } = useQlubRouter();

  useEffect(() => {
    analytics.earn.rendered(program);
  }, [program.id]);

  if (!vendor) return null;

  const legacySubmitHandler = async (mobile: string) => {
    try {
      const res = await bill?.emailReceiptV2({
        phone: mobile,
        id: getSession(sid),
        diningSessionID: dsi || "",
        lang,
        reference: ref,
        countryCode: vendor?.country.code,
        timezone: vendor?.timezone?.timezone || ""
      });
      let status = "error";
      if (res?.data.status === "success") {
        status = "success";
        if (res?.data.meta?.como === "already_sent") {
          status = "already_sent";
          window.snackbar.enqueue(t("You have already earned points for this transaction"), {
            variant: "warning"
          });
        }
      } else {
        window.snackbar.enqueue(t(`Request is not submitted. ${res?.data.message}`), { variant: "error" });
      }
      analytics.earn.legacy.tapEarnPointsBtn(mobile, status);
    } catch (err) {
      window.snackbar.enqueue(getError(err), { variant: "error" });
      analytics.earn.legacy.tapEarnPointsBtn(mobile, "error");
    }
  };

  const submitHandler = async (mobileNumber: string) => {
    try {
      await loyalty.points.earn(dsi, vendor!, program, mobileNumber);
      analytics.earn.legacy.tapEarnPointsBtn(mobileNumber, "success");
      analytics.earn.submit(program);
    } catch (err: any) {
      let status = "error";
      if (err?.data?.items === "Points already earned") {
        status = "already_sent";
        window.snackbar.enqueue(t("You have already earned points for this transaction"), { variant: "warning" });
      } else if (err?.data?.items?.includes("invalid value for telephone number")) {
        window.snackbar.enqueue(t("Invalid value for telephone number"), { variant: "error" });
      } else {
        window.snackbar.enqueue(t("Failed to earn points"), { variant: "error" });
      }
      analytics.earn.legacy.tapEarnPointsBtn(mobileNumber, status);
      throw err;
    }
  };

  if (isProfileLoading || profile?.id) return <></>;

  const handlePhoneInputChange = ({ value }: any) => analytics.earn.legacy.enterPhoneNumber(value);

  return (
    <Earn
      keys={[dsi]}
      country={vendor.country.code}
      currencyFormat={currencyFormat}
      program={program}
      events={{
        onInput: async (mobile) => handlePhoneInputChange({ value: mobile }),
        onEarn: program.config.isLegacy ? legacySubmitHandler : submitHandler
      }}
      ui={{
        text: {
          title: getLocaleText(program.config.earnWidgetTitle ?? "", lang, Locales.English),
          description: getLocaleText(program.config.earnWidgetDescription ?? "", lang, Locales.English)
        },
        enablePopup: program.config.earnWidgetPopup
      }}
      meta={{
        restaurantLogoUrl: vendor.config?.loyaltyProgramLogoUrl ?? vendor.logoBigUrl,
        restaurantLogoAvatarUrl: vendor.config?.loyaltyProgramLogoUrl ?? vendor.logoSmallUrl
      }}
      className={className}
      style={style}
    />
  );
};

export default EarnCentral;
