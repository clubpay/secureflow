import { useMemo } from "react";
import { useGetRestaurantLoyaltyPrograms } from "@/hooks/api";
import { inflateLoyaltyProgram } from "@/transformers";
import { GatewayPaymentMethod, GatewayVendor, ILoyalty, LoyaltyService } from "@/types";
import { IComoConfig, ILoyaltyProgram } from "@/types/entities/program";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";

export interface IUseProgramsProps {
  gatewayVendor?: string;
  gatewayPaymentMethod?: GatewayPaymentMethod;
  earnings?: ILoyalty[];
  redemptions?: any;
}

export const usePrograms = ({ gatewayVendor, gatewayPaymentMethod, redemptions }: IUseProgramsProps) => {
  const { vendor } = useVendor();

  const { data: programs } = useGetRestaurantLoyaltyPrograms();

  return useMemo(() => {
    const list = [];
    if (
      vendor?.config?.tickitEnabled &&
      gatewayVendor === GatewayVendor.Checkout &&
      gatewayPaymentMethod === GatewayPaymentMethod.ApplePay
    ) {
      list.push(inflateLoyaltyProgram({ id: LoyaltyService.Tickit, type: LoyaltyService.Tickit } as any, vendor));
    }
    if ((vendor?.config?.comoV2EarnWithoutLogin || vendor?.config?.comoEnable) && !redemptions) {
      list.push(
        inflateLoyaltyProgram(
          { id: LoyaltyService.Como, type: LoyaltyService.Como } as any,
          vendor,
          vendor?.config?.comoEnable && !vendor?.config?.comoV2EarnWithoutLogin
        )
      );
    }
    const como = programs?.find((program) => program.type === LoyaltyService.Como) as ILoyaltyProgram<IComoConfig>;
    if (como?.config?.enableEarnWithoutLogin && vendor && !redemptions?.length) {
      list.push(inflateLoyaltyProgram(como, vendor));
    }
    return list;
  }, [vendor?.config, gatewayVendor, gatewayPaymentMethod, redemptions]);
};

export default usePrograms;
