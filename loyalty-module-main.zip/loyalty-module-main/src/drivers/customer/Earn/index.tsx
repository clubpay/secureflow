import dynamic from "next/dynamic";
import { default as DynamicLoader } from "@/components/Common/Core/DynamicLoader";
import { IProps } from "./dynamic";

const Earn = dynamic<IProps>(() => import("./dynamic"), {
  loading: DynamicLoader,
  ssr: false
});

export default Earn;
