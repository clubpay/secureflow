import { useAuthStore } from "@/store/auth";
import { useCheckoutStore } from "@/store/checkout";
import { LoyaltyService } from "@/types";
import { checkIfInSchedule } from "@/utils";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { default as Core, IProps as ICentralProps } from "./central";
import { default as usePrograms } from "./programs";

export interface IProps extends Omit<ICentralProps, "program"> {
  services?: LoyaltyService[];
}

export const Redemption = (props: IProps) => {
  const programs = usePrograms();
  const { vendor } = useVendor();
  const { isTimeExceeded } = useCheckoutStore();

  return (
    <>
      {programs.map((program) => {
        const inSchedule =
          checkIfInSchedule(program.config?.burnPermittedSchedule, vendor?.timezone?.timezone) &&
          !isTimeExceeded[program.id];
        const user = useAuthStore.getState().user[program.id];
        return (
          (inSchedule || (!program.config?.useToggle && !user?.isAuthorized)) &&
          (props.services ? props.services.includes(program.type) : true) && (
            <Core key={program.id} program={program} {...props} />
          )
        );
      })}
    </>
  );
};

export default Redemption;
