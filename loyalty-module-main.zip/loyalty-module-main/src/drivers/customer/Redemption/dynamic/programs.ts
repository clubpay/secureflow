import { useMemo } from "react";
import { useGetRestaurantLoyaltyPrograms } from "@/hooks/api";
import { useGlobalStore } from "@/store/global";
import { inflateLoyaltyProgram } from "@/transformers";
import { LoyaltyService } from "@/types";
import {
  IComoConfig,
  ILoyaltyProgram,
  IQlubConfig,
  IRotanaConfig,
  InternalProgramType
} from "@/types/entities/program";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";

export const usePrograms = () => {
  const { vendor } = useVendor();

  const { data: programs } = useGetRestaurantLoyaltyPrograms();

  return useMemo(() => {
    const list = [];
    if (vendor?.config?.comoV2Enabled) {
      list.push(inflateLoyaltyProgram({ id: LoyaltyService.Como, type: LoyaltyService.Como } as any, vendor));
    }
    const como = programs?.find((program) => program.type === LoyaltyService.Como) as ILoyaltyProgram<IComoConfig>;
    if (como?.config?.isBurnEnabled && vendor) {
      list.push(inflateLoyaltyProgram(como, vendor));
    }
    const rotana = programs?.find(
      (program) => program.type === LoyaltyService.Rotana
    ) as ILoyaltyProgram<IRotanaConfig>;
    if (rotana?.config?.isBurnEnabled && vendor) {
      list.push(inflateLoyaltyProgram(rotana, vendor));
    }
    (programs as any)?.forEach((program: ILoyaltyProgram<IQlubConfig>) => {
      if (vendor) {
        const inflatedProgram = inflateLoyaltyProgram(program, vendor);
        if (
          program.type === LoyaltyService.Qlub &&
          program.enabled &&
          program.config.isBurnEnabled &&
          inflatedProgram.internalProgramType === InternalProgramType.IN_EARN_BURN
        ) {
          list.push(inflatedProgram);
        }
      }
    });
    const globalState = useGlobalStore.getState();
    if (!globalState.selectedProgram?.id && list.length > 0) {
      globalState.setSelectedProgram(list[0]);
    }
    return list;
  }, [vendor?.config?.comoV2Enabled, programs]);
};

export default usePrograms;
