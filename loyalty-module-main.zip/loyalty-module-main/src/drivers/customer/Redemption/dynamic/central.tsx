import { default as Toggle } from "@/components/Redemption/Toggle";
import { default as Trigger } from "@/components/Trigger";
import { CUID, lockGatewayID } from "@/constants";
import { default as useAnalytics } from "@/hooks/analytics";
import { default as useAPI, useProfile } from "@/hooks/api";
import { default as useAuthComponentProps } from "@/hooks/auth";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useCheckoutStore } from "@/store/checkout";
import { useGlobalStore } from "@/store/global";
import { IPaymentPartyUI } from "@/types";
import { IDriverProps } from "@/types/drivers";
import { ILoyaltyProgram } from "@/types/entities/program";
import { checkIfInSchedule } from "@/utils";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { snackBar } from "@clubpay/customer-common-module/src/hook/snackBar";
import {
  IGatewayPayHandler,
  IPayBeforePaymentHandler,
  PaymentElementEnum
} from "@clubpay/customer-common-module/src/repository/common/payment/type";
import { SplitModeTypeEnum } from "@clubpay/customer-common-module/src/repository/vendor";
import { getAuth } from "@clubpay/customer-common-module/src/service/session/auth";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";
import { Box } from "@mui/material";
import { Divider } from "@qlub-dev/qlub-kit";
import { getParty } from "./utils";

export interface IProps extends IDriverProps {
  program: ILoyaltyProgram;
  onBeforePayment?: (payload: IPayBeforePaymentHandler) => Promise<boolean>;
  onRefresh?: () => Promise<void>;
  onDone?: (payload: IGatewayPayHandler, isComoFullPayment?: boolean) => void;
  enableTriggerTopDivider?: boolean;
}

const LoyaltyRedemption = ({ api, onRefresh, onDone, program, onBeforePayment, enableTriggerTopDivider }: IProps) => {
  const customerID = new URLSearchParams(window.location.search).get(CUID) as any;

  const authComponentProps = useAuthComponentProps(program);

  const { triggerSnackBar } = snackBar();

  const { profile: qlubProfile, login } = useAuth();

  const { profile, refetch: refetchProfile } = useProfile(
    !program.config.automatedLogin || customerID ? program : undefined
  );

  const paymentDetails = useGlobalStore((state) => state.paymentDetails);

  const setAccountBalance = useAuthStore((state) => state.setAccountBalance);

  const setIsTimeExceeded = useCheckoutStore((state) => state.setIsTimeExceeded);

  const { vendor, tableName, currencyFormat } = useVendor();

  const { bill, loyalty } = useAPI(api);

  const analytics = useAnalytics();

  const shouldRedirect = (
    loyaltyAmount: number,
    currentParty: IPaymentPartyUI | undefined,
    confirmation?: string
  ): boolean => {
    if (
      ((!currentParty?.amountNumber || currentParty?.amountNumber === 0) &&
        loyaltyAmount === Number(currentParty?.loyalty?.amount)) ||
      (!currentParty && loyaltyAmount === paymentDetails.billNumber.yourShare)
    ) {
      onDone?.(
        {
          amount: Number(loyaltyAmount),
          method: "",
          paymentElement: PaymentElementEnum.None,
          refId: currentParty?.loyalty?.confirmation || confirmation || "",
          gatewayId: "",
          traceId: "",
          tableName
        },
        true
      );
      return true;
    }
    return false;
  };

  const onRedemption = async ({ points, maxRedeemablePoints, maxRedeemablePointsIgnoringBalance }: any) => {
    if (!checkIfInSchedule(program.config.burnPermittedSchedule, vendor?.timezone?.timezone)) {
      triggerSnackBar(t("You cannot redeem at this time"), { variant: "error" });
      setIsTimeExceeded(program.id, true);
      throw new Error("cannot_redeem_at_this_time");
    }
    const billUpdateCheckResult = await onBeforePayment?.({
      tip: 0,
      paymentElement: PaymentElementEnum.Loyalty,
      isFromLoyaltyModule: true,
      gatewayId: lockGatewayID
    });
    if (!billUpdateCheckResult) {
      throw new Error("bill_is_updated");
    }
    if (!getAuth().JWTToken) await login({ guest: true }).catch(() => {});
    const loyaltyAmount = Number(points * profile!.conversionRate!).toFixed(2);
    analytics.redemption.redeem(
      program,
      profile!.accountBalance >= maxRedeemablePointsIgnoringBalance,
      points === maxRedeemablePoints
    );
    const res = await loyalty.points
      .burn(
        vendor!,
        program,
        {
          amount: loyaltyAmount,
          points: points.toFixed(2),
          pointIdentifier: program.config?.pointIdentifier ?? vendor!.config.loyaltyPointIdentifier ?? ""
        },
        {
          id: customerID,
          phoneNumber: profile!.phoneNumber!
        }
      )
      .catch((e) => {
        if (e.status === 409) {
          triggerSnackBar(
            t("Your redemption didn't go through, there already is another redemption happening for this bill"),
            {
              variant: "warning"
            }
          );
          throw new Error("lock_failed");
        }
        throw e;
      });
    analytics.redemption.success(program);
    if (res?.accountBalance?.nonMonetary !== undefined) {
      setAccountBalance(program.id, res?.accountBalance);
      let currentParty = getParty(paymentDetails.parties);
      if (paymentDetails.yourSplitSettings.amountNumber && profile) {
        const yourCommission = Number(paymentDetails.billNumber.yourCommission) || 0;
        const shareWithoutCommission = paymentDetails.yourSplitSettings.amountNumber - yourCommission;
        const updatedShare =
          paymentDetails.yourSplitSettings.amountNumber - yourCommission - points * profile!.conversionRate!;
        const updatedShareRatio = updatedShare / shareWithoutCommission;
        const updatedCommission = yourCommission * updatedShareRatio;
        const detailsRes = await bill
          ?.setAmount(
            {
              amount: (updatedShare + updatedCommission).toFixed(2),
              diningSessionID: paymentDetails.diningSessionID,
              id: getSession(),
              name: paymentDetails.yourSplitSettings.name,
              splitMode: SplitModeTypeEnum.custom,
              items: paymentDetails.yourSplitSettings.billSplit.items,
              share: paymentDetails.yourSplitSettings.billSplit.share,
              totalShares: paymentDetails.yourSplitSettings.billSplit.totalShares
            },
            {
              cc: vendor?.country.code || "en",
              vendor
            }
          )
          .catch(async (e) => {
            if (e.response?.data?.error?.items === "PAYMENT_AMOUNT_IS_TOO_LARGE") {
              await onRefresh?.();
            }
            throw e;
          });
        currentParty = getParty(detailsRes?.paymentDetails?.parties);
      }
      const redirected = shouldRedirect(Number(loyaltyAmount), currentParty, res?.confirmation);
      if (!redirected) {
        await onRefresh?.();
      }
    }
  };

  if (!vendor || (program.config.automatedLogin && !customerID)) return null;

  if (
    program.config.limitSingleRedemptionPerCustomer &&
    paymentDetails?.parties?.find(
      (p) => p.customerID === qlubProfile?.id && p.loyalty?.status === "ok" && p.loyalty?.program === program.id
    )
  ) {
    return <></>;
  }

  const onTriggerClick = async () => {
    analytics.redemption.clickCTA(program);
    analytics.general.clickEarnAndRedeem(program);
    if (profile?.id && (!program.config.displayOfferSelectorSheet || !program.config.isDiscountEnabled))
      await refetchProfile();
  };

  const onRedemptionTriggerVisible = () => analytics.redemption.impression(program);

  const onRedemptionClick = () => analytics.redemption.click(program);

  const onRedemptionConfirm = () => analytics.redemption.confirm(program);

  const onRedemptionCancel = () => analytics.redemption.cancel(program);

  const onWalletOpen = () => analytics.redemption.walletImpression(program);

  const onInsufficientPoints = () => analytics.redemption.insufficientPoints(program);

  const Component = program.config?.useToggle ? Toggle : Trigger;

  const toggleLoginPrompt =
    program.config?.useToggle && !profile?.isAuthorized && (profile?.accountBalance?.nonMonetary ?? 0) <= 0;

  return (
    <>
      <Box mt={!authComponentProps.config.redemption.completed && !toggleLoginPrompt ? 2 : 0}>
        <Component
          {...authComponentProps}
          currencyFormat={currencyFormat}
          config={{
            ...authComponentProps.config,
            events: {
              ...authComponentProps.config.events,
              onTriggerClick,
              onWalletOpen,
              onRedemption,
              onRedemptionClick,
              onRedemptionConfirm,
              onRedemptionCancel,
              onRedemptionTriggerVisible,
              onInsufficientPoints,
              onRefresh
            },
            ui: {
              enableTriggerTopDivider
            }
          }}
        />
      </Box>
      {!authComponentProps.config.redemption.completed &&
        !(program.config.useToggle && !profile?.isAuthorized && (profile?.accountBalance.nonMonetary ?? 0) <= 0) && (
          <Box position="relative" mt={2}>
            <Divider sx={{ width: "calc(100% + 3rem)", marginLeft: "-1.5rem" }} type="fullWidth" />
          </Box>
        )}
    </>
  );
};

export default LoyaltyRedemption;
