import { IPaymentPartyUI } from "@/types";
import { getSession } from "@clubpay/customer-common-module/src/service/session/dsi";

export const getParty = (parties: IPaymentPartyUI[] | undefined) => {
  return parties?.find((p) => p.id === getSession());
};