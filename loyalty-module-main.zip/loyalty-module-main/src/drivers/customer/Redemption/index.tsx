import dynamic from "next/dynamic";
import { default as DynamicLoader } from "@/components/Common/Core/DynamicLoader";
import { IProps } from "./dynamic";

const LoyaltyCore = dynamic<IProps>(() => import("./dynamic"), {
  loading: DynamicLoader,
  ssr: false
});

export default LoyaltyCore;
