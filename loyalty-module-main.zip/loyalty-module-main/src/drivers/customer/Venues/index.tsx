import { useEffect, useState } from "react";
import { useInView } from "react-intersection-observer";
import { default as Search } from "@/components/Common/Core/Search";
import { VenueCard } from "@/components/Venue";
import { default as VenueCardLoader } from "@/components/Venue/Card/loader";
import { useDebounce } from "@/hooks";
import { useEnabledLoyaltyProgram, useGetCountryLoyaltyProgram, useGetProgramVenues } from "@/hooks/api";
import { t } from "@/locales";
import { getLocaleText } from "@clubpay/customer-common-module/src/component/MultiLocale";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { useQlubRouter } from "@clubpay/customer-common-module/src/hook/router";
import { InfoOutlined } from "@mui/icons-material";
import { Typography } from "@mui/material";
import { default as styles } from "./venues.module.scss";

const VenuesUI = () => {
  const { ref, inView } = useInView();
  const [search, setSearch] = useState<string>("");

  const deferredSearch = useDebounce(search);

  const { vendor } = useVendor();

  const { lang = vendor?.country?.languageCode, url } = useQlubRouter();

  const { program: restaurantProgram, isLoading: isProgramLoading } = useEnabledLoyaltyProgram();

  const { data: countryProgram } = useGetCountryLoyaltyProgram(url?.cc);

  const program = restaurantProgram ?? countryProgram;

  const {
    data: venues,
    isLoading: isVenuesLoading,
    fetchNextPage,
    isFetchingNextPage
  } = useGetProgramVenues(program?.id, deferredSearch);

  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => setSearch(e.target.value);

  useEffect(() => {
    if (inView) fetchNextPage();
  }, [inView]);

  const isLoading = isVenuesLoading || (isProgramLoading && !countryProgram);

  return (
    <div className={styles.root}>
      <Search placeholder={t("Search by venue name")} value={search} onChange={onChange} />
      <div className={styles.list}>
        {!isLoading &&
          (venues && venues.pages.at(0)?.count ? (
            venues.pages.map((page) =>
              page.rows.map((venue) => (
                <VenueCard key={venue.code} venue={venue} getLocaleText={getLocaleText} locale={lang} />
              ))
            )
          ) : (
            <div className={styles.empty}>
              <InfoOutlined color="disabled" fontSize="large" />
              <Typography align="center" color="GrayText">
                {t(search ? "No search result found" : "No venues found")}
              </Typography>
            </div>
          ))}
        {(isFetchingNextPage || isLoading) &&
          Array.from({ length: 3 }).map((_, index) => <VenueCardLoader key={index} />)}
      </div>
      <div className={styles.anchor}>
        <span ref={ref} />
      </div>
    </div>
  );
};

export default VenuesUI;
