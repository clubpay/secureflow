import { default as LoginBanner } from "@/components/Banners/Login";
import { default as EarnPrompt } from "@/components/EarnPrompt/Qlub";
import { useEnabledLoyaltyProgram } from "@/hooks/api";
import { Locales } from "@/types";
import { getLocaleText } from "@clubpay/customer-common-module/src/component/MultiLocale";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { useQlubRouter } from "@clubpay/customer-common-module/src/hook/router";
import { StackElements } from "@qlub-dev/qlub-kit/dist/components/StackElements";

interface IProps {
  billAmount?: number;
  billCommission?: number;
  onLogin: () => void;
}

const LoyaltyMenuBottomSheetContent = (props: IProps) => {
  const { vendor, currencyFormat } = useVendor();

  const { lang } = useQlubRouter();

  const { program } = useEnabledLoyaltyProgram();

  const isUrl = new RegExp(/^https?:\/\//i).test(program?.config?.loginBanner || "");
  const loginBanner = isUrl
    ? program?.config?.loginBanner
    : getLocaleText(program?.config?.loginBanner || "", lang, Locales.English);

  if (!program || !vendor) return <></>;

  return (
    <StackElements
      alignItems="center"
      justifyContent="center"
      direction="column"
      spacing={3}
      style={{
        paddingTop: "10px",
        width: "100%"
      }}
    >
      {loginBanner && <LoginBanner banner={loginBanner} />}
      <EarnPrompt program={program} currencyFormat={currencyFormat} {...props} />
    </StackElements>
  );
};

export default LoyaltyMenuBottomSheetContent;
