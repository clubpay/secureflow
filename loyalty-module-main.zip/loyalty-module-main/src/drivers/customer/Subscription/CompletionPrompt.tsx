import { default as BaseSubscriptionCompletionPrompt } from "@/components/Subscription/CompletionPrompt";
import { useEnabledLoyaltyProgram } from "@/hooks/api";

export const SubscriptionCompletionPrompt = (props: React.HTMLAttributes<HTMLDivElement>) => {
  const { program } = useEnabledLoyaltyProgram();

  if (!program || !program.config.readableSubscriptionCompletionPrompt) return <></>;

  return <BaseSubscriptionCompletionPrompt program={program} {...props} />;
};
