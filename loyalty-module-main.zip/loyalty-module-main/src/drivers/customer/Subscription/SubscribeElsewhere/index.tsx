import { default as Button } from "@/components/Common/Core/Button";
import { useEnabledLoyaltyProgram } from "@/hooks/api";
import { Arrow } from "@/icons";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useGlobalStore } from "@/store/global";
import { useSubscriptionStore } from "@/store/subscription";
import { InternalProgramType } from "@/types/entities/program";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { useQlubRouter } from "@clubpay/customer-common-module/src/hook/router";
import styles from "./index.module.scss";

interface ISubscribeElsewhereProps extends React.HtmlHTMLAttributes<HTMLDivElement> {}

const SubscribeElsewhere = (props: ISubscribeElsewhereProps) => {
  const { vendor } = useVendor();
  const { routerPush } = useQlubRouter();
  const { program } = useEnabledLoyaltyProgram();
  const qlubUser = useAuthStore((state) => state.qlubUser);
  const paymentDetails = useGlobalStore((state) => state.paymentDetails);
  const optedForSubscription = useSubscriptionStore((state) => state.optedForSubscription);

  if (
    !vendor ||
    program?.internalProgramType !== InternalProgramType.IN_SUB_DISCOUNT ||
    !optedForSubscription ||
    Number(paymentDetails?.bill?.remaining) > 0 ||
    qlubUser?.hasSubscription(program.subscription!)
  ) {
    return <></>;
  }

  return (
    <div {...props} className={styles.root}>
      <span>{t("In order to subscribe please make a payment at any of our select restaurants")}</span>
      <Button
        onClick={() => {
          routerPush(`/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/loyalty/venues`, {
            utm_source: "app",
            utm_medium: "checkout_page"
          });
        }}
        className={styles.action}
      >
        {t("Explore qlub+ Venues")}
        <Arrow />
      </Button>
    </div>
  );
};

export default SubscribeElsewhere;
