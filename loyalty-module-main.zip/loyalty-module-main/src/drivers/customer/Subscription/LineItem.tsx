import { default as LineItem } from "@/components/Subscription/LineItem";
import { useEnabledLoyaltyProgram } from "@/hooks/api";
import { useSubscriptionCost } from "@/hooks/subscription";
import { t } from "@/locales";
import { useGlobalStore } from "@/store/global";
import { InternalProgramType } from "@/types/entities/program";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";

export const SubscriptionLineItem = (props: React.HTMLAttributes<HTMLDivElement>) => {
  const { vendor, currencyFormat } = useVendor();

  const subscriptionCost = useSubscriptionCost();

  if (!vendor || !subscriptionCost) return <></>;

  return (
    <LineItem
      value={subscriptionCost}
      currencyFormat={currencyFormat}
      color="#7D00D4"
      label={t("qlub plus subscription")}
      {...props}
    />
  );
};

export const DiscountLineItem = (props: React.HTMLAttributes<HTMLDivElement>) => {
  const { vendor, currencyFormat } = useVendor();

  const { program } = useEnabledLoyaltyProgram();

  const paymentDetails = useGlobalStore((state) => state.paymentDetails);

  const remaining = Number(paymentDetails?.bill?.remaining ?? "0.00");

  const discount = paymentDetails?.billNumber?.qlubLoyaltyDiscount;

  if (!vendor || !discount || !remaining || program?.internalProgramType !== InternalProgramType.IN_SUB_DISCOUNT)
    return <></>;

  return (
    <LineItem
      value={-discount}
      currencyFormat={currencyFormat}
      label={t("qlub plus discount")}
      color="#22a958"
      {...props}
    />
  );
};
