import { useEffect } from "react";
import Savings from "@/components/Subscription/Savings";
import { useEnabledLoyaltyProgram } from "@/hooks/api";
import { IAppliedDiscount } from "@/types";
import { InternalProgramType } from "@/types/entities/program";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { useQlubRouter } from "@clubpay/customer-common-module/src/hook/router";

interface ISubscriptionSavingsProps extends React.HtmlHTMLAttributes<HTMLDivElement> {
  appliedDiscounts?: IAppliedDiscount[];
}

const SubscriptionSavings = ({ appliedDiscounts, ...props }: ISubscriptionSavingsProps) => {
  const { vendor, currencyFormat } = useVendor();
  const { routerPush } = useQlubRouter();
  const { refetchProfile } = useAuth();
  const { program } = useEnabledLoyaltyProgram();
  const savings = appliedDiscounts?.reduce((acc, { amount }) => acc + Number(amount), 0) || 0;

  useEffect(() => {
    if (program?.internalProgramType === InternalProgramType.IN_SUB_DISCOUNT) {
      refetchProfile();
    }
  }, [program?.id]);

  if (!vendor || savings <= 0 || program?.internalProgramType !== InternalProgramType.IN_SUB_DISCOUNT) return <></>;
  return (
    <Savings
      savings={savings}
      currencyFormat={currencyFormat}
      onDiscoverClick={() => {
        routerPush(`/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/loyalty/venues`, {
          utm_source: "app",
          utm_medium: "confirmation_page"
        });
      }}
      {...props}
    />
  );
};

export default SubscriptionSavings;
