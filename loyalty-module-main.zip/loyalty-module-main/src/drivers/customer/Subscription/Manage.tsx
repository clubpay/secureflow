import { useEffect } from "react";
import { default as dayjs } from "dayjs";
import Manage from "@/components/Subscription/Manage";
import { useEnabledLoyaltyProgram } from "@/hooks/api";
import { Locales } from "@/types";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { useQlubRouter } from "@clubpay/customer-common-module/src/hook/router";

function ManageSubscription(): JSX.Element {
  const { lang, routerReplace } = useQlubRouter();
  const { vendor, currencyFormat } = useVendor();
  const { program } = useEnabledLoyaltyProgram();

  const { profile } = useAuth();

  const subscription = profile?.subscriptions?.find(
    (sub) => sub.subscriptionID === program?.subscription?.subscriptionID
  );

  const isSuspended = subscription?.status === "suspended";

  const isTemporarilySuspended = isSuspended && dayjs(subscription.renewalDate).isAfter(dayjs());

  useEffect(() => {
    if (isSuspended && !isTemporarilySuspended) {
      routerReplace(`/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]`);
    }
  }, [isSuspended, isTemporarilySuspended]);

  if (!program || !vendor || !subscription) return <></>;

  return (
    <Manage
      program={program}
      currencyFormat={currencyFormat}
      subscription={subscription}
      isTemporarilySuspended={isTemporarilySuspended}
      lang={lang || Locales.English}
    />
  );
}

export default ManageSubscription;
