import { useEffect, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { SubscriptionPrompt as Subscribe, SubscribedBanner } from "@/components/Subscription/Checkout";
import useAnalytics from "@/hooks/analytics";
import { default as useAPI, useEnabledLoyaltyProgram } from "@/hooks/api";
import { t } from "@/locales";
import { useAuthStore } from "@/store/auth";
import { useGlobalStore } from "@/store/global";
import { useSubscriptionStore } from "@/store/subscription";
import { PopupVariant } from "@/types";
import { IDriverProps } from "@/types/drivers";
import { InternalProgramType } from "@/types/entities/program";
import * as events from "@clubpay/customer-common-module/src/const/events";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";

interface ISubscriptionPromptProps extends IDriverProps, React.HtmlHTMLAttributes<HTMLDivElement> {
  onRefresh?: () => Promise<void>;
  onSetAmount: (details: any) => void;
  setBillDetailsLoading: React.Dispatch<React.SetStateAction<boolean>>;
}

const SubscribtionPrompt = (props: ISubscriptionPromptProps) => {
  const { logoutCallbacks, setLogoutCallbacks } = useAuth();
  const { vendor, currencyFormat } = useVendor();
  const { program } = useEnabledLoyaltyProgram();
  const { setOptedForSubscription, joinPopupDisplayed, setJoinPopupDisplayed } = useSubscriptionStore();
  const openLoginSheet = useAuthStore((state) => state.openLoginSheet);
  const setLoginVerificationCallback = useAuthStore((state) => state.setLoginVerificationCallback);
  const paymentDetails = useGlobalStore((state) => state.paymentDetails);
  const qlubUser = useAuthStore((state) => state.qlubUser);
  const openPopup = useGlobalStore((state) => state.popup.openPopup);

  const hasViewEventFired = useRef<boolean>(false);

  const analytics = useAnalytics();

  const { loyalty } = useAPI(props.api);

  const yourShare = Number(paymentDetails?.bill?.yourShare || 0);

  const remainingToPay = Number(paymentDetails?.bill?.remaining || 0);

  const isSplitPayment = remainingToPay > 0 && yourShare > 0 && yourShare < remainingToPay;

  const isSubscribed = program?.subscription?.options?.isActive && qlubUser?.hasSubscription(program!.subscription);

  const enrollMutation = useMutation({
    mutationFn: (subscriptionID: number) =>
      loyalty.subscription.enroll(subscriptionID, paymentDetails?.diningSessionID),
    onError: (response: any) => {
      setOptedForSubscription(false);
      if (response.status === 409) {
        const message = response?.data?.items;
        let messageToShow = "Something went wrong. Please try again";
        if (message == "SUBSCRIPTION_IN_PROGRESS") {
          messageToShow = "You cannot initiate another subscription at the moment";
        } else if (message == "CUSTOMER_SUBSCRIBED") {
          messageToShow = "You are already subscribed";
          props.onRefresh?.();
        }
        window.snackbar.enqueue(t(messageToShow), { variant: "error", autoHideDuration: 5000, persist: false });
      }
    },
    onSuccess: () => {
      if (!joinPopupDisplayed) {
        analytics.subscription.welcomeDiscountApplied(program!, qlubUser);
        openPopup({
          title: t("Congratulations!"),
          subtitle: (
            <>
              {t("You've joined qlub+!")}
              <br />
              {t("Enjoy great deals and savings!")}
            </>
          ),
          buttonText: t("Awesome!"),
          autoCloseDuration: 5000,
          variant: PopupVariant.Congratulations
        });
        setJoinPopupDisplayed(true);
      }
      props.onRefresh?.();
    }
  });

  const cancelMutation = useMutation({
    mutationFn: (subscriptionID: number) => {
      return loyalty.subscription.cancel(subscriptionID, paymentDetails?.diningSessionID);
    },
    onSuccess: () => {
      props.onRefresh?.();
    }
  });

  useEffect(() => {
    if (program?.internalProgramType === InternalProgramType.IN_SUB_DISCOUNT) {
      setLogoutCallbacks?.([...logoutCallbacks, () => setOptedForSubscription(false)]);
    }
  }, [program?.internalProgramType]);

  useEffect(() => {
    const refreshHandler = () => {
      if (program?.internalProgramType === InternalProgramType.IN_SUB_DISCOUNT) {
        props.onRefresh?.();
      }
    };
    document.addEventListener(events.login, refreshHandler);
    return () => {
      document.removeEventListener(events.login, refreshHandler);
    };
  }, [program?.internalProgramType, props.onRefresh]);

  const shouldHide =
    !vendor ||
    !program ||
    program.internalProgramType !== InternalProgramType.IN_SUB_DISCOUNT ||
    isSplitPayment ||
    yourShare == 0;

  useEffect(() => {
    if (!shouldHide && !isSubscribed && !hasViewEventFired.current) {
      analytics.subscription.viewSubscription(program);
      hasViewEventFired.current = true;
    }
  }, [vendor, program, isSplitPayment, yourShare, isSubscribed]);

  if (shouldHide) {
    return <></>;
  }

  if (isSubscribed) return <SubscribedBanner currencyFormat={currencyFormat} {...props} />;

  return (
    <Subscribe
      program={program}
      currencyFormat={currencyFormat}
      disabled={enrollMutation.isPending || cancelMutation.isPending}
      onSubscriptionChange={(checked: boolean) => {
        if (checked) {
          analytics.subscription.clickOnSubscription(program);
          const subscribe = () => {
            enrollMutation.mutate(program?.subscription!.subscriptionID);
            setOptedForSubscription(true);
          };
          if (qlubUser?.id) {
            subscribe();
          } else {
            openLoginSheet(program.id, true);
            setLoginVerificationCallback(program.id, subscribe as any);
          }
        } else {
          analytics.subscription.clickOnUnsubscribe(program);
          window.openDialog?.(t("Are you sure you want to unsubscribe?"), () => {
            cancelMutation.mutate(program?.subscription!.subscriptionID);
            setOptedForSubscription(false);
            window.closeDialog();
          });
        }
      }}
      {...props}
    />
  );
};

export default SubscribtionPrompt;
