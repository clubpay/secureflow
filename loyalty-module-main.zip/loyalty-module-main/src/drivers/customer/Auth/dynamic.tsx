import { LoginSheet, OTPSheet, RegistrationSheet, WelcomeSheet } from "@/components/Auth";
import useAuthComponentProps from "@/hooks/auth";

const LoyaltyAuth = () => {
  const props = useAuthComponentProps();
  return (
    <>
      <LoginSheet {...props} />
      <OTPSheet {...props} />
      <RegistrationSheet {...props} />
      <WelcomeSheet {...props} />
    </>
  );
};

export default LoyaltyAuth;
