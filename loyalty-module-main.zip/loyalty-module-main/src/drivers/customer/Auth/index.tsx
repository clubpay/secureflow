import dynamic from "next/dynamic";
import { default as DynamicLoader } from "@/components/Common/Core/DynamicLoader";

const LoyaltyCore = dynamic(() => import("./dynamic"), {
  loading: DynamicLoader,
  ssr: false
});

export default LoyaltyCore;
