import { FC } from "react";
import { default as Trigger } from "@/components/Trigger";
import { CUID } from "@/constants";
import useAuthComponentProps from "@/hooks/auth";
import { TriggerType } from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { default as Box } from "@mui/material/Box";

export interface IProps {
  program: ILoyaltyProgram;
  onRefresh: () => Promise<void>;
}

const Offers: FC<IProps> = ({ program, onRefresh }) => {
  const customerID = new URLSearchParams(window.location.search).get(CUID) as any;

  const authComponentProps = useAuthComponentProps(program);

  const { vendor, currencyFormat } = useVendor();

  if (!vendor || (program.config.automatedLogin && !customerID)) return null;

  if (program.config.limitSingleLoyaltyDiscount && authComponentProps.bill?.hasLoyaltyDiscounts) {
    return <></>;
  }

  return (
    <Box sx={{ pt: 2 }}>
      <Trigger
        {...authComponentProps}
        type={TriggerType.Offer}
        currencyFormat={currencyFormat}
        config={{
          ...authComponentProps.config,
          events: {
            ...authComponentProps.config.events,
            onRefresh
          }
        }}
      />
    </Box>
  );
};

export default Offers;
