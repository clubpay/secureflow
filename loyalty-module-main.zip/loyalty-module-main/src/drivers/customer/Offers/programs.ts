import { useMemo } from "react";
import { useGetRestaurantLoyaltyPrograms } from "@/hooks/api";
import { useGlobalStore } from "@/store/global";
import { inflateLoyaltyProgram } from "@/transformers";
import { LoyaltyService } from "@/types";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";

export const usePrograms = () => {
  const { vendor = { config: {} } as any } = useVendor();

  const { data: programs } = useGetRestaurantLoyaltyPrograms();

  return useMemo(() => {
    const list = [];
    const como = programs?.find((program) => program.type === LoyaltyService.Como);
    if (como?.config?.isDiscountEnabled && vendor) {
      list.push(inflateLoyaltyProgram(como, vendor));
    }
    const rotana = programs?.find(({ type }) => type === LoyaltyService.Rotana);
    if (rotana?.config?.isDiscountEnabled) {
      list.push(inflateLoyaltyProgram(rotana, vendor));
    }
    const globalState = useGlobalStore.getState();
    if (!globalState.selectedProgram?.id && list.length > 0) {
      globalState.setSelectedProgram(list[0]);
    }
    return list;
  }, [programs, vendor?.config?.comoV2Enabled]);
};

export default usePrograms;
