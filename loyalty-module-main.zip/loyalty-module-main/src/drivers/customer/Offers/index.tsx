import { LoyaltyService } from "@/types";
import { IProps as ICentralProps, default as OfferCentral } from "./central";
import { default as usePrograms } from "./programs";

export interface IProps extends Omit<ICentralProps, "program"> {
  services?: LoyaltyService[];
}

export const Offers = (props: IProps) => {
  const programs = usePrograms();

  return (
    <>
      {programs.map(
        (program) =>
          (props.services ? props.services.includes(program.type) : true) && (
            <OfferCentral key={program.id} program={program} {...props} />
          )
      )}
    </>
  );
};

export default Offers;
