import { useCallback, useEffect, useState } from "react";
import { default as throttle } from "lodash/throttle";
import { useGetRestaurantLoyaltyPrograms, useLoyaltyProgram } from "@/hooks/api";
import { t } from "@/locales";
import { useEarnStore } from "@/store/earn";
import { ILoyalty, Locales, LoyaltyService } from "@/types";
import { getLocaleText } from "@clubpay/customer-common-module/src/component/MultiLocale";
import { useConfigContext } from "@clubpay/customer-common-module/src/context/config";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { useQlubRouter } from "@clubpay/customer-common-module/src/hook/router";
import { default as Box } from "@mui/material/Box";
import { Divider, Typography } from "@qlub-dev/qlub-kit";
import { default as styles } from "./earn.confirmation.module.scss";

export interface IProps {
  redemption?: ILoyalty;
  earnings?: ILoyalty[];
  earningsRefetchFn: (...args: any[]) => any;
}

const EarnConfirmation = ({ redemption, earnings, earningsRefetchFn }: IProps) => {
  const { vendor } = useVendor();
  const { config } = useConfigContext();
  const { lang } = useQlubRouter();
  const pointsEarned = useEarnStore((state) => state.pointsEarned);
  const [refetched, setRefetched] = useState(false);

  const earnedProgramIDFromLocalState = Object.entries(pointsEarned).find(([, v]) => v)?.[0];

  const { data: programs } = useGetRestaurantLoyaltyPrograms();

  const program = useLoyaltyProgram(earnings?.[0]?.program ?? earnedProgramIDFromLocalState ?? "");

  const refetchEarnings = useCallback(
    throttle(earningsRefetchFn, 1000, {
      leading: true,
      trailing: true
    }),
    [earningsRefetchFn]
  );

  useEffect(() => {
    if (programs?.length && !earnings?.length && !refetched) {
      refetchEarnings(true);
      setRefetched(true);
    }
    setTimeout(() => {
      if (!earnings?.length) refetchEarnings(true);
      setTimeout(() => {
        if (!earnings?.length) refetchEarnings(true);
      }, 500);
    }, 300);
  }, [programs?.length, program?.type, earnings?.length, refetched]);

  if (
    !vendor ||
    redemption?.type === LoyaltyService.Qlub ||
    (!earnings?.length && !earnedProgramIDFromLocalState && redemption?.status !== "ok")
  ) {
    return null;
  }

  const vendorLoyaltyProgramName = getLocaleText(vendor?.config?.loyaltyProgramName ?? "", lang, Locales.English);

  return (
    <Box mb={3} className={styles.container} sx={{ px: 3 }}>
      {(vendorLoyaltyProgramName || program) && (
        <Typography sx={{ py: 1 }} typo="caption_overline">
          {t("Check your {{loyaltyProgram}} App for your earned points", {
            loyaltyProgram: program ? program.config.readableDisplayName : vendorLoyaltyProgramName
          })}
        </Typography>
      )}
      {(vendor?.config.orderSummary || config?.orderSummary) === "show" && (
        <Box position="relative" mt={2}>
          <Divider sx={{ width: "calc(100% + 3rem)", marginLeft: "-1.5rem" }} type="fullWidth" />
        </Box>
      )}
    </Box>
  );
};

export default EarnConfirmation;
