import { default as EarnPrompt } from "@/components/EarnPrompt/Como";
import { RedemptionDetails } from "@/components/Redemption";
import { useLoyaltyProgram } from "@/hooks/api";
import { t } from "@/locales";
import { useGlobalStore } from "@/store/global";
import { inflateLoyaltyProgram } from "@/transformers";
import { Locales, LoyaltyService } from "@/types";
import { IComoConfig } from "@/types/entities/program";
import { getLocaleText } from "@clubpay/customer-common-module/src/component/MultiLocale";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { useQlubRouter } from "@clubpay/customer-common-module/src/hook/router";

const RedemptionConfirmation = () => {
  const { vendor, currencyFormat } = useVendor();

  const { paymentDetails } = useGlobalStore();

  const { lang = vendor?.country?.languageCode } = useQlubRouter();

  const loyalty = paymentDetails?.yourSplitSettings?.loyalty;

  const redeemedProgram = useLoyaltyProgram(loyalty?.program ?? "");

  const como = useLoyaltyProgram<IComoConfig>(LoyaltyService.Como);

  if (!vendor) return null;

  if (loyalty?.status !== "ok") {
    if ((vendor.config.comoV2Enabled && vendor.config.comoV2EnableLoginPrompt) || como?.config?.enableLoginPrompt) {
      return (
        <EarnPrompt
          locale={lang}
          serviceID={como?.id ?? LoyaltyService.Como}
          logoUrl={como?.config?.logo || vendor.config.loyaltyProgramLogoUrl || vendor.logoBigUrl}
        />
      );
    }
    return null;
  }

  return (
    <RedemptionDetails
      country={vendor.country.code}
      currencyFormat={currencyFormat}
      meta={{
        restaurantLogoUrl: redeemedProgram
          ? redeemedProgram?.config?.logo
          : vendor.config?.loyaltyProgramLogoUrl ?? vendor.logoBigUrl,
        restaurantLogoAvatarUrl: redeemedProgram
          ? redeemedProgram?.config?.logo
          : vendor.config?.loyaltyProgramLogoUrl ?? vendor.logoSmallUrl
      }}
      program={inflateLoyaltyProgram(
        redeemedProgram ? redeemedProgram : ({ id: loyalty.program, type: loyalty.type } as any),
        vendor
      )}
      config={{
        redemption: {
          amount: Number(loyalty.amount) || 0,
          points: Number(loyalty.points) || 0,
          pointIdentifier: getLocaleText(
            loyalty?.pointName || vendor.config.loyaltyPointIdentifier || t("Points"),
            lang,
            Locales.English
          ),
          completed: loyalty.status === "ok"
        }
      }}
    />
  );
};

export default RedemptionConfirmation;
