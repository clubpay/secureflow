import { useEffect } from "react";
import { default as EarnedPointsComponent } from "@/components/EarnedPoints";
import { useEnabledLoyaltyProgram } from "@/hooks/api";
import { useAuthStore } from "@/store/auth";
import { ILoyalty, LoyaltyService } from "@/types";
import { InternalProgramType, LoyaltyVisibilityStatus } from "@/types/entities/program";
import { useAuth } from "@clubpay/customer-common-module/src/context/auth";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";

export interface IProps {
  earnings: ILoyalty[];
  earningsRefetchFn: (...args: any[]) => any;
}

const EarnedPoints = ({ earnings }: IProps) => {
  const { vendor, currencyFormat } = useVendor();

  const { program } = useEnabledLoyaltyProgram();

  const render = program?.enabled && program?.config?.isEarnEnabled && program?.type === LoyaltyService.Qlub;

  const qlubUser = useAuth();

  const { openLoginSheet } = useAuthStore();

  const earning = earnings?.find((e) => e.program === program?.id);

  useEffect(() => {
    if (
      render &&
      qlubUser &&
      !qlubUser.isAuthorizedUser &&
      program?.internalProgramType === InternalProgramType.IN_EARN_BURN &&
      program.config.showSecurePoints !== LoyaltyVisibilityStatus.Hide &&
      earning
    )
      openLoginSheet(program.id, true, true, { amount: earning.amount });
  }, [qlubUser?.isAuthorizedUser, render, program?.internalProgramType, earning?.amount]);

  if (!vendor || !render || !earning || program?.internalProgramType !== InternalProgramType.IN_EARN_BURN) return null;

  return <EarnedPointsComponent currencyFormat={currencyFormat} program={program} amount={Number(earning.amount)} />;
};

export default EarnedPoints;
