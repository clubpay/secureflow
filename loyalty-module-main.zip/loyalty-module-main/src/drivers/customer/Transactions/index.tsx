import { Fragment, useEffect } from "react";
import { useInView } from "react-intersection-observer";
import { default as Tabs } from "@/components/Common/Core/Tabs";
import { default as TransactionCard } from "@/components/Transaction/Item";
import { WalletType } from "@/components/Wallet";
import { default as Wallet } from "@/drivers/customer/Wallet";
import { useCustomerTransactions, useEnabledLoyaltyProgram, useProfile } from "@/hooks/api";
import { t } from "@/locales";
import { IProfileDetails } from "@/types";
import { ILoyaltyProgram, IQlubConfig } from "@/types/entities/program";
import { default as InfoOutlined } from "@mui/icons-material/InfoOutlined";
import { Box, Skeleton, Stack, Typography } from "@mui/material";
import { Divider } from "@qlub-dev/qlub-kit";
import { default as styles } from "./transactions.module.scss";

const TransactionsUI = () => {
  const { program } = useEnabledLoyaltyProgram();

  const { profile } = useProfile(program);

  return (
    <div className={styles.root}>
      <Wallet type={WalletType.Detailed} />
      <Box marginTop="20px">
        <Tabs
          data={[
            {
              label: t("Transactions"),
              content: <Transactions user={profile} program={program} />
            },
            {
              label: t("Earned & Expiring"),
              content: <EarnAndExpiring user={profile} program={program} />
            }
          ]}
        />
      </Box>
    </div>
  );
};

function Transactions({
  user,
  program
}: {
  user?: IProfileDetails;
  program?: ILoyaltyProgram<IQlubConfig>;
}): JSX.Element {
  const { ref, inView } = useInView();
  const { data, fetchNextPage, isFetchingNextPage, isPending } = useCustomerTransactions(user?.id, {
    programId: program?.id,
    program: "qlub",
    transferTypes: ["loyalty-earn", "loyalty-burn", "loyalty-move"]
  });

  useEffect(() => {
    if (inView) fetchNextPage();
  }, [inView]);

  return (
    <Fragment>
      {!isPending &&
        (data && data.pages.at(0)?.count
          ? data.pages.map((page) => page.transfers.map((item) => <TransactionCard key={item.id} transaction={item} />))
          : user?.id &&
            program?.id && (
              <div className={styles.empty}>
                <InfoOutlined color="disabled" fontSize="large" />
                <Typography align="center" color="GrayText">
                  {t("No transactions available")}
                </Typography>
              </div>
            ))}
      {(isFetchingNextPage || isPending || !user?.id || !program?.id) &&
        Array.from({ length: 3 }).map((_, index) => (
          <Fragment key={index}>
            <Box paddingY="12px">
              <Skeleton variant="rounded" height={43} width="100%" />
            </Box>
            {index !== 2 && (
              <Box position="relative">
                <Divider type="fullWidth" />
              </Box>
            )}
          </Fragment>
        ))}
      <div className={styles.anchor}>
        <span ref={ref} />
      </div>
    </Fragment>
  );
}

function EarnAndExpiring({
  user,
  program
}: {
  user?: IProfileDetails;
  program?: ILoyaltyProgram<IQlubConfig>;
}): JSX.Element {
  const { ref, inView } = useInView();
  const { data, fetchNextPage, isFetchingNextPage, isPending } = useCustomerTransactions(user?.id, {
    programId: program?.id,
    program: "qlub",
    transferTypes: ["loyalty-earn", "loyalty-move"]
  });

  useEffect(() => {
    if (inView) fetchNextPage();
  }, [inView]);

  return (
    <Fragment>
      {!isPending &&
        (data && data.pages.at(0)?.count
          ? data.pages.map((page) =>
              page.transfers.map((item) => <TransactionCard key={item.id} transaction={item} showExpiry />)
            )
          : user?.id &&
            program?.id && (
              <div className={styles.empty}>
                <InfoOutlined color="disabled" fontSize="large" />
                <Typography color="GrayText">{t("No transactions available")}</Typography>
              </div>
            ))}
      {(isFetchingNextPage || isPending || !user?.id || !program?.id) &&
        Array.from({ length: 3 }).map((_, index) => (
          <Fragment key={index}>
            <Stack spacing="7px" paddingY="12px">
              <Skeleton variant="rounded" height={43} width="100%" />
              <Skeleton variant="rounded" height={24} width="100%" />
            </Stack>
            {index !== 2 && (
              <Box position="relative">
                <Divider type="fullWidth" />
              </Box>
            )}
          </Fragment>
        ))}
      <div className={styles.anchor}>
        <span ref={ref} />
      </div>
    </Fragment>
  );
}

export default TransactionsUI;
