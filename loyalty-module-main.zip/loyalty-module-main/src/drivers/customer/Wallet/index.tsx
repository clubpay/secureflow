import { useEffect, useState } from "react";
import { default as WalletUI } from "@/components/Wallet";
import { WalletType } from "@/components/Wallet";
import { useEnabledLoyaltyProgram, useProfile } from "@/hooks/api";
import { LoyaltyVisibilityStatus } from "@/types/entities/program";
import { useVendor } from "@clubpay/customer-common-module/src/context/vendor";
import { Collapse } from "@mui/material";

interface IProps {
  type?: WalletType;
  billAmount?: number;
  loading?: boolean;
  isLanding?: boolean;
}

const Wallet = ({ type = WalletType.Teaser, billAmount, loading, isLanding = false }: IProps) => {
  const [collapsed, setCollapsed] = useState(true);

  const { currencyFormat } = useVendor();

  const { program, isError } = useEnabledLoyaltyProgram();

  const { profile } = useProfile(program);

  useEffect(() => {
    if (profile?.id && program?.id) {
      setCollapsed(false);
    }
  }, [program?.id, profile?.id]);

  if (isError || !program) return <></>;

  return (
    <>
      {(!isLanding || program.config.showWalletInLanding !== LoyaltyVisibilityStatus.Hide) && (
        <Collapse in={!collapsed} style={{ width: "100%" }} unmountOnExit>
          <WalletUI
            type={type}
            key={program.id}
            program={program}
            billAmount={billAmount}
            currencyFormat={currencyFormat}
            loading={loading}
          />
        </Collapse>
      )}
    </>
  );
};

export default Wallet;
