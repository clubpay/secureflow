import { default as Button } from "@/components/Common/Core/Button";
import { useEnabledLoyaltyProgram } from "@/hooks/api";
import { Arrow } from "@/icons";
import { t } from "@/locales";
import { InternalProgramType } from "@/types/entities/program";
import { useQlubRouter } from "@clubpay/customer-common-module/src/hook/router";
import { Box } from "@mui/material";
import styles from "./wallet.partners.module.scss";

const WalletPartnerButton = () => {
  const { routerPush } = useQlubRouter();

  const { program } = useEnabledLoyaltyProgram();

  if (!program) return <></>;

  const onClick = () => {
    routerPush(`/qr/[cc]/[slug]/[id]/[f1]/[f2]/[hash]/loyalty/venues`, {
      utm_source: "app",
      utm_medium: "confirmation_page"
    });
  };

  return (
    <Box className={styles.root}>
      <Button onClick={onClick}>
        {program?.internalProgramType === InternalProgramType.IN_SUB_DISCOUNT
          ? t("Explore qlub+ Venues")
          : t("Loyalty restaurants")}
        <Arrow className={styles.svg} />
      </Button>
    </Box>
  );
};

export default WalletPartnerButton;
