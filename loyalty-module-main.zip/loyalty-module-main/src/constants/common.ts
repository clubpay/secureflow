// OS Types
export const IOS = "iOS";
export const Android = "Android";
