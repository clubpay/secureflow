export const alphaNumericDashUnderscore = /^[A-Za-z0-9-_]+(?: +[A-Za-z0-9]+)*$/;
export const alphaNumericOnly = /^[a-zA-Z0-9 ]*$/;
export const emailValidationWithQlubIo = /^[A-Za-z0-9._%+-]+@qlub.io$/;
export const emailValidationWithQlub = /^[A-Za-z0-9._%+-]+@qlub[.][a-z]{2,6}$/;
export const capitalSmallSpecialCharacter = /^(?=.)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^!&*+=]).*$/;
export const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:\.[a-zA-Z]{2,})?$/;
