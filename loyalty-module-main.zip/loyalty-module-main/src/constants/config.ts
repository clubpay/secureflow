import { LoyaltyService } from "@/types";

export const serviceVendorConfigKeys = {
  [LoyaltyService.Como]: "comoV2Enabled",
  [LoyaltyService.Tickit]: "tickitEnabled"
};
