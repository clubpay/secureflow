export * from "./auth";
export * from "./config";
export * from "./defaults";
export * from "./regexes";

export const isRunningTests = process?.env?.VITEST_POOL_ID ? true : false;

export const lockGatewayID = "0000";
