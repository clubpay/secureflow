export const sessionAccessToken = "qlub.loyalty.access_token";
export const sessionRefreshToken = "qlub.loyalty.refresh_token";
export const sessionCollectedNumber = "qlub.loyalty.collected_number";
export const sessionCollectedNumberValidity = `${sessionCollectedNumber}.validity`;

export const hdrLoyaltyAuth = "Qlub-Loyalty-Auth";

export const sessionLoginKey = (service: string) => `qlub.loyalty.${service}.authenticated`;

export const CUID = "loyalty_cuid";
