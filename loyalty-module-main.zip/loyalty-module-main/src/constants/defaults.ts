export const defaults = {
  country: "ae",
  currency: {
    symbol: "AED",
    precision: 2
  }
};
