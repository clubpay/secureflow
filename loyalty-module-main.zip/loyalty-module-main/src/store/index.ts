import { resetAuthStore } from "./auth";
import { resetCheckoutStore } from "./checkout";
import { resetEarnStore } from "./earn";
import { resetGlobalStore } from "./global";
import { resetOfferStore } from "./offer";
import { resetSubscriptionStore } from "./subscription";
import { resetWalletStore } from "./wallet";

export const resetStores = () => {
  resetAuthStore();
  resetCheckoutStore();
  resetEarnStore();
  resetGlobalStore();
  resetOfferStore();
  resetSubscriptionStore();
  resetWalletStore();
};
