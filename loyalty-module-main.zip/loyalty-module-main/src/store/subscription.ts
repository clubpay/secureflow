import { StateCreator, create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { devtools } from "zustand/middleware";

interface SubscriptionSlice {
  optedForSubscription: boolean;
  savingsPopupDisplayed: boolean;
  joinPopupDisplayed: boolean;
  setOptedForSubscription: (value: boolean) => void;
  setSavingsPopupDisplayed: (value: boolean) => void;
  setJoinPopupDisplayed: (value: boolean) => void;
}

const createSubscriptionSlice: StateCreator<SubscriptionSlice> = (set) => ({
  optedForSubscription: false,
  savingsPopupDisplayed: false,
  joinPopupDisplayed: false,
  setOptedForSubscription: (value) => set({ optedForSubscription: value }),
  setSavingsPopupDisplayed: (value) => set({ savingsPopupDisplayed: value }),
  setJoinPopupDisplayed: (value) => set({ joinPopupDisplayed: value })
});

export const useSubscriptionStore = create<SubscriptionSlice>()(
  persist(devtools(createSubscriptionSlice), {
    name: "subscription-store",
    storage: createJSONStorage(() => sessionStorage)
  })
);

const initialState = useSubscriptionStore.getState();

export const resetSubscriptionStore = () => useSubscriptionStore.setState(initialState);
