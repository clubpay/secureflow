import { StateCreator, create } from "zustand";
import { devtools } from "zustand/middleware";
import { serviceDefaults } from "@/utils";

interface CheckoutSlice {
  sheetOpen: Record<string, boolean>;
  openSheet: (service: string, value: boolean) => void;
  points: Record<string, number | undefined>;
  setPoints: (service: string, value: any) => void;
  maxRedeemablePoints: Record<string, number | undefined>;
  setMaxRedeemablePoints: (service: string, value: any) => void;
  maxRedeemablePointsIgnoringBalance: Record<string, number | undefined>;
  setMaxRedeemablePointsIgnoringBalance: (service: string, value: any) => void;
  error: Record<string, string>;
  setError: (service: string, value: string) => void;
  insufficientBalanceRecorded: Record<string, boolean>;
  setInsufficientBalanceRecorded: (service: string, value: boolean) => void;
  isTimeExceeded: Record<string, boolean>;
  setIsTimeExceeded: (service: string, value: boolean) => void;
}

const createCheckoutSlice: StateCreator<CheckoutSlice> = (set) => ({
  sheetOpen: serviceDefaults(false),
  points: serviceDefaults(undefined),
  error: serviceDefaults(""),
  insufficientBalanceRecorded: serviceDefaults(false),
  openSheet: (service, value) => set((state) => ({ sheetOpen: { ...state.sheetOpen, [service]: value } })),
  setPoints: (service, value) => set((state) => ({ points: { ...state.points, [service]: value } })),
  maxRedeemablePoints: serviceDefaults(undefined),
  setMaxRedeemablePoints: (service, value) =>
    set((state) => ({ maxRedeemablePoints: { ...state.maxRedeemablePoints, [service]: value } })),
  maxRedeemablePointsIgnoringBalance: serviceDefaults(undefined),
  setMaxRedeemablePointsIgnoringBalance: (service, value) =>
    set((state) => ({
      maxRedeemablePointsIgnoringBalance: { ...state.maxRedeemablePointsIgnoringBalance, [service]: value }
    })),
  setError: (service, value) => set((state) => ({ error: { ...state.error, [service]: value } })),
  setInsufficientBalanceRecorded: (service, value) =>
    set((state) => ({ insufficientBalanceRecorded: { ...state.insufficientBalanceRecorded, [service]: value } })),
  isTimeExceeded: serviceDefaults(false),
  setIsTimeExceeded: (service, value) =>
    set((state) => ({ isTimeExceeded: { ...state.isTimeExceeded, [service]: value } }))
});

export const useCheckoutStore = create<CheckoutSlice>()(devtools(createCheckoutSlice));

const initialState = useCheckoutStore.getState();

export const resetCheckoutStore = () => useCheckoutStore.setState(initialState);
