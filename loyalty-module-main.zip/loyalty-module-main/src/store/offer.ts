import { StateCreator, create } from "zustand";
import { createJSONStorage, devtools, persist } from "zustand/middleware";
import { IOffer } from "@/types";
import { serviceDefaults } from "@/utils";
import { qlubSessionStorage } from "@clubpay/customer-common-module/src/service/storage/sessionStorage";

interface OfferSlice {
  sheetOpen: Record<string, boolean>;
  detailSheetOpen: Record<string, boolean>;
  selectorSheetOpen: Record<string, boolean>;
  selectedOffer?: Record<string, IOffer>;
  combinedOfferName: Record<string, string | undefined>;
  congratulated: Record<string, boolean>;
  alertedNoOffers: Record<string, boolean>;
  openSheet: (service: string, open: boolean) => void;
  openDetailSheet: (service: string, open: boolean) => void;
  openSelectorSheet: (service: string, open: boolean) => void;
  setSelectedOffer: (service: string, offer: IOffer) => void;
  setCombinedOfferName: (service: string, name: string | undefined) => void;
  setCongratulated: (service: string, congratulated: boolean) => void;
  setAlertedNoOffers: (service: string, alerted: boolean) => void;
}

const createOfferSlice: StateCreator<OfferSlice> = (set) => ({
  sheetOpen: serviceDefaults(false),
  detailSheetOpen: serviceDefaults(false),
  selectorSheetOpen: serviceDefaults(false),
  selectedOffer: serviceDefaults(undefined),
  combinedOfferName: serviceDefaults(undefined),
  congratulated: serviceDefaults(false),
  alertedNoOffers: serviceDefaults(false),
  openSheet: (service, value) => set((state) => ({ sheetOpen: { ...state.sheetOpen, [service]: value } })),
  openDetailSheet: (service, value) =>
    set((state) => ({ detailSheetOpen: { ...state.detailSheetOpen, [service]: value } })),
  openSelectorSheet: (service, value) =>
    set((state) => ({ selectorSheetOpen: { ...state.selectorSheetOpen, [service]: value } })),
  setSelectedOffer: (service, value) =>
    set((state) => ({ selectedOffer: { ...state.selectedOffer, [service]: value } })),
  setCombinedOfferName: (service, value) =>
    set((state) => ({ combinedOfferName: { ...state.combinedOfferName, [service]: value } })),
  setCongratulated: (service, value) =>
    set((state) => ({ congratulated: { ...state.congratulated, [service]: value } })),
  setAlertedNoOffers: (service, value) =>
    set((state) => ({ alertedNoOffers: { ...state.alertedNoOffers, [service]: value } }))
});

export const useOfferStore = create<OfferSlice>()(
  devtools(
    persist(createOfferSlice, {
      name: "loyalty-offer-store",
      partialize: (state) => ({ congratulated: state.congratulated }),
      storage: createJSONStorage(() => ({
        getItem: (name) => qlubSessionStorage.get(name),
        setItem: (name, value) => qlubSessionStorage.set(name, value),
        removeItem: (name) => qlubSessionStorage.remove(name)
      }))
    })
  )
);

const initialState = useOfferStore.getState();

export const resetOfferStore = () => useOfferStore.setState(initialState);
