import { StateCreator, create } from "zustand";
import { devtools } from "zustand/middleware";

interface WalletSlice {
  functionSheetOpen: boolean;
  openFunctionSheet: (value: boolean) => void;
}

const createWalletSlice: StateCreator<WalletSlice> = (set) => ({
  functionSheetOpen: false,
  openFunctionSheet: (value) => set({ functionSheetOpen: value })
});

export const useWalletStore = create<WalletSlice>()(devtools(createWalletSlice));

const initialState = useWalletStore.getState();

export const resetWalletStore = () => useWalletStore.setState(initialState);
