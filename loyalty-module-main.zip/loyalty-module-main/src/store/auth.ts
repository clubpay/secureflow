import { StateCreator, create } from "zustand";
import { devtools } from "zustand/middleware";
import { sessionCollectedNumber, sessionCollectedNumberValidity } from "@/constants";
import { IAccountBalance, IProfileDetails, IQlubProfile, LoyaltyService } from "@/types";
import { serviceDefaults } from "@/utils";
import { qlubSessionStorage } from "@clubpay/customer-common-module/src/service/storage/sessionStorage";

export const authSessionKey = "qlub.loyalty.user";

const serviceCollectedMobileNumbers = (() => {
  if (typeof window === "undefined") return {};
  const state = Object.entries(qlubSessionStorage.getAll()).reduce((acc, [key, value]) => {
    if (key.startsWith(sessionCollectedNumber)) {
      acc[key.split(".").pop()!] = value;
    }
    return acc;
  }, {} as any);
  state[LoyaltyService.Como] ??= "";
  return state;
})();

const serviceCollectedMobileNumbersValidity = (() => {
  if (typeof window === "undefined") return {};
  const state = Object.entries(qlubSessionStorage.getAll()).reduce((acc, [key, value]) => {
    if (key.startsWith(sessionCollectedNumberValidity)) {
      acc[key.split(".").pop()!] = value === "valid";
    }
    return acc;
  }, {} as any);
  state[LoyaltyService.Como] ??= process?.env?.VITEST_POOL_ID ? true : false;
  return state;
})();

interface AuthSlice {
  otp: Record<string, string>;
  mobileNumber: Record<string, string>;
  user: Record<string, IProfileDetails | undefined>;
  qlubUser: IQlubProfile | undefined;
  isCompact: Record<string, boolean>;
  loginMeta: Record<string, Record<string, any> | undefined>;
  loginSheetOpen: Record<string, boolean>;
  verificationSheetOpen: Record<string, boolean>;
  welcomeSheetOpen: Record<string, boolean>;
  registrationSheetOpen: Record<string, boolean>;
  isNewUser: Record<string, boolean>;
  isAgreedOnTerms: Record<string, boolean>;
  loginPromptEnabled: Record<string, boolean>;
  loginSheetPrompted: Record<string, boolean>;
  isMobileNumberValid: Record<string, boolean>;
  loginVerificationCallback: Record<string, () => void>;
  automatedLoginInProgress: Record<string, boolean>;
  setOTP: (service: string, value: string) => void;
  setMobileNumber: (service: string, value: string) => void;
  setUser: (service: string, value: IProfileDetails | undefined, refreshTimestamp?: boolean) => void;
  setQlubUser: (value: IQlubProfile | undefined) => void;
  setAccountBalance: (service: string, balance: IAccountBalance) => void;
  openLoginSheet: (service: string, value: boolean, isCompact?: boolean, meta?: Record<string, any>) => void;
  openVerificationSheet: (service: string, value: boolean) => void;
  openWelcomeSheet: (service: string, value: boolean) => void;
  openRegistrationSheet: (service: string, value: boolean) => void;
  setIsNewUser: (service: string, value: boolean) => void;
  toggleAgreedOnTerms: (service: string, value: boolean) => void;
  setLoginPromptEnabled: (service: string, value: boolean) => void;
  setLoginSheetPrompted: (service: string, value: boolean) => void;
  setIsMobileNumberValid: (service: string, value: boolean, clearSession?: boolean) => void;
  setLoginVerificationCallback: (service: string, value: () => Promise<void>) => void;
  setAutomatedLoginInProgress: (service: string, value: boolean) => void;
}

const createAuthSlice: StateCreator<AuthSlice> = (set) => ({
  otp: serviceDefaults(""),
  mobileNumber: serviceCollectedMobileNumbers,
  user: serviceDefaults(undefined),
  qlubUser: undefined,
  isCompact: serviceDefaults(false),
  loginMeta: serviceDefaults(undefined),
  loginSheetOpen: serviceDefaults(false),
  verificationSheetOpen: serviceDefaults(false),
  welcomeSheetOpen: serviceDefaults(false),
  registrationSheetOpen: serviceDefaults(false),
  isNewUser: serviceDefaults(false),
  isAgreedOnTerms: serviceDefaults(false),
  loginPromptEnabled: serviceDefaults(false),
  loginSheetPrompted: serviceDefaults(false),
  isMobileNumberValid: serviceCollectedMobileNumbersValidity,
  loginVerificationCallback: serviceDefaults(undefined),
  automatedLoginInProgress: serviceDefaults(false),
  setOTP: (service, value) => set((state) => ({ otp: { ...state.otp, [service]: value } })),
  setMobileNumber: (service, value) => {
    set((state) => ({ mobileNumber: { ...state.mobileNumber, [service]: value } }));
    if (!value) sessionStorage.removeItem(`${sessionCollectedNumber}.${service}`);
  },
  setUser: (service, value) => {
    const payload = { user: value } as any;
    set((state) => ({ user: { ...state.user, [service]: payload.user } }));
  },
  setQlubUser: (value) => set({ qlubUser: value }),
  setAccountBalance: (service, value) =>
    set((state: any) => ({
      user: {
        ...state.user,
        [service]: state.user?.[service] ? { ...state.user[service], accountBalance: value } : undefined
      }
    })),
  openLoginSheet: (service, value, isCompact, meta) =>
    set((state) => ({
      loginSheetOpen: { ...state.loginSheetOpen, [service]: value },
      ...(isCompact !== undefined ? { isCompact: { ...state.isCompact, [service]: isCompact } } : {}),
      ...(meta !== undefined ? { loginMeta: { ...state.loginMeta, [service]: meta } } : {})
    })),
  openVerificationSheet: (service, value) =>
    set((state) => ({
      verificationSheetOpen: { ...state.verificationSheetOpen, [service]: value },
      ...(!value
        ? {
            isCompact: { ...state.isCompact, [service]: false },
            loginMeta: { ...state.loginMeta, [service]: undefined }
          }
        : {})
    })),
  openWelcomeSheet: (service, value) =>
    set((state) => ({ welcomeSheetOpen: { ...state.welcomeSheetOpen, [service]: value } })),
  openRegistrationSheet: (service, value) =>
    set((state) => ({ registrationSheetOpen: { ...state.registrationSheetOpen, [service]: value } })),
  setIsNewUser: (service, value) => set((state) => ({ isNewUser: { ...state.isNewUser, [service]: value } })),
  toggleAgreedOnTerms: (service, value) =>
    set((state) => ({ isAgreedOnTerms: { ...state.isAgreedOnTerms, [service]: value } })),
  setLoginPromptEnabled: (service, value) =>
    set((state) => ({ loginPromptEnabled: { ...state.loginPromptEnabled, [service]: value } })),
  setLoginSheetPrompted: (service, value) =>
    set((state) => ({ loginSheetPrompted: { ...state.loginSheetPrompted, [service]: value } })),
  setIsMobileNumberValid: (service, value, clearSession = true) => {
    set((state) => ({ isMobileNumberValid: { ...state.isMobileNumberValid, [service]: value } }));
    if (!value && clearSession) sessionStorage.removeItem(`${sessionCollectedNumberValidity}.${service}`);
  },
  setLoginVerificationCallback: (service, value) =>
    set((state) => ({ loginVerificationCallback: { ...state.loginVerificationCallback, [service]: value } })),
  setAutomatedLoginInProgress: (service, value) =>
    set((state) => ({ automatedLoginInProgress: { ...state.automatedLoginInProgress, [service]: value } }))
});

export const useAuthStore = create<AuthSlice>()(devtools(createAuthSlice));

const initialState = useAuthStore.getState();

export const resetAuthStore = () => useAuthStore.setState(initialState);
