import { StateCreator, create } from "zustand";
import { devtools } from "zustand/middleware";

interface EarnSlice {
  pointsEarned: Record<string, boolean>;
  setPointsEarned: (service: string, value: boolean) => void;
  guestGreetingPopupOpen: boolean;
  toggleGuestGreetingPopup: (value: boolean) => void;
}

const createEarnSlice: StateCreator<EarnSlice> = (set) => ({
  pointsEarned: {},
  setPointsEarned: (service, value) => {
    set((state) => ({
      pointsEarned: {
        ...state.pointsEarned,
        [service]: value
      }
    }));
  },
  guestGreetingPopupOpen: false,
  toggleGuestGreetingPopup: (value) => set({ guestGreetingPopupOpen: value })
});

export const useEarnStore = create<EarnSlice>()(devtools(createEarnSlice));

const initialState = useEarnStore.getState();

export const resetEarnStore = () => useEarnStore.setState(initialState);
