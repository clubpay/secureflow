import { StateCreator, create } from "zustand";
import { devtools } from "zustand/middleware";
import { IPaymentDetails } from "@/types";
import { ILoyaltyProgram } from "@/types/entities/program";
import { PopupSlice, createPopupSlice } from "./popup";

export interface GlobalSlice {
  locale: string;
  selectedProgram: ILoyaltyProgram;
  paymentDetails: IPaymentDetails;
  paymentDetailsLoading: boolean;
  setLocale: (locale: string) => void;
  setSelectedProgram: (program: ILoyaltyProgram) => void;
  setPaymentDetails: (paymentDetails: IPaymentDetails) => void;
  setPaymentDetailsLoading: (loading: boolean) => void;
}

export const createGlobalSlice: StateCreator<GlobalSlice> = (set) => ({
  locale: "en",
  selectedProgram: { config: {} } as any,
  paymentDetails: {} as any,
  paymentDetailsLoading: false,
  setLocale: (locale) => {
    set({ locale: locale });
  },
  setSelectedProgram: (program) => {
    set({ selectedProgram: program });
  },
  setPaymentDetails: (paymentDetails) => {
    set({ paymentDetails: paymentDetails });
  },
  setPaymentDetailsLoading: (loading) => {
    set({ paymentDetailsLoading: loading });
  }
});

export const useGlobalStore = create<GlobalSlice & PopupSlice>()(
  devtools((...a) => ({
    ...createGlobalSlice(...a),
    ...createPopupSlice(...a)
  }))
);

const initialState = useGlobalStore.getState();

export const resetGlobalStore = () => useGlobalStore.setState(initialState);
