import { ReactNode } from "react";
import { StateCreator } from "zustand";
import { PopupVariant } from "@/types";

type OpenArgs = {
  variant?: PopupVariant;
  title?: string;
  subtitle?: string | ReactNode;
  buttonText?: string | ReactNode;
  buttonArrow?: boolean;
  autoCloseDuration?: number;
  actionClickHandler?: () => void;
};

export interface PopupSlice {
  popup: {
    open: boolean;
    title: string;
    subtitle?: string | ReactNode;
    buttonText?: string | ReactNode;
    buttonArrow?: boolean;
    variant: PopupVariant;
    actionClickHandler?: () => void;
    openPopup: (args: OpenArgs) => void;
    closePopup: () => void;
  };
}

export const createPopupSlice: StateCreator<PopupSlice> = (set, get) => ({
  popup: {
    open: false,
    title: "",
    subtitle: "",
    buttonText: "",
    buttonArrow: false,
    variant: PopupVariant.Success,
    actionClickHandler: () => {},
    openPopup: ({ variant = PopupVariant.Success, ...args }: OpenArgs) => {
      if (variant !== PopupVariant.Success && variant !== PopupVariant.Congratulations)
        return console.warn("Unsupported variant");
      set({
        popup: {
          ...get().popup,
          open: true,
          title: args?.title ?? "",
          subtitle: args?.subtitle ?? "",
          buttonText: args?.buttonText ?? "",
          buttonArrow: args?.buttonArrow ?? false,
          actionClickHandler: args?.actionClickHandler ?? (() => {}),
          variant: variant
        }
      });
      if (args?.autoCloseDuration)
        setTimeout(
          () =>
            set({
              popup: {
                ...get().popup,
                open: false
              }
            }),
          args.autoCloseDuration
        );
    },
    closePopup: () => {
      set({
        popup: {
          ...get().popup,
          open: false
        }
      });
    }
  }
});
