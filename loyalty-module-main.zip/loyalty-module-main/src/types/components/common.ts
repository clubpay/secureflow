import { CurrencyFormat } from "@qlub-dev/qlub-kit/dist/components/Format";
import { IProfileDetails } from "../api";

export interface IScheduleDate {
  enabled: boolean;
  times: {
    start: string;
    end: string;
  }[];
}

export interface ISchedule {
  monday: IScheduleDate;
  tuesday: IScheduleDate;
  wednesday: IScheduleDate;
  thursday: IScheduleDate;
  friday: IScheduleDate;
  saturday: IScheduleDate;
  sunday: IScheduleDate;
}

export interface LocalizedMapItem {
  key: string;
  value: string;
  image?: string;
}

export interface IRedemption {
  points?: number;
  amount?: number;
  pointIdentifier?: string;
  completed?: boolean;
}

export interface ILoginEventResponseAttributes {
  isNewUser?: boolean;
}

export interface IRedemptionEventAttributes {
  points?: number;
  maxRedeemablePoints?: number;
  maxRedeemablePointsIgnoringBalance?: number;
  maxRedeemableValue?: number;
}

export interface AuthEvents {
  onLogin?: (
    user: Partial<IProfileDetails>,
    trailingCall?: boolean
  ) => Promise<ILoginEventResponseAttributes> | Promise<any>;
  onLoginVerification?: (otp: string, user: Partial<IProfileDetails>) => Promise<any>;
  onRegister?: (data: Record<string, any>) => Promise<any>;
  onLogout?: () => Promise<any>;
}

export interface RedemptionEvents {
  onWalletOpen?: () => Promise<any> | void;
  onRedemptionTriggerVisible?: () => Promise<any> | void;
  onRedemption?: (redemption: IRedemptionEventAttributes) => Promise<any>;
  onRedemptionClick?: () => Promise<any> | void;
  onRedemptionConfirm?: () => Promise<any> | void;
  onRedemptionCancel?: () => Promise<any> | void;
  onInsufficientPoints?: () => Promise<any> | void;
  onRefresh?: () => Promise<any> | void;
}

export interface CommonEvents {
  onTriggerClick?: () => Promise<any>;
  onWelcome?: () => Promise<any>;
  onWelcomeSheetOpen?: () => Promise<any> | void;
  onSheetClose?: () => Promise<any> | void;
}

export interface IEvents extends AuthEvents, RedemptionEvents, CommonEvents {}

export interface IQlubMetaData {
  restaurantLogoUrl?: string;
  restaurantLogoAvatarUrl?: string;
}

export interface ICurrency {
  symbol: string;
  precision?: number;
}

export interface IGenericOptions {
  country?: string;
  currencyFormat: CurrencyFormat;
  meta?: IQlubMetaData;
}

export interface ISharedConfig {
  dsi?: string;
}

export interface ISharedRedemptionConfig extends ISharedConfig {
  // 1 point = ? value (burn)
  conversionRate?: number;
  ui?: {
    enableTriggerTopDivider?: boolean;
  };
  redemption?: IRedemption;
  events?: IEvents;
}

export interface ISharedOfferConfig extends ISharedConfig {
  events?: IEvents;
}
