import { Dispatch, SetStateAction } from "react";
import { ILoyaltyProgram } from "../entities/program";
import { IEvents, IGenericOptions, ISharedConfig, ISharedOfferConfig, ISharedRedemptionConfig } from "./common";

export * from "./common";
export * from "./popup";

export enum TriggerType {
  Offer = "offer",
  Redemption = "redemption"
}

export interface IBill {
  amount: number;
  commission: number;
  share: number;
  shareCommission?: number;
  remaining: number;
  tax: number;
  payments?: {
    regular?: number;
    loyalty?: number;
  };
  hasDiscounts?: boolean;
  hasLoyaltyDiscounts?: boolean;
}

export interface IAuthOptions extends IGenericOptions {
  config: ISharedConfig & {
    events?: IEvents;
  };
}

export interface IAuthContentOptions extends IAuthOptions {
  onBack: () => void;
  onContinue: (setError: Dispatch<SetStateAction<boolean>>, setLoading: Dispatch<SetStateAction<boolean>>) => void;
}

export interface IRedemptionOptions extends IGenericOptions {
  config: ISharedRedemptionConfig;
  bill: IBill;
  program: ILoyaltyProgram;
}

export interface IOfferOptions extends IGenericOptions {
  config: ISharedOfferConfig;
  bill: Partial<IBill>;
  program: ILoyaltyProgram;
}

export type ITriggerOptions = {
  type?: TriggerType;
} & (IRedemptionOptions | IOfferOptions);
