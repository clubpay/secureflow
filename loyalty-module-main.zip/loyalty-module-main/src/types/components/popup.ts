export enum PopupVariant {
  Success = "success",
  Congratulations = "congratulations",
  Error = "error",
  Warning = "warning",
  Info = "info"
}
