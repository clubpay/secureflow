import { IExternalAPI } from "@/types/api";

export interface IDriverProps {
  api?: IExternalAPI;
}
