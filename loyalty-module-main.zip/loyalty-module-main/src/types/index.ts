import { LoyaltyService } from "./entities";

export * from "./api";
export * from "./entities";
export * from "./components";

export enum Locales {
  English = "en",
  Arabic = "ar",
  Japanese = "ja",
  Portuguese = "pt",
  Turkish = "tr",
  Chinese = "zh",
  Spanish = "es",
  Russian = "ru"
}

export interface LazyComponentInventory {
  [key: LoyaltyService | string]: React.LazyExoticComponent<any>;
}

export interface KeyValue {
  [key: string]: any;
}

declare global {
  interface Window {
    clarity: (...args: any) => void;
  }
}
