export interface IGetLoyaltySubscriptionDiscountResponse {
  discountValue: number;
  discountType: string;
  discountName: string;
  posDiscountId: string;
  reference: string;
  loyaltyProgramId: string;
  loyaltyProgramType: string;
  loyaltyProgramName: string;
  isUserSubscribed: boolean;
  subscriptionId: number;
}
