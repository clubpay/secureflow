import { IRestaurant, SplitModeTypeEnum } from "@clubpay/customer-common-module/src/repository/vendor";
import { LoyaltyService } from "../entities";

export enum GatewayPaymentMethod {
  Unknown = "unknown",
  Card = "card",
  ApplePay = "apple_pay",
  GooglePay = "google_pay",
  StcPay = "stc_pay",
  SavedCard = "saved_card",
  Softpos = "softpos",
  Pix = "pix"
}

export enum GatewayVendor {
  Checkout = "checkout"
}

export enum BillStatusEnum {
  partiallyPaid = "partiallyPaid",
  fullyPaid = "fullyPaid"
}

export enum RecordStatusEnum {
  accepted = "accepted",
  pending = "pending",
  failed = "failed"
}

export enum AdditiveCategoryEnum {
  Tax = "tax",
  Discount = "discount",
  Fee = "fee",
  Sum = "sum",
  Commision = "com",
  Unknown = "unknown"
}

export interface IAdditiveView {
  key: string;
  amount: string;
  value: string;
  valueType: string;
  category: AdditiveCategoryEnum;
  title: string;
}

export interface IOrderItemView {
  qty: string;
  title: string;
  unitPrice: string;
  updatedAt: number;
  subTotal?: string;
  finalPrice?: string;
  finalUnitPrice?: string;
  additives?: Array<IAdditiveView>;
  sig: string;
}

export interface IPaymentParty {
  amount: string;
  id: string;
  name: string;
  paymentDone?: boolean;
  paidAt?: number;
  nonQlub?: boolean;
}

export interface IPaymentDetailsBill {
  id: string;
  qlubDiscount: string;
  qlubLoyaltyDiscount: string;
  paid: string;
  remaining: string;
  remainingCommission: string;
  optionalDinerFee?: string;
  subTotal: string;
  tax: string;
  total: string;
  vat: string;
  yourShare: string;
  yourCommission: string;
  additives?: Array<IAdditiveView>;
  billAmount?: string;
  payableAmount?: string;
  covers: number;
  updatedAt: string;
}

export interface IPaymentDetailsBillNumber {
  qlubDiscount: number;
  qlubLoyaltyDiscount: number;
  paid: number;
  remaining: number;
  subTotal: number;
  commission: number;
  tax: number;
  total: number;
  vat: number;
  yourShare: number;
  yourCommission: number;
  billAmount: number;
  payableAmount: number;
}

export interface ILoyalty {
  program: string;
  amount: number;
  points: number;
  pointName: string;
  confirmation: string;
  type?: LoyaltyService;
  status: string;
  isFullRedemption?: boolean;
}

export interface IPaymentDetailsLoyalty {
  tax: number;
  paid: number;
}

export interface IPartySplitUI {
  items?: Array<IItemToPay>;
  meta?: any;
  splitMode: SplitModeTypeEnum;
  share: number;
  totalShares: number;
}

export interface IPaymentPartyUI {
  amount: string;
  amountNumber: number;
  id: string;
  name: string;
  paymentDone?: boolean;
  paidAt?: number;
  nonQlub?: boolean;
  billSplit: IPartySplitUI;
  loyalty?: ILoyalty;
  customerID?: string;
}

export interface IKeyValue {
  key: string;
  value: any;
  order?: number;
  title?: string;
  id?: string;
  sig?: string;
}

export interface IKeyValueOrder extends IKeyValue {
  qty?: string;
  altValue?: string;
  secondAltValue?: string;
  updatedAt?: number;
  selectedItemsQty?: number;
  paidItemsQty?: number;
}

export interface IPaymentDetailsOrderItems {
  item: IKeyValueOrder;
  items: IKeyValueOrder[];
}

export interface IPaymentDetails {
  _orderItems: IPaymentDetailsOrderItems[];
  bill: IPaymentDetailsBill;
  billNumber: IPaymentDetailsBillNumber;
  billLoyalty: IPaymentDetailsLoyalty;
  restaurantUnique: string;
  tableID: string;
  parties?: IPaymentPartyUI[];
  currency: string;
  diningSessionID: string;
  currencyPrecision: number;
  tableName?: string;
  yourSplitSettings: IPaymentPartyUI;
  otherSplitSettings: IPaymentPartyUI;
  tablePreferredName?: string;
}

export interface IPaymentStatus {
  amount: string;
  currency: string;
  bill: {
    currency: string;
    orderID: string;
    remainingAmount: string;
    status: BillStatusEnum;
    tableID: string;
    tableName: string;
    totalAmount: string;
  };
  loyalty?: {
    redemptions?: ILoyalty[];
    earnings?: ILoyalty[];
  };
  record: {
    accepted: boolean;
    billAmount: string;
    createdAt: BigInt64Array;
    gatewayVendor: string;
    gatewayPaymentMethod?: GatewayPaymentMethod;
    reference: string;
    status: RecordStatusEnum;
    tipAmount: string;
    total: string;
  };
  verified: boolean;
}

export interface IGetLayoutConfig {
  cc: string;
  vendor?: IRestaurant;
}

export interface IItemToPay {
  id?: string;
  index: number;
  qty: string;
  sig: string;
}

export interface ISetAmountRequestPayload {
  amount?: string;
  diningSessionID: string;
  id: string;
  name: string;
  splitMode?: string;
  share?: number;
  totalShares?: number;
  items?: IItemToPay[];
  phoneNumber?: string;
  meta?: any;
}

export interface ISetAmountV2Response {
  paymentDetails: IPaymentDetails;
  error?: { items: string };
}

export interface IEmailReceiptRequestNewPayload {
  countryCode: string;
  diningSessionID: string;
  email?: string;
  phone?: string;
  id: string;
  lang: string;
  reference: string;
  timezone: string;
}

export interface IEmailReceiptResponse {
  status?: string;
  meta: { como: string };
  message: string;
}

export interface IExplodedItem {
  index: number;
  price: string;
  qty: string;
  sig: string;
}

export interface IPaymentSplit {
  availableModes: Array<SplitModeTypeEnum>;
  mode: SplitModeTypeEnum;
  totalShares: string;
  shareAmount: string;
}

export interface IVoucher {
  code: string;
  partyID: string;
  redeemed: boolean;
  isVoucherOwner?: boolean;
  amount?: string;
}

export interface IPaymentDetailsResponse {
  bill: IPaymentDetailsBill;
  billSplit: IPaymentSplit;
  currency: string;
  currencyPrecision: number;
  orderItems?: IOrderItemView[];
  parties?: IPaymentParty[];
  restaurantUnique: string;
  tableID: string;
  diningSessionID: string;
  tableName: string;
  jwt?: string;
  campaign: {
    appliedVouchers: IVoucher[];
  };
  explodedItems?: IExplodedItem[];
}
