import { type AxiosResponse } from "axios";
import { IProfile } from "@clubpay/customer-common-module/src/repository/auth/type";
import { ISubscriptionSchema } from "@clubpay/customer-common-module/src/repository/common/subscription/type";
import { IOffer, ITransaction, IVenue } from "../entities";
import { ILoyaltyProgram } from "../entities/program";
import {
  IEmailReceiptRequestNewPayload,
  IEmailReceiptResponse,
  IGetLayoutConfig,
  ISetAmountRequestPayload,
  ISetAmountV2Response
} from "./bill";

export * from "./bill";
export * from "./subscription";

export interface IAccountBalance {
  monetary: number;
  nonMonetary: number;
}

export interface IProfileDetails {
  id: string;
  name: string;
  email: string;
  phoneNumber: string;
  status: string;
  createdOn: string;
  tier?: string;
  accountNumber: string;
  accountBalance: IAccountBalance;
  conversionRate: number;
  isAuthorized?: boolean;
  pointsSpent?: number;
  pointsEarned?: number;
  expiringPoints?: number;
  firstName?: string;
  lastName?: string;
  gender?: string;
  birthday?: string;
  discountSavings?: number;
}

export interface IQlubProfile extends IProfile {
  hasSubscription(subscription: ISubscriptionSchema): boolean;
}

export interface IRedeemRequest {
  amount: string;
  points: string;
  pointIdentifier: string;
}

export interface ILoginResponse {
  isNewUser: boolean;
  tokens: {
    accessToken: string;
    refreshToken: string;
  };
  otpId?: string;
}

export interface IVerifyResponse {
  profile: IProfileDetails;
  tokens: {
    accessToken: string;
    refreshToken: string;
  };
}

export interface IProfileResponse {
  profile: IProfileDetails;
}

export interface IRedeemResponse {
  confirmation: string;
  accountBalance: IAccountBalance;
}

export interface IEarnResponse {
  confirmation?: string;
}

export interface IGetOffersResponse {
  offers: IOffer[];
  combinedOfferName?: string;
}

export interface IApplyOffersResponse {
  appliedOffers: IOffer[];
}

export type IRestaurantLoyaltyProgramsResponse = {
  programs: ILoyaltyProgram[];
};

export interface IExternalAPI {
  bill?: {
    setAmount: (
      payload: ISetAmountRequestPayload,
      config?: IGetLayoutConfig,
      axiosConfig?: Record<string, any>
    ) => Promise<ISetAmountV2Response>;
    emailReceiptV2: (payload: IEmailReceiptRequestNewPayload) => Promise<AxiosResponse<IEmailReceiptResponse>>;
    [key: string]: (...args: any[]) => Promise<any>;
  };
}

export type IProgramVenuesResponse = {
  rows: IVenue[];
  count: number;
};

export type ICustomerTransactionsResponse = {
  transfers: ITransaction[];
  count: number;
};

export interface IRegisterResponse {
  profile: IProfileDetails;
}
