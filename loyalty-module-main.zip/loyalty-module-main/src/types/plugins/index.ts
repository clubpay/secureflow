export interface ISnackBar {
  _isNative?: boolean;
  enqueue: (message: string, options?: any) => void;
  close: (key?: any) => void;
}
