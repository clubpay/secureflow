import { IBaseConfig } from ".";

export interface IComoConfig extends IBaseConfig {}
