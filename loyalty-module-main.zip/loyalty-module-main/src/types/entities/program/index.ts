import { ISchedule, LocalizedMapItem } from "@/types/components";
import { ISubscriptionSchema } from "@clubpay/customer-common-module/src/repository/common/subscription/type";
import { IDiscount, LoyaltyService } from "../";

export * from "./como";
export * from "./rotana";

export enum LoyaltyVisibilityStatus {
  Show = "Show",
  Hide = "Hide"
}

export interface IBaseConfigOptions {
  readableDisplayName?: string;
  readablePointIdentifier?: string;
  localizedLoginBanner?: string;
  freezeRegionalLogin?: boolean;
  forceMobileInputLTR?: boolean;
  showEarnNote?: boolean;
  enableRegistrationFlow?: boolean;
  registrationFields?: string[];
  requiredRegistrationFields?: string[];
  registrationTermsLink?: string;
  automatedLogin?: boolean;
  redemptionConfirmationPopup?: boolean;
  enableLoginPrompt?: boolean;
  enableLoginVerificationPrompt?: boolean;
  displayOfferSelectorSheet?: boolean;
  disableAutomatedOfferFetch?: boolean;
  hideOfferTrigger?: boolean;
  disregardStepForFullRedemption?: boolean;
  disableFractionalRedemption?: boolean;
  isDiscountEnabled?: boolean;
  limitSingleLoyaltyDiscount?: boolean;
  limitSingleRedemptionPerCustomer?: boolean;
  apiVersion?: number;
}

export interface IBaseConfig extends IBaseConfigOptions {
  displayName?: string;
  pointIdentifier?: string;
  isEarnEnabled: boolean;
  isBurnEnabled: boolean;
  enableEarnWithoutLogin?: boolean;
  minPointsPerTransaction?: number;
  maxPointsPerTransaction?: number;
  redeemableAdditives?: string[];
  redeemableBillPercentage?: number;
  minimumRedeemableBillPercentage?: number;
  redeemablePointStep?: number;
  useToggle?: boolean;
  logo?: string;
  loginBanner?: string;
  burnPermittedScheduleText?: string;
  burnPermittedSchedule?: ISchedule;
  disableRedemptionIfDiscountAvailable?: boolean;
  displayMenuSheet?: boolean;
  isLegacy?: boolean;
  earnWidgetPopup?: boolean;
  earnWidgetTitle?: string;
  earnWidgetDescription?: string;
  showQlubAppDownloadLink?: boolean;
  qlubAppAppStoreURL?: string;
  qlubAppPlayStoreURL?: string;
  qlubPlusAppStoreSecurePointsURL?: string;
  qlubPlusPlayStoreSecurePointsURL?: string;
  showSubscriptionFreeMonths?: boolean;
}

export interface IQlubConfig extends IBaseConfig {
  earnPointConversionRate: number;
  burnPointConversionRate: number;
  pointExpiryDuration?: number;
  showExpiryNotificationOnLanding?: boolean;
  useToggle?: boolean;
  onlyBurnEnabledInVenues?: boolean;
  showWalletInLanding?: LoyaltyVisibilityStatus;
  showSecurePoints?: LoyaltyVisibilityStatus;
  loyaltyBenefits?: LocalizedMapItem[];
  howItWorks?: LocalizedMapItem[];
  displayLoyaltyBenefits?: boolean;
  discountTeaserText?: string;
  discountTeaserValue?: string;
  subscriptionCompletionPrompt?: string;
  readableDiscountTeaserText?: string;
  readableDiscountTeaserValue?: string;
  readableSubscriptionCompletionPrompt?: string;
  cancelSubscriptionReasons?: LocalizedMapItem[];
}

export type ILoyaltyProgram<T = Record<string, any>> = {
  id: string;
  sequentialId: number;
  name: string;
  type: LoyaltyService;
  internalProgramType?: InternalProgramType;
  config: IBaseConfig & Record<string, any> & T;
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
  discounts?: IDiscount[];
  subscription?: ISubscriptionSchema;
};

export enum InternalProgramType {
  IN_EARN_BURN = "internal-earn-burn",
  IN_SUB_DISCOUNT = "internal-subscription-discount",
  IN_NONE = "internal-none"
}
