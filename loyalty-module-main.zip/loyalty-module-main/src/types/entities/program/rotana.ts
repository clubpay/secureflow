import { IBaseConfig } from ".";

export interface IRotanaConfig extends IBaseConfig {}
