export interface ITransaction {
  id: number;
  ledgerID: number;
  title: string;
  debitAccountID: number;
  debitBalance: number;
  creditAccountID: number;
  creditBalance: number;
  amount: number;
  details: {
    service: string;
    refDocID: string;
    funnel: string;
    type: string;
    info: {
      amount: number;
      programID: string;
      currency: string;
    };
    meta: {
      partyId: string;
      restaurantName: string;
      tableSessionID: number;
      expiresAt?: string;
    };
  };
  createdAt: number;
  documentCreatedAt: number;
  paymentRecordDetails: {
    status: string;
    billAmount: number;
    tipAmount: number;
    leftToPay: number;
    lastUpdatedAt: number;
  };
}
