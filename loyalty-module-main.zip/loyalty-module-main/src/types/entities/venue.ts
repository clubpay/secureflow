import { ISubscriptionSchema } from "@clubpay/customer-common-module/src/repository/common/subscription/type";
import { OrderModeEnum } from "@clubpay/customer-common-module/src/repository/vendor";
import { ICurrency } from "../components";
import { IDiscount } from "./discount";
import { IQlubConfig, InternalProgramType } from "./program";

export interface IVenue {
  name: string;
  title: string;
  country: {
    code: string;
  };
  currency: ICurrency;
  city: string;
  code: string;
  address1: string;
  address2: string;
  email: string;
  logoBigUrl: string;
  logoSmallUrl: string;
  photoUrl: string;
  earnEnabled: boolean;
  burnEnabled: boolean;
  reviewRating: number;
  googlePlaceId?: string;
  directionsUrl?: string;
  menuUrl?: string;
  config: IQlubConfig;
  orderMode?: OrderModeEnum;
  hideViewMenuButton?: boolean;
  discounts?: IDiscount[];
  subscription?: ISubscriptionSchema;
  internalProgramType?: InternalProgramType;
}
