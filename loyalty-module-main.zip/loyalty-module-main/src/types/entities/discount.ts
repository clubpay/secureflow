import { LoyaltyService } from ".";
import { ISchedule } from "../components";

export enum DiscountValueType {
  PERCENTAGE = "PERCENTAGE"
}

export interface IDiscountConfig {
  schedule: ISchedule;
}

export interface IDiscount {
  id: number;
  uniqueID: string;
  title: string;
  programID: string;
  valueType: DiscountValueType;
  amount: number;
  config: IDiscountConfig;
  discountMinimumValue: number;
  discountMaximumValue: number;
  minimumBillAmount: number;
  maximumBillAmount: number;
  enabled: boolean;
}

export interface IAppliedDiscount {
  discountID: number;
  amount: number;
  discountType: string;
  program: string;
  type: LoyaltyService;
}
