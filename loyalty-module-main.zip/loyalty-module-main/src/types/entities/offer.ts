export enum OfferType {
  Discount = "discount"
}

export interface IOffer {
  id: string;
  name: string;
  description?: string;
  type: OfferType;
  percentage?: boolean;
  value?: number;
  applied?: boolean;
  autoApplicable?: boolean;
  reusable?: boolean;
  expiration?: string;
}
