# Qlub Loyalty UI Kit

This library contains all Loyalty Web UI components that can be used across Web projects in Qlub

## Usage

Run `yarn add @clubpay/loyalty` with appropriate authentication to incorporate into your project <br/> <br/>

**Please refer the following storybooks for examples on how to use the module**

- [Production Storybook](https://loyalty-storybook.teleport.qlub.cloud)
- [Dev Storybook](https://loyalty-storybook-dev6.teleport.qlub.cloud) (This is not stable and may change frequently)

## Development Setup

- Install the [Bun](https://bun.sh/docs/installation) runtime. It is recommended to **use 1.0.20** to avoid any issues with the current setup.
- Create a file named `.env` at the root of your project with the following content

```
REGISTRY_ACCESS_TOKEN={{access_token}}
```

- The access token is a GitHub personal access token with the `read:packages` scope and optionally `write:packages` if you want to publish packages from your local environment which generally is not recommended.

## Useful commands

- Run `bun install` to install all dependencies
- Run `bun storybook` to start the storybooks dev server
- Run `bun build-storybook` to build the project for a web release
- Run `bun run build` to build the project for a package release
- Run `bun test` to run tests with coverage

## Commit messages

- We follow conventional commits during our development workflow as a good practice. More information can be found at their official [documentation](https://www.conventionalcommits.org/en/v1.0.0-beta.4/#examples)

## Additional tools

- This project is bootstrapped with [Lefthook](https://evilmartians.com/opensource/lefthook), [Eslint](https://eslint.org/) and [Prettier](https://prettier.io/). Please make good use of them.
