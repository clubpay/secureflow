import { default as path } from "path";
import type { StorybookConfig } from "@storybook/nextjs";

const config: StorybookConfig = {
  stories: ["../src/**/*.mdx", "../src/**/*.stories.@(js|jsx|mjs|ts|tsx)"],
  addons: [
    "@storybook/addon-links",
    "@storybook/addon-essentials",
    "@storybook/addon-interactions",
    "storybook-addon-deep-controls"
  ],
  docs: {
    autodocs: "tag"
  },
  staticDirs: ["./public"],
  framework: {
    name: "@storybook/nextjs",
    options: {}
  },
  async webpackFinal(config) {
    config.module = {
      ...config.module,
      rules: [
        ...(config.module?.rules || []),
        {
          test: /\.scss$/,
          use: [
            {
              loader: "sass-loader",
              options: {
                additionalData: `@import "@/styles/index.scss";`
              }
            }
          ],
          include: path.resolve(__dirname, "../src")
        },
        {
          test: /\.(ts|tsx)$/,
          include: [
            path.resolve(__dirname, "../src"),
            path.resolve(__dirname, "../node_modules/@clubpay/customer-common-module")
          ],
          use: [
            {
              loader: "ts-loader",
              options: {
                transpileOnly: true
              }
            }
          ]
        }
      ]
    };
    config.resolve = {
      ...config.resolve,
      alias: {
        ...config.resolve?.alias,
        "@/": `${path.resolve(__dirname, "../src")}/`
      }
    };
    return config;
  }
};
export default config;
