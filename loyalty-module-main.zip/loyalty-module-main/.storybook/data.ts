export const vendor: any = {
  address1: "dubai 1 ",
  address2: "dubai 2",
  area: "Dubai",
  backgroundUrl: "",
  brand: {
    config: {},
    id: "337",
    name: "Qlub Loyalty"
  },
  city: "Dubai",
  config: {},
  country: {
    code: "ae",
    config: {
      contactUsWhatsAppNumber: "+905428417440",
      customerAppBlackMode: ["ae|narges-test"],
      defaultLang: "en",
      dinerFeeVisibility: ["hideDashboard"],
      displayCodeBoxBrands: ["12", "210", "178"],
      emailTermsAndConditions: "show",
      emailTermsAndConditionsV4: false,
      enableSSOLogin: "disable",
      enableUserProfile: "disable",
      enableUserProfileByBrand: ["338", "337"],
      enabledPaymentLinkScheduler: true,
      isGoogleCurrencyFormatEnabled: true,
      mailTemplate: "v2",
      newAppCondition: "new",
      newAppConditionVendors: ["au|doshii-demo", "sa|sasan-foodics", "ae|sasan-release"],
      newAppHost: "newapp-staging.qlub.cloud",
      orderSummary: "hide",
      paymentLinkEmailRequestCron: "0 0 5 * * *",
      qlubAddress: "الرياض،الرياض،آل عساكر ، 12471",
      qlubBusinessName: "شركة التوصيل الأسهل المحدوده",
      qlubRegistrationNumber: "1010583691",
      qlubVatNumber: "310387776800003",
      showArea: false,
      showDinerFeeTooltip: "show",
      showGst: false,
      showTax: true,
      showTip: true,
      showVat: true,
      splashEnable: false,
      splitMode: "",
      tipGamificationMode: "gamificationOn",
      tipModalHideNotNow: false,
      tipModalWithPayment: true,
      tipMode: "fixedWithHint",
      tipOptions: [5, 10, 15, -1, 0],
      vatAmount: "10",
      voucherHasActiveCampaign: true
    },
    currencyCode: "aed",
    currencySymbol: "AED",
    isoCode: "are",
    languageCode: "en",
    name: "United Arab Emirates",
    phonePrefix: "+971"
  },
  discount: null,
  email: "mahesh@qlub.io",
  externalMenuFormat: null,
  externalMenuUrl: "",
  googlePlaceId: null,
  id: "",
  logoBigUrl: "https://stage-qlub-cloud.s3.ap-southeast-1.amazonaws.com/temp/92024/m0qnwdbjwtnisc17yh_editedImage.png",
  logoSmallUrl:
    "https://stage-qlub-cloud.s3.ap-southeast-1.amazonaws.com/temp/92024/m0qnwdbjwtnisc17yh_editedImage.png",
  meta: "",
  name: "Embazzy",
  opsMode: "test",
  orderConfig: {},
  orderMode: "default",
  paymentGateways: [
    {
      config: {
        countryCode: "AE",
        disableSavedCard: true,
        fallbackTimeout: 5,
        googleAllowedCardNetworks: ["AMEX", "DISCOVER", "VISA", "MASTERCARD"],
        googleMerchantId: "BCR2DN4TYD76RI2J",
        indicatorTimeout: 5,
        merchantCapabilities: ["supports3DS"],
        priority: 2,
        publicKey: "pk_sbox_hdczitdwiuacggtiofcebg6rlq3",
        refundType: "disabled",
        sandbox: true,
        supportedNetworksList: ["visa", "masterCard", "amex", "discover"]
      },
      countryCode: "ae",
      id: "1733",
      name: "checkout"
    }
  ],
  phone: "+1 (111) 111-1111",
  posVendor: {
    config: {
      ExternalPayments: 0,
      billLayout:
        '[{"color":"primary","icon":"dollar","key":"com_exclusive_fixed","locales":[],"style":"titleSmall","newFormat":true,"useTitle":false,"format":"","vcond":""}]',
      showLoadingPage: false
    },
    posId: "17"
  },
  posVendors: [],
  primaryColour: "",
  qr: "",
  secondaryColour: "",
  status: null,
  timezone: {
    countryCode: "ae",
    timezone: "Asia/Dubai"
  },
  title: "Embazzy",
  unique: "Embazzy"
};
