import React, { useEffect } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { SnackbarProvider } from "notistack";
import { VendorContextProvider } from "@clubpay/customer-common-module/src/context/vendor";
import { CssBaseline } from "@mui/material";
import { ThemeProvider } from "@mui/material/styles";
import { QlubKitTheme } from "@qlub-dev/qlub-kit";
import { default as Popup } from "../src/components/Common/Popup";
import { default as WalletFunctionSheet} from "../src/components/WalletFunctions";
import { default as LoyaltyAuth } from "../src/drivers/customer/Auth";
import { DialogProvider } from "../src/providers/dialog";
import { queryClient } from "../src/providers/query";
import { resetStores } from "../src/store";
import { vendor } from "./data";
import { useGlobalStore } from "../src/store/global";
import { mockLoyaltyProgram } from "../test/_mocks_/generic";

const withMuiTheme = (Story) => (
  <ThemeProvider theme={QlubKitTheme}>
    <CssBaseline />
    <Story />
  </ThemeProvider>
);

const withProviders = (Story) => {
  useEffect(() => {
    useGlobalStore.getState().setSelectedProgram(mockLoyaltyProgram);
  }, []);
  return <SnackbarProvider>
    <VendorContextProvider vendor={vendor}>
      <QueryClientProvider client={queryClient}>
        <DialogProvider>
          <Story />
          <LoyaltyAuth />
          <WalletFunctionSheet
            program={mockLoyaltyProgram}
            onActionClick={() => {}}
            currencyFormat={{
              cc:  "ae",
              cs:  "AED",
              currencyPrecision:  2,
              currencyCommaSeparator:  "disable" 
            }}
          />
          <Popup />
        </DialogProvider>
      </QueryClientProvider>
    </VendorContextProvider>
  </SnackbarProvider>
};

const withStateReset = (Story) => {
  useEffect(() => {
    return resetStores;
  }, []);
  return <Story />;
};

export const decorators = [withMuiTheme, withProviders, withStateReset];

const preview = {
  parameters: {
    actions: { argTypesRegex: "^on[A-Z].*" },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/
      }
    },
    deepControls: { enabled: true },
    options: {
      storySort: (a, b) => {
        return a.id.split("-").length - b.id.split("-").length;
      }
    }
  }
};

export default preview;
