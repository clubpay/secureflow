const i18n = {
  translations: {
    en: {}
  },
  defaultLang: "en",
  useBrowserDefault: true
};

module.exports = i18n;
