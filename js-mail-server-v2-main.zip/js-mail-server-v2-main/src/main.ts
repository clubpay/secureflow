import { NestFactory } from '@nestjs/core';
import { AppModule } from '.';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  await app.listen(process.env.PORT ?? 3000);
}
bootstrap().catch((err) => {
  console.error('Failed to start application:', err);
  setTimeout(() => process.exit(1), 1000);
});
